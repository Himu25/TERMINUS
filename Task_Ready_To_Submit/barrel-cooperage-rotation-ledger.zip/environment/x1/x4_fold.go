package x1

// X4Fold compares ledger open lots against barrel_slot-derived open lots.
func X4Fold(fillBP int64, ledgerOpenLots, slotOpenLots int) int {
	_ = fillBP
	return ledgerOpenLots - slotOpenLots
}
