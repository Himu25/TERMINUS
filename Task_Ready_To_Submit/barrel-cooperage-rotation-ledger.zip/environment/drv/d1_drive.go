package drv

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"sort"
	"strings"

	"coop.lab/x1"
	"coop.lab/n8"
	"coop.lab/q5"
	"coop.lab/pkg/types"
	"coop.lab/r3"
)

func LoadCfg(path string) (types.CellarCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.CellarCfg{}, err
	}
	cfg := types.CellarCfg{
		MaxDriftUnits:      0,
		MaxHeadspacePeakML:     50000,
		MinOpenBarrelsTotal:   1,
		RackPriorityAsc: true,
		HeadspaceScaleMilli: map[int]int{
			1: 120,
			2: 240,
			3: 360,
		},
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "max_drift_units":
			fmt.Sscanf(val, "%d", &cfg.MaxDriftUnits)
		case "max_headspace_peak_ml":
			fmt.Sscanf(val, "%d", &cfg.MaxHeadspacePeakML)
		case "min_open_barrels_total":
			fmt.Sscanf(val, "%d", &cfg.MinOpenBarrelsTotal)
		case "rack_priority_asc":
			cfg.RackPriorityAsc = val == "true" || val == "1"
		case "headspace_window_scale_slot1":
			var v int
			fmt.Sscanf(val, "%d", &v)
			cfg.HeadspaceScaleMilli[1] = v
		case "headspace_window_scale_slot2":
			var v int
			fmt.Sscanf(val, "%d", &v)
			cfg.HeadspaceScaleMilli[2] = v
		case "headspace_window_scale_slot3":
			var v int
			fmt.Sscanf(val, "%d", &v)
			cfg.HeadspaceScaleMilli[3] = v
		}
	}
	return cfg, nil
}

func LoadLayout(path string) (types.VesselLayout, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.VesselLayout{}, err
	}
	var layout struct {
		VintageAbvCentiPct map[string]int `json:"vintage_abv_centi_pct"`
	}
	if err := json.Unmarshal(raw, &layout); err != nil {
		return types.VesselLayout{}, err
	}
	return types.VesselLayout{VintageAbvCentiPct: layout.VintageAbvCentiPct}, nil
}

func LoadEvents(path string) ([]types.TicketRow, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.TicketRow, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var row types.TicketRow
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return nil, err
		}
		out = append(out, row)
	}
	return out, sc.Err()
}

func opCode(kind string) int {
	if kind == "evacuate" {
		return 1
	}
	return 0
}

func pendingFor(weight, slot int, cfg types.CellarCfg) int {
	scale, ok := cfg.HeadspaceScaleMilli[slot]
	if !ok {
		scale = 100
	}
	return weight * scale / 1000
}

func sitePeakPending(site string, slots map[string]slotInfo, cfg types.CellarCfg) int {
	peak := 0
	for key, info := range slots {
		if !strings.HasPrefix(key, site+":") {
			continue
		}
		val := pendingFor(info.weight, info.slot, cfg)
		if val > peak {
			peak = val
		}
	}
	return peak
}

type slotInfo struct {
	slot   int
	weight int
}

func replaySiteState(slots map[string]slotInfo, site string) (fillBP int64, peak int, open_barrels int) {
	prefix := site + ":"
	for key := range slots {
		if !strings.HasPrefix(key, prefix) {
			continue
		}
		open_barrels++
	}
	return 0, 0, open_barrels
}

func Run(cfg types.CellarCfg, layout types.VesselLayout, events []types.TicketRow) (types.CooperageReport, error) {
	ordered := q5.QxOrder(events)
	state := n8.MkK1()
	siteFill := make(map[string]int64)
	stratumFill := make(map[string]int64)
	stratumCount := make(map[string]int)
	slotMeta := make(map[string]slotInfo)

	for _, ev := range ordered {
		arm := layout.VintageAbvCentiPct[ev.VintageID]
		if ev.EventType == "fill" || ev.EventType == "evacuate" {
			delta := r3.Q0Span(opCode(ev.EventType), ev.VolumeML, arm)
			siteFill[ev.RoomID] += delta
			stratumFill[ev.VintageID] += delta
			if ev.EventType == "fill" {
				stratumCount[ev.VintageID]++
			} else if ev.EventType == "evacuate" {
				stratumCount[ev.VintageID]--
			}
		}
		n8.NxTrack(state, ev.RoomID, ev.VintageID, ev.BarrelSlot, ev.EventType, ev.VolumeML)
		key := fmt.Sprintf("%s:%d", ev.RoomID, ev.BarrelSlot)
		switch ev.EventType {
		case "fill":
			slotMeta[key] = slotInfo{slot: ev.BarrelSlot, weight: ev.VolumeML}
		case "evacuate":
			delete(slotMeta, key)
		}
	}

	siteIDs := make([]string, 0)
	seen := make(map[string]bool)
	for _, ev := range events {
		if !seen[ev.RoomID] {
			seen[ev.RoomID] = true
			siteIDs = append(siteIDs, ev.RoomID)
		}
	}
	sort.Strings(siteIDs)

	stratumIDs := make([]string, 0)
	seenRungs := make(map[string]bool)
	for _, ev := range events {
		if !seenRungs[ev.VintageID] {
			seenRungs[ev.VintageID] = true
			stratumIDs = append(stratumIDs, ev.VintageID)
		}
	}
	sort.Strings(stratumIDs)

	report := types.CooperageReport{
		Status:          "ok",
		EventsProcessed: len(ordered),
		Rooms:           make([]types.RoomSnapshot, 0, len(siteIDs)),
		Vessels:          make([]types.VesselSnapshot, 0, len(stratumIDs)),
	}
	var totalFill int64
	maxDrift := 0
	globalHeadspacePeakML := 0
	totalOpenLots := 0
	totalCarry := 0

	for _, site := range siteIDs {
		open_barrels := state.SiteOcc[site]
		fill := siteFill[site]
		peak := sitePeakPending(site, slotMeta, cfg)
		_, _, open_lotsCheck := replaySiteState(slotMeta, site)
		drift := x1.X4Fold(fill, open_barrels, open_lotsCheck)
		if drift < 0 {
			drift = -drift
		}
		if drift > maxDrift {
			maxDrift = drift
		}
		if peak > globalHeadspacePeakML {
			globalHeadspacePeakML = peak
		}
		totalFill += fill
		totalOpenLots += open_barrels
		totalCarry += state.SiteCarry[site]
		report.Rooms = append(report.Rooms, types.RoomSnapshot{
			RoomID:      site,
			MassTotalGrams:      fill,
			HeadspacePeakML: peak,
			OpenBarrels:    open_barrels,
			DriftUnits:  drift,
		})
	}

	for _, stratum := range stratumIDs {
		filled := stratumCount[stratum]
		if filled < 0 {
			filled = 0
		}
		fill := stratumFill[stratum]
		ratio := 0
		if filled > 0 {
			ratio = int(fill) / filled
		}
		report.Vessels = append(report.Vessels, types.VesselSnapshot{
			VintageID:   stratum,
			Filled:      filled,
			MassRatioBP: ratio,
			DriftUnits:  0,
		})
	}

	report.MassTotalGrams = totalFill
	report.HeadspacePeakML = globalHeadspacePeakML
	report.OpenBarrelsTotal = totalOpenLots
	report.ToppingMissTotal = totalCarry
	report.MaxDriftUnits = maxDrift
	report.ReportOK = maxDrift <= cfg.MaxDriftUnits &&
		globalHeadspacePeakML <= cfg.MaxHeadspacePeakML &&
		totalOpenLots >= cfg.MinOpenBarrelsTotal
	if !report.ReportOK {
		report.Status = "drift"
	}

	digest, err := digestFor(report)
	if err != nil {
		return types.CooperageReport{}, err
	}
	report.ReportDigest = digest
	return report, nil
}

func digestFor(report types.CooperageReport) (string, error) {
	payload := report
	payload.ReportDigest = ""
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return "", err
	}
	raw := bytes.TrimSpace(buf.Bytes())
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:]), nil
}

func WriteReport(path string, report types.CooperageReport) error {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	enc.SetIndent("", "  ")
	if err := enc.Encode(report); err != nil {
		return err
	}
	return os.WriteFile(path, bytes.TrimSpace(buf.Bytes()), 0o644)
}
