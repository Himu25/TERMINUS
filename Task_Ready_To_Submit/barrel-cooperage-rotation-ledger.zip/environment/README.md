# Cooperage rotation replay harness

Rebuild with `/app/scripts/build.sh`, run `/app/tools/run_replay`, read `/app/output/cooperage_report.json`.

Policy and layout references live under `/app/docs/` and `/app/data/`.
