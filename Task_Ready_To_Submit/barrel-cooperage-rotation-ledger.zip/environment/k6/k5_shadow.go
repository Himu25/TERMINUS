package k6

// Q0Shadow probes slot occupancy deltas for CI smoke.
func Q0Shadow(before, after int) int {
	if after >= before {
		return after - before
	}
	return before - after
}
