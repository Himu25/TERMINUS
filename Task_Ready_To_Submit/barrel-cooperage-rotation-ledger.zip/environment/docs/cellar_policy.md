Cooperage rotation replay semantics

ABV-weighted mass grams per room use transfer volume_ml times the vintage ABV arm from /app/data/vessel_layout.json (vintage_abv_centi_pct: centi-percent units, not standard basis points). Scale with divisor 100: mass_total_grams = volume_ml * arm / 100 (e.g. V2021-PN arm 120 on a 12000-ml fill accrues 14400 grams). Fill events add mass grams; evacuate events subtract the same ABV arm used at placement.

Headspace window peak per room is an end-of-replay value, not a running peak across events. After all tickets are applied, take each occupied barrel slot in the room and compute its topping-window load as volume_ml times the barrel_slot headspace-window scale from /app/config/cellar.toml divided by 1000; headspace_peak_ml for the room is the maximum of those loads among slots still occupied at replay end. Report-level headspace_peak_ml is the maximum across rooms.

Open barrels counts distinct occupied barrel slots per room after replay. Topping-bind miss increments per room on topping_bind events and feeds topping_miss_total. Drift units compare ledger open barrels against barrel-slot-derived open barrels for each room.

Vessel filled is the net fill count for that vintage_id (increment on fill, decrement on evacuate), floored at zero. Vessel mass_ratio_bp is the vintage accrued mass grams divided by filled using integer division when filled is positive, otherwise zero.

Rack tie-break: when seq values match, lower rack_lane runs first when rack_priority_asc is true in /app/config/cellar.toml.

Report JSON top-level fields: status, events_processed, report_ok, max_drift_units, mass_total_grams, headspace_peak_ml, topping_miss_total, open_barrels_total, report_digest, rooms, vessels. Each room row carries room_id, mass_total_grams, headspace_peak_ml, open_barrels, drift_units. Each vessel row carries vintage_id, filled, mass_ratio_bp, drift_units. Report digest is 64 lowercase hex from compact JSON with report_digest blanked.
