package summ

import "coop.lab/pkg/types"

// S8Fold totals fill basis points across site snapshots.
func S8Fold(rooms []types.RoomSnapshot) int64 {
	var sum int64
	for _, site := range rooms {
		sum += site.MassTotalGrams
	}
	return sum
}
