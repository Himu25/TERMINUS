#!/bin/bash
set -euo pipefail
test -x /app/scripts/build.sh
/app/scripts/build.sh
