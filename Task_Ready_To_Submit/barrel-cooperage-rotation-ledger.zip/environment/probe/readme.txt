probe harness placeholder
