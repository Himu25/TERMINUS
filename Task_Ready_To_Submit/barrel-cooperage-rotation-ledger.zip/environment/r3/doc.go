// Package r3 exposes the native arm integrator to Go callers.
package r3
