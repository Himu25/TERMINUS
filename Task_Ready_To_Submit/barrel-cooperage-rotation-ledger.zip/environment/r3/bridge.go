package r3

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libr3_arm.a -ldl -lm
#include "fold_arm.h"
*/
import "C"

func Q0Span(op int, weight, armBP int) int64 {
	raw := C.q0_span(C.int(op), C.int(weight), C.int(armBP))
	return int64(raw)
}
