#ifndef FOLD_ARM_H
#define FOLD_ARM_H

int q0_span(int op, int weight, int arm_bp);

#endif
