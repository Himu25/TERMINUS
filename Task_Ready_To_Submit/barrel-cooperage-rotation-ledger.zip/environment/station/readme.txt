shore-side station notes
