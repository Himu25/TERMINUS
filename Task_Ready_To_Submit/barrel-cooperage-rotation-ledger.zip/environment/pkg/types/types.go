// CooperageReport is written to /app/output/cooperage_report.json by cooperaudit.
// Top-level keys: status, events_processed, report_ok, max_drift_units,
// mass_total_grams, headspace_peak_ml, topping_miss_total, open_barrels_total,
// report_digest, rooms, vessels.
package types

type CellarCfg struct {
	MaxDriftUnits          int
	MaxHeadspacePeakML    int
	MinOpenBarrelsTotal       int
	RackPriorityAsc        bool
	HeadspaceScaleMilli map[int]int
}

type VesselLayout struct {
	VintageAbvCentiPct map[string]int `json:"vintage_abv_centi_pct"`
}

type TicketRow struct {
	EventID       string `json:"event_id"`
	Seq           int    `json:"seq"`
	RackLane        string `json:"rack_lane"`
	RoomID        string `json:"room_id"`
	VintageID         string `json:"vintage_id"`
	BarrelSlot           int    `json:"barrel_slot"`
	EventType     string `json:"event_type"`
	VolumeML int    `json:"volume_ml"`
}

type RoomSnapshot struct {
	RoomID           string `json:"room_id"`
	MassTotalGrams     int64  `json:"mass_total_grams"`
	HeadspacePeakML int    `json:"headspace_peak_ml"`
	OpenBarrels         int    `json:"open_barrels"`
	DriftUnits       int    `json:"drift_units"`
}

type VesselSnapshot struct {
	VintageID          string `json:"vintage_id"`
	Filled         int    `json:"filled"`
	MassRatioBP int    `json:"mass_ratio_bp"`
	DriftUnits     int    `json:"drift_units"`
}

type CooperageReport struct {
	Status              string           `json:"status"`
	EventsProcessed     int              `json:"events_processed"`
	ReportOK            bool             `json:"report_ok"`
	MaxDriftUnits       int              `json:"max_drift_units"`
	MassTotalGrams   int64            `json:"mass_total_grams"`
	HeadspacePeakML    int              `json:"headspace_peak_ml"`
	ToppingMissTotal     int              `json:"topping_miss_total"`
	OpenBarrelsTotal       int              `json:"open_barrels_total"`
	ReportDigest        string           `json:"report_digest"`
	Rooms               []RoomSnapshot   `json:"rooms"`
	Vessels             []VesselSnapshot   `json:"vessels"`
}
