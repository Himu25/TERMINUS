module coop.lab

go 1.24
