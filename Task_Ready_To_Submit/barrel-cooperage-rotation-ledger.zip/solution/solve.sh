#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/cellar.toml
require_file /app/data/tickets_manifest.jsonl
require_file /app/data/vessel_layout.json
mkdir -p /app/bin /app/output

log "install corrected ABV mass engine"
install -m 0644 "${ROOT_DIR}/fixed/lib.rs" /app/r3/src/lib.rs

log "install corrected lot lineage ledger"
install -m 0644 "${ROOT_DIR}/fixed/n2_record.go" /app/n8/n2_record.go

log "install corrected rack ordering"
install -m 0644 "${ROOT_DIR}/fixed/q3_pick.go" /app/q5/q3_pick.go

log "rebuild cooperage audit harness"
bash /app/scripts/build.sh

log "refresh default ticket bundle"
/app/bin/ticketpack /app/data/tickets_manifest.jsonl /app/data/tickets_default.jsonl

log "emit default cooperage report"
/app/tools/run_replay

log "post-run validation against cellar.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg = {}
for line in Path("/app/config/cellar.toml").read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = (part.strip() for part in line.split("=", 1))
    if k in ("max_drift_units", "max_headspace_peak_ml", "min_open_barrels_total"):
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/cooperage_report.json").read_text())
assert report["status"] == "ok", report
assert report["report_ok"]
assert report["max_drift_units"] <= cfg["max_drift_units"]
assert report["open_barrels_total"] >= cfg["min_open_barrels_total"]
assert report["headspace_peak_ml"] <= cfg["max_headspace_peak_ml"]
print("ok", report["mass_total_grams"], report["open_barrels_total"])
PY

log "oracle complete"
