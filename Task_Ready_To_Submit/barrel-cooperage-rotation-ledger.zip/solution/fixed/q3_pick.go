package q5

import (
	"sort"

	"coop.lab/pkg/types"
)

func q2_rank(id string) int {
	if len(id) == 0 {
		return 99
	}
	last := id[len(id)-1]
	if last >= '0' && last <= '9' {
		return int(last - '0')
	}
	return 99
}

func q2_less(a, b types.TicketRow) bool {
	if a.Seq != b.Seq {
		return a.Seq < b.Seq
	}
	ra, rb := q2_rank(a.RackLane), q2_rank(b.RackLane)
	if ra != rb {
		return ra < rb
	}
	if a.RackLane != b.RackLane {
		return a.RackLane < b.RackLane
	}
	return a.VintageID < b.VintageID
}

func QxOrder(rows []types.TicketRow) []types.TicketRow {
	out := make([]types.TicketRow, len(rows))
	copy(out, rows)
	sort.SliceStable(out, func(i, j int) bool {
		return q2_less(out[i], out[j])
	})
	return out
}
