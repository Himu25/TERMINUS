"""Validate /app/output/cooperage_report.json against cellar.toml guardrails."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "cooperage_report.json"
TICKETS = APP / "data" / "tickets_default.jsonl"
LAYOUT = APP / "data" / "vessel_layout.json"
CFG = APP / "config" / "cellar.toml"
CASES = Path(__file__).resolve().parent / "data"

_DEFAULT_TICKETS_TEXT = TICKETS.read_text(encoding="utf-8") if TICKETS.is_file() else ""

REPORT_KEYS = frozenset(
    {
        "status",
        "events_processed",
        "report_ok",
        "max_drift_units",
        "mass_total_grams",
        "headspace_peak_ml",
        "topping_miss_total",
        "open_barrels_total",
        "report_digest",
        "rooms",
        "vessels",
    }
)
ROOM_KEYS = frozenset(
    {
        "room_id",
        "mass_total_grams",
        "headspace_peak_ml",
        "open_barrels",
        "drift_units",
    }
)
VESSEL_KEYS = frozenset(
    {
        "vintage_id",
        "filled",
        "mass_ratio_bp",
        "drift_units",
    }
)


def _parse_cfg() -> dict[str, int]:
    cfg: dict[str, int] = {
        "max_drift_units": 0,
        "max_headspace_peak_ml": 50000,
        "min_open_barrels_total": 1,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in cfg:
            cfg[key] = int(float(val))
    return cfg


def _load_layout() -> dict[str, dict]:
    raw = json.loads(LAYOUT.read_text(encoding="utf-8"))
    vintage_abv = {k: v for k, v in raw["vintage_abv_centi_pct"].items()}
    window_scale = {1: 120, 2: 240, 3: 360}
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key == "headspace_window_scale_slot1":
            window_scale[1] = int(float(val))
        elif key == "headspace_window_scale_slot2":
            window_scale[2] = int(float(val))
        elif key == "headspace_window_scale_slot3":
            window_scale[3] = int(float(val))
    return {"vintage_abv": vintage_abv, "window_scale": window_scale}


def _parse_tickets(text: str) -> list[dict]:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if line:
            rows.append(json.loads(line))
    return rows


def _rack_rank(rack_lane: str) -> int:
    if not rack_lane:
        return 99
    last = rack_lane[-1]
    if last.isdigit():
        return int(last)
    return 99


def _sort_tickets(rows: list[dict]) -> list[dict]:
    return sorted(
        rows,
        key=lambda row: (row["seq"], _rack_rank(row["rack_lane"]), row["rack_lane"], row["vintage_id"]),
    )


def _slot_key(room: str, barrel_slot: int) -> str:
    return f"{room}:{barrel_slot}"


def _expected_from_tickets(tickets_text: str) -> dict[str, dict]:
    layout = _load_layout()
    vintage_abv = layout["vintage_abv"]
    window_scale = layout["window_scale"]
    ordered = _sort_tickets(_parse_tickets(tickets_text))
    lots: dict[str, dict] = {}
    room_mass: dict[str, int] = {}
    room_occ: dict[str, int] = {}
    room_carry: dict[str, int] = {}
    rung_accrued: dict[str, int] = {}
    rung_count: dict[str, int] = {}

    for ev in ordered:
        room = ev["room_id"]
        key = _slot_key(room, ev["barrel_slot"])
        abv = vintage_abv[ev["vintage_id"]]
        notional = ev["volume_ml"]
        if ev["event_type"] in ("fill", "evacuate"):
            delta = notional * abv // 100
            if ev["event_type"] == "evacuate":
                delta = -delta
            room_mass[room] = room_mass.get(room, 0) + delta
            rung_accrued[ev["vintage_id"]] = rung_accrued.get(ev["vintage_id"], 0) + delta
            if ev["event_type"] == "fill":
                rung_count[ev["vintage_id"]] = rung_count.get(ev["vintage_id"], 0) + 1
            else:
                rung_count[ev["vintage_id"]] = rung_count.get(ev["vintage_id"], 0) - 1
        if ev["event_type"] == "fill":
            if key not in lots:
                room_occ[room] = room_occ.get(room, 0) + 1
            lots[key] = {"barrel_slot": ev["barrel_slot"], "volume_ml": notional}
        elif ev["event_type"] == "evacuate" and key in lots:
            del lots[key]
            room_occ[room] = room_occ.get(room, 0) - 1
        elif ev["event_type"] == "topping_bind":
            room_carry[room] = room_carry.get(room, 0) + 1

    rooms: dict[str, dict] = {}
    for room in sorted({ev["room_id"] for ev in ordered}):
        prefix = f"{room}:"
        lot_open = sum(1 for k in lots if k.startswith(prefix))
        peak = 0
        for k, info in lots.items():
            if not k.startswith(prefix):
                continue
            window = info["volume_ml"] * window_scale[info["barrel_slot"]] // 1000
            peak = max(peak, window)
        rooms[room] = {
            "mass_total_grams": room_mass.get(room, 0),
            "open_barrels": room_occ.get(room, 0),
            "headspace_peak_ml": peak,
            "drift_units": abs(room_occ.get(room, 0) - lot_open),
        }

    vessels: dict[str, dict] = {}
    for vintage_id in sorted({ev["vintage_id"] for ev in ordered}):
        filled = max(rung_count.get(vintage_id, 0), 0)
        accrued = rung_accrued.get(vintage_id, 0)
        ratio = accrued // filled if filled > 0 else 0
        vessels[vintage_id] = {
            "filled": filled,
            "mass_ratio_bp": ratio,
            "drift_units": 0,
        }

    total_accrued = sum(v["mass_total_grams"] for v in rooms.values())
    total_open = sum(v["open_barrels"] for v in rooms.values())
    global_window = max((v["headspace_peak_ml"] for v in rooms.values()), default=0)
    max_drift = max((v["drift_units"] for v in rooms.values()), default=0)
    total_carry = sum(room_carry.values())
    return {
        "rooms": rooms,
        "vessels": vessels,
        "mass_total_grams": total_accrued,
        "open_barrels_total": total_open,
        "headspace_peak_ml": global_window,
        "topping_miss_total": total_carry,
        "max_drift_units": max_drift,
        "events_processed": len(ordered),
    }


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _swap_fixture(stem: str) -> str:
    src = CASES / f"{stem}.jsonl"
    text = src.read_text(encoding="utf-8")
    _atomic_write_text(TICKETS, text)
    return text


def _expected_digest(report: dict) -> str:
    payload = dict(report)
    payload["report_digest"] = ""
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _invoke_default() -> None:
    proc = subprocess.run(
        ["/app/tools/run_replay"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "cooperage_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


def _room_map(report: dict) -> dict[str, dict]:
    return {row["room_id"]: row for row in report["rooms"]}


def _vessel_map(report: dict) -> dict[str, dict]:
    return {row["vintage_id"]: row for row in report["vessels"]}


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    _invoke_default()


@pytest.fixture(autouse=True)
def restore_default_tickets() -> None:
    yield
    if _DEFAULT_TICKETS_TEXT:
        _atomic_write_text(TICKETS, _DEFAULT_TICKETS_TEXT)


def test_h1_schema() -> None:
    """Report must expose only the documented top-level keys."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS


def test_h8_row_shape() -> None:
    """Each room and vessel row must match the documented schemas."""
    report = _load_report()
    assert report["rooms"]
    assert report["vessels"]
    for row in report["rooms"]:
        assert set(row.keys()) == ROOM_KEYS
        assert isinstance(row["room_id"], str) and row["room_id"]
        assert isinstance(row["mass_total_grams"], int)
        assert isinstance(row["headspace_peak_ml"], int)
        assert isinstance(row["open_barrels"], int)
        assert isinstance(row["drift_units"], int)
    for row in report["vessels"]:
        assert set(row.keys()) == VESSEL_KEYS
        assert isinstance(row["vintage_id"], str) and row["vintage_id"]
        assert isinstance(row["filled"], int)
        assert isinstance(row["mass_ratio_bp"], int)
        assert isinstance(row["drift_units"], int)


def test_h2_guardrails() -> None:
    """Default bundle must finish ok and meet cellar.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["report_ok"]
    assert report["max_drift_units"] <= cfg["max_drift_units"]
    assert report["open_barrels_total"] >= cfg["min_open_barrels_total"]
    assert report["headspace_peak_ml"] <= cfg["max_headspace_peak_ml"]


def test_h3_total_a() -> None:
    """Default replay mass_total_grams must match layout-derived replay."""
    expected = _expected_from_tickets(_DEFAULT_TICKETS_TEXT)
    report = _load_report()
    assert report["mass_total_grams"] == expected["mass_total_grams"]


def test_h4_total_b() -> None:
    """Default replay open_barrels_total must match barrel_slot-derived open barrels."""
    expected = _expected_from_tickets(_DEFAULT_TICKETS_TEXT)
    report = _load_report()
    assert report["open_barrels_total"] == expected["open_barrels_total"]


def test_h5_row_a() -> None:
    """R01 mass after V2021-PN evacuate must match layout-derived replay."""
    expected = _expected_from_tickets(_DEFAULT_TICKETS_TEXT)
    report = _load_report()
    r01 = _room_map(report)["R01"]
    assert r01["mass_total_grams"] == expected["rooms"]["R01"]["mass_total_grams"]


def test_h6_row_b() -> None:
    """R01 open barrels after V2021-PN evacuate must match barrel_slot ledger."""
    cfg = _parse_cfg()
    expected = _expected_from_tickets(_DEFAULT_TICKETS_TEXT)
    report = _load_report()
    r01 = _room_map(report)["R01"]
    assert r01["open_barrels"] == expected["rooms"]["R01"]["open_barrels"]
    assert r01["drift_units"] <= cfg["max_drift_units"]


def test_h7_row_c() -> None:
    """R04 barrel_slot clash must reflect L1-first tie resolution."""
    expected = _expected_from_tickets(_DEFAULT_TICKETS_TEXT)
    report = _load_report()
    r04 = _room_map(report)["R04"]
    assert r04["mass_total_grams"] == expected["rooms"]["R04"]["mass_total_grams"]
    assert r04["open_barrels"] == expected["rooms"]["R04"]["open_barrels"]


def test_h16_row_d() -> None:
    """R03 seq-50 rack tie must reflect L1-first ordering on default bundle."""
    expected = _expected_from_tickets(_DEFAULT_TICKETS_TEXT)
    report = _load_report()
    r03 = _room_map(report)["R03"]
    assert r03["mass_total_grams"] == expected["rooms"]["R03"]["mass_total_grams"]
    assert r03["open_barrels"] == expected["rooms"]["R03"]["open_barrels"]


def test_h17_row_e() -> None:
    """R02 stacked triple on default bundle must reconcile mass and headspace peak."""
    expected = _expected_from_tickets(_DEFAULT_TICKETS_TEXT)
    report = _load_report()
    r02 = _room_map(report)["R02"]
    assert r02["mass_total_grams"] == expected["rooms"]["R02"]["mass_total_grams"]
    assert r02["headspace_peak_ml"] == expected["rooms"]["R02"]["headspace_peak_ml"]


def test_h18_total_c() -> None:
    """Default replay headspace_peak_ml must match barrel-slot window replay."""
    expected = _expected_from_tickets(_DEFAULT_TICKETS_TEXT)
    report = _load_report()
    assert report["headspace_peak_ml"] == expected["headspace_peak_ml"]


def test_h19_total_d() -> None:
    """Default replay topping_miss_total must match topping-bind carry replay."""
    expected = _expected_from_tickets(_DEFAULT_TICKETS_TEXT)
    report = _load_report()
    assert report["topping_miss_total"] == expected["topping_miss_total"]


def test_h20_vessel_a() -> None:
    """Default vessel rows must reconcile filled counts and mass_ratio_bp."""
    expected = _expected_from_tickets(_DEFAULT_TICKETS_TEXT)
    report = _load_report()
    vessels = _vessel_map(report)
    for vintage_id, want in expected["vessels"].items():
        got = vessels[vintage_id]
        assert got["filled"] == want["filled"]
        assert got["mass_ratio_bp"] == want["mass_ratio_bp"]
        assert got["drift_units"] == want["drift_units"]


def test_h9_count() -> None:
    """events_processed must equal non-empty rows in the active bundle."""
    expected = _expected_from_tickets(_DEFAULT_TICKETS_TEXT)
    report = _load_report()
    assert report["events_processed"] == expected["events_processed"]


def test_h15_digest() -> None:
    """report_digest must hash the compact pre-digest JSON payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_h10_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_h11_case_a() -> None:
    """Dual-rack open scenario must reconcile R01 mass and open barrels."""
    tickets_text = _swap_fixture("dual_rack_open")
    _invoke_default()
    expected = _expected_from_tickets(tickets_text)
    report = _load_report()
    r01 = _room_map(report)["R01"]
    assert report["status"] == "ok"
    assert r01["mass_total_grams"] == expected["rooms"]["R01"]["mass_total_grams"]
    assert r01["open_barrels"] == expected["rooms"]["R01"]["open_barrels"]


def test_h12_case_b() -> None:
    """Stacked triple scenario must reconcile R02 mass and headspace window."""
    tickets_text = _swap_fixture("stacked_triple")
    _invoke_default()
    expected = _expected_from_tickets(tickets_text)
    report = _load_report()
    r02 = _room_map(report)["R02"]
    assert report["status"] == "ok"
    assert r02["mass_total_grams"] == expected["rooms"]["R02"]["mass_total_grams"]
    assert r02["open_barrels"] == expected["rooms"]["R02"]["open_barrels"]
    assert r02["headspace_peak_ml"] == expected["rooms"]["R02"]["headspace_peak_ml"]


def test_h13_case_c() -> None:
    """Slot clash scenario must keep L1-first volume on R04."""
    tickets_text = _swap_fixture("slot_clash")
    _invoke_default()
    expected = _expected_from_tickets(tickets_text)
    report = _load_report()
    r04 = _room_map(report)["R04"]
    assert report["status"] == "ok"
    assert r04["mass_total_grams"] == expected["rooms"]["R04"]["mass_total_grams"]
    assert r04["headspace_peak_ml"] == expected["rooms"]["R04"]["headspace_peak_ml"]


def test_h14_case_d() -> None:
    """Evacuate-after-peer scenario must reconcile R01 drift and topping-bind miss."""
    tickets_text = _swap_fixture("evacuate_after_peer")
    _invoke_default()
    expected = _expected_from_tickets(tickets_text)
    cfg = _parse_cfg()
    report = _load_report()
    r01 = _room_map(report)["R01"]
    assert report["report_ok"]
    assert r01["drift_units"] <= cfg["max_drift_units"]
    assert r01["open_barrels"] == expected["rooms"]["R01"]["open_barrels"]
    assert report["topping_miss_total"] == expected["topping_miss_total"]
