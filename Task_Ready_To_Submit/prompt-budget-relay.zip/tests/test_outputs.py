"""Validate /app/output/budget_bench.json against pinned budget guardrails."""

from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "budget_bench.json"
CFG = APP / "config" / "budget.toml"
MANIFEST = APP / "registry" / "budget_manifest.json"

# Pinned profile thresholds — gate comparisons use these, not agent-mutable config.
PINNED_THRESHOLDS = {
    "success_floor": 0.92,
    "max_mean_slot_count": 42.0,
    "max_mean_dup_ratio": 0.18,
    "max_mean_token_units": 28000.0,
    "anchor_span_floor": 0.95,
    "structured_success_floor": 0.90,
    "multilingual_success_floor": 0.88,
    "budget_profile": "v3",
}
PINNED_MANIFEST = {
    "budget_profile": "v3",
    "notes": "Structure-aware pane assembly with x9fold dedup before slot registration.",
}
RUNS = APP / "data" / "runs_default.jsonl"
RUN_SPECS = APP / "data" / "run_specs.jsonl"
DIGEST_TABLE = APP / "ref" / "anchors" / "digest_table.json"
FIXTURES = Path(__file__).resolve().parent / "fixtures"
SEGMENT_OVERHEAD_UNITS = 4

REPORT_KEYS = frozenset(
    {
        "status",
        "corpus_docs",
        "budget_profile",
        "runs_total",
        "mean_success_rate",
        "mean_slot_count",
        "mean_dup_ratio",
        "mean_token_units",
        "anchor_span_rate",
        "report_digest",
        "runs",
    }
)
RUN_KEYS = frozenset(
    {
        "run_id",
        "success_rate",
        "slot_count",
        "dup_ratio",
        "token_units",
        "anchor_spans",
        "query_hits",
        "segment_ids",
    }
)

_SUBPROC_ENV = os.environ.copy()
_SUBPROC_ENV["PATH"] = "/usr/local/go/bin:/app/bin:" + _SUBPROC_ENV.get("PATH", "")
_SUBPROC_ENV["LD_LIBRARY_PATH"] = "/app/lib:" + _SUBPROC_ENV.get("LD_LIBRARY_PATH", "")
_BUILD_TIMEOUT = 240
_RUN_TIMEOUT = 120


def _parse_budget_toml_thresholds() -> dict:
    cfg: dict = {}
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key.endswith("_floor") or key.startswith("max_mean_"):
            cfg[key] = float(val)
        elif key == "budget_profile":
            cfg[key] = val
    return cfg


def _assert_config_integrity() -> None:
    """budget.toml and budget_manifest.json must match the intended profile."""
    parsed = _parse_budget_toml_thresholds()
    for key, expected in PINNED_THRESHOLDS.items():
        assert parsed.get(key) == expected, f"budget.toml field {key!r} was tampered"
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    assert manifest == PINNED_MANIFEST, "budget_manifest.json was tampered"


def _parse_cfg() -> dict:
    _assert_config_integrity()
    return dict(PINNED_THRESHOLDS)


def _round4(value: float) -> float:
    return int(value * 10000 + 0.5) / 10000


def _digest_body(report: dict) -> str:
    body = dict(report)
    body["report_digest"] = ""
    raw = json.dumps(body, separators=(",", ":"))
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _rebuild_and_run(
    runs_path: Path | None = None,
    out_path: Path | None = None,
    corpus_path: Path | None = None,
) -> dict:
    runs_path = runs_path or RUNS
    out_path = out_path or OUT
    env = dict(_SUBPROC_ENV)
    if corpus_path is not None:
        env["TB_CORPUS_PATH"] = str(corpus_path)
    else:
        env.pop("TB_CORPUS_PATH", None)
    out_path.unlink(missing_ok=True)
    subprocess.run(
        ["bash", "/app/scripts/build_all.sh"],
        cwd=APP,
        check=True,
        timeout=_BUILD_TIMEOUT,
        env=env,
    )
    subprocess.run(
        ["/app/bin/budgetbench", runs_path.as_posix(), out_path.as_posix()],
        cwd=APP,
        check=True,
        timeout=_RUN_TIMEOUT,
        env=env,
    )
    return json.loads(out_path.read_text(encoding="utf-8"))


def _run_rows(report: dict) -> dict[str, dict]:
    return {row["run_id"]: row for row in report["runs"]}


def _load_run_specs() -> dict[str, list[str]]:
    specs: dict[str, list[str]] = {}
    for line in RUN_SPECS.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        obj = json.loads(line)
        specs[obj["run_id"]] = obj["doc_ids"]
    return specs


def _gold_digests_for_run(run_id: str) -> list[str]:
    table = json.loads(DIGEST_TABLE.read_text(encoding="utf-8"))
    specs = _load_run_specs()
    out: list[str] = []
    for doc_id in specs[run_id]:
        out.extend(table.get(doc_id, []))
    return out


def _assert_fixture_pack(pack: str, cfg: dict) -> dict:
    corpus = FIXTURES / pack / "corpus.json"
    specs = FIXTURES / pack / "run_specs.jsonl"
    tmp_out = APP / "output" / f"budget_{pack}.json"
    report = _rebuild_and_run(specs, tmp_out, corpus)
    assert report["status"] == "ok"
    assert report["mean_success_rate"] >= cfg["success_floor"]
    assert report["mean_slot_count"] <= cfg["max_mean_slot_count"]
    assert report["anchor_span_rate"] >= cfg["anchor_span_floor"]
    return report


@pytest.fixture(scope="module")
def cfg() -> dict:
    return _parse_cfg()


@pytest.fixture(scope="module")
def default_report() -> dict:
    if not OUT.is_file():
        _rebuild_and_run()
    return json.loads(OUT.read_text(encoding="utf-8"))


def test_budgetbench_binary_exists() -> None:
    """The budgetbench driver binary is present after environment build."""
    bench = APP / "bin" / "budgetbench"
    assert bench.is_file() and os.access(bench, os.X_OK)


def test_budget_config_untampered() -> None:
    """Mutable config files must still match the intended budget profile."""
    _assert_config_integrity()


def test_report_schema_and_digest(default_report: dict) -> None:
    """Top-level schema and report_digest must match compact pre-digest JSON."""
    assert set(default_report.keys()) == REPORT_KEYS
    assert re.fullmatch(r"[0-9a-f]{64}", default_report["report_digest"])
    assert default_report["report_digest"] == _digest_body(default_report)
    for row in default_report["runs"]:
        assert set(row.keys()) == RUN_KEYS


def test_default_pack_quality_floors(default_report: dict, cfg: dict) -> None:
    """Default run pack must meet budget.toml mean floors and ceilings."""
    assert default_report["status"] == "ok"
    assert default_report["runs_total"] == len(
        [ln for ln in RUNS.read_text(encoding="utf-8").splitlines() if ln.strip()]
    )
    assert default_report["mean_success_rate"] >= cfg["success_floor"]
    assert default_report["mean_slot_count"] <= cfg["max_mean_slot_count"]
    assert default_report["mean_dup_ratio"] <= cfg["max_mean_dup_ratio"]
    assert default_report["mean_token_units"] <= cfg["max_mean_token_units"]
    assert default_report["anchor_span_rate"] >= cfg["anchor_span_floor"]


def test_summary_means_recomputed_from_run_rows(default_report: dict) -> None:
    """Aggregate means must match the arithmetic mean of per-run rows."""
    rows = default_report["runs"]
    n = len(rows)
    assert n > 0
    assert default_report["mean_success_rate"] == _round4(
        sum(r["success_rate"] for r in rows) / n
    )
    assert default_report["mean_slot_count"] == _round4(
        sum(r["slot_count"] for r in rows) / n
    )
    assert default_report["mean_dup_ratio"] == _round4(
        sum(r["dup_ratio"] for r in rows) / n
    )
    assert default_report["mean_token_units"] == _round4(
        sum(r["token_units"] for r in rows) / n
    )


def test_success_hits_consistent_with_gold_table(default_report: dict) -> None:
    """Per-run success_rate must align with canonical digest_table gold counts."""
    for row in default_report["runs"]:
        gold = _gold_digests_for_run(row["run_id"])
        if not gold:
            continue
        implied_hits = row["success_rate"] * len(gold)
        assert abs(implied_hits - round(implied_hits)) < 1e-3
        assert row["success_rate"] <= 1.0
        assert row["query_hits"] == row["slot_count"]


def test_token_units_minimum_overhead(default_report: dict) -> None:
    """Each emitted segment contributes four overhead units beyond raw text."""
    for row in default_report["runs"]:
        assert row["token_units"] >= row["slot_count"] * SEGMENT_OVERHEAD_UNITS


def test_table_code_run_anchor_spans(default_report: dict, cfg: dict) -> None:
    """r_table_code_fence must preserve fenced and table blocks as intact spans."""
    row = _run_rows(default_report)["r_table_code_fence"]
    assert row["anchor_spans"] >= 2
    assert row["success_rate"] >= cfg["structured_success_floor"]


def test_structured_long_run_success(default_report: dict, cfg: dict) -> None:
    """r_structured_long must reach structured_success_floor."""
    row = _run_rows(default_report)["r_structured_long"]
    assert row["success_rate"] >= cfg["structured_success_floor"]


def test_overlap_stress_low_redundancy(default_report: dict, cfg: dict) -> None:
    """r_overlap_stress must keep dup_ratio under the configured ceiling."""
    row = _run_rows(default_report)["r_overlap_stress"]
    assert row["dup_ratio"] <= cfg["max_mean_dup_ratio"]
    assert row["slot_count"] <= cfg["max_mean_slot_count"]


def test_per_run_token_units_ceiling(default_report: dict, cfg: dict) -> None:
    """Every run row must stay within max_mean_token_units."""
    for row in default_report["runs"]:
        assert row["token_units"] <= cfg["max_mean_token_units"]


def test_segment_ids_sorted_per_run(default_report: dict) -> None:
    """segment_ids within each run must be lexicographically sorted."""
    for row in default_report["runs"]:
        ids = row["segment_ids"]
        assert ids == sorted(ids)


def test_multilingual_run_slot_budget(default_report: dict, cfg: dict) -> None:
    """Multilingual blend run must not exceed the mean slot ceiling."""
    row = _run_rows(default_report)["r_multilingual_blend"]
    assert row["slot_count"] <= cfg["max_mean_slot_count"]
    assert row["success_rate"] >= cfg["multilingual_success_floor"]


def test_budget_profile_matches_manifest(default_report: dict) -> None:
    """budget_profile in the report must match registry budget_manifest.json."""
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    assert default_report["budget_profile"] == manifest["budget_profile"]


def test_determinism_repeat_run(default_report: dict) -> None:
    """Identical inputs must yield byte-identical budget_bench.json."""
    first = OUT.read_bytes()
    _rebuild_and_run()
    second = OUT.read_bytes()
    assert first == second


def test_pack_long_structured_regression(cfg: dict) -> None:
    """Hidden long structured corpus must pass success and slot ceilings."""
    _assert_fixture_pack("pack_long_structured", cfg)


def test_pack_table_code_regression(cfg: dict) -> None:
    """Hidden table and fenced-code corpus must pass anchor span and success floors."""
    report = _assert_fixture_pack("pack_table_code", cfg)
    row = report["runs"][0]
    assert row["anchor_spans"] >= 2
    assert row["success_rate"] >= cfg["structured_success_floor"]


def test_pack_multilingual_regression(cfg: dict) -> None:
    """Hidden multilingual corpus must pass success and slot ceilings."""
    report = _assert_fixture_pack("pack_multilingual", cfg)
    row = report["runs"][0]
    assert row["success_rate"] >= cfg["multilingual_success_floor"]


def test_pack_overlap_hidden_regression(cfg: dict) -> None:
    """Hidden overlap corpus must keep dup_ratio and slot_count within ceilings."""
    report = _assert_fixture_pack("pack_overlap_hidden", cfg)
    row = report["runs"][0]
    assert row["dup_ratio"] <= cfg["max_mean_dup_ratio"]
    assert row["slot_count"] <= cfg["max_mean_slot_count"]
    assert report["mean_dup_ratio"] <= cfg["max_mean_dup_ratio"]


def test_pack_token_budget_regression(cfg: dict) -> None:
    """Hidden token budget corpus must honor the four-unit per-segment overhead rule."""
    corpus = FIXTURES / "pack_token_budget" / "corpus.json"
    char_budget = sum(len(doc["text"]) for doc in json.loads(corpus.read_text(encoding="utf-8")))
    report = _assert_fixture_pack("pack_token_budget", cfg)
    row = report["runs"][0]
    assert row["slot_count"] > 0
    assert row["token_units"] <= cfg["max_mean_token_units"]
    payload = row["token_units"] - row["slot_count"] * SEGMENT_OVERHEAD_UNITS
    assert payload <= char_budget + SEGMENT_OVERHEAD_UNITS
