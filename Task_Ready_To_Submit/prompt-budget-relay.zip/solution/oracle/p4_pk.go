package pane

import (
	"fmt"
	"strings"
)

func PkBuild(docID string, body string, primary int, secondary int) []Segment {
	spans := LgSplit(body)
	out := make([]Segment, 0)
	idx := 0
	for _, span := range spans {
		blocks := BlkScan(span.Text)
		if len(blocks) == 0 {
			for _, part := range WinMk(span.Text, primary, secondary) {
				out = append(out, Segment{
					ID:   fmt.Sprintf("%s#%d", docID, idx),
					Text: part,
					Kind: "window",
				})
				idx++
			}
			continue
		}
		for _, blk := range blocks {
			if blk.Kind == "fence" || blk.Kind == "table" {
				out = append(out, Segment{
					ID:   fmt.Sprintf("%s#%d", docID, idx),
					Text: blk.Text,
					Kind: blk.Kind,
				})
				idx++
				continue
			}
			for _, part := range WinMk(blk.Text, primary, secondary) {
				out = append(out, Segment{
					ID:   fmt.Sprintf("%s#%d", docID, idx),
					Text: part,
					Kind: blk.Kind,
				})
				idx++
			}
		}
	}
	return dedupeSegments(out)
}

func dedupeSegments(in []Segment) []Segment {
	seen := make(map[string]struct{})
	out := make([]Segment, 0, len(in))
	for _, ch := range in {
		key := strings.Join(strings.Fields(strings.ToLower(ch.Text)), " ")
		if _, ok := seen[key]; ok {
			continue
		}
		seen[key] = struct{}{}
		out = append(out, ch)
	}
	return out
}

func PkOverlapRatio(chunks []Segment) float64 {
	if len(chunks) < 2 {
		return 0
	}
	dupes := 0
	seen := make(map[string]int)
	for _, ch := range chunks {
		key := strings.Join(strings.Fields(strings.ToLower(ch.Text)), " ")
		seen[key]++
		if seen[key] > 1 {
			dupes++
		}
	}
	return float64(dupes) / float64(len(chunks))
}
