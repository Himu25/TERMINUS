#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

log "preflight: prompt budget relay workspace"
test -f /app/go.mod
test -f /app/config/budget.toml
test -f /app/data/corpus_default.json
test -f /app/data/run_specs.jsonl
mkdir -p /app/bin /app/lib /app/output

log "survey: guardrails and subsystem layout"
grep -nE 'success|slot|dup|anchor|token_units' \
  /app/config/budget.toml /app/metrics/guardrails.txt /app/policies/retention.txt 2>/dev/null | head -n 24 || true
wc -l /app/pane/*.go /app/lane/*.go /app/x9fold/src/lib.rs /app/bench/drive.go /app/ref/*.go

log "restore language-aware document spans"
cp "${ROOT_DIR}/oracle/p1_lg.go" /app/pane/p1_lg.go

log "restore block extraction for tables and fenced code"
cp "${ROOT_DIR}/oracle/p2_scan.go" /app/pane/p2_scan.go

log "restore non-overlapping stride windows without tail duplication"
cp "${ROOT_DIR}/oracle/p3_win.go" /app/pane/p3_win.go

log "restore pipeline assembly with atomic structure blocks"
cp "${ROOT_DIR}/oracle/p4_pk.go" /app/pane/p4_pk.go

log "restore simhash fingerprint core and near-duplicate rejection"
cp "${ROOT_DIR}/oracle/x9fold.rs" /app/x9fold/src/lib.rs
cp "${ROOT_DIR}/oracle/g5_lane.go" /app/lane/g5_lane.go

log "restore anchor span scoring against structure blocks"
cp "${ROOT_DIR}/oracle/g6_units.go" /app/lane/g6_units.go

log "rebuild Rust x9fold shared library and Go bench driver"
bash /app/scripts/build_all.sh

log "run default prompt budget bench report"
chmod +x /app/scripts/run_bench.sh
/app/scripts/run_bench.sh /app/data/runs_default.jsonl /app/output/budget_bench.json

log "post-run validation against budget.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg = {}
for line in Path("/app/config/budget.toml").read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = (p.strip() for p in line.split("=", 1))
    if k.endswith("_floor") or k.startswith("max_mean_"):
        cfg[k] = float(v)
    elif k.startswith("max_"):
        cfg[k] = int(float(v))
    else:
        cfg[k] = v

report = json.loads(Path("/app/output/budget_bench.json").read_text())
assert report["status"] == "ok", report.get("status")
assert report["mean_success_rate"] >= cfg["success_floor"]
assert report["mean_slot_count"] <= cfg["max_mean_slot_count"]
assert report["mean_dup_ratio"] <= cfg["max_mean_dup_ratio"]
assert report["mean_token_units"] <= cfg["max_mean_token_units"]
assert report["anchor_span_rate"] >= cfg["anchor_span_floor"]
manifest = json.loads(Path("/app/registry/budget_manifest.json").read_text())
assert report["budget_profile"] == manifest["budget_profile"]
print("budget bench ok", report["mean_success_rate"], report["mean_slot_count"])
PY

log "done"
