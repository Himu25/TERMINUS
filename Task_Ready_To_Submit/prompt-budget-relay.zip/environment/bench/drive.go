package bench

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"

	"budgetlab.dev/promptrelay/corpus"
	"budgetlab.dev/promptrelay/lane"
	"budgetlab.dev/promptrelay/ingest"
	"budgetlab.dev/promptrelay/pkg/types"
	"budgetlab.dev/promptrelay/ref"
	"budgetlab.dev/promptrelay/pane"
)

func Run(cfg types.BudgetCfg, cases []types.RunCase) (types.BudgetReport, error) {
	if override := os.Getenv("TB_CORPUS_PATH"); override != "" {
		cfg.CorpusPath = override
	}
	docs, err := corpus.Load(cfg.CorpusPath)
	if err != nil {
		return types.BudgetReport{}, err
	}
	byID := corpus.ByID(docs)
	report := types.BudgetReport{
		Status:       "ok",
		CorpusDocs:   len(docs),
		BudgetProfile: cfg.BudgetProfile,
		RunsTotal:    len(cases),
	}
	var sumRecall, sumEmb, sumRed, sumUnits float64
	totalBlocks, intactBlocks := 0, 0
	report.Runs = make([]types.RunRow, 0, len(cases))

	for _, rc := range cases {
		var allSegments []pane.Segment
		var allBlocks []pane.Block
		goldDigests := make([]string, 0)
		for _, docID := range rc.DocIDs {
			doc, ok := byID[docID]
			if !ok {
				continue
			}
			raw := pane.PkBuild(doc.ID, doc.Text, cfg.PrimaryWindow, cfg.SecondaryStride)
			allSegments = append(allSegments, raw...)
			for _, span := range pane.LgSplit(doc.Text) {
				allBlocks = append(allBlocks, pane.BlkScan(span.Text)...)
			}
			goldDigests = append(goldDigests, ref.GoldSegments(doc.ID, doc.Text, cfg.PrimaryWindow, cfg.SecondaryStride)...)
		}
		sparse := lane.SpFilter(allSegments)
		produced := make([]string, 0, len(sparse))
		chunkIDs := make([]string, 0, len(sparse))
		for _, ch := range sparse {
			dg := ref.DgFold(ch.Text)
			produced = append(produced, dg)
			chunkIDs = append(chunkIDs, ch.ID)
		}
		sort.Strings(chunkIDs)
		recall := ref.SuccessRate(goldDigests, produced, len(produced))
		red := pane.PkOverlapRatio(allSegments)
		units := lane.RegUnits(sparse)
		intact := lane.RegIntact(sparse, allBlocks)
		totalBlocks += len(allBlocks)
		intactBlocks += intact
		row := types.RunRow{
			RunID:           rc.RunID,
			SuccessRate:       round4(recall),
			SlotCount:  len(sparse),
			DupRatio: round4(red),
			TokenUnits:      units,
			AnchorSpans:    intact,
			QueryHits:       len(produced),
			SegmentIDs:        chunkIDs,
		}
		report.Runs = append(report.Runs, row)
		sumRecall += row.SuccessRate
		sumEmb += float64(row.SlotCount)
		sumRed += row.DupRatio
		sumUnits += float64(row.TokenUnits)
	}
	n := float64(len(cases))
	if n > 0 {
		report.MeanSuccessRate = round4(sumRecall / n)
		report.MeanSlotCount = round4(sumEmb / n)
		report.MeanDupRatio = round4(sumRed / n)
		report.MeanTokenUnits = round4(sumUnits / n)
	}
	switch {
	case totalBlocks == 0:
		report.AnchorSpanRate = 1
	default:
		report.AnchorSpanRate = round4(float64(intactBlocks) / float64(totalBlocks))
	}
	sort.Slice(report.Runs, func(i, j int) bool {
		return report.Runs[i].RunID < report.Runs[j].RunID
	})
	if report.MeanSuccessRate < cfg.RecallFloor ||
		report.MeanSlotCount > float64(cfg.MaxMeanSlotCount) ||
		report.MeanDupRatio > cfg.MaxMeanDupRatio ||
		report.MeanTokenUnits > float64(cfg.MaxMeanTokenUnits) ||
		report.AnchorSpanRate < cfg.IntactBlockFloor {
		report.Status = "fail"
	}
	report.ReportDigest = digestReport(report)
	return report, nil
}

func digestReport(report types.BudgetReport) string {
	body := report
	body.ReportDigest = ""
	raw, _ := json.Marshal(body)
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func WriteReport(path string, report types.BudgetReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

func LoadCfgAndRuns(cfgPath, runsPath string) (types.BudgetCfg, []types.RunCase, error) {
	cfg, err := ingest.LoadCfg(cfgPath)
	if err != nil {
		return cfg, nil, err
	}
	cases, err := ingest.LoadRuns(runsPath)
	if err != nil {
		return cfg, nil, err
	}
	return cfg, cases, nil
}

func SortRuns(runs []types.RunRow) {
	sort.Slice(runs, func(i, j int) bool {
		return runs[i].RunID < runs[j].RunID
	})
}

func FormatRun(id string) string {
	return fmt.Sprintf("run-%s", id)
}
