package types

type BudgetCfg struct {
	CorpusPath              string
	WorkerCount             int
	BudgetProfile            string
	PrimaryWindow           int
	SecondaryStride         int
	RecallFloor             float64
	MaxMeanSlotCount   int
	MaxMeanDupRatio  float64
	MaxMeanTokenUnits       int
	IntactBlockFloor        float64
	StructuredRecallFloor   float64
	MultilingualRecallFloor float64
}

type Doc struct {
	ID   string `json:"id"`
	Text string `json:"text"`
	Lang string `json:"lang"`
}

type RunCase struct {
	RunID  string   `json:"run_id"`
	DocIDs []string `json:"doc_ids"`
}

type RunRow struct {
	RunID            string   `json:"run_id"`
	SuccessRate        float64  `json:"success_rate"`
	SlotCount   int      `json:"slot_count"`
	DupRatio  float64  `json:"dup_ratio"`
	TokenUnits       int      `json:"token_units"`
	AnchorSpans     int      `json:"anchor_spans"`
	QueryHits        int      `json:"query_hits"`
	SegmentIDs         []string `json:"segment_ids"`
}

type BudgetReport struct {
	Status               string   `json:"status"`
	CorpusDocs           int      `json:"corpus_docs"`
	BudgetProfile         string   `json:"budget_profile"`
	RunsTotal            int      `json:"runs_total"`
	MeanSuccessRate        float64  `json:"mean_success_rate"`
	MeanSlotCount   float64  `json:"mean_slot_count"`
	MeanDupRatio  float64  `json:"mean_dup_ratio"`
	MeanTokenUnits       float64  `json:"mean_token_units"`
	AnchorSpanRate      float64  `json:"anchor_span_rate"`
	ReportDigest         string   `json:"report_digest"`
	Runs                 []RunRow `json:"runs"`
}
