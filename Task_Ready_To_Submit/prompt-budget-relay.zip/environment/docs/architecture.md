# Architecture notes

Corpus JSON lives at `/app/data/corpus_default.json`. Run packs are JSONL with run_id and doc_ids. The Go driver `/app/bin/budgetbench` loads `/app/config/budget.toml`, segments documents through `/app/pane`, deduplicates via `/app/lane` and the Rust helper at `/app/x9fold/src/lib.rs`, tallies units with `/app/lane`, and writes `/app/output/budget_bench.json`. Rebuild with `/app/scripts/build_all.sh` and run `/app/scripts/run_bench.sh`.

Top-level report keys: status, corpus_docs, budget_profile, runs_total, mean_success_rate, mean_slot_count, mean_dup_ratio, mean_token_units, anchor_span_rate, report_digest, runs.

Each runs row: run_id, success_rate, slot_count, dup_ratio, token_units, anchor_spans, query_hits, segment_ids. query_hits counts the total emitted segments after dedup and equals slot_count on a correct run. success_rate is the fraction of canonical reference segment digests recovered in the packed prompt set. Reference digests are keyed by document id in `/app/ref/anchors/digest_table.json`. Unit fields are synthetic cost tallies, not wall-clock timings.

Digest covers every report field except report_digest, serialized as compact JSON with report_digest set to an empty string. budgetbench computes the digest from that payload before writing the indented report file.

dup_ratio measures duplicate normalized segment bodies before x9fold dedup. anchor_spans counts structure blocks (fenced code or markdown tables) whose full text appears in a single emitted segment. token_units sums utf8 rune counts across emitted segments plus four overhead units per segment after dedup. Quality gates compare means against floors and ceilings in budget.toml.

Regenerate the default run pack with `/app/bin/refgen` after corpus edits.

Verifier-side rebuilds prepend `/usr/local/go/bin:/app/bin:` to `PATH` and `/app/lib:` to `LD_LIBRARY_PATH` when invoking `/app/scripts/build_all.sh` and `/app/bin/budgetbench`.
