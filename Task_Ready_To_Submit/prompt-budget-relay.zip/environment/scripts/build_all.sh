#!/bin/bash
set -euo pipefail

ROOT="/app"
mkdir -p "${ROOT}/bin" "${ROOT}/lib" "${ROOT}/output" "${ROOT}/output/cargo-target"

export CARGO_TARGET_DIR="${ROOT}/output/cargo-target"
export CARGO_HOME="${CARGO_HOME:-/usr/local/cargo}"
export CGO_LDFLAGS="-L${ROOT}/lib -Wl,-rpath,${ROOT}/lib"
export LD_LIBRARY_PATH="${ROOT}/lib:${LD_LIBRARY_PATH:-}"

cd "${ROOT}/x9fold"
cargo build --release --locked 2>/dev/null || cargo build --release
install -m 0644 "${CARGO_TARGET_DIR}/release/libx9fold.so" "${ROOT}/lib/libx9fold.so"

cd "${ROOT}"
go mod tidy
go build -o "${ROOT}/bin/budgetbench" ./cmd/budgetbench
go build -o "${ROOT}/bin/refgen" ./cmd/refgen

"${ROOT}/bin/refgen" \
  "${ROOT}/data/corpus_default.json" \
  "${ROOT}/data/run_specs.jsonl" \
  "${ROOT}/data/runs_default.jsonl"
