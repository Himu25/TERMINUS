#!/bin/bash
set -euo pipefail

RUNS="${1:-/app/data/runs_default.jsonl}"
OUT="${2:-/app/output/budget_bench.json}"

mkdir -p /app/output
export LD_LIBRARY_PATH="/app/lib:${LD_LIBRARY_PATH:-}"
/app/bin/budgetbench "${RUNS}" "${OUT}"
