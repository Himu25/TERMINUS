module budgetlab.dev/promptrelay

go 1.22
