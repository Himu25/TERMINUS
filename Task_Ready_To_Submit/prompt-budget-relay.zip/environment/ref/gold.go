package ref

import (
	"crypto/sha256"
	"encoding/hex"
	"strings"
)

func DgFold(text string) string {
	norm := strings.ToLower(strings.Join(strings.Fields(text), " "))
	sum := sha256.Sum256([]byte(norm))
	return hex.EncodeToString(sum[:])
}

func GoldSegments(docID string, body string, primary int, secondary int) []string {
	return CanonSegments(docID, body, primary, secondary)
}

func SuccessRate(gold []string, produced []string, k int) float64 {
	if len(gold) == 0 {
		return 1
	}
	if k <= 0 {
		k = len(produced)
	}
	if k > len(produced) {
		k = len(produced)
	}
	hits := 0
	seen := make(map[string]struct{}, k)
	for i := 0; i < k && i < len(produced); i++ {
		seen[produced[i]] = struct{}{}
	}
	for _, g := range gold {
		if _, ok := seen[g]; ok {
			hits++
		}
	}
	return float64(hits) / float64(len(gold))
}
