package main

import (
	"encoding/json"
	"fmt"
	"os"

	"budgetlab.dev/promptrelay/corpus"
)

func main() {
	if len(os.Args) != 4 {
		fmt.Fprintf(os.Stderr, "usage: refgen <corpus.json> <run_specs.jsonl> <runs.jsonl>\n")
		os.Exit(2)
	}
	specRaw, err := os.ReadFile(os.Args[2])
	if err != nil {
		fmt.Fprintf(os.Stderr, "read specs: %v\n", err)
		os.Exit(1)
	}
	docs, err := corpus.Load(os.Args[1])
	if err != nil {
		fmt.Fprintf(os.Stderr, "corpus: %v\n", err)
		os.Exit(1)
	}
	_ = docs
	out, err := os.Create(os.Args[3])
	if err != nil {
		fmt.Fprintf(os.Stderr, "create: %v\n", err)
		os.Exit(1)
	}
	defer out.Close()
	for _, line := range splitLines(string(specRaw)) {
		var obj map[string]any
		if err := json.Unmarshal([]byte(line), &obj); err != nil {
			fmt.Fprintf(os.Stderr, "parse: %v\n", err)
			os.Exit(1)
		}
		b, _ := json.Marshal(obj)
		if _, err := out.Write(append(b, '\n')); err != nil {
			os.Exit(1)
		}
	}
}

func splitLines(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			line := trim(s[start:i])
			if line != "" {
				out = append(out, line)
			}
			start = i + 1
		}
	}
	if tail := trim(s[start:]); tail != "" {
		out = append(out, tail)
	}
	return out
}

func trim(s string) string {
	for len(s) > 0 && (s[0] == ' ' || s[0] == '\t' || s[0] == '\r') {
		s = s[1:]
	}
	for len(s) > 0 && (s[len(s)-1] == ' ' || s[len(s)-1] == '\t' || s[len(s)-1] == '\r') {
		s = s[:len(s)-1]
	}
	return s
}
