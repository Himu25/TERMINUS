package lane

import "budgetlab.dev/promptrelay/pane"

func BloomSketch(segments []pane.Segment) []pane.Segment {
	seen := make(map[string]struct{}, len(segments))
	out := make([]pane.Segment, 0, len(segments))
	for _, ch := range segments {
		key := ch.Text
		if _, ok := seen[key]; ok {
			continue
		}
		seen[key] = struct{}{}
		out = append(out, ch)
	}
	return out
}
