#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

patch_op_p() {
cat > /app/internal/lane_p3/op_p.go <<'EOF'
package lane_p3

import "lab.local/shard_glass_cut/internal/cutwire"

func strictlyBefore(seq int64, tagSeq int64) bool {
	if tagSeq <= 0 {
		return false
	}
	return seq < tagSeq
}

// OpP selects channel payloads recorded when a control tag arrives.
func OpP(msgs []cutwire.Msg, tagSeq int64) []cutwire.Msg {
	out := make([]cutwire.Msg, 0, len(msgs))
	for _, m := range msgs {
		if strictlyBefore(m.Seq, tagSeq) {
			out = append(out, m)
		}
	}
	return out
}
EOF
}

patch_op_t() {
cat > /app/pkg/tagfuse/op_t.go <<'EOF'
package tagfuse

func gatesSatisfied(outTagsDone bool, allInTagged bool) bool {
	if !outTagsDone {
		return false
	}
	if !allInTagged {
		return false
	}
	return true
}

// OpT gates whether a unit may freeze its local map.
func OpT(outTagsDone bool, allInTagged bool) bool {
	return gatesSatisfied(outTagsDone, allInTagged)
}
EOF
}

patch_op_k() {
cat > /app/internal/shut_k7/op_k.go <<'EOF'
package shut_k7

func quorumMet(totalUnits int, recorded int) bool {
	if totalUnits <= 0 {
		return false
	}
	return recorded >= totalUnits
}

// OpK decides whether the global cut may finalize.
func OpK(totalUnits int, recorded int, latePending bool) bool {
	if latePending {
		return false
	}
	return quorumMet(totalUnits, recorded)
}
EOF
}

patch_memgate() {
cat > /app/memgate/src/lib.rs <<'EOF'
use std::os::raw::c_int;

fn clamp_orphan(total: c_int, orphan: c_int) -> c_int {
	if orphan < 0 {
		return 0;
	}
	if orphan > total {
		return total;
	}
	orphan
}

/// mg_prune_count returns the reachable entry count after orphan removal.
#[no_mangle]
pub extern "C" fn mg_prune_count(total: c_int, orphan: c_int) -> c_int {
	if total <= 0 {
		return 0;
	}
	let drop = clamp_orphan(total, orphan);
	total - drop
}
EOF
}

patch_op_p
patch_op_t
patch_op_k
patch_memgate

bash /app/scripts/build.sh

rm -f /app/output/snap_report.json
mkdir -p /app/output
TB_SNAP_FIXTURE=1 /app/bin/snap_cut
test -s /app/output/snap_report.json

GOFLAGS=-mod=mod go test ./...
