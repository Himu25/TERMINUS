Eight-partition online backup cut lab. Driver binary lives at cmd/snap_cut.
Regression stems under data/regression each carry spec.json and trace.jsonl.
