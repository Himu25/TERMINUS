// Report JSON for /app/output/snap_report.json:
//
// schema_version — integer, must be 2
// cut_id — string, echoes active pack name
// shard_count — integer, unit count from active pack
// scenarios — array of stem rows
// Each row: name, finish_reason, keys_captured, duplicate_keys,
// unreachable_keys, in_flight_captured, cut_closed, late_wave_absorbed, digest_hex
//
// Root object contains only these keys plus scenarios array fields above.
package main

import (
	"log"
	"os"
	"path/filepath"

	"lab.local/shard_glass_cut/internal/config"
	"lab.local/shard_glass_cut/internal/driver"
)

func main() {
	if os.Getenv("TB_SNAP_FIXTURE") != "1" {
		log.Fatal("TB_SNAP_FIXTURE unset or not 1")
	}
	appRoot := "/app"
	indexPath := filepath.Join(appRoot, "docs", "scenario_index.txt")
	stems, err := config.ListStems(indexPath)
	if err != nil {
		log.Fatal(err)
	}
	// Always include quiet stem plus index stems.
	names := []string{"stem_quiet"}
	seen := map[string]bool{"stem_quiet": true}
	for _, s := range stems {
		if !seen[s] {
			names = append(names, s)
			seen[s] = true
		}
	}
	rep, err := driver.RunBundle(appRoot, names)
	if err != nil {
		log.Fatal(err)
	}
	outPath := filepath.Join(appRoot, "output", "snap_report.json")
	if err := driver.EmitReport(outPath, rep); err != nil {
		log.Fatal(err)
	}
}
