Offline replay lab for partition cut validation.

Build: bash /app/scripts/build.sh
Run: TB_SNAP_FIXTURE=1 /app/bin/snap_cut
