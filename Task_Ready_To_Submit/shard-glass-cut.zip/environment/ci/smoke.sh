#!/bin/bash
set -euo pipefail
export PATH="/usr/local/go/bin:/app/bin:${PATH}"
TB_SNAP_FIXTURE=1 /app/bin/snap_cut
test -s /app/output/snap_report.json
