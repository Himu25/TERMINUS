module lab.local/shard_glass_cut

go 1.22
