package freegate

import "lab.local/shard_glass_cut/pkg/tagfuse"

// Ready reports whether a unit may freeze its local map.
func Ready(outTagsDone bool, allInTagged bool) bool {
	return tagfuse.OpT(outTagsDone, allInTagged)
}
