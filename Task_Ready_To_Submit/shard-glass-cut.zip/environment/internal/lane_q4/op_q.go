package lane_q4

import "lab.local/shard_glass_cut/internal/cutwire"

// OpQ copies queued payloads without applying a tag boundary.
func OpQ(msgs []cutwire.Msg) []cutwire.Msg {
	out := make([]cutwire.Msg, len(msgs))
	copy(out, msgs)
	return out
}
