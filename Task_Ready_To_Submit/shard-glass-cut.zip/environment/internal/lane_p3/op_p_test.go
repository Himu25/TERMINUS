package lane_p3_test

import (
	"testing"

	"lab.local/shard_glass_cut/internal/cutwire"
	"lab.local/shard_glass_cut/internal/lane_p3"
)

func TestOpPBounds(t *testing.T) {
	msgs := []cutwire.Msg{
		{Seq: 1, Key: "a", Value: "1"},
		{Seq: 2, Key: "b", Value: "2"},
	}
	got := lane_p3.OpP(msgs, 2)
	if len(got) != 1 {
		t.Fatalf("expected 1 msg strictly before tag seq, got %d", len(got))
	}
}
