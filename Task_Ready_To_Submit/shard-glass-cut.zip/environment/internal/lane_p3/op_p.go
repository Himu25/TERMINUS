package lane_p3

import "lab.local/shard_glass_cut/internal/cutwire"

// OpP selects channel payloads recorded when a control tag arrives.
func OpP(msgs []cutwire.Msg, tagSeq int64) []cutwire.Msg {
	out := make([]cutwire.Msg, 0, len(msgs))
	for _, m := range msgs {
		if m.Seq <= tagSeq {
			out = append(out, m)
		}
	}
	return out
}
