package config

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"lab.local/shard_glass_cut/internal/cutwire"
)

// Pack is the active bundle descriptor.
type Pack struct {
	CutID     string `json:"cut_id"`
	UnitCount int    `json:"unit_count"`
}

// LoadPack reads the active snap pack JSON.
func LoadPack(path string) (Pack, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return Pack{}, err
	}
	var p Pack
	if err := json.Unmarshal(raw, &p); err != nil {
		return Pack{}, err
	}
	return p, nil
}

// LoadStem reads spec and trace for one regression stem.
func LoadStem(root, stem string) (cutwire.Spec, []cutwire.Event, error) {
	dir := filepath.Join(root, "data", "regression", stem)
	specPath := filepath.Join(dir, "spec.json")
	tracePath := filepath.Join(dir, "trace.jsonl")

	specRaw, err := os.ReadFile(specPath)
	if err != nil {
		return cutwire.Spec{}, nil, err
	}
	var spec cutwire.Spec
	if err := json.Unmarshal(specRaw, &spec); err != nil {
		return cutwire.Spec{}, nil, err
	}

	f, err := os.Open(tracePath)
	if err != nil {
		return cutwire.Spec{}, nil, err
	}
	defer f.Close()

	var events []cutwire.Event
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := sc.Text()
		if line == "" || line[0] == '#' {
			continue
		}
		var ev cutwire.Event
		if err := json.Unmarshal([]byte(line), &ev); err != nil {
			return cutwire.Spec{}, nil, fmt.Errorf("trace parse: %w", err)
		}
		events = append(events, ev)
	}
	if err := sc.Err(); err != nil {
		return cutwire.Spec{}, nil, err
	}
	return spec, events, nil
}

// ListStems returns stem names from the scenario index file.
func ListStems(indexPath string) ([]string, error) {
	raw, err := os.ReadFile(indexPath)
	if err != nil {
		return nil, err
	}
	var stems []string
	for _, line := range splitLines(string(raw)) {
		if line == "" || line[0] == '#' {
			continue
		}
		stems = append(stems, line)
	}
	return stems, nil
}

func splitLines(s string) []string {
	out := make([]string, 0)
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			out = append(out, trim(s[start:i]))
			start = i + 1
		}
	}
	if start <= len(s) {
		out = append(out, trim(s[start:]))
	}
	return out
}

func trim(s string) string {
	for len(s) > 0 && (s[0] == ' ' || s[0] == '\t') {
		s = s[1:]
	}
	for len(s) > 0 && (s[len(s)-1] == ' ' || s[len(s)-1] == '\t' || s[len(s)-1] == '\r') {
		s = s[:len(s)-1]
	}
	return s
}
