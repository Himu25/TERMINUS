package chanlog

import (
	"lab.local/shard_glass_cut/internal/cutwire"
	"lab.local/shard_glass_cut/internal/lane_p3"
)

// Apply records inbound channel payloads at a control tag boundary.
func Apply(msgs []cutwire.Msg, tagSeq int64) []cutwire.Msg {
	return lane_p3.OpP(msgs, tagSeq)
}
