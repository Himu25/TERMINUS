package fingate

import "lab.local/shard_glass_cut/internal/shut_k7"

// Sealed reports whether the global cut may finalize.
func Sealed(totalUnits int, recorded int, latePending bool) bool {
	return shut_k7.OpK(totalUnits, recorded, latePending)
}
