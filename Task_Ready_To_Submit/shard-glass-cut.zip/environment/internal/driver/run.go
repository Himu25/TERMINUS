package driver

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"lab.local/shard_glass_cut/internal/config"
	"lab.local/shard_glass_cut/internal/engine"
	"lab.local/shard_glass_cut/internal/fingate"
	"lab.local/shard_glass_cut/pkg/frame"
)

const (
	schemaVersion  = 2
	finishClosed   = "closed"
	finishOpen     = "open"
)

// ScenarioRow is one stem outcome in the report.
type ScenarioRow struct {
	Name             string `json:"name"`
	FinishReason     string `json:"finish_reason"`
	KeysCaptured     int    `json:"keys_captured"`
	DuplicateKeys    int    `json:"duplicate_keys"`
	UnreachableKeys  int    `json:"unreachable_keys"`
	InFlightCaptured int    `json:"in_flight_captured"`
	CutClosed        int    `json:"cut_closed"`
	LateWaveAbsorbed int    `json:"late_wave_absorbed"`
	DigestHex        string `json:"digest_hex"`
}

// Report is written to /app/output/snap_report.json.
type Report struct {
	SchemaVersion int           `json:"schema_version"`
	CutID         string        `json:"cut_id"`
	ShardCount    int           `json:"shard_count"`
	Scenarios     []ScenarioRow `json:"scenarios"`
}

// RunBundle executes all requested stems and returns a report.
func RunBundle(appRoot string, stemNames []string) (Report, error) {
	packPath := filepath.Join(appRoot, "data", "active", "snap_pack.json")
	pack, err := config.LoadPack(packPath)
	if err != nil {
		return Report{}, err
	}

	rows := make([]ScenarioRow, 0, len(stemNames))
	for _, name := range stemNames {
		spec, events, err := config.LoadStem(appRoot, name)
		if err != nil {
			return Report{}, fmt.Errorf("stem %s: %w", name, err)
		}
		raw := engine.ReplayStem(spec, events)
		closed := 0
		finish := finishOpen
		if fingate.Sealed(raw.TotalUnits, raw.Recorded, raw.LatePending) {
			closed = 1
			finish = finishClosed
		}
		row := ScenarioRow{
			Name:             name,
			FinishReason:     finish,
			KeysCaptured:     raw.KeysCaptured,
			DuplicateKeys:    raw.DuplicateKeys,
			UnreachableKeys:  raw.UnreachableKeys,
			InFlightCaptured: raw.InFlightCaptured,
			CutClosed:        closed,
			LateWaveAbsorbed: raw.LateWaveAbsorbed,
		}
		row.DigestHex = frame.RowDigest(
			row.Name, row.FinishReason,
			row.KeysCaptured, row.DuplicateKeys, row.UnreachableKeys,
			row.InFlightCaptured, row.CutClosed, row.LateWaveAbsorbed,
		)
		rows = append(rows, row)
	}

	return Report{
		SchemaVersion: schemaVersion,
		CutID:         pack.CutID,
		ShardCount:    pack.UnitCount,
		Scenarios:     rows,
	}, nil
}

// EmitReport writes the JSON report file.
func EmitReport(path string, rep Report) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}
