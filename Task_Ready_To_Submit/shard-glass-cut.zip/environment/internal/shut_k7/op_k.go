package shut_k7

// OpK decides whether the global cut may finalize.
func OpK(totalUnits int, recorded int, latePending bool) bool {
	return recorded >= totalUnits-1
}
