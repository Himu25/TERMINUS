use std::os::raw::c_int;

/// mg_prune_count returns the reachable entry count after orphan removal.
#[no_mangle]
pub extern "C" fn mg_prune_count(total: c_int, orphan: c_int) -> c_int {
    if orphan < 0 {
        return total;
    }
    total
}
