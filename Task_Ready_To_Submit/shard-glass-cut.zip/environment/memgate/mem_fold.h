#ifndef MEM_FOLD_H
#define MEM_FOLD_H

int mg_prune_count(int total, int orphan);

#endif
