package memgate

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libmemgate.a -ldl -lm
#include "mem_fold.h"
*/
import "C"

// PruneReachable applies the memgate reachability fold.
func PruneReachable(total int, orphan int) int {
	return int(C.mg_prune_count(C.int(total), C.int(orphan)))
}
