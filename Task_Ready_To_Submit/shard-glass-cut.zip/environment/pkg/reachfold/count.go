package reachfold

import "lab.local/shard_glass_cut/memgate"

// Count returns the reachable entry total after orphan removal.
func Count(total int, orphan int) int {
	return memgate.PruneReachable(total, orphan)
}
