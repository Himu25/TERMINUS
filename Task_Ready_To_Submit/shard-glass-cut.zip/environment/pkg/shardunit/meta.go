package shardunit

// Meta holds static unit layout info.
type Meta struct {
	ID   int
	Role string
}

// All returns the default eight-unit layout.
func All() []Meta {
	out := make([]Meta, 8)
	for i := range out {
		out[i] = Meta{ID: i, Role: "data"}
	}
	return out
}
