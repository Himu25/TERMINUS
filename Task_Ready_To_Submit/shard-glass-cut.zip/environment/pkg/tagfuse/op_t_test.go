package tagfuse_test

import "testing"

import "lab.local/shard_glass_cut/pkg/tagfuse"

func TestOpTRequiresBoth(t *testing.T) {
	if tagfuse.OpT(false, false) {
		t.Fatal("expected false when neither gate is set")
	}
}
