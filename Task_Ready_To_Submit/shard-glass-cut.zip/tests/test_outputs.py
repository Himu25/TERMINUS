"""Verifier for shard glass cut lab reports."""

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "snap_report.json"
BIN = "/app/bin/snap_cut"
ACTIVE_PACK = APP / "data" / "active" / "snap_pack.json"
STEM_INDEX = APP / "docs" / "scenario_index.txt"

SCHEMA_VERSION = 2
FINISH_CLOSED = "closed"
FINISH_OPEN = "open"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    """Build snap_cut once for the verifier session."""
    env = {**os.environ}
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _row_digest(row: dict) -> str:
    proc = subprocess.run(
        [
            "/app/bin/digest_cli",
            row["name"],
            row["finish_reason"],
            str(row["keys_captured"]),
            str(row["duplicate_keys"]),
            str(row["unreachable_keys"]),
            str(row["in_flight_captured"]),
            str(row["cut_closed"]),
            str(row["late_wave_absorbed"]),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return proc.stdout.strip()


def _run_lab(extra_env: dict | None = None) -> dict:
    env = {**os.environ, "TB_SNAP_FIXTURE": "1"}
    if extra_env:
        env.update(extra_env)
    subprocess.run([BIN], cwd="/app", env=env, check=True)
    return json.loads(OUT.read_text())


def _by_name(report: dict) -> dict[str, dict]:
    return {row["name"]: row for row in report["scenarios"]}


def _load_stems() -> list[str]:
    lines = STEM_INDEX.read_text().splitlines()
    return [line.strip() for line in lines if line.strip() and not line.startswith("#")]


def test_report_schema_and_pack() -> None:
    """Report uses schema version 2 and the active cut id."""
    report = _run_lab()
    assert report["schema_version"] == SCHEMA_VERSION
    pack = json.loads(ACTIVE_PACK.read_text())
    assert report["cut_id"] == pack["cut_id"]
    assert report["shard_count"] == pack["unit_count"]
    assert len(report["scenarios"]) >= 7


def test_quiet_baseline_clean() -> None:
    """Quiet stem closes cleanly with no duplicate or unreachable keys."""
    row = _by_name(_run_lab())["stem_quiet"]
    assert row["finish_reason"] == FINISH_CLOSED
    assert row["duplicate_keys"] == 0
    assert row["unreachable_keys"] == 0
    assert row["cut_closed"] == 1


def test_crash_emit_closes() -> None:
    """Crash-emit stem closes without duplicate keys."""
    row = _by_name(_run_lab())["stem_crash_emit"]
    assert row["finish_reason"] == FINISH_CLOSED
    assert row["cut_closed"] == 1
    assert row["duplicate_keys"] == 0


def test_stem_crash_emit() -> None:
    """Regression crash-emit stem stays closed with zero duplicates."""
    row = _by_name(_run_lab())["stem_crash_emit"]
    assert row["duplicate_keys"] == 0
    assert row["cut_closed"] == 1


def test_late_wave_holds_open() -> None:
    """Late-wave stem keeps the cut open while a control wave is pending."""
    row = _by_name(_run_lab())["stem_late_wave"]
    assert row["finish_reason"] == FINISH_OPEN
    assert row["cut_closed"] == 0
    assert row["late_wave_absorbed"] == 0


def test_stem_late_wave() -> None:
    """Regression late-wave stem does not close before the wave is applied."""
    row = _by_name(_run_lab())["stem_late_wave"]
    assert row["cut_closed"] == 0


def test_late_deliver_absorbs() -> None:
    """Late-deliver stem records the absorbed pending wave."""
    row = _by_name(_run_lab())["stem_late_deliver"]
    assert row["finish_reason"] == FINISH_CLOSED
    assert row["late_wave_absorbed"] == 1
    assert row["cut_closed"] == 1


def test_mv_race_no_duplicates() -> None:
    """Mv-race stem keeps duplicate_keys at zero when a key moves mid-cut."""
    row = _by_name(_run_lab())["stem_mv_race"]
    assert row["finish_reason"] == FINISH_CLOSED
    assert row["duplicate_keys"] == 0


def test_stem_mv_race() -> None:
    """Regression mv-race stem finishes closed without duplicate keys."""
    row = _by_name(_run_lab())["stem_mv_race"]
    assert row["duplicate_keys"] == 0
    assert row["finish_reason"] == FINISH_CLOSED


def test_channel_edge_inflight() -> None:
    """Channel-edge stem records zero in_flight_captured past the tag boundary."""
    row = _by_name(_run_lab())["stem_channel_edge"]
    assert row["in_flight_captured"] == 0


def test_stem_channel_edge() -> None:
    """Regression channel-edge stem excludes post-tag channel payloads."""
    row = _by_name(_run_lab())["stem_channel_edge"]
    assert row["in_flight_captured"] == 0


def test_orphan_trim_zero() -> None:
    """Orphan-trim stem reports zero unreachable keys after pruning."""
    row = _by_name(_run_lab())["stem_orphan_trim"]
    assert row["finish_reason"] == FINISH_CLOSED
    assert row["unreachable_keys"] == 0
    assert row["duplicate_keys"] == 0


def test_stem_orphan_trim() -> None:
    """Regression orphan-trim stem trims ghost entries from the cut."""
    row = _by_name(_run_lab())["stem_orphan_trim"]
    assert row["unreachable_keys"] == 0
    assert row["duplicate_keys"] == 0


def test_row_digests_match_cli() -> None:
    """Each scenario digest matches the digest helper."""
    report = _run_lab()
    for row in report["scenarios"]:
        assert row["digest_hex"] == _row_digest(row)


def test_regression_stems_present() -> None:
    """Every stem listed in the scenario index appears in the report."""
    report = _run_lab()
    names = {row["name"] for row in report["scenarios"]}
    for stem in _load_stems():
        assert stem in names


def test_go_unit_tests_pass() -> None:
    """Go packages under /app pass their unit tests."""
    subprocess.run(
        ["go", "test", "./..."],
        cwd="/app",
        env={**os.environ, "GOFLAGS": "-mod=mod"},
        check=True,
    )
