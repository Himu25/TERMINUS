package skiff

import (
	"fmt"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

// K1Spin rotates signed bearer rows within grace.
func K1Spin(raw string, ttlSec int, graceSec int) (string, error) {
	parser := jwt.NewParser(jwt.WithoutClaimsValidation())
	parsed, err := parser.Parse(raw, func(t *jwt.Token) (any, error) {
		if t.Method != jwt.SigningMethodHS256 {
			return nil, fmt.Errorf("unexpected signing method")
		}
		return laneKey, nil
	})
	if err != nil {
		return "", err
	}
	claims, ok := parsed.Claims.(jwt.MapClaims)
	if !ok || !parsed.Valid {
		return "", fmt.Errorf("invalid claims")
	}
	sub, _ := claims["sub"].(string)
	expVal, ok := claims["exp"].(float64)
	if !ok {
		return "", fmt.Errorf("missing exp")
	}
	expAt := time.Unix(int64(expVal), 0)
	graceEnd := expAt.Add(time.Duration(graceSec) * time.Second)
	if time.Now().UTC().After(graceEnd) {
		return "", fmt.Errorf("credential expired")
	}
	return K0Mint(sub, ttlSec)
}
