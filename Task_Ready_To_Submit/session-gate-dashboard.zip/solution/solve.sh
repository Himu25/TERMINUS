#!/bin/bash
# Terminal-Bench Canary: session-gate-dashboard oracle
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

echo "Surveying workshop UI contract"
head -n 30 /app/workshop/overview.md

echo "Reviewing session timing notes"
grep -nE 'grace|stale|Bearer|dash_cred' /app/docs/session_notes.md || true

echo "Installing corrected skiff and dock modules"
install -m 0644 "${ROOT_DIR}/oracle/skiff/k0_bind.go" /app/skiff/k0_bind.go
install -m 0644 "${ROOT_DIR}/oracle/skiff/k1_spin.go" /app/skiff/k1_spin.go
install -m 0644 "${ROOT_DIR}/oracle/dock/m0_wrap.go" /app/dock/m0_wrap.go

echo "Patching UI credential storage and header shape"
sed -i 's/sessionStorage\.setItem/localStorage.setItem/' /app/web/client/app.js
sed -i 's/sessionStorage\.removeItem/localStorage.removeItem/' /app/web/client/app.js
sed -i 's/headers.Authorization = tok;/headers.Authorization = "Bearer " + tok;/' /app/web/client/app.js

echo "Verifying module graph compiles"
go vet ./...
go test ./...

echo "Building dash server binary"
go build -o /app/tools/dashsrv ./cmd/dashsrv

echo "Starting dash server for smoke probe"
/app/tools/dashsrv >/tmp/dashsrv.log 2>&1 &
dash_pid=$!
trap 'kill "${dash_pid}" 2>/dev/null || true' EXIT

python3 <<'SMOKE'
import json
import re
import time
import urllib.error
import urllib.request
from pathlib import Path

probe_origin = "http://127.0.0.1:8080"
bind_src = Path("/app/skiff/k0_bind.go").read_text(encoding="utf-8")
match = re.search(r'laneKey = \[\]byte\("([^"]+)"\)', bind_src)
if not match:
    raise SystemExit("lane key not discoverable")
lane_key = match.group(1).encode()

app_src = Path("/app/web/client/app.js").read_text(encoding="utf-8")
if "localStorage.setItem" not in app_src:
    raise SystemExit("ui bundle must persist rows in localStorage")
if 'headers.Authorization = "Bearer " + tok' not in app_src:
    raise SystemExit("ui bundle must prefix Authorization with Bearer")
if "sessionStorage.setItem" in app_src:
    raise SystemExit("ui bundle must not write sessionStorage for credentials")

for _ in range(40):
    try:
        urllib.request.urlopen(f"{probe_origin}/healthz", timeout=1)
        break
    except Exception:
        time.sleep(0.25)
else:
    raise SystemExit("server did not become ready")

def post_json(path: str, payload: dict, headers: dict | None = None) -> tuple[int, dict]:
    hdrs = {"Content-Type": "application/json"}
    if headers:
        hdrs.update(headers)
    req = urllib.request.Request(
        f"{probe_origin}{path}",
        data=json.dumps(payload).encode(),
        headers=hdrs,
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            body = resp.read().decode()
            return resp.status, json.loads(body) if body else {}
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode()
        try:
            parsed = json.loads(raw) if raw else {}
        except json.JSONDecodeError:
            parsed = {}
        return exc.code, parsed

def get_json(path: str, headers: dict) -> tuple[int, dict]:
    req = urllib.request.Request(f"{probe_origin}{path}", headers=headers, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            body = resp.read().decode()
            return resp.status, json.loads(body) if body else {}
    except urllib.error.HTTPError as exc:
        return exc.code, {}

status, body = post_json("/api/v1/login", {"user": "admin", "pass": "not-the-password"})
if status != 401:
    raise SystemExit("wrong passphrase must be denied")

status, body = post_json("/api/v1/login", {"user": "admin", "pass": "admin"})
if status != 200 or "token" not in body:
    raise SystemExit("lab login failed")
token = body["token"]

sum_status, view = get_json(
    "/api/v1/summary",
    {"Authorization": f"Bearer {token}", "X-Request-Tag": "dash-ui"},
)
if sum_status != 200:
    raise SystemExit("summary failed after login")

overview = Path("/app/workshop/overview.md").read_text(encoding="utf-8")
for needle in ("open count: 14", "closed count: 6", "session label: ops-west"):
    if needle not in overview:
        raise SystemExit(f"overview missing {needle}")

if view["open_count"] != 14 or view["closed_count"] != 6:
    raise SystemExit("unexpected lab counts")
if view["session_label"] != "ops-west":
    raise SystemExit("unexpected session label")

opt = urllib.request.Request(
    f"{probe_origin}/api/v1/refresh",
    method="OPTIONS",
    headers={
        "Authorization": f"Bearer {token}",
        "X-Request-Tag": "dash-ui",
        "Content-Type": "application/json",
        "Origin": "http://127.0.0.1:8080",
        "Access-Control-Request-Method": "POST",
        "Access-Control-Request-Headers": "authorization, x-request-tag",
    },
)
with urllib.request.urlopen(opt, timeout=5) as resp:
    allow = resp.headers.get("Access-Control-Allow-Headers", "")
if "authorization" not in allow.lower():
    raise SystemExit("preflight missing Authorization")

notes = Path("/app/docs/session_notes.md").read_text(encoding="utf-8")
if "well past grace" not in notes.lower():
    raise SystemExit("stale timing not documented in session notes")

dash_cfg = Path("/app/config/dash.toml").read_text(encoding="utf-8")
ttl_match = re.search(r"token_ttl_sec\s*=\s*(\d+)", dash_cfg)
grace_match = re.search(r"refresh_grace_sec\s*=\s*(\d+)", dash_cfg)
if not ttl_match or not grace_match:
    raise SystemExit("dash.toml missing token_ttl_sec or refresh_grace_sec")
stale_offset = int(ttl_match.group(1)) + int(grace_match.group(1)) + 60

def b64url(data: bytes) -> str:
    import base64

    return base64.urlsafe_b64encode(data).decode().rstrip("=")

def mint_row(subject: str, exp_unix: int) -> str:
    import base64
    import hashlib
    import hmac

    header = b64url(json.dumps({"alg": "HS256", "typ": "JWT"}, separators=(",", ":")).encode())
    payload = b64url(
        json.dumps(
            {"sub": subject, "iat": int(time.time()) - 10, "exp": exp_unix},
            separators=(",", ":"),
        ).encode()
    )
    signing_input = f"{header}.{payload}".encode()
    sig = b64url(hmac.new(lane_key, signing_input, hashlib.sha256).digest())
    return f"{header}.{payload}.{sig}"

stale = mint_row("admin", int(time.time()) - stale_offset)
stale_status, _ = get_json(
    "/api/v1/summary",
    {"Authorization": f"Bearer {stale}", "X-Request-Tag": "dash-ui"},
)
if stale_status != 401:
    raise SystemExit("stale row must be rejected")

far_past = mint_row("admin", int(time.time()) - stale_offset)
far_status, _ = get_json(
    "/api/v1/summary",
    {"Authorization": f"Bearer {far_past}", "X-Request-Tag": "dash-ui"},
)
if far_status != 401:
    raise SystemExit("far-past row must stay rejected")

probe = json.loads(Path("/app/output/session_probe.json").read_text(encoding="utf-8"))
if probe["open_count"] != 14 or probe["closed_count"] != 6:
    raise SystemExit("probe counts mismatch")
if probe["session_label"] != "ops-west":
    raise SystemExit("probe label mismatch")

SMOKE

echo "Oracle completed"
