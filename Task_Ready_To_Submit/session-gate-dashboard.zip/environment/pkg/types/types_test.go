package types

import "testing"

func TestSummaryViewFields(t *testing.T) {
	v := SummaryView{SessionLabel: "x", OpenCount: 1, ClosedCount: 2}
	if v.OpenCount+v.ClosedCount != 3 {
		t.Fatalf("unexpected counts")
	}
}
