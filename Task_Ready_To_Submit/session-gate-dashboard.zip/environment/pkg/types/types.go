package types

type DashConfig struct {
	ListenAddr   string
	OperatorUser string
	OperatorPass string
	SessionLabel string
	TokenTTL     int
	RefreshGrace int
}

type TicketRow struct {
	ID     string `json:"id"`
	State  string `json:"state"`
	Region string `json:"region"`
}

type SummaryView struct {
	SessionLabel string `json:"session_label"`
	OpenCount    int    `json:"open_count"`
	ClosedCount  int    `json:"closed_count"`
}
