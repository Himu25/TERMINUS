package pane

import (
	"encoding/json"
	"os"

	"session.lab/pkg/types"
)

// H2Load reads ticket rows from disk.
func H2Load(path string) ([]types.TicketRow, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var rows []types.TicketRow
	if err := json.Unmarshal(raw, &rows); err != nil {
		return nil, err
	}
	return rows, nil
}

// H2Summarize counts open and closed rows for a region label.
func H2Summarize(rows []types.TicketRow, region string) types.SummaryView {
	view := types.SummaryView{SessionLabel: region}
	for _, row := range rows {
		switch row.State {
		case "open":
			view.OpenCount++
		case "closed":
			view.ClosedCount++
		}
	}
	return view
}
