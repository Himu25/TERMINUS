const CRED_KEY = "dash_cred";

function persistCredential(tok) {
  sessionStorage.setItem(CRED_KEY, tok);
}

function readCredential() {
  return localStorage.getItem(CRED_KEY) || "";
}

function clearCredential() {
  sessionStorage.removeItem(CRED_KEY);
  localStorage.removeItem(CRED_KEY);
}

async function apiFetch(path, opts = {}) {
  const headers = Object.assign({}, opts.headers || {});
  const tok = readCredential();
  if (tok) {
    headers.Authorization = tok;
  }
  headers["X-Request-Tag"] = "dash-ui";
  const res = await fetch(path, Object.assign({}, opts, { headers, credentials: "include" }));
  return res;
}

function showError(msg) {
  const el = document.getElementById("login-error");
  el.textContent = msg;
  el.hidden = !msg;
}

function renderSummary(view) {
  document.getElementById("session-label").textContent = view.session_label;
  const open = document.getElementById("tile-open");
  const closed = document.getElementById("tile-closed");
  open.textContent = String(view.open_count);
  closed.textContent = String(view.closed_count);
  open.dataset.loaded = "true";
  closed.dataset.loaded = "true";
}

async function loadSummary() {
  const res = await apiFetch("/api/v1/summary");
  if (!res.ok) {
    throw new Error("summary failed");
  }
  return res.json();
}

async function doLogin() {
  const user = document.getElementById("login-user").value;
  const pass = document.getElementById("login-pass").value;
  const res = await fetch("/api/v1/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ user, pass }),
    credentials: "include",
  });
  if (!res.ok) {
    showError("login denied");
    return;
  }
  const body = await res.json();
  persistCredential(body.token);
  document.getElementById("login-panel").hidden = true;
  document.getElementById("dash-panel").hidden = false;
  showError("");
  const view = await loadSummary();
  renderSummary(view);
}

async function doRefresh() {
  const res = await apiFetch("/api/v1/refresh", { method: "POST" });
  if (!res.ok) {
    showError("refresh blocked");
    return;
  }
  const body = await res.json();
  persistCredential(body.token);
  const view = await loadSummary();
  renderSummary(view);
}

function doLogout() {
  clearCredential();
  document.getElementById("dash-panel").hidden = true;
  document.getElementById("login-panel").hidden = false;
}

document.getElementById("login-submit").addEventListener("click", () => {
  doLogin().catch(() => showError("login flow failed"));
});
document.getElementById("refresh-btn").addEventListener("click", () => {
  doRefresh().catch(() => showError("refresh flow failed"));
});
document.getElementById("logout-btn").addEventListener("click", doLogout);
