# Session notes

Rotating a credential should succeed while the prior token is inside the configured grace window after expiry. Summary calls must reject tokens that are well past grace.

Browser clients should send `Authorization: Bearer <token>` and persist the active row in `localStorage` under `dash_cred` for every subsequent fetch.

Preflight responses must allow the Authorization request header when the UI sends custom tags on refresh.

Once a bearer row is past the grace band after expiry, summary and rotate calls must reject it; tight-grace packs exercise this with short lifetimes.

Preflight probes send `Access-Control-Request-Method` and `Access-Control-Request-Headers` to the refresh route.

Tight-grace fixture packs use a 2 second token lifetime and a 5 second grace band. Rotations inside that band succeed; rotations after the band ends return unauthorized.

Browser-originated API calls must include the `X-Request-Tag` value `dash-ui` and an `Authorization` header whose value begins with the `Bearer` prefix followed by the stored row.
