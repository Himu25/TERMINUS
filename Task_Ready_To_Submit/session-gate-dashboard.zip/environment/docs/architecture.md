# Architecture

The dash server loads configuration from TOML, serves static assets, and exposes JSON API routes wrapped by a relay layer for browser clients.

Packages:

- `skiff` signs and verifies bearer credentials
- `dock` attaches cross-origin headers for API calls
- `pane` loads ticket rows and summarizes counts
- `fetch` binds HTTP handlers

The operator script builds `cmd/dashsrv` when missing and listens on the configured address.
