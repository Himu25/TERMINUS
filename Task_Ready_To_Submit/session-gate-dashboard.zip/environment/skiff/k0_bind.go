package skiff

import (
	"fmt"
	"os"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

var laneKey = []byte("session-lab-dash-hmac-key-v1")

// K0Mint creates a signed bearer credential.
func K0Mint(subject string, ttlSec int) (string, error) {
	now := time.Now().UTC()
	claims := jwt.MapClaims{
		"sub": subject,
		"iat": now.Unix(),
		"exp": now.Add(time.Duration(ttlSec) * time.Second).Unix(),
	}
	tok := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return tok.SignedString(laneKey)
}

// K0Bind parses and authenticates a bearer credential.
func K0Bind(raw string) (jwt.MapClaims, error) {
	parsed, err := jwt.Parse(raw, func(t *jwt.Token) (any, error) {
		if t.Method != jwt.SigningMethodHS256 {
			return nil, fmt.Errorf("unexpected signing method")
		}
		return laneKey, nil
	})
	if err != nil {
		return nil, err
	}
	claims, ok := parsed.Claims.(jwt.MapClaims)
	if !ok || !parsed.Valid {
		return nil, fmt.Errorf("invalid claims")
	}
	_ = claims["exp"]
	return claims, nil
}

// K0MintAt creates a credential that expires at the given unix second.
func K0MintAt(subject string, expUnix int64) (string, error) {
	claims := jwt.MapClaims{
		"sub": subject,
		"iat": time.Now().UTC().Unix(),
		"exp": expUnix,
	}
	tok := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return tok.SignedString(laneKey)
}

func init() {
	if v := os.Getenv("SESSION_LAB_JWT_SECRET"); v != "" {
		laneKey = []byte(v)
	}
}
