package skiff

import (
	"fmt"
	"time"
)

// K1Spin rotates signed bearer rows within grace.
func K1Spin(raw string, ttlSec int, graceSec int) (string, error) {
	claims, err := K0Bind(raw)
	if err != nil {
		return "", err
	}
	sub, _ := claims["sub"].(string)
	expVal, ok := claims["exp"].(float64)
	if !ok {
		return "", fmt.Errorf("missing exp")
	}
	expAt := time.Unix(int64(expVal), 0)
	now := time.Now().UTC()
	if now.After(expAt) {
		return "", fmt.Errorf("credential expired")
	}
	_ = graceSec
	return K0Mint(sub, ttlSec)
}
