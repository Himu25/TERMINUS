# Session gate workshop

The dashboard process is started with `/app/tools/run_dashsrv.sh` and serves the UI at `http://127.0.0.1:8080`.

## Tile elements

- `#tile-open` shows open ticket count when `data-loaded=true`
- `#tile-closed` shows closed ticket count when `data-loaded=true`
- `#session-label` shows the active session label string
- `#logout-btn` ends the session and returns to the login panel
- `#login-panel` / `#dash-panel` toggle visibility on sign-in and sign-out
- `#login-error` shows a visible login failure message when sign-in is denied; it stays hidden after a successful sign-in

## Bundled lab steady state

After sign-in against the default config and ticket feed:

- open count: 14
- closed count: 6
- session label: ops-west

## Browser credential storage

The UI stores the active bearer row in `localStorage` under the key `dash_cred`. Login, rotate, and summary fetches must read that same key.

## API routes

- `POST /api/v1/login` with JSON user/pass; success body includes `token` (string bearer row)
- `GET /api/v1/summary` with bearer credential; success body includes `open_count`, `closed_count`, and `session_label`
- `POST /api/v1/refresh` with bearer credential and `X-Request-Tag` header; success body includes `token`; must accept credentials still inside the configured grace band after expiry

## Browser request contract

Authenticated fetches from the UI must send `X-Request-Tag: dash-ui` and `Authorization: Bearer <row>`. Successful summary responses refresh `/app/output/session_probe.json` so its counts match the tiles.

## Tight-grace fixture

`scenario_tight_grace` uses token_ttl_sec 2 and refresh_grace_sec 5. Rotations inside the grace band succeed; rotations after the band ends fail.

## Chained rotation fixture

`scenario_rotate_chain` uses a short token lifetime so operators can exercise two back-to-back refresh calls inside grace; both should stay authorized and keep summary counts stable.
