package fetch

import (
	"encoding/json"
	"net/http"
	"os"

	"session.lab/pkg/types"
)

const sessionProbePath = "/app/output/session_probe.json"

// F5Health is a lightweight readiness probe.
func F5Health(w http.ResponseWriter, _ *http.Request) {
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write([]byte("ok"))
}

// WriteSessionProbe persists the latest summary view for operators.
func WriteSessionProbe(path string, view types.SummaryView) error {
	if path == "" {
		path = sessionProbePath
	}
	if err := os.MkdirAll("/app/output", 0o755); err != nil {
		return err
	}
	raw, err := json.Marshal(view)
	if err != nil {
		return err
	}
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, raw, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}
