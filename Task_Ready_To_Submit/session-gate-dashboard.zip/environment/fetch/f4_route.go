package fetch

import (
	"encoding/json"
	"net/http"
	"strings"

	"session.lab/pane"
	"session.lab/pkg/types"
	"session.lab/skiff"
)

type Server struct {
	Cfg        types.DashConfig
	TicketPath string
}

type loginBody struct {
	User string `json:"user"`
	Pass string `json:"pass"`
}

func (s *Server) Mount(mux *http.ServeMux) {
	mux.HandleFunc("/api/v1/login", s.handleLogin)
	mux.HandleFunc("/api/v1/summary", s.handleSummary)
	mux.HandleFunc("/api/v1/refresh", s.handleRefresh)
}

func (s *Server) handleLogin(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method", http.StatusMethodNotAllowed)
		return
	}
	var body loginBody
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		http.Error(w, "bad json", http.StatusBadRequest)
		return
	}
	if body.User != s.Cfg.OperatorUser || body.Pass != s.Cfg.OperatorPass {
		http.Error(w, "denied", http.StatusUnauthorized)
		return
	}
	tok, err := skiff.K0Mint(body.User, s.Cfg.TokenTTL)
	if err != nil {
		http.Error(w, "issue", http.StatusInternalServerError)
		return
	}
	writeJSON(w, map[string]any{"token": tok, "session_label": s.Cfg.SessionLabel})
}

func (s *Server) handleSummary(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "method", http.StatusMethodNotAllowed)
		return
	}
	raw := bearerFrom(r)
	if raw == "" {
		http.Error(w, "missing credential", http.StatusUnauthorized)
		return
	}
	if _, err := skiff.K0Bind(raw); err != nil {
		http.Error(w, "invalid credential", http.StatusUnauthorized)
		return
	}
	rows, err := pane.H2Load(s.TicketPath)
	if err != nil {
		http.Error(w, "data", http.StatusInternalServerError)
		return
	}
	view := pane.H2Summarize(rows, s.Cfg.SessionLabel)
	if err := WriteSessionProbe("/app/output/session_probe.json", view); err != nil {
		http.Error(w, "probe", http.StatusInternalServerError)
		return
	}
	writeJSON(w, view)
}

func (s *Server) handleRefresh(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method", http.StatusMethodNotAllowed)
		return
	}
	raw := bearerFrom(r)
	if raw == "" {
		http.Error(w, "missing credential", http.StatusUnauthorized)
		return
	}
	tok, err := skiff.K1Spin(raw, s.Cfg.TokenTTL, s.Cfg.RefreshGrace)
	if err != nil {
		http.Error(w, "rotate", http.StatusUnauthorized)
		return
	}
	writeJSON(w, map[string]any{"token": tok, "session_label": s.Cfg.SessionLabel})
}

func bearerFrom(r *http.Request) string {
	h := r.Header.Get("Authorization")
	if h == "" {
		return ""
	}
	if strings.HasPrefix(strings.ToLower(h), "bearer ") {
		return strings.TrimSpace(h[7:])
	}
	return strings.TrimSpace(h)
}

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	enc := json.NewEncoder(w)
	enc.SetEscapeHTML(false)
	_ = enc.Encode(v)
}
