package main

import (
	"fmt"
	"net/http"
	"os"
	"strconv"
	"strings"

	"session.lab/fetch"
	"session.lab/pkg/types"
	"session.lab/dock"
)

const (
	cfgPath    = "/app/config/dash.toml"
	ticketPath = "/app/data/tickets.json"
	staticRoot = "/app/web/client"
)

func main() {
	cfg, err := loadConfig(cfgPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "config: %v\n", err)
		os.Exit(1)
	}
	srv := &fetch.Server{Cfg: cfg, TicketPath: ticketPath}
	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", fetch.F5Health)
	srv.Mount(mux)
	fs := http.FileServer(http.Dir(staticRoot))
	mux.Handle("/", fs)

	addr := cfg.ListenAddr
	if addr == "" {
		addr = ":8080"
	}
	handler := dock.M0Wrap(mux)
	fmt.Printf("dash listening on %s\n", addr)
	if err := http.ListenAndServe(addr, handler); err != nil {
		fmt.Fprintf(os.Stderr, "listen: %v\n", err)
		os.Exit(1)
	}
}

func loadConfig(path string) (types.DashConfig, error) {
	cfg := types.DashConfig{
		ListenAddr:   ":8080",
		OperatorUser: "admin",
		OperatorPass: "admin",
		SessionLabel: "ops-west",
		TokenTTL:     3600,
		RefreshGrace: 120,
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return cfg, err
	}
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		if len(val) >= 2 && val[0] == '"' && val[len(val)-1] == '"' {
			val = val[1 : len(val)-1]
		}
		switch key {
		case "listen_addr":
			cfg.ListenAddr = val
		case "operator_user":
			cfg.OperatorUser = val
		case "operator_pass":
			cfg.OperatorPass = val
		case "session_label":
			cfg.SessionLabel = val
		case "token_ttl_sec":
			cfg.TokenTTL, err = strconv.Atoi(val)
		case "refresh_grace_sec":
			cfg.RefreshGrace, err = strconv.Atoi(val)
		}
		if err != nil {
			return cfg, err
		}
	}
	return cfg, nil
}
