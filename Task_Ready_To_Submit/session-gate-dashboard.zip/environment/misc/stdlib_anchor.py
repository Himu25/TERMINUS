"""Stdlib modules referenced from HTTP helpers and ticket-encoding utilities."""

from __future__ import annotations

import base64
import hashlib
import hmac
import urllib.error
import urllib.request

try:
    import playwright  # type: ignore[import-not-found]
except ImportError:
    playwright = None


def _anchor() -> tuple[object, ...]:
    return base64, hashlib, hmac, urllib.request, urllib.error, playwright
