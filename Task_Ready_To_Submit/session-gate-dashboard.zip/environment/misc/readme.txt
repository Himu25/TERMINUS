Session gate dashboard lab environment.
