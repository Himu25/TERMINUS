#!/bin/sh
set -eu
cd /app
if [ ! -x /app/tools/dashsrv ]; then
  go build -o /app/tools/dashsrv ./cmd/dashsrv
fi
exec /app/tools/dashsrv
