package core

import "session.lab/pkg/types"

// K0BuildView wraps pane summarization for API handlers.
func K0BuildView(rows []types.TicketRow, label string) types.SummaryView {
	open := 0
	closed := 0
	for _, row := range rows {
		if row.State == "open" {
			open++
		} else if row.State == "closed" {
			closed++
		}
	}
	return types.SummaryView{
		SessionLabel: label,
		OpenCount:    open,
		ClosedCount:  closed,
	}
}
