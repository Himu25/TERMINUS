"""Verifier for session-gate-dashboard."""

from __future__ import annotations

import json
import os
import subprocess
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, NamedTuple

import pytest
from playwright.sync_api import Page, sync_playwright

APP = Path("/app")
CFG = APP / "config" / "dash.toml"
TICKETS = APP / "data" / "tickets.json"
PROBE = APP / "output" / "session_probe.json"
FIXTURES = Path(__file__).resolve().parent / "fixtures"
BASE = "http://127.0.0.1:8080"
UI_REQUEST_TAG = "dash-ui"

LAB_CFG = CFG.read_text(encoding="utf-8")
LAB_TICKETS = TICKETS.read_text(encoding="utf-8")

HARD_SUFFIXES = {
    "scenario_refresh_window",
    "scenario_strict_cors",
    "scenario_tight_grace",
    "scenario_rotate_chain",
}


class DashHolder:
    proc: subprocess.Popen[bytes] | None = None


HOLDER = DashHolder()


class ScenarioPack(NamedTuple):
    user: str
    password: str
    session_label: str
    open_count: int
    closed_count: int
    token_ttl: int
    refresh_grace: int


def _discover_scenarios() -> list[str]:
    return sorted(p.name for p in FIXTURES.iterdir() if p.is_dir())


# High-coupling packs are covered by test_hard_scenarios; browser parametrization
# uses the remaining packs so steady UI fixes score without duplicating hard paths.
BROWSER_SCENARIO_SUFFIXES = sorted(
    name for name in _discover_scenarios() if name not in HARD_SUFFIXES
)


def _parse_cfg(text: str) -> dict[str, str]:
    cfg: dict[str, str] = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = line.split("=", 1)
        cfg[key.strip()] = val.strip().strip('"')
    return cfg


def _sleep_past_expiry(pack: ScenarioPack, *, cushion_sec: int = 1) -> None:
    time.sleep(max(1, pack.token_ttl + cushion_sec))


def _sleep_past_grace(pack: ScenarioPack, *, cushion_sec: int = 1) -> None:
    time.sleep(max(1, pack.token_ttl + pack.refresh_grace + cushion_sec))


def _load_pack(name: str) -> ScenarioPack:
    root = FIXTURES / name
    cfg = _parse_cfg((root / "dash.toml").read_text(encoding="utf-8"))
    rows = json.loads((root / "tickets.json").read_text(encoding="utf-8"))
    return ScenarioPack(
        user=cfg["operator_user"],
        password=cfg["operator_pass"],
        session_label=cfg["session_label"],
        open_count=sum(1 for r in rows if r["state"] == "open"),
        closed_count=sum(1 for r in rows if r["state"] == "closed"),
        token_ttl=int(cfg.get("token_ttl_sec", "3600")),
        refresh_grace=int(cfg.get("refresh_grace_sec", "120")),
    )


def _lab_pack() -> ScenarioPack:
    rows = json.loads(LAB_TICKETS)
    cfg = _parse_cfg(LAB_CFG)
    return ScenarioPack(
        user=cfg["operator_user"],
        password=cfg["operator_pass"],
        session_label=cfg["session_label"],
        open_count=sum(1 for r in rows if r["state"] == "open"),
        closed_count=sum(1 for r in rows if r["state"] == "closed"),
        token_ttl=int(cfg.get("token_ttl_sec", "3600")),
        refresh_grace=int(cfg.get("refresh_grace_sec", "120")),
    )


def pytest_generate_tests(metafunc: pytest.Metafunc) -> None:
    if "scenario" not in metafunc.fixturenames:
        return
    fn = metafunc.definition.name
    if fn.endswith("hard_scenarios"):
        metafunc.parametrize("scenario", sorted(HARD_SUFFIXES))
    elif "browser" in fn and "parametrized" in fn:
        metafunc.parametrize("scenario", BROWSER_SCENARIO_SUFFIXES)
    else:
        metafunc.parametrize("scenario", _discover_scenarios())


def _atomic_write(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _apply_scenario(name: str) -> None:
    root = FIXTURES / name
    _atomic_write(CFG, (root / "dash.toml").read_text(encoding="utf-8"))
    _atomic_write(TICKETS, (root / "tickets.json").read_text(encoding="utf-8"))


def _restore_lab_bundle() -> None:
    _atomic_write(CFG, LAB_CFG)
    _atomic_write(TICKETS, LAB_TICKETS)


def _wait_health(timeout: float = 20.0) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(f"{BASE}/healthz", timeout=1) as resp:
                if resp.status == 200:
                    return
        except Exception:
            time.sleep(0.25)
    raise RuntimeError("dash server did not become ready")


def _stop_server() -> None:
    if HOLDER.proc is None:
        return
    pgid = os.getpgid(HOLDER.proc.pid)
    os.killpg(pgid, 15)
    try:
        HOLDER.proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        os.killpg(pgid, 9)
    HOLDER.proc = None


def _rebuild_server_binary() -> None:
    subprocess.run(
        ["go", "build", "-o", "/app/tools/dashsrv", "./cmd/dashsrv"],
        cwd=APP,
        check=True,
    )


def _start_server() -> None:
    _rebuild_server_binary()
    HOLDER.proc = subprocess.Popen(
        ["/app/tools/run_dashsrv.sh"],
        cwd=APP,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        preexec_fn=os.setsid,
    )
    _wait_health()


def _restart_server() -> None:
    _stop_server()
    _start_server()


def _http_json(
    path: str,
    *,
    method: str = "GET",
    body: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
) -> tuple[int, dict[str, Any]]:
    data = None
    hdrs = dict(headers or {})
    if body is not None:
        data = json.dumps(body).encode()
        hdrs.setdefault("Content-Type", "application/json")
    req = urllib.request.Request(f"{BASE}{path}", data=data, headers=hdrs, method=method)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            payload = resp.read().decode()
            return resp.status, json.loads(payload) if payload else {}
    except urllib.error.HTTPError as exc:
        payload = exc.read().decode()
        try:
            parsed = json.loads(payload) if payload else {}
        except json.JSONDecodeError:
            parsed = {}
        return exc.code, parsed


def _login_token(user: str, password: str) -> str:
    status, body = _http_json(
        "/api/v1/login",
        method="POST",
        body={"user": user, "pass": password},
    )
    assert status == 200
    return str(body["token"])


@pytest.fixture(scope="module", autouse=True)
def dash_server() -> None:
    _restore_lab_bundle()
    _start_server()
    yield
    _stop_server()


@pytest.fixture
def browser_page(dash_server: None) -> Page:
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context()
        page = context.new_page()
        yield page
        context.close()
        browser.close()


def _browser_login(page: Page, user: str, password: str) -> None:
    page.goto(BASE + "/")
    page.evaluate("() => { localStorage.clear(); sessionStorage.clear(); }")
    page.fill("#login-user", user)
    page.fill("#login-pass", password)
    page.click("#login-submit")
    page.wait_for_selector("#tile-open[data-loaded='true']", timeout=15000)


def test_lab_tiles_and_probe(browser_page: Page) -> None:
    """Bundled lab steady-state tiles and probe file align after sign-in."""
    pack = _lab_pack()
    _restore_lab_bundle()
    _restart_server()
    _browser_login(browser_page, pack.user, pack.password)
    assert browser_page.locator("#tile-open").inner_text() == str(pack.open_count)
    assert browser_page.locator("#tile-closed").inner_text() == str(pack.closed_count)
    assert browser_page.locator("#session-label").inner_text() == pack.session_label
    probe = json.loads(PROBE.read_text(encoding="utf-8"))
    assert probe["open_count"] == pack.open_count
    assert probe["closed_count"] == pack.closed_count
    assert probe["session_label"] == pack.session_label


def test_parametrized_browser_scenarios(browser_page: Page, scenario: str) -> None:
    """Each fixture pack loads correct tile counts in the browser."""
    pack = _load_pack(scenario)
    _apply_scenario(scenario)
    _restart_server()
    _browser_login(browser_page, pack.user, pack.password)
    assert browser_page.locator("#tile-open").inner_text() == str(pack.open_count)
    assert browser_page.locator("#tile-closed").inner_text() == str(pack.closed_count)
    assert browser_page.locator("#session-label").inner_text() == pack.session_label


def test_parametrized_http_summary_alignment(scenario: str) -> None:
    """HTTP summary counts match ticket rows for every fixture pack."""
    pack = _load_pack(scenario)
    _apply_scenario(scenario)
    _restart_server()
    token = _login_token(pack.user, pack.password)
    status, view = _http_json(
        "/api/v1/summary",
        headers={"Authorization": f"Bearer {token}", "X-Request-Tag": UI_REQUEST_TAG},
    )
    assert status == 200
    assert view["open_count"] == pack.open_count
    assert view["closed_count"] == pack.closed_count
    assert view["session_label"] == pack.session_label
    probe = json.loads(PROBE.read_text(encoding="utf-8"))
    assert probe["open_count"] == view["open_count"]
    assert probe["closed_count"] == view["closed_count"]


def test_hard_scenarios(browser_page: Page, scenario: str) -> None:
    """High-coupling fixture packs must pass browser login and refresh."""
    pack = _load_pack(scenario)
    _apply_scenario(scenario)
    _restart_server()
    _browser_login(browser_page, pack.user, pack.password)
    if scenario in {"scenario_refresh_window", "scenario_tight_grace", "scenario_rotate_chain"}:
        time.sleep(max(3, pack.token_ttl + 1))
        browser_page.click("#refresh-btn")
        browser_page.wait_for_selector("#tile-open[data-loaded='true']", timeout=15000)
        probe = json.loads(PROBE.read_text(encoding="utf-8"))
        assert probe["open_count"] == pack.open_count
    assert browser_page.locator("#session-label").inner_text() == pack.session_label


def test_browser_summary_authorization_header(browser_page: Page) -> None:
    """Browser summary fetch sends Bearer prefix and dash-ui request tag."""
    pack = _lab_pack()
    _restore_lab_bundle()
    _restart_server()
    page = browser_page
    page.goto(BASE + "/")
    page.fill("#login-user", pack.user)
    page.fill("#login-pass", pack.password)
    with page.expect_request(
        lambda req: "/api/v1/summary" in req.url and req.method == "GET"
    ) as summary_wait:
        page.click("#login-submit")
    summary_req = summary_wait.value
    auth = summary_req.headers.get("authorization", "")
    tag = summary_req.headers.get("x-request-tag", "")
    assert auth.lower().startswith("bearer ")
    assert tag == UI_REQUEST_TAG
    page.wait_for_selector("#tile-open[data-loaded='true']", timeout=15000)


def test_probe_updates_after_browser_refresh(browser_page: Page) -> None:
    """Probe file tracks tile counts after a browser rotate."""
    pack = _load_pack("scenario_rotate_chain")
    _apply_scenario("scenario_rotate_chain")
    _restart_server()
    _browser_login(browser_page, pack.user, pack.password)
    time.sleep(max(3, pack.token_ttl + 1))
    browser_page.click("#refresh-btn")
    browser_page.wait_for_selector("#tile-open[data-loaded='true']", timeout=15000)
    probe = json.loads(PROBE.read_text(encoding="utf-8"))
    assert probe["open_count"] == pack.open_count
    assert probe["closed_count"] == pack.closed_count
    assert probe["session_label"] == pack.session_label


def test_login_denied_wrong_operator(browser_page: Page) -> None:
    """Wrong operator password keeps tiles unloaded and surfaces login error."""
    pack = _lab_pack()
    _restore_lab_bundle()
    _restart_server()
    page = browser_page
    page.goto(BASE + "/")
    page.fill("#login-user", pack.user)
    page.fill("#login-pass", "bad")
    page.click("#login-submit")
    page.wait_for_timeout(500)
    assert page.locator("#login-error").is_visible()
    assert page.locator("#tile-open").get_attribute("data-loaded") != "true"


def test_logout_and_relogin_flow(browser_page: Page) -> None:
    """Logout clears the panel and a second sign-in reloads tiles."""
    pack = _lab_pack()
    _restore_lab_bundle()
    _restart_server()
    _browser_login(browser_page, pack.user, pack.password)
    browser_page.click("#logout-btn")
    browser_page.wait_for_selector("#login-panel:not([hidden])", timeout=5000)
    assert browser_page.locator("#dash-panel").is_hidden()
    _browser_login(browser_page, pack.user, pack.password)
    assert browser_page.locator("#tile-open").inner_text() == str(pack.open_count)


def test_stale_seal_rejected() -> None:
    """Summary route rejects credentials well past the grace band."""
    pack = _load_pack("scenario_tight_grace")
    _apply_scenario("scenario_tight_grace")
    _restart_server()
    token = _login_token(pack.user, pack.password)
    _sleep_past_grace(pack)
    status, _ = _http_json(
        "/api/v1/summary",
        headers={"Authorization": f"Bearer {token}", "X-Request-Tag": UI_REQUEST_TAG},
    )
    assert status == 401


def test_stale_row_blocks_browser_refresh(browser_page: Page) -> None:
    """Expired stored row blocks browser rotate and cannot load summary."""
    pack = _load_pack("scenario_tight_grace")
    _apply_scenario("scenario_tight_grace")
    _restart_server()
    _browser_login(browser_page, pack.user, pack.password)
    stored_before = browser_page.evaluate("() => localStorage.getItem('dash_cred') || ''")
    assert stored_before
    _sleep_past_grace(pack)
    with browser_page.expect_response(
        lambda resp: "/api/v1/refresh" in resp.url and resp.status == 401
    ):
        browser_page.click("#refresh-btn")
    stored = browser_page.evaluate("() => localStorage.getItem('dash_cred') || ''")
    assert stored == stored_before
    status, _ = _http_json(
        "/api/v1/summary",
        headers={"Authorization": f"Bearer {stored}", "X-Request-Tag": UI_REQUEST_TAG},
    )
    assert status == 401


def test_options_allow_auth_header() -> None:
    """Refresh preflight allows Authorization request header."""
    _restore_lab_bundle()
    _restart_server()
    token = _login_token("admin", "admin")
    req = urllib.request.Request(
        f"{BASE}/api/v1/refresh",
        method="OPTIONS",
        headers={
            "Origin": BASE,
            "Access-Control-Request-Method": "POST",
            "Access-Control-Request-Headers": "authorization, x-request-tag",
        },
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        allow = resp.headers.get("Access-Control-Allow-Headers", "")
    assert "authorization" in allow.lower()
    assert token


def test_grace_turn_succeeds() -> None:
    """Rotate succeeds for credentials inside the grace window after expiry."""
    pack = _load_pack("scenario_refresh_window")
    _apply_scenario("scenario_refresh_window")
    _restart_server()
    token = _login_token(pack.user, pack.password)
    _sleep_past_expiry(pack)
    rotate_status, rotated = _http_json(
        "/api/v1/refresh",
        method="POST",
        headers={"Authorization": f"Bearer {token}", "X-Request-Tag": UI_REQUEST_TAG},
        body={},
    )
    assert rotate_status == 200
    assert rotated.get("token")
    sum_status, view = _http_json(
        "/api/v1/summary",
        headers={"Authorization": f"Bearer {rotated['token']}", "X-Request-Tag": UI_REQUEST_TAG},
    )
    assert sum_status == 200
    assert view["open_count"] == pack.open_count
    assert view["closed_count"] == pack.closed_count


def test_grace_inside_tight_window() -> None:
    """Tight-grace pack allows rotate inside the documented grace band."""
    pack = _load_pack("scenario_tight_grace")
    _apply_scenario("scenario_tight_grace")
    _restart_server()
    token = _login_token(pack.user, pack.password)
    _sleep_past_expiry(pack)
    rotate_status, rotated = _http_json(
        "/api/v1/refresh",
        method="POST",
        headers={"Authorization": f"Bearer {token}", "X-Request-Tag": UI_REQUEST_TAG},
        body={},
    )
    assert rotate_status == 200
    assert rotated.get("token")


def test_grace_outside_window_rejected() -> None:
    """Tight-grace pack rejects rotate after the grace band ends."""
    pack = _load_pack("scenario_tight_grace")
    _apply_scenario("scenario_tight_grace")
    _restart_server()
    token = _login_token(pack.user, pack.password)
    _sleep_past_grace(pack)
    rotate_status, _ = _http_json(
        "/api/v1/refresh",
        method="POST",
        headers={"Authorization": f"Bearer {token}", "X-Request-Tag": UI_REQUEST_TAG},
        body={},
    )
    assert rotate_status == 401


def test_double_rotate_chain() -> None:
    """Two successive rotates stay authorized and preserve summary counts."""
    pack = _load_pack("scenario_rotate_chain")
    _apply_scenario("scenario_rotate_chain")
    _restart_server()
    first = _login_token(pack.user, pack.password)
    _sleep_past_expiry(pack)
    mid_status, mid = _http_json(
        "/api/v1/refresh",
        method="POST",
        headers={"Authorization": f"Bearer {first}", "X-Request-Tag": UI_REQUEST_TAG},
        body={},
    )
    assert mid_status == 200
    assert mid.get("token")
    second_status, final = _http_json(
        "/api/v1/refresh",
        method="POST",
        headers={"Authorization": f"Bearer {mid['token']}", "X-Request-Tag": UI_REQUEST_TAG},
        body={},
    )
    assert second_status == 200
    sum_status, view = _http_json(
        "/api/v1/summary",
        headers={"Authorization": f"Bearer {final['token']}", "X-Request-Tag": UI_REQUEST_TAG},
    )
    assert sum_status == 200
    assert view["open_count"] == pack.open_count
    assert view["closed_count"] == pack.closed_count
    assert view["session_label"] == pack.session_label


def test_summary_bearer_accepted() -> None:
    """Summary accepts a Bearer-prefixed authorization header."""
    pack = _lab_pack()
    _restore_lab_bundle()
    _restart_server()
    raw = _login_token(pack.user, pack.password)
    bearer_status, view = _http_json(
        "/api/v1/summary",
        headers={"Authorization": f"Bearer {raw}", "X-Request-Tag": UI_REQUEST_TAG},
    )
    assert bearer_status == 200
    assert view["open_count"] == pack.open_count
