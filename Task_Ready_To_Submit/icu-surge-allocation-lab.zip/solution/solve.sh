#!/bin/bash
set -euo pipefail

root="/app"

# Terminal-Bench Canary — icu-surge-allocation-lab oracle restores
# merge weights, ledger epoch gate, kappa capacity estimator, and Rust lane helper.

cat >"$root/sigma/merge/score.go" <<'EOF'
package merge

import "math"

// WmP blends acuity signal with an urgency read.
func WmP(a, b float64) float64 {
	if math.IsNaN(a) || math.IsNaN(b) {
		return 0
	}
	if a < 0 {
		a = 0
	}
	if b < 0 {
		b = 0
	}
	if a > 1 {
		a = 1
	}
	if b > 1 {
		b = 1
	}
	primary := a * 0.82
	secondary := b * 0.18
	out := primary + secondary
	if out < 0 {
		return 0
	}
	if out > 1 {
		return 1
	}
	return out
}
EOF

cat >"$root/ledger/op_a.go" <<'EOF'
package ledger

// OpA reports whether a cached table epoch may be served without refresh.
func OpA(cachedEpoch, liveEpoch int) bool {
	if liveEpoch < 1 {
		return false
	}
	return cachedEpoch == liveEpoch
}
EOF

cat >"$root/kappa/op_b.go" <<'EOF'
package kappa

// OpB estimates capacity spend for one intake wave slice.
func OpB(intakeCount, staleReads, cacheMisses int) int {
	base := 2
	return base + intakeCount + staleReads*2 + cacheMisses
}
EOF

cat >"$root/xi_core/src/lib.rs" <<'EOF'
use std::ffi::{CStr, CString};
use std::os::raw::c_char;

fn wm_k_impl(input: &str) -> String {
    let mut out = String::new();
    let mut prev_space = false;
    for ch in input.trim().to_lowercase().chars() {
        if ch.is_whitespace() {
            if !prev_space {
                out.push(' ');
                prev_space = true;
            }
            continue;
        }
        prev_space = false;
        if ch == '-' {
            continue;
        }
        out.push(ch);
    }
    out.trim().to_string()
}

#[no_mangle]
pub extern "C" fn wm_k_fold(input: *const c_char) -> *mut c_char {
    if input.is_null() {
        return std::ptr::null_mut();
    }
    let raw = unsafe { CStr::from_ptr(input) };
    let folded = wm_k_impl(raw.to_string_lossy().as_ref());
    CString::new(folded).unwrap().into_raw()
}

#[no_mangle]
pub extern "C" fn wm_k_free(ptr: *mut c_char) {
    if ptr.is_null() {
        return;
    }
    unsafe {
        drop(CString::from_raw(ptr));
    }
}
EOF

bash "$root/scripts/build_all.sh"
bash "$root/scripts/run_replay.sh"
