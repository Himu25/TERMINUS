use std::ffi::{CStr, CString};
use std::os::raw::c_char;

fn wm_k_impl(input: &str) -> String {
    input.trim().to_lowercase()
}

#[no_mangle]
pub extern "C" fn wm_k_fold(input: *const c_char) -> *mut c_char {
    if input.is_null() {
        return std::ptr::null_mut();
    }
    let raw = unsafe { CStr::from_ptr(input) };
    let folded = wm_k_impl(raw.to_string_lossy().as_ref());
    CString::new(folded).unwrap().into_raw()
}

#[no_mangle]
pub extern "C" fn wm_k_free(ptr: *mut c_char) {
    if ptr.is_null() {
        return;
    }
    unsafe {
        drop(CString::from_raw(ptr));
    }
}
