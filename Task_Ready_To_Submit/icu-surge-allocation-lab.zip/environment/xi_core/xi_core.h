#ifndef XI_CORE_H
#define XI_CORE_H

char *wm_k_fold(const char *input);
void wm_k_free(char *ptr);

#endif
