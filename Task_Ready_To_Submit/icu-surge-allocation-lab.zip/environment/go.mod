module ward.dev/ops

go 1.22
