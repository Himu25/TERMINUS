package util

import "strings"

func TrimSpaces(raw string) string {
	return strings.TrimSpace(raw)
}
