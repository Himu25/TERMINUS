package model

import "crypto/sha256"
import "encoding/hex"

func DigestLabel(label string) string {
	sum := sha256.Sum256([]byte(label))
	return hex.EncodeToString(sum[:8])
}
