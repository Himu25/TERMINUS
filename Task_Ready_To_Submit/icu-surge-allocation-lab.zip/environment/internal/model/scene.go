package model

type Intake struct {
	IntakeID  string  `json:"intake_id"`
	LaneCode  string  `json:"lane_code"`
	AcuityA   float64 `json:"acuity_a"`
	UrgencyU  float64 `json:"urgency_u"`
}

type Pulse struct {
	PulseID       string   `json:"pulse_id"`
	ResourceEpoch int      `json:"resource_epoch,omitempty"`
	Intakes       []Intake `json:"intakes"`
}

type ResourceSlot struct {
	Boost float64 `json:"boost"`
	Epoch int     `json:"epoch"`
}

type Scenario struct {
	WaveLabel       string                  `json:"wave_label"`
	CapacityBudget  int                     `json:"capacity_budget"`
	ResourceEpoch   int                     `json:"resource_epoch"`
	Pulses          []Pulse                 `json:"pulses"`
	ResourceTable   map[string]ResourceSlot `json:"resource_table"`
}

type Entry struct {
	WaveLabel           string `json:"wave_label"`
	HeadAdmitID         string `json:"head_admit_id"`
	CapacityMissTotal   int    `json:"capacity_miss_total"`
	StaleRefreshTotal   int    `json:"stale_refresh_total"`
	PriorityOkFlag      string `json:"priority_ok_flag"`
	CapacityOkFlag      string `json:"capacity_ok_flag"`
}

type ReportDoc struct {
	Schema  string  `json:"schema"`
	Entries []Entry `json:"entries"`
}
