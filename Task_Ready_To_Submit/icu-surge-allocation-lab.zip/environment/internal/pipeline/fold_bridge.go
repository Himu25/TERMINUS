package pipeline

/*
#cgo LDFLAGS: -L/app/lib -lxi_core
#include "../../xi_core/xi_core.h"
#include <stdlib.h>
*/
import "C"
import "unsafe"

func FoldKey(raw string) string {
	cstr := C.CString(raw)
	defer C.free(unsafe.Pointer(cstr))
	out := C.wm_k_fold(cstr)
	if out == nil {
		return ""
	}
	defer C.wm_k_free(out)
	return C.GoString(out)
}
