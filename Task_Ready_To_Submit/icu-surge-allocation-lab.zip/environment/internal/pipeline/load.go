package pipeline

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sort"
	"ward.dev/ops/internal/model"
)

func loadScenarios(dir string) ([]model.Scenario, error) {
	paths, err := filepath.Glob(filepath.Join(dir, "*.json"))
	if err != nil {
		return nil, err
	}
	sort.Strings(paths)
	out := make([]model.Scenario, 0, len(paths))
	for _, p := range paths {
		raw, err := os.ReadFile(p)
		if err != nil {
			return nil, err
		}
		var scene model.Scenario
		if err := json.Unmarshal(raw, &scene); err != nil {
			return nil, err
		}
		out = append(out, scene)
	}
	return out, nil
}
