package pipeline

import (
	"ward.dev/ops/internal/model"
	"sort"
)

func prioritySanity(scene model.Scenario, head string) bool {
	if len(scene.Pulses) == 0 {
		return head == ""
	}
	last := scene.Pulses[len(scene.Pulses)-1]
	if len(last.Intakes) == 0 {
		return head == ""
	}
	expect := expectedHead(last, scene.ResourceTable)
	return head == expect
}

func expectedHead(pulse model.Pulse, table map[string]model.ResourceSlot) string {
	type pair struct {
		id    string
		score float64
	}
	scored := make([]pair, 0, len(pulse.Intakes))
	for _, intake := range pulse.Intakes {
		key := FoldKey(intake.LaneCode)
		boost := 0.0
		if slot, ok := table[key]; ok {
			boost = slot.Boost
		}
		score := blendScore(intake.AcuityA, intake.UrgencyU) + boost
		scored = append(scored, pair{id: intake.IntakeID, score: score})
	}
	sort.Slice(scored, func(i, j int) bool {
		if scored[i].score == scored[j].score {
			return scored[i].id < scored[j].id
		}
		return scored[i].score > scored[j].score
	})
	return scored[0].id
}
