package pipeline

import (
	"sort"
	"ward.dev/ops/internal/model"
	"ward.dev/ops/ledger"
	"ward.dev/ops/lane"
	"ward.dev/ops/kappa"
)

type scoredIntake struct {
	intake model.Intake
	score  float64
}

func ReplayScenario(scene model.Scenario) model.Entry {
	cache := ledger.NewCache()
	staleTotal := 0
	capacityMiss := 0
	lastHead := ""
	table := ledger.TableFromResources(toResourceInputs(scene.ResourceTable))

	for _, pls := range scene.Pulses {
		stalePulse := 0
		missPulse := 0
		liveEpoch := scene.ResourceEpoch
		if pls.ResourceEpoch > 0 {
			liveEpoch = pls.ResourceEpoch
		}
		scored := make([]scoredIntake, 0, len(pls.Intakes))
		for _, intake := range pls.Intakes {
			key := FoldKey(intake.LaneCode)
			boost, stale, miss := ledger.LookupBoost(cache, table, key, liveEpoch)
			stalePulse += stale
			missPulse += miss
			score := blendScore(intake.AcuityA, intake.UrgencyU) + boost
			scored = append(scored, scoredIntake{intake: intake, score: score})
		}
		staleTotal += stalePulse
		sort.Slice(scored, func(i, j int) bool {
			if scored[i].score == scored[j].score {
				return scored[i].intake.IntakeID < scored[j].intake.IntakeID
			}
			return scored[i].score > scored[j].score
		})
		if len(scored) > 0 {
			lastHead = scored[0].intake.IntakeID
		}
		ticks := kappa.PulseTicks(len(pls.Intakes), stalePulse, missPulse)
		if ticks > scene.CapacityBudget {
			capacityMiss++
		}
	}

	priorityOK := prioritySanity(scene, lastHead)
	capacityOK := capacityMiss == 0
	return model.Entry{
		WaveLabel:         scene.WaveLabel,
		HeadAdmitID:       lastHead,
		CapacityMissTotal: capacityMiss,
		StaleRefreshTotal: staleTotal,
		PriorityOkFlag:    lane.Flag(priorityOK),
		CapacityOkFlag:    lane.Flag(capacityOK),
	}
}

func LoadScenarios(dir string) ([]model.Scenario, error) {
	return loadScenarios(dir)
}

func toResourceInputs(raw map[string]model.ResourceSlot) map[string]ledger.ResourceInput {
	out := make(map[string]ledger.ResourceInput, len(raw))
	for k, v := range raw {
		out[k] = ledger.ResourceInput{Boost: v.Boost, Epoch: v.Epoch}
	}
	return out
}
