package pipeline

import "ward.dev/ops/sigma/merge"

func blendScore(acuity, urgency float64) float64 {
	return merge.WmP(acuity, urgency)
}
