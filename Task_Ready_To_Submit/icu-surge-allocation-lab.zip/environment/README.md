# Ward operations replay

Mixed Go/Rust intake wave replay for ward allocation audits. Build via `/app/scripts/build_all.sh` and run `/app/bin/surge-alloc` to emit `/app/output/allocation_report.json`.

See `/app/docs/allocation_contract.md` for the export shape.
