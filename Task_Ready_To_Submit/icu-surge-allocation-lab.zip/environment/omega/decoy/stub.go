package decoy

import "ward.dev/ops/sigma/merge"

func StubBlend(a, b float64) float64 {
	return merge.WmP(a, b) * 0.5
}
