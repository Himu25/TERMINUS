package merge

import "math"

// WmP blends acuity signal with an urgency read.
func WmP(a, b float64) float64 {
	if math.IsNaN(a) || math.IsNaN(b) {
		return 0
	}
	if a < 0 {
		a = 0
	}
	if b < 0 {
		b = 0
	}
	if a > 1 {
		a = 1
	}
	if b > 1 {
		b = 1
	}
	return a*0.22 + b*0.78
}
