# Architecture notes

The replay binary links a Rust static archive for lane-code folding and walks sorted scenario JSON under `/app/data/scenarios/`. Warm slot reads flow through the ledger cache; per-wave spend estimates come from the kappa module.

The sigma module combines two normalized intake signals. Ledger freshness checks gate cached table rows. Kappa accumulates spend units per wave slice.

Output rows land in `/app/output/allocation_report.json` with schema marker `surge-alloc-1`.
