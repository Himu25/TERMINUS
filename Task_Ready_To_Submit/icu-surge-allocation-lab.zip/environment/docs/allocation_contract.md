# Allocation export contract

`/app/output/allocation_report.json` is a JSON object with `schema` set to `surge-alloc-1` and an `entries` array.

Each entry includes `wave_label`, `head_admit_id`, `capacity_miss_total`, `stale_refresh_total`, `priority_ok_flag`, and `capacity_ok_flag`. Integer totals are plain JSON numbers. `priority_ok_flag` is `yes` when the final-pulse head admit matches the lane-normalized priority probe, otherwise `no`. `capacity_ok_flag` is `yes` when no pulse exceeded the scenario `capacity_budget` under the correct refresh capacity costing, otherwise `no`.

Process scenario files in sorted filename order under `/app/data/scenarios/`.
