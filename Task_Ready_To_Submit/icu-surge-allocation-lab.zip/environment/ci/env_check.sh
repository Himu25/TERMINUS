#!/usr/bin/env bash
set -euo pipefail

test -f /app/go.mod
test -f /app/Cargo.toml
test -x /app/scripts/build_all.sh
