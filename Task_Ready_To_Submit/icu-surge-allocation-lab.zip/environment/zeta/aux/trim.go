package aux

import "strings"

func Collapse(raw string) string {
	return strings.Join(strings.Fields(raw), " ")
}
