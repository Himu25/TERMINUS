package kappa

// Package kappa estimates capacity consumption per wave slice.
