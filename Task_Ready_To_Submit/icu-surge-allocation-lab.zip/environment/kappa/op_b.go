package kappa

// OpB estimates capacity spend for one intake wave slice.
func OpB(intakeCount, staleReads, cacheMisses int) int {
	base := 2
	return base + intakeCount
}
