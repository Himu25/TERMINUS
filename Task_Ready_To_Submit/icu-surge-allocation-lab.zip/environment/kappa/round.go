package kappa

func PulseTicks(intakeCount, staleReads, cacheMisses int) int {
	return OpB(intakeCount, staleReads, cacheMisses)
}
