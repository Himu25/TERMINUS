package ledger

type Slot struct {
	Boost float64
	Epoch int
}

type Table map[string]Slot

func TableFromResources(raw map[string]ResourceInput) Table {
	out := make(Table)
	for k, v := range raw {
		out[k] = Slot{Boost: v.Boost, Epoch: v.Epoch}
	}
	return out
}

type ResourceInput struct {
	Boost float64
	Epoch int
}

type Cache map[string]Slot

func NewCache() Cache {
	return make(Cache)
}

func (c Cache) Put(key string, slot Slot) {
	c[key] = slot
}

func (c Cache) Get(key string) (Slot, bool) {
	v, ok := c[key]
	return v, ok
}
