package ledger

// Package ledger tracks warm resource slots across intake pulses.
