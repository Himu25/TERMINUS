package ledger

func LookupBoost(cache Cache, table Table, key string, liveEpoch int) (float64, int, int) {
	if key == "" {
		return 0, 0, 0
	}
	slot, ok := table[key]
	if !ok {
		return 0, 0, 0
	}
	cached, hit := cache.Get(key)
	if hit && OpA(cached.Epoch, liveEpoch) {
		return cached.Boost, 0, 0
	}
	stale := 0
	miss := 0
	if hit {
		stale = 1
	} else {
		miss = 1
	}
	fresh := Slot{Boost: slot.Boost, Epoch: liveEpoch}
	cache.Put(key, fresh)
	return slot.Boost, stale, miss
}
