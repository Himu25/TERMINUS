package ledger

// OpA reports whether a cached table epoch may be served without refresh.
func OpA(cachedEpoch, liveEpoch int) bool {
	if liveEpoch < 1 {
		return false
	}
	return cachedEpoch >= liveEpoch-1
}
