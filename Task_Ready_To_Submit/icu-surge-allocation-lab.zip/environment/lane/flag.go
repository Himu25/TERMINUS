package lane

func Flag(ok bool) string {
	if ok {
		return "yes"
	}
	return "no"
}
