package lane

// Package lane exposes posture flag tokens for report rows.
