package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"ward.dev/ops/internal/model"
	"ward.dev/ops/internal/pipeline"
)

func main() {
	root := "/app"
	scenes, err := pipeline.LoadScenarios(filepath.Join(root, "data", "scenarios"))
	if err != nil {
		panic(err)
	}
	entries := make([]model.Entry, 0, len(scenes))
	for _, scene := range scenes {
		entries = append(entries, pipeline.ReplayScenario(scene))
	}
	doc := model.ReportDoc{Schema: "surge-alloc-1", Entries: entries}
	outDir := filepath.Join(root, "output")
	_ = os.MkdirAll(outDir, 0o755)
	data, _ := json.MarshalIndent(doc, "", "  ")
	_ = os.WriteFile(filepath.Join(outDir, "allocation_report.json"), data, 0o644)
}
