#!/usr/bin/env bash
set -euo pipefail

APP_ROOT="/app"
export PATH="/usr/local/go/bin:/usr/local/cargo/bin:${PATH}"

cd "${APP_ROOT}"
mkdir -p "${APP_ROOT}/lib" "${APP_ROOT}/bin"

cargo build --release --locked --manifest-path "${APP_ROOT}/Cargo.toml" -p xi_core
install -m 0644 "${APP_ROOT}/target/release/libxi_core.a" "${APP_ROOT}/lib/libxi_core.a"

export CGO_LDFLAGS="-L${APP_ROOT}/lib -lxi_core"
/usr/local/go/bin/go build -buildvcs=false -o "${APP_ROOT}/bin/surge-alloc" ./cmd/surge-alloc
