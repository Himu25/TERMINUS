"""Verifier for ward surge allocation replay report."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "allocation_report.json"
FIXTURE_DIR = Path(__file__).resolve().parent / "fixtures" / "scenarios"
_SUBPROC_ENV = os.environ.copy()
_SUBPROC_ENV["PATH"] = "/usr/local/go/bin:/app/bin:" + _SUBPROC_ENV.get("PATH", "")
_BUILD_TIMEOUT_SEC = 180
_RUN_TIMEOUT_SEC = 60


def _fold_key(raw: str) -> str:
    out: list[str] = []
    prev_space = False
    for ch in raw.strip().lower():
        if ch.isspace():
            if not prev_space:
                out.append(" ")
                prev_space = True
            continue
        if ch == "-":
            continue
        prev_space = False
        out.append(ch)
    return "".join(out).strip()


def _wmp(a: float, b: float) -> float:
    a = max(0.0, min(1.0, a))
    b = max(0.0, min(1.0, b))
    return a * 0.82 + b * 0.18


def _op_a(cached: int, live: int) -> bool:
    return cached == live if live >= 1 else False


def _op_b(intake_count: int, stale: int, miss: int) -> int:
    return 2 + intake_count + stale * 2 + miss


def _reference_row(scene: dict) -> dict[str, int | str]:
    cache: dict[str, tuple[float, int]] = {}
    stale_total = 0
    capacity_miss = 0
    last_head = ""
    table = scene["resource_table"]
    base_epoch = int(scene["resource_epoch"])

    for pulse in scene["pulses"]:
        live_epoch = int(pulse.get("resource_epoch") or base_epoch)
        stale_pulse = 0
        miss_pulse = 0
        scored: list[tuple[str, float]] = []
        for intake in pulse["intakes"]:
            key = _fold_key(intake["lane_code"])
            boost = 0.0
            if key in table:
                slot = table[key]
                if key in cache and _op_a(cache[key][1], live_epoch):
                    boost = cache[key][0]
                else:
                    if key in cache:
                        stale_pulse += 1
                    else:
                        miss_pulse += 1
                    boost = float(slot["boost"])
                    cache[key] = (boost, live_epoch)
            score = _wmp(float(intake["acuity_a"]), float(intake["urgency_u"])) + boost
            scored.append((intake["intake_id"], score))
        stale_total += stale_pulse
        scored.sort(key=lambda item: (-item[1], item[0]))
        if scored:
            last_head = scored[0][0]
        ticks = _op_b(len(pulse["intakes"]), stale_pulse, miss_pulse)
        if ticks > int(scene["capacity_budget"]):
            capacity_miss += 1

    priority_probe = _probe_last_pulse_head(scene)
    priority_ok = "yes" if last_head == priority_probe else "no"
    capacity_ok = "yes" if capacity_miss == 0 else "no"
    return {
        "head_admit_id": last_head,
        "capacity_miss_total": capacity_miss,
        "stale_refresh_total": stale_total,
        "priority_ok_flag": priority_ok,
        "capacity_ok_flag": capacity_ok,
    }


def _probe_last_pulse_head(scene: dict) -> str:
    """Lane-normalized priority probe for the final pulse."""
    pulses = scene["pulses"]
    if not pulses:
        return ""
    last = pulses[-1]
    if not last["intakes"]:
        return ""
    table = scene["resource_table"]
    scored: list[tuple[str, float]] = []
    for intake in last["intakes"]:
        key = _fold_key(intake["lane_code"])
        boost = float(table[key]["boost"]) if key in table else 0.0
        score = _wmp(float(intake["acuity_a"]), float(intake["urgency_u"])) + boost
        scored.append((intake["intake_id"], score))
    scored.sort(key=lambda item: (-item[1], item[0]))
    return scored[0][0]


def _wave_labels_sorted() -> list[str]:
    return sorted(json.loads(p.read_text(encoding="utf-8"))["wave_label"] for p in sorted(FIXTURE_DIR.glob("*.json")))


WAVE_LABELS = _wave_labels_sorted()


def _sync_scenarios_from_harness() -> None:
    dest = APP / "data" / "scenarios"
    dest.mkdir(parents=True, exist_ok=True)
    for child in dest.glob("*.json"):
        child.unlink()
    for src in sorted(FIXTURE_DIR.glob("*.json")):
        shutil.copy2(src, dest / src.name)


def _fixture_payloads() -> list[dict]:
    return [json.loads(p.read_text(encoding="utf-8")) for p in sorted(FIXTURE_DIR.glob("*.json"))]


def _expected_by_label() -> dict[str, dict[str, int | str]]:
    return {row["wave_label"]: _reference_row(row) for row in _fixture_payloads()}


def _rebuild_and_run() -> dict:
    _sync_scenarios_from_harness()
    OUT.unlink(missing_ok=True)
    subprocess.run(
        ["bash", "/app/scripts/build_all.sh"],
        cwd=APP,
        check=True,
        env=_SUBPROC_ENV,
        timeout=_BUILD_TIMEOUT_SEC,
    )
    subprocess.run(
        ["/app/bin/surge-alloc"],
        cwd=APP,
        check=True,
        env=_SUBPROC_ENV,
        timeout=_RUN_TIMEOUT_SEC,
    )
    return json.loads(OUT.read_text(encoding="utf-8"))


@pytest.fixture(scope="module")
def report_doc() -> dict:
    return _rebuild_and_run()


@pytest.fixture(scope="module")
def expected_by_label() -> dict[str, dict[str, int | str]]:
    return _expected_by_label()


def test_report_schema_marker(report_doc: dict) -> None:
    """Emitted document carries the instruction schema marker."""

    assert report_doc["schema"] == "surge-alloc-1"
    assert "entries" in report_doc


def test_entry_order_matches_sorted_filenames(report_doc: dict) -> None:
    """Rows follow sorted scenario filenames on disk."""

    got = [entry["wave_label"] for entry in report_doc["entries"]]
    labels = [
        json.loads(p.read_text(encoding="utf-8"))["wave_label"]
        for p in sorted((APP / "data" / "scenarios").glob("*.json"))
    ]
    assert got == labels


@pytest.mark.parametrize("label", WAVE_LABELS)
def test_head_admit_id_matches_reference(
    report_doc: dict,
    expected_by_label: dict[str, dict[str, int | str]],
    label: str,
) -> None:
    """Each replay row head admit column matches priority math."""

    row = next(entry for entry in report_doc["entries"] if entry["wave_label"] == label)
    assert row["head_admit_id"] == expected_by_label[label]["head_admit_id"]


@pytest.mark.parametrize("label", WAVE_LABELS)
def test_capacity_miss_total_matches_reference(
    report_doc: dict,
    expected_by_label: dict[str, dict[str, int | str]],
    label: str,
) -> None:
    """Each replay row capacity miss column matches budget math."""

    row = next(entry for entry in report_doc["entries"] if entry["wave_label"] == label)
    assert row["capacity_miss_total"] == expected_by_label[label]["capacity_miss_total"]


@pytest.mark.parametrize("label", WAVE_LABELS)
def test_stale_refresh_total_matches_reference(
    report_doc: dict,
    expected_by_label: dict[str, dict[str, int | str]],
    label: str,
) -> None:
    """Each replay row stale refresh column matches ledger refresh math."""

    row = next(entry for entry in report_doc["entries"] if entry["wave_label"] == label)
    assert row["stale_refresh_total"] == expected_by_label[label]["stale_refresh_total"]


@pytest.mark.parametrize("label", WAVE_LABELS)
def test_priority_ok_flag_matches_reference(
    report_doc: dict,
    expected_by_label: dict[str, dict[str, int | str]],
    label: str,
) -> None:
    """Each replay row priority_ok_flag matches aggregate priority posture."""

    row = next(entry for entry in report_doc["entries"] if entry["wave_label"] == label)
    assert row["priority_ok_flag"] == expected_by_label[label]["priority_ok_flag"]


@pytest.mark.parametrize("label", WAVE_LABELS)
def test_capacity_ok_flag_matches_reference(
    report_doc: dict,
    expected_by_label: dict[str, dict[str, int | str]],
    label: str,
) -> None:
    """Each replay row capacity_ok_flag matches aggregate capacity posture."""

    row = next(entry for entry in report_doc["entries"] if entry["wave_label"] == label)
    assert row["capacity_ok_flag"] == expected_by_label[label]["capacity_ok_flag"]


def test_catalog_matches_harness_scenarios(
    report_doc: dict, expected_by_label: dict[str, dict[str, int | str]]
) -> None:
    """Report lists every harness scenario exactly once."""

    labels = {entry["wave_label"] for entry in report_doc["entries"]}
    assert labels == set(expected_by_label.keys())
    assert len(report_doc["entries"]) == len(expected_by_label)


def test_harness_extends_shipped_scenario_set() -> None:
    """Grading fixtures include scenarios not copied into the runtime image."""

    shipped = {"steady_pulse.json", "acuity_cross.json", "lane_flip.json", "epoch_rush.json"}
    harness = {path.name for path in FIXTURE_DIR.glob("*.json")}
    assert len(harness) > len(shipped)
    assert harness - shipped


def test_entry_shape_per_row(report_doc: dict) -> None:
    """Each report row exposes the contract fields with string flag tokens."""

    required = {
        "wave_label",
        "head_admit_id",
        "capacity_miss_total",
        "stale_refresh_total",
        "priority_ok_flag",
        "capacity_ok_flag",
    }
    for entry in report_doc["entries"]:
        assert required <= set(entry.keys())
        assert entry["priority_ok_flag"] in {"yes", "no"}
        assert entry["capacity_ok_flag"] in {"yes", "no"}
