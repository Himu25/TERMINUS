During surge conditions the ward operations platform under `/app` emits allocation reports that disagree with pivot spreadsheets built from `/app/data/scenarios/*.json`. Replay rows mismatch on head admit columns, capacity miss totals, stale refresh totals, and the per-wave priority and capacity posture flags.

Rebuild `/app/bin/surge-alloc` from the Go and Rust sources via `/app/scripts/build_all.sh`, regenerate `/app/output/allocation_report.json` per `/app/docs/allocation_contract.md`, and process scenarios in sorted filename order. Grading prepends `/usr/local/go/bin:/app/bin:` to PATH and may substitute an extended scenario catalog beyond the image copy.

Write `/app/output/allocation_report.json` with schema `surge-alloc-1` and an `entries` array. Each entry carries `wave_label`, `head_admit_id`, `capacity_miss_total`, `stale_refresh_total`, `priority_ok_flag` (`yes` or `no`), and `capacity_ok_flag` (`yes` or `no`).

The repaired report should match pivot tables for each scenario capacity budget, resource epoch, pulses, and resource table entries. Signal completion when the report matches.
