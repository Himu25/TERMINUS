module lab.local/vector_shard_mesh

go 1.22
