use std::ffi::CStr;
use std::os::raw::c_char;

fn fold_cell(bytes: &[u8]) -> u32 {
    let mut sum: u32 = 0;
    for b in bytes {
        sum = sum.wrapping_add(u32::from(*b));
    }
    sum
}

/// rl_apply_hold folds ingest hold smear into shard clock skew baseline (milliseconds).
#[no_mangle]
pub extern "C" fn rl_apply_hold(base_ms: i64, hold_ms: i64) -> i64 {
    if hold_ms == 0 {
        return base_ms;
    }
    base_ms + hold_ms
}

/// rl_cell_sig returns the low-latency lane digest for one materialized cell key.
#[no_mangle]
pub extern "C" fn rl_cell_sig(ptr: *const c_char) -> u32 {
    if ptr.is_null() {
        return 0;
    }
    let cstr = unsafe { CStr::from_ptr(ptr) };
    let bytes = cstr.to_bytes();
    bytes.len() as u32
}
