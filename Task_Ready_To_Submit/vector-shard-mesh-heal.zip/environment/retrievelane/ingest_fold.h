#pragma once

long long rl_apply_hold(long long base_ms, long long hold_ms);
unsigned int rl_cell_sig(const char *cell_key);
