package retrievelane

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libretrievelane.a -ldl -lm
#include "ingest_fold.h"
#include <stdlib.h>
*/
import "C"
import "unsafe"

// ApplySmear combines shard clock skew with optional ingest hold smear.
func ApplySmear(baseMS int64, holdMS int64) int64 {
	return int64(C.rl_apply_hold(C.longlong(baseMS), C.longlong(holdMS)))
}

// CellSig reads the hot-lane signature for one cell key string.
func CellSig(cellKey string) int64 {
	cstr := C.CString(cellKey)
	defer C.free(unsafe.Pointer(cstr))
	return int64(C.rl_cell_sig(cstr))
}
