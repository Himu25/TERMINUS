// Report JSON for /app/output/sync_report.json:
//
// schema_version — string, must be "1"
// pack_id — string, echoes active pack name
// vector_dim — unsigned dimensionality declared in shard_pack.json
// material_epoch — highest version epoch in the consistent chain
// replay_seq — highest contiguous sequence included in the chain
// conflict_resolved — integrity repairs applied to winning update groups
// gap_count — sequence positions without shard agreement
// shards_active — count of shards contributing to accepted rows
// missing_recovered — catalog entities restored from pre-watermark valid rows
// retrieval_ok — boolean; hot-lane probes match replay for probe_entities
// skew_band — string, "tight" or "wide"
// sep_clean — boolean (not 0/1 strings)
// digest_hex — lowercase hex SHA-256 of pack_id|vector_dim|material_epoch|replay_seq|conflict_resolved|gap_count|shards_active|missing_recovered|retrieval_ok|skew_band|sep_clean
//
// Replay derives one watermark from the five shard stale_mark values in each shard meta.json; use the lowest mark across the pack.
// At each sequence above that watermark, rows sharing the same version epoch and cell payload form an update group.
// A group is admitted only when it has quorum support within itself: at least q_size distinct shards and at least q_size CRC-valid rows in that same group, where q_size comes from the active pack.
// Sequences with no admitted group increment gap_count. When several groups qualify at one sequence, the winning group is the one whose earliest drift-adjusted write time wins — raw gps_ms minus that shard's effective skew (clock_skew_ms minus any ingest_hold_ms smear).
// conflict_resolved tallies integrity repairs applied only to replicas in the admitted group for each sequence.
// missing_recovered counts catalog entities listed in shard_pack.json that are absent from winning rows but restorable from valid pre-watermark segments.
// retrieval_ok is true when hot-lane signatures match replay for every entity in probe_entities.
//
// Root object contains only these keys.
package main

import (
	"log"
	"os"

	"lab.local/vector_shard_mesh/internal/driver"
)

func main() {
	if os.Getenv("TB_SHARD_FIXTURE") != "1" {
		log.Fatal("TB_SHARD_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/sync_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
