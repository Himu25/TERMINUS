package offsetfold

import "lab.local/vector_shard_mesh/retrievelane"

// FoldUnitSkew applies optional ingest hold smear to the recorded clock skew baseline.
func FoldUnitSkew(skewMS int64, ingestHoldMS int64) int64 {
	return retrievelane.ApplySmear(skewMS, ingestHoldMS)
}
