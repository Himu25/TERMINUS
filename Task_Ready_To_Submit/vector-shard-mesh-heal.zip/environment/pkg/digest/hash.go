package digest

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
)

// ReportHex matches the pipe-separated digest in cmd/shard_sync.
func ReportHex(
	packID string,
	vectorDim, materialEpoch, replaySeq, conflictResolved, gapCount, shardsActive, missingRecovered uint32,
	retrievalOK bool,
	skewBand string,
	sepClean bool,
) string {
	ret := "true"
	if !retrievalOK {
		ret = "false"
	}
	ck := "true"
	if !sepClean {
		ck = "false"
	}
	raw := fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%d|%d|%s|%s|%s",
		packID, vectorDim, materialEpoch, replaySeq, conflictResolved, gapCount, shardsActive, missingRecovered, ret, skewBand, ck,
	)
	sum := sha256.Sum256([]byte(raw))
	return hex.EncodeToString(sum[:])
}
