package version

// ToolingTag is stamped into build metadata.
const ToolingTag = "vect-shard-0.9"
