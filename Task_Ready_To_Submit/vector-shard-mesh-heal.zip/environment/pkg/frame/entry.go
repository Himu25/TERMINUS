package frame

// Row is one append-only replication line from a shard segment.
type Row struct {
	Seq     uint32 `json:"seq"`
	Epoch   uint32 `json:"epoch"`
	WallMS  int64  `json:"gps_ms"`
	Payload string `json:"payload"`
	CRC     uint16 `json:"crc"`
	Site    string `json:"site"`
}
