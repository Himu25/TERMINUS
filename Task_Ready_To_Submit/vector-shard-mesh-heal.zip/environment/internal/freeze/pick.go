package freeze

import (
	"lab.local/vector_shard_mesh/pkg/markfold"
	"lab.local/vector_shard_mesh/pkg/unit"
)

// Watermark collects partition marks from profiles.
func Watermark(profiles []unit.Profile) int64 {
	marks := make([]int64, 0, len(profiles))
	for _, p := range profiles {
		marks = append(marks, int64(p.StaleMark))
	}
	return markfold.OpW(marks)
}
