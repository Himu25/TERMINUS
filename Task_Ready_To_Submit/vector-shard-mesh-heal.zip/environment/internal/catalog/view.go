package catalog

// PackView is the replay-facing subset of a loaded shard pack.
type PackView struct {
	PackID        string
	QSize         int
	SepEpoch      uint32
	SkewTightMS   int64
	VectorDim     uint32
	Catalog       []string
	ProbeEntities []string
}
