package catalog

import (
	"strings"

	"lab.local/vector_shard_mesh/internal/crc"
	"lab.local/vector_shard_mesh/pkg/frame"
)

// EntityFromCell splits an entity prefix from a cell key payload.
func EntityFromCell(cellKey string) string {
	if i := strings.IndexByte(cellKey, ':'); i >= 0 {
		return cellKey[:i]
	}
	return cellKey
}

// CountMissingRecovered tallies catalog entities absent from winners but restorable below watermark.
func CountMissingRecovered(
	catalog []string,
	watermark uint32,
	winners map[string]struct{},
	allRows map[uint32][]frame.Row,
) uint32 {
	if len(catalog) == 0 {
		return 0
	}
	var recovered uint32
	for _, ent := range catalog {
		if _, ok := winners[ent]; ok {
			continue
		}
		found := false
		for seq := uint32(1); seq <= watermark; seq++ {
			for _, row := range allRows[seq] {
				if EntityFromCell(row.Payload) != ent {
					continue
				}
				if !crc.OpValid(row.Seq, row.Payload, row.CRC) {
					continue
				}
				found = true
				break
			}
			if found {
				break
			}
		}
		if found {
			recovered++
		}
	}
	return recovered
}

// WinnerEntities collects entity prefixes present in accepted winning payloads.
func WinnerEntities(accepted map[uint32]string) map[string]struct{} {
	out := make(map[string]struct{}, len(accepted))
	for _, cell := range accepted {
		out[EntityFromCell(cell)] = struct{}{}
	}
	return out
}
