package engine

import (
	"lab.local/vector_shard_mesh/internal/catalog"
	"lab.local/vector_shard_mesh/internal/fastlane"
	"lab.local/vector_shard_mesh/internal/freeze"
	"lab.local/vector_shard_mesh/internal/merge"
	"lab.local/vector_shard_mesh/pkg/frame"
	"lab.local/vector_shard_mesh/pkg/unit"
)

// Replay executes one pack through freeze and merge stages.
func Replay(
	pack catalog.PackView,
	profiles []unit.Profile,
	allRows map[uint32][]frame.Row,
	offsets map[string]int64,
) merge.Outcome {
	wm := freeze.Watermark(profiles)
	above := make(map[uint32][]frame.Row)
	for seq, rows := range allRows {
		if seq > uint32(wm) {
			above[seq] = rows
		}
	}
	out := merge.FusePack(uint32(wm), pack.QSize, pack.SepEpoch, pack.SkewTightMS, offsets, above, allRows)
	winners := catalog.WinnerEntities(out.WinCells)
	out.MissingRecovered = catalog.CountMissingRecovered(pack.Catalog, uint32(wm), winners, allRows)
	out.RetrievalOK = probeRetrieval(pack.ProbeEntities, out.WinCells)
	_ = pack.PackID
	return out
}

func probeRetrieval(probes []string, winCells map[uint32]string) bool {
	if len(probes) == 0 {
		return true
	}
	latest := latestCells(winCells)
	for _, ent := range probes {
		cell, ok := latest[ent]
		if !ok {
			cell = ent
		}
		if !fastlane.ProbeOK(cell) {
			return false
		}
	}
	return true
}

func latestCells(winCells map[uint32]string) map[string]string {
	out := make(map[string]string)
	bestSeq := make(map[string]uint32)
	for seq, cell := range winCells {
		ent := catalog.EntityFromCell(cell)
		if prev, ok := bestSeq[ent]; !ok || seq > prev {
			bestSeq[ent] = seq
			out[ent] = cell
		}
	}
	return out
}
