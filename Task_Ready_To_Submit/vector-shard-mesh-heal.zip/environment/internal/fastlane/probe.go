package fastlane

import (
	"lab.local/vector_shard_mesh/pkg/frame"
	"lab.local/vector_shard_mesh/retrievelane"
)

// ProbeOK checks the low-latency lane signature against replay-derived material.
func ProbeOK(cellKey string) bool {
	want := uint32(frame.WireCRC(0, cellKey))
	got := uint32(retrievelane.CellSig(cellKey))
	return want == got
}
