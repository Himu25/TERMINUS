package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"

	"lab.local/vector_shard_mesh/internal/catalog"
	"lab.local/vector_shard_mesh/internal/config"
	"lab.local/vector_shard_mesh/internal/engine"
)

// Report is the outward JSON envelope.
type Report struct {
	SchemaVersion    string `json:"schema_version"`
	PackID           string `json:"pack_id"`
	VectorDim        uint32 `json:"vector_dim"`
	MaterialEpoch    uint32 `json:"material_epoch"`
	ReplaySeq        uint32 `json:"replay_seq"`
	ConflictResolved uint32 `json:"conflict_resolved"`
	GapCount         uint32 `json:"gap_count"`
	ShardsActive     uint32 `json:"shards_active"`
	MissingRecovered uint32 `json:"missing_recovered"`
	RetrievalOK      bool   `json:"retrieval_ok"`
	SkewBand         string `json:"skew_band"`
	SepClean         bool   `json:"sep_clean"`
	DigestHex        string `json:"digest_hex"`
}

// RunActive loads the active pack and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	pack, profiles, rows, offsets, err := config.LoadPack(dir)
	if err != nil {
		return Report{}, err
	}
	view := catalog.PackView{
		PackID:        pack.PackID,
		QSize:         pack.QSize,
		SepEpoch:      pack.SepEpoch,
		SkewTightMS:   pack.SkewTightMS,
		VectorDim:     pack.VectorDim,
		Catalog:       pack.Catalog,
		ProbeEntities: pack.ProbeEntities,
	}
	out := engine.Replay(view, profiles, rows, offsets)
	ck := "true"
	if !out.SepClean {
		ck = "false"
	}
	ret := "true"
	if !out.RetrievalOK {
		ret = "false"
	}
	digest := sha256.Sum256([]byte(fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%d|%d|%s|%s|%s",
		pack.PackID,
		pack.VectorDim,
		out.MaterialEpoch,
		out.ReplaySeq,
		out.ConflictResolved,
		out.GapCount,
		out.ShardsActive,
		out.MissingRecovered,
		ret,
		out.SkewBand,
		ck,
	)))
	return Report{
		SchemaVersion:    "1",
		PackID:           pack.PackID,
		VectorDim:        pack.VectorDim,
		MaterialEpoch:    out.MaterialEpoch,
		ReplaySeq:        out.ReplaySeq,
		ConflictResolved: out.ConflictResolved,
		GapCount:         out.GapCount,
		ShardsActive:     out.ShardsActive,
		MissingRecovered: out.MissingRecovered,
		RetrievalOK:      out.RetrievalOK,
		SkewBand:         out.SkewBand,
		SepClean:         out.SepClean,
		DigestHex:        hex.EncodeToString(digest[:]),
	}, nil
}
