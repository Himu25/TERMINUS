Ingest hold smear folds into shard clock skew baselines when packs load. Hold windows are declared per-shard in meta.json as ingest_hold_ms.
