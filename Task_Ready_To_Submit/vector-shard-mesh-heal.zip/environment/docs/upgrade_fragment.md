# Upgrade fragment

2024-07: write-time tie ordering now references drift-adjusted timestamps from shard meta profiles.

2024-11: ingest hold windows affect folded clock skew baselines when packs load.
