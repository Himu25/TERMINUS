# Mesh layout

Five shards (`n1`–`n5`) append materialized cell rows under `/app/data/active/shards/`.
Each shard carries `clock_skew_ms`, optional `ingest_hold_ms`, and a `stale_mark` watermark in `meta.json`.
The active pack lists `catalog` entities that may be recovered from pre-watermark segments and `probe_entities` checked against the hot-lane path.
