Operator tools live outside the sync driver; use /app/bin/shard_sync for pack replay.
The digest_cli helper under /app/tools/digest_cli supports digest recomputation from report fields.
