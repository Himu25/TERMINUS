package main

import (
	"fmt"
	"os"
	"strconv"

	"lab.local/vector_shard_mesh/pkg/digest"
)

func main() {
	if len(os.Args) < 12 {
		fmt.Fprintln(os.Stderr, "usage: digest_cli pack vector_dim material replay conflict gap shards missing retrieval skew sep")
		os.Exit(2)
	}
	vectorDim, _ := strconv.ParseUint(os.Args[2], 10, 32)
	material, _ := strconv.ParseUint(os.Args[3], 10, 32)
	replay, _ := strconv.ParseUint(os.Args[4], 10, 32)
	conflict, _ := strconv.ParseUint(os.Args[5], 10, 32)
	gap, _ := strconv.ParseUint(os.Args[6], 10, 32)
	shards, _ := strconv.ParseUint(os.Args[7], 10, 32)
	missing, _ := strconv.ParseUint(os.Args[8], 10, 32)
	retrieval := os.Args[9] == "true"
	clean := os.Args[11] == "true"
	fmt.Print(digest.ReportHex(
		os.Args[1],
		uint32(vectorDim),
		uint32(material),
		uint32(replay),
		uint32(conflict),
		uint32(gap),
		uint32(shards),
		uint32(missing),
		retrieval,
		os.Args[10],
		clean,
	))
}
