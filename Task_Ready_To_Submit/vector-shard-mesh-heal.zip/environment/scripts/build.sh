#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/app/output/cargo-target}"

mkdir -p /app/bin /app/output/cargo-target /app/retrievelane/target/release
cd /app/retrievelane
cargo build --release --locked
install -m 0644 "${CARGO_TARGET_DIR}/release/libretrievelane.a" /app/retrievelane/target/release/libretrievelane.a
cd /app
GOFLAGS=-mod=mod go build -trimpath -buildvcs=false -o /app/bin/shard_sync ./cmd/shard_sync
