"""Verifier for distributed feature-shard synchronization report."""

import json
import os
import shutil
import subprocess
import tempfile

import pytest
from collections import defaultdict
from pathlib import Path

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = Path(__file__).resolve().parent / "fixtures"
OUT = APP / "output" / "sync_report.json"
GO_BIN = "/usr/local/go/bin/go"
VERIFY_BIN = os.path.join(tempfile.gettempdir(), "ss_verify")


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)
    subprocess.run(["cp", "/app/bin/shard_sync", VERIFY_BIN], check=True)


def _entity(cell_key: str) -> str:
    if ":" in cell_key:
        return cell_key.split(":", 1)[0]
    return cell_key


def _digest_hex(
    pack_id: str,
    vector_dim: int,
    material_epoch: int,
    replay_seq: int,
    repair: int,
    loss: int,
    shards_active: int,
    missing: int,
    retrieval_ok: bool,
    drift: str,
    sep_clean: bool,
) -> str:
    ck = "true" if sep_clean else "false"
    ret = "true" if retrieval_ok else "false"
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            pack_id,
            str(vector_dim),
            str(material_epoch),
            str(replay_seq),
            str(repair),
            str(loss),
            str(shards_active),
            str(missing),
            ret,
            drift,
            ck,
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _crc16(seq: int, payload: str) -> int:
    s = sum(payload.encode()) & 0xFFFFFFFF
    return (s ^ seq) & 0xFFFF


def _missing_recovered(catalog: list[str], watermark: int, win_cells: dict[int, str], all_rows: dict[int, list]) -> int:
    winners = {_entity(cell) for cell in win_cells.values()}
    recovered = 0
    for ent in catalog:
        if ent in winners:
            continue
        found = False
        for seq in range(1, watermark + 1):
            for entry in all_rows.get(seq, []):
                if _entity(entry["payload"]) != ent:
                    continue
                if _crc16(entry["seq"], entry["payload"]) == entry["crc"]:
                    found = True
                    break
            if found:
                break
        if found:
            recovered += 1
    return recovered


def _retrieval_ok(probes: list[str], win_cells: dict[int, str]) -> bool:
    """Oracle replay with repaired hot-lane always satisfies probe_entities."""
    _ = (probes, win_cells)
    return True


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = FIXTURES / pack_name
    pack = json.loads((pack_dir / "shard_pack.json").read_text())
    q = pack["q_size"]
    sep_epoch = pack["sep_epoch"]
    drift_tight = pack["skew_tight_ms"]
    offsets: dict[str, int] = {}
    freezes: list[int] = []
    rows: list[dict] = []
    for mid in pack["shards"]:
        meta = json.loads((pack_dir / "shards" / mid / "meta.json").read_text())
        hold = int(meta.get("ingest_hold_ms", 0))
        offsets[mid] = int(meta["clock_skew_ms"]) - hold
        freezes.append(meta["stale_mark"])
        seg = pack_dir / "shards" / mid / "seg_001.jsonl"
        if not seg.exists():
            continue
        for line in seg.read_text().splitlines():
            if not line.strip():
                continue
            entry = json.loads(line)
            entry["site"] = mid
            rows.append(entry)
    wm = min(freezes) if freezes else 0
    by_seq: dict[int, list] = defaultdict(list)
    all_rows: dict[int, list] = defaultdict(list)
    for entry in rows:
        all_rows[entry["seq"]].append(entry)
        if entry["seq"] > wm:
            by_seq[entry["seq"]].append(entry)
    accepted: dict[int, int] = {}
    win_cells: dict[int, str] = {}
    repair = 0
    loss = 0
    live: set[str] = set()
    sep_clean = True
    for seq in sorted(by_seq):
        buckets: dict[tuple, list] = defaultdict(list)
        for entry in by_seq[seq]:
            buckets[(entry["epoch"], entry["payload"])].append(entry)
        picked = None
        best_adj = None
        for key, items in buckets.items():
            if len({it["site"] for it in items}) < q:
                continue
            valid = [it for it in items if _crc16(it["seq"], it["payload"]) == it["crc"]]
            if len(valid) < q:
                continue
            adj = min(it["gps_ms"] - offsets[it["site"]] for it in valid)
            if picked is None or adj < best_adj:
                picked, best_adj = key, adj
        if picked is None:
            loss += 1
            continue
        items = buckets[picked]
        repair += sum(1 for it in items if _crc16(it["seq"], it["payload"]) != it["crc"])
        epoch = picked[0]
        valid = [it for it in items if _crc16(it["seq"], it["payload"]) == it["crc"]]
        if epoch > sep_epoch and len({it["site"] for it in valid}) < q:
            sep_clean = False
        for it in valid:
            live.add(it["site"])
        accepted[seq] = epoch
        win_cells[seq] = picked[1]
    replay_seq = 0
    s = 1
    while True:
        if s <= wm or s in accepted:
            replay_seq = s
            s += 1
        else:
            break
    material_epoch = 0
    for seq, seq_rows in all_rows.items():
        if seq > replay_seq:
            continue
        for entry in seq_rows:
            if seq in accepted and entry["epoch"] == accepted[seq]:
                if _crc16(entry["seq"], entry["payload"]) == entry["crc"] and entry["epoch"] > material_epoch:
                    material_epoch = entry["epoch"]
            elif seq <= wm and entry["epoch"] > material_epoch:
                material_epoch = entry["epoch"]
    spread = max(offsets.values()) - min(offsets.values())
    drift = "tight" if spread <= drift_tight else "wide"
    missing = _missing_recovered(pack.get("catalog", []), wm, win_cells, all_rows)
    retrieval_ok = _retrieval_ok(pack.get("probe_entities", []), win_cells)
    digest = _digest_hex(
        pack["pack_id"],
        pack["vector_dim"],
        material_epoch,
        replay_seq,
        repair,
        loss,
        len(live),
        missing,
        retrieval_ok,
        drift,
        sep_clean,
    )
    return {
        "schema_version": "1",
        "pack_id": pack["pack_id"],
        "vector_dim": pack["vector_dim"],
        "material_epoch": material_epoch,
        "replay_seq": replay_seq,
        "conflict_resolved": repair,
        "gap_count": loss,
        "shards_active": len(live),
        "missing_recovered": missing,
        "retrieval_ok": retrieval_ok,
        "skew_band": drift,
        "sep_clean": sep_clean,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_SHARD_FIXTURE": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_alpha_report_matches_quorum_replay() -> None:
    """Alpha pack should reach tight skew band with catalog recovery and hot-lane probes."""
    _swap("shard_alpha")
    exp = _expected_from_fixture("shard_alpha")
    got = _run_tool()
    assert got == exp


def test_beta_report_matches_quorum_replay() -> None:
    """Beta pack applies ingest hold smear when folding shard skew for replay."""
    _swap("shard_beta")
    exp = _expected_from_fixture("shard_beta")
    got = _run_tool()
    assert got == exp


def test_gamma_loss_after_lone_epoch() -> None:
    """Gamma stops the chain when only one shard carries a high material row."""
    _swap("shard_gamma")
    exp = _expected_from_fixture("shard_gamma")
    got = _run_tool()
    assert got["gap_count"] == exp["gap_count"]
    assert got["replay_seq"] == exp["replay_seq"]


def test_delta_high_gap_count() -> None:
    """Delta orphan high sequence should not extend the global chain."""
    _swap("shard_delta")
    exp = _expected_from_fixture("shard_delta")
    got = _run_tool()
    assert got["gap_count"] == exp["gap_count"]
    assert got["replay_seq"] == exp["replay_seq"]


def test_epsilon_conflict_resolved_nonzero() -> None:
    """Epsilon should count one integrity repair on the winning update group."""
    _swap("shard_epsilon")
    exp = _expected_from_fixture("shard_epsilon")
    got = _run_tool()
    assert got["conflict_resolved"] == exp["conflict_resolved"]
    assert got["replay_seq"] == exp["replay_seq"]


def test_zeta_replay_seq_watermark() -> None:
    """Alpha stale watermark must use the minimum mark, not the maximum."""
    _swap("shard_alpha")
    exp = _expected_from_fixture("shard_alpha")
    got = _run_tool()
    assert got["replay_seq"] == exp["replay_seq"]


def test_alpha_missing_recovered_catalog() -> None:
    """Alpha catalog entity ghost_ent must restore from pre-watermark valid rows."""
    _swap("shard_alpha")
    exp = _expected_from_fixture("shard_alpha")
    got = _run_tool()
    assert got["missing_recovered"] == exp["missing_recovered"]
    assert got["missing_recovered"] >= 1


def test_beta_retrieval_lane_ok() -> None:
    """Beta probe_entities must report retrieval_ok true after hot-lane repair."""
    _swap("shard_beta")
    exp = _expected_from_fixture("shard_beta")
    got = _run_tool()
    assert got["retrieval_ok"] is True
    assert got["retrieval_ok"] == exp["retrieval_ok"]


def test_go_subsystem_tests_pass() -> None:
    """Go unit tests under /app must pass after the repair."""
    subprocess.run(
        [GO_BIN, "test", "./..."],
        cwd="/app",
        env={
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        },
        check=True,
    )
