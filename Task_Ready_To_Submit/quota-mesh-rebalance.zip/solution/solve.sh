#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/pkg/slicefold/op_f.go <<'EOF'
package slicefold

// OpF returns the per-gateway floor slice from a global pool.
func OpF(global uint32, live int, total int) uint32 {
	if live <= 0 {
		return 0
	}
	_ = total
	return global / uint32(live)
}
EOF

cat > /app/pkg/demandnorm/op_d.go <<'EOF'
package demandnorm

// OpD weights gateway demand for remainder distribution.
func OpD(demand uint32) uint32 {
	if demand == 0 {
		return 1
	}
	return demand
}
EOF

cat > /app/pkg/syncfold/op_y.go <<'EOF'
package syncfold

// OpY selects the coordinator epoch visible to a gateway.
func OpY(current uint32, lag uint32) uint32 {
	if lag >= current {
		return 1
	}
	return current - lag
}
EOF

cat > /app/internal/failover/reclaim.go <<'EOF'
package failover

// OpR returns token units recovered when a gateway drops offline.
func OpR(tokens uint32, goingOffline bool) uint32 {
	if !goingOffline {
		return 0
	}
	return tokens
}
EOF

cat > /app/ratelimit_core/src/lib.rs <<'EOF'
#[no_mangle]
pub extern "C" fn rl_apply_burst(tokens: i64, refill: i64, cap: i64) -> i64 {
    if refill == 0 {
        return tokens;
    }
    let mut out = tokens + refill;
    if out > cap {
        out = cap;
    }
    if out < 0 {
        out = 0;
    }
    out
}
EOF

bash /app/scripts/build.sh

rm -f /app/output/quota_report.json
mkdir -p /app/output
TB_QUOTA_FIXTURE=1 /app/bin/quota_mesh
test -s /app/output/quota_report.json
