"""Verifier for distributed quota mesh rebalance report."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = Path("/tests") / "fixtures"
OUT = APP / "output" / "quota_report.json"
VERIFY_BIN = "/app/bin/quota_mesh"
GO_BIN = "go"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _digest_hex(
    mesh_id: str,
    epochs_run: int,
    admitted: int,
    starved: int,
    waste: int,
    fairness: str,
    burst: int,
    failover: int,
    sync_skew: int,
    nodes_live: int,
) -> str:
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            mesh_id,
            str(epochs_run),
            str(admitted),
            str(starved),
            str(waste),
            fairness,
            str(burst),
            str(failover),
            str(sync_skew),
            str(nodes_live),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _op_f(global_q: int, live: int, total: int) -> int:
    if live <= 0:
        return 0
    return global_q // live


def _op_d(demand: int) -> int:
    return demand if demand > 0 else 1


def _op_y(current: int, lag: int) -> int:
    if lag >= current:
        return 1
    return current - lag


def _op_l(epoch: int, offline_at: int) -> bool:
    if offline_at == 0:
        return True
    return epoch < offline_at


def _apply_burst(tokens: int, refill: int, cap: int) -> int:
    if refill == 0:
        return tokens
    out = tokens + refill
    if out > cap:
        out = cap
    return max(0, out)


def _reclaim_offline(tokens: int, going_offline: bool) -> int:
    return tokens if going_offline else 0


def _lag_sum(mesh_lag: int, region_lag: int) -> int:
    return mesh_lag + region_lag


def _demand_at(rows: list[dict], node_id: str) -> int:
    for row in rows:
        if row["node_id"] == node_id:
            return int(row["demand"])
    return 0


def _load_fixture(pack_name: str) -> tuple[dict, list[dict], list[dict]]:
    pack_dir = FIXTURES / pack_name
    plan = json.loads((pack_dir / "mesh_plan.json").read_text())
    profiles: list[dict] = []
    rows: list[dict] = []
    for rid in plan["regions"]:
        meta = json.loads((pack_dir / "regions" / rid / "region_meta.json").read_text())
        profiles.append(meta)
        seg = pack_dir / "regions" / rid / "shard_001.jsonl"
        if not seg.exists():
            continue
        for line in seg.read_text().splitlines():
            if not line.strip():
                continue
            entry = json.loads(line)
            entry["region"] = rid
            rows.append(entry)
    return plan, profiles, rows


def _expected_from_fixture(pack_name: str) -> dict:
    plan, profiles, rows = _load_fixture(pack_name)
    region_lag = {p["region_id"]: int(p.get("sync_lag_epochs", 0)) for p in profiles}
    offline_at = {p["region_id"]: int(p.get("offline_epoch", 0)) for p in profiles}
    nodes: dict[str, list] = {}
    max_epoch = 0
    by_epoch: dict[int, list[dict]] = {}
    for row in rows:
        ep = int(row["epoch"])
        by_epoch.setdefault(ep, []).append(row)
        max_epoch = max(max_epoch, ep)
        if row["node_id"] not in nodes:
            nodes[row["node_id"]] = [
                offline_at[row["region"]],
                region_lag[row["region"]],
                0,
                0,
                False,
                0,
            ]
        if ep == int(plan["base_epoch"]):
            nodes[row["node_id"]][2] = int(row["demand"])

    admitted_total = 0
    starved_total = 0
    waste_units = 0
    burst_absorbed = 0
    failover_reclaims = 0
    sync_skew_epochs = 0
    slice_hist: dict[int, dict[str, int]] = {}

    for epoch in range(1, max_epoch + 1):
        live_ids = sorted(nid for nid, st in nodes.items() if _op_l(epoch, st[0]))
        for st in nodes.values():
            live = _op_l(epoch, st[0])
            if not live and st[4]:
                failover_reclaims += _reclaim_offline(st[3], True)
                st[3] = 0
            st[4] = live

        base = _op_f(int(plan["global_quota"]), len(live_ids), int(plan["node_total"]))
        grants = {nid: base for nid in live_ids}
        remainder = int(plan["global_quota"]) - base * len(live_ids)
        if remainder > 0 and live_ids:
            weights = sorted(
                ((nid, _op_d(_demand_at(by_epoch.get(epoch, []), nid))) for nid in live_ids),
                key=lambda x: (-x[1], x[0]),
            )
            for i in range(min(remainder, len(weights))):
                grants[weights[i][0]] += 1
        slice_hist[epoch] = dict(grants)

        for nid in live_ids:
            st = nodes[nid]
            lag = _lag_sum(int(plan["sync_delay_epochs"]), st[1])
            view_epoch = _op_y(epoch, lag)
            live_grant = grants[nid]
            view_grant = slice_hist.get(view_epoch, {}).get(nid, live_grant)
            if view_epoch != epoch and view_grant != live_grant:
                sync_skew_epochs += 1

            st[3] = _apply_burst(st[3], int(plan["burst_refill"]), int(plan["burst_cap"]))
            st[3] += view_grant
            demand = _demand_at(by_epoch.get(epoch, []), nid)
            admit = min(demand, st[3])
            st[3] -= admit
            admitted_total += admit
            if demand > admit:
                starved_total += demand - admit
            if view_grant > admit:
                waste_units += view_grant - admit
            st[5] += admit
            if demand > st[2] > 0:
                base_admit = min(st[2], admit)
                if admit > base_admit:
                    burst_absorbed += admit - base_admit

    nodes_live = sum(1 for st in nodes.values() if _op_l(max_epoch, st[0]))
    admits = [st[5] for st in nodes.values() if st[5] > 0]
    if len(admits) < 2:
        fairness = "yes"
    else:
        mn, mx = min(admits), max(admits)
        fairness = "yes" if mx == 0 or mn * 2 >= mx else "no"

    rep = {
        "schema_version": "1",
        "mesh_id": plan["mesh_id"],
        "epochs_run": max_epoch,
        "admitted_total": admitted_total,
        "starved_total": starved_total,
        "waste_units": waste_units,
        "fairness_ok_flag": fairness,
        "burst_absorbed": burst_absorbed,
        "failover_reclaims": failover_reclaims,
        "sync_skew_epochs": sync_skew_epochs,
        "nodes_live": nodes_live,
    }
    rep["digest_hex"] = _digest_hex(
        rep["mesh_id"],
        rep["epochs_run"],
        rep["admitted_total"],
        rep["starved_total"],
        rep["waste_units"],
        rep["fairness_ok_flag"],
        rep["burst_absorbed"],
        rep["failover_reclaims"],
        rep["sync_skew_epochs"],
        rep["nodes_live"],
    )
    return rep


def _swap_active(pack_name: str) -> None:
    src = FIXTURES / pack_name
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_driver() -> dict:
    OUT.unlink(missing_ok=True)
    env = {**os.environ, "TB_QUOTA_FIXTURE": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    return json.loads(OUT.read_text())


PACKS = ["mesh_alpha", "mesh_beta", "mesh_gamma", "mesh_delta", "mesh_epsilon"]


class TestQuotaMeshRebalance:
    """Quota mesh replay report checks."""

    def test_active_alpha_report(self) -> None:
        """Active catalog matches alpha stem expectations."""
        _swap_active("mesh_alpha")
        expected = _expected_from_fixture("mesh_alpha")
        got = _run_driver()
        for key, val in expected.items():
            assert got[key] == val, f"alpha {key}: got {got[key]!r} want {val!r}"

    def test_beta_burst_traffic(self) -> None:
        """Burst stem replays with absorbed spike volume."""
        _swap_active("mesh_beta")
        expected = _expected_from_fixture("mesh_beta")
        got = _run_driver()
        assert got["burst_absorbed"] == expected["burst_absorbed"]
        assert got["starved_total"] == expected["starved_total"]
        assert got["digest_hex"] == expected["digest_hex"]

    def test_gamma_node_failure(self) -> None:
        """Offline stem reclaims stranded tokens and raises live slice."""
        _swap_active("mesh_gamma")
        expected = _expected_from_fixture("mesh_gamma")
        got = _run_driver()
        assert got["failover_reclaims"] == expected["failover_reclaims"]
        assert got["nodes_live"] == expected["nodes_live"]
        assert got["waste_units"] == expected["waste_units"]
        assert got["digest_hex"] == expected["digest_hex"]

    def test_delta_delayed_sync(self) -> None:
        """Lag stem counts epochs with stale coordinator slices."""
        _swap_active("mesh_delta")
        expected = _expected_from_fixture("mesh_delta")
        got = _run_driver()
        assert got["sync_skew_epochs"] == expected["sync_skew_epochs"]
        assert got["sync_skew_epochs"] > 0
        assert got["failover_reclaims"] == expected["failover_reclaims"]
        assert got["digest_hex"] == expected["digest_hex"]

    def test_epsilon_combined_stress(self) -> None:
        """Combined stem balances burst, failover, and lag."""
        _swap_active("mesh_epsilon")
        expected = _expected_from_fixture("mesh_epsilon")
        got = _run_driver()
        assert got == expected

    def test_schema_keys_only(self) -> None:
        """Outward JSON carries only documented keys."""
        _swap_active("mesh_alpha")
        got = _run_driver()
        allowed = {
            "schema_version",
            "mesh_id",
            "epochs_run",
            "admitted_total",
            "starved_total",
            "waste_units",
            "fairness_ok_flag",
            "burst_absorbed",
            "failover_reclaims",
            "sync_skew_epochs",
            "nodes_live",
            "digest_hex",
        }
        assert set(got.keys()) == allowed

    def test_fairness_flag_values(self) -> None:
        """Fairness flag is yes or no across stems."""
        for pack in PACKS:
            _swap_active(pack)
            got = _run_driver()
            assert got["fairness_ok_flag"] in ("yes", "no")

    def test_admitted_nonzero_alpha(self) -> None:
        """Steady stem admits traffic."""
        _swap_active("mesh_alpha")
        got = _run_driver()
        assert got["admitted_total"] > 0

    def test_binary_exists(self) -> None:
        """Driver binary is present at the documented path."""
        assert Path(VERIFY_BIN).is_file()

    def test_fixture_index_stems(self) -> None:
        """Listed regression stems exist under harness fixtures."""
        index = (APP / "docs" / "fixture_index.txt").read_text().splitlines()
        stems = [line.strip() for line in index if line.strip()]
        for stem in stems:
            assert (FIXTURES / stem / "mesh_plan.json").is_file()
