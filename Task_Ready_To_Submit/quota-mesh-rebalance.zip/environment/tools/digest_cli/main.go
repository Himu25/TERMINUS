package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
)

func main() {
	if len(os.Args) != 11 {
		fmt.Fprintln(os.Stderr, "usage: digest_cli mesh_id epochs admitted starved waste fairness burst failover sync nodes")
		os.Exit(2)
	}
	payload := fmt.Sprintf(
		"%s|%s|%s|%s|%s|%s|%s|%s|%s|%s",
		os.Args[1], os.Args[2], os.Args[3], os.Args[4], os.Args[5],
		os.Args[6], os.Args[7], os.Args[8], os.Args[9], os.Args[10],
	)
	sum := sha256.Sum256([]byte(payload))
	fmt.Println(hex.EncodeToString(sum[:]))
}
