Digest helper for quota report fingerprinting at /app/tools/digest_cli.
