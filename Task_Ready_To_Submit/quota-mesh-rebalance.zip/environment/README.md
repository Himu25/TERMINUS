# Quota mesh rebalance

Regional inference gateways share a coordinator-issued slice pool. Replay
driver lives under `cmd/quota_mesh`; allotment folding is in `internal/merge`.

Build with `scripts/build.sh`. Active catalog under `data/active`.
