package demandnorm

// OpD weights gateway demand for remainder distribution.
func OpD(demand uint32) uint32 {
	_ = demand
	return 1
}
