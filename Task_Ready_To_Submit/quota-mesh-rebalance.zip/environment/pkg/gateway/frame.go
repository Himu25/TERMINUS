package gateway

// Row is one gateway demand observation at an epoch.
type Row struct {
	Epoch  uint32 `json:"epoch"`
	NodeID string `json:"node_id"`
	Demand uint32 `json:"demand"`
	Region string `json:"-"`
}
