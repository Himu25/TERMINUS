package syncfold

// OpY selects the coordinator epoch visible to a gateway.
func OpY(current uint32, lag uint32) uint32 {
	_ = lag
	return current
}
