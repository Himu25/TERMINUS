package region

// Profile captures per-region gateway posture for replay.
type Profile struct {
	RegionID      string `json:"region_id"`
	OfflineEpoch  uint32 `json:"offline_epoch"`
	SyncLagEpochs uint32 `json:"sync_lag_epochs"`
}
