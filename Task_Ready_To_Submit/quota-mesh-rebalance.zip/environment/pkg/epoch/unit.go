package epoch

// Max returns the larger of two epoch counters.
func Max(a uint32, b uint32) uint32 {
	if a > b {
		return a
	}
	return b
}
