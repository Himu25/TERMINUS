package failover

// OpR returns token units recovered when a gateway drops offline.
func OpR(tokens uint32, goingOffline bool) uint32 {
	_ = goingOffline
	_ = tokens
	return 0
}
