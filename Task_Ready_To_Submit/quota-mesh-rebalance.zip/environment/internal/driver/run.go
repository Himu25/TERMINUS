package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"

	"lab.local/quota_mesh_rebalance/internal/config"
	"lab.local/quota_mesh_rebalance/internal/engine"
)

// Report is the outward JSON document.
type Report struct {
	SchemaVersion    string `json:"schema_version"`
	MeshID           string `json:"mesh_id"`
	EpochsRun        uint32 `json:"epochs_run"`
	AdmittedTotal    uint32 `json:"admitted_total"`
	StarvedTotal     uint32 `json:"starved_total"`
	WasteUnits       uint32 `json:"waste_units"`
	FairnessOKFlag   string `json:"fairness_ok_flag"`
	BurstAbsorbed    uint32 `json:"burst_absorbed"`
	FailoverReclaims uint32 `json:"failover_reclaims"`
	SyncSkewEpochs   uint32 `json:"sync_skew_epochs"`
	NodesLive        uint32 `json:"nodes_live"`
	DigestHex        string `json:"digest_hex"`
}

// RunActive loads the active mesh plan and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	plan, profiles, rows, err := config.LoadPlan(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(plan, profiles, rows)
	digest := sha256.Sum256([]byte(fmt.Sprintf(
		"%s|%d|%d|%d|%d|%s|%d|%d|%d|%d",
		plan.MeshID,
		out.EpochsRun,
		out.AdmittedTotal,
		out.StarvedTotal,
		out.WasteUnits,
		out.FairnessOKFlag,
		out.BurstAbsorbed,
		out.FailoverReclaims,
		out.SyncSkewEpochs,
		out.NodesLive,
	)))
	return Report{
		SchemaVersion:    "1",
		MeshID:           plan.MeshID,
		EpochsRun:        out.EpochsRun,
		AdmittedTotal:    out.AdmittedTotal,
		StarvedTotal:     out.StarvedTotal,
		WasteUnits:       out.WasteUnits,
		FairnessOKFlag:   out.FairnessOKFlag,
		BurstAbsorbed:    out.BurstAbsorbed,
		FailoverReclaims: out.FailoverReclaims,
		SyncSkewEpochs:   out.SyncSkewEpochs,
		NodesLive:        out.NodesLive,
		DigestHex:        hex.EncodeToString(digest[:]),
	}, nil
}
