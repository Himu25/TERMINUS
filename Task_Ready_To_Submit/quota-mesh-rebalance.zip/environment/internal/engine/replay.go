package engine

import (
	"lab.local/quota_mesh_rebalance/internal/config"
	"lab.local/quota_mesh_rebalance/internal/merge"
	"lab.local/quota_mesh_rebalance/pkg/gateway"
	"lab.local/quota_mesh_rebalance/pkg/region"
)

// Replay executes one mesh plan through the allotment stage.
func Replay(plan config.Plan, profiles []region.Profile, rows []gateway.Row) merge.Outcome {
	return merge.AllotMesh(
		plan.GlobalQuota,
		plan.BurstCap,
		plan.BurstRefill,
		plan.SyncDelayEpochs,
		plan.BaseEpoch,
		plan.NodeTotal,
		profiles,
		rows,
	)
}
