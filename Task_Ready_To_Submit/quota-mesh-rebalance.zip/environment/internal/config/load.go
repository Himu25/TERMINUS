package config

import (
	"encoding/json"
	"os"
	"path/filepath"

	"lab.local/quota_mesh_rebalance/pkg/gateway"
	"lab.local/quota_mesh_rebalance/pkg/region"
)

// Plan describes one quota mesh scenario root.
type Plan struct {
	MeshID           string   `json:"mesh_id"`
	GlobalQuota      uint32   `json:"global_quota"`
	BurstCap         uint32   `json:"burst_cap"`
	BurstRefill      uint32   `json:"burst_refill"`
	SyncDelayEpochs  uint32   `json:"sync_delay_epochs"`
	BaseEpoch        uint32   `json:"base_epoch"`
	NodeTotal        int      `json:"node_total"`
	Regions          []string `json:"regions"`
}

// ActivePaths resolves the bundled active plan directory.
func ActivePaths(root string) (string, error) {
	return filepath.Join(root, "data", "active"), nil
}

// LoadPlan reads mesh_plan.json and regional shard trees.
func LoadPlan(dir string) (Plan, []region.Profile, []gateway.Row, error) {
	raw, err := os.ReadFile(filepath.Join(dir, "mesh_plan.json"))
	if err != nil {
		return Plan{}, nil, nil, err
	}
	var doc Plan
	if err := json.Unmarshal(raw, &doc); err != nil {
		return Plan{}, nil, nil, err
	}
	profiles := make([]region.Profile, 0, len(doc.Regions))
	rows := make([]gateway.Row, 0, 128)
	for _, rid := range doc.Regions {
		metaPath := filepath.Join(dir, "regions", rid, "region_meta.json")
		metaRaw, err := os.ReadFile(metaPath)
		if err != nil {
			return Plan{}, nil, nil, err
		}
		var prof region.Profile
		if err := json.Unmarshal(metaRaw, &prof); err != nil {
			return Plan{}, nil, nil, err
		}
		profiles = append(profiles, prof)
		seg := filepath.Join(dir, "regions", rid, "shard_001.jsonl")
		data, err := os.ReadFile(seg)
		if err != nil {
			if os.IsNotExist(err) {
				continue
			}
			return Plan{}, nil, nil, err
		}
		for _, line := range splitLines(string(data)) {
			if line == "" {
				continue
			}
			var row gateway.Row
			if err := json.Unmarshal([]byte(line), &row); err != nil {
				continue
			}
			row.Region = rid
			rows = append(rows, row)
		}
	}
	return doc, profiles, rows, nil
}

func splitLines(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			out = append(out, s[start:i])
			start = i + 1
		}
	}
	if start < len(s) {
		out = append(out, s[start:])
	}
	return out
}
