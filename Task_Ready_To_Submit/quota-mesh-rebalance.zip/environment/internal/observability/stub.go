package observability

// Stub holds no-op telemetry hooks for the replay driver.
func Stub() {}
