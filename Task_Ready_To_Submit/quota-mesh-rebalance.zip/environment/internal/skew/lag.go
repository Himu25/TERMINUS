package skew

// LagSum folds mesh-wide and regional sync lag into one band.
func LagSum(meshLag uint32, regionLag uint32) uint32 {
	return meshLag + regionLag
}
