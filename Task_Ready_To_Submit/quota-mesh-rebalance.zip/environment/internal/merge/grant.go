package merge

import (
	"sort"

	"lab.local/quota_mesh_rebalance/pkg/demandnorm"
	"lab.local/quota_mesh_rebalance/pkg/slicefold"
)

// BuildGrants folds a global pool into per-gateway slice grants.
func BuildGrants(globalQuota uint32, liveIDs []string, nodeTotal int, demands map[string]uint32) map[string]uint32 {
	base := slicefold.OpF(globalQuota, len(liveIDs), nodeTotal)
	grants := make(map[string]uint32, len(liveIDs))
	for _, id := range liveIDs {
		grants[id] = base
	}
	remainder := int(globalQuota) - int(base)*len(liveIDs)
	if remainder <= 0 || len(liveIDs) == 0 {
		return grants
	}
	type pair struct {
		id string
		w  uint32
	}
	weights := make([]pair, 0, len(liveIDs))
	for _, id := range liveIDs {
		weights = append(weights, pair{id: id, w: demandnorm.OpD(demands[id])})
	}
	sort.Slice(weights, func(i, j int) bool {
		if weights[i].w == weights[j].w {
			return weights[i].id < weights[j].id
		}
		return weights[i].w > weights[j].w
	})
	for i := 0; i < remainder && i < len(weights); i++ {
		grants[weights[i].id]++
	}
	return grants
}
