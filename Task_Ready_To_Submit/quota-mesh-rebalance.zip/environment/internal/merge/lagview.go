package merge

import "lab.local/quota_mesh_rebalance/pkg/syncfold"

// ViewEpoch selects the coordinator epoch visible to a gateway.
func ViewEpoch(current uint32, lag uint32) uint32 {
	return syncfold.OpY(current, lag)
}
