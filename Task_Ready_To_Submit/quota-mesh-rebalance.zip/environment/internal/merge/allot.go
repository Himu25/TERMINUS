package merge

import (
	"sort"

	"lab.local/quota_mesh_rebalance/internal/failover"
	"lab.local/quota_mesh_rebalance/internal/skew"
	"lab.local/quota_mesh_rebalance/pkg/gateway"
	"lab.local/quota_mesh_rebalance/pkg/livefold"
	"lab.local/quota_mesh_rebalance/pkg/region"
)

// Outcome is the folded quota counters for one mesh replay.
type Outcome struct {
	EpochsRun        uint32
	AdmittedTotal    uint32
	StarvedTotal     uint32
	WasteUnits       uint32
	FairnessOKFlag   string
	BurstAbsorbed    uint32
	FailoverReclaims uint32
	SyncSkewEpochs   uint32
	NodesLive        uint32
}

type nodeMeta struct {
	region     string
	offlineAt  uint32
	regionLag  uint32
	steady     uint32
	tokens     uint32
	wasLive    bool
	totalAdmit uint32
}

// AllotMesh rebuilds quota admission across gateway epochs.
func AllotMesh(
	globalQuota uint32,
	burstCap uint32,
	burstRefill uint32,
	syncDelay uint32,
	baseEpoch uint32,
	nodeTotal int,
	profiles []region.Profile,
	rows []gateway.Row,
) Outcome {
	regionLag := map[string]uint32{}
	offlineAt := map[string]uint32{}
	for _, p := range profiles {
		regionLag[p.RegionID] = p.SyncLagEpochs
		offlineAt[p.RegionID] = p.OfflineEpoch
	}
	nodes := map[string]*nodeMeta{}
	maxEpoch := uint32(0)
	byEpoch := map[uint32][]gateway.Row{}
	for _, row := range rows {
		byEpoch[row.Epoch] = append(byEpoch[row.Epoch], row)
		if row.Epoch > maxEpoch {
			maxEpoch = row.Epoch
		}
		if _, ok := nodes[row.NodeID]; !ok {
			nodes[row.NodeID] = &nodeMeta{region: row.Region, offlineAt: offlineAt[row.Region], regionLag: regionLag[row.Region]}
		}
		if row.Epoch == baseEpoch {
			nodes[row.NodeID].steady = row.Demand
		}
	}
	sliceHist := map[uint32]map[string]uint32{}
	var out Outcome
	for epoch := uint32(1); epoch <= maxEpoch; epoch++ {
		liveIDs := make([]string, 0, len(nodes))
		for id, st := range nodes {
			live := livefold.OpL(epoch, st.offlineAt)
			if live {
				liveIDs = append(liveIDs, id)
			} else if st.wasLive {
				out.FailoverReclaims += failover.OpR(st.tokens, true)
				st.tokens = 0
			}
			st.wasLive = live
		}
		sort.Strings(liveIDs)
		demands := map[string]uint32{}
		for _, id := range liveIDs {
			demands[id] = demandAt(byEpoch[epoch], id)
		}
		grants := BuildGrants(globalQuota, liveIDs, nodeTotal, demands)
		sliceHist[epoch] = grants
		for _, id := range liveIDs {
			st := nodes[id]
			lag := skew.LagSum(syncDelay, st.regionLag)
			viewEpoch := ViewEpoch(epoch, lag)
			if viewEpoch < 1 {
				viewEpoch = 1
			}
			liveGrant := grants[id]
			viewGrant := liveGrant
			if hist, ok := sliceHist[viewEpoch]; ok {
				if g, ok2 := hist[id]; ok2 {
					viewGrant = g
				}
			}
			if viewEpoch != epoch && viewGrant != liveGrant {
				out.SyncSkewEpochs++
			}
			st.tokens = RefillTokens(st.tokens, burstRefill, burstCap)
			st.tokens += viewGrant
			demand := demands[id]
			admit := demand
			if st.tokens < admit {
				admit = st.tokens
			}
			st.tokens -= admit
			out.AdmittedTotal += admit
			if demand > admit {
				out.StarvedTotal += demand - admit
			}
			if viewGrant > admit {
				out.WasteUnits += viewGrant - admit
			}
			st.totalAdmit += admit
			if demand > st.steady && st.steady > 0 {
				baseAdmit := st.steady
				if admit < baseAdmit {
					baseAdmit = admit
				}
				if admit > baseAdmit {
					out.BurstAbsorbed += admit - baseAdmit
				}
			}
		}
	}
	out.EpochsRun = maxEpoch
	out.NodesLive = uint32(len(liveAt(maxEpoch, nodes)))
	out.FairnessOKFlag = fairnessFlag(nodes)
	return out
}

func demandAt(rows []gateway.Row, nodeID string) uint32 {
	for _, row := range rows {
		if row.NodeID == nodeID {
			return row.Demand
		}
	}
	return 0
}

func liveAt(epoch uint32, nodes map[string]*nodeMeta) []string {
	out := make([]string, 0, len(nodes))
	for id, st := range nodes {
		if livefold.OpL(epoch, st.offlineAt) {
			out = append(out, id)
		}
	}
	sort.Strings(out)
	return out
}

func fairnessFlag(nodes map[string]*nodeMeta) string {
	var admits []uint32
	for _, st := range nodes {
		if st.totalAdmit > 0 {
			admits = append(admits, st.totalAdmit)
		}
	}
	if len(admits) < 2 {
		return "yes"
	}
	sort.Slice(admits, func(i, j int) bool { return admits[i] < admits[j] })
	minA := admits[0]
	maxA := admits[len(admits)-1]
	if maxA == 0 {
		return "yes"
	}
	if minA*2 >= maxA {
		return "yes"
	}
	return "no"
}
