package merge

import "lab.local/quota_mesh_rebalance/ratelimit_core"

// RefillTokens folds burst refill into a gateway token bucket.
func RefillTokens(tokens uint32, refill uint32, cap uint32) uint32 {
	next := ratelimit_core.ApplyBurst(int64(tokens), int64(refill), int64(cap))
	if next < 0 {
		return 0
	}
	return uint32(next)
}
