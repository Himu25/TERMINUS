#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1

mkdir -p /app/bin
cd /app/ratelimit_core
cargo build --release --locked 2>/dev/null || cargo build --release
cd /app
GOFLAGS=-mod=mod go build -trimpath -buildvcs=false -o /app/bin/quota_mesh ./cmd/quota_mesh
