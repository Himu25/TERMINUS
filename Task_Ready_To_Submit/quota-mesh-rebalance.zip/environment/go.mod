module lab.local/quota_mesh_rebalance

go 1.22
