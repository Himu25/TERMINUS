#ifndef RL_BURST_FOLD_H
#define RL_BURST_FOLD_H

long long rl_apply_burst(long long tokens, long long refill, long long cap);

#endif
