package ratelimit_core

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libratelimit_core.a -ldl -lm
#include "burst_fold.h"
*/
import "C"

// ApplyBurst folds burst refill into a gateway token bucket.
func ApplyBurst(tokens int64, refill int64, cap int64) int64 {
	return int64(C.rl_apply_burst(C.longlong(tokens), C.longlong(refill), C.longlong(cap)))
}
