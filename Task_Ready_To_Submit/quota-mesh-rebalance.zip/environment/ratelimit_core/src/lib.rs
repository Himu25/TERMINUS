#[no_mangle]
pub extern "C" fn rl_apply_burst(tokens: i64, refill: i64, cap: i64) -> i64 {
    if refill == 0 {
        return tokens;
    }
    tokens - refill
}
