Four regional edges (east, west, north, south) host three gateways each.
Traffic shards are JSONL per region. Coordinator epochs align across the mesh.
