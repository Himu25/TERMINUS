Fairness flag is yes when the smallest positive gateway admit total is at
least half the largest. Waste counts slice grant minus admitted per epoch.
