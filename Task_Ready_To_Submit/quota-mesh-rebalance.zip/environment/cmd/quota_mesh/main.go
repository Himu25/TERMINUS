// Report JSON for /app/output/quota_report.json:
//
// schema_version — string, must be "1"
// mesh_id — string, echoes active mesh plan name
// epochs_run — highest traffic epoch included in replay
// admitted_total — requests admitted across all gateways and epochs
// starved_total — requests denied for lack of local tokens
// waste_units — coordinator slice capacity left unused after admission
// fairness_ok_flag — string, "yes" or "no"
// burst_absorbed — admitted volume above steady baseline at base_epoch
// failover_reclaims — token units reclaimed when gateways go offline
// sync_skew_epochs — epochs where lagged slice differed from live grant
// nodes_live — gateways contributing to the final epoch replay
// digest_hex — lowercase hex SHA-256 of mesh_id|epochs_run|admitted_total|starved_total|waste_units|fairness_ok_flag|burst_absorbed|failover_reclaims|sync_skew_epochs|nodes_live
//
// Root object contains only these keys.
package main

import (
	"log"
	"os"

	"lab.local/quota_mesh_rebalance/internal/driver"
)

func main() {
	if os.Getenv("TB_QUOTA_FIXTURE") != "1" {
		log.Fatal("TB_QUOTA_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/quota_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
