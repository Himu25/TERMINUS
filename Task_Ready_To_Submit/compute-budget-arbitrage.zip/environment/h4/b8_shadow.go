package h4

// WxShadow mirrors burst absorb shape for catalog probes.
func WxShadow(burstNeed, headroom int) int {
	if burstNeed <= 0 || headroom <= 0 {
		return 0
	}
	if burstNeed > headroom {
		return headroom
	}
	return burstNeed
}
