Daily credit pool simulator for ML training jobs. Build and runtime entrypoints are documented in `/app/docs/architecture.md`.
