package z1

// RxShadow mirrors waste roll shape for catalog probes.
func RxShadow(reserved, used int) int {
	if reserved <= used {
		return 0
	}
	return reserved - used
}
