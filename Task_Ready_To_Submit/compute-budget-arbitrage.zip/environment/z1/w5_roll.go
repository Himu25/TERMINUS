package z1

// RxRoll totals reservation waste for one job wave.
func RxRoll(reserved, used int) int {
	if reserved <= used {
		return 0
	}
	return (reserved - used) / 2
}
