Daily credit arbitrage ties together a Go driver, Rust static meter, and bash runners under /app.
The driver loads credits.toml, job JSONL bundles, and runtime_overlay.csv before simulating
daily credit allocation across dependent ML jobs.

Dispatch logic is split across small Go packages plus a Rust static library linked through CGO.
When est_credits is zero, the meter resolves billable credits from overlay telemetry.

Build via /app/scripts/build.sh. Default bundle generation uses jobpack on job_specs.jsonl.
Default report emission uses /app/tools/run_arbitrage.
