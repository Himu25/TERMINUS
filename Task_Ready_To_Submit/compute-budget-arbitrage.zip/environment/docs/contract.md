# Arbitrage report contract

## Top-level fields

- status: ok when guardrails pass, otherwise fail
- credit_budget: daily pool from credits.toml
- credits_spent: billable credits consumed by completed jobs
- credits_waste: reservation waste summed across jobs
- jobs_total: input JSONL row count
- jobs_completed: jobs marked completed
- completion_rate: jobs_completed divided by jobs_total
- waste_ratio: credits_waste divided by credits_spent
- dep_violations: jobs started before dependencies finished
- priority_inversions: completed jobs whose rank score fell below a prior finish
- burst_absorbed: burst headroom credits absorbed during waves
- value_captured: weighted value total for completed jobs
- report_digest: sha256 hex of compact JSON with report_digest empty
- jobs: per-job rows

## Job row fields

- job_id, team, priority
- credits_reserved, credits_used, waste_credits
- completed, dep_ready, priority_rank, burst_slot, value_captured

## Input coverage

jobs_total equals the number of rows in the active jobs JSONL input. The jobs array must contain exactly one row per input job_id with no omissions or extras.

## Scheduling order

Pending jobs are ranked so late catalog revisions outrank stale rows, then higher priority wins, then higher value weight, with job_id as the stable tie-break.

## priority_rank

1-based position in the scheduler processing order after ranking. Lower priority_rank means the job was scheduled earlier.

## Priority inversions

For each completed job, form rank score = priority_rev * 10 + priority. priority_inversions counts how often a completed job's rank score is greater than the rank score of an earlier-completed job.

## Drift and credit accounting

- credits_reserved: reservation size from est_credits when est_credits is positive; when est_credits is zero, reservation follows billable credits from the overlay meter
- credits_used: overlay act_credits when runtime_overlay.csv supplies a value, otherwise act_credits from the job row
- waste_credits: credits_reserved minus credits_used (zero when reserved is not greater than used)
- Overlay drift rows keep the estimate reservation even when actual consumption is lower, so waste_credits reflects reserved minus used

## Value capture

value_captured and per-row value_captured equal value_weight times team_weight from credits.toml times credits_used divided by 1000. The report-level value_captured is the sum of completed per-row values.

## Burst absorb

burst_absorbed sums min(burst demand, spare headroom) per burst wave row; demand for a row is est_credits divided by four.

## report_digest

64-character lowercase hexadecimal SHA-256 of compact JSON encoding of the full report object with report_digest set to empty string. Use JSON separators (",", ":"), ensure_ascii=false, and no HTML character escaping. Strip any single trailing newline from the JSON string before hashing.

Digest JSON uses the same keys as the written report with report_digest set to empty string before hashing.

## Determinism

Identical job bundle, overlay, and config inputs must yield byte-identical report JSON on repeated runs.

## Regression bundles

The same contract applies when the jobs bundle is replaced with isolated dependency-chain, priority-flip, estimate-drift, burst-cluster, value-mix, or overlay-meter replays.
