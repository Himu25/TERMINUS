package k2

// QxShadow mirrors dependency checks for catalog probes.
func QxShadow(depOn []string, done map[string]bool) bool {
	if len(depOn) == 0 {
		return true
	}
	return done[depOn[len(depOn)-1]]
}
