package drv

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"

	"cred.arb/u3"
	"cred.arb/k2"
	"cred.arb/q9"
	"cred.arb/n8"
	"cred.arb/pkg/types"
	"cred.arb/summ"
	"cred.arb/z1"
	"cred.arb/h4"
)

func LoadCfg(path string) (types.CreditCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.CreditCfg{}, err
	}
	cfg := types.CreditCfg{
		CreditBudget:          12000,
		MinCompletionRate:     0.75,
		MaxWasteRatio:         0.22,
		MaxDepViolations:      0,
		MaxPriorityInversions: 1,
		MinBurstAbsorbed:      3,
		MinValueCaptured:      8.5,
		TeamWeights:           map[string]float64{"team_a": 1.0, "team_b": 1.0, "team_c": 1.0},
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "credit_budget":
			fmt.Sscanf(val, "%d", &cfg.CreditBudget)
		case "min_completion_rate":
			fmt.Sscanf(val, "%f", &cfg.MinCompletionRate)
		case "max_waste_ratio":
			fmt.Sscanf(val, "%f", &cfg.MaxWasteRatio)
		case "max_dep_violations":
			fmt.Sscanf(val, "%d", &cfg.MaxDepViolations)
		case "max_priority_inversions":
			fmt.Sscanf(val, "%d", &cfg.MaxPriorityInversions)
		case "min_burst_absorbed":
			fmt.Sscanf(val, "%d", &cfg.MinBurstAbsorbed)
		case "min_value_captured":
			fmt.Sscanf(val, "%f", &cfg.MinValueCaptured)
		case "team_weight_team_a":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.TeamWeights["team_a"] = w
		case "team_weight_team_b":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.TeamWeights["team_b"] = w
		case "team_weight_team_c":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.TeamWeights["team_c"] = w
		}
	}
	return cfg, nil
}

func LoadJobs(path string) ([]types.JobCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.JobCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var jc types.JobCase
		if err := json.Unmarshal([]byte(line), &jc); err != nil {
			return nil, err
		}
		out = append(out, jc)
	}
	return out, sc.Err()
}

func LoadOverlay(path string) (map[string]int, error) {
	f, err := os.Open(path)
	if err != nil {
		return map[string]int{}, nil
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]int)
	for i, row := range rows {
		if i == 0 || len(row) < 2 {
			continue
		}
		var credits int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &credits)
		out[strings.TrimSpace(row[0])] = credits
	}
	return out, nil
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

func Run(cfg types.CreditCfg, cases []types.JobCase, overlay map[string]int) (types.ArbitrageReport, error) {
	ordered := q9.PxOrder(cases)
	report := types.ArbitrageReport{
		Status:       "ok",
		CreditBudget: cfg.CreditBudget,
		JobsTotal:    len(ordered),
	}
	done := make(map[string]bool)
	budgetLeft := cfg.CreditBudget
	var spent, totalWaste, completed, depViol, inversions, burstTotal int
	var valueTotal float64
	prevRank := -1
	report.Jobs = make([]types.JobRow, 0, len(ordered))

	for idx, jc := range ordered {
		actualReady := true
		for _, depID := range jc.DepOn {
			if !done[depID] {
				actualReady = false
				break
			}
		}
		depReady := k2.DxReady(jc.DepOn, done)
		if len(jc.DepOn) > 0 && !actualReady && depReady {
			depViol++
		}
		overlayVal := 0
		if act, ok := overlay[jc.JobID]; ok && act > 0 {
			overlayVal = act
			jc.ActCredits = act
		}
		roll := n8.MeterSpan(jc.EstCredits, jc.ActCredits, overlayVal)
		billable := roll.Billable
		if billable <= 0 {
			billable = jc.EstCredits
		}
		reserveNeed := u3.AxNeed(jc.EstCredits, billable)
		reserved, ok := u3.BxReserve(budgetLeft, reserveNeed)
		headroom := budgetLeft - reserved
		if jc.BurstWave > 0 {
			burstTotal += h4.WxAbsorb(jc.EstCredits/4, headroom)
		}
		used := 0
		finished := false
		if ok && depReady {
			used = jc.ActCredits
			if used <= 0 {
				used = billable
			}
			if used > reserved {
				used = reserved
			}
			budgetLeft -= reserved
			spent += used
			finished = true
			completed++
			done[jc.JobID] = true
			teamScale := cfg.TeamWeights[jc.Team]
			if teamScale <= 0 {
				teamScale = 1.0
			}
			valueTotal += u3.VxValue(jc.ValueWeight, used, teamScale)
		}
		wasteAmt := z1.RxRoll(reserved, used)
		totalWaste += wasteAmt
		rankScore := jc.PriorityRev*10 + jc.Priority
		if finished {
			if prevRank >= 0 && rankScore > prevRank {
				inversions++
			}
			prevRank = rankScore
		}
		row := types.JobRow{
			JobID:           jc.JobID,
			Team:            jc.Team,
			Priority:        jc.Priority,
			CreditsReserved: reserved,
			CreditsUsed:     used,
			Completed:       finished,
			DepReady:        depReady,
			PriorityRank:    idx + 1,
			WasteCredits:    wasteAmt,
			BurstSlot:       jc.BurstWave,
			ValueCaptured: round4(func() float64 {
				teamScale := cfg.TeamWeights[jc.Team]
				if teamScale <= 0 {
					teamScale = 1.0
				}
				return u3.VxValue(jc.ValueWeight, used, teamScale)
			}()),
		}
		report.Jobs = append(report.Jobs, row)
	}

	report.CreditsSpent = spent
	report.CreditsWaste = totalWaste
	report.JobsCompleted = completed
	if report.JobsTotal > 0 {
		report.CompletionRate = round4(float64(completed) / float64(report.JobsTotal))
	}
	if spent > 0 {
		report.WasteRatio = round4(float64(totalWaste) / float64(spent))
	}
	report.DepViolations = depViol
	report.PriorityInversions = inversions
	report.BurstAbsorbed = burstTotal
	report.ValueCaptured = round4(valueTotal)
	hasBurst := false
	for _, jc := range ordered {
		if jc.BurstWave > 0 {
			hasBurst = true
			break
		}
	}
	if !meetsFloors(cfg, report, hasBurst) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func meetsFloors(cfg types.CreditCfg, report types.ArbitrageReport, hasBurst bool) bool {
	if report.CompletionRate < cfg.MinCompletionRate {
		return false
	}
	if report.WasteRatio > cfg.MaxWasteRatio {
		return false
	}
	if report.DepViolations > cfg.MaxDepViolations {
		return false
	}
	if report.PriorityInversions > cfg.MaxPriorityInversions {
		return false
	}
	if report.BurstAbsorbed < cfg.MinBurstAbsorbed {
		if hasBurst {
			return false
		}
	}
	if report.ValueCaptured < cfg.MinValueCaptured {
		return false
	}
	for _, row := range report.Jobs {
		if strings.HasPrefix(row.JobID, "j_dep_") && !row.DepReady && row.Completed {
			return false
		}
		if strings.HasPrefix(row.JobID, "j_burst_") && row.BurstSlot > 0 && !row.Completed {
			return false
		}
		if strings.HasPrefix(row.JobID, "j_drift_") && row.WasteCredits == 0 && row.CreditsReserved > row.CreditsUsed+50 {
			return false
		}
	}
	_ = summ.SxFold(report.Jobs)
	return true
}

type digestPayload struct {
	Status             string         `json:"status"`
	CreditBudget       int            `json:"credit_budget"`
	CreditsSpent       int            `json:"credits_spent"`
	CreditsWaste       int            `json:"credits_waste"`
	JobsTotal          int            `json:"jobs_total"`
	JobsCompleted      int            `json:"jobs_completed"`
	CompletionRate     float64        `json:"completion_rate"`
	WasteRatio         float64        `json:"waste_ratio"`
	DepViolations      int            `json:"dep_violations"`
	PriorityInversions int            `json:"priority_inversions"`
	BurstAbsorbed      int            `json:"burst_absorbed"`
	ValueCaptured      float64        `json:"value_captured"`
	ReportDigest       string         `json:"report_digest"`
	Jobs               []types.JobRow `json:"jobs"`
}

func digestBody(report types.ArbitrageReport) string {
	payload := digestPayload{
		Status:             report.Status,
		CreditBudget:       report.CreditBudget,
		CreditsSpent:       report.CreditsSpent,
		CreditsWaste:       report.CreditsWaste,
		JobsTotal:          report.JobsTotal,
		JobsCompleted:      report.JobsCompleted,
		CompletionRate:     report.CompletionRate,
		WasteRatio:         report.WasteRatio,
		DepViolations:      report.DepViolations,
		PriorityInversions: report.PriorityInversions,
		BurstAbsorbed:      report.BurstAbsorbed,
		ValueCaptured:      report.ValueCaptured,
		ReportDigest:       "",
		Jobs:               report.Jobs,
	}
	raw, err := marshalDigestJSON(payload)
	if err != nil {
		return ""
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func marshalDigestJSON(payload digestPayload) ([]byte, error) {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return nil, err
	}
	b := buf.Bytes()
	if n := len(b); n > 0 && b[n-1] == '\n' {
		b = b[:n-1]
	}
	return b, nil
}

func WriteReport(path string, report types.ArbitrageReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func p95(values []int) int {
	if len(values) == 0 {
		return 0
	}
	cp := append([]int(nil), values...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}
