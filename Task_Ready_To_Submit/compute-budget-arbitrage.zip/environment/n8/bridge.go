package n8

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libn8_meter.a -ldl -lm
#include "credit_fold.h"
*/
import "C"

// Roll holds billable credits for one job.
type Roll struct {
	Billable  int
	DriftFlag bool
}

// MeterSpan resolves billable credits for a job row.
func MeterSpan(est, act, overlay int) Roll {
	ct := C.credit_meter_span(C.int(est), C.int(act), C.int(overlay))
	return Roll{
		Billable:  int(ct.billable),
		DriftFlag: ct.drift_flag != 0,
	}
}

// MeterBatch scores a slice of estimates (decoy helper).
func MeterBatch(estimates []int32) int {
	if len(estimates) == 0 {
		return 0
	}
	sum := 0
	for _, e := range estimates {
		if e > 0 {
			sum += int(e)
		}
	}
	return sum
}
