#ifndef CREDIT_FOLD_H
#define CREDIT_FOLD_H

typedef struct {
    int billable;
    int drift_flag;
} credit_roll;

credit_roll credit_meter_span(int est, int act, int overlay);

#endif
