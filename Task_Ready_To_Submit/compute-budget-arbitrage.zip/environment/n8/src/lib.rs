use std::os::raw::c_int;

#[repr(C)]
pub struct CreditRoll {
    pub billable: c_int,
    pub drift_flag: c_int,
}

fn drift(est: i32, act: i32) -> bool {
    if est <= 0 {
        return false;
    }
    (act - est).abs() * 100 > est * 15
}

#[no_mangle]
pub extern "C" fn credit_meter_span(est: c_int, act: c_int, overlay: c_int) -> CreditRoll {
    let est_i = est.max(0);
    let act_i = act.max(0);
    let overlay_i = overlay.max(0);
    let drifting = overlay_i > 0 && drift(est_i, act_i);
    let billable = if overlay_i > 0 {
        est_i.max(act_i)
    } else if act_i > 0 {
        act_i
    } else {
        est_i.max(1)
    };
    CreditRoll {
        billable,
        drift_flag: if drifting { 1 } else { 0 },
    }
}
