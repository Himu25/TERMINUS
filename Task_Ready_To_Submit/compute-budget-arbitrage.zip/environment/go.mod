module cred.arb

go 1.22
