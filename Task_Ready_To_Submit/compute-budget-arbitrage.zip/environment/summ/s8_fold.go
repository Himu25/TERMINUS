package summ

import "cred.arb/pkg/types"

// SxFold folds job rows for telemetry export (non-scheduling).
func SxFold(rows []types.JobRow) int {
	total := 0
	for _, row := range rows {
		total += row.CreditsUsed
	}
	return total
}
