package types

type CreditCfg struct {
	CreditBudget          int
	MinCompletionRate     float64
	MaxWasteRatio         float64
	MaxDepViolations      int
	MaxPriorityInversions int
	MinBurstAbsorbed      int
	MinValueCaptured      float64
	TeamWeights           map[string]float64
}

type JobCase struct {
	JobID       string   `json:"job_id"`
	Team        string   `json:"team"`
	Priority    int      `json:"priority"`
	PriorityRev int      `json:"priority_rev"`
	EstCredits  int      `json:"est_credits"`
	ActCredits  int      `json:"act_credits"`
	DepOn       []string `json:"dep_on"`
	BurstWave   int      `json:"burst_wave"`
	ValueWeight float64  `json:"value_weight"`
}

type JobRow struct {
	JobID           string  `json:"job_id"`
	Team            string  `json:"team"`
	Priority        int     `json:"priority"`
	CreditsReserved int     `json:"credits_reserved"`
	CreditsUsed     int     `json:"credits_used"`
	Completed       bool    `json:"completed"`
	DepReady        bool    `json:"dep_ready"`
	PriorityRank    int     `json:"priority_rank"`
	WasteCredits    int     `json:"waste_credits"`
	BurstSlot       int     `json:"burst_slot"`
	ValueCaptured   float64 `json:"value_captured"`
}

type ArbitrageReport struct {
	Status             string   `json:"status"`
	CreditBudget       int      `json:"credit_budget"`
	CreditsSpent       int      `json:"credits_spent"`
	CreditsWaste       int      `json:"credits_waste"`
	JobsTotal          int      `json:"jobs_total"`
	JobsCompleted      int      `json:"jobs_completed"`
	CompletionRate     float64  `json:"completion_rate"`
	WasteRatio         float64  `json:"waste_ratio"`
	DepViolations      int      `json:"dep_violations"`
	PriorityInversions int      `json:"priority_inversions"`
	BurstAbsorbed      int      `json:"burst_absorbed"`
	ValueCaptured      float64  `json:"value_captured"`
	ReportDigest       string   `json:"report_digest"`
	Jobs               []JobRow `json:"jobs"`
}
