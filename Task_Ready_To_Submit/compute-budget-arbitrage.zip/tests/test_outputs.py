"""Validate /app/output/arbitrage_report.json against credits.toml guardrails."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "arbitrage_report.json"
JOBS = APP / "data" / "jobs_default.jsonl"
CFG = APP / "config" / "credits.toml"
OVERLAY = APP / "data" / "runtime_overlay.csv"
CASES = Path(__file__).resolve().parent / "data"

_DEFAULT_JOBS_TEXT = JOBS.read_text(encoding="utf-8") if JOBS.is_file() else ""

REPORT_KEYS = frozenset(
    {
        "status",
        "credit_budget",
        "credits_spent",
        "credits_waste",
        "jobs_total",
        "jobs_completed",
        "completion_rate",
        "waste_ratio",
        "dep_violations",
        "priority_inversions",
        "burst_absorbed",
        "value_captured",
        "report_digest",
        "jobs",
    }
)
RUN_TIMEOUT_SEC = 120

ROW_KEYS = frozenset(
    {
        "job_id",
        "team",
        "priority",
        "credits_reserved",
        "credits_used",
        "waste_credits",
        "completed",
        "dep_ready",
        "priority_rank",
        "burst_slot",
        "value_captured",
    }
)


def _load_overlay() -> dict[str, int]:
    overlay: dict[str, int] = {}
    if not OVERLAY.is_file():
        return overlay
    lines = OVERLAY.read_text(encoding="utf-8").splitlines()
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        job_id, credits = (part.strip() for part in line.split(",", 1))
        overlay[job_id] = int(credits)
    return overlay


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "credit_budget": 12000,
        "min_completion_rate": 0.75,
        "max_waste_ratio": 0.35,
        "max_dep_violations": 0,
        "max_priority_inversions": 1,
        "min_burst_absorbed": 3,
        "min_value_captured": 2.0,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in ("min_completion_rate", "max_waste_ratio", "min_value_captured"):
            cfg[key] = float(val)
        elif key in (
            "credit_budget",
            "max_dep_violations",
            "max_priority_inversions",
            "min_burst_absorbed",
        ):
            cfg[key] = int(float(val))
    return cfg


def _parse_team_weights() -> dict[str, float]:
    weights: dict[str, float] = {}
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line.startswith("team_weight_"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        weights[key.removeprefix("team_weight_")] = float(val)
    return weights


def _expected_row_value(row: dict, spec: dict, team_weights: dict[str, float]) -> float:
    if not row["completed"] or row["credits_used"] <= 0:
        return 0.0
    weight = spec.get("value_weight", 1.0)
    if weight <= 0:
        weight = 1.0
    team_scale = team_weights.get(row["team"], 1.0)
    if team_scale <= 0:
        team_scale = 1.0
    return round(weight * team_scale * row["credits_used"] / 1000.0, 4)


def _job_rows_from_text(text: str) -> list[dict]:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def _job_ids_from_text(text: str) -> list[str]:
    return [row["job_id"] for row in _job_rows_from_text(text)]


def _job_map_from_text(text: str) -> dict[str, dict]:
    return {row["job_id"]: row for row in _job_rows_from_text(text)}


def _assert_jobs_match_input(report: dict, jobs_text: str) -> None:
    expected_ids = _job_ids_from_text(jobs_text)
    report_ids = [row["job_id"] for row in report["jobs"]]
    assert report["jobs_total"] == len(expected_ids)
    assert len(report_ids) == len(expected_ids)
    assert set(report_ids) == set(expected_ids)


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    try:
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, path)
    finally:
        if tmp.is_file():
            tmp.unlink()


def _swap_fixture(stem: str) -> str:
    src = CASES / f"{stem}.jsonl"
    text = src.read_text(encoding="utf-8")
    _atomic_write_text(JOBS, text)
    return text


def _expected_digest(report: dict) -> str:
    payload = dict(report)
    payload["report_digest"] = ""
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
        timeout=RUN_TIMEOUT_SEC,
    )
    return proc.stdout.split()[0]


def _invoke_default() -> None:
    proc = subprocess.run(
        ["/app/tools/run_arbitrage"],
        capture_output=True,
        text=True,
        check=False,
        timeout=RUN_TIMEOUT_SEC,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "arbitrage_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


@pytest.fixture(autouse=True)
def _isolated_default_bundle() -> None:
    """Reset jobs and report so scenario swaps cannot leak across tests."""
    if _DEFAULT_JOBS_TEXT:
        _atomic_write_text(JOBS, _DEFAULT_JOBS_TEXT)
    _invoke_default()
    yield
    if _DEFAULT_JOBS_TEXT:
        _atomic_write_text(JOBS, _DEFAULT_JOBS_TEXT)
    stale_tmp = JOBS.with_suffix(JOBS.suffix + ".tmp")
    if stale_tmp.is_file():
        stale_tmp.unlink()


def test_report_top_level_keys_exact() -> None:
    """Report must expose only the documented top-level keys."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS


def test_job_row_schema() -> None:
    """Each job row must match the documented per-job schema."""
    report = _load_report()
    assert report["jobs"]
    for row in report["jobs"]:
        assert set(row.keys()) == ROW_KEYS
        assert isinstance(row["job_id"], str) and row["job_id"]
        assert isinstance(row["team"], str) and row["team"]
        assert isinstance(row["priority"], int)
        assert row["credits_reserved"] >= 0
        assert row["credits_used"] >= 0
        assert row["waste_credits"] >= 0
        assert isinstance(row["completed"], bool)
        assert isinstance(row["dep_ready"], bool)
        assert row["priority_rank"] >= 1
        assert row["burst_slot"] >= 0
        assert row["value_captured"] >= 0.0


def test_passing_run_contract() -> None:
    """Default bundle must finish ok and meet credits.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["credit_budget"] == cfg["credit_budget"]
    _assert_jobs_match_input(report, _DEFAULT_JOBS_TEXT)
    assert report["completion_rate"] >= cfg["min_completion_rate"]
    assert report["waste_ratio"] <= cfg["max_waste_ratio"]
    assert report["dep_violations"] <= cfg["max_dep_violations"]
    assert report["priority_inversions"] <= cfg["max_priority_inversions"]
    assert report["burst_absorbed"] >= cfg["min_burst_absorbed"]
    assert report["value_captured"] >= cfg["min_value_captured"]


def test_jobs_total_matches_input_rows() -> None:
    """Report job IDs must cover every input JSONL row with no drops or extras."""
    report = _load_report()
    _assert_jobs_match_input(report, _DEFAULT_JOBS_TEXT)


def test_report_digest_matches_payload() -> None:
    """report_digest must hash the compact pre-digest JSON payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_deterministic_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_dep_rows_finish_in_order() -> None:
    """Dependency chain rows must complete only after prerequisites."""
    report = _load_report()
    ranks = {row["job_id"]: row["priority_rank"] for row in report["jobs"]}
    assert ranks["j_dep_root"] < ranks["j_dep_leaf"] < ranks["j_dep_chain"]
    for row in report["jobs"]:
        if row["job_id"].startswith("j_dep_") and row["completed"]:
            assert row["dep_ready"] is True, row


def test_prio_hot_ranks_before_cold() -> None:
    """Late priority revision rows must finish before stale low-revision peers."""
    report = _load_report()
    hot = next(r for r in report["jobs"] if r["job_id"] == "j_prio_hot")
    cold = next(r for r in report["jobs"] if r["job_id"] == "j_prio_cold")
    assert hot["completed"] is True
    assert cold["completed"] is True
    assert hot["priority_rank"] < cold["priority_rank"], (hot, cold)


def test_drift_accounting_semantics() -> None:
    """Drift rows reserve estimates, bill actuals, and record reserved minus used."""
    report = _load_report()
    inputs = _job_map_from_text(_DEFAULT_JOBS_TEXT)
    overlay = _load_overlay()
    for row in report["jobs"]:
        if not row["job_id"].startswith("j_drift_") or not row["completed"]:
            continue
        spec = inputs[row["job_id"]]
        expected_used = overlay.get(row["job_id"], spec["act_credits"])
        assert row["credits_reserved"] == spec["est_credits"]
        assert row["credits_used"] == expected_used
        assert row["waste_credits"] == max(0, row["credits_reserved"] - row["credits_used"])


def test_drift_rows_record_waste() -> None:
    """Drift-prone rows with inflated reservations must record waste_credits."""
    report = _load_report()
    drift_rows = [r for r in report["jobs"] if r["job_id"].startswith("j_drift_")]
    assert drift_rows
    assert any(r["waste_credits"] > 0 for r in drift_rows if r["completed"])


def test_burst_rows_complete() -> None:
    """Burst wave rows must complete under the default bundle."""
    report = _load_report()
    burst_rows = [r for r in report["jobs"] if r["job_id"].startswith("j_burst_")]
    assert burst_rows
    assert all(r["completed"] for r in burst_rows), burst_rows


def test_scenario_dep_chain() -> None:
    """Dependency-chain scenario must schedule deps before dependents."""
    jobs_text = _swap_fixture("dep_chain")
    _invoke_default()
    report = _load_report()
    _assert_jobs_match_input(report, jobs_text)
    assert report["dep_violations"] == 0
    assert report["status"] == "ok"
    ranks = {row["job_id"]: row["priority_rank"] for row in report["jobs"]}
    assert ranks["j_dep_root"] < ranks["j_dep_leaf"] < ranks["j_dep_chain"]


def test_scenario_priority_flip() -> None:
    """Priority-flip scenario must schedule late revisions ahead of stale peers."""
    cfg = _parse_cfg()
    jobs_text = _swap_fixture("priority_flip")
    _invoke_default()
    report = _load_report()
    _assert_jobs_match_input(report, jobs_text)
    hot = next(r for r in report["jobs"] if r["job_id"] == "j_prio_hot")
    cold = next(r for r in report["jobs"] if r["job_id"] == "j_prio_cold")
    assert hot["priority_rank"] < cold["priority_rank"]
    assert report["priority_inversions"] <= cfg["max_priority_inversions"]
    assert report["status"] == "ok"


def test_scenario_est_drift() -> None:
    """Estimate-drift scenario must keep waste_ratio under max_waste_ratio."""
    cfg = _parse_cfg()
    jobs_text = _swap_fixture("est_drift")
    _invoke_default()
    report = _load_report()
    _assert_jobs_match_input(report, jobs_text)
    inputs = _job_map_from_text(jobs_text)
    for row in report["jobs"]:
        if not row["job_id"].startswith("j_drift_") or not row["completed"]:
            continue
        spec = inputs[row["job_id"]]
        assert row["credits_reserved"] == spec["est_credits"]
        assert row["waste_credits"] == max(0, row["credits_reserved"] - row["credits_used"])
        assert row["waste_credits"] > 0
    assert report["waste_ratio"] <= cfg["max_waste_ratio"]
    assert report["status"] == "ok"


def test_scenario_burst_cluster() -> None:
    """Burst-cluster scenario must absorb enough burst headroom."""
    cfg = _parse_cfg()
    jobs_text = _swap_fixture("burst_cluster")
    _invoke_default()
    report = _load_report()
    _assert_jobs_match_input(report, jobs_text)
    burst_rows = [r for r in report["jobs"] if r["job_id"].startswith("j_burst_")]
    assert burst_rows
    assert all(r["completed"] for r in burst_rows)
    assert report["burst_absorbed"] >= cfg["min_burst_absorbed"]
    assert report["status"] == "ok"


def test_scenario_value_mix() -> None:
    """Value-mix scenario must meet value_captured floor."""
    cfg = _parse_cfg()
    jobs_text = _swap_fixture("value_mix")
    _invoke_default()
    report = _load_report()
    _assert_jobs_match_input(report, jobs_text)
    assert report["value_captured"] >= cfg["min_value_captured"]


def test_scenario_overlay_meter() -> None:
    """Zero-estimate overlay row must bill overlay credits through the meter."""
    jobs_text = _swap_fixture("overlay_meter")
    _invoke_default()
    report = _load_report()
    _assert_jobs_match_input(report, jobs_text)
    overlay = _load_overlay()
    expected_used = overlay["j_meter_overlay"]
    row = next(r for r in report["jobs"] if r["job_id"] == "j_meter_overlay")
    assert row["completed"] is True
    assert row["credits_used"] == expected_used
    assert row["credits_reserved"] == expected_used
    assert row["credits_reserved"] >= row["credits_used"]
    assert row["waste_credits"] == max(0, row["credits_reserved"] - row["credits_used"])


def test_row_value_captured_team_weight() -> None:
    """Per-row value_captured must scale value_weight by team weight and credits_used."""
    report = _load_report()
    jobs_text = JOBS.read_text(encoding="utf-8")
    inputs = _job_map_from_text(jobs_text)
    team_weights = _parse_team_weights()
    row = next(r for r in report["jobs"] if r["job_id"] == "j_value_mix")
    assert row["completed"] is True
    expected = _expected_row_value(row, inputs[row["job_id"]], team_weights)
    assert row["value_captured"] == expected


def test_report_value_captured_matches_rows() -> None:
    """Top-level value_captured must equal the sum of completed row values."""
    report = _load_report()
    jobs_text = JOBS.read_text(encoding="utf-8")
    inputs = _job_map_from_text(jobs_text)
    team_weights = _parse_team_weights()
    total = round(
        sum(
            _expected_row_value(row, inputs[row["job_id"]], team_weights)
            for row in report["jobs"]
            if row["completed"]
        ),
        4,
    )
    assert report["value_captured"] == total


def test_burst_absorb_clamped_to_need() -> None:
    """burst_absorbed must not exceed summed burst demand for completed waves."""
    report = _load_report()
    jobs_text = JOBS.read_text(encoding="utf-8")
    inputs = _job_map_from_text(jobs_text)
    demand = sum(
        inputs[row["job_id"]]["est_credits"] // 4
        for row in report["jobs"]
        if row["burst_slot"] > 0 and row["completed"]
    )
    assert report["burst_absorbed"] <= demand
    assert report["burst_absorbed"] > 0
