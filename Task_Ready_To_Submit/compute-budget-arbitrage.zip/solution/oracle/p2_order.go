package q9

import (
	"sort"

	"cred.arb/pkg/types"
)

// PxOrder ranks pending jobs for credit allocation.
func PxOrder(cases []types.JobCase) []types.JobCase {
	out := make([]types.JobCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		a, b := out[i], out[j]
		if a.PriorityRev != b.PriorityRev {
			return a.PriorityRev > b.PriorityRev
		}
		if a.Priority != b.Priority {
			return a.Priority > b.Priority
		}
		if a.ValueWeight != b.ValueWeight {
			return a.ValueWeight > b.ValueWeight
		}
		return a.JobID < b.JobID
	})
	return out
}
