package k2

// DxReady reports whether dependency prerequisites are satisfied.
func DxReady(depOn []string, done map[string]bool) bool {
	if len(depOn) == 0 {
		return true
	}
	for _, depID := range depOn {
		if !done[depID] {
			return false
		}
	}
	return true
}
