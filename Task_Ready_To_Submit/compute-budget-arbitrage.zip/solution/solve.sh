#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/credits.toml
require_file /app/data/job_specs.jsonl
require_file /app/data/runtime_overlay.csv
mkdir -p /app/bin /app/output

log "apply patched sources"
cp "${ROOT_DIR}/oracle/p2_order.go" /app/q9/p2_order.go
cp "${ROOT_DIR}/oracle/d4_hold.go" /app/k2/d4_hold.go
cp "${ROOT_DIR}/oracle/b7_slot.go" /app/h4/b7_slot.go
cp "${ROOT_DIR}/oracle/w5_roll.go" /app/z1/w5_roll.go
cp "${ROOT_DIR}/oracle/a2_fit.go" /app/u3/a2_fit.go
python3 - <<'PY'
from pathlib import Path
path = Path("/app/n8/src/lib.rs")
text = path.read_text(encoding="utf-8")
old = """    let billable = if overlay_i > 0 {
        est_i.max(act_i)
    } else if act_i > 0 {
        act_i
    } else {
        est_i.max(1)
    };"""
new = """    let billable = if drifting {
        act_i.max(1)
    } else if act_i > 0 {
        act_i
    } else {
        est_i.max(1)
    };"""
if old not in text:
    raise SystemExit("lib.rs meter span block not found")
path.write_text(text.replace(old, new, 1), encoding="utf-8")
PY

log "rebuild allocator"
bash /app/scripts/build.sh
rm -rf /app/n8/target /app/output/go-build

log "refresh default job bundle"
/app/bin/jobpack /app/data/job_specs.jsonl /app/data/jobs_default.jsonl

log "emit default arbitrage report"
/app/tools/run_arbitrage

log "post-run validation against credits.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/credits.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k in ("min_completion_rate", "max_waste_ratio", "min_value_captured"):
        cfg[k] = float(v)
    elif k.startswith("max_") or k.startswith("min_") or k == "credit_budget":
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/arbitrage_report.json").read_text())
assert report["status"] == "ok", report
assert report["completion_rate"] >= cfg["min_completion_rate"]
assert report["waste_ratio"] <= cfg["max_waste_ratio"]
assert report["dep_violations"] <= cfg["max_dep_violations"]
assert report["priority_inversions"] <= cfg["max_priority_inversions"]
assert report["burst_absorbed"] >= cfg["min_burst_absorbed"]
assert report["value_captured"] >= cfg["min_value_captured"]
for row in report["jobs"]:
    if row["job_id"].startswith("j_dep_") and row["completed"]:
        assert row["dep_ready"], row
    if row["job_id"].startswith("j_burst_"):
        assert row["completed"], row
print("ok", report["completion_rate"], report["waste_ratio"], report["value_captured"])
PY

log "oracle complete"
