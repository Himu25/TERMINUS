"""Verifier for airspace conflict resolver lab reports."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "air_report.json"
BIN = "/app/bin/air_lab"
ACTIVE_PLAN = APP / "data" / "active" / "plan.json"
STEM_INDEX = APP / "docs" / "scenario_index.txt"

SCHEMA_VERSION = 2
FINISH_COMPLETE = "complete"

REQUIRED_TOP_FIELDS = ("schema_version", "sector_id", "scenarios")
REQUIRED_ROW_FIELDS = (
    "name",
    "finish_reason",
    "conflicts_found",
    "routes_changed",
    "deadlines_met",
    "collision_free",
    "cache_valid",
    "delay_handled",
    "emergency_cleared",
    "digest_hex",
)

# PUBLIC (~70%): basic overlap, reroute, deadline, separation, chain hops, dense sector.
PUBLIC_EXPECTED = {
    "case_cross_detect": {
        "finish_reason": FINISH_COMPLETE,
        "conflicts_found": 1,
    },
    "case_reroute_simple": {
        "finish_reason": FINISH_COMPLETE,
        "collision_free": 1,
        "routes_changed": 1,
    },
    "case_deadline_hold": {
        "finish_reason": FINISH_COMPLETE,
        "deadlines_met": 1,
    },
    "case_no_touch": {
        "finish_reason": FINISH_COMPLETE,
        "collision_free": 1,
        "conflicts_found": 0,
    },
    "case_chain_reroute": {
        "finish_reason": FINISH_COMPLETE,
        "routes_changed": 2,
        "collision_free": 1,
    },
    "case_sector_dense": {
        "finish_reason": FINISH_COMPLETE,
        "collision_free": 1,
    },
}

# HIDDEN (~30%): caching invalidation, session stash leakage, emergency corridor edge cases.
HIDDEN_EXPECTED = {
    "case_weather_shift": {
        "finish_reason": FINISH_COMPLETE,
        "cache_valid": 1,
        "conflicts_found": 1,
    },
    "case_comm_delay": {
        "finish_reason": FINISH_COMPLETE,
        "delay_handled": 1,
    },
    "case_emergency_insert": {
        "finish_reason": FINISH_COMPLETE,
        "emergency_cleared": 1,
        "collision_free": 1,
    },
}


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    """Build air_lab once for the verifier session."""
    env = {**os.environ}
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _row_digest_matches_rust(row: dict) -> str:
    proc = subprocess.run(
        [
            "/app/bin/digest_cli",
            row["name"],
            row["finish_reason"],
            str(row["conflicts_found"]),
            str(row["routes_changed"]),
            str(row["deadlines_met"]),
            str(row["collision_free"]),
            str(row["cache_valid"]),
            str(row["delay_handled"]),
            str(row["emergency_cleared"]),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return proc.stdout.strip()


def _run_lab(extra_env: dict | None = None) -> dict:
    env = {
        **os.environ,
        "TB_AIR_FIXTURE": "1",
    }
    if extra_env:
        env.update(extra_env)
    subprocess.run([BIN], cwd="/app", env=env, check=True)
    return json.loads(OUT.read_text())


def _by_name(report: dict) -> dict[str, dict]:
    return {row["name"]: row for row in report["scenarios"]}


def _load_stems() -> list[str]:
    lines = STEM_INDEX.read_text().splitlines()
    return [line.strip() for line in lines if line.strip() and not line.startswith("#")]


# --- Public infrastructure ---


def test_report_schema_and_sector() -> None:
    """Report uses schema version 2 and the active sector id."""
    report = _run_lab()
    assert report["schema_version"] == SCHEMA_VERSION
    plan = json.loads(ACTIVE_PLAN.read_text())
    assert report["sector_id"] == plan["sector_id"]
    assert len(report["scenarios"]) >= 9


def test_report_contains_required_fields() -> None:
    """Top-level and per-scenario report rows include every schema field."""
    report = _run_lab()
    for field in REQUIRED_TOP_FIELDS:
        assert field in report
    for row in report["scenarios"]:
        for field in REQUIRED_ROW_FIELDS:
            assert field in row


# --- Public behavior: basic routing scenarios ---


def test_cross_detect_finds_overlap() -> None:
    """Crossing tracks at the same tick register a conflict."""
    row = _by_name(_run_lab())["case_cross_detect"]
    ex = PUBLIC_EXPECTED["case_cross_detect"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["conflicts_found"] == ex["conflicts_found"]


def test_reroute_clears_collision() -> None:
    """A lateral shift clears an overlap and marks the sector collision-free."""
    row = _by_name(_run_lab())["case_reroute_simple"]
    ex = PUBLIC_EXPECTED["case_reroute_simple"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["collision_free"] == ex["collision_free"]
    assert row["routes_changed"] == ex["routes_changed"]


def test_deadline_preserved_after_shift() -> None:
    """Deadline stem keeps deadlines_met after a small shift."""
    row = _by_name(_run_lab())["case_deadline_hold"]
    ex = PUBLIC_EXPECTED["case_deadline_hold"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["deadlines_met"] == ex["deadlines_met"]


def test_clean_paths_no_conflict() -> None:
    """Separated tracks report zero conflicts and collision_free."""
    row = _by_name(_run_lab())["case_no_touch"]
    ex = PUBLIC_EXPECTED["case_no_touch"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["conflicts_found"] == ex["conflicts_found"]
    assert row["collision_free"] == ex["collision_free"]


def test_chain_reroute_both_hops() -> None:
    """Two-hop chain reroute applies both shifts and clears the overlap."""
    row = _by_name(_run_lab())["case_chain_reroute"]
    ex = PUBLIC_EXPECTED["case_chain_reroute"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["routes_changed"] == ex["routes_changed"]
    assert row["collision_free"] == ex["collision_free"]


def test_dense_sector_complete() -> None:
    """Dense sector stem finishes without residual overlaps."""
    row = _by_name(_run_lab())["case_sector_dense"]
    ex = PUBLIC_EXPECTED["case_sector_dense"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["collision_free"] == ex["collision_free"]


# --- Hidden edge cases (not spelled out in instruction bindings) ---


def test_hidden_weather_shift_cache() -> None:
    """Caching edge: weather revision bump invalidates stale overlap memo entries."""
    row = _by_name(_run_lab())["case_weather_shift"]
    ex = HIDDEN_EXPECTED["case_weather_shift"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["cache_valid"] == ex["cache_valid"]
    assert row["conflicts_found"] == ex["conflicts_found"]


def test_hidden_comm_delay_session() -> None:
    """State-leakage edge: delayed telemetry pass clears prior stash before re-checking tracks."""
    row = _by_name(_run_lab())["case_comm_delay"]
    ex = HIDDEN_EXPECTED["case_comm_delay"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["delay_handled"] == ex["delay_handled"]


def test_hidden_emergency_corridor() -> None:
    """Cross-module edge: emergency priority insert shifts routine traffic aside."""
    row = _by_name(_run_lab())["case_emergency_insert"]
    ex = HIDDEN_EXPECTED["case_emergency_insert"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["emergency_cleared"] == ex["emergency_cleared"]
    assert row["collision_free"] == ex["collision_free"]


def test_regression_stems_complete() -> None:
    """Every stem listed in scenario_index finishes complete."""
    report = _run_lab()
    rows = _by_name(report)
    for stem in _load_stems():
        assert rows[stem]["finish_reason"] == FINISH_COMPLETE


def test_row_digests_match_helper() -> None:
    """Each scenario digest matches the digest helper."""
    report = _run_lab()
    for row in report["scenarios"]:
        assert row["digest_hex"] == _row_digest_matches_rust(row)


def test_cargo_smoke_tests_pass() -> None:
    """Workspace unit smoke tests pass after the agent fix."""
    env = {**os.environ}
    subprocess.run(
        ["cargo", "test", "--workspace", "--quiet"],
        cwd="/app",
        env=env,
        check=True,
    )
