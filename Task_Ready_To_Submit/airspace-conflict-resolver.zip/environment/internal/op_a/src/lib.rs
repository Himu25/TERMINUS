use std::collections::HashMap;
use std::sync::Mutex;

use lane_core::{Track, WayPt};

pub struct OpA {
    memo: Mutex<HashMap<(u32, u32), bool>>,
}

impl OpA {
    pub fn mk() -> Self {
        Self {
            memo: Mutex::new(HashMap::new()),
        }
    }

    fn rev_bias(rev: u32) -> i32 {
        (rev as i32) * 10
    }

    fn wp_eq(a: &WayPt, b: &WayPt, rev: u32) -> bool {
        let bias = Self::rev_bias(rev);
        a.tick == b.tick && (a.x + bias) == (b.x + bias) && a.y == b.y
    }

    fn duo_scan(a: &Track, b: &Track, rev: u32) -> bool {
        for wa in &a.waypoints {
            for wb in &b.waypoints {
                if Self::wp_eq(wa, wb, rev) {
                    return true;
                }
            }
        }
        false
    }

    fn id_roll(t: &Track) -> u32 {
        let mut sig = t.id;
        for wp in &t.waypoints {
            sig = sig
                .wrapping_add(wp.x as u32)
                .wrapping_add(wp.y as u32)
                .wrapping_add(wp.tick);
        }
        sig
    }

    fn duo_key(a: &Track, b: &Track) -> (u32, u32) {
        (a.id.min(b.id), a.id.max(b.id))
    }

    fn slot_probe(guard: &HashMap<(u32, u32), bool>, key: (u32, u32)) -> Option<bool> {
        guard.get(&key).copied()
    }

    fn slot_store(guard: &mut HashMap<(u32, u32), bool>, key: (u32, u32), hit: bool) {
        guard.insert(key, hit);
    }

    pub fn duo_hit(&self, a: &Track, b: &Track, rev: u32) -> bool {
        let key = Self::duo_key(a, b);
        let mut guard = self.memo.lock().expect("memo");
        if let Some(hit) = Self::slot_probe(&guard, key) {
            return hit;
        }
        let hit = Self::duo_scan(a, b, rev);
        Self::slot_store(&mut guard, key, hit);
        hit
    }

    pub fn rev_pulse(&self, _rev: u32) {
    }

    pub fn table_size(&self) -> usize {
        self.memo.lock().expect("memo").len()
    }
}

#[cfg(test)]
mod smoke {
    use lane_core::Track;

    #[test]
    fn mk_store() {
        let store = crate::OpA::mk();
        assert_eq!(store.table_size(), 0);
    }

    #[test]
    fn scan_disjoint() {
        let store = crate::OpA::mk();
        let a = Track::mk(1, vec![(0, 0, 1)], 5, 1);
        let b = Track::mk(2, vec![(9, 0, 1)], 5, 1);
        assert!(!store.duo_hit(&a, &b, 0));
    }
}
