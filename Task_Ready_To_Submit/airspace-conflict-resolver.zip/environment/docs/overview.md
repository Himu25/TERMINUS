The lab models sector traffic as tick-indexed waypoint tracks. Overlap detection applies
a revision-dependent zone shift. Reroute planning can chain multiple lateral hops.
Deadline checks compare arrival ticks against per-track ceilings. Session stashes record
conflict participant ids between delayed telemetry passes.

The workspace splits geometry, overlap helpers, shift utilities, orchestration, and
per-run session state across several internal crates wired through the lab driver.
Typical failure modes include stale memo reuse, broken multi-hop ownership, deadline
gate mismatches, and session ids carried into later passes.
