use std::path::Path;

use lane_core::{PathLane, Track};
use op_c::OpC;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

#[derive(Debug, Clone, Deserialize)]
pub struct Plan {
    pub sector_id: String,
    pub drone_count: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScenarioRow {
    pub name: String,
    pub finish_reason: String,
    pub conflicts_found: u32,
    pub routes_changed: u32,
    pub deadlines_met: u32,
    pub collision_free: u32,
    pub cache_valid: u32,
    pub delay_handled: u32,
    pub emergency_cleared: u32,
    pub digest_hex: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Report {
    pub schema_version: u32,
    pub sector_id: String,
    pub scenarios: Vec<ScenarioRow>,
}

pub fn load_plan(path: &Path) -> Plan {
    let raw = std::fs::read_to_string(path).expect("plan json");
    serde_json::from_str(&raw).expect("plan parse")
}

pub fn digest_row(row: &ScenarioRow) -> String {
    let payload = format!(
        "{}|{}|{}|{}|{}|{}|{}|{}|{}|",
        row.name,
        row.finish_reason,
        row.conflicts_found,
        row.routes_changed,
        row.deadlines_met,
        row.collision_free,
        row.cache_valid,
        row.delay_handled,
        row.emergency_cleared,
    );
    format!("{:x}", Sha256::digest(payload.as_bytes()))
}

fn seal(mut row: ScenarioRow) -> ScenarioRow {
    row.digest_hex = digest_row(&row);
    row
}

fn track_to_lane(track: &Track) -> PathLane {
    PathLane::from_track(track)
}

pub fn run_cross_detect(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let a = Track::mk(1, vec![(0, 0, 2), (5, 0, 4)], 10, 1);
    let b = Track::mk(2, vec![(5, 0, 4), (10, 0, 6)], 10, 1);
    let hit = core.duo_probe(&a, &b, 0);
    seal(ScenarioRow {
        name: "case_cross_detect".into(),
        finish_reason: if hit { "complete" } else { "stuck" }.into(),
        conflicts_found: if hit { 1 } else { 0 },
        routes_changed: 0,
        deadlines_met: 0,
        collision_free: 0,
        cache_valid: 0,
        delay_handled: 0,
        emergency_cleared: 0,
        digest_hex: String::new(),
    })
}

pub fn run_reroute_simple(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let a = Track::mk(1, vec![(0, 0, 2), (5, 0, 4)], 12, 1);
    let b = Track::mk(2, vec![(5, 0, 4), (10, 0, 6)], 12, 1);
    let mut lane = track_to_lane(&a);
    let hit_before = core.duo_probe(&a, &b, 0);
    core.axis_step(&mut lane, 8);
    let a2 = Track::mk(1, lane.waypoints.iter().map(|p| (p.x, p.y, p.tick)).collect(), 12, 1);
    let hit_after = core.duo_probe(&a2, &b, 0);
    let clean = hit_before && !hit_after;
    seal(ScenarioRow {
        name: "case_reroute_simple".into(),
        finish_reason: if clean { "complete" } else { "stuck" }.into(),
        conflicts_found: if hit_before { 1 } else { 0 },
        routes_changed: if clean { 1 } else { 0 },
        deadlines_met: 0,
        collision_free: if clean { 1 } else { 0 },
        cache_valid: 0,
        delay_handled: 0,
        emergency_cleared: 0,
        digest_hex: String::new(),
    })
}

pub fn run_deadline_hold(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let track = Track::mk(3, vec![(0, 0, 1), (4, 0, 5)], 8, 2);
    let mut lane = track_to_lane(&track);
    lane.slot_idx = 10;
    core.axis_step(&mut lane, 2);
    let atis = lane.waypoints.last().map(|p| p.tick).unwrap_or(0);
    let ok = core.bound_ok(atis, track.deadline_tick, lane.slot_idx);
    seal(ScenarioRow {
        name: "case_deadline_hold".into(),
        finish_reason: if ok { "complete" } else { "stuck" }.into(),
        conflicts_found: 0,
        routes_changed: 1,
        deadlines_met: if ok { 1 } else { 0 },
        collision_free: 0,
        cache_valid: 0,
        delay_handled: 0,
        emergency_cleared: 0,
        digest_hex: String::new(),
    })
}

pub fn run_no_touch(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let a = Track::mk(4, vec![(0, 0, 1), (0, 5, 3)], 10, 1);
    let b = Track::mk(5, vec![(10, 0, 1), (10, 5, 3)], 10, 1);
    let hit = core.duo_probe(&a, &b, 0);
    seal(ScenarioRow {
        name: "case_no_touch".into(),
        finish_reason: if !hit { "complete" } else { "collision" }.into(),
        conflicts_found: 0,
        routes_changed: 0,
        deadlines_met: 0,
        collision_free: if !hit { 1 } else { 0 },
        cache_valid: 0,
        delay_handled: 0,
        emergency_cleared: 0,
        digest_hex: String::new(),
    })
}

pub fn run_chain_reroute(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let a = Track::mk(6, vec![(0, 0, 2), (5, 0, 4), (10, 0, 6)], 14, 1);
    let b = Track::mk(7, vec![(5, 0, 4), (5, 5, 6)], 14, 1);
    let lane = track_to_lane(&a);
    let hit_before = core.duo_probe(&a, &b, 0);
    let (shifted, hops) = core.hop_series(lane, &[6, 4]);
    let a2 = Track::mk(
        6,
        shifted
            .waypoints
            .iter()
            .map(|p| (p.x, p.y, p.tick))
            .collect(),
        14,
        1,
    );
    let hit_after = core.duo_probe(&a2, &b, 0);
    let clean = hit_before && !hit_after && hops == 2;
    seal(ScenarioRow {
        name: "case_chain_reroute".into(),
        finish_reason: if clean { "complete" } else { "partial" }.into(),
        conflicts_found: if hit_before { 1 } else { 0 },
        routes_changed: hops,
        deadlines_met: 0,
        collision_free: if clean { 1 } else { 0 },
        cache_valid: 0,
        delay_handled: 0,
        emergency_cleared: 0,
        digest_hex: String::new(),
    })
}

pub fn run_sector_dense(plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let count = plan.drone_count.max(4);
    let mut tracks = Vec::new();
    for i in 0..count {
        let x = (i as i32) * 3;
        tracks.push(Track::mk(
            100 + i,
            vec![(x, 0, 2), (x + 2, 0, 4)],
            20,
            1,
        ));
    }
    let mut conflicts = 0u32;
    for i in 0..tracks.len() {
        for j in (i + 1)..tracks.len() {
            if core.duo_probe(&tracks[i], &tracks[j], 0) {
                conflicts += 1;
                let mut lane = track_to_lane(&tracks[i]);
                core.axis_step(&mut lane, 15);
                tracks[i] = Track::mk(
                    tracks[i].id,
                    lane
                        .waypoints
                        .iter()
                        .map(|p| (p.x, p.y, p.tick))
                        .collect(),
                    20,
                    1,
                );
            }
        }
    }
    let mut residual = 0u32;
    for i in 0..tracks.len() {
        for j in (i + 1)..tracks.len() {
            if core.duo_probe(&tracks[i], &tracks[j], 0) {
                residual += 1;
            }
        }
    }
    seal(ScenarioRow {
        name: "case_sector_dense".into(),
        finish_reason: if residual == 0 { "complete" } else { "partial" }.into(),
        conflicts_found: conflicts,
        routes_changed: conflicts,
        deadlines_met: 0,
        collision_free: if residual == 0 { 1 } else { 0 },
        cache_valid: 0,
        delay_handled: 0,
        emergency_cleared: 0,
        digest_hex: String::new(),
    })
}

pub fn run_weather_shift(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let a = Track::mk(8, vec![(0, 0, 3)], 10, 1);
    let b = Track::mk(9, vec![(10, 0, 3)], 10, 1);
    let miss_rev0 = core.duo_probe(&a, &b, 0);
    core.pulse_rev(1);
    let b_shift = Track::mk(9, vec![(0, 0, 3)], 10, 1);
    let hit_rev1 = core.duo_probe(&a, &b_shift, 1);
    let cache_ok = !miss_rev0 && hit_rev1;
    seal(ScenarioRow {
        name: "case_weather_shift".into(),
        finish_reason: if cache_ok { "complete" } else { "stuck" }.into(),
        conflicts_found: if hit_rev1 { 1 } else { 0 },
        routes_changed: 0,
        deadlines_met: 0,
        collision_free: 0,
        cache_valid: if cache_ok { 1 } else { 0 },
        delay_handled: 0,
        emergency_cleared: 0,
        digest_hex: String::new(),
    })
}

pub fn run_comm_delay(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    core.begin_run();
    let stale_a = Track::mk(11, vec![(0, 0, 2), (5, 0, 4)], 10, 1);
    let stale_b = Track::mk(12, vec![(5, 0, 4), (10, 0, 6)], 10, 1);
    if core.duo_probe(&stale_a, &stale_b, 0) {
        core.hold_ids(&[stale_a.id, stale_b.id]);
    }
    core.begin_run();
    let fresh_a = Track::mk(11, vec![(0, 0, 2), (20, 0, 4)], 10, 1);
    let fresh_b = Track::mk(12, vec![(30, 0, 4), (40, 0, 6)], 10, 1);
    let live_hit = core.duo_probe(&fresh_a, &fresh_b, 0);
    let stash = core.read_hold();
    let handled = stash.is_empty() && !live_hit;
    seal(ScenarioRow {
        name: "case_comm_delay".into(),
        finish_reason: if handled { "complete" } else { "stuck" }.into(),
        conflicts_found: if live_hit { 1 } else { 0 },
        routes_changed: 0,
        deadlines_met: 0,
        collision_free: 0,
        cache_valid: 0,
        delay_handled: if handled { 1 } else { 0 },
        emergency_cleared: 0,
        digest_hex: String::new(),
    })
}

pub fn run_emergency_insert(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let emerg = Track::mk(20, vec![(0, 0, 1), (0, 10, 3)], 6, 99);
    let routine = Track::mk(21, vec![(0, 5, 2), (0, 10, 3)], 12, 1);
    let hit_before = core.duo_probe(&emerg, &routine, 0);
    let mut lane = track_to_lane(&routine);
    if emerg.priority > routine.priority {
        core.axis_step(&mut lane, 20);
    }
    let routine2 = Track::mk(
        21,
        lane.waypoints.iter().map(|p| (p.x, p.y, p.tick)).collect(),
        12,
        1,
    );
    let hit_after = core.duo_probe(&emerg, &routine2, 0);
    let cleared = hit_before && !hit_after;
    seal(ScenarioRow {
        name: "case_emergency_insert".into(),
        finish_reason: if cleared { "complete" } else { "collision" }.into(),
        conflicts_found: if hit_before { 1 } else { 0 },
        routes_changed: if cleared { 1 } else { 0 },
        deadlines_met: 0,
        collision_free: if cleared { 1 } else { 0 },
        cache_valid: 0,
        delay_handled: 0,
        emergency_cleared: if cleared { 1 } else { 0 },
        digest_hex: String::new(),
    })
}

pub fn run_named(name: &str, plan: &Plan) -> ScenarioRow {
    match name {
        "case_cross_detect" => run_cross_detect(plan),
        "case_reroute_simple" => run_reroute_simple(plan),
        "case_deadline_hold" => run_deadline_hold(plan),
        "case_no_touch" => run_no_touch(plan),
        "case_chain_reroute" => run_chain_reroute(plan),
        "case_sector_dense" => run_sector_dense(plan),
        "case_weather_shift" => run_weather_shift(plan),
        "case_comm_delay" => run_comm_delay(plan),
        "case_emergency_insert" => run_emergency_insert(plan),
        other => seal(ScenarioRow {
            name: other.into(),
            finish_reason: "unknown".into(),
            conflicts_found: 0,
            routes_changed: 0,
            deadlines_met: 0,
            collision_free: 0,
            cache_valid: 0,
            delay_handled: 0,
            emergency_cleared: 0,
            digest_hex: String::new(),
        }),
    }
}

pub fn run_bundle(plan: &Plan, names: &[String]) -> Report {
    let scenarios = names.iter().map(|n| run_named(n, plan)).collect();
    Report {
        schema_version: 2,
        sector_id: plan.sector_id.clone(),
        scenarios,
    }
}
