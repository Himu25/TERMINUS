# Airspace conflict lab

Rust workspace under `/app` simulates sector routing with paired-track overlap checks,
chain shifts, deadline gates, and session stashes.

Rebuild with `/app/scripts/build.sh` and drive scenarios through `/app/bin/air_lab`.
Set `TB_AIR_FIXTURE=1` to include regression stems from `/app/docs/scenario_index.txt`.

Report schema lives in `/app/schemas/report.example.json`.
