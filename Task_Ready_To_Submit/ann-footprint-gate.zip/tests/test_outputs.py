"""Verifier for ann-footprint-gate."""

from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "index_bench.json"
CFG = APP / "config" / "index.toml"
RUNNER = APP / "tools" / "run_bench"
FOOTPROBE = APP / "bin" / "footprobe"
FIXTURES = Path(__file__).resolve().parent / "fixtures"

REPORT_KEYS = frozenset(
    {
        "status",
        "corpus_vectors",
        "vector_dim",
        "queries_total",
        "index_bytes",
        "raw_float_bytes",
        "compression_ratio",
        "mean_recall_at_10",
        "mean_ndcg_at_10",
        "graph_nodes",
        "graph_edges",
        "report_digest",
        "queries",
    }
)
QUERY_KEYS = frozenset({"query_id", "recall_at_10", "ndcg_at_10", "gold_hits"})

GO_BUILD_TIMEOUT = 180
BENCHD_TIMEOUT = 120
GOLDGEN_TIMEOUT = 60
PROBE_TIMEOUT = 30


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "vector_dim": 64,
        "graph_degree": 8,
        "search_ef": 32,
        "top_k": 10,
        "recall_floor": 0.85,
        "ndcg_floor": 0.75,
        "max_index_bytes": 52000,
        "min_compression_ratio": 3.2,
        "graph_min_edges_per_node": 1,
        "graph_max_spare_edges_per_node": 1,
    }
    float_keys = {"recall_floor", "ndcg_floor", "min_compression_ratio"}
    int_keys = {
        "vector_dim",
        "graph_degree",
        "search_ef",
        "top_k",
        "max_index_bytes",
        "graph_min_edges_per_node",
        "graph_max_spare_edges_per_node",
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in float_keys:
            cfg[key] = float(val)
        elif key in int_keys:
            cfg[key] = int(float(val))
    return cfg


def _round4(value: float) -> float:
    return round(value * 10000 + 0.5) / 10000


def _footprint_bytes_close(reported: int, measured: int) -> None:
    slack = max(256, int(measured * 0.05))
    assert abs(reported - measured) <= slack, (
        f"reported index_bytes {reported} != measured {measured} (slack {slack})"
    )


def _footprint_ratio_close(reported: float, measured: float) -> None:
    assert reported == pytest.approx(measured, rel=0.05, abs=0.1)


def _expected_means(rows: list[dict]) -> tuple[float, float]:
    if not rows:
        return 0.0, 0.0
    total = len(rows)
    recall = sum(row["recall_at_10"] for row in rows) / total
    ndcg = sum(row["ndcg_at_10"] for row in rows) / total
    return _round4(recall), _round4(ndcg)


def _digest_payload(report: dict) -> dict:
    return {
        "status": report["status"],
        "corpus_vectors": report["corpus_vectors"],
        "vector_dim": report["vector_dim"],
        "queries_total": report["queries_total"],
        "index_bytes": report["index_bytes"],
        "raw_float_bytes": report["raw_float_bytes"],
        "compression_ratio": report["compression_ratio"],
        "mean_recall_at_10": report["mean_recall_at_10"],
        "mean_ndcg_at_10": report["mean_ndcg_at_10"],
        "graph_nodes": report["graph_nodes"],
        "graph_edges": report["graph_edges"],
        "report_digest": "",
        "queries": report["queries"],
    }


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _assert_query_row(row: dict) -> None:
    assert set(row) == QUERY_KEYS
    assert isinstance(row["query_id"], str) and row["query_id"]
    assert isinstance(row["recall_at_10"], (int, float))
    assert isinstance(row["ndcg_at_10"], (int, float))
    assert isinstance(row["gold_hits"], int)
    assert 0.0 <= float(row["recall_at_10"]) <= 1.0
    assert 0.0 <= float(row["ndcg_at_10"]) <= 1.0
    assert row["gold_hits"] >= 0


def _assert_report_schema(data: dict) -> None:
    assert set(data) == REPORT_KEYS
    assert isinstance(data["status"], str) and data["status"] in {"ok", "fail"}
    for int_key in (
        "corpus_vectors",
        "vector_dim",
        "queries_total",
        "index_bytes",
        "raw_float_bytes",
        "graph_nodes",
        "graph_edges",
    ):
        assert isinstance(data[int_key], int), int_key
        assert data[int_key] >= 0, int_key
    for float_key in ("compression_ratio", "mean_recall_at_10", "mean_ndcg_at_10"):
        assert isinstance(data[float_key], (int, float)), float_key
        assert float(data[float_key]) >= 0.0, float_key
    digest = data["report_digest"]
    assert isinstance(digest, str) and len(digest) == 64
    assert digest == digest.lower()
    assert re.fullmatch(r"[0-9a-f]{64}", digest)
    assert isinstance(data["queries"], list)
    for row in data["queries"]:
        _assert_query_row(row)


def _load_report(path: Path = OUT) -> dict:
    assert path.is_file(), f"missing report at {path}"
    data = json.loads(path.read_text(encoding="utf-8"))
    _assert_report_schema(data)
    return data


def _assert_ok_default(report: dict) -> None:
    cfg = _parse_cfg()
    assert report["status"] == "ok"
    assert report["mean_recall_at_10"] >= cfg["recall_floor"]
    assert report["mean_ndcg_at_10"] >= cfg["ndcg_floor"]
    assert report["index_bytes"] <= cfg["max_index_bytes"]
    assert report["compression_ratio"] >= cfg["min_compression_ratio"]


def _rebuild_tools(env: dict[str, str] | None = None) -> None:
    env = env or os.environ.copy()
    for name in ("benchd", "footprobe"):
        proc = subprocess.run(
            [
                "go",
                "build",
                "-o",
                str(APP / "bin" / name),
                str(APP / "cmd" / name),
            ],
            cwd=APP,
            env=env,
            capture_output=True,
            text=True,
            timeout=GO_BUILD_TIMEOUT,
        )
        if proc.returncode != 0:
            raise subprocess.CalledProcessError(
                proc.returncode,
                proc.args,
                proc.stdout,
                proc.stderr,
            )


def _goldgen(corpus_path: Path, specs_path: Path, out_path: Path) -> None:
    subprocess.run(
        [
            "/app/bin/goldgen",
            corpus_path.as_posix(),
            specs_path.as_posix(),
            out_path.as_posix(),
        ],
        check=True,
        capture_output=True,
        text=True,
        timeout=GOLDGEN_TIMEOUT,
    )


def _footprint_probe(corpus_path: Path | None = None) -> dict[str, int]:
    env = os.environ.copy()
    if corpus_path is not None:
        env["TB_CORPUS_PATH"] = str(corpus_path)
    else:
        env.pop("TB_CORPUS_PATH", None)
    proc = subprocess.run(
        [FOOTPROBE.as_posix()],
        cwd=APP,
        env=env,
        check=True,
        capture_output=True,
        text=True,
        timeout=PROBE_TIMEOUT,
    )
    payload = json.loads(proc.stdout.strip())
    assert set(payload) == {"index_bytes", "raw_float_bytes"}
    return payload


def _run_bench(
    query_path: Path,
    out_path: Path = OUT,
    corpus_path: Path | None = None,
) -> None:
    env = os.environ.copy()
    if corpus_path is not None:
        env["TB_CORPUS_PATH"] = str(corpus_path)
    else:
        env.pop("TB_CORPUS_PATH", None)
    if out_path.exists():
        out_path.unlink()
    subprocess.run(
        [
            "/app/bin/benchd",
            query_path.as_posix(),
            out_path.as_posix(),
        ],
        cwd=APP,
        env=env,
        check=True,
        capture_output=True,
        text=True,
        timeout=BENCHD_TIMEOUT,
    )


@pytest.fixture(scope="session")
def cfg() -> dict[str, float | int]:
    return _parse_cfg()


@pytest.fixture(scope="session", autouse=True)
def _default_bench_run() -> None:
    _rebuild_tools()
    _goldgen(
        APP / "data" / "corpus_default.json",
        APP / "data" / "query_specs.jsonl",
        APP / "data" / "queries_default.jsonl",
    )
    _run_bench(APP / "data" / "queries_default.jsonl")


@pytest.fixture(scope="session")
def default_report() -> dict:
    return _load_report()


@pytest.fixture(scope="session")
def default_probe() -> dict[str, int]:
    return _footprint_probe(APP / "data" / "corpus_default.json")


def test_runner_exists() -> None:
    """Documented bench driver is present and executable."""
    assert RUNNER.is_file() and os.access(RUNNER, os.X_OK)
    assert FOOTPROBE.is_file() and os.access(FOOTPROBE, os.X_OK)


def test_report_schema_and_default_gates(default_report: dict, cfg: dict) -> None:
    """Default report matches the contract schema and clears guardrail floors."""
    report = default_report
    _assert_ok_default(report)
    assert report["queries_total"] == len(report["queries"])
    expected_lines = sum(
        1
        for line in (APP / "data" / "queries_default.jsonl")
        .read_text(encoding="utf-8")
        .splitlines()
        if line.strip()
    )
    assert report["queries_total"] == expected_lines
    manifest = json.loads((APP / "registry" / "shard_manifest.json").read_text(encoding="utf-8"))
    assert report["corpus_vectors"] == manifest["count"]
    assert report["vector_dim"] == manifest["dim"]


def test_footprint_matches_live_storage(
    default_report: dict,
    default_probe: dict[str, int],
    cfg: dict,
) -> None:
    """Footprint fields track measured packed storage, not float64 echo buffers."""
    report = default_report
    probe = default_probe
    measured_ratio = probe["raw_float_bytes"] / probe["index_bytes"]
    assert probe["index_bytes"] <= cfg["max_index_bytes"]
    assert measured_ratio >= cfg["min_compression_ratio"]
    assert probe["index_bytes"] < probe["raw_float_bytes"]
    _footprint_bytes_close(report["index_bytes"], probe["index_bytes"])
    assert report["raw_float_bytes"] == probe["raw_float_bytes"]
    _footprint_ratio_close(report["compression_ratio"], measured_ratio)


def test_graph_edge_budget(default_report: dict, cfg: dict) -> None:
    """Graph stores neighbor indices without inline vector payloads on edges."""
    report = default_report
    nodes = report["graph_nodes"]
    edges = report["graph_edges"]
    assert nodes == report["corpus_vectors"]
    assert edges >= nodes * cfg["graph_min_edges_per_node"]
    assert edges <= nodes * cfg["graph_degree"] + nodes * cfg["graph_max_spare_edges_per_node"]


def test_summary_means_recomputed_from_query_rows(default_report: dict) -> None:
    """Mean recall and ndcg must match per-query rows."""
    report = default_report
    want_recall, want_ndcg = _expected_means(report["queries"])
    assert report["mean_recall_at_10"] == pytest.approx(want_recall, abs=2e-4)
    assert report["mean_ndcg_at_10"] == pytest.approx(want_ndcg, abs=2e-4)


def test_report_digest_matches_body(default_report: dict) -> None:
    """report_digest is SHA-256 of the compact pre-digest payload."""
    report = default_report
    assert report["report_digest"] == _expected_digest(report)


def test_repeat_run_byte_identical(default_report: dict) -> None:
    """Back-to-back default runs emit identical report bytes."""
    _assert_ok_default(default_report)
    first = OUT.read_bytes()
    _run_bench(APP / "data" / "queries_default.jsonl")
    second = OUT.read_bytes()
    assert first == second


def test_dense_corpus_regression_pack(cfg: dict) -> None:
    """Alternate dense corpus still meets footprint and recall guardrails."""
    manifest = json.loads((APP / "registry" / "shard_manifest.json").read_text(encoding="utf-8"))
    pack = FIXTURES / manifest["regression_pack"]
    out = APP / "output" / f"bench_{pack.name}.json"
    specs = pack / "query_specs.jsonl"
    queries = pack / specs.name.replace("specs", "queries")
    corpus_path = pack / "corpus.json"
    _goldgen(corpus_path, specs, queries)
    _run_bench(queries, out, corpus_path)
    report = _load_report(out)
    probe = _footprint_probe(corpus_path)
    dense_count = len(json.loads(corpus_path.read_text(encoding="utf-8"))["vectors"])
    assert report["status"] == "ok"
    assert report["corpus_vectors"] >= dense_count
    assert report["mean_recall_at_10"] >= cfg["recall_floor"]
    assert report["compression_ratio"] >= cfg["min_compression_ratio"]
    _footprint_bytes_close(report["index_bytes"], probe["index_bytes"])
    assert report["raw_float_bytes"] == probe["raw_float_bytes"]
