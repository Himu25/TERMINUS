package m7

import "math"

type Packed struct {
	ID    string
	Codes []int8
	Scale float64
}

type Bank struct {
	Rows []Packed
}

func QkStore(id string, vec []float64) Packed {
	scale := QkPeak(vec)
	if scale == 0 {
		scale = 1
	}
	codes := make([]int8, len(vec))
	for i, x := range vec {
		codes[i] = int8(math.Round(x / scale * 127))
	}
	return Packed{ID: id, Codes: codes, Scale: scale}
}

func (b *Bank) QkAdd(id string, vec []float64) {
	b.Rows = append(b.Rows, QkStore(id, vec))
}

func (p Packed) QkOpen() []float64 {
	out := make([]float64, len(p.Codes))
	for i, c := range p.Codes {
		out[i] = float64(c) / 127.0 * p.Scale
	}
	return out
}

func (b Bank) QkSpan(dim int) int {
	n := len(b.Rows)
	if n == 0 {
		return 0
	}
	return n*(dim+8) + 16
}

func NxBase(n, dim int) int {
	return n * dim * 8
}

func QkFold(raw, packed int) float64 {
	if packed <= 0 {
		return 0
	}
	return float64(raw) / float64(packed)
}

func QkPeak(v []float64) float64 {
	m := 0.0
	for _, x := range v {
		if ax := math.Abs(x); ax > m {
			m = ax
		}
	}
	return m
}

func ClipBand(v []float64, lo, hi float64) []float64 {
	if len(v) == 0 {
		return nil
	}
	out := make([]float64, len(v))
	for i, x := range v {
		switch {
		case x < lo:
			out[i] = lo
		case x > hi:
			out[i] = hi
		default:
			out[i] = x
		}
	}
	return out
}

func RescaleRow(v []float64, target float64) []float64 {
	m := QkPeak(v)
	if m == 0 {
		return v
	}
	out := make([]float64, len(v))
	f := target / m
	for i, x := range v {
		out[i] = x * f
	}
	return out
}
