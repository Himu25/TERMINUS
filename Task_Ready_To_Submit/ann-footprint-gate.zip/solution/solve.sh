#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '[oracle] %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight: index workspace"
require_file /app/go.mod
require_file /app/config/index.toml
require_file /app/data/corpus_default.json
require_file /app/data/queries_default.jsonl
require_file /app/m7/k2_cells.go
require_file /app/lattice/h3_build.go
require_file /app/s4/p4_ann.go
mkdir -p /app/bin /app/output

log "survey: guardrails before repair"
grep -nE 'recall|ndcg|index_bytes|compression' /app/config/index.toml /app/metrics/guardrails.txt 2>/dev/null | head -n 12 || true
wc -l /app/m7/k2_cells.go /app/lattice/h3_build.go /app/s4/p4_ann.go

log "apply packed vector lane fix"
patch -p1 < "${ROOT_DIR}/patches/kbox.patch"

log "apply neighbor link table fix"
patch -p1 < "${ROOT_DIR}/patches/mlink.patch"

log "apply query s4 ranking fix"
patch -p1 < "${ROOT_DIR}/patches/qseek.patch"

log "regenerate query gold ids with repaired codec + embed lane"
go run ./cmd/goldgen /app/data/corpus_default.json /app/data/query_specs.jsonl /app/data/queries_default.jsonl

log "rebuild bench driver and emit default index bench report"
go build -o /app/bin/benchd ./cmd/benchd
/app/tools/run_bench /app/data/queries_default.jsonl /app/output/index_bench.json

log "sanity: report status and footprint"
python3 - <<'PY'
import json
p = "/app/output/index_bench.json"
r = json.load(open(p))
assert r["status"] == "ok", r
assert r["index_bytes"] <= 52000, r["index_bytes"]
assert r["compression_ratio"] >= 3.2, r["compression_ratio"]
assert r["mean_recall_at_10"] >= 0.85, r["mean_recall_at_10"]
print("ok", r["index_bytes"], r["compression_ratio"], r["mean_recall_at_10"])
PY

log "oracle complete"
