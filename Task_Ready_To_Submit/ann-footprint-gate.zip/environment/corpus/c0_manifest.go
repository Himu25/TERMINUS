package corpus

import (
	"encoding/json"
	"os"
)

type Manifest struct {
	Shard string `json:"shard"`
	Count int    `json:"count"`
}

func ReadManifest(path string) (Manifest, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return Manifest{}, err
	}
	var m Manifest
	return m, json.Unmarshal(raw, &m)
}
