package bench

import (
	"annfp.lab/lattice"
	"annfp.lab/m7"
)

func indexByteSpan(bank m7.Bank, g *lattice.Graph, dim int) int {
	return bank.QkSpan(dim) + g.LxOverhead()
}
