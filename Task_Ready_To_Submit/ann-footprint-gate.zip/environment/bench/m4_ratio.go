package bench

import "annfp.lab/m7"

func rawAndFold(n, dim, indexBytes int) (int, float64) {
	raw := m7.NxBase(n, dim)
	return raw, m7.QkFold(raw, indexBytes)
}
