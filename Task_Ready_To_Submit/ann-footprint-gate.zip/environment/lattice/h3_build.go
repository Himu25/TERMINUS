package lattice

import (
	"sort"

	"annfp.lab/m7"
	"annfp.lab/embed"
)

type Edge struct {
	Neighbor int
	Payload  []float64
}

type Node struct {
	ID    int
	Edges []Edge
}

type Graph struct {
	Nodes []Node
	Dim   int
}

func LxWire(bank m7.Bank, degree int) *Graph {
	g := &Graph{Dim: 0}
	if len(bank.Rows) == 0 {
		return g
	}
	g.Dim = len(bank.Rows[0].Data)
	vecs := make([][]float64, len(bank.Rows))
	for i, row := range bank.Rows {
		vecs[i] = row.QkOpen()
	}
	g.Nodes = make([]Node, len(bank.Rows))
	for i := range bank.Rows {
		type scored struct {
			j     int
			score float64
		}
		pairs := make([]scored, 0, len(vecs)-1)
		for j, v := range vecs {
			if i == j {
				continue
			}
			pairs = append(pairs, scored{j: j, score: embed.Dot(vecs[i], v)})
		}
		sort.Slice(pairs, func(a, b int) bool {
			return pairs[a].score > pairs[b].score
		})
		limit := degree
		if limit > len(pairs) {
			limit = len(pairs)
		}
		edges := make([]Edge, 0, limit)
		for k := 0; k < limit; k++ {
			j := pairs[k].j
			payload := make([]float64, len(vecs[j]))
			copy(payload, vecs[j])
			edges = append(edges, Edge{Neighbor: j, Payload: payload})
		}
		g.Nodes[i] = Node{ID: i, Edges: edges}
	}
	return g
}

func (g *Graph) Tally() (nodes, edges int) {
	nodes = len(g.Nodes)
	for _, n := range g.Nodes {
		edges += len(n.Edges)
	}
	return nodes, edges
}

func (g *Graph) LxOverhead() int {
	total := 0
	for _, n := range g.Nodes {
		for _, e := range n.Edges {
			total += 8 + len(e.Payload)*8
		}
	}
	return total
}
