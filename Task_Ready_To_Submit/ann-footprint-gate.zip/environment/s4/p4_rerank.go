package s4

import "annfp.lab/embed"

func RerankDot(query, doc []float64) float64 {
	return embed.Dot(query, doc)
}
