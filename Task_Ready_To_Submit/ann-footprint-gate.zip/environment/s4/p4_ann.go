package s4

import (
	"sort"

	"annfp.lab/m7"
	"annfp.lab/embed"
	"annfp.lab/lattice"
)

func PxScan(query []float64, bank m7.Bank, g *lattice.Graph, topK int, ef int) []int {
	_ = ef
	_ = g
	type scored struct {
		idx   int
		score float64
	}
	pairs := make([]scored, 0, len(bank.Rows))
	half := len(query) / 2
	if half <= 0 {
		half = len(query)
	}
	qSlice := query[:half]
	for i, row := range bank.Rows {
		vec := row.QkOpen()
		if len(vec) > half {
			vec = vec[:half]
		}
		pairs = append(pairs, scored{idx: i, score: embed.Dot(qSlice, vec)})
	}
	sort.Slice(pairs, func(i, j int) bool {
		return pairs[i].score < pairs[j].score
	})
	if topK <= 0 || topK > len(pairs) {
		topK = len(pairs)
	}
	out := make([]int, 0, topK)
	for i := 0; i < topK; i++ {
		out = append(out, pairs[i].idx)
	}
	return out
}
