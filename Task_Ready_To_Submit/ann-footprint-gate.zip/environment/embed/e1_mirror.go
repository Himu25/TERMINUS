package embed

// Mirror path keeps an alternate tokenization helper for experiments; not on the hot index path.
func MirrorTokens(text string) []string {
	return lexSplit(text)
}
