module annfp.lab

go 1.22
