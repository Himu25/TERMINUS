package types

type CorpusDoc struct {
	ID    string `json:"id"`
	Label string `json:"label"`
	Text  string `json:"text"`
}

type CorpusFile struct {
	Vectors []CorpusDoc `json:"vectors"`
}

type QueryCase struct {
	QueryID string   `json:"query_id"`
	Query   string   `json:"query"`
	GoldIDs []string `json:"gold_ids"`
}

type QueryRow struct {
	QueryID     string  `json:"query_id"`
	RecallAt10  float64 `json:"recall_at_10"`
	NdcgAt10    float64 `json:"ndcg_at_10"`
	GoldHits    int     `json:"gold_hits"`
}

type BenchReport struct {
	Status            string     `json:"status"`
	CorpusVectors     int        `json:"corpus_vectors"`
	VectorDim         int        `json:"vector_dim"`
	QueriesTotal      int        `json:"queries_total"`
	IndexBytes        int        `json:"index_bytes"`
	RawFloatBytes    int        `json:"raw_float_bytes"`
	CompressionRatio  float64    `json:"compression_ratio"`
	MeanRecallAt10    float64    `json:"mean_recall_at_10"`
	MeanNdcgAt10      float64    `json:"mean_ndcg_at_10"`
	GraphNodes        int        `json:"graph_nodes"`
	GraphEdges        int        `json:"graph_edges"`
	ReportDigest      string     `json:"report_digest"`
	Queries           []QueryRow `json:"queries"`
}

type IndexCfg struct {
	VectorDim            int
	GraphDegree          int
	SearchEF             int
	TopK                 int
	RecallFloor          float64
	NdcgFloor            float64
	MaxIndexBytes        int
	MinCompressionRatio  float64
	CorpusPath               string
	TightSecurityRecallFloor float64
}
