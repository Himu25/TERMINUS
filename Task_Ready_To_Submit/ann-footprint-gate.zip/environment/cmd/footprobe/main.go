package main

import (
	"encoding/json"
	"fmt"
	"os"
	"reflect"

	"annfp.lab/bench"
	"annfp.lab/corpus"
	"annfp.lab/embed"
	"annfp.lab/lattice"
	"annfp.lab/m7"
)

func sliceBytes(v reflect.Value) int {
	if v.Kind() != reflect.Slice || v.Len() == 0 {
		return 0
	}
	return v.Len() * int(v.Type().Elem().Size())
}

func structStorageBytes(v reflect.Value) int {
	total := 0
	for i := 0; i < v.NumField(); i++ {
		f := v.Field(i)
		switch f.Kind() {
		case reflect.Slice:
			total += sliceBytes(f)
		case reflect.Float64:
			total += 8
		case reflect.Int, reflect.Int8, reflect.Int32, reflect.Int64, reflect.Uint8, reflect.Uint32, reflect.Uint64:
			total += int(f.Type().Size())
		}
	}
	return total
}

func measureBank(b m7.Bank) int {
	rows := reflect.ValueOf(b).FieldByName("Rows")
	total := 16
	for i := 0; i < rows.Len(); i++ {
		total += structStorageBytes(rows.Index(i))
	}
	return total
}

func measureGraph(g *lattice.Graph) int {
	total := 0
	nodes := reflect.ValueOf(g).Elem().FieldByName("Nodes")
	for i := 0; i < nodes.Len(); i++ {
		edges := nodes.Index(i).FieldByName("Edges")
		for j := 0; j < edges.Len(); j++ {
			total += structStorageBytes(edges.Index(j))
		}
	}
	return total
}

func main() {
	cfg, err := bench.LoadCfg("/app/config/index.toml")
	if err != nil {
		fmt.Fprintf(os.Stderr, "config: %v\n", err)
		os.Exit(1)
	}
	if override := os.Getenv("TB_CORPUS_PATH"); override != "" {
		cfg.CorpusPath = override
	}
	docs, err := corpus.Load(cfg.CorpusPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "corpus: %v\n", err)
		os.Exit(1)
	}
	bank := m7.Bank{}
	for _, doc := range docs {
		vec := embed.VecFromText(doc.Text, cfg.VectorDim)
		bank.QkAdd(doc.ID, vec)
	}
	g := lattice.LxWire(bank, cfg.GraphDegree)
	indexBytes := measureBank(bank) + measureGraph(g)
	rawBytes := len(docs) * cfg.VectorDim * 8
	out, err := json.Marshal(map[string]int{
		"index_bytes":     indexBytes,
		"raw_float_bytes": rawBytes,
	})
	if err != nil {
		fmt.Fprintf(os.Stderr, "marshal: %v\n", err)
		os.Exit(1)
	}
	fmt.Println(string(out))
}
