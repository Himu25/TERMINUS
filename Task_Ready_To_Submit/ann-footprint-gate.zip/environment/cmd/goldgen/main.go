package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"sort"

	"annfp.lab/corpus"
	"annfp.lab/m7"
	"annfp.lab/embed"
)

type specRow struct {
	QueryID string `json:"query_id"`
	Query   string `json:"query"`
}

type outRow struct {
	QueryID string   `json:"query_id"`
	Query   string   `json:"query"`
	GoldIDs []string `json:"gold_ids"`
}

func main() {
	if len(os.Args) < 4 {
		fmt.Fprintf(os.Stderr, "usage: goldgen <corpus.json> <specs.jsonl> <out.jsonl>\n")
		os.Exit(2)
	}
	docs, err := corpus.Load(os.Args[1])
	if err != nil {
		panic(err)
	}
	dim := 64
	bank := m7.Bank{}
	ids := make([]string, 0, len(docs))
	for _, doc := range docs {
		vec := embed.VecFromText(doc.Text, dim)
		bank.QkAdd(doc.ID, vec)
		ids = append(ids, doc.ID)
	}
	specs, err := loadSpecs(os.Args[2])
	if err != nil {
		panic(err)
	}
	out, err := os.Create(os.Args[3])
	if err != nil {
		panic(err)
	}
	defer out.Close()
	for _, spec := range specs {
		qv := embed.VecFromText(spec.Query, dim)
		type scored struct {
			idx   int
			score float64
		}
		pairs := make([]scored, 0, len(bank.Rows))
		for i, row := range bank.Rows {
			pairs = append(pairs, scored{idx: i, score: embed.Dot(qv, row.QkOpen())})
		}
		sort.Slice(pairs, func(i, j int) bool {
			return pairs[i].score > pairs[j].score
		})
		gold := make([]string, 0, 3)
		for i := 0; i < 3 && i < len(pairs); i++ {
			gold = append(gold, ids[pairs[i].idx])
		}
		row := outRow{QueryID: spec.QueryID, Query: spec.Query, GoldIDs: gold}
		raw, _ := json.Marshal(row)
		_, _ = out.Write(raw)
		_, _ = out.Write([]byte("\n"))
	}
}

func loadSpecs(path string) ([]specRow, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]specRow, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := sc.Text()
		if line == "" {
			continue
		}
		var row specRow
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return nil, err
		}
		out = append(out, row)
	}
	return out, sc.Err()
}
