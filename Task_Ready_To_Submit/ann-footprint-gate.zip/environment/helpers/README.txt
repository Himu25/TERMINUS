Helper scripts are not wired into benchd. Use tools/run_bench as the supported driver.
Rebuild query gold ids with /app/bin/goldgen when the embed or packed vector lane changes.
Rebuild /app/bin/footprobe from annfp.lab/cmd/footprobe when measuring live struct storage.
