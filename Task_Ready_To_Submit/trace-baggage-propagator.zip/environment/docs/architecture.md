# Continuity lab layout

The replay driver at `/app/cmd/trace_lab` loads case bundles from JSONL files and exercises HTTP and gRPC inbound carriers against profile limits in `/app/profiles/default.json`. Shared wire types live under `/app/pkg/frame`. Percent-encoding helpers sit in `/app/pkg/codec`.

OpenTelemetry TextMap wiring is in `/app/pkg/oteliface`. Report digests hash boolean summary fields only. Example report layout is in `/app/schemas/report.example.json`.

Build with `/app/scripts/build.sh`. Go unit tests run under `/app`.
