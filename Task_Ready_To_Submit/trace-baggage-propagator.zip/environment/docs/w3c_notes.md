W3C trace context headers use lowercase names in this lab. Baggage members are comma-separated key=value pairs with percent-encoded keys and values. Tracestate vendor lists allow backslash-escaped commas inside values.

HTTP obs-fold joins continuation lines before parsing slot headers.
