module lab.local/trace_baggage_propagator

go 1.22
