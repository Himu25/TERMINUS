package harness

import (
	"encoding/json"
	"os"
)

// CaseSpec describes one replay bundle.
type CaseSpec struct {
	CaseID         string            `json:"case_id"`
	Kind           string            `json:"kind"`
	Parent         string            `json:"parent"`
	State          string            `json:"state"`
	Slot           string            `json:"slot"`
	FoldedLines    []string          `json:"folded_lines"`
	Metadata       map[string]string `json:"metadata"`
	ExpectItems    int               `json:"expect_items"`
	ExpectPass     bool              `json:"expect_pass"`
	ExpectDedupKey string            `json:"expect_dedup_key"`
	ExpectDedupVal string            `json:"expect_dedup_val"`
	ExpectVersion  bool              `json:"expect_version_clash"`
	ExpectMaxBytes    int    `json:"expect_max_bytes"`
	ExpectStateCount  int    `json:"expect_state_entries"`
	ExpectStateValue  string `json:"expect_state_value"`
	ExpectStateKey    string `json:"expect_state_key"`
	Notes             string `json:"notes"`
}

// LoadCases reads a JSONL case file.
func LoadCases(path string) ([]CaseSpec, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var out []CaseSpec
	for _, line := range splitLines(raw) {
		if len(line) == 0 {
			continue
		}
		var c CaseSpec
		if err := json.Unmarshal(line, &c); err != nil {
			return nil, err
		}
		out = append(out, c)
	}
	return out, nil
}

func splitLines(b []byte) [][]byte {
	var lines [][]byte
	start := 0
	for i := 0; i < len(b); i++ {
		if b[i] == '\n' {
			lines = append(lines, b[start:i])
			start = i + 1
		}
	}
	if start < len(b) {
		lines = append(lines, b[start:])
	}
	return lines
}
