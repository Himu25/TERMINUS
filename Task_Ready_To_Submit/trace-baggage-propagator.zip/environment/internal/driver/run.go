package driver

import (
	"encoding/json"
	"os"
	"path/filepath"

	"lab.local/trace_baggage_propagator/internal/harness"
	"lab.local/trace_baggage_propagator/pkg/frame"
	"lab.local/trace_baggage_propagator/pkg/oteliface"
	"lab.local/trace_baggage_propagator/pkg/cx"
	"lab.local/trace_baggage_propagator/pkg/fold"
	"lab.local/trace_baggage_propagator/pkg/report"
)

// Profile holds limits from /app/profiles/default.json.
type Profile struct {
	MaxItems    int `json:"max_items"`
	MaxBytes    int `json:"max_bytes"`
	DenseItems  int `json:"dense_items"`
}

// LoadProfile reads profile JSON.
func LoadProfile(root string) (Profile, error) {
	raw, err := os.ReadFile(filepath.Join(root, "profiles", "default.json"))
	if err != nil {
		return Profile{}, err
	}
	var p Profile
	return p, json.Unmarshal(raw, &p)
}

// RunSuite executes cases and returns a lab report.
func RunSuite(root, casesPath, suiteID string) (report.LabReport, error) {
	prof, err := LoadProfile(root)
	if err != nil {
		return report.LabReport{}, err
	}
	cases, err := harness.LoadCases(casesPath)
	if err != nil {
		return report.LabReport{}, err
	}

	rep := report.LabReport{
		SchemaVersion: "1",
		SuiteID:       suiteID,
	}
	opts := fold.ParseOpts{MaxItems: prof.MaxItems, MaxBytes: prof.MaxBytes}

	httpOK := true
	grpcOK := true
	headerOK := true
	dedupOK := true
	versionOK := true
	zeroHeap := true
	maxItems := 0

	for _, spec := range cases {
		row, pass, diag := runCase(spec, opts, prof)
		rep.Cases = append(rep.Cases, row)
		if pass {
			rep.CasesPassed++
		}
		if spec.Kind == "http" && !pass {
			httpOK = false
		}
		if spec.Kind == "grpc" && !pass {
			grpcOK = false
		}
		if !diag.headerLimit {
			headerOK = false
		}
		if !diag.dedup {
			dedupOK = false
		}
		if !diag.version {
			versionOK = false
		}
		if !diag.zeroHeap {
			zeroHeap = false
		}
		if row.ItemsSeen > maxItems {
			maxItems = row.ItemsSeen
		}
	}

	rep.CasesTotal = len(cases)
	rep.HTTPRoundtripOK = httpOK
	rep.GRPCRoundtripOK = grpcOK
	rep.MaxBaggageItems = maxItems
	rep.HeaderLimitOK = headerOK
	rep.DedupPolicyOK = dedupOK
	rep.VersionCheckOK = versionOK
	rep.ZeroParseHeap = zeroHeap
	return rep, nil
}

type diagFlags struct {
	headerLimit bool
	dedup       bool
	version     bool
	zeroHeap    bool
}

func runCase(spec harness.CaseSpec, opts fold.ParseOpts, prof Profile) (report.CaseRow, bool, diagFlags) {
	row := report.CaseRow{CaseID: spec.CaseID, Notes: spec.Notes}
	d := diagFlags{headerLimit: true, dedup: true, version: true, zeroHeap: true}

	var slotBuf [128]frame.SlotEntry
	var parent frame.ParentLayout
	var states []frame.StateEntry
	var slots fold.ParseResult
	var ok bool

	switch spec.Kind {
	case "http":
		carrier := oteliface.MapCarrier{}
		if len(spec.FoldedLines) > 0 {
			joined := cx.FoldJoin(spec.FoldedLines)
			carrier[fold.SlotKey()] = joined
		} else {
			carrier[fold.ParentKey()] = spec.Parent
			carrier[fold.StateKey()] = spec.State
			carrier[fold.SlotKey()] = spec.Slot
		}
		parent, states, slots, ok = cx.OpH(carrier, slotBuf[:], opts)
	case "grpc":
		meta := oteliface.MetadataCarrier{}
		for k, v := range spec.Metadata {
			meta[k] = v
		}
		parent, states, slots, ok = cx.OpG(meta, slotBuf[:], opts)
	default:
		row.Passed = false
		row.Notes = "unknown kind"
		return row, false, d
	}

	if !ok {
		row.Passed = false
		return row, false, d
	}

	row.ItemsSeen = len(slots.Entries)
	if spec.ExpectItems > 0 && row.ItemsSeen != spec.ExpectItems {
		ok = false
	}

	if spec.ExpectStateCount > 0 {
		if len(states) != spec.ExpectStateCount {
			ok = false
		}
		if spec.ExpectStateKey != "" {
			found := false
			for _, s := range states {
				if string(s.Key) == spec.ExpectStateKey && string(s.Value) == spec.ExpectStateValue {
					found = true
					break
				}
			}
			if !found {
				ok = false
			}
		}
	}

	if spec.ExpectDedupKey != "" {
		found := false
		for _, e := range slots.Entries {
			if string(e.Key) == spec.ExpectDedupKey && string(e.Value) == spec.ExpectDedupVal {
				found = true
				break
			}
		}
		if !found {
			ok = false
			d.dedup = false
		}
	}

	if spec.ExpectVersion {
		if !slots.VersionClash {
			ok = false
			d.version = false
		}
	} else if slots.VersionClash {
		ok = false
		d.version = false
	}

	if slots.HeapUsed {
		d.zeroHeap = false
		if spec.ExpectItems >= prof.DenseItems {
			ok = false
		}
	}

	if spec.ExpectMaxBytes > 0 {
		var enc [1024]byte
		encoded, encOK := fold.EncodeSlots(slots.Entries, enc[:0], spec.ExpectMaxBytes)
		row.HeaderBytes = len(encoded)
		if !encOK || len(encoded) > spec.ExpectMaxBytes {
			ok = false
			d.headerLimit = false
		}
	}

	_ = parent
	_ = states

	row.Passed = ok && spec.ExpectPass
	return row, row.Passed, d
}

// Emit writes report to path.
func Emit(path string, rep report.LabReport) error {
	return report.WriteJSON(path, rep)
}

// RunActive runs the active bundle under /app/data/active.
func RunActive(root string) (report.LabReport, error) {
	return RunSuite(root, filepath.Join(root, "data", "active", "cases.jsonl"), "active")
}
