#!/usr/bin/env bash
set -euo pipefail
cd /app
bash /app/scripts/build.sh
TB_TRACE_FIXTURE=1 /app/bin/trace_lab >/dev/null
test -s /app/output/propagator_report.json
