#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/go/bin:${PATH}"
export GOFLAGS="-mod=mod"
export CGO_ENABLED=0
export GOCACHE="${GOCACHE:-/app/output/go-build}"
export GOTMPDIR="${GOTMPDIR:-/tmp}"

install -d -m 0777 /app/bin /app/output /app/output/go-build

cd /app
go build -trimpath -ldflags="-s -w" -o /app/bin/trace_lab ./cmd/trace_lab
go build -trimpath -ldflags="-s -w" -o /app/bin/digest_cli ./tools/digest_cli
