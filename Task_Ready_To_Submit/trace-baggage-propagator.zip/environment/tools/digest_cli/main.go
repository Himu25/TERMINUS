package main

import (
	"fmt"
	"os"

	"lab.local/trace_baggage_propagator/pkg/frame"
)

func main() {
	args := os.Args[1:]
	parts := make([]interface{}, len(args))
	for i, a := range args {
		parts[i] = a
	}
	fmt.Print(frame.WireDigest(parts...))
}
