digest_cli prints lowercase hex SHA-256 of pipe-joined arguments.
