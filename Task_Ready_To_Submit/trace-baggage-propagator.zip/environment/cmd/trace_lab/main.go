// Report JSON for /app/output/propagator_report.json:
//
// schema_version — string, always "1"
// suite_id — string, echoes active bundle name
// http_roundtrip_ok — boolean, all HTTP-kind cases passed
// grpc_roundtrip_ok — boolean, all gRPC-kind cases passed
// cases_total — count of case rows executed
// cases_passed — count of case rows with passed true
// max_baggage_items — largest items_seen across cases
// header_limit_ok — boolean, encoded slot headers respected profile byte ceiling
// dedup_policy_ok — boolean, duplicate keys kept last value
// version_check_ok — boolean, parent/state version clashes detected when expected
// zero_parse_heap — boolean, dense slot bundles parsed without heap growth
// digest_hex — lowercase hex SHA-256 of schema_version|suite_id|http_roundtrip_ok|grpc_roundtrip_ok|cases_total|cases_passed|max_baggage_items|header_limit_ok|dedup_policy_ok|version_check_ok|zero_parse_heap
// cases — array of {case_id, passed, items_seen, header_bytes, notes}
//
// Root object contains only these keys.
package main

import (
	"log"
	"os"

	"lab.local/trace_baggage_propagator/internal/driver"
)

func main() {
	if os.Getenv("TB_TRACE_FIXTURE") != "1" {
		log.Fatal("TB_TRACE_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.Emit("/app/output/propagator_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
