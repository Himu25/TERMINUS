package oteliface

// TextMapCarrier is the minimal propagation surface used by the lab harness.
type TextMapCarrier interface {
	Get(key string) string
	Set(key string, value string)
	Keys() []string
}

// MapCarrier is a string map adapter.
type MapCarrier map[string]string

func (c MapCarrier) Get(key string) string { return c[key] }
func (c MapCarrier) Set(key string, value string) {
	c[key] = value
}
func (c MapCarrier) Keys() []string {
	out := make([]string, 0, len(c))
	for k := range c {
		out = append(out, k)
	}
	return out
}

// MetadataCarrier adapts gRPC-style lower-case metadata keys.
type MetadataCarrier map[string]string

func (c MetadataCarrier) Get(key string) string { return c[string(key)] }
func (c MetadataCarrier) Set(key string, value string) {
	c[string(key)] = value
}
func (c MetadataCarrier) Keys() []string {
	out := make([]string, 0, len(c))
	for k := range c {
		out = append(out, k)
	}
	return out
}
