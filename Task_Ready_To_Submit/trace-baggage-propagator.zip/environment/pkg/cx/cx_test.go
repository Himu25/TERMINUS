package cx_test

import (
	"testing"

	"lab.local/trace_baggage_propagator/pkg/cx"
	"lab.local/trace_baggage_propagator/pkg/frame"
	"lab.local/trace_baggage_propagator/pkg/oteliface"
	"lab.local/trace_baggage_propagator/pkg/fold"
)

func TestFoldJoinMergesLines(t *testing.T) {
	got := cx.FoldJoin([]string{"a=1,", " b=2"})
	if got != "a=1, b=2" {
		t.Fatalf("fold join wrong: %q", got)
	}
}

func TestOpGUsesMetadataKeys(t *testing.T) {
	meta := oteliface.MetadataCarrier{
		"traceparent": "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01",
		"tracestate":  "",
		"baggage":     "x=1",
	}
	var buf [8]frame.SlotEntry
	_, _, slots, ok := cx.OpG(meta, buf[:], fold.ParseOpts{MaxItems: 8, MaxBytes: 512})
	if !ok || len(slots.Entries) != 1 {
		t.Fatalf("grpc extract failed ok=%v entries=%d", ok, len(slots.Entries))
	}
}

func TestOpHDetectsVersionClash(t *testing.T) {
	c := oteliface.MapCarrier{
		fold.ParentKey(): "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01",
		fold.StateKey():  "ot=2",
	}
	var buf [8]frame.SlotEntry
	_, _, slots, ok := cx.OpH(c, buf[:], fold.ParseOpts{MaxItems: 8, MaxBytes: 512})
	if !ok || !slots.VersionClash {
		t.Fatal("expected version clash")
	}
}
