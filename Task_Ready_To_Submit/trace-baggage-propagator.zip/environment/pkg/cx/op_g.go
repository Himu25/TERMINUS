package cx

import (
	"strings"

	"lab.local/trace_baggage_propagator/pkg/frame"
	"lab.local/trace_baggage_propagator/pkg/oteliface"
	"lab.local/trace_baggage_propagator/pkg/fold"
)

// OpG extracts fields from gRPC metadata carrier keys.
func OpG(c oteliface.TextMapCarrier, slotBuf []frame.SlotEntry, opts fold.ParseOpts) (frame.ParentLayout, []frame.StateEntry, fold.ParseResult, bool) {
	parentRaw := c.Get("grpc-trace-bin")
	stateRaw := c.Get("grpc-trace-state")
	slotRaw := c.Get("grpc-baggage-bin")

	parent := fold.OpT([]byte(parentRaw))
	var stateDst [64]frame.StateEntry
	states, ok := fold.OpS([]byte(stateRaw), stateDst[:])
	if !ok {
		return parent, nil, fold.ParseResult{}, false
	}
	slots, ok := fold.OpB([]byte(slotRaw), slotBuf, opts)
	if !ok {
		return parent, nil, fold.ParseResult{}, false
	}
	return parent, states, slots, true
}

// InjectGRPC writes propagation fields using metadata key names.
func InjectGRPC(c oteliface.TextMapCarrier, parent frame.ParentLayout, states []frame.StateEntry, slots []frame.SlotEntry, maxBytes int) bool {
	if !parent.Valid {
		return false
	}
	var pbuf [64]byte
	pwire := formatParent(parent, pbuf[:0])
	c.Set("grpc-trace-bin", string(pwire))

	var sbuf [512]byte
	swire, ok := formatState(states, sbuf[:0])
	if !ok {
		return false
	}
	c.Set("grpc-trace-state", string(swire))

	var dbuf [1024]byte
	dwire, ok := fold.EncodeSlots(slots, dbuf[:0], maxBytes)
	if !ok {
		return false
	}
	c.Set("grpc-baggage-bin", string(dwire))
	return true
}

// NormalizeMeta lowercases metadata keys for lookup.
func NormalizeMeta(key string) string {
	return strings.ToLower(key)
}
