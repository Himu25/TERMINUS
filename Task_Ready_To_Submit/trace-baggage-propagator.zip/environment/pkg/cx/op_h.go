package cx

import (
	"strings"

	"lab.local/trace_baggage_propagator/pkg/frame"
	"lab.local/trace_baggage_propagator/pkg/oteliface"
	"lab.local/trace_baggage_propagator/pkg/fold"
)

// FoldJoin merges folded header lines per RFC 7230 obs-fold rules.
func FoldJoin(lines []string) string {
	if len(lines) == 0 {
		return ""
	}
	return strings.TrimSpace(lines[0])
}

// OpH extracts parent, state, and slot fields from an HTTP carrier.
func OpH(c oteliface.TextMapCarrier, slotBuf []frame.SlotEntry, opts fold.ParseOpts) (frame.ParentLayout, []frame.StateEntry, fold.ParseResult, bool) {
	parentRaw := c.Get(fold.ParentKey())
	stateRaw := c.Get(fold.StateKey())
	slotRaw := c.Get(fold.SlotKey())

	parent := fold.OpT([]byte(parentRaw))
	var stateDst [64]frame.StateEntry
	states, ok := fold.OpS([]byte(stateRaw), stateDst[:])
	if !ok {
		return parent, nil, fold.ParseResult{}, false
	}
	slots, ok := fold.OpB([]byte(slotRaw), slotBuf, opts)
	if !ok {
		return parent, nil, fold.ParseResult{}, false
	}
	return parent, states, slots, true
}

// InjectHTTP writes parent/state/slot into carrier.
func InjectHTTP(c oteliface.TextMapCarrier, parent frame.ParentLayout, states []frame.StateEntry, slots []frame.SlotEntry, maxBytes int) bool {
	if !parent.Valid {
		return false
	}
	var pbuf [64]byte
	pwire := formatParent(parent, pbuf[:0])
	c.Set(fold.ParentKey(), string(pwire))

	var sbuf [512]byte
	swire, ok := formatState(states, sbuf[:0])
	if !ok {
		return false
	}
	c.Set(fold.StateKey(), string(swire))

	var dbuf [1024]byte
	dwire, ok := fold.EncodeSlots(slots, dbuf[:0], maxBytes)
	if !ok {
		return false
	}
	c.Set(fold.SlotKey(), string(dwire))
	return true
}

func formatParent(p frame.ParentLayout, dst []byte) []byte {
	dst = append(dst, p.Version...)
	dst = append(dst, '-')
	dst = appendHex(dst, p.TraceID[:])
	dst = append(dst, '-')
	dst = appendHex(dst, p.SpanID[:])
	dst = append(dst, '-')
	dst = appendHexByte(dst, p.Flags)
	return dst
}

func formatState(states []frame.StateEntry, dst []byte) ([]byte, bool) {
	for i, s := range states {
		if i > 0 {
			dst = append(dst, ',')
		}
		dst = append(dst, s.Key...)
		dst = append(dst, '=')
		dst = append(dst, s.Value...)
	}
	return dst, true
}

func appendHex(dst, src []byte) []byte {
	const hexd = "0123456789abcdef"
	for _, b := range src {
		dst = append(dst, hexd[b>>4], hexd[b&0x0f])
	}
	return dst
}

func appendHexByte(dst []byte, b byte) []byte {
	const hexd = "0123456789abcdef"
	return append(dst, hexd[b>>4], hexd[b&0x0f])
}
