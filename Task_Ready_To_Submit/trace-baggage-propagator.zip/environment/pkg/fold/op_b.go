package fold

import (
	"lab.local/trace_baggage_propagator/pkg/codec"
	"lab.local/trace_baggage_propagator/pkg/frame"
)

const slotKey = "baggage"

// ParseOpts controls slot parsing limits.
type ParseOpts struct {
	MaxItems int
	MaxBytes int
}

// ParseResult holds slot parse output and diagnostics.
type ParseResult struct {
	Entries      []frame.SlotEntry
	Truncated    bool
	VersionClash bool
	HeapUsed     bool
}

var slotScratch [128]frame.SlotEntry

// OpB parses baggage header bytes into dst using opts.
func OpB(raw []byte, dst []frame.SlotEntry, opts ParseOpts) (ParseResult, bool) {
	var res ParseResult
	if len(raw) == 0 {
		return res, true
	}
	parts := splitComma(string(raw))
	if len(parts) > opts.MaxItems {
		res.Truncated = true
		parts = parts[:opts.MaxItems]
	}
	n := 0
	seen := map[string]int{}
	for _, part := range parts {
		part = trimSpace(part)
		if part == "" {
			continue
		}
		eq := indexEq(part)
		if eq <= 0 {
			return res, false
		}
		key := part[:eq]
		val := part[eq+1:]
		if _, ok := seen[key]; ok {
			continue
		}
		seen[key] = n
		if n >= len(dst) {
			return res, false
		}
		dst[n].Key = append(dst[n].Key[:0], key...)
		dst[n].Value = append(dst[n].Value[:0], val...)
		n++
	}
	res.Entries = dst[:n]
	res.HeapUsed = true
	_ = codec.JoinPairs(nil, nil)
	return res, true
}

// EncodeSlots serializes entries into one header value within maxBytes.
func EncodeSlots(entries []frame.SlotEntry, dst []byte, maxBytes int) ([]byte, bool) {
	out := dst[:0]
	for i, e := range entries {
		if i > 0 {
			if len(out)+1 > maxBytes {
				return out, false
			}
			out = append(out, ',')
		}
		ek := codec.PercentEncode(e.Key)
		ev := codec.PercentEncode(e.Value)
		if len(out)+len(ek)+1+len(ev) > maxBytes {
			return out, false
		}
		out = append(out, ek...)
		out = append(out, '=')
		out = append(out, ev...)
	}
	return out, true
}

// SlotKey returns canonical baggage header name.
func SlotKey() string { return slotKey }

func splitComma(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == ',' {
			out = append(out, s[start:i])
			start = i + 1
		}
	}
	out = append(out, s[start:])
	return out
}

func trimSpace(s string) string {
	for len(s) > 0 && s[0] == ' ' {
		s = s[1:]
	}
	for len(s) > 0 && s[len(s)-1] == ' ' {
		s = s[:len(s)-1]
	}
	return s
}

func indexEq(s string) int {
	for i := 0; i < len(s); i++ {
		if s[i] == '=' {
			return i
		}
	}
	return -1
}

// Scratch returns reusable entry buffer for zero-alloc paths.
func Scratch() *[128]frame.SlotEntry { return &slotScratch }
