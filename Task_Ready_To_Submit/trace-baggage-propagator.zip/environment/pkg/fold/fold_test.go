package fold_test

import (
	"testing"

	"lab.local/trace_baggage_propagator/pkg/fold"
	"lab.local/trace_baggage_propagator/pkg/frame"
)

func TestOpTParsesValidParent(t *testing.T) {
	raw := []byte("00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01")
	p := fold.OpT(raw)
	if !p.Valid || p.Version != "00" {
		t.Fatalf("expected valid parent, got %+v", p)
	}
}

func TestOpSPreservesEscapedComma(t *testing.T) {
	raw := []byte("v1=b\\,c,v2=d")
	var buf [8]frame.StateEntry
	entries, ok := fold.OpS(raw, buf[:])
	if !ok || len(entries) != 2 {
		t.Fatalf("expected 2 entries, got %d ok=%v", len(entries), ok)
	}
	if string(entries[0].Value) != "b,c" {
		t.Fatalf("escaped comma lost: %q", entries[0].Value)
	}
}

func TestOpBDedupLastWins(t *testing.T) {
	raw := []byte("a=1,a=2,b=3")
	var buf [8]frame.SlotEntry
	opts := fold.ParseOpts{MaxItems: 8, MaxBytes: 512}
	res, ok := fold.OpB(raw, buf[:], opts)
	if !ok {
		t.Fatal("parse failed")
	}
	if len(res.Entries) != 2 {
		t.Fatalf("expected 2 entries, got %d", len(res.Entries))
	}
	if string(res.Entries[0].Key) == "a" && string(res.Entries[0].Value) != "2" {
		t.Fatalf("dedup policy wrong: %+v", res.Entries)
	}
}

func TestOpBDecodesPercent(t *testing.T) {
	raw := []byte("k=on%3D1")
	var buf [4]frame.SlotEntry
	res, ok := fold.OpB(raw, buf[:], fold.ParseOpts{MaxItems: 4, MaxBytes: 512})
	if !ok || len(res.Entries) != 1 {
		t.Fatal("parse failed")
	}
	if string(res.Entries[0].Value) != "on=1" {
		t.Fatalf("decode failed: %q", res.Entries[0].Value)
	}
}

func TestOpBNoHeapOnDense(t *testing.T) {
	var raw []byte
	for i := 0; i < 100; i++ {
		if i > 0 {
			raw = append(raw, ',')
		}
		if i < 10 {
			raw = append(raw, byte('0'+i), '=', 'v')
		} else {
			raw = append(raw, byte('0'+i/10), byte('0'+i%10), '=', 'v')
		}
	}
	var buf [128]frame.SlotEntry
	res, ok := fold.OpB(raw, buf[:], fold.ParseOpts{MaxItems: 100, MaxBytes: 512})
	if !ok || res.HeapUsed || len(res.Entries) != 100 {
		t.Fatalf("dense parse heapUsed=%v ok=%v count=%d", res.HeapUsed, ok, len(res.Entries))
	}
}
