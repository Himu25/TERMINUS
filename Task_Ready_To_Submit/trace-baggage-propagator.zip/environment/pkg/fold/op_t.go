package fold

import (
	"bytes"
	"lab.local/trace_baggage_propagator/pkg/frame"
)

const parentKey = "traceparent"
const stateKey = "tracestate"

// OpT parses a traceparent header value from raw bytes.
func OpT(raw []byte) frame.ParentLayout {
	var out frame.ParentLayout
	parts := bytes.Split(raw, []byte{'-'})
	if len(parts) != 4 {
		return out
	}
	out.Version = string(parts[0])
	if len(parts[1]) != 32 || len(parts[2]) != 16 {
		return out
	}
	copy(out.TraceID[:], parts[1])
	copy(out.SpanID[:], parts[2])
	if len(parts[3]) >= 2 {
		var f byte
		for i := 0; i < 2; i++ {
			f = f<<4 | nibble(parts[3][i])
		}
		out.Flags = f
	}
	out.Valid = true
	return out
}

func nibble(b byte) byte {
	switch {
	case b >= '0' && b <= '9':
		return b - '0'
	case b >= 'a' && b <= 'f':
		return b - 'a' + 10
	case b >= 'A' && b <= 'F':
		return b - 'A' + 10
	default:
		return 0
	}
}

// OpS parses tracestate list members from raw bytes.
func OpS(raw []byte, dst []frame.StateEntry) ([]frame.StateEntry, bool) {
	if len(raw) == 0 {
		return dst[:0], true
	}
	chunks := bytes.Split(raw, []byte{','})
	n := 0
	for _, chunk := range chunks {
		chunk = bytes.TrimSpace(chunk)
		if len(chunk) == 0 {
			continue
		}
		eq := bytes.IndexByte(chunk, '=')
		if eq <= 0 {
			return dst[:0], false
		}
		if n >= len(dst) {
			return dst[:0], false
		}
		dst[n].Key = append(dst[n].Key[:0], chunk[:eq]...)
		dst[n].Value = append(dst[n].Value[:0], chunk[eq+1:]...)
		n++
	}
	return dst[:n], true
}

// ParentKey returns the canonical parent header name.
func ParentKey() string { return parentKey }

// StateKey returns the canonical state header name.
func StateKey() string { return stateKey }
