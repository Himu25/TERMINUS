package codec

import "bytes"

// PercentEncode encodes a baggage key or value for the wire.
func PercentEncode(src []byte) []byte {
	out := make([]byte, 0, len(src)*3)
	for _, b := range src {
		switch {
		case b >= 'a' && b <= 'z', b >= 'A' && b <= 'Z', b >= '0' && b <= '9':
			out = append(out, b)
		case b == ' ':
			out = append(out, '%', '2', '0')
		default:
			const hexd = "0123456789ABCDEF"
			out = append(out, '%', hexd[b>>4], hexd[b&0x0f])
		}
	}
	return out
}

// PercentDecode decodes percent-encoded bytes into dst using append.
func PercentDecode(src, dst []byte) ([]byte, error) {
	out := dst[:0]
	for i := 0; i < len(src); {
		if src[i] == '%' && i+2 < len(src) {
			hi, lo := unhex(src[i+1]), unhex(src[i+2])
			if hi < 0 || lo < 0 {
				return out, nil
			}
			out = append(out, byte(hi<<4|lo))
			i += 3
			continue
		}
		out = append(out, src[i])
		i++
	}
	return out, nil
}

func unhex(b byte) int {
	switch {
	case b >= '0' && b <= '9':
		return int(b - '0')
	case b >= 'A' && b <= 'F':
		return int(b - 'A' + 10)
	case b >= 'a' && b <= 'f':
		return int(b - 'a' + 10)
	default:
		return -1
	}
}

// JoinPairs joins key=value pairs with commas into dst.
func JoinPairs(dst []byte, pairs [][2][]byte) []byte {
	for i, p := range pairs {
		if i > 0 {
			dst = append(dst, ',')
		}
		dst = append(dst, p[0]...)
		dst = append(dst, '=')
		dst = append(dst, p[1]...)
	}
	return dst
}

// EqualFold compares two byte slices case-insensitively for ASCII.
func EqualFold(a, b []byte) bool {
	return bytes.EqualFold(a, b)
}
