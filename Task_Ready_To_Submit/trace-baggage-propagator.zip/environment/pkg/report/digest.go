package report

import (
	"encoding/json"
	"os"

	"lab.local/trace_baggage_propagator/pkg/frame"
)

// CaseRow is one scenario outcome.
type CaseRow struct {
	CaseID      string `json:"case_id"`
	Passed      bool   `json:"passed"`
	ItemsSeen   int    `json:"items_seen"`
	HeaderBytes int    `json:"header_bytes"`
	Notes       string `json:"notes"`
}

// LabReport is the JSON written to /app/output/propagator_report.json.
type LabReport struct {
	SchemaVersion    string    `json:"schema_version"`
	SuiteID          string    `json:"suite_id"`
	HTTPRoundtripOK  bool      `json:"http_roundtrip_ok"`
	GRPCRoundtripOK  bool      `json:"grpc_roundtrip_ok"`
	CasesTotal       int       `json:"cases_total"`
	CasesPassed      int       `json:"cases_passed"`
	MaxBaggageItems  int       `json:"max_baggage_items"`
	HeaderLimitOK    bool      `json:"header_limit_ok"`
	DedupPolicyOK    bool      `json:"dedup_policy_ok"`
	VersionCheckOK   bool      `json:"version_check_ok"`
	ZeroParseHeap    bool      `json:"zero_parse_heap"`
	DigestHex        string    `json:"digest_hex"`
	Cases            []CaseRow `json:"cases"`
}

// Digest computes digest_hex for rep.
func Digest(rep LabReport) string {
	return frame.WireDigest(
		rep.SchemaVersion,
		rep.SuiteID,
		rep.HTTPRoundtripOK,
		rep.GRPCRoundtripOK,
		rep.CasesTotal,
		rep.CasesPassed,
		rep.MaxBaggageItems,
		rep.HeaderLimitOK,
		rep.DedupPolicyOK,
		rep.VersionCheckOK,
		rep.ZeroParseHeap,
	)
}

// WriteJSON persists rep to path.
func WriteJSON(path string, rep LabReport) error {
	rep.DigestHex = Digest(rep)
	data, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	data = append(data, '\n')
	return os.WriteFile(path, data, 0o644)
}
