package frame

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
)

// WireDigest hashes report fields for digest_hex.
func WireDigest(parts ...interface{}) string {
	h := sha256.New()
	for _, p := range parts {
		fmt.Fprintf(h, "%v|", p)
	}
	return hex.EncodeToString(h.Sum(nil))
}

// ParentLayout holds parsed parent header fields.
type ParentLayout struct {
	Version string
	TraceID [16]byte
	SpanID  [8]byte
	Flags   byte
	Valid   bool
}

// StateEntry is one vendor list member.
type StateEntry struct {
	Key   []byte
	Value []byte
}

// SlotEntry is one baggage member.
type SlotEntry struct {
	Key   []byte
	Value []byte
}
