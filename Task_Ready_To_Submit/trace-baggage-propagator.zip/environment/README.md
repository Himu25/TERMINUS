Continuity propagation lab for mesh ingress replay.

Run `/app/bin/trace_lab` with `TB_TRACE_FIXTURE=1` after building. Profile limits live under `/app/profiles`.
