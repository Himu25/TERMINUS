#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/pkg/fold/op_t.go <<'EOF'
package fold

import (
	"bytes"
	"lab.local/trace_baggage_propagator/pkg/frame"
)

const parentKey = "traceparent"
const stateKey = "tracestate"

func OpT(raw []byte) frame.ParentLayout {
	var out frame.ParentLayout
	parts := bytes.Split(raw, []byte{'-'})
	if len(parts) != 4 {
		return out
	}
	out.Version = string(parts[0])
	if len(parts[1]) != 32 || len(parts[2]) != 16 {
		return out
	}
	copy(out.TraceID[:], parts[1])
	copy(out.SpanID[:], parts[2])
	if len(parts[3]) >= 2 {
		var f byte
		for i := 0; i < 2; i++ {
			f = f<<4 | nibble(parts[3][i])
		}
		out.Flags = f
	}
	out.Valid = true
	return out
}

func nibble(b byte) byte {
	switch {
	case b >= '0' && b <= '9':
		return b - '0'
	case b >= 'a' && b <= 'f':
		return b - 'a' + 10
	case b >= 'A' && b <= 'F':
		return b - 'A' + 10
	default:
		return 0
	}
}

func OpS(raw []byte, dst []frame.StateEntry) ([]frame.StateEntry, bool) {
	if len(raw) == 0 {
		return dst[:0], true
	}
	n := 0
	i := 0
	for i <= len(raw) {
		start := i
		for i < len(raw) {
			if raw[i] == ',' {
				if i == 0 || raw[i-1] != '\\' {
					break
				}
			}
			i++
		}
		chunk := bytes.TrimSpace(raw[start:i])
		if len(chunk) > 0 {
			eq := bytes.IndexByte(chunk, '=')
			if eq <= 0 {
				return dst[:0], false
			}
			if n >= len(dst) {
				return dst[:0], false
			}
			key := chunk[:eq]
			val := chunk[eq+1:]
			val = unescapeComma(val)
			dst[n].Key = append(dst[n].Key[:0], key...)
			dst[n].Value = append(dst[n].Value[:0], val...)
			n++
		}
		if i >= len(raw) {
			break
		}
		i++
	}
	return dst[:n], true
}

func unescapeComma(b []byte) []byte {
	out := b[:0]
	for i := 0; i < len(b); i++ {
		if b[i] == '\\' && i+1 < len(b) && b[i+1] == ',' {
			out = append(out, ',')
			i++
			continue
		}
		out = append(out, b[i])
	}
	return out
}

func ParentKey() string { return parentKey }
func StateKey() string { return stateKey }
EOF

cat > /app/pkg/fold/op_b.go <<'EOF'
package fold

import (
	"bytes"
	"lab.local/trace_baggage_propagator/pkg/codec"
	"lab.local/trace_baggage_propagator/pkg/frame"
)

const slotKey = "baggage"

type ParseOpts struct {
	MaxItems int
	MaxBytes int
}

type ParseResult struct {
	Entries      []frame.SlotEntry
	Truncated    bool
	VersionClash bool
	HeapUsed     bool
}

var slotScratch [128]frame.SlotEntry
var keyScratch [256]byte
var valScratch [256]byte

func OpB(raw []byte, dst []frame.SlotEntry, opts ParseOpts) (ParseResult, bool) {
	var res ParseResult
	if len(raw) == 0 {
		return res, true
	}
	count := 0
	i := 0
	for i <= len(raw) && count < len(dst) {
		start := i
		for i < len(raw) {
			if raw[i] == ',' {
				break
			}
			i++
		}
		chunk := bytes.TrimSpace(raw[start:i])
		if len(chunk) > 0 {
			eq := bytes.IndexByte(chunk, '=')
			if eq <= 0 {
				return res, false
			}
			keyDec, err := codec.PercentDecode(chunk[:eq], keyScratch[:0])
			if err != nil {
				return res, false
			}
			valDec, err := codec.PercentDecode(chunk[eq+1:], valScratch[:0])
			if err != nil {
				return res, false
			}
			idx := -1
			for j := 0; j < count; j++ {
				if bytes.Equal(dst[j].Key, keyDec) {
					idx = j
					break
				}
			}
			if idx >= 0 {
				dst[idx].Value = append(dst[idx].Value[:0], valDec...)
			} else {
				if count >= opts.MaxItems {
					res.Truncated = true
					break
				}
				dst[count].Key = append(dst[count].Key[:0], keyDec...)
				dst[count].Value = append(dst[count].Value[:0], valDec...)
				count++
			}
		}
		if i >= len(raw) {
			break
		}
		i++
	}
	res.Entries = dst[:count]
	res.HeapUsed = false
	return res, true
}

func EncodeSlots(entries []frame.SlotEntry, dst []byte, maxBytes int) ([]byte, bool) {
	out := dst[:0]
	for i, e := range entries {
		if i > 0 {
			if len(out)+1 > maxBytes {
				return out, false
			}
			out = append(out, ',')
		}
		ek := codec.PercentEncode(e.Key)
		ev := codec.PercentEncode(e.Value)
		if len(out)+len(ek)+1+len(ev) > maxBytes {
			return out, false
		}
		out = append(out, ek...)
		out = append(out, '=')
		out = append(out, ev...)
	}
	return out, true
}

func SlotKey() string { return slotKey }
func Scratch() *[128]frame.SlotEntry { return &slotScratch }
EOF

cat > /app/pkg/cx/op_h.go <<'EOF'
package cx

import (
	"strings"

	"lab.local/trace_baggage_propagator/pkg/frame"
	"lab.local/trace_baggage_propagator/pkg/oteliface"
	"lab.local/trace_baggage_propagator/pkg/fold"
)

func FoldJoin(lines []string) string {
	if len(lines) == 0 {
		return ""
	}
	var b strings.Builder
	for i, ln := range lines {
		ln = strings.TrimSpace(ln)
		if i == 0 {
			b.WriteString(ln)
			continue
		}
		if !strings.HasPrefix(ln, " ") && !strings.HasPrefix(ln, "\t") {
			b.WriteByte(' ')
		}
		b.WriteString(strings.TrimSpace(ln))
	}
	return b.String()
}

func OpH(c oteliface.TextMapCarrier, slotBuf []frame.SlotEntry, opts fold.ParseOpts) (frame.ParentLayout, []frame.StateEntry, fold.ParseResult, bool) {
	parentRaw := c.Get(fold.ParentKey())
	stateRaw := c.Get(fold.StateKey())
	slotRaw := c.Get(fold.SlotKey())

	parent := fold.OpT([]byte(parentRaw))
	var stateDst [64]frame.StateEntry
	states, ok := fold.OpS([]byte(stateRaw), stateDst[:])
	if !ok {
		return parent, nil, fold.ParseResult{}, false
	}
	slots, ok := fold.OpB([]byte(slotRaw), slotBuf, opts)
	if !ok {
		return parent, nil, fold.ParseResult{}, false
	}
	slots.VersionClash = detectVersionClash(parent, states)
	return parent, states, slots, true
}

func detectVersionClash(parent frame.ParentLayout, states []frame.StateEntry) bool {
	if !parent.Valid || parent.Version != "00" {
		return false
	}
	for _, s := range states {
		if string(s.Key) == "ot" && string(s.Value) != "1" && len(s.Value) > 0 {
			return true
		}
	}
	return false
}

func InjectHTTP(c oteliface.TextMapCarrier, parent frame.ParentLayout, states []frame.StateEntry, slots []frame.SlotEntry, maxBytes int) bool {
	if !parent.Valid {
		return false
	}
	var pbuf [64]byte
	pwire := formatParent(parent, pbuf[:0])
	c.Set(fold.ParentKey(), string(pwire))

	var sbuf [512]byte
	swire, ok := formatState(states, sbuf[:0])
	if !ok {
		return false
	}
	c.Set(fold.StateKey(), string(swire))

	var dbuf [1024]byte
	dwire, ok := fold.EncodeSlots(slots, dbuf[:0], maxBytes)
	if !ok {
		return false
	}
	c.Set(fold.SlotKey(), string(dwire))
	return true
}

func formatParent(p frame.ParentLayout, dst []byte) []byte {
	dst = append(dst, p.Version...)
	dst = append(dst, '-')
	dst = appendHex(dst, p.TraceID[:])
	dst = append(dst, '-')
	dst = appendHex(dst, p.SpanID[:])
	dst = append(dst, '-')
	dst = appendHexByte(dst, p.Flags)
	return dst
}

func formatState(states []frame.StateEntry, dst []byte) ([]byte, bool) {
	for i, s := range states {
		if i > 0 {
			dst = append(dst, ',')
		}
		dst = append(dst, s.Key...)
		dst = append(dst, '=')
		dst = append(dst, s.Value...)
	}
	return dst, true
}

func appendHex(dst, src []byte) []byte {
	const hexd = "0123456789abcdef"
	for _, b := range src {
		dst = append(dst, hexd[b>>4], hexd[b&0x0f])
	}
	return dst
}

func appendHexByte(dst []byte, b byte) []byte {
	const hexd = "0123456789abcdef"
	return append(dst, hexd[b>>4], hexd[b&0x0f])
}
EOF

cat > /app/pkg/cx/op_g.go <<'EOF'
package cx

import (
	"strings"

	"lab.local/trace_baggage_propagator/pkg/frame"
	"lab.local/trace_baggage_propagator/pkg/oteliface"
	"lab.local/trace_baggage_propagator/pkg/fold"
)

func OpG(c oteliface.TextMapCarrier, slotBuf []frame.SlotEntry, opts fold.ParseOpts) (frame.ParentLayout, []frame.StateEntry, fold.ParseResult, bool) {
	parentRaw := c.Get("traceparent")
	stateRaw := c.Get("tracestate")
	slotRaw := c.Get("baggage")

	parent := fold.OpT([]byte(parentRaw))
	var stateDst [64]frame.StateEntry
	states, ok := fold.OpS([]byte(stateRaw), stateDst[:])
	if !ok {
		return parent, nil, fold.ParseResult{}, false
	}
	slots, ok := fold.OpB([]byte(slotRaw), slotBuf, opts)
	if !ok {
		return parent, nil, fold.ParseResult{}, false
	}
	slots.VersionClash = detectVersionClash(parent, states)
	return parent, states, slots, true
}

func InjectGRPC(c oteliface.TextMapCarrier, parent frame.ParentLayout, states []frame.StateEntry, slots []frame.SlotEntry, maxBytes int) bool {
	if !parent.Valid {
		return false
	}
	var pbuf [64]byte
	pwire := formatParent(parent, pbuf[:0])
	c.Set("traceparent", string(pwire))

	var sbuf [512]byte
	swire, ok := formatState(states, sbuf[:0])
	if !ok {
		return false
	}
	c.Set("tracestate", string(swire))

	var dbuf [1024]byte
	dwire, ok := fold.EncodeSlots(slots, dbuf[:0], maxBytes)
	if !ok {
		return false
	}
	c.Set("baggage", string(dwire))
	return true
}

func NormalizeMeta(key string) string {
	return strings.ToLower(key)
}
EOF

bash /app/scripts/build.sh

rm -f /app/output/propagator_report.json
mkdir -p /app/output
TB_TRACE_FIXTURE=1 /app/bin/trace_lab
test -s /app/output/propagator_report.json

GOFLAGS=-mod=mod go test ./...
