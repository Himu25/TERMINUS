"""Verifier for W3C trace context and baggage propagation lab."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "propagator_report.json"
ACTIVE = APP / "data" / "active" / "cases.jsonl"
FIXTURES = Path("/tests") / "fixtures"
PROFILE = APP / "profiles" / "default.json"
INDEX = APP / "docs" / "fixture_index.txt"

REPORT_KEYS = frozenset(
    {
        "schema_version",
        "suite_id",
        "http_roundtrip_ok",
        "grpc_roundtrip_ok",
        "cases_total",
        "cases_passed",
        "max_baggage_items",
        "header_limit_ok",
        "dedup_policy_ok",
        "version_check_ok",
        "zero_parse_heap",
        "digest_hex",
        "cases",
    }
)
CASE_KEYS = frozenset({"case_id", "passed", "items_seen", "header_bytes", "notes"})


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {**os.environ, "GOFLAGS": "-mod=mod", "CGO_ENABLED": "0"}
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _digest(rep: dict) -> str:
    def _wire(v: object) -> str:
        if isinstance(v, bool):
            return "true" if v else "false"
        return str(v)

    parts = [
        _wire(rep["schema_version"]),
        _wire(rep["suite_id"]),
        _wire(rep["http_roundtrip_ok"]),
        _wire(rep["grpc_roundtrip_ok"]),
        _wire(rep["cases_total"]),
        _wire(rep["cases_passed"]),
        _wire(rep["max_baggage_items"]),
        _wire(rep["header_limit_ok"]),
        _wire(rep["dedup_policy_ok"]),
        _wire(rep["version_check_ok"]),
        _wire(rep["zero_parse_heap"]),
    ]
    proc = subprocess.run(
        ["/app/bin/digest_cli", *parts],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return proc.stdout.strip()


def _run_driver(env: dict | None = None) -> dict:
    run_env = {**os.environ, "TB_TRACE_FIXTURE": "1", "GOFLAGS": "-mod=mod"}
    if env:
        run_env.update(env)
    if OUT.exists():
        OUT.unlink()
    subprocess.run(["/app/bin/trace_lab"], cwd="/app", env=run_env, check=True)
    return json.loads(OUT.read_text(encoding="utf-8"))


def _expected_case_total() -> int:
    return sum(1 for line in ACTIVE.read_text().splitlines() if line.strip())


class TestPropagatorReport:
    def test_report_exists_after_driver(self) -> None:
        """Driver run must emit a non-empty propagator report file."""
        rep = _run_driver()
        assert OUT.is_file()
        assert isinstance(rep["schema_version"], str) and rep["schema_version"]

    def test_report_schema_keys(self) -> None:
        """Top-level report object must expose exactly the documented keys."""
        rep = _run_driver()
        assert set(rep) == REPORT_KEYS

    def test_case_rows_shape(self) -> None:
        """Each case row must include the documented per-case fields."""
        rep = _run_driver()
        assert len(rep["cases"]) == rep["cases_total"]
        for row in rep["cases"]:
            assert set(row) == CASE_KEYS

    def test_active_bundle_passes(self) -> None:
        """Bundled scenarios must all pass with full case clearance."""
        rep = _run_driver()
        assert rep["cases_total"] == _expected_case_total()
        assert rep["cases_passed"] == rep["cases_total"]
        assert all(row["passed"] for row in rep["cases"])

    def test_dense_and_policy_flags(self) -> None:
        """Summary counters must reflect dense bundles and policy compliance."""
        rep = _run_driver()
        prof = json.loads(PROFILE.read_text(encoding="utf-8"))
        assert rep["max_baggage_items"] >= prof["dense_items"]
        assert rep["cases_passed"] == rep["cases_total"]

    def test_digest_hex_matches(self) -> None:
        """digest_hex must match the canonical pipe-joined field hash."""
        rep = _run_driver()
        assert rep["digest_hex"] == _digest(rep)

    def test_summary_flags_when_bundle_clears(self) -> None:
        """Summary booleans must reflect a fully cleared replay bundle."""
        rep = _run_driver()
        assert rep["cases_passed"] == rep["cases_total"]
        assert rep["http_roundtrip_ok"]
        assert rep["grpc_roundtrip_ok"]
        assert rep["header_limit_ok"]
        assert rep["dedup_policy_ok"]
        assert rep["version_check_ok"]
        assert rep["zero_parse_heap"]

    def test_go_unit_tests_pass(self) -> None:
        """Go unit tests under /app must pass after the driver run."""
        _run_driver()
        proc = subprocess.run(
            ["go", "test", "-mod=mod", "./..."],
            cwd="/app",
            capture_output=True,
            text=True,
        )
        assert proc.returncode == 0, proc.stdout + proc.stderr

    def test_regression_stems(self) -> None:
        """Indexed fixture stems must replay with full case pass counts."""
        stems = [
            ln.strip()
            for ln in INDEX.read_text().splitlines()
            if ln.strip() and not ln.strip().startswith("#")
        ]
        assert stems, "fixture index empty"
        active_backup = ACTIVE.read_text(encoding="utf-8")
        try:
            for stem in stems:
                src = FIXTURES / stem / "cases.jsonl"
                assert src.is_file(), f"missing fixture {stem}"
                shutil.copy(src, ACTIVE)
                rep = _run_driver()
                assert rep["cases_passed"] == rep["cases_total"], stem
                assert all(row["passed"] for row in rep["cases"]), stem
        finally:
            ACTIVE.write_text(active_backup, encoding="utf-8")

    def test_version_clash_case_present(self) -> None:
        """version_clash scenario must pass when parent and state disagree."""
        rep = _run_driver()
        ids = {row["case_id"] for row in rep["cases"]}
        assert "version_clash" in ids
        clash = next(r for r in rep["cases"] if r["case_id"] == "version_clash")
        assert clash["passed"] is True

    def test_state_vendor_case_present(self) -> None:
        """state_vendor scenario must pass with escaped comma preservation."""
        rep = _run_driver()
        vendor = next(r for r in rep["cases"] if r["case_id"] == "state_vendor")
        assert vendor["passed"] is True

    def test_deterministic_repeat(self) -> None:
        """Two consecutive driver runs must produce identical reports."""
        first = _run_driver()
        second = _run_driver()
        assert first == second
