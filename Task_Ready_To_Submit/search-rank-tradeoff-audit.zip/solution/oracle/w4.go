package cx

import (
	"sort"
	"unicode/utf8"

	"ranklab.dev/rankaudit/pkg/types"
)

// OpShardBx assigns documents to shard lanes for one query scenario.
func OpShardBx(docs []types.Doc, shardCount int) [][]string {
	if shardCount < 1 {
		shardCount = 1
	}
	sorted := append([]types.Doc(nil), docs...)
	sort.Slice(sorted, func(i, j int) bool {
		return utf8.RuneCountInString(sorted[i].Text) > utf8.RuneCountInString(sorted[j].Text)
	})
	lanes := make([][]string, shardCount)
	loads := make([]int, shardCount)
	left, right := 0, len(sorted)-1
	for left <= right {
		if left == right {
			lane := minLoadLane(loads)
			lanes[lane] = append(lanes[lane], sorted[left].ID)
			loads[lane] += utf8.RuneCountInString(sorted[left].Text)
			break
		}
		lane := minLoadLane(loads)
		lanes[lane] = append(lanes[lane], sorted[left].ID, sorted[right].ID)
		loads[lane] += utf8.RuneCountInString(sorted[left].Text) + utf8.RuneCountInString(sorted[right].Text)
		left++
		right--
	}
	return lanes
}

func minLoadLane(loads []int) int {
	lane := 0
	for i := 1; i < len(loads); i++ {
		if loads[i] < loads[lane] {
			lane = i
		}
	}
	return lane
}
