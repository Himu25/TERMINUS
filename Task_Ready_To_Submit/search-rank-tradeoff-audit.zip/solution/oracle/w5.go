package cx

// OpShardWx returns how many shard lanes may run concurrently.
func OpShardWx(cfgShards int, dead []int) int {
	active := 0
	for i := 0; i < cfgShards; i++ {
		if isDead(i, dead) {
			continue
		}
		active++
	}
	if active == 0 {
		return cfgShards
	}
	return active
}

func isDead(lane int, dead []int) bool {
	for _, d := range dead {
		if d == lane {
			return true
		}
	}
	return false
}
