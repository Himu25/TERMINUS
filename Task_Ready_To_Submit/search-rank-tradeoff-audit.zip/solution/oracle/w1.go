package ax

// OpDwellWeight maps a click and dwell sample into engagement weight for CTR aggregates.
func OpDwellWeight(clicked int, dwellMs int) float64 {
	if clicked == 0 {
		return 0
	}
	w := float64(dwellMs) / 2000.0
	if w > 1.0 {
		w = 1.0
	}
	if w < 0.05 {
		w = 0.05
	}
	return w
}

// OpLogLagUnits estimates spread between earliest and latest log timestamps.
func OpLogLagUnits(eventMs []int64) int {
	if len(eventMs) < 2 {
		return 0
	}
	minMs, maxMs := eventMs[0], eventMs[0]
	for _, v := range eventMs[1:] {
		if v < minMs {
			minMs = v
		}
		if v > maxMs {
			maxMs = v
		}
	}
	return int(maxMs - minMs)
}

// OpLogWindow returns the impression slice visible after lag budgeting.
func OpLogWindow(eventMs []int64, lagCap int) []int64 {
	if lagCap <= 0 || len(eventMs) <= lagCap {
		return eventMs
	}
	return eventMs[len(eventMs)-lagCap:]
}
