use sha2::{Digest, Sha256};
use std::ffi::{CStr, CString};
use std::os::raw::c_char;
use unicode_normalization::UnicodeNormalization;

fn rfNormFx(input: &str) -> String {
    input.nfkc().collect::<String>().to_lowercase()
}

fn rfTokFold(norm: &str) -> (Vec<String>, u32) {
    let tokens: Vec<String> = norm
        .split_whitespace()
        .filter(|t| !t.is_empty())
        .map(|t| t.to_string())
        .collect();
    let alloc_units = (norm.len() as u32).saturating_add(64) / 64;
    (tokens, alloc_units)
}

fn rfFoldDg(tokens: &[String]) -> String {
    let joined = tokens.join(" ");
    let mut hasher = Sha256::new();
    hasher.update(joined.as_bytes());
    format!("{:x}", hasher.finalize())
}

#[no_mangle]
pub extern "C" fn rfFeat(
    text: *const c_char,
    out_count: *mut u32,
    out_alloc: *mut u32,
) -> *mut c_char {
    if text.is_null() || out_count.is_null() || out_alloc.is_null() {
        return std::ptr::null_mut();
    }
    let raw = unsafe { CStr::from_ptr(text) };
    let input = raw.to_string_lossy();
    let norm = rfNormFx(&input);
    let (tokens, alloc) = rfTokFold(&norm);
    unsafe {
        *out_count = tokens.len() as u32;
        *out_alloc = alloc;
    }
    let dg = rfFoldDg(&tokens);
    CString::new(dg)
        .ok()
        .map(CString::into_raw)
        .unwrap_or(std::ptr::null_mut())
}

#[no_mangle]
pub extern "C" fn rfFree(ptr: *mut c_char) {
    if !ptr.is_null() {
        unsafe {
            let _ = CString::from_raw(ptr);
        }
    }
}
