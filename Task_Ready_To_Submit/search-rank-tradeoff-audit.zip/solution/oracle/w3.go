package cx

var seenDoc = map[string]uint64{}

// OpReset clears per-query impression dedup state.
func OpReset() {
	seenDoc = map[string]uint64{}
}

// OpAccept reports whether an impression row may be counted.
func OpAccept(docID string, seq uint64) bool {
	prev, ok := seenDoc[docID]
	if ok && prev >= seq {
		return false
	}
	seenDoc[docID] = seq
	return true
}

// OpTailCap returns how many ranked slots may be merged for a bucket.
func OpTailCap(bucket string, topK int) int {
	if topK <= 0 {
		return 10
	}
	return topK
}
