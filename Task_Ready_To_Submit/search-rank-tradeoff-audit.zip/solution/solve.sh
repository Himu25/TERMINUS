#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

log "preflight: search ranking tradeoff audit workspace"
test -f /app/go.mod
test -f /app/config/rank.toml
test -f /app/data/docs_default.json
test -f /app/data/query_specs.jsonl
mkdir -p /app/bin /app/lib /app/output

log "survey: guardrails and ranking subsystem layout"
grep -nE 'recall|satisfaction|ctr|popularity|tail' \
  /app/config/rank.toml /app/metrics/guardrails.txt /app/policies/retention.txt 2>/dev/null | head -n 20 || true
wc -l /app/bench/drive.go /app/scripts/build_all.sh

log "apply oracle patches across ranking blend path"
install -m 0644 "${ROOT_DIR}/oracle/w1.go" /app/ax/w1.go
install -m 0644 "${ROOT_DIR}/oracle/w2.go" /app/bx/w2.go
install -m 0644 "${ROOT_DIR}/oracle/w3.go" /app/cx/w3.go
install -m 0644 "${ROOT_DIR}/oracle/w4.go" /app/cx/w4.go
install -m 0644 "${ROOT_DIR}/oracle/w5.go" /app/cx/w5.go
install -m 0644 "${ROOT_DIR}/oracle/w6.go" /app/dx/w6.go
install -m 0644 "${ROOT_DIR}/oracle/rfold.rs" /app/rfold/src/lib.rs

log "rebuild Rust scorer and Go rankaudit driver"
bash /app/scripts/build_all.sh

log "regenerate default session pack after scorer repair"
/app/bin/refgen \
  /app/data/docs_default.json \
  /app/data/query_specs.jsonl \
  /app/data/sessions_default.jsonl

log "run default ranking tradeoff audit report"
export LD_LIBRARY_PATH="/app/lib:${LD_LIBRARY_PATH:-}"
chmod +x /app/scripts/run_bench.sh
/app/scripts/run_bench.sh /app/data/sessions_default.jsonl /app/output/rank_audit.json

log "done"
