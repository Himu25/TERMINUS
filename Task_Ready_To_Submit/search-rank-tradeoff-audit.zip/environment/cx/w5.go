package cx

// OpShardWx returns how many shard lanes may run concurrently.
func OpShardWx(cfgShards int, dead []int) int {
	_ = dead
	return 1
}
