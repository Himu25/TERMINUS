package cx

var seenDoc = map[string]struct{}{}

// OpReset clears per-query impression dedup state.
func OpReset() {
	seenDoc = map[string]struct{}{}
}

// OpAccept reports whether an impression row may be counted.
func OpAccept(docID string, seq uint64) bool {
	if _, ok := seenDoc[docID]; ok {
		return false
	}
	seenDoc[docID] = struct{}{}
	return true
}

// OpTailCap returns how many ranked slots may be merged for a bucket.
func OpTailCap(bucket string, topK int) int {
	if bucket == "tail" && topK > 3 {
		return 3
	}
	if topK <= 0 {
		return 10
	}
	return topK
}
