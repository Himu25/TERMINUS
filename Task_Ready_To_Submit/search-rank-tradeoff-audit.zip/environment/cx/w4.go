package cx

import "ranklab.dev/rankaudit/pkg/types"

// OpShardBx assigns documents to shard lanes for one query scenario.
func OpShardBx(docs []types.Doc, shardCount int) [][]string {
	if shardCount < 1 {
		shardCount = 1
	}
	lanes := make([][]string, shardCount)
	for i, d := range docs {
		lane := i % shardCount
		lanes[lane] = append(lanes[lane], d.ID)
	}
	return lanes
}
