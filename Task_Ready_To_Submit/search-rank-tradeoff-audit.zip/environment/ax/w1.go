package ax

// OpDwellWeight maps a click and dwell sample into engagement weight for CTR aggregates.
func OpDwellWeight(clicked int, dwellMs int) float64 {
	if clicked == 0 {
		return 0
	}
	_ = dwellMs
	return 1.0
}

// OpLogLagUnits estimates spread between earliest and latest log timestamps.
func OpLogLagUnits(eventMs []int64) int {
	if len(eventMs) < 2 {
		return 0
	}
	return int(eventMs[len(eventMs)-1] - eventMs[0])
}

// OpLogWindow returns the impression slice visible after lag budgeting.
func OpLogWindow(eventMs []int64, lagCap int) []int64 {
	if len(eventMs) <= 1 {
		return eventMs
	}
	cut := len(eventMs) / 2
	if lagCap > 0 && cut > lagCap {
		cut = lagCap
	}
	return eventMs[:cut]
}
