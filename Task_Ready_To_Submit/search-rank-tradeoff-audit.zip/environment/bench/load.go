package bench

import (
	"bufio"
	"encoding/json"
	"os"
	"strconv"
	"strings"

	"ranklab.dev/rankaudit/pkg/types"
)

func LoadCfg(path string) (types.RankCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.RankCfg{}, err
	}
	cfg := types.RankCfg{
		CorpusPath:            "/app/data/docs_default.json",
		ShardCount:            4,
		AuditProfile:          "v2",
		RecallFloor:           0.82,
		SatisfactionFloor:     0.78,
		MaxMeanPositionBias:   0.35,
		MaxMeanPopularityBias: 0.40,
		MaxTailRecallGap:      0.18,
		CtrQualityFloor:       0.88,
		PositionFairnessFloor: 0.90,
		MaxMeanBlendUnits:     2200,
		MaxMeanStaleUnits:     1200,
		FailoverRecallFloor:   0.72,
		SkewBalanceMin:        0.65,
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		parts := strings.SplitN(line, "=", 2)
		if len(parts) != 2 {
			continue
		}
		key := strings.TrimSpace(parts[0])
		val := strings.TrimSpace(parts[1])
		switch key {
		case "corpus_path":
			cfg.CorpusPath = val
		case "shard_count":
			cfg.ShardCount, _ = strconv.Atoi(val)
		case "audit_profile":
			cfg.AuditProfile = val
		case "recall_floor", "satisfaction_floor", "max_mean_position_bias",
			"max_mean_popularity_bias", "max_tail_recall_gap", "ctr_quality_floor",
			"position_fairness_floor", "failover_recall_floor", "skew_balance_min":
			cfg, err = setFloatField(cfg, key, val)
			if err != nil {
				return types.RankCfg{}, err
			}
		case "max_mean_blend_units", "max_mean_stale_units":
			cfg, err = setIntField(cfg, key, val)
			if err != nil {
				return types.RankCfg{}, err
			}
		}
	}
	return cfg, nil
}

func setFloatField(cfg types.RankCfg, key, val string) (types.RankCfg, error) {
	f, err := strconv.ParseFloat(val, 64)
	if err != nil {
		return cfg, err
	}
	switch key {
	case "recall_floor":
		cfg.RecallFloor = f
	case "satisfaction_floor":
		cfg.SatisfactionFloor = f
	case "max_mean_position_bias":
		cfg.MaxMeanPositionBias = f
	case "max_mean_popularity_bias":
		cfg.MaxMeanPopularityBias = f
	case "max_tail_recall_gap":
		cfg.MaxTailRecallGap = f
	case "ctr_quality_floor":
		cfg.CtrQualityFloor = f
	case "position_fairness_floor":
		cfg.PositionFairnessFloor = f
	case "failover_recall_floor":
		cfg.FailoverRecallFloor = f
	case "skew_balance_min":
		cfg.SkewBalanceMin = f
	}
	return cfg, nil
}

func setIntField(cfg types.RankCfg, key, val string) (types.RankCfg, error) {
	i, err := strconv.Atoi(val)
	if err != nil {
		return cfg, err
	}
	switch key {
	case "max_mean_blend_units":
		cfg.MaxMeanBlendUnits = i
	case "max_mean_stale_units":
		cfg.MaxMeanStaleUnits = i
	}
	return cfg, nil
}

func LoadQueries(path string) ([]types.QueryCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	var out []types.QueryCase
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var row types.QueryCase
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return nil, err
		}
		if row.TopK == 0 {
			row.TopK = 10
		}
		if row.Bucket == "" {
			row.Bucket = "head"
		}
		out = append(out, row)
	}
	return out, sc.Err()
}

// LoadStreams keeps the goldgen entrypoint stable.
func LoadStreams(path string) ([]types.QueryCase, error) {
	return LoadQueries(path)
}
