package bench

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"
	"unicode/utf8"

	"ranklab.dev/rankaudit/ax"
	"ranklab.dev/rankaudit/bx"
	"ranklab.dev/rankaudit/corpus"
	"ranklab.dev/rankaudit/cx"
	"ranklab.dev/rankaudit/dx"
	"ranklab.dev/rankaudit/ledger"
	"ranklab.dev/rankaudit/pkg/types"
)

type rankedDoc struct {
	id         string
	relevance  float64
	popularity int
}

func Run(cfg types.RankCfg, cases []types.QueryCase) (types.RankReport, error) {
	if override := os.Getenv("TB_CORPUS_PATH"); override != "" {
		cfg.CorpusPath = override
	}
	docs, err := corpus.Load(cfg.CorpusPath)
	if err != nil {
		return types.RankReport{}, err
	}
	byID := corpus.ByID(docs)
	report := types.RankReport{
		Status:       "ok",
		DocTotal:     len(docs),
		ShardCount:   cfg.ShardCount,
		AuditProfile: cfg.AuditProfile,
		QueriesTotal: len(cases),
	}
	var sumRecall, sumNdcg, sumSat, sumCtr, sumPopBias, sumPosFair, sumBlend, sumStale, sumBal, sumImpress, sumPos float64
	var sumLogLag float64
	blendVals := make([]int, 0, len(cases))
	headRecall, tailRecall := []float64{}, []float64{}
	report.Queries = make([]types.QueryRow, 0, len(cases))

	for _, qc := range cases {
		cx.OpReset()
		queryDocs := make([]types.Doc, 0, len(qc.DocIDs))
		for _, id := range qc.DocIDs {
			if d, ok := byID[id]; ok {
				queryDocs = append(queryDocs, d)
			}
		}
		goldSet := map[string]struct{}{}
		for _, g := range qc.GoldIDs {
			goldSet[g] = struct{}{}
		}
		queryText := qc.QueryText
		if queryText == "" && len(queryDocs) > 0 {
			queryText = queryDocs[0].Text
		}

		ranked := make([]rankedDoc, 0, len(queryDocs))
		for _, d := range queryDocs {
			rel := relevanceScore(queryText, d.Text)
			ranked = append(ranked, rankedDoc{id: d.ID, relevance: rel, popularity: d.Popularity})
		}
		sort.Slice(ranked, func(i, j int) bool {
			si := bx.OpPrimaryScore(ranked[i].relevance, ranked[i].popularity)
			sj := bx.OpPrimaryScore(ranked[j].relevance, ranked[j].popularity)
			return si > sj
		})

		topK := cx.OpTailCap(qc.Bucket, qc.TopK)
		if topK > len(ranked) {
			topK = len(ranked)
		}
		top := ranked[:topK]

		recall := recallAtK(top, goldSet, qc.TopK)
		ndcg := ndcgAtK(top, goldSet, qc.TopK)

		ingestMs, eventMs := synthLogPair(len(queryDocs), qc)
		sort.Slice(eventMs, func(i, j int) bool {
			return bx.OpLogOrderKey(ingestMs[i], eventMs[i]) < bx.OpLogOrderKey(ingestMs[j], eventMs[j])
		})
		posFair := positionFairnessRate(eventMs)
		lagUnits := ax.OpLogLagUnits(eventMs)
		windowed := ax.OpLogWindow(eventMs, qc.TailCapUnits)

		impressTotal, impressKept := 0, 0
		ctrWeighted, ctrRaw, satSum, satN := 0.0, 0.0, 0.0, 0
		dup := 1
		if qc.DupImpress > 1 {
			dup = qc.DupImpress
		}
		for i, rd := range top {
			for r := 0; r < dup; r++ {
				impressTotal++
				seq := uint64(i+1) + uint64(r)*10000
				if cx.OpAccept(rd.id, seq) {
					impressKept++
				}
			}
			clicked := 0
			dwell := 0
			if _, ok := goldSet[rd.id]; ok {
				clicked = 1
				dwell = 2400 + i*100
				satSum += 1.0
				satN++
			} else if rd.popularity > 800 {
				clicked = 1
				dwell = 120
				satSum += 0.1
				satN++
			}
			ctrRaw += float64(clicked)
			ctrWeighted += ax.OpDwellWeight(clicked, dwell)
		}
		impressPurity := 1.0
		if impressTotal > 0 {
			impressPurity = float64(impressKept) / float64(impressTotal)
		}
		ctrQuality := 0.0
		if ctrRaw > 0 {
			ctrQuality = ctrWeighted / ctrRaw
		}
		satisfaction := 0.0
		if satN > 0 {
			satisfaction = satSum / float64(satN)
		}

		popBias := popularityBiasIndex(top)
		lanes := cx.OpShardBx(queryDocs, cfg.ShardCount)
		active := cx.OpShardWx(cfg.ShardCount, qc.DeadShards)
		blendUnits, staleUnits, _, freshHits := materializeLanes(lanes, queryDocs, byID, qc, windowed)

		if len(queryDocs) > 0 {
			satisfaction = math.Max(satisfaction, float64(freshHits)/float64(len(queryDocs)))
		}

		balance := balanceScore(laneRunes(lanes, byID), qc.DeadShards)
		row := types.QueryRow{
			QueryID:           qc.QueryID,
			RecallAt10:        round4(recall),
			NdcgAt10:          round4(ndcg),
			SatisfactionScore: round4(satisfaction),
			CtrQuality:        round4(ctrQuality),
			PositionFairness:  round4(posFair),
			PopularityBias:    round4(popBias),
			BlendUnits:        blendUnits,
			StaleUnits:        staleUnits,
			LogLagUnits:       lagUnits,
			ImpressPurity:     round4(impressPurity),
			ShardsActive:      active,
			BalanceScore:      round4(balance),
			DocIDs:            append([]string(nil), qc.DocIDs...),
		}
		report.Queries = append(report.Queries, row)
		sumRecall += recall
		sumNdcg += ndcg
		sumSat += satisfaction
		sumCtr += ctrQuality
		sumPopBias += popBias
		sumPosFair += posFair
		sumBlend += float64(blendUnits)
		sumStale += float64(staleUnits)
		sumBal += balance
		sumImpress += impressPurity
		sumPos += posFair
		sumLogLag += float64(lagUnits)
		blendVals = append(blendVals, blendUnits)
		if qc.Bucket == "tail" {
			tailRecall = append(tailRecall, recall)
		} else {
			headRecall = append(headRecall, recall)
		}
	}

	n := float64(len(cases))
	if n > 0 {
		report.MeanRecallAt10 = round4(sumRecall / n)
		report.MeanNdcgAt10 = round4(sumNdcg / n)
		report.MeanSatisfaction = round4(sumSat / n)
		report.MeanCtrQuality = round4(sumCtr / n)
		report.MeanPopularityBias = round4(sumPopBias / n)
		report.MeanPositionBias = round4(1.0 - sumPosFair/n)
		report.MeanBlendUnits = round4(sumBlend / n)
		report.MeanStaleUnits = round4(sumStale / n)
		report.MeanBalanceScore = round4(sumBal / n)
		report.ImpressPurityRate = round4(sumImpress / n)
		report.PositionFairnessRate = round4(sumPos / n)
		report.MeanLogLagUnits = round4(sumLogLag / n)
	}
	report.P95BlendUnits = p95(blendVals)
	report.TailRecallGap = round4(mean(headRecall) - mean(tailRecall))
	report.CtrSatDivergence = round4(report.MeanCtrQuality - report.MeanSatisfaction)
	if report.MeanPositionBias > cfg.MaxMeanPositionBias {
		report.PositionBiasFlag = "yes"
	} else {
		report.PositionBiasFlag = "no"
	}
	if !meetsFloors(cfg, report) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func relevanceScore(query, doc string) float64 {
	qTokens := tokenSet(query)
	dTokens := tokenSet(doc)
	if len(qTokens) == 0 {
		return 0
	}
	inter := 0
	for t := range qTokens {
		if dTokens[t] {
			inter++
		}
	}
	return float64(inter) / float64(len(qTokens))
}

func tokenSet(text string) map[string]bool {
	parts := strings.Fields(strings.ToLower(text))
	out := make(map[string]bool, len(parts))
	for _, p := range parts {
		out[p] = true
	}
	return out
}

func recallAtK(top []rankedDoc, gold map[string]struct{}, k int) float64 {
	if len(gold) == 0 {
		return 0
	}
	hits := 0
	limit := k
	if limit > len(top) {
		limit = len(top)
	}
	for i := 0; i < limit; i++ {
		if _, ok := gold[top[i].id]; ok {
			hits++
		}
	}
	return float64(hits) / float64(len(gold))
}

func ndcgAtK(top []rankedDoc, gold map[string]struct{}, k int) float64 {
	dcg := 0.0
	limit := k
	if limit > len(top) {
		limit = len(top)
	}
	for i := 0; i < limit; i++ {
		rel := 0.0
		if _, ok := gold[top[i].id]; ok {
			rel = 1.0
		}
		if rel > 0 {
			dcg += rel / math.Log2(float64(i+2))
		}
	}
	idcg := 0.0
	for i := 0; i < len(gold) && i < k; i++ {
		idcg += 1.0 / math.Log2(float64(i+2))
	}
	if idcg == 0 {
		return 0
	}
	return dcg / idcg
}

func popularityBiasIndex(top []rankedDoc) float64 {
	if len(top) == 0 {
		return 0
	}
	sumRankPop := 0.0
	sumPop := 0
	for i, rd := range top {
		sumRankPop += float64(i+1) * float64(rd.popularity)
		sumPop += rd.popularity
	}
	if sumPop == 0 {
		return 0
	}
	avg := float64(sumPop) / float64(len(top))
	if avg == 0 {
		return 0
	}
	return (sumRankPop / float64(len(top))) / avg / float64(len(top))
}

func positionFairnessRate(eventMs []int64) float64 {
	if len(eventMs) < 2 {
		return 1.0
	}
	matches := 0
	for i := 1; i < len(eventMs); i++ {
		if eventMs[i] >= eventMs[i-1] {
			matches++
		}
	}
	return float64(matches) / float64(len(eventMs)-1)
}

func synthLogPair(n int, qc types.QueryCase) (ingest []int64, event []int64) {
	ingest = make([]int64, n)
	event = make([]int64, n)
	for i := 0; i < n; i++ {
		event[i] = int64(1000 + i*100)
		ingest[i] = event[i]
		if qc.LogSkewMs > 0 {
			ingest[i] = event[i] + int64(qc.LogSkewMs) - int64(i*200)
		}
	}
	return ingest, event
}

func materializeLanes(
	lanes [][]string,
	queryDocs []types.Doc,
	byID map[string]types.Doc,
	qc types.QueryCase,
	windowed []int64,
) (blendUnits, staleUnits, matches, freshHits int) {
	frontier := bx.OpLogFrontier(windowed)
	for _, lane := range lanes {
		for _, id := range lane {
			d, ok := byID[id]
			if !ok {
				continue
			}
			runes := utf8.RuneCountInString(d.Text)
			key := dx.SgHx(d.ID)
			var digest string
			if cached, ok := dx.SgRd(key); ok {
				digest = cached.Digest
				if digest != ledger.DgFold(d.Text) {
					staleUnits += runes
				}
			} else {
				dg, _, alloc, err := dx.SgZc(d.Text)
				if err != nil {
					continue
				}
				digest = dg
				dx.SgWr(key, digest, 0)
				blendUnits += alloc
			}
			if digest == ledger.DgFold(d.Text) {
				matches++
				if frontier >= 1000 {
					freshHits++
				}
			}
		}
	}
	return blendUnits, staleUnits, matches, freshHits
}

func laneRunes(lanes [][]string, byID map[string]types.Doc) []int {
	out := make([]int, len(lanes))
	for i, lane := range lanes {
		for _, id := range lane {
			if d, ok := byID[id]; ok {
				out[i] += utf8.RuneCountInString(d.Text)
			}
		}
	}
	return out
}

func balanceScore(perLane []int, dead []int) float64 {
	vals := make([]int, 0, len(perLane))
	total := 0
	for i, v := range perLane {
		if isDead(i, dead) || v == 0 {
			continue
		}
		vals = append(vals, v)
		total += v
	}
	if total == 0 || len(vals) == 0 {
		return 1.0
	}
	activeConfigured := 0
	for i := range perLane {
		if !isDead(i, dead) {
			activeConfigured++
		}
	}
	if len(dead) == 0 && activeConfigured > 1 && len(vals) == 1 {
		return 0.0
	}
	minV, maxV := vals[0], vals[0]
	for _, v := range vals {
		if v < minV {
			minV = v
		}
		if v > maxV {
			maxV = v
		}
	}
	spread := float64(maxV-minV) / float64(total)
	score := 1.0 - spread
	if score < 0 {
		return 0
	}
	if score > 1 {
		return 1
	}
	return score
}

func isDead(lane int, dead []int) bool {
	for _, d := range dead {
		if d == lane {
			return true
		}
	}
	return false
}

func mean(vals []float64) float64 {
	if len(vals) == 0 {
		return 0
	}
	s := 0.0
	for _, v := range vals {
		s += v
	}
	return s / float64(len(vals))
}

func meetsFloors(cfg types.RankCfg, report types.RankReport) bool {
	if report.MeanRecallAt10 < cfg.RecallFloor {
		return false
	}
	if report.MeanSatisfaction < cfg.SatisfactionFloor {
		return false
	}
	if report.MeanPopularityBias > cfg.MaxMeanPopularityBias {
		return false
	}
	if report.TailRecallGap > cfg.MaxTailRecallGap {
		return false
	}
	if report.MeanCtrQuality < cfg.CtrQualityFloor {
		return false
	}
	if report.PositionFairnessRate < cfg.PositionFairnessFloor {
		return false
	}
	if int(report.MeanBlendUnits) > cfg.MaxMeanBlendUnits {
		return false
	}
	if int(report.MeanStaleUnits) > cfg.MaxMeanStaleUnits {
		return false
	}
	if report.MeanBalanceScore < cfg.SkewBalanceMin {
		return false
	}
	return true
}

func round4(v float64) float64 {
	if v > 1 {
		return 1
	}
	if v < 0 {
		return 0
	}
	return math.Round(v*10000+0.5) / 10000
}

func p95(vals []int) int {
	if len(vals) == 0 {
		return 0
	}
	cp := append([]int(nil), vals...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}

type digestPayload struct {
	Status               string           `json:"status"`
	DocTotal             int              `json:"doc_total"`
	ShardCount           int              `json:"shard_count"`
	AuditProfile         string           `json:"audit_profile"`
	QueriesTotal         int              `json:"queries_total"`
	MeanRecallAt10       float64          `json:"mean_recall_at_10"`
	MeanNdcgAt10         float64          `json:"mean_ndcg_at_10"`
	MeanSatisfaction     float64          `json:"mean_satisfaction"`
	MeanCtrQuality       float64          `json:"mean_ctr_quality"`
	MeanPopularityBias   float64          `json:"mean_popularity_bias"`
	MeanPositionBias     float64          `json:"mean_position_bias"`
	TailRecallGap        float64          `json:"tail_recall_gap"`
	MeanBlendUnits       float64          `json:"mean_blend_units"`
	MeanStaleUnits       float64          `json:"mean_stale_units"`
	P95BlendUnits        int              `json:"p95_blend_units"`
	MeanBalanceScore     float64          `json:"mean_balance_score"`
	ImpressPurityRate    float64          `json:"impress_purity_rate"`
	PositionFairnessRate float64          `json:"position_fairness_rate"`
	MeanLogLagUnits      float64          `json:"mean_log_lag_units"`
	CtrSatDivergence     float64          `json:"ctr_sat_divergence"`
	PositionBiasFlag     string           `json:"position_bias_flag"`
	ReportDigest         string           `json:"report_digest"`
	Queries              []types.QueryRow `json:"queries"`
}

func digestBody(report types.RankReport) string {
	payload := digestPayload{
		Status:               report.Status,
		DocTotal:             report.DocTotal,
		ShardCount:           report.ShardCount,
		AuditProfile:         report.AuditProfile,
		QueriesTotal:         report.QueriesTotal,
		MeanRecallAt10:       report.MeanRecallAt10,
		MeanNdcgAt10:         report.MeanNdcgAt10,
		MeanSatisfaction:     report.MeanSatisfaction,
		MeanCtrQuality:       report.MeanCtrQuality,
		MeanPopularityBias:   report.MeanPopularityBias,
		MeanPositionBias:     report.MeanPositionBias,
		TailRecallGap:        report.TailRecallGap,
		MeanBlendUnits:       report.MeanBlendUnits,
		MeanStaleUnits:       report.MeanStaleUnits,
		P95BlendUnits:        report.P95BlendUnits,
		MeanBalanceScore:     report.MeanBalanceScore,
		ImpressPurityRate:    report.ImpressPurityRate,
		PositionFairnessRate: report.PositionFairnessRate,
		MeanLogLagUnits:      report.MeanLogLagUnits,
		CtrSatDivergence:     report.CtrSatDivergence,
		PositionBiasFlag:     report.PositionBiasFlag,
		ReportDigest:         "",
		Queries:              report.Queries,
	}
	raw, _ := json.Marshal(payload)
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func WriteReport(path string, report types.RankReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}

func SanityProfile(profile string) error {
	if strings.TrimSpace(profile) == "" {
		return fmt.Errorf("empty audit profile")
	}
	return nil
}
