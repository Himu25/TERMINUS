package types

type RankCfg struct {
	CorpusPath              string
	ShardCount              int
	AuditProfile            string
	RecallFloor             float64
	SatisfactionFloor       float64
	MaxMeanPositionBias     float64
	MaxMeanPopularityBias   float64
	MaxTailRecallGap        float64
	CtrQualityFloor         float64
	PositionFairnessFloor   float64
	MaxMeanBlendUnits       int
	MaxMeanStaleUnits       int
	FailoverRecallFloor     float64
	SkewBalanceMin          float64
}

type Doc struct {
	ID         string `json:"id"`
	Text       string `json:"text"`
	Popularity int    `json:"popularity"`
	Lang       string `json:"lang"`
}

type QueryCase struct {
	QueryID      string   `json:"query_id"`
	DocIDs       []string `json:"doc_ids"`
	GoldIDs      []string `json:"gold_ids"`
	Bucket       string   `json:"bucket"`
	QueryText    string   `json:"query_text"`
	TopK         int      `json:"top_k"`
	DeadShards   []int    `json:"dead_shards"`
	LogSkewMs    int      `json:"log_skew_ms"`
	DupImpress   int      `json:"dup_impress"`
	TailCapUnits int      `json:"tail_cap_units"`
}

type QueryRow struct {
	QueryID            string   `json:"query_id"`
	RecallAt10         float64  `json:"recall_at_10"`
	NdcgAt10           float64  `json:"ndcg_at_10"`
	SatisfactionScore  float64  `json:"satisfaction_score"`
	CtrQuality         float64  `json:"ctr_quality"`
	PositionFairness   float64  `json:"position_fairness"`
	PopularityBias     float64  `json:"popularity_bias"`
	BlendUnits         int      `json:"blend_units"`
	StaleUnits         int      `json:"stale_units"`
	LogLagUnits        int      `json:"log_lag_units"`
	ImpressPurity      float64  `json:"impress_purity"`
	ShardsActive       int      `json:"shards_active"`
	BalanceScore       float64  `json:"balance_score"`
	DocIDs             []string `json:"doc_ids"`
}

type RankReport struct {
	Status                string     `json:"status"`
	DocTotal              int        `json:"doc_total"`
	ShardCount            int        `json:"shard_count"`
	AuditProfile          string     `json:"audit_profile"`
	QueriesTotal          int        `json:"queries_total"`
	MeanRecallAt10        float64    `json:"mean_recall_at_10"`
	MeanNdcgAt10          float64    `json:"mean_ndcg_at_10"`
	MeanSatisfaction      float64    `json:"mean_satisfaction"`
	MeanCtrQuality        float64    `json:"mean_ctr_quality"`
	MeanPopularityBias    float64    `json:"mean_popularity_bias"`
	MeanPositionBias      float64    `json:"mean_position_bias"`
	TailRecallGap         float64    `json:"tail_recall_gap"`
	MeanBlendUnits        float64    `json:"mean_blend_units"`
	MeanStaleUnits        float64    `json:"mean_stale_units"`
	P95BlendUnits         int        `json:"p95_blend_units"`
	MeanBalanceScore      float64    `json:"mean_balance_score"`
	ImpressPurityRate     float64    `json:"impress_purity_rate"`
	PositionFairnessRate  float64    `json:"position_fairness_rate"`
	MeanLogLagUnits       float64    `json:"mean_log_lag_units"`
	CtrSatDivergence      float64    `json:"ctr_sat_divergence"`
	PositionBiasFlag      string     `json:"position_bias_flag"`
	ReportDigest          string     `json:"report_digest"`
	Queries               []QueryRow `json:"queries"`
}

// Legacy aliases used while migrating bench loaders.
type Entity = Doc
type StreamCase = QueryCase
type StreamRow = QueryRow
type FreshReport = RankReport
type FreshCfg = RankCfg
