# Ranking audit bench architecture

The offline stack under `/app` replays query packs against a document corpus, blends Rust token materialization with Go shard orchestration, and writes `/app/output/rank_audit.json`.

## Drivers

- `/app/bin/rankaudit` loads `/app/config/rank.toml`, reads a session JSONL pack (default `/app/data/sessions_default.jsonl`), and emits the audit report.
- `/app/bin/refgen` attaches `gold_digests` to each query spec row using `/app/data/docs_default.json`.

## Report digest

`report_digest` is a 64-character lowercase hex SHA-256 over compact JSON of all other top-level fields with `report_digest` set to an empty string. The queries array is included verbatim.

## Query row semantics

- `recall_at_10` — fraction of gold documents present in the ranked top-k after blending.
- `ndcg_at_10` — normalized discounted cumulative gain at k using binary relevance for gold ids.
- `satisfaction_score` — fraction of impressions that match gold materialization with timely log frontier.
- `ctr_quality` — dwell-weighted engagement divided by raw click count for the ranked slate.
- `popularity_bias` — rank-position-weighted popularity concentration in the merged top-k.
- `position_fairness` — monotonicity rate of event-time log ordering after replay.
- `impress_purity` — deduplicated impression rows divided by total impression attempts.
- `tail_recall_gap` — mean recall on head-bucket queries minus mean recall on tail-bucket queries.

## Scenario knobs (query_specs.jsonl)

- `bucket` — `head` or `tail`; tail rows participate in tail_recall_gap.
- `log_skew_ms` — injects ingest-time skew for position-fairness scenarios.
- `dup_impress` — replays duplicate impression rows for purity scenarios.
- `dead_shards` — shard lanes treated as offline during blending.
- `tail_cap_units` — lag window cap passed to the log window helper (0 means unlimited).

## Floors

Verifier runs may write scratch JSON under `/app/output/` (for example `/app/output/rank_audit.json` and internal ablation copies `/app/output/rank_ablation_m1.json`, `/app/output/rank_ablation_m2.json`, `/app/output/rank_ablation_m3.json`, `/app/output/rank_ablation_m4.json`, `/app/output/rank_ablation_m5.json`, and `/app/output/rank_ablation_m6.json`). Ablation copies may land in Go or Rust sources under `/app/ax`, `/app/bx`, `/app/cx`, `/app/dx`, or `/app/rfold` from the verifier fixture tree (`fixtures` with files such as `z_w2.go`, `z_w3.go`, `z_w5.go`, `z_w6.go`, and `z_rfold.rs`). Rebuild via `/app/scripts/build_all.sh`. Grading prepends `/usr/local/go/bin:/app/bin:` to PATH when invoking rankaudit.

Regression impress purity on duplicate-impression scenarios expects at least 0.95 on the query row. Size-skew scenarios require balance_score at or above skew_balance_min on the individual query row. Unicode normalization scenarios expect zero stale_units on the query row once cross-language digest paths align. Default-pack ctr_sat_divergence should stay at or below 0.25 when dwell-weighted CTR aligns with satisfaction.
