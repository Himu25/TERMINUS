Search ranking tradeoff audit lab. See /app/docs/architecture.md for bench contract.
