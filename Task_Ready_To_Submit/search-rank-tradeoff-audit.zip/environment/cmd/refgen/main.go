package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"

	"ranklab.dev/rankaudit/bench"
	"ranklab.dev/rankaudit/corpus"
	"ranklab.dev/rankaudit/ledger"
	"ranklab.dev/rankaudit/pkg/types"
)

func main() {
	if len(os.Args) < 4 {
		fmt.Fprintln(os.Stderr, "usage: refgen <docs.json> <specs.jsonl> <out.jsonl>")
		os.Exit(2)
	}
	docs, err := corpus.Load(os.Args[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	byID := corpus.ByID(docs)
	specs, err := bench.LoadQueries(os.Args[2])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	out, err := os.Create(os.Args[3])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer out.Close()
	w := bufio.NewWriter(out)
	for _, spec := range specs {
		gold := make(map[string]string, len(spec.GoldIDs))
		for _, id := range spec.GoldIDs {
			if d, ok := byID[id]; ok {
				gold[id] = ledger.DgFold(d.Text)
			}
		}
		row := struct {
			types.QueryCase
			GoldDigests map[string]string `json:"gold_digests"`
		}{
			QueryCase:   spec,
			GoldDigests: gold,
		}
		raw, _ := json.Marshal(row)
		if _, err := w.Write(append(raw, '\n')); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	}
	if err := w.Flush(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
