package main

import (
	"fmt"
	"os"

	"ranklab.dev/rankaudit/bench"
)

func main() {
	if len(os.Args) < 3 {
		fmt.Fprintln(os.Stderr, "usage: rankaudit <sessions.jsonl> <out.json>")
		os.Exit(2)
	}
	cfg, err := bench.LoadCfg("/app/config/rank.toml")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	cases, err := bench.LoadQueries(os.Args[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	report, err := bench.Run(cfg, cases)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if err := bench.WriteReport(os.Args[2], report); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
