#!/bin/bash
set -euo pipefail

ROOT="/app"
mkdir -p "${ROOT}/bin" "${ROOT}/lib" "${ROOT}/output" "${ROOT}/output/cargo-target"

export CARGO_TARGET_DIR="${ROOT}/output/cargo-target"
export CARGO_HOME="${CARGO_HOME:-/usr/local/cargo}"
export CGO_LDFLAGS="-L${ROOT}/lib -lrfold"
export LD_LIBRARY_PATH="${ROOT}/lib:${LD_LIBRARY_PATH:-}"

cd "${ROOT}/rfold"
cargo build --release --locked
install -m 0644 "${CARGO_TARGET_DIR}/release/librfold.so" "${ROOT}/lib/librfold.so"

cd "${ROOT}"
go build -o "${ROOT}/bin/rankaudit" ./cmd/rankaudit
go build -o "${ROOT}/bin/refgen" ./cmd/refgen

export LD_LIBRARY_PATH="${ROOT}/lib:${LD_LIBRARY_PATH:-}"

"${ROOT}/bin/refgen" \
  "${ROOT}/data/docs_default.json" \
  "${ROOT}/data/query_specs.jsonl" \
  "${ROOT}/data/sessions_default.jsonl"

install -m 0755 "${ROOT}/bin/rankaudit" "${ROOT}/bin/rankmat"
