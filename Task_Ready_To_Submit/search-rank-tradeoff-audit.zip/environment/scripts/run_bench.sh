#!/bin/bash
set -euo pipefail

SESSIONS="${1:-/app/data/sessions_default.jsonl}"
OUT="${2:-/app/output/rank_audit.json}"

export LD_LIBRARY_PATH="/app/lib:${LD_LIBRARY_PATH:-}"
exec /app/bin/rankaudit "${SESSIONS}" "${OUT}"
