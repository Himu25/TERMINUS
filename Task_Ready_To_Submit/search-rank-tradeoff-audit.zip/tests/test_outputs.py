"""Validate /app/output/rank_audit.json against rank.toml guardrails."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "rank_audit.json"
CFG = APP / "config" / "rank.toml"
MANIFEST = APP / "registry" / "rank_manifest.json"
SESSIONS = APP / "data" / "sessions_default.jsonl"
FIXTURES = Path(__file__).resolve().parent / "fixtures"

REPORT_KEYS = frozenset(
    {
        "status",
        "doc_total",
        "shard_count",
        "audit_profile",
        "queries_total",
        "mean_recall_at_10",
        "mean_ndcg_at_10",
        "mean_satisfaction",
        "mean_ctr_quality",
        "mean_popularity_bias",
        "mean_position_bias",
        "tail_recall_gap",
        "mean_blend_units",
        "mean_stale_units",
        "p95_blend_units",
        "mean_balance_score",
        "impress_purity_rate",
        "position_fairness_rate",
        "mean_log_lag_units",
        "ctr_sat_divergence",
        "position_bias_flag",
        "report_digest",
        "queries",
    }
)
QUERY_KEYS = frozenset(
    {
        "query_id",
        "recall_at_10",
        "ndcg_at_10",
        "satisfaction_score",
        "ctr_quality",
        "position_fairness",
        "popularity_bias",
        "blend_units",
        "stale_units",
        "log_lag_units",
        "impress_purity",
        "shards_active",
        "balance_score",
        "doc_ids",
    }
)

_SUBPROC_ENV = os.environ.copy()
_path_prefix = "/usr/local/go/bin:/app/bin:"
_SUBPROC_ENV["PATH"] = _path_prefix + _SUBPROC_ENV.get("PATH", "")
_SUBPROC_ENV["LD_LIBRARY_PATH"] = "/app/lib:" + _SUBPROC_ENV.get("LD_LIBRARY_PATH", "")
_BUILD_TIMEOUT = 180
_RUN_TIMEOUT = 90


def _parse_cfg() -> dict:
    cfg: dict = {
        "shard_count": 4,
        "audit_profile": "v2",
        "recall_floor": 0.82,
        "satisfaction_floor": 0.78,
        "max_mean_position_bias": 0.35,
        "max_mean_popularity_bias": 0.60,
        "max_tail_recall_gap": 0.18,
        "ctr_quality_floor": 0.88,
        "position_fairness_floor": 0.90,
        "max_mean_blend_units": 2200,
        "max_mean_stale_units": 1200,
        "failover_recall_floor": 0.72,
        "skew_balance_min": 0.65,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in (
            "recall_floor",
            "satisfaction_floor",
            "max_mean_position_bias",
            "max_mean_popularity_bias",
            "max_tail_recall_gap",
            "ctr_quality_floor",
            "position_fairness_floor",
            "failover_recall_floor",
            "skew_balance_min",
        ):
            cfg[key] = float(val)
        elif key in ("shard_count", "max_mean_blend_units", "max_mean_stale_units"):
            cfg[key] = int(float(val))
        elif key == "audit_profile":
            cfg[key] = val
    return cfg


def _digest_payload(report: dict) -> dict:
    return {
        "status": report["status"],
        "doc_total": report["doc_total"],
        "shard_count": report["shard_count"],
        "audit_profile": report["audit_profile"],
        "queries_total": report["queries_total"],
        "mean_recall_at_10": report["mean_recall_at_10"],
        "mean_ndcg_at_10": report["mean_ndcg_at_10"],
        "mean_satisfaction": report["mean_satisfaction"],
        "mean_ctr_quality": report["mean_ctr_quality"],
        "mean_popularity_bias": report["mean_popularity_bias"],
        "mean_position_bias": report["mean_position_bias"],
        "tail_recall_gap": report["tail_recall_gap"],
        "mean_blend_units": report["mean_blend_units"],
        "mean_stale_units": report["mean_stale_units"],
        "p95_blend_units": report["p95_blend_units"],
        "mean_balance_score": report["mean_balance_score"],
        "impress_purity_rate": report["impress_purity_rate"],
        "position_fairness_rate": report["position_fairness_rate"],
        "mean_log_lag_units": report["mean_log_lag_units"],
        "ctr_sat_divergence": report["ctr_sat_divergence"],
        "position_bias_flag": report["position_bias_flag"],
        "report_digest": "",
        "queries": report["queries"],
    }


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _rebuild_go_only(env: dict) -> None:
    subprocess.run(
        ["go", "build", "-o", "/app/bin/rankaudit", "./cmd/rankaudit"],
        cwd=APP,
        check=True,
        timeout=_BUILD_TIMEOUT,
        env=env,
    )
    subprocess.run(
        ["go", "build", "-o", "/app/bin/refgen", "./cmd/refgen"],
        cwd=APP,
        check=True,
        timeout=_BUILD_TIMEOUT,
        env=env,
    )


def _rebuild_and_run(
    sessions_path: Path | None = None,
    out_path: Path | None = None,
    corpus_path: Path | None = None,
    *,
    full_build: bool = True,
) -> dict:
    sessions_path = sessions_path or SESSIONS
    out_path = out_path or OUT
    env = dict(_SUBPROC_ENV)
    if corpus_path is not None:
        env["TB_CORPUS_PATH"] = str(corpus_path)
    out_path.unlink(missing_ok=True)
    if full_build:
        subprocess.run(
            ["bash", "/app/scripts/build_all.sh"],
            cwd=APP,
            check=True,
            timeout=_BUILD_TIMEOUT,
            env=env,
        )
    else:
        _rebuild_go_only(env)
    subprocess.run(
        ["/app/bin/rankaudit", sessions_path.as_posix(), out_path.as_posix()],
        cwd=APP,
        check=True,
        timeout=_RUN_TIMEOUT,
        env=env,
    )
    return json.loads(out_path.read_text(encoding="utf-8"))


def _query_rows(report: dict) -> dict[str, dict]:
    return {row["query_id"]: row for row in report["queries"]}


@pytest.fixture(scope="module")
def cfg() -> dict:
    return _parse_cfg()


@pytest.fixture(scope="module")
def default_report() -> dict:
    if not OUT.is_file():
        pytest.fail(f"missing agent output at {OUT}")
    return json.loads(OUT.read_text(encoding="utf-8"))


def test_report_schema_and_digest(default_report: dict) -> None:
    """Top-level schema and report_digest must match compact pre-digest JSON."""
    assert set(default_report.keys()) == REPORT_KEYS
    assert re.fullmatch(r"[0-9a-f]{64}", default_report["report_digest"])
    assert default_report["report_digest"] == _expected_digest(default_report)
    for row in default_report["queries"]:
        assert set(row.keys()) == QUERY_KEYS


def test_default_pack_quality_floors(default_report: dict, cfg: dict) -> None:
    """Default query pack must meet rank.toml mean floors and ceilings."""
    assert default_report["status"] == "ok"
    assert default_report["queries_total"] == len(
        [ln for ln in SESSIONS.read_text(encoding="utf-8").splitlines() if ln.strip()]
    )
    assert default_report["mean_recall_at_10"] >= cfg["recall_floor"]
    assert default_report["mean_satisfaction"] >= cfg["satisfaction_floor"]
    assert default_report["mean_popularity_bias"] <= cfg["max_mean_popularity_bias"]
    assert default_report["tail_recall_gap"] <= cfg["max_tail_recall_gap"]
    assert default_report["mean_ctr_quality"] >= cfg["ctr_quality_floor"]
    assert default_report["position_fairness_rate"] >= cfg["position_fairness_floor"]
    assert int(default_report["mean_blend_units"]) <= cfg["max_mean_blend_units"]
    assert int(default_report["mean_stale_units"]) <= cfg["max_mean_stale_units"]
    assert default_report["mean_balance_score"] >= cfg["skew_balance_min"]
    assert default_report["mean_position_bias"] <= cfg["max_mean_position_bias"]


def test_unicode_query_recall(default_report: dict) -> None:
    """q_unicode_mix must reach full recall after Rust normalization repair."""
    row = _query_rows(default_report)["q_unicode_mix"]
    assert row["recall_at_10"] >= 0.9999
    assert row["stale_units"] == 0


def test_tail_sparse_recall(default_report: dict, cfg: dict) -> None:
    """q_tail_sparse must meet recall_floor despite tail bucket routing."""
    row = _query_rows(default_report)["q_tail_sparse"]
    assert row["recall_at_10"] >= cfg["recall_floor"]


def test_position_bias_fairness(default_report: dict, cfg: dict) -> None:
    """Log skew on q_position_bias must still yield position_fairness at floor."""
    row = _query_rows(default_report)["q_position_bias"]
    assert row["position_fairness"] >= cfg["position_fairness_floor"]


def test_dup_impress_purity(default_report: dict) -> None:
    """Duplicate impressions on q_dup_impress must keep impress_purity high."""
    row = _query_rows(default_report)["q_dup_impress"]
    assert row["impress_purity"] >= 0.95


def test_failover_queries_keep_recall(default_report: dict, cfg: dict) -> None:
    """Failover queries must stay above failover_recall_floor with reduced shards_active."""
    rows = _query_rows(default_report)
    lane = rows["q_failover_lane"]
    multi = rows["q_failover_multi"]
    assert lane["shards_active"] == cfg["shard_count"] - 1
    assert multi["shards_active"] == cfg["shard_count"] - 2
    assert lane["recall_at_10"] >= cfg["failover_recall_floor"]
    assert multi["recall_at_10"] >= cfg["failover_recall_floor"]


def test_size_skew_balance_floor(default_report: dict, cfg: dict) -> None:
    """Uneven doc payload sizes must still yield balance_score at skew_balance_min."""
    row = _query_rows(default_report)["q_size_skew"]
    assert row["balance_score"] >= cfg["skew_balance_min"]


def test_audit_profile_matches_manifest(default_report: dict) -> None:
    """audit_profile in the report must match registry rank_manifest.json."""
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    assert default_report["audit_profile"] == manifest["audit_profile"]


def test_ctr_sat_divergence_bounded(default_report: dict) -> None:
    """Dwell-weighted CTR quality must not diverge far above satisfaction on default pack."""
    assert default_report["ctr_sat_divergence"] <= 0.25


def test_determinism_repeat_run(default_report: dict) -> None:
    """Identical inputs must yield byte-identical rank_audit.json."""
    first = OUT.read_bytes()
    OUT.unlink(missing_ok=True)
    subprocess.run(
        ["/app/bin/rankaudit", SESSIONS.as_posix(), OUT.as_posix()],
        cwd=APP,
        check=True,
        timeout=_RUN_TIMEOUT,
        env=_SUBPROC_ENV,
    )
    second = OUT.read_bytes()
    assert first == second


def test_z_ablation_m1_fails_tail_recall() -> None:
    """Tail slot cap must not satisfy recall on q_tail_sparse."""
    shutil.copy2(FIXTURES / "z_w3.go", APP / "cx" / "w3.go")
    report = _rebuild_and_run(
        out_path=APP / "output" / "rank_ablation_m1.json", full_build=False
    )
    cfg = _parse_cfg()
    row = _query_rows(report)["q_tail_sparse"]
    assert row["recall_at_10"] < cfg["recall_floor"]


def test_z_ablation_m2_fails_position_fairness() -> None:
    """Ingest-time sort key must drop position_fairness on q_position_bias."""
    shutil.copy2(FIXTURES / "z_w2.go", APP / "bx" / "w2.go")
    report = _rebuild_and_run(
        out_path=APP / "output" / "rank_ablation_m2.json", full_build=False
    )
    cfg = _parse_cfg()
    row = _query_rows(report)["q_position_bias"]
    assert row["position_fairness"] < cfg["position_fairness_floor"]


def test_z_ablation_m3_fails_impress_purity() -> None:
    """Doc-only dedup gate must collapse impress_purity on q_dup_impress."""
    shutil.copy2(FIXTURES / "z_w3.go", APP / "cx" / "w3.go")
    report = _rebuild_and_run(
        out_path=APP / "output" / "rank_ablation_m3.json", full_build=False
    )
    row = _query_rows(report)["q_dup_impress"]
    assert row["impress_purity"] < 0.95


def test_z_ablation_m4_fails_materialization() -> None:
    """Prefix-only cache keys must raise stale_units on q_position_bias."""
    shutil.copy2(FIXTURES / "z_w6.go", APP / "dx" / "w6.go")
    report = _rebuild_and_run(
        out_path=APP / "output" / "rank_ablation_m4.json", full_build=False
    )
    row = _query_rows(report)["q_position_bias"]
    assert row["stale_units"] > 0


def test_z_ablation_m5_fails_balance() -> None:
    """Single-lane sharding must fail balance on q_size_skew."""
    shutil.copy2(FIXTURES / "z_w5.go", APP / "cx" / "w4.go")
    report = _rebuild_and_run(
        out_path=APP / "output" / "rank_ablation_m5.json", full_build=False
    )
    cfg = _parse_cfg()
    row = _query_rows(report)["q_size_skew"]
    assert row["balance_score"] < cfg["skew_balance_min"]


def test_z_ablation_m6_fails_unicode_materialization() -> None:
    """Broken Rust normalization must raise stale_units on q_unicode_mix."""
    shutil.copy2(FIXTURES / "z_rfold.rs", APP / "rfold" / "src" / "lib.rs")
    report = _rebuild_and_run(out_path=APP / "output" / "rank_ablation_m6.json")
    row = _query_rows(report)["q_unicode_mix"]
    assert row["stale_units"] > 0
