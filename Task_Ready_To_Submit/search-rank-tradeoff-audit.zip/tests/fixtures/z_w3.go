package cx

var seenDoc = map[string]struct{}{}

func OpReset() {
	seenDoc = map[string]struct{}{}
}

func OpAccept(docID string, seq uint64) bool {
	if _, ok := seenDoc[docID]; ok {
		return false
	}
	seenDoc[docID] = struct{}{}
	return true
}

func OpTailCap(bucket string, topK int) int {
	if bucket == "tail" && topK > 3 {
		return 3
	}
	if topK <= 0 {
		return 10
	}
	return topK
}
