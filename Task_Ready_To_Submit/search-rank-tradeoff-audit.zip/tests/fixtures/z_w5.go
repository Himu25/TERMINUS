package cx

import "ranklab.dev/rankaudit/pkg/types"

func OpShardBx(docs []types.Doc, shardCount int) [][]string {
	if shardCount < 1 {
		shardCount = 1
	}
	out := make([][]string, shardCount)
	for _, d := range docs {
		out[0] = append(out[0], d.ID)
	}
	return out
}
