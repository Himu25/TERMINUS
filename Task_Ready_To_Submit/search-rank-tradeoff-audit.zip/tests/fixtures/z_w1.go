package ax

// OpLogWindow returns the impression slice visible after lag budgeting (ablation: head truncate).
func OpLogWindow(eventMs []int64, lagCap int) []int64 {
	if len(eventMs) <= 1 {
		return eventMs
	}
	cut := len(eventMs) / 2
	if lagCap > 0 && cut > lagCap {
		cut = lagCap
	}
	return eventMs[:cut]
}

func OpDwellWeight(clicked int, dwellMs int) float64 {
	if clicked == 0 {
		return 0
	}
	return 1.0
}

func OpLogLagUnits(eventMs []int64) int {
	if len(eventMs) == 0 {
		return 0
	}
	return int(eventMs[len(eventMs)-1] - eventMs[0])
}
