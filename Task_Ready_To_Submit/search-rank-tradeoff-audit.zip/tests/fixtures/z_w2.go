package bx

// OpLogOrderKey orders impression events for fairness replay (ablation: ingest-time key).
func OpLogOrderKey(ingestMs int64, eventMs int64) int64 {
	return ingestMs
}

func OpPrimaryScore(relevance float64, popularity int) float64 {
	return float64(popularity)
}

func OpLogFrontier(eventMs []int64) int64 {
	if len(eventMs) == 0 {
		return 0
	}
	max := eventMs[0]
	for _, v := range eventMs[1:] {
		if v > max {
			max = v
		}
	}
	return max
}
