smoke: build handoff_ctl and run with TB_HANDOFF_FIXTURE=1
