package lg_p9

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/liblg_p9.a -ldl -lm
#include "link_gate.h"
*/
import "C"

// PathLoss returns path attenuation in dB for a link segment.
func PathLoss(distM float64, freqMHz float64, mode int) float64 {
	return float64(C.lf_path_loss(C.double(distM), C.double(freqMHz), C.int(mode)))
}

// HoldAdjust folds edge hold margin into a reference level.
func HoldAdjust(baseDb float64, holdDb float64) float64 {
	return float64(C.lf_hold_adjust(C.double(baseDb), C.double(holdDb)))
}
