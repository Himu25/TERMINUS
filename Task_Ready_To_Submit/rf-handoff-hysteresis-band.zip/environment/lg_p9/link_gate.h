#ifndef LINK_GATE_H
#define LINK_GATE_H

double lf_path_loss(double dist_m, double freq_mhz, int mode);
double lf_hold_adjust(double base_db, double hold_db);

#endif
