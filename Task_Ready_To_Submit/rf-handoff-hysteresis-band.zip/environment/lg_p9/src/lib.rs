use std::os::raw::c_int;

#[no_mangle]
pub extern "C" fn lf_path_loss(dist_m: f64, freq_mhz: f64, mode: c_int) -> f64 {
    let mut d = dist_m;
    if d < 1.0 {
        d = 1.0;
    }
    let mut loss = 20.0 * d.log10() + 20.0 * freq_mhz.log10() - 27.55;
    if mode == 1 {
        loss += 3.0;
    }
    loss
}

#[no_mangle]
pub extern "C" fn lf_hold_adjust(base_db: f64, hold_db: f64) -> f64 {
    if hold_db == 0.0 {
        return base_db;
    }
    if hold_db > 0.0 {
        return base_db + hold_db;
    }
    base_db - hold_db
}
