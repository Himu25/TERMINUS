package main

import (
	"fmt"
	"os"

	"lab.local/rf_handoff/internal/driver"
)

func main() {
	if os.Getenv("TB_HANDOFF_FIXTURE") != "1" {
		fmt.Fprintln(os.Stderr, "set TB_HANDOFF_FIXTURE=1 to run replay")
		os.Exit(2)
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if err := driver.EmitReport("/app", rep); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
