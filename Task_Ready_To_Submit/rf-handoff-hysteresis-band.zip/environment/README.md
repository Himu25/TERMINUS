# rf corridor replay

Four-site chain with per-band hysteresis rows and Rust path attenuation.
