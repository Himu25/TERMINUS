digest_cli helper at /app/tools/digest_cli for report binding checks.
