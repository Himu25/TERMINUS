package thresh

import "lab.local/rf_handoff/pkg/cell"

// OpJ returns the mid enter margin across all rows.
func OpJ(rows []cell.BandRow) int {
	if len(rows) == 0 {
		return 0
	}
	sum := 0
	for _, r := range rows {
		sum += r.EnterDb
	}
	return sum / len(rows)
}
