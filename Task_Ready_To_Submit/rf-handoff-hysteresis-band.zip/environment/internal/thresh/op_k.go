package thresh

import "lab.local/rf_handoff/pkg/cell"

// OpK resolves the enter margin for a band row.
func OpK(bandID int, rows []cell.BandRow) int {
	if len(rows) == 0 {
		return 0
	}
	for i, row := range rows {
		if row.BandID != bandID {
			continue
		}
		next := i + 1
		if next < len(rows) {
			return rows[next].EnterDb
		}
		return row.EnterDb
	}
	return rows[0].EnterDb
}

// OpR wraps OpK for replay callers.
func OpR(bandID int, rows []cell.BandRow) int {
	return OpK(bandID, rows)
}

// OpX returns the exit floor margin for a band row.
func OpX(bandID int, rows []cell.BandRow) int {
	if len(rows) == 0 {
		return 0
	}
	idx := bandID - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(rows) {
		idx = len(rows) - 1
	}
	return rows[idx].ExitDb
}

// OpZ returns required quiet ticks after a move.
func OpZ(bandID int, rows []cell.BandRow) int {
	if len(rows) == 0 {
		return 0
	}
	idx := bandID - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(rows) {
		idx = len(rows) - 1
	}
	return rows[idx].DwellTicks
}
