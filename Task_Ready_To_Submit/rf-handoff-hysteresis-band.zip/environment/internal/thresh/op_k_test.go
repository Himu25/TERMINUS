package thresh

import "testing"

import "lab.local/rf_handoff/pkg/cell"

func TestExitForBandOneBased(t *testing.T) {
	rows := []cell.BandRow{
		{BandID: 1, ExitDb: 8},
		{BandID: 2, ExitDb: 10},
	}
	if got := OpX(2, rows); got != 10 {
		t.Fatalf("exit band 2 = %d want 10", got)
	}
}
