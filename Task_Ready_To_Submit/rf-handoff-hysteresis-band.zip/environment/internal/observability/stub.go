package observability

// Stub keeps compile-time hooks for future tracing.
func Stub() {}
