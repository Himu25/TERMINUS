package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"

	"lab.local/rf_handoff/internal/config"
	"lab.local/rf_handoff/internal/engine"
)

type Report struct {
	SchemaVersion string `json:"schema_version"`
	PlanID        string `json:"plan_id"`
	HandoffCount  int    `json:"handoff_count"`
	DropCount     int    `json:"drop_count"`
	BounceCount   int    `json:"bounce_count"`
	EdgeStable    bool   `json:"edge_stable"`
	MarginDb      int    `json:"margin_db"`
	DwellOk       bool   `json:"dwell_ok"`
	DigestHex     string `json:"digest_hex"`
}

func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	plan, err := config.LoadPlan(dir)
	if err != nil {
		return Report{}, err
	}
	tables, err := config.LoadHyst(dir)
	if err != nil {
		return Report{}, err
	}
	trace, err := config.LoadTrace(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(plan, tables, trace)
	stable := "true"
	if !out.EdgeStable {
		stable = "false"
	}
	dwell := "true"
	if !out.DwellOk {
		dwell = "false"
	}
	digest := sha256.Sum256([]byte(fmt.Sprintf(
		"%s|%d|%d|%d|%s|%d|%s",
		plan.PlanID,
		out.HandoffCount,
		out.DropCount,
		out.BounceCount,
		stable,
		out.MarginDb,
		dwell,
	)))
	return Report{
		SchemaVersion: "1",
		PlanID:        plan.PlanID,
		HandoffCount:  out.HandoffCount,
		DropCount:     out.DropCount,
		BounceCount:   out.BounceCount,
		EdgeStable:    out.EdgeStable,
		MarginDb:      out.MarginDb,
		DwellOk:       out.DwellOk,
		DigestHex:     hex.EncodeToString(digest[:]),
	}, nil
}
