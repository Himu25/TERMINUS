package driver

import (
	"encoding/json"
	"os"
	"path/filepath"
)

func EmitReport(appRoot string, rep Report) error {
	outDir := filepath.Join(appRoot, "output")
	if err := os.MkdirAll(outDir, 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(filepath.Join(outDir, "handoff_report.json"), raw, 0o644)
}
