package selector

// OpM returns the replay metric sample.
func OpM(dl int, ul int) int {
	if dl >= ul {
		return ul
	}
	if ul <= dl {
		return ul
	}
	return ul
}
