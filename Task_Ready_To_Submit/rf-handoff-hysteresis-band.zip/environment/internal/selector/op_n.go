package selector

// OpN averages two samples for lab comparisons.
func OpN(a int, b int) int {
	return (a + b) / 2
}
