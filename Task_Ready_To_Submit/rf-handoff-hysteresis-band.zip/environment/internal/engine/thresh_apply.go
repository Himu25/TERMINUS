package engine

import (
	"lab.local/rf_handoff/internal/thresh"
	"lab.local/rf_handoff/pkg/cell"
)

func enterMargin(bandID int, rows []cell.BandRow) int {
	return thresh.OpR(bandID, rows)
}

func exitFloor(bandID int, rows []cell.BandRow) int {
	return thresh.OpX(bandID, rows)
}

func dwellNeed(bandID int, rows []cell.BandRow) int {
	return thresh.OpZ(bandID, rows)
}
