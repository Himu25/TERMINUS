package engine

import (
	"lab.local/rf_handoff/pkg/cell"
	"lab.local/rf_handoff/pkg/metric"
)

type Outcome struct {
	HandoffCount int
	DropCount    int
	BounceCount  int
	EdgeStable   bool
	MarginDb     int
	DwellOk      bool
}

func siteMap(cells []cell.Site) map[string]cell.Site {
	out := make(map[string]cell.Site, len(cells))
	for _, s := range cells {
		out[s.ID] = s
	}
	return out
}

// Replay walks a mobility tape against the active plan.
func Replay(plan cell.Plan, hystTables cell.HystTables, trace []cell.TracePoint) Outcome {
	sites := siteMap(plan.Cells)
	serving := plan.InitialServe
	if serving == "" && len(plan.Cells) > 0 {
		serving = plan.Cells[0].ID
	}
	lastHandoffTick := map[string]int{}
	prevServing := ""
	handoffs := 0
	drops := 0
	bounces := 0
	minMargin := 999
	edgeStable := true
	dwellOk := true
	lastBand := 0
	if s, ok := sites[serving]; ok {
		lastBand = s.Band
	}

	for _, pt := range trace {
		cur, ok := sites[serving]
		if !ok {
			continue
		}
		sDl, sUl := metric.RSSIPair(plan, cur, pt.X, pt.Y)
		servingMetric := compareSample(sDl, sUl)
		exitDb := exitFloor(cur.Band, hystTables.Bands)
		enterDb := enterMargin(cur.Band, hystTables.Bands)
		dwellTicks := dwellNeed(cur.Band, hystTables.Bands)

		margin := servingMetric - exitDb
		if margin < minMargin {
			minMargin = margin
		}

		neighbors := plan.Neighbors[serving]
		bestNeighbor := ""
		bestDelta := -999
		for _, nid := range neighbors {
			ns, ok := sites[nid]
			if !ok {
				continue
			}
			nDl, nUl := metric.RSSIPair(plan, ns, pt.X, pt.Y)
			nMetric := compareSample(nDl, nUl)
			delta := nMetric - servingMetric
			if delta > bestDelta {
				bestDelta = delta
				bestNeighbor = nid
			}
		}

		key := quietKey(serving, cur.Band)
		lastTick := lastHandoffTick[key]
		quiet := pt.Tick-lastTick >= dwellTicks

		if bestNeighbor != "" && bestDelta >= enterDb && quiet {
			handoffs++
			if prevServing != "" && bestNeighbor == prevServing {
				bounces++
				edgeStable = false
			}
			ns := sites[bestNeighbor]
			if ns.Band != lastBand {
				if bounces > 0 || drops > 0 {
					edgeStable = false
				}
			}
			prevServing = serving
			serving = bestNeighbor
			lastHandoffTick[key] = pt.Tick
			cur = ns
			lastBand = cur.Band
		} else if servingMetric < exitDb {
			drops++
			edgeStable = false
		} else if !quiet && bestNeighbor != "" && bestDelta >= enterDb {
			dwellOk = false
		}
	}

	if minMargin == 999 {
		minMargin = 0
	}
	return Outcome{
		HandoffCount: handoffs,
		DropCount:    drops,
		BounceCount:  bounces,
		EdgeStable:   edgeStable,
		MarginDb:     minMargin,
		DwellOk:      dwellOk,
	}
}
