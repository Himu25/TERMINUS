package engine

import (
	"testing"

	"lab.local/rf_handoff/pkg/cell"
)

func TestReplayEmptyTrace(t *testing.T) {
	plan := cell.Plan{
		InitialServe: "a",
		Cells:        []cell.Site{{ID: "a", Band: 1, FreqMHz: 2100}},
		Neighbors:    map[string][]string{"a": {}},
	}
	out := Replay(plan, cell.HystTables{Bands: []cell.BandRow{{BandID: 1, EnterDb: 3, ExitDb: -55, DwellTicks: 4}}}, nil)
	if out.HandoffCount != 0 {
		t.Fatalf("expected zero handoffs, got %d", out.HandoffCount)
	}
}
