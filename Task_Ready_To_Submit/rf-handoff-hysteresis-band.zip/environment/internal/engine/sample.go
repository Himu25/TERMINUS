package engine

import (
	"lab.local/rf_handoff/internal/selector"
	"lab.local/rf_handoff/pkg/quiet"
)

func compareSample(dl int, ul int) int {
	return selector.OpM(dl, ul)
}

func quietKey(site string, band int) string {
	return quiet.OpQ(site, band)
}
