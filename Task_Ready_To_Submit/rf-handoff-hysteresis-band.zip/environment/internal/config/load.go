package config

import (
	"encoding/json"
	"os"
	"path/filepath"

	"lab.local/rf_handoff/pkg/cell"
)

type ActiveDir struct {
	Root string
}

func ActivePaths(appRoot string) (ActiveDir, error) {
	return ActiveDir{Root: filepath.Join(appRoot, "data", "active")}, nil
}

func LoadPlan(dir ActiveDir) (cell.Plan, error) {
	raw, err := os.ReadFile(filepath.Join(dir.Root, "network_plan.json"))
	if err != nil {
		return cell.Plan{}, err
	}
	var plan cell.Plan
	if err := json.Unmarshal(raw, &plan); err != nil {
		return cell.Plan{}, err
	}
	return plan, nil
}

func LoadHyst(dir ActiveDir) (cell.HystTables, error) {
	raw, err := os.ReadFile(filepath.Join(dir.Root, "hyst_tables.json"))
	if err != nil {
		return cell.HystTables{}, err
	}
	var tables cell.HystTables
	if err := json.Unmarshal(raw, &tables); err != nil {
		return cell.HystTables{}, err
	}
	return tables, nil
}

func LoadTrace(dir ActiveDir) ([]cell.TracePoint, error) {
	raw, err := os.ReadFile(filepath.Join(dir.Root, "traces", "trace_001.jsonl"))
	if err != nil {
		return nil, err
	}
	var pts []cell.TracePoint
	for _, line := range splitLines(string(raw)) {
		if line == "" {
			continue
		}
		var pt cell.TracePoint
		if err := json.Unmarshal([]byte(line), &pt); err != nil {
			return nil, err
		}
		pts = append(pts, pt)
	}
	return pts, nil
}

func splitLines(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			out = append(out, s[start:i])
			start = i + 1
		}
	}
	if start < len(s) {
		out = append(out, s[start:])
	}
	return out
}
