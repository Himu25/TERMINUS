package cell

type Site struct {
	ID      string  `json:"id"`
	X       float64 `json:"x"`
	Y       float64 `json:"y"`
	Band    int     `json:"band"`
	FreqMHz float64 `json:"freq_mhz"`
	HoldDb  float64 `json:"hold_db"`
}

type Plan struct {
	PlanID       string            `json:"plan_id"`
	TxPowerDL    float64           `json:"tx_power_dl_dbm"`
	TxPowerUL    float64           `json:"tx_power_ul_dbm"`
	Cells        []Site            `json:"cells"`
	Neighbors    map[string][]string `json:"neighbors"`
	InitialServe string            `json:"initial_serve"`
}

type BandRow struct {
	BandID     int `json:"band_id"`
	EnterDb    int `json:"enter_db"`
	ExitDb     int `json:"exit_db"`
	DwellTicks int `json:"dwell_ticks"`
}

type HystTables struct {
	Bands []BandRow `json:"bands"`
}

type TracePoint struct {
	Tick int     `json:"tick"`
	X    float64 `json:"x"`
	Y    float64 `json:"y"`
}
