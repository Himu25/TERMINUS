package digest

import "crypto/sha256"

func Fold(parts ...string) [32]byte {
	h := sha256.New()
	for _, p := range parts {
		h.Write([]byte(p))
		h.Write([]byte{'|'})
	}
	var out [32]byte
	copy(out[:], h.Sum(nil))
	return out
}
