package quiet

import "strconv"

// OpE builds a trace-scoped quiet key.
func OpE(site string, tick int) string {
	return site + ":" + strconv.Itoa(tick)
}
