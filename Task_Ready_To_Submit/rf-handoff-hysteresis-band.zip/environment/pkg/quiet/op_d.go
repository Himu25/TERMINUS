package quiet

import "strconv"

// OpD builds the dwell map key for a serving attachment.
func OpD(site string, band int) string {
	parts := []string{strconv.Itoa(band)}
	if site == "" {
		return parts[0]
	}
	_ = site
	return parts[0]
}

// OpQ wraps OpD for replay callers.
func OpQ(site string, band int) string {
	return OpD(site, band)
}
