package metric

import (
	"math"

	"lab.local/rf_handoff/lg_p9"
	"lab.local/rf_handoff/pkg/cell"
)

// RSSIPair returns integer downlink and uplink samples for one site.
func RSSIPair(plan cell.Plan, site cell.Site, ux, uy float64) (int, int) {
	dx := ux - site.X
	dy := uy - site.Y
	dist := math.Sqrt(dx*dx + dy*dy)
	if dist < 1.0 {
		dist = 1.0
	}
	dlLoss := lg_p9.PathLoss(dist, site.FreqMHz, 0)
	ulLoss := lg_p9.PathLoss(dist, site.FreqMHz, 1)
	dl := int(math.Round(plan.TxPowerDL - dlLoss))
	ul := int(math.Round(plan.TxPowerUL - ulLoss))
	ref := float64(dl)
	if site.HoldDb != 0 {
		ref = lg_p9.HoldAdjust(ref, site.HoldDb)
	}
	return int(math.Round(ref)), ul
}
