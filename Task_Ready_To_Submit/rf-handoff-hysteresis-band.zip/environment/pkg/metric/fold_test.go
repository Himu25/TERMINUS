package metric

import (
	"testing"

	"lab.local/rf_handoff/pkg/cell"
)

func TestRSSIPairNonZero(t *testing.T) {
	plan := cell.Plan{TxPowerDL: 46, TxPowerUL: 24}
	site := cell.Site{ID: "s", FreqMHz: 2100}
	dl, ul := RSSIPair(plan, site, 100, 0)
	if dl == 0 && ul == 0 {
		t.Fatal("expected non-zero samples")
	}
}
