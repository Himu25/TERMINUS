module lab.local/rf_handoff

go 1.22
