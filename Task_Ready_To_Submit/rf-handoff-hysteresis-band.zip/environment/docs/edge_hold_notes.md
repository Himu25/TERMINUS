Band-edge hold windows adjust the serving reference before neighbor evaluation.
When hold_db is non-zero, effective serving downlink is base downlink minus hold_db.
