# corridor layout

Four-site chain with two carrier bands. Mobility tapes sweep east along the x axis.

## replay inputs

- network_plan.json — site geometry and neighbor graph
- hyst_tables.json — ordered band rows; enter, exit, and dwell parameters resolve from row index band minus one, clamped to table bounds
- traces/trace_001.jsonl — tick, x, y samples

## driver

handoff_ctl reads the active pack and emits handoff_report.json when TB_HANDOFF_FIXTURE=1.

## deterministic replay semantics

- serving reference uses downlink as the comparison sample
- hold margin fold is subtractive: effective downlink reference is downlink minus hold_db when hold is non-zero
- enter, exit, and dwell thresholds share the same indexed row selection (band minus one, with low and high clamp)
- quiet-period map keys are scoped as site colon band
- quiet-period bookkeeping updates on the departing site-band attachment when a handoff occurs
