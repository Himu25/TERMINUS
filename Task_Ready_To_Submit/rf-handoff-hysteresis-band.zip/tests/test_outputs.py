"""Verifier for RF corridor handoff replay report."""

import json
import os
import shutil
import subprocess

import pytest
from pathlib import Path

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = Path("/tests") / "fixtures"
OUT = APP / "output" / "handoff_report.json"
GO_BIN = "go"
VERIFY_BIN = "/app/output/handoff_verify_bin"
_LOG10_CACHE: dict[float, float] = {}


def _log10(x: float) -> float:
    key = round(x, 8)
    if key not in _LOG10_CACHE:
        out = subprocess.check_output(
            ["python3", "-c", f"import math; print(math.log10({key}))"],
            text=True,
        )
        _LOG10_CACHE[key] = float(out.strip())
    return _LOG10_CACHE[key]


def _hypot(ax: float, ay: float) -> float:
    return float(
        subprocess.check_output(
            ["python3", "-c", f"import math; print(math.hypot({ax}, {ay}))"],
            text=True,
        ).strip()
    )


def _path_loss(dist_m: float, freq_mhz: float, mode: int) -> float:
    d = max(dist_m, 1.0)
    loss = 20 * _log10(d) + 20 * _log10(freq_mhz) - 27.55
    if mode == 1:
        loss += 3.0
    return loss


def _hold_adjust(base_db: float, hold_db: float) -> float:
    if hold_db == 0.0:
        return base_db
    return base_db - hold_db


def _rssi_pair(plan: dict, site: dict, ux: float, uy: float) -> tuple[int, int]:
    dx = ux - site["x"]
    dy = uy - site["y"]
    dist = max(_hypot(dx, dy), 1.0)
    dl = int(round(plan["tx_power_dl_dbm"] - _path_loss(dist, site["freq_mhz"], 0)))
    ul = int(round(plan["tx_power_ul_dbm"] - _path_loss(dist, site["freq_mhz"], 1)))
    ref = float(dl)
    if site.get("hold_db", 0):
        ref = _hold_adjust(ref, site["hold_db"])
    return int(round(ref)), ul


def _op_m(dl: int, ul: int) -> int:
    return dl


def _op_k(band_id: int, rows: list[dict]) -> int:
    idx = band_id - 1
    if idx < 0:
        idx = 0
    if idx >= len(rows):
        idx = len(rows) - 1
    return rows[idx]["enter_db"]


def _exit_for_band(band_id: int, rows: list[dict]) -> int:
    idx = band_id - 1
    if idx < 0:
        idx = 0
    if idx >= len(rows):
        idx = len(rows) - 1
    return rows[idx]["exit_db"]


def _dwell_for_band(band_id: int, rows: list[dict]) -> int:
    idx = band_id - 1
    if idx < 0:
        idx = 0
    if idx >= len(rows):
        idx = len(rows) - 1
    return rows[idx]["dwell_ticks"]


def _op_d(site: str, band: int) -> str:
    return f"{site}:{band}"


def _digest_hex(
    plan_id: str,
    handoff: int,
    drop: int,
    bounce: int,
    stable: bool,
    margin: int,
    dwell: bool,
) -> str:
    st = "true" if stable else "false"
    dw = "true" if dwell else "false"
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            plan_id,
            str(handoff),
            str(drop),
            str(bounce),
            st,
            str(margin),
            dw,
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _expected_from_fixture(name: str) -> dict:
    pack_dir = FIXTURES / name
    plan = json.loads((pack_dir / "network_plan.json").read_text())
    tables = json.loads((pack_dir / "hyst_tables.json").read_text())
    rows = tables["bands"]
    sites = {c["id"]: c for c in plan["cells"]}
    trace = []
    for line in (pack_dir / "traces" / "trace_001.jsonl").read_text().splitlines():
        if line.strip():
            trace.append(json.loads(line))

    serving = plan.get("initial_serve") or plan["cells"][0]["id"]
    last_handoff: dict[str, int] = {}
    prev_serving = ""
    handoffs = 0
    drops = 0
    bounces = 0
    min_margin = 999
    edge_stable = True
    dwell_ok = True
    last_band = sites[serving]["band"]

    for pt in trace:
        cur = sites[serving]
        s_dl, s_ul = _rssi_pair(plan, cur, pt["x"], pt["y"])
        serving_metric = _op_m(s_dl, s_ul)
        exit_db = _exit_for_band(cur["band"], rows)
        enter_db = _op_k(cur["band"], rows)
        dwell_need = _dwell_for_band(cur["band"], rows)
        margin = serving_metric - exit_db
        min_margin = min(min_margin, margin)

        best_neighbor = ""
        best_delta = -999
        for nid in plan["neighbors"].get(serving, []):
            ns = sites[nid]
            n_dl, n_ul = _rssi_pair(plan, ns, pt["x"], pt["y"])
            n_metric = _op_m(n_dl, n_ul)
            delta = n_metric - serving_metric
            if delta > best_delta:
                best_delta = delta
                best_neighbor = nid

        key = _op_d(serving, cur["band"])
        last_tick = last_handoff.get(key, -9999)
        quiet = pt["tick"] - last_tick >= dwell_need

        if best_neighbor and best_delta >= enter_db and quiet:
            handoffs += 1
            if prev_serving and best_neighbor == prev_serving:
                bounces += 1
                edge_stable = False
            ns = sites[best_neighbor]
            if ns["band"] != last_band and (bounces > 0 or drops > 0):
                edge_stable = False
            prev_serving = serving
            serving = best_neighbor
            last_handoff[key] = pt["tick"]
            cur = sites[serving]
            last_band = cur["band"]
        elif serving_metric < exit_db:
            drops += 1
            edge_stable = False
        elif not quiet and best_neighbor and best_delta >= enter_db:
            dwell_ok = False

    if min_margin == 999:
        min_margin = 0

    digest = _digest_hex(
        plan["plan_id"], handoffs, drops, bounces, edge_stable, min_margin, dwell_ok
    )
    return {
        "schema_version": "1",
        "plan_id": plan["plan_id"],
        "handoff_count": handoffs,
        "drop_count": drops,
        "bounce_count": bounces,
        "edge_stable": edge_stable,
        "margin_db": min_margin,
        "dwell_ok": dwell_ok,
        "digest_hex": digest,
    }


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)
    subprocess.run(["cp", "/app/bin/handoff_ctl", VERIFY_BIN], check=True)


def _swap(name: str) -> None:
    src = FIXTURES / name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_HANDOFF_FIXTURE": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_r01_alpha_report_matches_replay() -> None:
    """Alpha corridor tape should replay cleanly with stable band edges."""
    _swap("trace_alpha")
    exp = _expected_from_fixture("trace_alpha")
    got = _run_tool()
    assert got == exp


def test_r02_beta_hold_margin_on_band_edge() -> None:
    """Beta lingers on the band-two edge where hold margin adjusts serving reference."""
    _swap("trace_beta")
    exp = _expected_from_fixture("trace_beta")
    got = _run_tool()
    assert got["handoff_count"] == exp["handoff_count"]
    assert got["margin_db"] == exp["margin_db"]


def test_r03_gamma_bounce_count() -> None:
    """Gamma oscillation near the band-one to band-two seam must not ping-pong."""
    _swap("trace_gamma")
    exp = _expected_from_fixture("trace_gamma")
    got = _run_tool()
    assert got["bounce_count"] == exp["bounce_count"]
    assert got["edge_stable"] == exp["edge_stable"]


def test_r04_delta_drop_count() -> None:
    """Delta tape should not drop while downlink margin stays above the exit floor."""
    _swap("trace_delta")
    exp = _expected_from_fixture("trace_delta")
    got = _run_tool()
    assert got["drop_count"] == exp["drop_count"]


def test_r05_epsilon_dwell_ok() -> None:
    """Epsilon rapid seam crossings must respect per-band quiet periods."""
    _swap("trace_epsilon")
    exp = _expected_from_fixture("trace_epsilon")
    got = _run_tool()
    assert got["dwell_ok"] == exp["dwell_ok"]
    assert got["handoff_count"] == exp["handoff_count"]


def test_r06_digest_binding() -> None:
    """Report digest must bind counters and stability flags."""
    _swap("trace_alpha")
    exp = _expected_from_fixture("trace_alpha")
    got = _run_tool()
    assert got["digest_hex"] == exp["digest_hex"]


def test_r07_go_unit_tests_pass() -> None:
    """Go unit tests under /app must pass after the repair."""
    subprocess.run(
        [GO_BIN, "test", "./..."],
        cwd="/app",
        env={
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        },
        check=True,
    )
