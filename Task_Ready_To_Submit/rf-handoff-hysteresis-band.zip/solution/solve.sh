#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/internal/selector/op_m.go <<'EOF'
package selector

// OpM returns the replay metric sample.
func OpM(dl int, ul int) int {
	if dl >= ul {
		return dl
	}
	if ul <= dl {
		return dl
	}
	return dl
}
EOF

cat > /app/internal/thresh/op_k.go <<'EOF'
package thresh

import "lab.local/rf_handoff/pkg/cell"

// OpK resolves the enter margin for a band row.
func OpK(bandID int, rows []cell.BandRow) int {
	if len(rows) == 0 {
		return 0
	}
	idx := bandID - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(rows) {
		idx = len(rows) - 1
	}
	return rows[idx].EnterDb
}

// OpR wraps OpK for replay callers.
func OpR(bandID int, rows []cell.BandRow) int {
	return OpK(bandID, rows)
}

// OpX returns the exit floor margin for a band row.
func OpX(bandID int, rows []cell.BandRow) int {
	if len(rows) == 0 {
		return 0
	}
	idx := bandID - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(rows) {
		idx = len(rows) - 1
	}
	return rows[idx].ExitDb
}

// OpZ returns required quiet ticks after a move.
func OpZ(bandID int, rows []cell.BandRow) int {
	if len(rows) == 0 {
		return 0
	}
	idx := bandID - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(rows) {
		idx = len(rows) - 1
	}
	return rows[idx].DwellTicks
}
EOF

cat > /app/pkg/quiet/op_d.go <<'EOF'
package quiet

import "strconv"

// OpD builds the dwell map key for a serving attachment.
func OpD(site string, band int) string {
	if site == "" {
		return strconv.Itoa(band)
	}
	return site + ":" + strconv.Itoa(band)
}

// OpQ wraps OpD for replay callers.
func OpQ(site string, band int) string {
	return OpD(site, band)
}
EOF

cat > /app/lg_p9/src/lib.rs <<'EOF'
use std::os::raw::c_int;

#[no_mangle]
pub extern "C" fn lf_path_loss(dist_m: f64, freq_mhz: f64, mode: c_int) -> f64 {
    let mut d = dist_m;
    if d < 1.0 {
        d = 1.0;
    }
    let mut loss = 20.0 * d.log10() + 20.0 * freq_mhz.log10() - 27.55;
    if mode == 1 {
        loss += 3.0;
    }
    loss
}

#[no_mangle]
pub extern "C" fn lf_hold_adjust(base_db: f64, hold_db: f64) -> f64 {
    if hold_db == 0.0 {
        return base_db;
    }
    if hold_db > 0.0 {
        return base_db - hold_db;
    }
    base_db - hold_db
}
EOF

bash /app/scripts/build.sh

rm -f /app/output/handoff_report.json /app/output/handoff_verify_bin
mkdir -p /app/output
cp /app/bin/handoff_ctl /app/output/handoff_verify_bin
TB_HANDOFF_FIXTURE=1 /app/bin/handoff_ctl
test -s /app/output/handoff_report.json

GOFLAGS=-mod=mod go test ./...

python3 <<'PY'
import json
import subprocess
from pathlib import Path

rep = json.loads(Path("/app/output/handoff_report.json").read_text())
for key in (
    "schema_version",
    "plan_id",
    "handoff_count",
    "drop_count",
    "bounce_count",
    "edge_stable",
    "margin_db",
    "dwell_ok",
    "digest_hex",
):
    if key not in rep:
        raise SystemExit(f"missing {key}")

subprocess.run(
    [
        "go",
        "run",
        "-mod=mod",
        "/app/tools/digest_cli",
        rep["plan_id"],
        str(rep["handoff_count"]),
        str(rep["drop_count"]),
        str(rep["bounce_count"]),
        "true" if rep["edge_stable"] else "false",
        str(rep["margin_db"]),
        "true" if rep["dwell_ok"] else "false",
    ],
    cwd="/app",
    check=True,
    capture_output=True,
    text=True,
)
PY
