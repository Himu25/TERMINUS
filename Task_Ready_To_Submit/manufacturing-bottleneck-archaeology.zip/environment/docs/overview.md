Plant throughput archaeology lab.

The harness models line units as tick-indexed stage paths. Overlap detection applies a
revision-dependent zone shift. Retune planning can chain multiple lateral hops.
SLA checks compare completion ticks against per-unit ceilings. Session stashes
record blocked unit ids between delayed telemetry passes.

The workspace splits geometry, overlap helpers, retune utilities, orchestration, and
per-run session state across several internal crates wired through the plant driver.
Typical failure modes include stale cache reuse, broken multi-hop ownership, SLA gate
mismatches, and session ids carried into later passes.

Run `/app/scripts/build.sh` then `/app/bin/plant_lab` with TB_PLANT_FIXTURE=1.
