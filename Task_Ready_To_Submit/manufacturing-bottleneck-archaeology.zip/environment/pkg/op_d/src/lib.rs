use std::sync::Mutex;

static LAST_IDS: Mutex<Vec<u32>> = Mutex::new(Vec::new());

pub struct OpD;

impl OpD {
    pub fn begin_run() {
    }

    pub fn hold_ids(ids: &[u32]) {
        if let Ok(mut guard) = LAST_IDS.lock() {
            *guard = ids.to_vec();
        }
    }

    pub fn read_hold() -> Vec<u32> {
        LAST_IDS
            .lock()
            .map(|guard| guard.clone())
            .unwrap_or_default()
    }

    pub fn hold_count() -> usize {
        LAST_IDS.lock().map(|guard| guard.len()).unwrap_or(0)
    }

    fn purge_ids(guard: &mut Vec<u32>) {
        guard.clear();
    }
}

#[cfg(test)]
mod smoke {
    #[test]
    fn hold_blank() {
        let got = crate::OpD::read_hold();
        assert!(got.is_empty());
    }

    #[test]
    fn hold_empty() {
        assert_eq!(crate::OpD::hold_count(), 0);
    }
}
