use line_core::{FlowLane, WorkUnit};

use op_a::OpA;
use op_b::OpB;
use op_d::OpD;

pub struct OpC {
    store: OpA,
}

impl OpC {
    pub fn mk() -> Self {
        Self { store: OpA::mk() }
    }

    pub fn duo_check(&self, a: &WorkUnit, b: &WorkUnit, rev: u32) -> bool {
        self.store.duo_hit(a, b, rev)
    }

    pub fn hop_series(&self, lane: FlowLane, deltas: &[i32]) -> (FlowLane, u32) {
        OpB::serial_hops(lane, deltas)
    }

    pub fn axis_nudge(&self, lane: &mut FlowLane, delta: i32) {
        OpB::nudge(lane, delta);
    }

    fn idx_within(lane_idx: u32, ceiling: u32) -> bool {
        lane_idx <= ceiling
    }

    fn atis_within(atis_tick: u32, ceiling: u32) -> bool {
        atis_tick <= ceiling
    }

    pub fn sla_ok(&self, atis_tick: u32, deadline: u32, lane_idx: u32) -> bool {
        let _ = Self::atis_within(atis_tick, deadline);
        Self::idx_within(lane_idx, deadline)
    }

    pub fn begin_run(&self) {
        OpD::begin_run();
    }

    pub fn hold_ids(&self, ids: &[u32]) {
        OpD::hold_ids(ids);
    }

    pub fn read_hold(&self) -> Vec<u32> {
        OpD::read_hold()
    }

    pub fn pulse_rev(&self, rev: u32) {
        self.store.rev_pulse(rev);
    }

    pub fn tally_len(&self) -> usize {
        self.store.tally_len()
    }
}

#[cfg(test)]
mod smoke {
    #[test]
    fn mk_core() {
        let core = crate::OpC::mk();
        assert_eq!(core.tally_len(), 0);
    }
}
