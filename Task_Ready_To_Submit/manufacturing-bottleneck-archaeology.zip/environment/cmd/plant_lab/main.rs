//! plant_lab writes /app/output/factory_report.json with schema_version 2,
//! plant_id, scenarios[] where each row has name, finish_reason,
//! stations_blocked, retunes_applied, sla_met, line_clear,
//! memo_fresh, backlog_drained, rush_resolved, digest_hex.

use std::env;
use std::fs;
use std::path::PathBuf;

use plant_driver::{load_plan, run_bundle};

fn read_stems(path: &PathBuf) -> Vec<String> {
    let raw = fs::read_to_string(path).expect("scenario index");
    raw.lines()
        .map(str::trim)
        .filter(|line| !line.is_empty() && !line.starts_with('#'))
        .map(str::to_string)
        .collect()
}

fn main() {
    let plan_path = PathBuf::from("/app/data/active/plan.json");
    let plan = load_plan(&plan_path);
    let mut names = vec![
        "case_stn_overlap".to_string(),
        "case_lane_shift".to_string(),
        "case_sla_window".to_string(),
        "case_even_flow".to_string(),
        "case_peak_load".to_string(),
    ];
    if env::var("TB_PLANT_FIXTURE").ok().as_deref() == Some("1") {
        let stems = read_stems(&PathBuf::from("/app/docs/scenario_index.txt"));
        names.extend(stems);
    }
    names.sort();
    names.dedup();

    let report = run_bundle(&plan, &names);
    fs::create_dir_all("/app/output").expect("output dir");
    let encoded = serde_json::to_string_pretty(&report).expect("encode report");
    fs::write("/app/output/factory_report.json", encoded).expect("write report");
}
