# Manufacturing plant lab — throughput archaeology harness

Rust workspace under `/app` replays production history bundles and writes
`/app/output/factory_report.json`. See `/app/docs/overview.md` for module roles.
