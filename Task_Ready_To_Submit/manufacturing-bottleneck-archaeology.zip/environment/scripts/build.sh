#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:${PATH}"
cd /app
mkdir -p /app/bin /app/output

target_root="${CARGO_TARGET_DIR:-/tmp/cargo-target}"

cargo build --release --bin plant_lab
install -m 0755 "${target_root}/release/plant_lab" /app/bin/plant_lab
cargo build --release --bin digest_cli
install -m 0755 "${target_root}/release/digest_cli" /app/bin/digest_cli
