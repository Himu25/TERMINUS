#!/usr/bin/env bash
set -euo pipefail
test -x /app/scripts/build.sh
test -f /app/data/active/plan.json
