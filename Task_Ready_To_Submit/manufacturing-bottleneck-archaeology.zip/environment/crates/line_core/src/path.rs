#[derive(Debug, Clone)]
pub struct StagePt {
    pub x: i32,
    pub y: i32,
    pub tick: u32,
}

#[derive(Debug, Clone)]
pub struct WorkUnit {
    pub id: u32,
    pub waypoints: Vec<StagePt>,
    pub deadline_tick: u32,
    pub priority: u32,
}

#[derive(Debug, Clone)]
pub struct FlowLane {
    pub waypoints: Vec<StagePt>,
    pub link_id: u32,
    pub lane_idx: u32,
}

impl WorkUnit {
    pub fn mk(id: u32, pts: Vec<(i32, i32, u32)>, deadline: u32, priority: u32) -> Self {
        Self {
            id,
            waypoints: pts
                .into_iter()
                .map(|(x, y, tick)| StagePt { x, y, tick })
                .collect(),
            deadline_tick: deadline,
            priority,
        }
    }
}

impl FlowLane {
    pub fn from_unit(track: &WorkUnit) -> Self {
        Self {
            waypoints: track.waypoints.clone(),
            link_id: track.id,
            lane_idx: track.waypoints.last().map(|p| p.tick).unwrap_or(0),
        }
    }
}
