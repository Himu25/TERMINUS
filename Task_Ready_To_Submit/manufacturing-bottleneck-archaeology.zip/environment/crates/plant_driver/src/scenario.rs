use std::path::Path;

use line_core::{FlowLane, WorkUnit};
use op_c::OpC;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

#[derive(Debug, Clone, Deserialize)]
pub struct Plan {
    pub plant_id: String,
    pub line_count: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScenarioRow {
    pub name: String,
    pub finish_reason: String,
    pub stations_blocked: u32,
    pub retunes_applied: u32,
    pub sla_met: u32,
    pub line_clear: u32,
    pub memo_fresh: u32,
    pub backlog_drained: u32,
    pub rush_resolved: u32,
    pub digest_hex: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Report {
    pub schema_version: u32,
    pub plant_id: String,
    pub scenarios: Vec<ScenarioRow>,
}

pub fn load_plan(path: &Path) -> Plan {
    let raw = std::fs::read_to_string(path).expect("plan json");
    serde_json::from_str(&raw).expect("plan parse")
}

pub fn digest_row(row: &ScenarioRow) -> String {
    let payload = format!(
        "{}|{}|{}|{}|{}|{}|{}|{}|{}|",
        row.name,
        row.finish_reason,
        row.stations_blocked,
        row.retunes_applied,
        row.sla_met,
        row.line_clear,
        row.memo_fresh,
        row.backlog_drained,
        row.rush_resolved,
    );
    format!("{:x}", Sha256::digest(payload.as_bytes()))
}

fn seal(mut row: ScenarioRow) -> ScenarioRow {
    row.digest_hex = digest_row(&row);
    row
}

fn unit_to_lane(track: &WorkUnit) -> FlowLane {
    FlowLane::from_unit(track)
}

pub fn run_stn_overlap(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let a = WorkUnit::mk(1, vec![(0, 0, 2), (5, 0, 4)], 10, 1);
    let b = WorkUnit::mk(2, vec![(5, 0, 4), (10, 0, 6)], 10, 1);
    let hit = core.duo_check(&a, &b, 0);
    seal(ScenarioRow {
        name: "case_stn_overlap".into(),
        finish_reason: if hit { "complete" } else { "stuck" }.into(),
        stations_blocked: if hit { 1 } else { 0 },
        retunes_applied: 0,
        sla_met: 0,
        line_clear: 0,
        memo_fresh: 0,
        backlog_drained: 0,
        rush_resolved: 0,
        digest_hex: String::new(),
    })
}

pub fn run_lane_shift(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let a = WorkUnit::mk(1, vec![(0, 0, 2), (5, 0, 4)], 12, 1);
    let b = WorkUnit::mk(2, vec![(5, 0, 4), (10, 0, 6)], 12, 1);
    let mut lane = unit_to_lane(&a);
    let hit_before = core.duo_check(&a, &b, 0);
    core.axis_nudge(&mut lane, 8);
    let a2 = WorkUnit::mk(1, lane.waypoints.iter().map(|p| (p.x, p.y, p.tick)).collect(), 12, 1);
    let hit_after = core.duo_check(&a2, &b, 0);
    let clean = hit_before && !hit_after;
    seal(ScenarioRow {
        name: "case_lane_shift".into(),
        finish_reason: if clean { "complete" } else { "stuck" }.into(),
        stations_blocked: if hit_before { 1 } else { 0 },
        retunes_applied: if clean { 1 } else { 0 },
        sla_met: 0,
        line_clear: if clean { 1 } else { 0 },
        memo_fresh: 0,
        backlog_drained: 0,
        rush_resolved: 0,
        digest_hex: String::new(),
    })
}

pub fn run_sla_window(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let track = WorkUnit::mk(3, vec![(0, 0, 1), (4, 0, 5)], 8, 2);
    let mut lane = unit_to_lane(&track);
    lane.lane_idx = 10;
    core.axis_nudge(&mut lane, 2);
    let atis = lane.waypoints.last().map(|p| p.tick).unwrap_or(0);
    let ok = core.sla_ok(atis, track.deadline_tick, lane.lane_idx);
    seal(ScenarioRow {
        name: "case_sla_window".into(),
        finish_reason: if ok { "complete" } else { "stuck" }.into(),
        stations_blocked: 0,
        retunes_applied: 1,
        sla_met: if ok { 1 } else { 0 },
        line_clear: 0,
        memo_fresh: 0,
        backlog_drained: 0,
        rush_resolved: 0,
        digest_hex: String::new(),
    })
}

pub fn run_even_flow(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let a = WorkUnit::mk(4, vec![(0, 0, 1), (0, 5, 3)], 10, 1);
    let b = WorkUnit::mk(5, vec![(10, 0, 1), (10, 5, 3)], 10, 1);
    let hit = core.duo_check(&a, &b, 0);
    seal(ScenarioRow {
        name: "case_even_flow".into(),
        finish_reason: if !hit { "complete" } else { "blocked" }.into(),
        stations_blocked: 0,
        retunes_applied: 0,
        sla_met: 0,
        line_clear: if !hit { 1 } else { 0 },
        memo_fresh: 0,
        backlog_drained: 0,
        rush_resolved: 0,
        digest_hex: String::new(),
    })
}

pub fn run_chain_shift(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let a = WorkUnit::mk(6, vec![(0, 0, 2), (5, 0, 4), (10, 0, 6)], 14, 1);
    let b = WorkUnit::mk(7, vec![(5, 0, 4), (5, 5, 6)], 14, 1);
    let lane = unit_to_lane(&a);
    let hit_before = core.duo_check(&a, &b, 0);
    let (shifted, hops) = core.hop_series(lane, &[6, 4]);
    let a2 = WorkUnit::mk(
        6,
        shifted
            .waypoints
            .iter()
            .map(|p| (p.x, p.y, p.tick))
            .collect(),
        14,
        1,
    );
    let hit_after = core.duo_check(&a2, &b, 0);
    let clean = hit_before && !hit_after && hops == 2;
    seal(ScenarioRow {
        name: "case_chain_shift".into(),
        finish_reason: if clean { "complete" } else { "partial" }.into(),
        stations_blocked: if hit_before { 1 } else { 0 },
        retunes_applied: hops,
        sla_met: 0,
        line_clear: if clean { 1 } else { 0 },
        memo_fresh: 0,
        backlog_drained: 0,
        rush_resolved: 0,
        digest_hex: String::new(),
    })
}

pub fn run_peak_load(plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let count = plan.line_count.max(4);
    let mut tracks = Vec::new();
    for i in 0..count {
        let x = (i as i32) * 3;
        tracks.push(WorkUnit::mk(
            100 + i,
            vec![(x, 0, 2), (x + 2, 0, 4)],
            20,
            1,
        ));
    }
    let mut conflicts = 0u32;
    for i in 0..tracks.len() {
        for j in (i + 1)..tracks.len() {
            if core.duo_check(&tracks[i], &tracks[j], 0) {
                conflicts += 1;
                let mut lane = unit_to_lane(&tracks[i]);
                core.axis_nudge(&mut lane, 15);
                tracks[i] = WorkUnit::mk(
                    tracks[i].id,
                    lane
                        .waypoints
                        .iter()
                        .map(|p| (p.x, p.y, p.tick))
                        .collect(),
                    20,
                    1,
                );
            }
        }
    }
    let mut residual = 0u32;
    for i in 0..tracks.len() {
        for j in (i + 1)..tracks.len() {
            if core.duo_check(&tracks[i], &tracks[j], 0) {
                residual += 1;
            }
        }
    }
    seal(ScenarioRow {
        name: "case_peak_load".into(),
        finish_reason: if residual == 0 { "complete" } else { "partial" }.into(),
        stations_blocked: conflicts,
        retunes_applied: conflicts,
        sla_met: 0,
        line_clear: if residual == 0 { 1 } else { 0 },
        memo_fresh: 0,
        backlog_drained: 0,
        rush_resolved: 0,
        digest_hex: String::new(),
    })
}

pub fn run_maint_rev(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let a = WorkUnit::mk(8, vec![(0, 0, 3)], 10, 1);
    let b = WorkUnit::mk(9, vec![(10, 0, 3)], 10, 1);
    let miss_maint0 = core.duo_check(&a, &b, 0);
    core.pulse_rev(1);
    let b_shift = WorkUnit::mk(9, vec![(0, 0, 3)], 10, 1);
    let hit_maint1 = core.duo_check(&a, &b_shift, 1);
    let cache_ok = !miss_maint0 && hit_maint1;
    seal(ScenarioRow {
        name: "case_maint_rev".into(),
        finish_reason: if cache_ok { "complete" } else { "stuck" }.into(),
        stations_blocked: if hit_maint1 { 1 } else { 0 },
        retunes_applied: 0,
        sla_met: 0,
        line_clear: 0,
        memo_fresh: if cache_ok { 1 } else { 0 },
        backlog_drained: 0,
        rush_resolved: 0,
        digest_hex: String::new(),
    })
}

pub fn run_shift_gap(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    core.begin_run();
    let stale_a = WorkUnit::mk(11, vec![(0, 0, 2), (5, 0, 4)], 10, 1);
    let stale_b = WorkUnit::mk(12, vec![(5, 0, 4), (10, 0, 6)], 10, 1);
    if core.duo_check(&stale_a, &stale_b, 0) {
        core.hold_ids(&[stale_a.id, stale_b.id]);
    }
    core.begin_run();
    let fresh_a = WorkUnit::mk(11, vec![(0, 0, 2), (20, 0, 4)], 10, 1);
    let fresh_b = WorkUnit::mk(12, vec![(30, 0, 4), (40, 0, 6)], 10, 1);
    let live_hit = core.duo_check(&fresh_a, &fresh_b, 0);
    let stash = core.read_hold();
    let handled = stash.is_empty() && !live_hit;
    seal(ScenarioRow {
        name: "case_shift_gap".into(),
        finish_reason: if handled { "complete" } else { "stuck" }.into(),
        stations_blocked: if live_hit { 1 } else { 0 },
        retunes_applied: 0,
        sla_met: 0,
        line_clear: 0,
        memo_fresh: 0,
        backlog_drained: if handled { 1 } else { 0 },
        rush_resolved: 0,
        digest_hex: String::new(),
    })
}

pub fn run_rush_slot(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let emerg = WorkUnit::mk(20, vec![(0, 0, 1), (0, 10, 3)], 6, 99);
    let routine = WorkUnit::mk(21, vec![(0, 5, 2), (0, 10, 3)], 12, 1);
    let hit_before = core.duo_check(&emerg, &routine, 0);
    let mut lane = unit_to_lane(&routine);
    if emerg.priority > routine.priority {
        core.axis_nudge(&mut lane, 20);
    }
    let routine2 = WorkUnit::mk(
        21,
        lane.waypoints.iter().map(|p| (p.x, p.y, p.tick)).collect(),
        12,
        1,
    );
    let hit_after = core.duo_check(&emerg, &routine2, 0);
    let cleared = hit_before && !hit_after;
    seal(ScenarioRow {
        name: "case_rush_slot".into(),
        finish_reason: if cleared { "complete" } else { "blocked" }.into(),
        stations_blocked: if hit_before { 1 } else { 0 },
        retunes_applied: if cleared { 1 } else { 0 },
        sla_met: 0,
        line_clear: if cleared { 1 } else { 0 },
        memo_fresh: 0,
        backlog_drained: 0,
        rush_resolved: if cleared { 1 } else { 0 },
        digest_hex: String::new(),
    })
}

pub fn run_named(name: &str, plan: &Plan) -> ScenarioRow {
    match name {
        "case_stn_overlap" => run_stn_overlap(plan),
        "case_lane_shift" => run_lane_shift(plan),
        "case_sla_window" => run_sla_window(plan),
        "case_even_flow" => run_even_flow(plan),
        "case_chain_shift" => run_chain_shift(plan),
        "case_peak_load" => run_peak_load(plan),
        "case_maint_rev" => run_maint_rev(plan),
        "case_shift_gap" => run_shift_gap(plan),
        "case_rush_slot" => run_rush_slot(plan),
        other => seal(ScenarioRow {
            name: other.into(),
            finish_reason: "unknown".into(),
            stations_blocked: 0,
            retunes_applied: 0,
            sla_met: 0,
            line_clear: 0,
            memo_fresh: 0,
            backlog_drained: 0,
            rush_resolved: 0,
            digest_hex: String::new(),
        }),
    }
}

pub fn run_bundle(plan: &Plan, names: &[String]) -> Report {
    let scenarios = names.iter().map(|n| run_named(n, plan)).collect();
    Report {
        schema_version: 2,
        plant_id: plan.plant_id.clone(),
        scenarios,
    }
}
