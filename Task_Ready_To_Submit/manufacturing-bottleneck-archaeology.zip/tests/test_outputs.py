"""Verifier for manufacturing bottleneck archaeology plant lab reports."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "factory_report.json"
BIN = "/app/bin/plant_lab"
ACTIVE_PLAN = APP / "data" / "active" / "plan.json"
STEM_INDEX = APP / "docs" / "scenario_index.txt"
# Isolated from agent builds under /tmp/cargo-target so verifier rebuilds stay reliable.
VERIFIER_CARGO_TARGET = Path("/tmp/tbench-verifier-cargo-target")

SCHEMA_VERSION = 2
FINISH_COMPLETE = "complete"

BUILD_TIMEOUT_SEC = 540
LAB_TIMEOUT_SEC = 120
DIGEST_TIMEOUT_SEC = 30
CARGO_TEST_TIMEOUT_SEC = 300

_lab_report_cache: dict | None = None

REQUIRED_TOP_FIELDS = ("schema_version", "plant_id", "scenarios")
REQUIRED_ROW_FIELDS = (
    "name",
    "finish_reason",
    "stations_blocked",
    "retunes_applied",
    "sla_met",
    "line_clear",
    "memo_fresh",
    "backlog_drained",
    "rush_resolved",
    "digest_hex",
)

# PUBLIC (~70%): basic overlap, retune, SLA, separation, chain hops, peak load.
PUBLIC_EXPECTED = {
    "case_stn_overlap": {
        "finish_reason": FINISH_COMPLETE,
        "stations_blocked": 1,
    },
    "case_lane_shift": {
        "finish_reason": FINISH_COMPLETE,
        "line_clear": 1,
        "retunes_applied": 1,
    },
    "case_sla_window": {
        "finish_reason": FINISH_COMPLETE,
        "sla_met": 1,
    },
    "case_even_flow": {
        "finish_reason": FINISH_COMPLETE,
        "line_clear": 1,
        "stations_blocked": 0,
    },
    "case_chain_shift": {
        "finish_reason": FINISH_COMPLETE,
        "retunes_applied": 2,
        "line_clear": 1,
    },
    "case_peak_load": {
        "finish_reason": FINISH_COMPLETE,
        "line_clear": 1,
    },
}

# HIDDEN (~30%): maintenance memo cache, shift stash leakage, rush contention.
HIDDEN_EXPECTED = {
    "case_maint_rev": {
        "finish_reason": FINISH_COMPLETE,
        "memo_fresh": 1,
        "stations_blocked": 1,
    },
    "case_shift_gap": {
        "finish_reason": FINISH_COMPLETE,
        "backlog_drained": 1,
    },
    "case_rush_slot": {
        "finish_reason": FINISH_COMPLETE,
        "rush_resolved": 1,
        "line_clear": 1,
    },
}


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    """Build plant_lab once for the verifier session."""
    env = {
        **os.environ,
        "CARGO_TARGET_DIR": str(VERIFIER_CARGO_TARGET),
    }
    subprocess.run(
        ["bash", "/app/scripts/build.sh"],
        cwd="/app",
        env=env,
        check=True,
        timeout=BUILD_TIMEOUT_SEC,
    )


def _row_digest_matches_rust(row: dict) -> str:
    proc = subprocess.run(
        [
            "/app/bin/digest_cli",
            row["name"],
            row["finish_reason"],
            str(row["stations_blocked"]),
            str(row["retunes_applied"]),
            str(row["sla_met"]),
            str(row["line_clear"]),
            str(row["memo_fresh"]),
            str(row["backlog_drained"]),
            str(row["rush_resolved"]),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
        timeout=DIGEST_TIMEOUT_SEC,
    )
    return proc.stdout.strip()


def _run_lab(extra_env: dict | None = None) -> dict:
    global _lab_report_cache
    if extra_env:
        env = {
            **os.environ,
            "TB_PLANT_FIXTURE": "1",
            **extra_env,
        }
        subprocess.run(
            [BIN],
            cwd="/app",
            env=env,
            check=True,
            timeout=LAB_TIMEOUT_SEC,
        )
        return json.loads(OUT.read_text())

    if _lab_report_cache is None:
        env = {
            **os.environ,
            "TB_PLANT_FIXTURE": "1",
        }
        subprocess.run(
            [BIN],
            cwd="/app",
            env=env,
            check=True,
            timeout=LAB_TIMEOUT_SEC,
        )
        _lab_report_cache = json.loads(OUT.read_text())
    return _lab_report_cache


def _by_name(report: dict) -> dict[str, dict]:
    return {row["name"]: row for row in report["scenarios"]}


def _load_stems() -> list[str]:
    lines = STEM_INDEX.read_text().splitlines()
    return [line.strip() for line in lines if line.strip() and not line.startswith("#")]


def test_report_schema_and_plant() -> None:
    """Report uses schema version 2 and the active plant id."""
    report = _run_lab()
    assert report["schema_version"] == SCHEMA_VERSION
    plan = json.loads(ACTIVE_PLAN.read_text())
    assert report["plant_id"] == plan["plant_id"]
    assert len(report["scenarios"]) >= 9


def test_report_contains_required_fields() -> None:
    """Top-level and per-scenario report rows include every schema field."""
    report = _run_lab()
    for field in REQUIRED_TOP_FIELDS:
        assert field in report
    for row in report["scenarios"]:
        for field in REQUIRED_ROW_FIELDS:
            assert field in row


def test_stn_overlap_finds_block() -> None:
    """Units sharing a station at the same tick register a block."""
    row = _by_name(_run_lab())["case_stn_overlap"]
    ex = PUBLIC_EXPECTED["case_stn_overlap"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["stations_blocked"] == ex["stations_blocked"]


def test_lane_shift_clears_block() -> None:
    """A lateral retune clears an overlap and marks the line clear."""
    row = _by_name(_run_lab())["case_lane_shift"]
    ex = PUBLIC_EXPECTED["case_lane_shift"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["line_clear"] == ex["line_clear"]
    assert row["retunes_applied"] == ex["retunes_applied"]


def test_sla_window_preserved() -> None:
    """SLA stem keeps sla_met after a small shift."""
    row = _by_name(_run_lab())["case_sla_window"]
    ex = PUBLIC_EXPECTED["case_sla_window"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["sla_met"] == ex["sla_met"]


def test_even_flow_no_block() -> None:
    """Separated lines report zero blocks and line_clear."""
    row = _by_name(_run_lab())["case_even_flow"]
    ex = PUBLIC_EXPECTED["case_even_flow"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["stations_blocked"] == ex["stations_blocked"]
    assert row["line_clear"] == ex["line_clear"]


def test_chain_shift_both_hops() -> None:
    """Two-hop chain retune applies both shifts and clears the overlap."""
    row = _by_name(_run_lab())["case_chain_shift"]
    ex = PUBLIC_EXPECTED["case_chain_shift"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["retunes_applied"] == ex["retunes_applied"]
    assert row["line_clear"] == ex["line_clear"]


def test_peak_load_complete() -> None:
    """Peak load stem finishes without residual overlaps."""
    row = _by_name(_run_lab())["case_peak_load"]
    ex = PUBLIC_EXPECTED["case_peak_load"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["line_clear"] == ex["line_clear"]


def test_hidden_maint_rev_cache() -> None:
    """Maintenance revision bump invalidates stale slot memo entries."""
    row = _by_name(_run_lab())["case_maint_rev"]
    ex = HIDDEN_EXPECTED["case_maint_rev"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["memo_fresh"] == ex["memo_fresh"]
    assert row["stations_blocked"] == ex["stations_blocked"]


def test_hidden_shift_gap_session() -> None:
    """Shift handoff edge: delayed telemetry pass clears prior stash before re-checking units."""
    row = _by_name(_run_lab())["case_shift_gap"]
    ex = HIDDEN_EXPECTED["case_shift_gap"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["backlog_drained"] == ex["backlog_drained"]


def test_hidden_rush_slot_contention() -> None:
    """Cross-module edge: rush priority insert shifts routine traffic aside."""
    row = _by_name(_run_lab())["case_rush_slot"]
    ex = HIDDEN_EXPECTED["case_rush_slot"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["rush_resolved"] == ex["rush_resolved"]
    assert row["line_clear"] == ex["line_clear"]


def test_regression_stems_complete() -> None:
    """Every stem listed in scenario_index finishes complete."""
    report = _run_lab()
    rows = _by_name(report)
    for stem in _load_stems():
        assert rows[stem]["finish_reason"] == FINISH_COMPLETE


def test_row_digests_match_helper() -> None:
    """Each scenario digest matches the digest helper."""
    report = _run_lab()
    for row in report["scenarios"]:
        assert row["digest_hex"] == _row_digest_matches_rust(row)


def test_rust_unit_tests_pass() -> None:
    """Workspace unit tests must pass after the fix."""
    env = {
        **os.environ,
        "CARGO_TARGET_DIR": str(VERIFIER_CARGO_TARGET),
    }
    proc = subprocess.run(
        ["cargo", "test", "--release", "--locked", "--workspace", "--quiet"],
        cwd="/app",
        env=env,
        capture_output=True,
        text=True,
        check=False,
        timeout=CARGO_TEST_TIMEOUT_SEC,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout
