#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app
mkdir -p /app/outcomes /app/scripts

if ! grep -q '"overlapping_jobs"' /app/logs/corruption_events.jsonl; then
  echo "corruption_events.jsonl missing overlap evidence" >&2
  exit 1
fi

if grep -q 'legacy/copied_2022/vacuum_shard.sh' /app/logs/cron_runs.jsonl; then
  echo "confirmed stale vacuum invocation in run log" >&2
fi

overlap_window="$(python3 - <<'PY'
import json
from pathlib import Path
runs = [
    json.loads(line)
    for line in Path("/app/logs/cron_runs.jsonl").read_text(encoding="utf-8").splitlines()
    if line.strip()
]
catalog = {"vacuum-shard-a", "reindex-shard-a", "compact-cache"}
active = [r for r in runs if r["job_id"] in catalog]
starts = sorted(r["start_utc"] for r in active)
print(starts[0], starts[-1])
PY
)"
echo "catalog-write window ${overlap_window}" >&2

install -m0755 "${ROOT_DIR}/reconcile_fleet.sh" /app/scripts/reconcile_fleet.sh
bash /app/scripts/reconcile_fleet.sh

patch -p1 -d /app < "${ROOT_DIR}/patches/reindex_primary.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/retire_replica_wrappers.patch"
rm -f /app/shed/host-b/crontab.d/*.orig
patch -p1 -d /app < "${ROOT_DIR}/patches/coordination_state.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/r8_note.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/t7_stamp.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/nest_hold.patch"
chmod 0755 /app/shed/host-a/crontab.d/40-reindex-shard
chmod a-x /app/shed/host-b/crontab.d/30-vacuum-replica
chmod a-x /app/shed/host-b/crontab.d/35-reindex-replica

printf 'STATUS=sealed\nINCIDENT=night-2024-03-11\n' > /app/archive/incident_closure.env

bash /app/jobs/repair_catalog.sh
/app/bin/conflict_index --validate
/app/bin/schedule_guard --audit
