#!/usr/bin/env bash
set -euo pipefail

mkdir -p /app/outcomes

log_incident_overlap() {
  local incident_line
  incident_line="$(head -n1 /app/logs/corruption_events.jsonl)"
  python3 - <<'PY' "$incident_line"
import json, sys
payload = json.loads(sys.argv[1])
jobs = sorted(payload.get("overlapping_jobs", []))
print("incident jobs:", ",".join(jobs))
PY
}

scan_host_b_stale_wiring() {
  local path base
  for path in /app/shed/host-b/crontab.d/*; do
    [[ -f "$path" ]] || continue
    base="$(basename "$path")"
    if grep -q 'legacy/' "$path"; then
      echo "stale wiring detected in ${base}" >&2
    fi
    if grep -q 'CRON_TZ=UTC' "$path" && grep -q 'vacuum' "$path"; then
      echo "duplicate vacuum wrapper ${base} uses CRON_TZ override" >&2
    fi
  done
}

read_catalog_owners() {
  python3 - <<'PY'
import re
from pathlib import Path
text = Path("/app/jobs/catalog.toml").read_text(encoding="utf-8")
current = None
for line in text.splitlines():
    line = line.strip()
    m = re.match(r'id = "(.+)"', line)
    if m:
        current = m.group(1)
        continue
    m = re.match(r'owner_server = "(.+)"', line)
    if m and current:
        print(f"{current}\t{m.group(1)}")
PY
}

log_incident_overlap
scan_host_b_stale_wiring
read_catalog_owners >/dev/null

python3 - <<'PY'
import json
from pathlib import Path

runs = []
for line in Path("/app/logs/cron_runs.jsonl").read_text(encoding="utf-8").splitlines():
    line = line.strip()
    if line:
        runs.append(json.loads(line))

timeline = []
for run in runs:
    timeline.append(
        {
            "utc": run["start_utc"],
            "server": run["server"],
            "job_id": run["job_id"],
            "action": "start",
        }
    )
    timeline.append(
        {
            "utc": run["finish_utc"],
            "server": run["server"],
            "job_id": run["job_id"],
            "action": "finish",
        }
    )
timeline.sort(key=lambda item: (item["utc"], item["server"], item["job_id"]))
Path("/app/outcomes/execution_timeline.json").write_text(
    json.dumps(timeline, indent=2) + "\n",
    encoding="utf-8",
)

incident = json.loads(
    Path("/app/logs/corruption_events.jsonl").read_text(encoding="utf-8").splitlines()[0]
)
jobs = sorted(incident["overlapping_jobs"])
Path("/app/outcomes/conflict_groups.txt").write_text(
    ",".join(jobs) + "\n",
    encoding="utf-8",
)
PY

cat > /app/outcomes/coordinated_schedule.tsv <<'TSV'
server_id,job_id,cron_expr,enabled
host-a,log-rotate,15 4 * * *,1
host-a,metrics-scrape,20 4 * * *,1
host-a,reindex-shard-a,0 7 * * *,1
host-a,vacuum-shard-a,30 5 * * *,1
host-b,log-rotate,15 4 * * *,1
host-b,metrics-scrape,20 4 * * *,1
host-b,reindex-shard-a,0 5 * * *,0
host-b,vacuum-shard-a,30 5 * * *,0
host-c,compact-cache,0 6 * * *,1
host-c,metrics-scrape,20 4 * * *,1
TSV

{
  for path in /app/shed/host-b/crontab.d/*; do
    [[ -f "$path" ]] || continue
    base="$(basename "$path")"
    case "$base" in
      10-log-rotate|20-metrics-scrape) continue ;;
      *) echo "$base" ;;
    esac
  done
} | sort > /app/outcomes/disabled_cron_entries.txt

for wrapper in $(cat /app/outcomes/disabled_cron_entries.txt); do
  target="/app/shed/host-b/crontab.d/${wrapper}"
  if [[ -f "$target" ]]; then
    chmod a-x "$target"
  fi
done

if [[ -f /app/shed/host-a/crontab.d/40-reindex-shard ]]; then
  chmod 0755 /app/shed/host-a/crontab.d/40-reindex-shard
fi

for artifact in \
  /app/outcomes/conflict_groups.txt \
  /app/outcomes/execution_timeline.json \
  /app/outcomes/coordinated_schedule.tsv \
  /app/outcomes/disabled_cron_entries.txt
do
  [[ -s "$artifact" ]] || {
    echo "missing outcome artifact: $artifact" >&2
    exit 1
  }
done

echo "reconcile_fleet completed" >&2
