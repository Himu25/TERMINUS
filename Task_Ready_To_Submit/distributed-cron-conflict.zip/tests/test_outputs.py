"""Verifier for distributed cron conflict investigation."""

from __future__ import annotations

import csv
import json
import re
import subprocess
from pathlib import Path

APP = Path("/app")
OUTCOMES = APP / "outcomes"
RUNS_LOG = APP / "logs" / "cron_runs.jsonl"
INCIDENT_LOG = APP / "logs" / "corruption_events.jsonl"
CATALOG = APP / "jobs" / "catalog.toml"
SHARD = APP / "data" / "shard_catalog.json"

CONFLICT_PATH = OUTCOMES / "conflict_groups.txt"
TIMELINE_PATH = OUTCOMES / "execution_timeline.json"
SCHEDULE_PATH = OUTCOMES / "coordinated_schedule.tsv"
DISABLED_PATH = OUTCOMES / "disabled_cron_entries.txt"

STALE_SCRIPT = APP / "legacy" / "copied_2022" / "vacuum_shard.sh"
HOUSEKEEPING_WRAPPERS = frozenset({"10-log-rotate", "20-metrics-scrape"})


def _incident_jobs() -> list[str]:
    line = INCIDENT_LOG.read_text(encoding="utf-8").splitlines()[0].strip()
    payload = json.loads(line)
    return sorted(payload["overlapping_jobs"])


def _catalog_write_owners() -> dict[str, str]:
    owners: dict[str, str] = {}
    current_id: str | None = None
    for raw in CATALOG.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if line.startswith("id ="):
            current_id = line.split("=", 1)[1].strip().strip('"')
        elif line.startswith("owner_server =") and current_id:
            owners[current_id] = line.split("=", 1)[1].strip().strip('"')
    return {job: host for job, host in owners.items() if job in _incident_jobs()}


def _host_b_wrappers_to_retire() -> list[str]:
    crontab_dir = APP / "shed" / "host-b" / "crontab.d"
    names = [
        path.name
        for path in sorted(crontab_dir.iterdir())
        if path.is_file()
        and path.name not in HOUSEKEEPING_WRAPPERS
        and not path.name.endswith(".orig")
    ]
    return sorted(names)


def _cron_runs() -> list[dict]:
    events: list[dict] = []
    for line in RUNS_LOG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            events.append(json.loads(line))
    return events


def _expected_timeline() -> list[dict]:
    timeline: list[dict] = []
    for run in _cron_runs():
        for action, key in (("start", "start_utc"), ("finish", "finish_utc")):
            timeline.append(
                {
                    "utc": run[key],
                    "server": run["server"],
                    "job_id": run["job_id"],
                    "action": action,
                }
            )
    timeline.sort(key=lambda item: (item["utc"], item["server"], item["job_id"]))
    return timeline


def _load_timeline() -> list[dict]:
    payload = json.loads(TIMELINE_PATH.read_text(encoding="utf-8"))
    assert isinstance(payload, list)
    return payload


def _load_schedule() -> list[tuple[str, str, str, str]]:
    rows: list[tuple[str, str, str, str]] = []
    with SCHEDULE_PATH.open(newline="", encoding="utf-8") as handle:
        reader = csv.reader(handle)
        header = next(reader)
        assert header == ["server_id", "job_id", "cron_expr", "enabled"]
        for record in reader:
            assert len(record) == 4
            rows.append((record[0], record[1], record[2], record[3]))
    assert rows == sorted(rows, key=lambda item: (item[0], item[1])), (
        "coordinated_schedule.tsv rows must be sorted by server_id, job_id"
    )
    return rows


def _active_cron_text(server: str) -> str:
    crontab_dir = APP / "shed" / server / "crontab.d"
    chunks: list[str] = []
    for path in sorted(crontab_dir.iterdir()):
        if path.is_file() and path.stat().st_mode & 0o111:
            chunks.append(path.read_text(encoding="utf-8"))
    return "\n".join(chunks)


def _cron_minutes(expr: str) -> tuple[int, int] | None:
    parts = expr.split()
    if len(parts) < 2:
        return None
    try:
        return int(parts[1]), int(parts[0])
    except ValueError:
        return None


def _timeline_sort_key(item: dict) -> tuple[str, str, str]:
    return item["utc"], item["server"], item["job_id"]


class TestOutcomeArtifacts:
    def test_conflict_groups_cover_catalog_write_incident(self) -> None:
        """conflict_groups.txt names the catalog-write overlap from corruption logs."""
        assert CONFLICT_PATH.is_file(), "missing conflict_groups.txt"
        lines = [
            ln.strip()
            for ln in CONFLICT_PATH.read_text(encoding="utf-8").splitlines()
            if ln.strip()
        ]
        assert lines, "conflict_groups.txt must not be empty"
        assert lines == sorted(lines), "conflict group lines must be sorted"
        expected_line = ",".join(_incident_jobs())
        normalized = []
        for line in lines:
            parts = [part.strip() for part in line.split(",") if part.strip()]
            assert parts == sorted(parts), "jobs within a group must be sorted"
            normalized.append(",".join(parts))
        assert expected_line in normalized

    def test_execution_timeline_matches_run_log_utc_order(self) -> None:
        """execution_timeline.json reconstructs UTC start/finish ordering from cron_runs.jsonl."""
        assert TIMELINE_PATH.is_file(), "missing execution_timeline.json"
        got = _load_timeline()
        expected = _expected_timeline()
        assert got == sorted(got, key=_timeline_sort_key), (
            "execution_timeline.json must be sorted by utc, server, job_id"
        )
        assert got == expected, "timeline must mirror cron_runs.jsonl in UTC sort order"
        for event in got:
            assert event["utc"].endswith("Z"), "timeline timestamps must be UTC with Z suffix"
            assert event["action"] in {"start", "finish"}

    def test_coordinated_schedule_sorted_and_mutex_safe(self) -> None:
        """coordinated_schedule.tsv enables each catalog-write job on one host with staggered expr."""
        catalog_jobs = set(_incident_jobs())
        rows = _load_schedule()
        assert rows, "coordinated_schedule.tsv must not be empty"
        enabled_catalog: dict[str, str] = {}
        catalog_exprs: dict[str, str] = {}
        for server, job, expr, enabled in rows:
            assert enabled in {"0", "1"}
            if enabled != "1":
                continue
            if job in catalog_jobs:
                assert job not in enabled_catalog, f"duplicate catalog-write owner for {job}"
                enabled_catalog[job] = server
                catalog_exprs[job] = expr.strip()
        assert set(enabled_catalog) == catalog_jobs
        for job, host in _catalog_write_owners().items():
            assert enabled_catalog[job] == host
        compact = _cron_minutes(catalog_exprs["compact-cache"])
        reindex = _cron_minutes(catalog_exprs["reindex-shard-a"])
        assert compact and reindex
        assert reindex[0] * 60 + reindex[1] > compact[0] * 60 + compact[1]

    def test_disabled_cron_entries_sorted_and_effective(self) -> None:
        """disabled_cron_entries.txt is sorted and risky host-b wrappers are not executable."""
        assert DISABLED_PATH.is_file(), "missing disabled_cron_entries.txt"
        lines = [
            ln.strip()
            for ln in DISABLED_PATH.read_text(encoding="utf-8").splitlines()
            if ln.strip()
        ]
        assert lines == sorted(lines), "disabled entries must be sorted"
        for name in _host_b_wrappers_to_retire():
            assert name in lines
        for name in lines:
            for server in ("host-a", "host-b", "host-c"):
                path = APP / "shed" / server / "crontab.d" / name
                if path.exists():
                    assert not path.stat().st_mode & 0o111, f"{name} must be disabled on {server}"


class TestHiddenCronPitfalls:
    def test_stale_legacy_vacuum_not_scheduled(self) -> None:
        """Active crontabs must not execute the stale legacy vacuum script."""
        assert STALE_SCRIPT.is_file()
        for server in ("host-a", "host-b", "host-c"):
            active = _active_cron_text(server)
            assert "legacy/copied_2022/vacuum_shard.sh" not in active

    def test_no_duplicate_vacuum_enabled_on_replica(self) -> None:
        """vacuum-shard-a must not remain enabled on host-b after coordination."""
        rows = _load_schedule()
        replica_vacuum = [
            (server, enabled)
            for server, job, _expr, enabled in rows
            if job == "vacuum-shard-a" and server == "host-b"
        ]
        assert not any(enabled == "1" for _server, enabled in replica_vacuum)

    def test_timezone_skew_replica_reindex_retired(self) -> None:
        """host-b reindex wrapper is disabled (Chicago local vs UTC comment trap)."""
        path = APP / "shed" / "host-b" / "crontab.d" / "35-reindex-replica"
        if path.exists():
            assert not path.stat().st_mode & 0o111


class TestCatalogRepaired:
    def test_shard_catalog_clear(self) -> None:
        """shard_catalog.json reports corruption_detected false."""
        payload = json.loads(SHARD.read_text(encoding="utf-8"))
        assert payload.get("corruption_detected") is False

    def test_housekeeping_crons_still_executable(self) -> None:
        """log-rotate and metrics-scrape wrappers stay installed where required."""
        for server, names in (
            ("host-a", ("10-log-rotate", "20-metrics-scrape")),
            ("host-b", ("10-log-rotate", "20-metrics-scrape")),
            ("host-c", ("20-metrics-scrape",)),
        ):
            for name in names:
                path = APP / "shed" / server / "crontab.d" / name
                assert path.is_file(), f"missing housekeeping cron {name} on {server}"
                assert path.stat().st_mode & 0o111, f"{name} must remain executable"

    def test_catalog_write_jobs_use_flock_scripts(self) -> None:
        """Blessed catalog-write scripts acquire the shared catalog-write lock."""
        lock = APP / "runtime" / "catalog-write.lock"
        assert lock.parent.is_dir()
        for script_name in ("vacuum_shard.sh", "reindex_shard.sh", "compact_cache.sh"):
            text = (APP / "jobs" / script_name).read_text(encoding="utf-8")
            assert "catalog-write.lock" in text
            assert "flock" in text


class TestControlAuditors:
    def test_conflict_index_validate(self) -> None:
        """conflict_index --validate accepts outcome artifacts."""
        subprocess.run(["/app/bin/conflict_index", "--validate"], check=True, cwd="/app")

    def test_schedule_guard_audit(self) -> None:
        """schedule_guard --audit passes after coordinated scheduling."""
        subprocess.run(["/app/bin/schedule_guard", "--audit"], check=True, cwd="/app")

    def test_catalog_toml_mutex_members(self) -> None:
        """catalog.toml still lists catalog-write mutex members."""
        text = CATALOG.read_text(encoding="utf-8")
        block = re.search(r"catalog-write\s*=\s*\[([^\]]+)\]", text)
        assert block, "mutex group catalog-write missing"
        for job in _incident_jobs():
            assert f'"{job}"' in block.group(1)
