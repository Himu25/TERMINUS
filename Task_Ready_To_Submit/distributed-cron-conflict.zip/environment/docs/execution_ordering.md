# Execution ordering notes

`cron_runs.jsonl` records observed runs with UTC `start_utc` and `finish_utc`.
Reconstruct timelines using those timestamps only.

When two runs share a mutex group and their intervals overlap, treat them as one
conflict group for coordinated scheduling.

Housekeeping jobs (`log-rotate`, `metrics-scrape`) may overlap each other but must
not be disabled during incident response.
