# Cron coordination policy

Coordinated schedules use **UTC** wall times. Per-host `timezone` in `server.toml` may disagree with crontab comments.

## Mutex

`catalog-write` members are listed in `/app/jobs/catalog.toml`. Only one member may be active at a time fleet-wide. Blessed writers coordinate through `/app/runtime/catalog-write.lock`.

## Canonical scripts

Blessed maintenance lives under `/app/jobs/`. Anything under `/app/legacy/` is a stale copy and must not stay wired in `crontab.d/`.
The known stale vacuum path is `legacy/copied_2022/vacuum_shard.sh`.
Corruption postmortems record `overlapping_jobs` arrays in `/app/logs/corruption_events.jsonl`.

## Remediation outputs

| Path | Shape |
|------|-------|
| `/app/outcomes/conflict_groups.txt` | One group per line; comma-separated `job_id` values sorted within the line; lines sorted |
| `/app/outcomes/execution_timeline.json` | JSON array of `{utc, server, job_id, action}` with `action` in `start`/`finish`; sorted by `utc`, `server`, `job_id` |
| `/app/outcomes/coordinated_schedule.tsv` | Comma-delimited rows (the `.tsv` path uses commas, not tabs). Header `server_id,job_id,cron_expr,enabled`; sorted by `server_id`, `job_id`; each `catalog-write` job enabled on exactly one server, on that job's `owner_server` from `/app/jobs/catalog.toml`; housekeeping jobs (`log-rotate`, `metrics-scrape`) stay enabled wherever they already exist |
| `/app/outcomes/disabled_cron_entries.txt` | `crontab.d` basenames disabled or removed; sorted; any matching file left under `/app/shed/*/crontab.d/` must not be executable |

Stagger `catalog-write` jobs so their run windows do not overlap the incident window recorded in `/app/logs/corruption_events.jsonl`.

Housekeeping wrappers (`10-log-rotate`, `20-metrics-scrape`) must remain executable on hosts that already installed them.

Validate after `/app/data/shard_catalog.json` shows `corruption_detected` false.
