package main

import (
	"bufio"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"sort"
	"strings"
)

func readLines(path string) ([]string, error) {
	handle, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer handle.Close()

	var lines []string
	scanner := bufio.NewScanner(handle)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line != "" {
			lines = append(lines, line)
		}
	}
	return lines, scanner.Err()
}

func incidentCatalogWriteJobs() ([]string, error) {
	raw, err := os.ReadFile("/app/logs/corruption_events.jsonl")
	if err != nil {
		return nil, err
	}
	first := ""
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line != "" {
			first = line
			break
		}
	}
	if first == "" {
		return nil, fmt.Errorf("corruption_events.jsonl empty")
	}
	var event struct {
		OverlappingJobs []string `json:"overlapping_jobs"`
	}
	if err := json.Unmarshal([]byte(first), &event); err != nil {
		return nil, err
	}
	if len(event.OverlappingJobs) == 0 {
		return nil, fmt.Errorf("overlapping_jobs missing")
	}
	jobs := append([]string{}, event.OverlappingJobs...)
	sort.Strings(jobs)
	return jobs, nil
}

func validateConflictGroups() error {
	expected, err := incidentCatalogWriteJobs()
	if err != nil {
		return err
	}
	lines, err := readLines("/app/outcomes/conflict_groups.txt")
	if err != nil {
		return err
	}
	if len(lines) == 0 {
		return fmt.Errorf("conflict_groups.txt empty")
	}

	expectedLine := strings.Join(expected, ",")
	found := false
	for _, line := range lines {
		parts := strings.Split(line, ",")
		sort.Strings(parts)
		if strings.Join(parts, ",") == expectedLine {
			found = true
		}
	}
	if !found {
		return fmt.Errorf("missing catalog-write conflict group")
	}
	return nil
}

func validateTimeline() error {
	raw, err := os.ReadFile("/app/outcomes/execution_timeline.json")
	if err != nil {
		return err
	}
	var events []map[string]string
	if err := json.Unmarshal(raw, &events); err != nil {
		return err
	}
	if len(events) < 10 {
		return fmt.Errorf("execution_timeline.json too short")
	}
	prev := ""
	for _, event := range events {
		for _, key := range []string{"utc", "server", "job_id", "action"} {
			if strings.TrimSpace(event[key]) == "" {
				return fmt.Errorf("timeline missing %s", key)
			}
		}
		if event["action"] != "start" && event["action"] != "finish" {
			return fmt.Errorf("invalid action %q", event["action"])
		}
		cur := event["utc"] + "\x00" + event["server"] + "\x00" + event["job_id"]
		if prev != "" && cur < prev {
			return fmt.Errorf("timeline not sorted")
		}
		prev = cur
	}
	return nil
}

func main() {
	validate := flag.Bool("validate", false, "validate outcome artifacts")
	flag.Parse()
	if !*validate {
		fmt.Fprintf(os.Stderr, "conflict_index: pass --validate after writing outcomes\n")
		os.Exit(2)
	}
	if err := validateConflictGroups(); err != nil {
		fmt.Fprintf(os.Stderr, "validate failed: %v\n", err)
		os.Exit(1)
	}
	if err := validateTimeline(); err != nil {
		fmt.Fprintf(os.Stderr, "validate failed: %v\n", err)
		os.Exit(1)
	}
	fmt.Println("conflict index ok")
}
