module conflict_index

go 1.19
