#!/usr/bin/env bash
set -euo pipefail
exec 9>/app/runtime/catalog-write.lock
flock -n 9 || exit 17
sleep 0.1
echo "compact ok" >> /app/logs/maintenance.log
