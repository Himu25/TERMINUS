#!/usr/bin/env bash
set -euo pipefail

target="/app/data/shard_catalog.json"
tmp="$(mktemp)"
sed \
  -e 's/"corruption_detected": true/"corruption_detected": false/' \
  -e 's/"note": "overlapping catalog-write maintenance"/"note": "coordinated schedule applied"/' \
  "$target" > "$tmp"
mv "$tmp" "$target"
