#!/usr/bin/env bash
set -euo pipefail
echo "log rotate ok" >> /app/logs/maintenance.log
