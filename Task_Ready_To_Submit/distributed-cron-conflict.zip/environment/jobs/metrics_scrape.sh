#!/usr/bin/env bash
set -euo pipefail
echo "metrics ok" >> /app/logs/maintenance.log
