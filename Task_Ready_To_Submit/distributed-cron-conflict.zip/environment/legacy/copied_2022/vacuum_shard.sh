#!/usr/bin/env bash
set -euo pipefail
# stale copy — no flock; allows duplicate catalog-write
sleep 0.1
echo "stale vacuum" >> /app/logs/maintenance.log
