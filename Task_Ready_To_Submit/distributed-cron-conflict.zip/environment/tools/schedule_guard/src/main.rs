use std::collections::{HashMap, HashSet};
use std::fs;
use std::io::{BufRead, BufReader};
use std::os::unix::fs::PermissionsExt;
use std::process;

const CATALOG_WRITE: [&str; 3] = ["vacuum-shard-a", "reindex-shard-a", "compact-cache"];
const HOUSEKEEPING: [&str; 2] = ["10-log-rotate", "20-metrics-scrape"];

fn read_lines(path: &str) -> Vec<String> {
    let file = fs::File::open(path).unwrap_or_else(|err| {
        eprintln!("schedule_guard: {err}");
        process::exit(1);
    });
    BufReader::new(file)
        .lines()
        .filter_map(|line| line.ok())
        .map(|line| line.trim().to_string())
        .filter(|line| !line.is_empty())
        .collect()
}

fn host_b_risk_wrappers() -> HashSet<String> {
    let mut names = HashSet::new();
    let dir = "/app/shed/host-b/crontab.d";
    let entries = fs::read_dir(dir).unwrap_or_else(|err| {
        eprintln!("schedule_guard: {err}");
        process::exit(1);
    });
    for entry in entries.flatten() {
        let path = entry.path();
        if !path.is_file() {
            continue;
        }
        if let Some(name) = path.file_name().and_then(|n| n.to_str()) {
            if name.ends_with(".orig") {
                continue;
            }
            if !HOUSEKEEPING.contains(&name) {
                names.insert(name.to_string());
            }
        }
    }
    names
}

fn load_schedule() -> Vec<(String, String, String, String)> {
    let raw = fs::read_to_string("/app/outcomes/coordinated_schedule.tsv").unwrap_or_else(|err| {
        eprintln!("schedule_guard: {err}");
        process::exit(1);
    });
    let mut rows = Vec::new();
    for (index, line) in raw.lines().enumerate() {
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        if index == 0 && line == "server_id,job_id,cron_expr,enabled" {
            continue;
        }
        let parts: Vec<&str> = line.split(',').collect();
        if parts.len() != 4 {
            eprintln!("malformed schedule row: {line}");
            process::exit(1);
        }
        rows.push((
            parts[0].to_string(),
            parts[1].to_string(),
            parts[2].to_string(),
            parts[3].to_string(),
        ));
    }
    rows
}

fn cron_minute_hour(expr: &str) -> Option<(u32, u32)> {
    let parts: Vec<&str> = expr.split_whitespace().collect();
    if parts.len() < 2 {
        return None;
    }
    let minute = parts[0].parse().ok()?;
    let hour = parts[1].parse().ok()?;
    Some((minute, hour))
}

fn catalog_write_owners() -> HashMap<String, String> {
    let raw = fs::read_to_string("/app/jobs/catalog.toml").unwrap_or_else(|err| {
        eprintln!("schedule_guard: {err}");
        process::exit(1);
    });
    let mut owners = HashMap::new();
    let mut current_id: Option<String> = None;
    for line in raw.lines() {
        let line = line.trim();
        if let Some(rest) = line.strip_prefix("id =") {
            current_id = Some(rest.trim().trim_matches('"').to_string());
        } else if let Some(rest) = line.strip_prefix("owner_server =") {
            if let Some(id) = current_id.clone() {
                if CATALOG_WRITE.contains(&id.as_str()) {
                    owners.insert(id, rest.trim().trim_matches('"').to_string());
                }
            }
        }
    }
    owners
}

fn assert_disabled_not_executable(disabled: &HashSet<String>) {
    for server in ["host-a", "host-b", "host-c"] {
        for name in disabled {
            let path = format!("/app/shed/{server}/crontab.d/{name}");
            let meta = match fs::metadata(&path) {
                Ok(meta) => meta,
                Err(_) => continue,
            };
            if meta.is_file() && meta.permissions().mode() & 0o111 != 0 {
                eprintln!("disabled wrapper {name} still executable on {server}");
                process::exit(1);
            }
        }
    }
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if !args.iter().any(|arg| arg == "--audit") {
        eprintln!("schedule_guard: pass --audit after outcomes are written");
        process::exit(2);
    }

    let risk = host_b_risk_wrappers();
    let disabled: HashSet<String> = read_lines("/app/outcomes/disabled_cron_entries.txt")
        .into_iter()
        .collect();
    for name in &risk {
        if !disabled.contains(name) {
            eprintln!("host-b wrapper {name} must be listed disabled");
            process::exit(1);
        }
    }
    assert_disabled_not_executable(&disabled);

    let owners = catalog_write_owners();
    let schedule = load_schedule();
    if schedule.is_empty() {
        eprintln!("coordinated_schedule.tsv empty");
        process::exit(1);
    }

    let mut catalog_write_hosts: HashMap<String, String> = HashMap::new();
    let mut housekeeping_hosts: HashMap<String, HashSet<String>> = HashMap::new();
    let mut catalog_exprs: HashMap<String, String> = HashMap::new();

    for (server, job, expr, enabled) in &schedule {
        if enabled != "1" {
            continue;
        }
        if CATALOG_WRITE.contains(&job.as_str()) {
            if let Some(expected) = owners.get(job) {
                if expected != server {
                    eprintln!("catalog-write job {job} enabled on {server}, expected {expected}");
                    process::exit(1);
                }
            }
            if let Some(other) = catalog_write_hosts.insert(job.clone(), server.clone()) {
                if other != *server {
                    eprintln!("catalog-write job {job} enabled on multiple servers");
                    process::exit(1);
                }
            }
            catalog_exprs.insert(job.clone(), expr.clone());
        } else {
            housekeeping_hosts
                .entry(job.clone())
                .or_default()
                .insert(server.clone());
        }
    }

    for job in CATALOG_WRITE {
        if !catalog_write_hosts.contains_key(job) {
            eprintln!("catalog-write job {job} must be enabled exactly once");
            process::exit(1);
        }
    }

    let log_hosts = housekeeping_hosts.get("log-rotate").cloned().unwrap_or_default();
    if !log_hosts.contains("host-a") || !log_hosts.contains("host-b") {
        eprintln!("log-rotate must stay enabled on host-a and host-b");
        process::exit(1);
    }

    let metrics_hosts = housekeeping_hosts.get("metrics-scrape").cloned().unwrap_or_default();
    for required in ["host-a", "host-b", "host-c"] {
        if !metrics_hosts.contains(required) {
            eprintln!("metrics-scrape must stay enabled on {required}");
            process::exit(1);
        }
    }

    if let (Some(compact_expr), Some(reindex_expr)) = (
        catalog_exprs.get("compact-cache"),
        catalog_exprs.get("reindex-shard-a"),
    ) {
        if let (Some((cm, ch)), Some((rm, rh))) =
            (cron_minute_hour(compact_expr), cron_minute_hour(reindex_expr))
        {
            let compact_start = ch * 60 + cm;
            let reindex_start = rh * 60 + rm;
            if reindex_start <= compact_start {
                eprintln!("reindex must be staggered after compact-cache window");
                process::exit(1);
            }
        }
    }

    let catalog = fs::read_to_string("/app/data/shard_catalog.json").unwrap_or_default();
    if catalog.contains("\"corruption_detected\": true") {
        eprintln!("shard_catalog still corrupted");
        process::exit(1);
    }

    println!("schedule audit ok");
}
