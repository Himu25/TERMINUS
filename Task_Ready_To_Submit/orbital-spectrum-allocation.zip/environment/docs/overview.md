Orbital spectrum allocation coordinates band carriers across LEO tenants. The lab driver replays stems that exercise overlap detection, multi-hop shifts, ephemeris revisions, pass-delayed state, priority inserts, and surge windows.

Active bundle: `/app/data/active/plan.json`
