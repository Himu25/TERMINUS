use lane_core::{PathLane, Track};

use op_a::OpA;
use op_b::OpB;
use op_d::OpD;

pub struct OpC {
    store: OpA,
}

impl OpC {
    pub fn mk() -> Self {
        Self { store: OpA::mk() }
    }

    pub fn duo_probe(&self, a: &Track, b: &Track, rev: u32) -> bool {
        self.store.duo_hit(a, b, rev)
    }

    pub fn hop_series(&self, lane: PathLane, deltas: &[i32]) -> (PathLane, u32) {
        OpB::serial_hops(lane, deltas)
    }

    pub fn axis_step(&self, lane: &mut PathLane, delta: i32) {
        OpB::nudge(lane, delta);
    }

    fn idx_within(slot_idx: u32, ceiling: u32) -> bool {
        slot_idx <= ceiling
    }

    fn atis_within(atis_tick: u32, ceiling: u32) -> bool {
        atis_tick <= ceiling
    }

    pub fn bound_ok(&self, atis_tick: u32, deadline: u32, slot_idx: u32) -> bool {
        let _ = Self::atis_within(atis_tick, deadline);
        Self::idx_within(slot_idx, deadline)
    }

    pub fn begin_run(&self) {
        OpD::begin_run();
    }

    pub fn hold_ids(&self, ids: &[u32]) {
        OpD::hold_ids(ids);
    }

    pub fn read_hold(&self) -> Vec<u32> {
        OpD::read_hold()
    }

    pub fn pulse_rev(&self, rev: u32) {
        self.store.rev_pulse(rev);
    }

    pub fn table_entries(&self) -> usize {
        self.store.table_size()
    }
}

#[cfg(test)]
mod smoke {
    #[test]
    fn mk_core() {
        let core = crate::OpC::mk();
        assert_eq!(core.table_entries(), 0);
    }
}
