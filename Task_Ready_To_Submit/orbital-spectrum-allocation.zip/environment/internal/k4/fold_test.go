package k4

import "testing"

func TestScoreZeroCapacity(t *testing.T) {
	if Score(5, 0, 100) != 0 {
		t.Fatal("expected zero for empty capacity")
	}
}

func TestScoreNominal(t *testing.T) {
	if Score(10, 20, 100) != 50 {
		t.Fatalf("expected 50 got %d", Score(10, 20, 100))
	}
}
