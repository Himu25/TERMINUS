package k4

func Score(assigned, capacity, surgePct uint32) uint32 {
	if capacity == 0 {
		return 0
	}
	return (assigned * 100) / capacity
}
