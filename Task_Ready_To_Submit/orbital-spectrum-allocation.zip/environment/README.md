# Orbital spectrum allocation lab

Mixed Rust/Go workspace under `/app` that simulates constellation band packing across competing operators. Rebuild with `/app/scripts/build.sh`, drive scenarios through `/app/bin/orbit_lab`, and inspect `/app/output/spectrum_report.json`.

See `/app/docs/scenario_index.txt` for regression stems and `/app/schemas/report.example.json` for the report layout.
