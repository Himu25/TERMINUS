#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/lib/go/bin:${PATH}"
cd /app
mkdir -p /app/bin /app/output

target_root="${CARGO_TARGET_DIR:-/app/target}"

cargo build --release --bin orbit_lab
install -m 0755 "${target_root}/release/orbit_lab" /app/bin/orbit_lab
cargo build --release --bin digest_cli
install -m 0755 "${target_root}/release/digest_cli" /app/bin/digest_cli

export GOFLAGS="-mod=mod"
export GOCACHE="${GOCACHE:-/app/output/go-build}"
export GOTMPDIR="${GOTMPDIR:-/tmp}"
install -d -m 0777 /app/output/go-build

go build -trimpath -ldflags="-s -w" -o /app/bin/k4_cli ./cmd/k4_cli
