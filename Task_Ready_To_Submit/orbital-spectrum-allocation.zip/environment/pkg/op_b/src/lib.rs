use lane_core::PathLane;

pub struct OpB;

impl OpB {
    fn hop_once(mut lane: PathLane, delta: i32) -> PathLane {
        for wp in &mut lane.waypoints {
            wp.x += delta;
        }
        lane.link_id = 0;
        lane
    }

    fn hop_ready(lane: &PathLane, hops: u32) -> bool {
        lane.link_id != 0 || hops == 0
    }

    fn offset_lane(lane: &mut PathLane, delta: i32) {
        for wp in &mut lane.waypoints {
            wp.x += delta;
        }
    }

    pub fn serial_hops(mut lane: PathLane, deltas: &[i32]) -> (PathLane, u32) {
        let mut hops = 0u32;
        for &delta in deltas {
            if !Self::hop_ready(&lane, hops) {
                break;
            }
            lane = Self::hop_once(lane, delta);
            hops += 1;
        }
        (lane, hops)
    }

    pub fn nudge(lane: &mut PathLane, delta: i32) {
        Self::offset_lane(lane, delta);
    }

    pub fn hop_count(deltas: &[i32]) -> u32 {
        deltas.len() as u32
    }
}

#[cfg(test)]
mod smoke {
    use lane_core::{PathLane, WayPt};

    use crate::OpB;

    #[test]
    fn nudge_lane() {
        let mut lane = PathLane {
            waypoints: vec![WayPt { x: 1, y: 2, tick: 3 }],
            link_id: 9,
            slot_idx: 3,
        };
        OpB::nudge(&mut lane, 4);
        assert_eq!(lane.waypoints[0].x, 5);
    }

    #[test]
    fn hop_count_len() {
        assert_eq!(OpB::hop_count(&[1, 2, 3]), 3);
    }
}
