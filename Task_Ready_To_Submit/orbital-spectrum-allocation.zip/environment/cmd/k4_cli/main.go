package main

import (
	"fmt"
	"os"
	"strconv"

	"orbital/k4/internal/k4"
)

func main() {
	if len(os.Args) != 4 {
		os.Exit(2)
	}
	assigned, err := strconv.ParseUint(os.Args[1], 10, 32)
	if err != nil {
		os.Exit(2)
	}
	capacity, err := strconv.ParseUint(os.Args[2], 10, 32)
	if err != nil {
		os.Exit(2)
	}
	surge, err := strconv.ParseUint(os.Args[3], 10, 32)
	if err != nil {
		os.Exit(2)
	}
	fmt.Println(k4.Score(uint32(assigned), uint32(capacity), uint32(surge)))
}
