#[derive(Debug, Clone)]
pub struct WayPt {
    pub x: i32,
    pub y: i32,
    pub tick: u32,
}

#[derive(Debug, Clone)]
pub struct Track {
    pub id: u32,
    pub waypoints: Vec<WayPt>,
    pub deadline_tick: u32,
    pub priority: u32,
}

#[derive(Debug, Clone)]
pub struct PathLane {
    pub waypoints: Vec<WayPt>,
    pub link_id: u32,
    pub slot_idx: u32,
}

impl Track {
    pub fn mk(id: u32, pts: Vec<(i32, i32, u32)>, deadline: u32, priority: u32) -> Self {
        Self {
            id,
            waypoints: pts
                .into_iter()
                .map(|(x, y, tick)| WayPt { x, y, tick })
                .collect(),
            deadline_tick: deadline,
            priority,
        }
    }
}

impl PathLane {
    pub fn from_track(track: &Track) -> Self {
        Self {
            waypoints: track.waypoints.clone(),
            link_id: track.id,
            slot_idx: track.waypoints.last().map(|p| p.tick).unwrap_or(0),
        }
    }
}
