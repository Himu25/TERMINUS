use std::path::Path;
use std::process::Command;

use lane_core::{PathLane, Track};
use op_c::OpC;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

#[derive(Debug, Clone, Deserialize)]
pub struct Plan {
    pub constellation_id: String,
    pub operator_count: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScenarioRow {
    pub name: String,
    pub finish_reason: String,
    pub interference_found: u32,
    pub bands_reassigned: u32,
    pub windows_met: u32,
    pub allocation_clean: u32,
    pub ephemeris_valid: u32,
    pub pass_handled: u32,
    pub priority_cleared: u32,
    pub utilization_pct: u32,
    pub digest_hex: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Report {
    pub schema_version: u32,
    pub constellation_id: String,
    pub scenarios: Vec<ScenarioRow>,
}

pub fn load_plan(path: &Path) -> Plan {
    let raw = std::fs::read_to_string(path).expect("plan json");
    serde_json::from_str(&raw).expect("plan parse")
}

pub fn digest_row(row: &ScenarioRow) -> String {
    let payload = format!(
        "{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|",
        row.name,
        row.finish_reason,
        row.interference_found,
        row.bands_reassigned,
        row.windows_met,
        row.allocation_clean,
        row.ephemeris_valid,
        row.pass_handled,
        row.priority_cleared,
        row.utilization_pct,
    );
    format!("{:x}", Sha256::digest(payload.as_bytes()))
}

fn seal(mut row: ScenarioRow) -> ScenarioRow {
    row.digest_hex = digest_row(&row);
    row
}

fn track_to_lane(track: &Track) -> PathLane {
    PathLane::from_track(track)
}

fn k4_score(assigned: u32, capacity: u32, surge_pct: u32) -> u32 {
    let output = Command::new("/app/bin/k4_cli")
        .args([
            assigned.to_string(),
            capacity.to_string(),
            surge_pct.to_string(),
        ])
        .output()
        .expect("k4_cli");
    if !output.status.success() {
        return 0;
    }
    let text = String::from_utf8_lossy(&output.stdout);
    text.trim().parse().unwrap_or(0)
}

pub fn run_cross_detect(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let a = Track::mk(1, vec![(0, 0, 2), (5, 0, 4)], 10, 1);
    let b = Track::mk(2, vec![(5, 0, 4), (10, 0, 6)], 10, 1);
    let hit = core.duo_probe(&a, &b, 0);
    seal(ScenarioRow {
        name: "case_overlap_detect".into(),
        finish_reason: if hit { "complete" } else { "stuck" }.into(),
        interference_found: if hit { 1 } else { 0 },
        bands_reassigned: 0,
        windows_met: 0,
        allocation_clean: 0,
        ephemeris_valid: 0,
        pass_handled: 0,
        priority_cleared: 0,
        utilization_pct: 0,
        digest_hex: String::new(),
    })
}

pub fn run_reroute_simple(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let a = Track::mk(1, vec![(0, 0, 2), (5, 0, 4)], 12, 1);
    let b = Track::mk(2, vec![(5, 0, 4), (10, 0, 6)], 12, 1);
    let mut lane = track_to_lane(&a);
    let hit_before = core.duo_probe(&a, &b, 0);
    core.axis_step(&mut lane, 8);
    let a2 = Track::mk(1, lane.waypoints.iter().map(|p| (p.x, p.y, p.tick)).collect(), 12, 1);
    let hit_after = core.duo_probe(&a2, &b, 0);
    let clean = hit_before && !hit_after;
    seal(ScenarioRow {
        name: "case_band_shift".into(),
        finish_reason: if clean { "complete" } else { "stuck" }.into(),
        interference_found: if hit_before { 1 } else { 0 },
        bands_reassigned: if clean { 1 } else { 0 },
        windows_met: 0,
        allocation_clean: if clean { 1 } else { 0 },
        ephemeris_valid: 0,
        pass_handled: 0,
        priority_cleared: 0,
        utilization_pct: 0,
        digest_hex: String::new(),
    })
}

pub fn run_deadline_hold(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let track = Track::mk(3, vec![(0, 0, 1), (4, 0, 5)], 8, 2);
    let mut lane = track_to_lane(&track);
    lane.slot_idx = 10;
    core.axis_step(&mut lane, 2);
    let atis = lane.waypoints.last().map(|p| p.tick).unwrap_or(0);
    let ok = core.bound_ok(atis, track.deadline_tick, lane.slot_idx);
    seal(ScenarioRow {
        name: "case_window_hold".into(),
        finish_reason: if ok { "complete" } else { "stuck" }.into(),
        interference_found: 0,
        bands_reassigned: 1,
        windows_met: if ok { 1 } else { 0 },
        allocation_clean: 0,
        ephemeris_valid: 0,
        pass_handled: 0,
        priority_cleared: 0,
        utilization_pct: 0,
        digest_hex: String::new(),
    })
}

pub fn run_no_touch(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let a = Track::mk(4, vec![(0, 0, 1), (0, 5, 3)], 10, 1);
    let b = Track::mk(5, vec![(10, 0, 1), (10, 5, 3)], 10, 1);
    let hit = core.duo_probe(&a, &b, 0);
    seal(ScenarioRow {
        name: "case_clean_sep".into(),
        finish_reason: if !hit { "complete" } else { "collision" }.into(),
        interference_found: 0,
        bands_reassigned: 0,
        windows_met: 0,
        allocation_clean: if !hit { 1 } else { 0 },
        ephemeris_valid: 0,
        pass_handled: 0,
        priority_cleared: 0,
        utilization_pct: 0,
        digest_hex: String::new(),
    })
}

pub fn run_chain_reroute(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let a = Track::mk(6, vec![(0, 0, 2), (5, 0, 4), (10, 0, 6)], 14, 1);
    let b = Track::mk(7, vec![(5, 0, 4), (5, 5, 6)], 14, 1);
    let lane = track_to_lane(&a);
    let hit_before = core.duo_probe(&a, &b, 0);
    let (shifted, hops) = core.hop_series(lane, &[6, 4]);
    let a2 = Track::mk(
        6,
        shifted
            .waypoints
            .iter()
            .map(|p| (p.x, p.y, p.tick))
            .collect(),
        14,
        1,
    );
    let hit_after = core.duo_probe(&a2, &b, 0);
    let clean = hit_before && !hit_after && hops == 2;
    seal(ScenarioRow {
        name: "case_chain_shift".into(),
        finish_reason: if clean { "complete" } else { "partial" }.into(),
        interference_found: if hit_before { 1 } else { 0 },
        bands_reassigned: hops,
        windows_met: 0,
        allocation_clean: if clean { 1 } else { 0 },
        ephemeris_valid: 0,
        pass_handled: 0,
        priority_cleared: 0,
        utilization_pct: 0,
        digest_hex: String::new(),
    })
}

pub fn run_sector_dense(plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let count = plan.operator_count.max(4);
    let mut tracks = Vec::new();
    for i in 0..count {
        let x = (i as i32) * 3;
        tracks.push(Track::mk(
            100 + i,
            vec![(x, 0, 2), (x + 2, 0, 4)],
            20,
            1,
        ));
    }
    let mut conflicts = 0u32;
    for i in 0..tracks.len() {
        for j in (i + 1)..tracks.len() {
            if core.duo_probe(&tracks[i], &tracks[j], 0) {
                conflicts += 1;
                let mut lane = track_to_lane(&tracks[i]);
                core.axis_step(&mut lane, 15);
                tracks[i] = Track::mk(
                    tracks[i].id,
                    lane
                        .waypoints
                        .iter()
                        .map(|p| (p.x, p.y, p.tick))
                        .collect(),
                    20,
                    1,
                );
            }
        }
    }
    let mut residual = 0u32;
    for i in 0..tracks.len() {
        for j in (i + 1)..tracks.len() {
            if core.duo_probe(&tracks[i], &tracks[j], 0) {
                residual += 1;
            }
        }
    }
    seal(ScenarioRow {
        name: "case_dense_constellation".into(),
        finish_reason: if residual == 0 { "complete" } else { "partial" }.into(),
        interference_found: conflicts,
        bands_reassigned: conflicts,
        windows_met: 0,
        allocation_clean: if residual == 0 { 1 } else { 0 },
        ephemeris_valid: 0,
        pass_handled: 0,
        priority_cleared: 0,
        utilization_pct: 0,
        digest_hex: String::new(),
    })
}

pub fn run_weather_shift(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let a = Track::mk(8, vec![(0, 0, 3)], 10, 1);
    let b = Track::mk(9, vec![(10, 0, 3)], 10, 1);
    let miss_rev0 = core.duo_probe(&a, &b, 0);
    core.pulse_rev(1);
    let b_shift = Track::mk(9, vec![(0, 0, 3)], 10, 1);
    let hit_rev1 = core.duo_probe(&a, &b_shift, 1);
    let cache_ok = !miss_rev0 && hit_rev1;
    seal(ScenarioRow {
        name: "case_ephemeris_drift".into(),
        finish_reason: if cache_ok { "complete" } else { "stuck" }.into(),
        interference_found: if hit_rev1 { 1 } else { 0 },
        bands_reassigned: 0,
        windows_met: 0,
        allocation_clean: 0,
        ephemeris_valid: if cache_ok { 1 } else { 0 },
        pass_handled: 0,
        priority_cleared: 0,
        utilization_pct: 0,
        digest_hex: String::new(),
    })
}

pub fn run_comm_delay(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    core.begin_run();
    let stale_a = Track::mk(11, vec![(0, 0, 2), (5, 0, 4)], 10, 1);
    let stale_b = Track::mk(12, vec![(5, 0, 4), (10, 0, 6)], 10, 1);
    if core.duo_probe(&stale_a, &stale_b, 0) {
        core.hold_ids(&[stale_a.id, stale_b.id]);
    }
    core.begin_run();
    let fresh_a = Track::mk(11, vec![(0, 0, 2), (20, 0, 4)], 10, 1);
    let fresh_b = Track::mk(12, vec![(30, 0, 4), (40, 0, 6)], 10, 1);
    let live_hit = core.duo_probe(&fresh_a, &fresh_b, 0);
    let stash = core.read_hold();
    let handled = stash.is_empty() && !live_hit;
    seal(ScenarioRow {
        name: "case_pass_delay".into(),
        finish_reason: if handled { "complete" } else { "stuck" }.into(),
        interference_found: if live_hit { 1 } else { 0 },
        bands_reassigned: 0,
        windows_met: 0,
        allocation_clean: 0,
        ephemeris_valid: 0,
        pass_handled: if handled { 1 } else { 0 },
        priority_cleared: 0,
        utilization_pct: 0,
        digest_hex: String::new(),
    })
}

pub fn run_emergency_insert(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let emerg = Track::mk(20, vec![(0, 0, 1), (0, 10, 3)], 6, 99);
    let routine = Track::mk(21, vec![(0, 5, 2), (0, 10, 3)], 12, 1);
    let hit_before = core.duo_probe(&emerg, &routine, 0);
    let mut lane = track_to_lane(&routine);
    if emerg.priority > routine.priority {
        core.axis_step(&mut lane, 20);
    }
    let routine2 = Track::mk(
        21,
        lane.waypoints.iter().map(|p| (p.x, p.y, p.tick)).collect(),
        12,
        1,
    );
    let hit_after = core.duo_probe(&emerg, &routine2, 0);
    let cleared = hit_before && !hit_after;
    seal(ScenarioRow {
        name: "case_priority_insert".into(),
        finish_reason: if cleared { "complete" } else { "collision" }.into(),
        interference_found: if hit_before { 1 } else { 0 },
        bands_reassigned: if cleared { 1 } else { 0 },
        windows_met: 0,
        allocation_clean: if cleared { 1 } else { 0 },
        ephemeris_valid: 0,
        pass_handled: 0,
        priority_cleared: if cleared { 1 } else { 0 },
        utilization_pct: 0,
        digest_hex: String::new(),
    })
}

pub fn run_demand_surge(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let a = Track::mk(30, vec![(1000, 0, 3)], 10, 3);
    let b = Track::mk(31, vec![(1000, 0, 3)], 10, 3);
    let c = Track::mk(32, vec![(1000, 0, 3)], 10, 1);
    let hit_before = core.duo_probe(&a, &b, 0) || core.duo_probe(&a, &c, 0);
    let mut lane_c = track_to_lane(&c);
    core.axis_step(&mut lane_c, 40);
    let c2 = Track::mk(
        32,
        lane_c
            .waypoints
            .iter()
            .map(|p| (p.x, p.y, p.tick))
            .collect(),
        10,
        1,
    );
    let clean = !core.duo_probe(&a, &c2, 0) && !core.duo_probe(&b, &c2, 0);
    let util = k4_score(10, 15, 150);
    let guard = k4_score(12, 15, 150);
    let ok = hit_before && clean && util == 66 && guard == 0;
    seal(ScenarioRow {
        name: "case_demand_surge".into(),
        finish_reason: if ok { "complete" } else { "stuck" }.into(),
        interference_found: if hit_before { 2 } else { 0 },
        bands_reassigned: if clean { 1 } else { 0 },
        windows_met: 0,
        allocation_clean: if clean { 1 } else { 0 },
        ephemeris_valid: 0,
        pass_handled: 0,
        priority_cleared: 0,
        utilization_pct: util,
        digest_hex: String::new(),
    })
}

pub fn run_named(name: &str, plan: &Plan) -> ScenarioRow {
    match name {
        "case_overlap_detect" => run_cross_detect(plan),
        "case_band_shift" => run_reroute_simple(plan),
        "case_window_hold" => run_deadline_hold(plan),
        "case_clean_sep" => run_no_touch(plan),
        "case_chain_shift" => run_chain_reroute(plan),
        "case_dense_constellation" => run_sector_dense(plan),
        "case_ephemeris_drift" => run_weather_shift(plan),
        "case_pass_delay" => run_comm_delay(plan),
        "case_priority_insert" => run_emergency_insert(plan),
        "case_demand_surge" => run_demand_surge(plan),
        other => seal(ScenarioRow {
            name: other.into(),
            finish_reason: "unknown".into(),
            interference_found: 0,
            bands_reassigned: 0,
            windows_met: 0,
            allocation_clean: 0,
            ephemeris_valid: 0,
            pass_handled: 0,
            priority_cleared: 0,
            utilization_pct: 0,
            digest_hex: String::new(),
        }),
    }
}

pub fn run_bundle(plan: &Plan, names: &[String]) -> Report {
    let scenarios = names.iter().map(|n| run_named(n, plan)).collect();
    Report {
        schema_version: 2,
        constellation_id: plan.constellation_id.clone(),
        scenarios,
    }
}
