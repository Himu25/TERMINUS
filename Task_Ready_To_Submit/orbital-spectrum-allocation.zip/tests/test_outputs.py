"""Verifier for orbital spectrum allocation lab reports."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "spectrum_report.json"
BIN = "/app/bin/orbit_lab"
ACTIVE_PLAN = APP / "data" / "active" / "plan.json"
STEM_INDEX = APP / "docs" / "scenario_index.txt"

SCHEMA_VERSION = 2
FINISH_COMPLETE = "complete"

REQUIRED_TOP_FIELDS = ("schema_version", "constellation_id", "scenarios")
REQUIRED_ROW_FIELDS = (
    "name",
    "finish_reason",
    "interference_found",
    "bands_reassigned",
    "windows_met",
    "allocation_clean",
    "ephemeris_valid",
    "pass_handled",
    "priority_cleared",
    "utilization_pct",
    "digest_hex",
)

PUBLIC_EXPECTED = {
    "case_overlap_detect": {
        "finish_reason": FINISH_COMPLETE,
        "interference_found": 1,
    },
    "case_band_shift": {
        "finish_reason": FINISH_COMPLETE,
        "allocation_clean": 1,
        "bands_reassigned": 1,
    },
    "case_window_hold": {
        "finish_reason": FINISH_COMPLETE,
        "windows_met": 1,
    },
    "case_clean_sep": {
        "finish_reason": FINISH_COMPLETE,
        "allocation_clean": 1,
        "interference_found": 0,
    },
    "case_chain_shift": {
        "finish_reason": FINISH_COMPLETE,
        "bands_reassigned": 2,
        "allocation_clean": 1,
    },
    "case_dense_constellation": {
        "finish_reason": FINISH_COMPLETE,
        "allocation_clean": 1,
    },
}

HIDDEN_EXPECTED = {
    "case_ephemeris_drift": {
        "finish_reason": FINISH_COMPLETE,
        "ephemeris_valid": 1,
        "interference_found": 1,
    },
    "case_pass_delay": {
        "finish_reason": FINISH_COMPLETE,
        "pass_handled": 1,
    },
    "case_priority_insert": {
        "finish_reason": FINISH_COMPLETE,
        "priority_cleared": 1,
        "allocation_clean": 1,
    },
    "case_demand_surge": {
        "finish_reason": FINISH_COMPLETE,
        "allocation_clean": 1,
    },
}


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    """Build orbit_lab once for the verifier session."""
    env = {**os.environ}
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _row_digest_matches_rust(row: dict) -> str:
    proc = subprocess.run(
        [
            "/app/bin/digest_cli",
            row["name"],
            row["finish_reason"],
            str(row["interference_found"]),
            str(row["bands_reassigned"]),
            str(row["windows_met"]),
            str(row["allocation_clean"]),
            str(row["ephemeris_valid"]),
            str(row["pass_handled"]),
            str(row["priority_cleared"]),
            str(row["utilization_pct"]),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return proc.stdout.strip()


def _run_lab(extra_env: dict | None = None) -> dict:
    env = {
        **os.environ,
        "TB_ORBIT_FIXTURE": "1",
    }
    if extra_env:
        env.update(extra_env)
    subprocess.run([BIN], cwd="/app", env=env, check=True)
    return json.loads(OUT.read_text())


def _by_name(report: dict) -> dict[str, dict]:
    return {row["name"]: row for row in report["scenarios"]}


def _load_stems() -> list[str]:
    lines = STEM_INDEX.read_text().splitlines()
    return [line.strip() for line in lines if line.strip() and not line.startswith("#")]


def test_report_schema_and_constellation() -> None:
    """Report uses schema version 2 and the active constellation id."""
    report = _run_lab()
    assert report["schema_version"] == SCHEMA_VERSION
    plan = json.loads(ACTIVE_PLAN.read_text())
    assert report["constellation_id"] == plan["constellation_id"]
    assert len(report["scenarios"]) >= 10


def test_report_contains_required_fields() -> None:
    """Top-level and per-scenario report rows include every schema field."""
    report = _run_lab()
    for field in REQUIRED_TOP_FIELDS:
        assert field in report
    for row in report["scenarios"]:
        for field in REQUIRED_ROW_FIELDS:
            assert field in row


def test_overlap_detect_finds_interference() -> None:
    """Overlapping operators at the same epoch register interference."""
    row = _by_name(_run_lab())["case_overlap_detect"]
    ex = PUBLIC_EXPECTED["case_overlap_detect"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["interference_found"] == ex["interference_found"]


def test_band_shift_clears_overlap() -> None:
    """A frequency shift clears overlap and marks allocation clean."""
    row = _by_name(_run_lab())["case_band_shift"]
    ex = PUBLIC_EXPECTED["case_band_shift"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["allocation_clean"] == ex["allocation_clean"]
    assert row["bands_reassigned"] == ex["bands_reassigned"]


def test_window_preserved_after_shift() -> None:
    """Window stem keeps windows_met after a small shift."""
    row = _by_name(_run_lab())["case_window_hold"]
    ex = PUBLIC_EXPECTED["case_window_hold"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["windows_met"] == ex["windows_met"]


def test_clean_sep_no_interference() -> None:
    """Separated operators report zero interference and allocation clean."""
    row = _by_name(_run_lab())["case_clean_sep"]
    ex = PUBLIC_EXPECTED["case_clean_sep"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["interference_found"] == ex["interference_found"]
    assert row["allocation_clean"] == ex["allocation_clean"]


def test_chain_shift_both_hops() -> None:
    """Two-hop chain shift applies both moves and clears overlap."""
    row = _by_name(_run_lab())["case_chain_shift"]
    ex = PUBLIC_EXPECTED["case_chain_shift"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["bands_reassigned"] == ex["bands_reassigned"]
    assert row["allocation_clean"] == ex["allocation_clean"]


def test_dense_constellation_complete() -> None:
    """Dense constellation stem finishes without residual overlaps."""
    row = _by_name(_run_lab())["case_dense_constellation"]
    ex = PUBLIC_EXPECTED["case_dense_constellation"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["allocation_clean"] == ex["allocation_clean"]


def test_hidden_ephemeris_drift_cache() -> None:
    """Ephemeris revision bump invalidates stale overlap memo entries."""
    row = _by_name(_run_lab())["case_ephemeris_drift"]
    ex = HIDDEN_EXPECTED["case_ephemeris_drift"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["ephemeris_valid"] == ex["ephemeris_valid"]
    assert row["interference_found"] == ex["interference_found"]


def test_hidden_pass_delay_session() -> None:
    """Delayed pass clears prior stash before re-checking operators."""
    row = _by_name(_run_lab())["case_pass_delay"]
    ex = HIDDEN_EXPECTED["case_pass_delay"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["pass_handled"] == ex["pass_handled"]


def test_hidden_priority_corridor() -> None:
    """Priority insert shifts routine tenant aside."""
    row = _by_name(_run_lab())["case_priority_insert"]
    ex = HIDDEN_EXPECTED["case_priority_insert"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["priority_cleared"] == ex["priority_cleared"]
    assert row["allocation_clean"] == ex["allocation_clean"]


def test_hidden_demand_surge_utilization() -> None:
    """Demand surge window reports effective utilization after band packing."""
    row = _by_name(_run_lab())["case_demand_surge"]
    ex = HIDDEN_EXPECTED["case_demand_surge"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["allocation_clean"] == ex["allocation_clean"]
    proc = subprocess.run(
        ["/app/bin/k4_cli", "10", "15", "150"],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    assert row["utilization_pct"] == int(proc.stdout.strip())


def test_regression_stems_complete() -> None:
    """Every stem listed in scenario_index finishes complete."""
    report = _run_lab()
    rows = _by_name(report)
    for stem in _load_stems():
        assert rows[stem]["finish_reason"] == FINISH_COMPLETE


def test_row_digests_match_helper() -> None:
    """Each scenario digest matches the digest helper."""
    report = _run_lab()
    for row in report["scenarios"]:
        assert row["digest_hex"] == _row_digest_matches_rust(row)


def test_cargo_smoke_tests_pass() -> None:
    """Workspace unit smoke tests pass after the agent fix."""
    env = {**os.environ}
    subprocess.run(
        ["cargo", "test", "--workspace", "--quiet"],
        cwd="/app",
        env=env,
        check=True,
    )
