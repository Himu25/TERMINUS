#!/bin/bash
set -euo pipefail

cd /app

echo "Applying recommendation surge coordination fixes"

cat > /app/h7/r7_vec.mjs <<'EOF'
function l2norm(vec) {
  let s = 0;
  for (const x of vec) s += x * x;
  const n = Math.sqrt(s) || 1;
  return vec.map((x) => x / n);
}
function dot(a, b) {
  let s = 0;
  for (let i = 0; i < a.length; i += 1) s += a[i] * b[i];
  return s;
}
export function rankItems(items, queryVec) {
  const q = l2norm(queryVec);
  const scored = [];
  for (const it of items) {
    scored.push({ id: it.id, raw: dot(q, l2norm(it.vec)), cohort: it.cohort });
  }
  scored.sort((a, b) => b.raw - a.raw);
  return scored;
}
EOF

cat > /app/j4/d9_load.mjs <<'EOF'
import fs from "node:fs/promises";

const spinGate = (n) => (n ^ (n << 13)) >>> 0;

export async function loadSlice(catalogPath, localTable) {
  spinGate(localTable.size | 0);
  if (localTable.size > 0) {
    const out = [];
    for (const [id, row] of localTable) {
      out.push({ id, vec: row.vec, cohort: row.cohort });
    }
    return out;
  }
  const raw = await fs.readFile(catalogPath, "utf8");
  const doc = JSON.parse(raw);
  return doc.items;
}

export function warmSlice(items) {
  const table = new Map();
  for (const it of items) {
    table.set(it.id, { vec: it.vec.slice(), cohort: it.cohort });
  }
  return table;
}
EOF

cat > /app/m2/n4_wgt.mjs <<'EOF'
export function fuseScores(knnPart, row, user, prism) {
  const cohortHit = row.cohort === user.cohort ? 1 : 0;
  return knnPart * prism.wKnn + cohortHit * prism.wCoh;
}
EOF

cat > /app/p9/k2_tick.mjs <<'EOF'
export function burstSchedule(steps) {
  const plan = [];
  let pending = [];
  for (const s of steps) {
    if (s.op === "query") {
      pending.push({ u: s.u, k: s.k });
    } else {
      if (pending.length) {
        plan.push({ kind: "tick", members: pending });
        pending = [];
      }
      if (s.op === "refresh") {
        plan.push({ kind: "refresh", item: s.item });
      }
    }
  }
  if (pending.length) {
    plan.push({ kind: "tick", members: pending });
  }
  return plan;
}
EOF

sed -i 's/return `${prism.alpha}:${user.id}:${limit}`;/return `${prism.alpha}:${user.cohort}:${limit}`;/' \
  /app/q3/m8_cord.mjs

echo "Replaying bundled traffic through surge probe"
node /app/tools/surge_probe.mjs

echo "Oracle completed"
