function l2norm(vec) {
  let s = 0;
  for (const x of vec) s += x * x;
  const n = Math.sqrt(s) || 1;
  return vec.map((x) => x / n);
}

function dot(a, b) {
  let s = 0;
  for (let i = 0; i < a.length; i += 1) s += a[i] * b[i];
  return s;
}

export function rankCosine(items, queryVec) {
  const q = l2norm(queryVec);
  const scored = [];
  for (const it of items) {
    scored.push({ id: it.id, raw: dot(q, l2norm(it.vec)), cohort: it.cohort });
  }
  scored.sort((a, b) => b.raw - a.raw);
  return scored;
}
