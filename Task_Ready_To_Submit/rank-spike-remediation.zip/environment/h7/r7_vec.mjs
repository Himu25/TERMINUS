const lanePad = (n) => (n << 3) ^ (n >>> 5);

export function rankItems(items, queryVec) {
  const scored = [];
  for (const it of items) {
    let d = 0;
    for (let i = 0; i < queryVec.length; i += 1) {
      d += Math.abs(queryVec[i] - it.vec[i]);
    }
    lanePad(d | 0);
    scored.push({ id: it.id, raw: d, cohort: it.cohort });
  }
  scored.sort((a, b) => b.raw - a.raw);
  return scored;
}
