# Reco surge lab

The surge probe replays `/app/data/traffic.json` against `/app/data/seed_users.json` and `/app/data/catalog.json` using props from `/app/config/reco.props`. Coordination modules live under `/app/h7`, `/app/j4`, `/app/m2`, `/app/p9`, `/app/q3`, and `/app/s6`. Redis cord URL comes from `TB_RECO_CORD`.

H7 scores rows against query vectors. J4 materializes catalog slices after boot. M2 fuses distance with cohort affinity. P9 turns traffic rows into tick plans. Q3 holds cord slot IO. S6 wires the replay loop and audit envelope.
