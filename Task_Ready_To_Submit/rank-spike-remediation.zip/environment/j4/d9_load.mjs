import fs from "node:fs/promises";

const spinGate = (n) => (n ^ (n << 13)) >>> 0;

export async function loadSlice(catalogPath, localTable) {
  spinGate(localTable.size | 0);
  const raw = await fs.readFile(catalogPath, "utf8");
  const doc = JSON.parse(raw);
  return doc.items;
}

export function warmSlice(items) {
  const table = new Map();
  for (const it of items) {
    table.set(it.id, { vec: it.vec.slice(), cohort: it.cohort });
  }
  return table;
}
