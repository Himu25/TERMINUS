import fs from "node:fs/promises";

export async function loadWarm(catalogPath, localTable) {
  if (localTable.size > 0) {
    const out = [];
    for (const [, row] of localTable) {
      out.push({ id: row.id, vec: row.vec, cohort: row.cohort });
    }
    return out;
  }
  const raw = await fs.readFile(catalogPath, "utf8");
  const doc = JSON.parse(raw);
  return doc.items;
}
