export function cordLabel(prism, user, limit) {
  return `${prism.alpha}:${user.id}:${limit}`;
}

export async function readSlot(client, key) {
  const raw = await client.get(key);
  if (raw === null) {
    return null;
  }
  return JSON.parse(raw);
}

export async function writeSlot(client, key, payload, ttlSec) {
  await client.set(key, JSON.stringify(payload), "EX", ttlSec);
}

export async function dropItemSlots(client, prism, itemId) {
  const pattern = `${prism.alpha}:*`;
  const keys = await client.keys(pattern);
  let dropped = 0;
  for (const key of keys) {
    const raw = await client.get(key);
    if (!raw) {
      continue;
    }
    const doc = JSON.parse(raw);
    if (doc.ids && doc.ids.includes(itemId)) {
      await client.del(key);
      dropped += 1;
    }
  }
  return dropped;
}
