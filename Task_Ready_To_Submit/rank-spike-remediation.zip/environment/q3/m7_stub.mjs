export function cordLabelLegacy(prism, user, limit) {
  return `${prism.beta}:${user.id}:${limit}`;
}
