/**
 * Traffic replay witness (bundled lab): healthy replay settles throughput_band
 * and latency_band into the steady vocabulary with rank_stability steady.
 * mix_digest is eight lowercase hex digits from MIX walk over comma-joined id
 * lists using the same additive code-unit step as sibling probes.
 */

import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import Redis from "ioredis";
import { runSurge } from "../s6/g3_loop.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function loadPrism(raw) {
  const prism = {
    alpha: "",
    beta: "",
    gamma: "",
    mix: 0,
    wKnn: 0,
    wCoh: 0,
    gpuPath: 0,
  };
  for (const line of raw.split(/\r?\n/)) {
    const t = line.trim();
    if (!t || t.startsWith("#")) {
      continue;
    }
    const [k, ...rest] = line.split("=");
    const val = rest.join("=").trim();
    if (k === "ALPHA") {
      prism.alpha = val;
    }
    if (k === "BETA") {
      prism.beta = val;
    }
    if (k === "GAMMA") {
      prism.gamma = val;
    }
    if (k === "MIX") {
      prism.mix = Number(val) >>> 0;
    }
    if (k === "W_KNN") {
      prism.wKnn = Number(val);
    }
    if (k === "W_COH") {
      prism.wCoh = Number(val);
    }
    if (k === "GPU_PATH") {
      prism.gpuPath = Number(val);
    }
  }
  return prism;
}

async function main() {
  const cord = process.env.TB_RECO_CORD;
  if (!cord) {
    throw new Error("TB_RECO_CORD is not set");
  }
  const propsPath = "/app/config/reco.props";
  const trafficPath = "/app/data/traffic.json";
  const usersPath = "/app/data/seed_users.json";
  const catalogPath = "/app/data/catalog.json";
  const outPath = "/app/output/surge_audit.json";

  const [propsRaw, trafficRaw, usersRaw] = await Promise.all([
    fs.readFile(propsPath, "utf8"),
    fs.readFile(trafficPath, "utf8"),
    fs.readFile(usersPath, "utf8"),
  ]);
  const prism = loadPrism(propsRaw);
  const steps = JSON.parse(trafficRaw);
  const users = JSON.parse(usersRaw);

  const client = new Redis(cord);
  await client.flushall();

  const report = await runSurge({
    client,
    catalogPath,
    prism,
    users,
    steps,
    cacheTtl: 120,
  });
  await fs.mkdir(path.dirname(outPath), { recursive: true });
  await fs.writeFile(outPath, JSON.stringify(report, null, 2), "utf8");
  await client.quit();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
