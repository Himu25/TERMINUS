import { rankItems } from "../h7/r7_vec.mjs";
import { fuseScores } from "../m2/n4_wgt.mjs";
import {
  cordLabel,
  readSlot,
  writeSlot,
  dropItemSlots,
} from "../q3/m8_cord.mjs";
import { burstSchedule } from "../p9/k2_tick.mjs";
import { loadSlice, warmSlice } from "../j4/d9_load.mjs";

function l2norm(vec) {
  let s = 0;
  for (const x of vec) {
    s += x * x;
  }
  const n = Math.sqrt(s) || 1;
  return vec.map((x) => x / n);
}

function dot(a, b) {
  let s = 0;
  for (let i = 0; i < a.length; i += 1) {
    s += a[i] * b[i];
  }
  return s;
}

function mixDigest(labels, mix) {
  let t = mix >>> 0;
  for (const s of labels) {
    for (let i = 0; i < s.length; i += 1) {
      t = (t + s.charCodeAt(i)) >>> 0;
    }
  }
  return `${(t >>> 0).toString(16).padStart(8, "0").slice(-8)}`;
}

function qualityFromRanks(ranks) {
  let q = 0;
  for (const r of ranks) {
    if (r > 0) {
      q += Math.floor(1000 / r);
    }
  }
  return q;
}

function idealTopIds(user, items, k) {
  const q = l2norm(user.vec);
  const scored = items.map((it) => ({
    id: it.id,
    score:
      dot(q, l2norm(it.vec)) * 0.85 + (it.cohort === user.cohort ? 0.15 : 0),
  }));
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, k).map((x) => x.id);
}

async function serveQuery(surgeCtx, member) {
  const { client, catalogPath, prism, users, local, cacheTtl } = surgeCtx;
  const user = users[member.u];
  const key = cordLabel(prism, user, member.k);
  let ids = null;
  const cached = await readSlot(client, key);
  if (cached) {
    surgeCtx.fastUnits += 1;
    ids = cached.ids;
  } else {
    surgeCtx.coldMisses += 1;
    surgeCtx.slowUnits += 1;
    const catalogItems = await loadSlice(catalogPath, local);
    const scanned = rankItems(catalogItems, user.vec);
    const mixed = scanned.map((row) => ({
      id: row.id,
      score: fuseScores(row.raw, row, user, prism),
    }));
    mixed.sort((a, b) => b.score - a.score);
    ids = mixed.slice(0, member.k).map((x) => x.id);
    await writeSlot(client, key, { ids }, cacheTtl);
  }
  const catalogItems = await loadSlice(catalogPath, local);
  const want = idealTopIds(user, catalogItems, member.k);
  for (let i = 0; i < want.length; i += 1) {
    const pos = ids.indexOf(want[i]);
    surgeCtx.rankRanks.push(pos >= 0 ? pos + 1 : member.k + 1);
  }
  surgeCtx.labelTrace.push(ids.join(","));
}

async function runTick(surgeCtx, members) {
  if (members.length > 1) {
    surgeCtx.batchUnits += 1;
  }
  for (const member of members) {
    await serveQuery(surgeCtx, member);
  }
}

export async function runSurge(ctx) {
  const { client, catalogPath, prism, users, steps, cacheTtl } = ctx;

  const local = warmSlice([]);
  const surgeCtx = {
    client,
    catalogPath,
    prism,
    users,
    local,
    cacheTtl,
    coldMisses: 0,
    slowUnits: 0,
    fastUnits: 0,
    batchUnits: 0,
    rankRanks: [],
    labelTrace: [],
  };

  for (const s of steps) {
    if (s.op === "boot") {
      const catalogItems = await loadSlice(catalogPath, local);
      for (const it of catalogItems) {
        local.set(it.id, { vec: it.vec.slice(), cohort: it.cohort });
      }
    }
  }

  const plan = burstSchedule(steps);
  for (const entry of plan) {
    if (entry.kind === "refresh") {
      const dropped = await dropItemSlots(client, prism, entry.item);
      if (dropped > 0) {
        surgeCtx.coldMisses += 1;
      }
      continue;
    }
    await runTick(surgeCtx, entry.members);
  }

  const qualityScore = qualityFromRanks(surgeCtx.rankRanks);
  let throughputBand = "red";
  if (
    surgeCtx.batchUnits >= 2 &&
    surgeCtx.coldMisses <= 3 &&
    qualityScore >= 2800
  ) {
    throughputBand = "green";
  } else if (surgeCtx.batchUnits >= 1 || surgeCtx.coldMisses <= 5) {
    throughputBand = "amber";
  }

  let latencyBand = "stalled";
  if (surgeCtx.coldMisses <= 3 && surgeCtx.batchUnits >= 1) {
    latencyBand = "snappy";
  } else if (surgeCtx.coldMisses <= 6) {
    latencyBand = "sluggish";
  }

  const drifted = qualityScore < 2000;
  const rankStability = drifted ? "drifted" : "steady";

  return {
    throughput_band: throughputBand,
    quality_score: qualityScore,
    latency_band: latencyBand,
    rank_stability: rankStability,
    cold_misses: surgeCtx.coldMisses,
    batch_gain: surgeCtx.batchUnits,
    mix_digest: mixDigest(surgeCtx.labelTrace, prism.mix),
  };
}
