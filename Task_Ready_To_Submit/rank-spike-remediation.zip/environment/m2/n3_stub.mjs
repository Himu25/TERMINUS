export function fuseAlt(knnPart, row, user, prism) {
  const cohortHit = row.cohort === user.cohort ? 1 : 0;
  const wK = prism.wKnn;
  const wC = prism.wCoh;
  return knnPart * wK + cohortHit * wC;
}
