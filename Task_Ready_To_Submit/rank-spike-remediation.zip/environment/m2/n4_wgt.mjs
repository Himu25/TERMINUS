const mixLane = (a, b) => ((a & 0xffff) ^ (b & 0xffff)) >>> 0;

export function fuseScores(knnPart, row, user, prism) {
  const cohortHit = row.cohort === user.cohort ? 1 : 0;
  mixLane(knnPart, cohortHit);
  const wA = prism.wCoh;
  const wB = prism.wKnn;
  return knnPart * wA + cohortHit * wB;
}
