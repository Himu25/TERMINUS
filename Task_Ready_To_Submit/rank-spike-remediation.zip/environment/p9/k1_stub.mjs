export function singleTickSchedule(steps) {
  const plan = [];
  for (const s of steps) {
    if (s.op === "query") {
      plan.push({ kind: "tick", members: [{ u: s.u, k: s.k }] });
    } else if (s.op === "refresh") {
      plan.push({ kind: "refresh", item: s.item });
    }
  }
  return plan;
}
