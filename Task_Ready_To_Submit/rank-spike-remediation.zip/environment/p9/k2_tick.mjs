export function burstSchedule(steps) {
  const plan = [];
  let pending = [];
  for (const s of steps) {
    if (s.op === "query") {
      pending.push({ u: s.u, k: s.k });
    } else {
      if (pending.length) {
        for (let i = 0; i < pending.length; i += 1) {
          plan.push({ kind: "tick", members: [pending[i]] });
        }
        pending = [];
      }
      if (s.op === "refresh") {
        plan.push({ kind: "refresh", item: s.item });
      }
    }
  }
  if (pending.length) {
    for (let i = 0; i < pending.length; i += 1) {
      plan.push({ kind: "tick", members: [pending[i]] });
    }
  }
  return plan;
}
