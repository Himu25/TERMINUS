"""Validate /app/output/embed_migrate_bench.json against migrate.toml guardrails."""

from __future__ import annotations

import contextlib
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "embed_migrate_bench.json"
CFG = APP / "config" / "migrate.toml"
MANIFEST = APP / "registry" / "migrate_manifest.json"
SHARDS = APP / "data" / "shards_default.jsonl"
FIXTURES = Path(__file__).resolve().parent / "fixtures"

REPORT_KEYS = frozenset(
    {
        "status",
        "vector_total",
        "worker_count",
        "format_profile",
        "shards_total",
        "mean_vector_integrity",
        "mean_recall_consistency",
        "mean_relay_units",
        "mean_legacy_units",
        "p95_reencode_units",
        "mean_balance_score",
        "checksum_purity_rate",
        "seq_order_rate",
        "mean_cutover_lag_units",
        "report_digest",
        "shards",
    }
)
SHARD_KEYS = frozenset(
    {
        "shard_id",
        "vector_integrity",
        "recall_consistency",
        "relay_units",
        "legacy_units",
        "cutover_lag_units",
        "checksum_purity",
        "seq_order_rate",
        "workers_active",
        "balance_score",
        "vector_ids",
    }
)

_SUBPROC_ENV = os.environ.copy()
_path_prefix = "/usr/local/go/bin:/app/bin:"
_SUBPROC_ENV["PATH"] = _path_prefix + _SUBPROC_ENV.get("PATH", "")
_SUBPROC_ENV["LD_LIBRARY_PATH"] = "/app/lib:" + _SUBPROC_ENV.get("LD_LIBRARY_PATH", "")
_BUILD_TIMEOUT = 240
_RUN_TIMEOUT = 120


def _parse_cfg() -> dict:
    cfg: dict = {
        "worker_count": 4,
        "format_profile": "v3",
        "integrity_floor": 0.98,
        "recall_consistency_floor": 0.95,
        "max_mean_relay_units": 2200,
        "max_mean_legacy_units": 1200,
        "max_p95_reencode_units": 9000,
        "balance_floor": 0.72,
        "checksum_purity_floor": 0.95,
        "seq_order_floor": 0.95,
        "max_mean_cutover_lag_units": 800,
        "failover_integrity_floor": 0.9,
        "skew_balance_min": 0.65,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in (
            "integrity_floor",
            "recall_consistency_floor",
            "balance_floor",
            "checksum_purity_floor",
            "seq_order_floor",
            "failover_integrity_floor",
            "skew_balance_min",
        ):
            cfg[key] = float(val)
        elif key in (
            "worker_count",
            "max_mean_relay_units",
            "max_mean_legacy_units",
            "max_p95_reencode_units",
            "max_mean_cutover_lag_units",
        ):
            cfg[key] = int(float(val))
        elif key == "format_profile":
            cfg[key] = val
    return cfg


def _digest_payload(report: dict) -> dict:
    return {
        "status": report["status"],
        "vector_total": report["vector_total"],
        "worker_count": report["worker_count"],
        "format_profile": report["format_profile"],
        "shards_total": report["shards_total"],
        "mean_vector_integrity": report["mean_vector_integrity"],
        "mean_recall_consistency": report["mean_recall_consistency"],
        "mean_relay_units": report["mean_relay_units"],
        "mean_legacy_units": report["mean_legacy_units"],
        "p95_reencode_units": report["p95_reencode_units"],
        "mean_balance_score": report["mean_balance_score"],
        "checksum_purity_rate": report["checksum_purity_rate"],
        "seq_order_rate": report["seq_order_rate"],
        "mean_cutover_lag_units": report["mean_cutover_lag_units"],
        "report_digest": "",
        "shards": report["shards"],
    }


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _rebuild_and_run(
    shards_path: Path | None = None,
    out_path: Path | None = None,
    vector_path: Path | None = None,
) -> dict:
    shards_path = shards_path or SHARDS
    out_path = out_path or OUT
    env = dict(_SUBPROC_ENV)
    if vector_path is not None:
        env["TB_ENTITY_PATH"] = str(vector_path)
    out_path.unlink(missing_ok=True)
    subprocess.run(
        ["bash", "/app/scripts/build_all.sh"],
        cwd=APP,
        check=True,
        timeout=_BUILD_TIMEOUT,
        env=env,
    )
    subprocess.run(
        ["/app/bin/migratebench", shards_path.as_posix(), out_path.as_posix()],
        cwd=APP,
        check=True,
        timeout=_RUN_TIMEOUT,
        env=env,
    )
    return json.loads(out_path.read_text(encoding="utf-8"))


def _go_rebuild_and_run(
    shards_path: Path | None = None,
    out_path: Path | None = None,
) -> dict:
    """Rebuild only Go binary and run migratebench (skips cargo for Go-only swaps)."""
    shards_path = shards_path or SHARDS
    out_path = out_path or OUT
    env = dict(_SUBPROC_ENV)
    out_path.unlink(missing_ok=True)
    subprocess.run(
        [
            "bash",
            "-c",
            'export CGO_LDFLAGS="-L/app/lib -lzetacore"; '
            "exec go build -o /app/bin/migratebench ./cmd/migratebench",
        ],
        cwd=APP,
        check=True,
        timeout=_BUILD_TIMEOUT,
        env=env,
    )
    subprocess.run(
        ["/app/bin/migratebench", shards_path.as_posix(), out_path.as_posix()],
        cwd=APP,
        check=True,
        timeout=_RUN_TIMEOUT,
        env=env,
    )
    return json.loads(out_path.read_text(encoding="utf-8"))


@contextlib.contextmanager
def _swap_file(src: Path, dst: Path):
    """Temporarily replace dst with src, restoring original on exit."""
    backup = dst.read_bytes()
    shutil.copy(src, dst)
    os.utime(dst)
    try:
        yield
    finally:
        dst.write_bytes(backup)


def _shard_rows(report: dict) -> dict[str, dict]:
    return {row["shard_id"]: row for row in report["shards"]}


@pytest.fixture(scope="module")
def cfg() -> dict:
    return _parse_cfg()


@pytest.fixture(scope="module")
def default_report() -> dict:
    if not OUT.is_file():
        pytest.fail(f"missing agent output at {OUT}")
    return json.loads(OUT.read_text(encoding="utf-8"))


def test_report_schema_and_digest(default_report: dict) -> None:
    """Top-level schema and report_digest must match compact pre-digest JSON."""
    assert set(default_report.keys()) == REPORT_KEYS
    assert re.fullmatch(r"[0-9a-f]{64}", default_report["report_digest"])
    assert default_report["report_digest"] == _expected_digest(default_report)
    for row in default_report["shards"]:
        assert set(row.keys()) == SHARD_KEYS


def test_default_pack_quality_floors(default_report: dict, cfg: dict) -> None:
    """Default shard bundle must meet migrate.toml mean floors and ceilings."""
    assert default_report["status"] == "ok"
    assert default_report["shards_total"] == len(
        [ln for ln in SHARDS.read_text(encoding="utf-8").splitlines() if ln.strip()]
    )
    assert default_report["mean_vector_integrity"] >= cfg["integrity_floor"]
    assert default_report["mean_recall_consistency"] >= cfg["recall_consistency_floor"]
    assert int(default_report["mean_relay_units"]) <= cfg["max_mean_relay_units"]
    assert int(default_report["mean_legacy_units"]) <= cfg["max_mean_legacy_units"]
    assert default_report["p95_reencode_units"] <= cfg["max_p95_reencode_units"]
    assert default_report["mean_balance_score"] >= cfg["balance_floor"]
    assert default_report["checksum_purity_rate"] >= cfg["checksum_purity_floor"]
    assert default_report["seq_order_rate"] >= cfg["seq_order_floor"]
    assert int(default_report["mean_cutover_lag_units"]) <= cfg["max_mean_cutover_lag_units"]


def test_unicode_mix_vector_integrity(default_report: dict) -> None:
    """m_fmt_unicode must reach full vector_integrity on unicode-heavy vector_ids."""
    row = _shard_rows(default_report)["m_fmt_unicode"]
    assert row["vector_integrity"] >= 0.9999
    assert row["legacy_units"] == 0


def test_cutover_lag_recall_consistency(default_report: dict, cfg: dict) -> None:
    """Delayed cutover window on m_cutover_lag must still meet recall_consistency_floor."""
    row = _shard_rows(default_report)["m_cutover_lag"]
    assert row["recall_consistency"] >= cfg["recall_consistency_floor"]
    assert row["vector_integrity"] >= cfg["integrity_floor"]


def test_seq_skew_timestamp_order(default_report: dict, cfg: dict) -> None:
    """Ingest skew on m_seq_skew must still yield seq_order_rate at floor."""
    row = _shard_rows(default_report)["m_seq_skew"]
    assert row["seq_order_rate"] >= cfg["seq_order_floor"]


def test_replay_burst_checksum_purity(default_report: dict, cfg: dict) -> None:
    """Duplicate replay on m_replay_burst must meet checksum_purity on the shard row."""
    row = _shard_rows(default_report)["m_replay_burst"]
    assert row["checksum_purity"] >= cfg["checksum_purity_floor"]


def test_failover_shards_keep_integrity(default_report: dict, cfg: dict) -> None:
    """Failover shards must stay above failover_integrity_floor with reduced workers_active."""
    rows = _shard_rows(default_report)
    fail = rows["m_failover_lane"]
    multi = rows["m_failover_multi"]
    assert fail["workers_active"] == cfg["worker_count"] - 1
    assert multi["workers_active"] == cfg["worker_count"] - 2
    assert fail["vector_integrity"] >= cfg["failover_integrity_floor"]
    assert multi["vector_integrity"] >= cfg["failover_integrity_floor"]


def test_worker_skew_balance_floor(default_report: dict, cfg: dict) -> None:
    """Uneven vector payload sizes must still yield balance_score at or above skew_balance_min."""
    row = _shard_rows(default_report)["m_worker_skew"]
    assert row["balance_score"] >= cfg["skew_balance_min"]


def test_format_profile_matches_manifest(default_report: dict) -> None:
    """format_profile in the report must match registry migrate_manifest.json."""
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    assert default_report["format_profile"] == manifest["format_profile"]


def test_determinism_repeat_run(default_report: dict) -> None:
    """Identical inputs must yield byte-identical embed_migrate_bench.json."""
    first = OUT.read_bytes()
    OUT.unlink(missing_ok=True)
    subprocess.run(
        ["/app/bin/migratebench", SHARDS.as_posix(), OUT.as_posix()],
        cwd=APP,
        check=True,
        timeout=_RUN_TIMEOUT,
        env=_SUBPROC_ENV,
    )
    second = OUT.read_bytes()
    assert first == second


def test_z_ablation_m1_fails_recall() -> None:
    """Truncated read window must not satisfy recall_consistency on m_cutover_lag."""
    with _swap_file(FIXTURES / "z_w1.go", APP / "ax" / "w1.go"):
        report = _go_rebuild_and_run(out_path=APP / "output" / "migrate_ablation_m1.json")
        cfg = _parse_cfg()
        row = _shard_rows(report)["m_cutover_lag"]
        assert report["status"] == "fail" or row["recall_consistency"] < cfg["recall_consistency_floor"]


def test_z_ablation_m2_fails_seq_rate() -> None:
    """Ingest-time sort key must drop seq_order_rate on m_seq_skew."""
    with _swap_file(FIXTURES / "z_w2.go", APP / "bx" / "w2.go"):
        report = _go_rebuild_and_run(out_path=APP / "output" / "migrate_ablation_m2.json")
        cfg = _parse_cfg()
        row = _shard_rows(report)["m_seq_skew"]
        assert row["seq_order_rate"] < cfg["seq_order_floor"]


def test_z_ablation_m3_fails_purity() -> None:
    """Vector-only seq gate must collapse checksum_purity on m_replay_burst."""
    with _swap_file(FIXTURES / "z_w3.go", APP / "cx" / "w3.go"):
        report = _go_rebuild_and_run(out_path=APP / "output" / "migrate_ablation_m3.json")
        cfg = _parse_cfg()
        row = _shard_rows(report)["m_replay_burst"]
        assert row["checksum_purity"] < cfg["checksum_purity_floor"]


def test_z_ablation_m4_fails_integrity() -> None:
    """Prefix-only slot keys must drop vector_integrity on m_cutover_lag."""
    with _swap_file(FIXTURES / "z_w6.go", APP / "dx" / "w6.go"):
        report = _go_rebuild_and_run(out_path=APP / "output" / "migrate_ablation_m4.json")
        row = _shard_rows(report)["m_cutover_lag"]
        assert row["vector_integrity"] < 1.0
        assert row["legacy_units"] > 0


def test_z_ablation_m5_fails_balance() -> None:
    """Single-lane assignment must fail balance on m_worker_skew."""
    with _swap_file(FIXTURES / "z_w5.go", APP / "cx" / "w5.go"):
        report = _go_rebuild_and_run(out_path=APP / "output" / "migrate_ablation_m5.json")
        cfg = _parse_cfg()
        row = _shard_rows(report)["m_worker_skew"]
        assert row["balance_score"] < cfg["skew_balance_min"]


def test_z_ablation_m6_fails_unicode() -> None:
    """Broken Rust normalization must collapse vector_integrity on m_fmt_unicode."""
    with _swap_file(FIXTURES / "z_r1.rs", APP / "zfold" / "src" / "lib.rs"):
        report = _rebuild_and_run(out_path=APP / "output" / "migrate_ablation_m6.json")
        row = _shard_rows(report)["m_fmt_unicode"]
        assert row["vector_integrity"] < 0.95
