package cx

var seenSeq = map[string]map[uint64]struct{}{}

// KpReset clears dedup state between stream scenarios.
func KpReset() {
	seenSeq = map[string]map[uint64]struct{}{}
}

// KpAccept reports whether an update may be applied.
func KpAccept(entityID string, seq uint64) bool {
	if seenSeq[entityID] == nil {
		seenSeq[entityID] = map[uint64]struct{}{}
	}
	if _, ok := seenSeq[entityID][seq]; ok {
		return false
	}
	seenSeq[entityID][seq] = struct{}{}
	return true
}
