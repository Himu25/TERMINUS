package bx

import "vecshard.dev/migrate/pkg/types"

// ThOrderKey selects the ordering key for stream events before materialization.
func ThOrderKey(ev types.ShardEvent) int64 {
	return ev.EventMs
}

// ThWatermark returns the event-time frontier after processing ordered events.
func ThWatermark(events []types.ShardEvent) int64 {
	if len(events) == 0 {
		return 0
	}
	max := events[0].EventMs
	for _, ev := range events[1:] {
		if ev.EventMs > max {
			max = ev.EventMs
		}
	}
	return max
}
