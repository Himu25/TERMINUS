package ax

import "vecshard.dev/migrate/pkg/types"

// DlApplyWindow returns the event slice visible to materialization after lag budgeting.
func DlApplyWindow(events []types.ShardEvent, lagCap int) []types.ShardEvent {
	if lagCap <= 0 || len(events) <= lagCap {
		return events
	}
	return events[len(events)-lagCap:]
}

// DlLagUnits estimates synthetic consumer lag from the ordered event log.
func DlLagUnits(events []types.ShardEvent) int {
	if len(events) < 2 {
		return 0
	}
	minMs := events[0].EventMs
	maxMs := events[0].EventMs
	for _, ev := range events[1:] {
		if ev.EventMs < minMs {
			minMs = ev.EventMs
		}
		if ev.EventMs > maxMs {
			maxMs = ev.EventMs
		}
	}
	return int(maxMs - minMs)
}
