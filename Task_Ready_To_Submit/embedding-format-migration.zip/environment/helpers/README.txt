Multilingual prep throughput lab. See /app/docs/architecture.md for bench contract.
