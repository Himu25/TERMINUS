package bx

import (
	"sort"

	"vecshard.dev/migrate/pkg/types"
)

// ThSeqOrderRate measures monotonic event-time order in the ingest sequence.
func ThSeqOrderRate(events []types.ShardEvent) float64 {
	if len(events) < 2 {
		return 1.0
	}
	matches := 0
	for i := 1; i < len(events); i++ {
		if events[i].EventMs >= events[i-1].EventMs {
			matches++
		}
	}
	return float64(matches) / float64(len(events)-1)
}

// ThSortEvents orders events by the active ordering key.
func ThSortEvents(events []types.ShardEvent) {
	sort.Slice(events, func(i, j int) bool {
		return ThOrderKey(events[i]) < ThOrderKey(events[j])
	})
}
