#!/bin/bash
set -euo pipefail

SHARDS="${1:-/app/data/shards_default.jsonl}"
OUT="${2:-/app/output/embed_migrate_bench.json}"

export LD_LIBRARY_PATH="/app/lib:${LD_LIBRARY_PATH:-}"
exec /app/bin/migratebench "${SHARDS}" "${OUT}"
