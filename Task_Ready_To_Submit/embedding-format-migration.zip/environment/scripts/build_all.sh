#!/bin/bash
set -euo pipefail

ROOT="/app"
mkdir -p "${ROOT}/bin" "${ROOT}/lib" "${ROOT}/output" "${ROOT}/output/cargo-target"

export CARGO_TARGET_DIR="${ROOT}/output/cargo-target"
export CARGO_HOME="${CARGO_HOME:-/usr/local/cargo}"
export CGO_LDFLAGS="-L${ROOT}/lib -lzetacore"
export LD_LIBRARY_PATH="${ROOT}/lib:${LD_LIBRARY_PATH:-}"

cd "${ROOT}/zfold"
cargo build --release --locked
install -m 0644 "${CARGO_TARGET_DIR}/release/libzetacore.so" "${ROOT}/lib/libzetacore.so"

cd "${ROOT}"
go build -o "${ROOT}/bin/migratebench" ./cmd/migratebench

SHARDS_OUT="${ROOT}/data/shards_default.jsonl"
SPECS_IN="${ROOT}/data/shard_specs.jsonl"
VECTORS_IN="${ROOT}/data/vectors_default.json"

needs_shardgen=0
if [ ! -x "${ROOT}/bin/shardgen" ]; then needs_shardgen=1; fi
if [ ! -s "${SHARDS_OUT}" ]; then needs_shardgen=1; fi
if [ "${SPECS_IN}" -nt "${SHARDS_OUT}" ] 2>/dev/null; then needs_shardgen=1; fi
if [ "${VECTORS_IN}" -nt "${SHARDS_OUT}" ] 2>/dev/null; then needs_shardgen=1; fi

if [ "${needs_shardgen}" -eq 1 ]; then
  go build -o "${ROOT}/bin/shardgen" ./cmd/shardgen
  "${ROOT}/bin/shardgen" "${VECTORS_IN}" "${SPECS_IN}" "${SHARDS_OUT}"
fi

install -m 0755 "${ROOT}/bin/migratebench" "${ROOT}/bin/migratemat"
