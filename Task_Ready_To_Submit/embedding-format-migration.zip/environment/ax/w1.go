package ax

import "vecshard.dev/migrate/pkg/types"

// DlApplyWindow returns the event slice visible to materialization after lag budgeting.
func DlApplyWindow(events []types.ShardEvent, lagCap int) []types.ShardEvent {
	if len(events) <= 1 {
		return events
	}
	cut := len(events) / 2
	if lagCap > 0 && cut > lagCap {
		cut = lagCap
	}
	return events[:cut]
}

// DlLagUnits estimates synthetic consumer lag from the tail of the ordered log.
func DlLagUnits(events []types.ShardEvent) int {
	if len(events) == 0 {
		return 0
	}
	tail := events[len(events)-1]
	return int(tail.IngestMs - events[0].EventMs)
}
