package types

type MigrateCfg struct {
	CorpusPath              string
	WorkerCount             int
	FormatProfile           string
	IntegrityFloor          float64
	MaxMeanRelayUnits       int
	MaxMeanLegacyUnits      int
	MaxP95ReencodeUnits     int
	BalanceFloor            float64
	RecallConsistencyFloor  float64
	ChecksumPurityFloor     float64
	SeqOrderFloor           float64
	MaxMeanCutoverLagUnits  int
	FailoverIntegrityFloor  float64
	SkewBalanceMin          float64
}

type Vector struct {
	ID      string `json:"id"`
	Payload string `json:"text"`
	Lang    string `json:"lang"`
}

type ShardEvent struct {
	VectorID string `json:"vector_id"`
	Seq      uint64 `json:"seq"`
	EventMs  int64  `json:"event_ms"`
	IngestMs int64  `json:"ingest_ms"`
	Payload  string `json:"payload"`
}

type ShardCase struct {
	ShardID      string   `json:"shard_id"`
	VectorIDs    []string `json:"vector_ids"`
	DeadWorkers  []int    `json:"dead_workers"`
	IngestSkewMs int      `json:"ingest_skew_ms"`
	DupReplay    int      `json:"dup_replay"`
	LagCapUnits  int      `json:"lag_cap_units"`
}

type ShardRow struct {
	ShardID            string   `json:"shard_id"`
	VectorIntegrity    float64  `json:"vector_integrity"`
	RecallConsistency  float64  `json:"recall_consistency"`
	RelayUnits         int      `json:"relay_units"`
	LegacyUnits        int      `json:"legacy_units"`
	CutoverLagUnits    int      `json:"cutover_lag_units"`
	ChecksumPurity     float64  `json:"checksum_purity"`
	SeqOrderRate       float64  `json:"seq_order_rate"`
	WorkersActive      int      `json:"workers_active"`
	BalanceScore       float64  `json:"balance_score"`
	VectorIDs          []string `json:"vector_ids"`
}

type MigrateReport struct {
	Status                  string     `json:"status"`
	VectorTotal             int        `json:"vector_total"`
	WorkerCount             int        `json:"worker_count"`
	FormatProfile           string     `json:"format_profile"`
	ShardsTotal             int        `json:"shards_total"`
	MeanVectorIntegrity     float64    `json:"mean_vector_integrity"`
	MeanRecallConsistency   float64    `json:"mean_recall_consistency"`
	MeanRelayUnits          float64    `json:"mean_relay_units"`
	MeanLegacyUnits         float64    `json:"mean_legacy_units"`
	P95ReencodeUnits        int        `json:"p95_reencode_units"`
	MeanBalanceScore        float64    `json:"mean_balance_score"`
	ChecksumPurityRate      float64    `json:"checksum_purity_rate"`
	SeqOrderRate            float64    `json:"seq_order_rate"`
	MeanCutoverLagUnits     float64    `json:"mean_cutover_lag_units"`
	ReportDigest            string     `json:"report_digest"`
	Shards                  []ShardRow `json:"shards"`
}
