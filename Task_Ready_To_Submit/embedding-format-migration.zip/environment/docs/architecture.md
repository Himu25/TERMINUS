# Architecture notes

Vector snapshots live at `/app/data/vectors_default.json`. Shard migration scenarios are JSONL with shard_id, vector_ids, and optional dead_workers, ingest_skew_ms, dup_replay, or lag_cap_units. The Go driver `/app/bin/migratebench` loads `/app/config/migrate.toml`, re-encodes payloads through the Rust helper built from `/app/zfold`, and writes `/app/output/embed_migrate_bench.json`. Rebuild with `/app/scripts/build_all.sh` and run `/app/scripts/run_bench.sh`.

Top-level report keys: status, vector_total, worker_count, format_profile, shards_total, mean_vector_integrity, mean_recall_consistency, mean_relay_units, mean_legacy_units, p95_reencode_units, mean_balance_score, checksum_purity_rate, seq_order_rate, mean_cutover_lag_units, report_digest, shards.

Each shards row: shard_id, vector_integrity, recall_consistency, relay_units, legacy_units, cutover_lag_units, checksum_purity, seq_order_rate, workers_active, balance_score, vector_ids. vector_integrity is the fraction of vectors whose re-encoded digest matches the canonical fold in `ledger/fold.go`. Unit fields are synthetic cost tallies, not wall-clock timings.

Digest covers every report field except report_digest, serialized as compact JSON with report_digest set to an empty string. migratebench computes the digest from that payload before writing the indented report file.

relay_units adds a serial penalty when fewer workers are active than worker_count. legacy_units counts extra rune work when a hot slot returns a digest that does not match the canonical fold. checksum_purity_rate and seq_order_rate summarize shard hygiene on the scenario; per-shard checksum_purity and seq_order_rate are produced by the cx and bx stream helpers (dedup filter and ordering metrics), not inlined only in bench/drive.go. balance_score is produced by cx lane-balance logic from per-lane rune totals. mean_cutover_lag_units averages synthetic lag tallies from the ordered event log.

Exported Go entrypoints in ax, bx, cx, and dx keep stable parameter lists; do not add parameters to cache-slot helpers or ordering hooks that other packages already call.

Quality gates compare means against floors and ceilings in migrate.toml. Failover shards list dead_workers; only live workers participate. Regenerate the default shard bundle with `/app/bin/shardgen` after vector edits.

Verifier runs may write scratch JSON under `/app/output/` (for example `/app/output/embed_migrate_bench.json` and internal ablation copies `/app/output/migrate_ablation_m1.json` through `/app/output/migrate_ablation_m6.json`). Ablation fixture swaps may overwrite `/app/ax/w1.go`, `/app/bx/w2.go`, `/app/cx/w3.go`, `/app/cx/w5.go`, `/app/dx/w6.go`, or `/app/zfold/src/lib.rs` from the verifier fixture tree. Grading prepends `/usr/local/go/bin:/app/bin:` to PATH when invoking migratebench.
