Embedding format migration lab under `/app` simulates zero-downtime vector re-encoding with Go migration workers and a Rust codec. See architecture.md for report schema and bench entrypoints.
