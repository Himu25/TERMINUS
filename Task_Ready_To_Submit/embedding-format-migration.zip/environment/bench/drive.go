package bench

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"
	"unicode/utf8"

	"vecshard.dev/migrate/corpus"
	"vecshard.dev/migrate/ax"
	"vecshard.dev/migrate/cx"
	"vecshard.dev/migrate/ledger"
	"vecshard.dev/migrate/pipeline"
	"vecshard.dev/migrate/pkg/types"
	"vecshard.dev/migrate/dx"
	"vecshard.dev/migrate/bx"
)

func Run(cfg types.MigrateCfg, cases []types.ShardCase) (types.MigrateReport, error) {
	if override := os.Getenv("TB_ENTITY_PATH"); override != "" {
		cfg.CorpusPath = override
	}
	entities, err := corpus.Load(cfg.CorpusPath)
	if err != nil {
		return types.MigrateReport{}, err
	}
	byID := corpus.ByID(entities)
	report := types.MigrateReport{
		Status:        "ok",
		VectorTotal:   len(entities),
		WorkerCount: cfg.WorkerCount,
		FormatProfile:  cfg.FormatProfile,
		ShardsTotal:  len(cases),
	}
	var sumIntegrity, sumFresh, sumProp, sumStale, sumBal, sumDedup, sumOrder, sumLag float64
	materialVals := make([]int, 0, len(cases))
	report.Shards = make([]types.ShardRow, 0, len(cases))

	for _, sc := range cases {
		cx.KpReset()
		shardVectors := make([]types.Vector, 0, len(sc.VectorIDs))
		for _, id := range sc.VectorIDs {
			if e, ok := byID[id]; ok {
				shardVectors = append(shardVectors, e)
			}
		}
		events := synthEvents(shardVectors, sc)
		bx.ThSortEvents(events)
		orderRate := bx.ThSeqOrderRate(events)
		lagUnits := ax.DlLagUnits(events)
		windowed := ax.DlApplyWindow(events, sc.LagCapUnits)
		accepted, dedupPurity := cx.KpFilterEvents(windowed)
		watermark := bx.ThWatermark(accepted)

		active := cx.KpWx(cfg.WorkerCount, sc.DeadWorkers)
		lanes := cx.KpBx(vectorPayloads(accepted), cfg.WorkerCount)
		var spill []types.Vector
		firstLive := -1
		for lane, batch := range lanes {
			if lane >= cfg.WorkerCount {
				continue
			}
			if isDead(lane, sc.DeadWorkers) {
				spill = append(spill, batch...)
				lanes[lane] = nil
				continue
			}
			if firstLive < 0 {
				firstLive = lane
			}
		}
		if firstLive >= 0 && len(spill) > 0 {
			lanes[firstLive] = append(lanes[firstLive], spill...)
		}

		matches := 0
		propUnits := 0
		staleUnits := 0
		materialUnits := 0
		perLaneRunes := make([]int, cfg.WorkerCount)
		unicodeHits, unicodeTotal := 0, 0
		freshHits := 0

		for lane, batch := range lanes {
			if lane >= cfg.WorkerCount || isDead(lane, sc.DeadWorkers) {
				continue
			}
			for _, ent := range batch {
				runes := utf8.RuneCountInString(ent.Payload)
				perLaneRunes[lane] += runes
				key := dx.SgHx(ent.ID)
				var digest string
				if cached, ok := dx.SgRd(key); ok {
					digest = cached.Digest
					if digest != ledger.DgFold(ent.Payload) {
						staleUnits += runes
					}
				} else {
					dg, _, alloc, err := dx.SgZc(ent.Payload)
					if err != nil {
						return types.MigrateReport{}, err
					}
					digest = dg
					dx.SgWr(key, digest, 0)
					materialUnits += alloc
				}
				if digest == ledger.DgFold(ent.Payload) {
					matches++
					if eventMsForVector(accepted, ent.ID) <= watermark {
						freshHits++
					}
				}
				if pipeline.HasUnicodeRunes(ent.Payload) {
					unicodeTotal++
					if digest == ledger.DgFold(ent.Payload) {
						unicodeHits++
					}
				}
			}
		}

		baseRunes := 0
		for _, r := range perLaneRunes {
			baseRunes += r
		}
		propUnits = baseRunes
		if active < cfg.WorkerCount {
			propUnits = baseRunes * cfg.WorkerCount
		}

		integrity := 0.0
		if len(shardVectors) > 0 {
			integrity = float64(matches) / float64(len(shardVectors))
		}
		freshness := 0.0
		if len(shardVectors) > 0 {
			freshness = float64(freshHits) / float64(len(shardVectors))
		}
		balance := cx.KpBalScore(perLaneRunes, sc.DeadWorkers)
		row := types.ShardRow{
			ShardID:           sc.ShardID,
			VectorIntegrity:   round4(integrity),
			RecallConsistency:     round4(freshness),
			RelayUnits:   propUnits,
			LegacyUnits:         staleUnits,
			CutoverLagUnits:   lagUnits,
			ChecksumPurity:        round4(dedupPurity),
			SeqOrderRate: round4(orderRate),
			WorkersActive:      active,
			BalanceScore:       round4(balance),
			VectorIDs:          append([]string(nil), sc.VectorIDs...),
		}
		report.Shards = append(report.Shards, row)
		sumIntegrity += integrity
		sumFresh += freshness
		sumProp += float64(propUnits)
		sumStale += float64(staleUnits)
		sumBal += balance
		sumDedup += dedupPurity
		sumOrder += orderRate
		sumLag += float64(lagUnits)
		materialVals = append(materialVals, materialUnits)
		_ = unicodeHits
		_ = unicodeTotal
	}

	n := float64(len(cases))
	if n > 0 {
		report.MeanVectorIntegrity = round4(sumIntegrity / n)
		report.MeanRecallConsistency = round4(sumFresh / n)
		report.MeanRelayUnits = round4(sumProp / n)
		report.MeanLegacyUnits = round4(sumStale / n)
		report.MeanBalanceScore = round4(sumBal / n)
		report.ChecksumPurityRate = round4(sumDedup / n)
		report.SeqOrderRate = round4(sumOrder / n)
		report.MeanCutoverLagUnits = round4(sumLag / n)
	}
	report.P95ReencodeUnits = p95(materialVals)
	if !meetsFloors(cfg, report) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func synthEvents(entities []types.Vector, sc types.ShardCase) []types.ShardEvent {
	replay := 1
	if sc.DupReplay > 1 {
		replay = sc.DupReplay
	}
	out := make([]types.ShardEvent, 0, len(entities)*replay)
	for i, ent := range entities {
		eventMs := int64(1000 + i*100)
		ingestMs := eventMs
		if sc.IngestSkewMs > 0 {
			ingestMs = eventMs + int64(sc.IngestSkewMs) - int64(i*200)
		}
		for r := 0; r < replay; r++ {
			seq := uint64(i+1) + uint64(r)*10000
			out = append(out, types.ShardEvent{
				VectorID: ent.ID,
				Seq:      seq,
				EventMs:  eventMs,
				IngestMs: ingestMs,
				Payload:  ent.Payload,
			})
		}
	}
	return out
}

func vectorPayloads(events []types.ShardEvent) []types.Vector {
	out := make([]types.Vector, 0, len(events))
	for _, ev := range events {
		out = append(out, types.Vector{ID: ev.VectorID, Payload: ev.Payload})
	}
	return out
}

func eventMsForVector(events []types.ShardEvent, vectorID string) int64 {
	var max int64
	for _, ev := range events {
		if ev.VectorID == vectorID && ev.EventMs > max {
			max = ev.EventMs
		}
	}
	return max
}

func isDead(lane int, dead []int) bool {
	for _, d := range dead {
		if d == lane {
			return true
		}
	}
	return false
}

func meetsFloors(cfg types.MigrateCfg, report types.MigrateReport) bool {
	if report.MeanVectorIntegrity < cfg.IntegrityFloor {
		return false
	}
	if report.MeanRecallConsistency < cfg.RecallConsistencyFloor {
		return false
	}
	if int(report.MeanRelayUnits) > cfg.MaxMeanRelayUnits {
		return false
	}
	if int(report.MeanLegacyUnits) > cfg.MaxMeanLegacyUnits {
		return false
	}
	if report.P95ReencodeUnits > cfg.MaxP95ReencodeUnits {
		return false
	}
	if report.MeanBalanceScore < cfg.BalanceFloor {
		return false
	}
	if report.ChecksumPurityRate < cfg.ChecksumPurityFloor {
		return false
	}
	if report.SeqOrderRate < cfg.SeqOrderFloor {
		return false
	}
	if int(report.MeanCutoverLagUnits) > cfg.MaxMeanCutoverLagUnits {
		return false
	}
	return true
}

func round4(v float64) float64 {
	if v > 1 {
		return 1
	}
	if v < 0 {
		return 0
	}
	return math.Round(v*10000+0.5) / 10000
}

func p95(vals []int) int {
	if len(vals) == 0 {
		return 0
	}
	cp := append([]int(nil), vals...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}

type digestPayload struct {
	Status               string             `json:"status"`
	VectorTotal          int                `json:"vector_total"`
	WorkerCount        int                `json:"worker_count"`
	FormatProfile         string             `json:"format_profile"`
	ShardsTotal         int                `json:"shards_total"`
	MeanVectorIntegrity float64            `json:"mean_vector_integrity"`
	MeanRecallConsistency   float64            `json:"mean_recall_consistency"`
	MeanRelayUnits float64            `json:"mean_relay_units"`
	MeanLegacyUnits       float64            `json:"mean_legacy_units"`
	P95ReencodeUnits     int                `json:"p95_reencode_units"`
	MeanBalanceScore     float64            `json:"mean_balance_score"`
	ChecksumPurityRate      float64            `json:"checksum_purity_rate"`
	SeqOrderRate   float64            `json:"seq_order_rate"`
	MeanCutoverLagUnits float64            `json:"mean_cutover_lag_units"`
	ReportDigest         string             `json:"report_digest"`
	Shards               []types.ShardRow  `json:"shards"`
}

func digestBody(report types.MigrateReport) string {
	payload := digestPayload{
		Status:               report.Status,
		VectorTotal:          report.VectorTotal,
		WorkerCount:        report.WorkerCount,
		FormatProfile:         report.FormatProfile,
		ShardsTotal:         report.ShardsTotal,
		MeanVectorIntegrity: report.MeanVectorIntegrity,
		MeanRecallConsistency:   report.MeanRecallConsistency,
		MeanRelayUnits: report.MeanRelayUnits,
		MeanLegacyUnits:       report.MeanLegacyUnits,
		P95ReencodeUnits:     report.P95ReencodeUnits,
		MeanBalanceScore:     report.MeanBalanceScore,
		ChecksumPurityRate:      report.ChecksumPurityRate,
		SeqOrderRate:   report.SeqOrderRate,
		MeanCutoverLagUnits: report.MeanCutoverLagUnits,
		ReportDigest:         "",
		Shards:               report.Shards,
	}
	raw, _ := json.Marshal(payload)
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func WriteReport(path string, report types.MigrateReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}

func SanityProfile(profile string) error {
	if strings.TrimSpace(profile) == "" {
		return fmt.Errorf("empty fresh profile")
	}
	return nil
}
