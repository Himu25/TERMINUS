package bench

import (
	"bufio"
	"encoding/json"
	"os"
	"strconv"
	"strings"

	"vecshard.dev/migrate/pkg/types"
)

func LoadCfg(path string) (types.MigrateCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.MigrateCfg{}, err
	}
	cfg := types.MigrateCfg{
		CorpusPath:              "/app/data/vectors_default.json",
		WorkerCount:           4,
		FormatProfile:            "v3",
		IntegrityFloor:          0.98,
		MaxMeanRelayUnits: 2200,
		MaxMeanLegacyUnits:       1200,
		MaxP95ReencodeUnits:     9000,
		BalanceFloor:            0.72,
		RecallConsistencyFloor:          0.95,
		ChecksumPurityFloor:        0.95,
		SeqOrderFloor:     0.95,
		MaxMeanCutoverLagUnits: 800,
		FailoverIntegrityFloor:  0.90,
		SkewBalanceMin:          0.65,
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		parts := strings.SplitN(line, "=", 2)
		if len(parts) != 2 {
			continue
		}
		key := strings.TrimSpace(parts[0])
		val := strings.TrimSpace(parts[1])
		switch key {
		case "corpus_path":
			cfg.CorpusPath = val
		case "worker_count":
			cfg.WorkerCount, _ = strconv.Atoi(val)
		case "format_profile":
			cfg.FormatProfile = val
		case "integrity_floor", "recall_consistency_floor", "balance_floor", "checksum_purity_floor",
			"seq_order_floor", "failover_integrity_floor", "skew_balance_min":
			cfg, err = setFloatField(cfg, key, val)
			if err != nil {
				return types.MigrateCfg{}, err
			}
		case "max_mean_relay_units", "max_mean_legacy_units", "max_p95_reencode_units",
			"max_mean_cutover_lag_units":
			cfg, err = setIntField(cfg, key, val)
			if err != nil {
				return types.MigrateCfg{}, err
			}
		}
	}
	return cfg, nil
}

func setFloatField(cfg types.MigrateCfg, key, val string) (types.MigrateCfg, error) {
	f, err := strconv.ParseFloat(val, 64)
	if err != nil {
		return cfg, err
	}
	switch key {
	case "integrity_floor":
		cfg.IntegrityFloor = f
	case "recall_consistency_floor":
		cfg.RecallConsistencyFloor = f
	case "balance_floor":
		cfg.BalanceFloor = f
	case "checksum_purity_floor":
		cfg.ChecksumPurityFloor = f
	case "seq_order_floor":
		cfg.SeqOrderFloor = f
	case "failover_integrity_floor":
		cfg.FailoverIntegrityFloor = f
	case "skew_balance_min":
		cfg.SkewBalanceMin = f
	}
	return cfg, nil
}

func setIntField(cfg types.MigrateCfg, key, val string) (types.MigrateCfg, error) {
	i, err := strconv.Atoi(val)
	if err != nil {
		return cfg, err
	}
	switch key {
	case "max_mean_relay_units":
		cfg.MaxMeanRelayUnits = i
	case "max_mean_legacy_units":
		cfg.MaxMeanLegacyUnits = i
	case "max_p95_reencode_units":
		cfg.MaxP95ReencodeUnits = i
	case "max_mean_cutover_lag_units":
		cfg.MaxMeanCutoverLagUnits = i
	}
	return cfg, nil
}

func LoadShards(path string) ([]types.ShardCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	var out []types.ShardCase
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var row types.ShardCase
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return nil, err
		}
		out = append(out, row)
	}
	return out, sc.Err()
}
