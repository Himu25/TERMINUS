package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"

	"vecshard.dev/migrate/bench"
	"vecshard.dev/migrate/corpus"
	"vecshard.dev/migrate/ledger"
	"vecshard.dev/migrate/pkg/types"
)

func main() {
	if len(os.Args) < 4 {
		fmt.Fprintln(os.Stderr, "usage: shardgen <entities.json> <specs.jsonl> <out.jsonl>")
		os.Exit(2)
	}
	entities, err := corpus.Load(os.Args[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	byID := corpus.ByID(entities)
	specs, err := bench.LoadShards(os.Args[2])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	out, err := os.Create(os.Args[3])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer out.Close()
	w := bufio.NewWriter(out)
	for _, spec := range specs {
		gold := make(map[string]string, len(spec.VectorIDs))
		for _, id := range spec.VectorIDs {
			if e, ok := byID[id]; ok {
				gold[id] = ledger.DgFold(e.Payload)
			}
		}
		row := struct {
			types.ShardCase
			GoldDigests map[string]string `json:"gold_digests"`
		}{
			ShardCase:  spec,
			GoldDigests: gold,
		}
		raw, _ := json.Marshal(row)
		if _, err := w.Write(append(raw, '\n')); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	}
	if err := w.Flush(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
