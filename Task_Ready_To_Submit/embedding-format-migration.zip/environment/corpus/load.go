package corpus

import (
	"encoding/json"
	"os"

	"vecshard.dev/migrate/pkg/types"
)

const DefaultCorpusPath = "/app/data/vectors_default.json"

func Load(path string) ([]types.Vector, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var entities []types.Vector
	if err := json.Unmarshal(raw, &entities); err != nil {
		return nil, err
	}
	return entities, nil
}

func ByID(entities []types.Vector) map[string]types.Vector {
	out := make(map[string]types.Vector, len(entities))
	for _, e := range entities {
		out[e.ID] = e
	}
	return out
}
