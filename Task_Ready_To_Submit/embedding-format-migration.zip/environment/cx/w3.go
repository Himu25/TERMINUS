package cx

var seenEntity = map[string]struct{}{}

// KpReset clears dedup state between stream scenarios.
func KpReset() {
	seenEntity = map[string]struct{}{}
}

// KpAccept reports whether an update may be applied.
func KpAccept(entityID string, seq uint64) bool {
	if _, ok := seenEntity[entityID]; ok {
		return false
	}
	seenEntity[entityID] = struct{}{}
	return true
}
