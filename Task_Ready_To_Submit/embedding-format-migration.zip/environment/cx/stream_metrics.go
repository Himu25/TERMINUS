package cx

import "vecshard.dev/migrate/pkg/types"

// KpFilterEvents applies stream dedup and returns accepted events plus purity.
func KpFilterEvents(events []types.ShardEvent) ([]types.ShardEvent, float64) {
	accepted := make([]types.ShardEvent, 0, len(events))
	for _, ev := range events {
		if KpAccept(ev.VectorID, ev.Seq) {
			accepted = append(accepted, ev)
		}
	}
	if len(events) == 0 {
		return accepted, 1.0
	}
	return accepted, float64(len(accepted)) / float64(len(events))
}

// KpBalScore scores lane load spread for active workers.
func KpBalScore(perLane []int, dead []int) float64 {
	vals := make([]int, 0, len(perLane))
	total := 0
	for i, v := range perLane {
		if isDeadLane(i, dead) || v == 0 {
			continue
		}
		vals = append(vals, v)
		total += v
	}
	if total == 0 || len(vals) == 0 {
		return 1.0
	}
	activeConfigured := 0
	for i := range perLane {
		if !isDeadLane(i, dead) {
			activeConfigured++
		}
	}
	if len(dead) == 0 && activeConfigured > 1 && len(vals) == 1 {
		return 0.0
	}
	minV, maxV := vals[0], vals[0]
	for _, v := range vals {
		if v < minV {
			minV = v
		}
		if v > maxV {
			maxV = v
		}
	}
	spread := float64(maxV-minV) / float64(total)
	score := 1.0 - spread
	if score < 0 {
		return 0
	}
	if score > 1 {
		return 1
	}
	return score
}

func isDeadLane(lane int, dead []int) bool {
	for _, d := range dead {
		if d == lane {
			return true
		}
	}
	return false
}
