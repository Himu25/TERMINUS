package cx

// KpWx returns how many prep workers may run concurrently.
func KpWx(cfgWorkers int, dead []int) int {
	_ = dead
	return 1
}
