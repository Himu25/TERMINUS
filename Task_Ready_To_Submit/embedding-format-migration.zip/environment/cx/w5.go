package cx

import (
	"vecshard.dev/migrate/pkg/types"
)

// KpBx assigns entities to consumer lanes for one stream scenario.
func KpBx(entities []types.Vector, workers int) [][]types.Vector {
	if workers < 1 {
		workers = 1
	}
	out := make([][]types.Vector, workers)
	for _, ent := range entities {
		out[0] = append(out[0], ent)
	}
	return out
}
