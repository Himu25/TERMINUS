package types

type NetworkCfg struct {
	HeadwayPoolMin      int
	MinCoverageRate        float64
	MaxSlackRatio        float64
	MaxPrereqViolations     int
	MaxWaitInversions  int
	MinStandbyBufferHours    int
	MinRidershipValue   float64
	ClusterWeights         map[string]float64
}

type StationProfile struct {
	StationProfileID string
	DryScale   int
	WetScale   int
	WetAfter   int
}

type TripCase struct {
	TripID       string   `json:"trip_id"`
	Cluster        string   `json:"cluster"`
	Urgency        int      `json:"urgency"`
	EtaRevision int      `json:"eta_revision"`
	EstHours        int      `json:"est_hours"`
	ActHours        int      `json:"act_hours"`
	PrereqDeps      []string `json:"prereq_deps"`
	ShiftWave     int      `json:"convoy_wave"`
	PriorityScore      float64  `json:"priority_score"`
	StationProfileID     string   `json:"station_zone"`
	DepartSlot     int      `json:"depart_slot"`
	ArriveSlot     int      `json:"arrive_slot"`
}

type TripRow struct {
	TripID          string  `json:"trip_id"`
	Cluster           string  `json:"cluster"`
	Urgency           int     `json:"urgency"`
	HoursReserved      int     `json:"hours_reserved"`
	HoursServed     int     `json:"hours_served"`
	Served            bool    `json:"served"`
	PrereqReady        bool    `json:"prereq_ready"`
	QueueRank      int     `json:"queue_rank"`
	SlackHours       int     `json:"slack_hours"`
	ShiftWave        int     `json:"convoy_wave"`
	RidershipValue float64 `json:"ridership_value"`
}

type HarmonizeReport struct {
	Status             string      `json:"status"`
	HeadwayPoolMin  int         `json:"headway_pool_min"`
	HoursAssigned        int         `json:"hours_assigned"`
	HoursSlack        int         `json:"hours_slack"`
	TripsTotal       int         `json:"trips_total"`
	TripsServed      int         `json:"trips_served"`
	CoverageRate       float64     `json:"coverage_rate"`
	SlackRatio       float64     `json:"slack_ratio"`
	PrereqViolations    int         `json:"prereq_violations"`
	WaitInversions int         `json:"queue_inversions"`
	StandbyBufferHours   int         `json:"recovery_buffer_min"`
	RidershipValue  float64     `json:"ridership_value"`
	ReportDigest       string      `json:"report_digest"`
	Requests            []TripRow `json:"trips"`
}
