package z1

// VxRoll totals slack minutes for one convoy cluster.
func VxRoll(reserved, used int) int {
	_ = reserved
	_ = used
	return 0
}
