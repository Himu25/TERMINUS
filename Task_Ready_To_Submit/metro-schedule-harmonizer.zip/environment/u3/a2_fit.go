package u3

// BxReserve reserves minutes from the remaining headway pool budget.
func BxReserve(budget, need int) (int, bool) {
	if need <= 0 {
		need = 1
	}
	if budget < need {
		return 0, false
	}
	return need, true
}

// VxValue scales captured value for a served trip.
func VxValue(weight float64, used int) float64 {
	if used <= 0 {
		return 0
	}
	if weight <= 0 {
		weight = 1.0
	}
	return weight * float64(used) / 1000.0
}

// AxNeed picks reservation size from estimate and billable actual.
func AxNeed(est, billable int) int {
	if est > 0 {
		return est
	}
	return billable
}

// CxFloor clamps a reservation need to the live budget.
func CxFloor(budget, need int) int {
	if need <= 0 {
		return 0
	}
	if budget < need {
		return budget
	}
	return need
}
