module mshm.lab

go 1.22
