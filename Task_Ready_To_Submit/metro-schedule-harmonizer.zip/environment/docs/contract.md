# Harmonize report contract

Default manifest scenario prefixes:

- `t_link_` turnback chain rows
- `t_delay_` delay-revision rows (late revision must finish before stale peers)
- `t_slip_` slip drift rows
- `t_convoy_` convoy cluster rows
- `t_bottle_` station-bottleneck rows
- `t_fail_` equipment-failure rows
- `t_recovery_` delayed-recovery rows in regression packs

Top-level fields:

- status: ok when all network.toml guardrails pass, otherwise fail
- headway_pool_min: configured minute pool from network.toml
- hours_assigned: billable minutes consumed by served trips
- hours_slack: reservation surplus summed across trips
- trips_total: input JSONL row count
- trips_served: trips marked served
- coverage_rate: trips_served / trips_total rounded to four decimals
- slack_ratio: hours_slack / hours_assigned rounded to four decimals
- prereq_violations: trips allocated before prereq dependencies finished
- queue_inversions: served trips whose rank score fell below a prior finish
- recovery_buffer_min: headroom minutes absorbed during convoy clusters
- ridership_value: weighted priority score total for served trips
- report_digest: sha256 hex of compact JSON with report_digest empty
- trips: per-trip rows

Per-trip row fields:

- trip_id, cluster, urgency
- hours_reserved, hours_served, slack_hours
- served, prereq_ready, queue_rank, convoy_wave, ridership_value

Ordering:
Pending trips are sorted before allocation using, in order:
eta_revision descending, urgency descending, priority_score descending, trip_id ascending.

queue_rank:
1-based position in the scheduler processing order after the sort above.

queue_inversions:
For each served trip, form rank score = eta_revision \* 10 + urgency.

Station profiles:
station_profiles.csv supplies dry_scale, wet_scale, and wet_after per station_zone.
The Rust meter span_fold blends those scales across each trip's depart_slot and act_hours before converting estimates and act_hours into billable hours.

Blending rules:

- Service duration is act_hours when positive, otherwise est_hours (minimum one slot).
- When the window ends at or before wet_after, use dry_scale only.
- When the window starts at or after wet_after, use wet_scale only.
- Otherwise weight dry_scale by the pre-threshold slot count and wet_scale by the post-threshold slot count, then divide by duration.
- Billable hours = act_hours times the blended scale divided by 100 (minimum one when act_hours is positive).
- eu-west bills below us-east for the same act_hours when its wet_scale is lower.

Intensity ceiling: for t_bottle_us and t_bottle_eu with act_hours 580, hours_reserved must be at most 498. Applying dry_scale alone overshoots that cap; duration-weighted blending lands underneath it.

Zero-estimate overlay: when est_hours is zero and actual_dwell.csv supplies act_hours for a trip, hours_reserved and hours_served equal the dwell log value without upward scale markup. t_bottle_meter must bill 650 from its dwell log row.

hours_served:
Dwell log act_hours when actual_dwell.csv supplies a value, otherwise act_hours from the trip row.

slack_hours:
max(0, hours_reserved - hours_served)

hours_reserved:
Positive est_hours drives reservations before service; zero-estimate rows with dwell-log act_hours bill the log value without upward scale markup.

Input coverage:
trips_total and the report trip_id set must match every input JSONL row with no drops or extras.

Passing run:
status is ok when all network.toml guardrails pass. report_digest is 64-character lowercase hex from compact pre-digest JSON with report_digest empty. Identical inputs must yield byte-identical output.
