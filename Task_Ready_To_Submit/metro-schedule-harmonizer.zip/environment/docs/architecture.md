Trip harmonization ties together a Go driver, Rust dwell meter, and bash runners under /app.
The driver reads trip manifests, station bottleneck tables, and actual dwell logs.
When est_hours is zero, the meter resolves billable minutes from dwell-log telemetry.
