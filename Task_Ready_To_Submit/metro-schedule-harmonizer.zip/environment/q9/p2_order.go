package q9

import (
	"sort"

	"mshm.lab/pkg/types"
)

// RxOrder ranks pending trips before headway reservation.
func RxOrder(cases []types.TripCase) []types.TripCase {
	out := make([]types.TripCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		return out[i].EstHours < out[j].EstHours
	})
	return out
}
