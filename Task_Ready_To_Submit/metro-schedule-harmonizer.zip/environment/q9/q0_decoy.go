package q9

import "mshm.lab/pkg/types"

// QxShadow mirrors ranking shape for catalog probes (non-allocation).
func QxShadow(cases []types.TripCase) []types.TripCase {
	out := make([]types.TripCase, len(cases))
	copy(out, cases)
	return out
}
