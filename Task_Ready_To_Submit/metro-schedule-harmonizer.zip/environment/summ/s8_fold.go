package summ

import "mshm.lab/pkg/types"

// SxFold folds trip rows for telemetry export (non-scheduling).
func SxFold(rows []types.TripRow) int {
	total := 0
	for _, row := range rows {
		total += row.HoursServed
	}
	return total
}
