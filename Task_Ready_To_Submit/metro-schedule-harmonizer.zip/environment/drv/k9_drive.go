package drv

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"

	"mshm.lab/k2"
	"mshm.lab/pkg/types"
	"mshm.lab/q9"
	"mshm.lab/summ"
	"mshm.lab/u3"
)

func LoadCfg(path string) (types.NetworkCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.NetworkCfg{}, err
	}
	cfg := types.NetworkCfg{
		HeadwayPoolMin:     12000,
		MinCoverageRate:     0.75,
		MaxSlackRatio:         0.35,
		MaxPrereqViolations:      0,
		MaxWaitInversions: 1,
		MinStandbyBufferHours:      3,
		MinRidershipValue:     2.0,
		ClusterWeights:           map[string]float64{"cluster_alpha": 1.0, "cluster_beta": 1.0, "cluster_gamma": 1.0},
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "headway_pool_min":
			fmt.Sscanf(val, "%d", &cfg.HeadwayPoolMin)
		case "min_coverage_rate":
			fmt.Sscanf(val, "%f", &cfg.MinCoverageRate)
		case "max_slack_ratio":
			fmt.Sscanf(val, "%f", &cfg.MaxSlackRatio)
		case "max_prereq_violations":
			fmt.Sscanf(val, "%d", &cfg.MaxPrereqViolations)
		case "max_queue_inversions":
			fmt.Sscanf(val, "%d", &cfg.MaxWaitInversions)
		case "min_recovery_buffer_min":
			fmt.Sscanf(val, "%d", &cfg.MinStandbyBufferHours)
		case "min_ridership_value":
			fmt.Sscanf(val, "%f", &cfg.MinRidershipValue)
		case "cluster_weight_alpha":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClusterWeights["cluster_alpha"] = w
		case "cluster_weight_beta":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClusterWeights["cluster_beta"] = w
		case "cluster_weight_gamma":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClusterWeights["cluster_gamma"] = w
		}
	}
	return cfg, nil
}

func LoadStationProfiles(path string) (map[string]types.StationProfile, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]types.StationProfile)
	for i, row := range rows {
		if i == 0 || len(row) < 4 {
			continue
		}
		var peak, renew, after int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &peak)
		fmt.Sscanf(strings.TrimSpace(row[2]), "%d", &renew)
		fmt.Sscanf(strings.TrimSpace(row[3]), "%d", &after)
		id := strings.TrimSpace(row[0])
		out[id] = types.StationProfile{
			StationProfileID: id,
			DryScale:  peak,
			WetScale: renew,
			WetAfter: after,
		}
	}
	return out, nil
}

func LoadTripCases(path string) ([]types.TripCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.TripCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var jc types.TripCase
		if err := json.Unmarshal([]byte(line), &jc); err != nil {
			return nil, err
		}
		if jc.StationProfileID == "" {
			jc.StationProfileID = "us-east"
		}
		out = append(out, jc)
	}
	return out, sc.Err()
}

func LoadActualDwell(path string) (map[string]int, error) {
	f, err := os.Open(path)
	if err != nil {
		return map[string]int{}, nil
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]int)
	for i, row := range rows {
		if i == 0 || len(row) < 2 {
			continue
		}
		var actTons int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &actTons)
		out[strings.TrimSpace(row[0])] = actTons
	}
	return out, nil
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

func calibrationFor(jc types.TripCase, calibrations map[string]types.StationProfile) types.StationProfile {
	if rp, ok := calibrations[jc.StationProfileID]; ok {
		return rp
	}
	return types.StationProfile{StationProfileID: jc.StationProfileID, DryScale: 100, WetScale: 100, WetAfter: 0}
}

func Run(cfg types.NetworkCfg, cases []types.TripCase, fieldReports map[string]int, calibrations map[string]types.StationProfile) (types.HarmonizeReport, error) {
	ordered := q9.RxOrder(cases)
	report := types.HarmonizeReport{
		Status:            "ok",
		HeadwayPoolMin: cfg.HeadwayPoolMin,
		TripsTotal:         len(ordered),
	}
	done := make(map[string]bool)
	budgetLeft := cfg.HeadwayPoolMin
	var spent, totalWaste, completed, depViol, inversions, renewTotal int
	var valueTotal float64
	prevRank := -1
	report.Requests = make([]types.TripRow, 0, len(ordered))

	for idx, jc := range ordered {
		actualReady := true
		for _, depID := range jc.PrereqDeps {
			if !done[depID] {
				actualReady = false
				break
			}
		}
		depReady := k2.DxGate(jc.PrereqDeps, done)
		if len(jc.PrereqDeps) > 0 && !actualReady && depReady {
			depViol++
		}
		fieldReportVal := 0
		if act, ok := fieldReports[jc.TripID]; ok && act > 0 {
			fieldReportVal = act
			jc.ActHours = act
		}
		rp := calibrationFor(jc, calibrations)
		billable := meterBillable(jc, fieldReportVal, rp)
		reserveNeed := u3.AxNeed(jc.EstHours, billable)
		reserved, ok := u3.BxReserve(budgetLeft, reserveNeed)
		headroom := budgetLeft - reserved
		if jc.ShiftWave > 0 {
			renewTotal += waveAllocationTotal(jc.ShiftWave, jc.EstHours, headroom)
		}
		used := 0
		finished := false
		if ok && depReady {
			used = jc.ActHours
			if used <= 0 {
				used = billable
			}
			if used > reserved {
				used = reserved
			}
			budgetLeft -= reserved
			spent += used
			finished = true
			completed++
			done[jc.TripID] = true
			valueTotal += u3.VxValue(jc.PriorityScore, used)
		}
		wasteAmt := requestSurplus(reserved, used)
		totalWaste += wasteAmt
		rankScore := jc.EtaRevision*10 + jc.Urgency
		if finished {
			if prevRank >= 0 && rankScore > prevRank {
				inversions++
			}
			prevRank = rankScore
		}
		row := types.TripRow{
			TripID:          jc.TripID,
			Cluster:           jc.Cluster,
			Urgency:       jc.Urgency,
			HoursReserved:  reserved,
			HoursServed:      used,
			Served:      finished,
			PrereqReady:       depReady,
			QueueRank:   idx + 1,
			SlackHours:     wasteAmt,
			ShiftWave:      jc.ShiftWave,
			RidershipValue: round4(u3.VxValue(jc.PriorityScore, used)),
		}
		report.Requests = append(report.Requests, row)
	}

	report.HoursAssigned = spent
	report.HoursSlack = totalWaste
	report.TripsServed = completed
	if report.TripsTotal > 0 {
		report.CoverageRate = round4(float64(completed) / float64(report.TripsTotal))
	}
	if spent > 0 {
		report.SlackRatio = round4(float64(totalWaste) / float64(spent))
	}
	report.PrereqViolations = depViol
	report.WaitInversions = inversions
	report.StandbyBufferHours = renewTotal
	report.RidershipValue = round4(valueTotal)
	hasAllocation := false
	for _, jc := range ordered {
		if jc.ShiftWave > 0 {
			hasAllocation = true
			break
		}
	}
	if !meetsFloors(cfg, report, hasAllocation) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func meetsFloors(cfg types.NetworkCfg, report types.HarmonizeReport, hasAllocation bool) bool {
	if report.CoverageRate < cfg.MinCoverageRate {
		return false
	}
	if report.SlackRatio > cfg.MaxSlackRatio {
		return false
	}
	if report.PrereqViolations > cfg.MaxPrereqViolations {
		return false
	}
	if report.WaitInversions > cfg.MaxWaitInversions {
		return false
	}
	if report.StandbyBufferHours < cfg.MinStandbyBufferHours {
		if hasAllocation {
			return false
		}
	}
	if report.RidershipValue < cfg.MinRidershipValue {
		return false
	}
	for _, row := range report.Requests {
		if strings.HasPrefix(row.TripID, "t_link_") && !row.PrereqReady && row.Served {
			return false
		}
		if strings.HasPrefix(row.TripID, "t_fail_") && !row.PrereqReady && row.Served {
			return false
		}
		if strings.HasPrefix(row.TripID, "t_convoy_") && row.ShiftWave > 0 && !row.Served {
			return false
		}
		if strings.HasPrefix(row.TripID, "t_slip_") && row.SlackHours == 0 && row.HoursReserved > row.HoursServed+50 {
			return false
		}
		if strings.HasPrefix(row.TripID, "t_bottle_") && row.Served && row.HoursServed > row.HoursReserved+200 {
			return false
		}
	}
	_ = summ.SxFold(report.Requests)
	return true
}

type digestPayload struct {
	Status              string         `json:"status"`
	HeadwayPoolMin   int            `json:"headway_pool_min"`
	HoursAssigned          int            `json:"hours_assigned"`
	HoursSlack          int            `json:"hours_slack"`
	TripsTotal           int            `json:"trips_total"`
	TripsServed       int            `json:"trips_served"`
	CoverageRate      float64        `json:"coverage_rate"`
	SlackRatio          float64        `json:"slack_ratio"`
	PrereqViolations       int            `json:"prereq_violations"`
	WaitInversions  int            `json:"queue_inversions"`
	StandbyBufferHours    int            `json:"recovery_buffer_min"`
	RidershipValue   float64        `json:"ridership_value"`
	ReportDigest        string         `json:"report_digest"`
	Requests             []types.TripRow `json:"trips"`
}

func digestBody(report types.HarmonizeReport) string {
	payload := digestPayload{
		Status:              report.Status,
		HeadwayPoolMin:   report.HeadwayPoolMin,
		HoursAssigned:         report.HoursAssigned,
		HoursSlack:         report.HoursSlack,
		TripsTotal:        report.TripsTotal,
		TripsServed:       report.TripsServed,
		CoverageRate:        report.CoverageRate,
		SlackRatio:        report.SlackRatio,
		PrereqViolations:     report.PrereqViolations,
		WaitInversions:  report.WaitInversions,
		StandbyBufferHours:    report.StandbyBufferHours,
		RidershipValue:   report.RidershipValue,
		ReportDigest:        "",
		Requests:             report.Requests,
	}
	raw, err := marshalDigestJSON(payload)
	if err != nil {
		return ""
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func marshalDigestJSON(payload digestPayload) ([]byte, error) {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return nil, err
	}
	b := buf.Bytes()
	if n := len(b); n > 0 && b[n-1] == '\n' {
		b = b[:n-1]
	}
	return b, nil
}

func WriteReport(path string, report types.HarmonizeReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func p95(values []int) int {
	if len(values) == 0 {
		return 0
	}
	cp := append([]int(nil), values...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}
