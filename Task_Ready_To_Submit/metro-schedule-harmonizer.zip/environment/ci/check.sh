#!/bin/bash
set -euo pipefail
cd /app
bash /app/scripts/build.sh
/app/bin/tripack /app/data/trip_manifest.jsonl /app/data/trips_default.jsonl
/app/tools/run_harmonizer
