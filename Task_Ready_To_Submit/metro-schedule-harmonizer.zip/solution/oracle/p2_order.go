package q9

import (
	"sort"

	"mshm.lab/pkg/types"
)

// RxOrder ranks pending trips before headway reservation.
func RxOrder(cases []types.TripCase) []types.TripCase {
	out := make([]types.TripCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		a, b := out[i], out[j]
		if a.EtaRevision != b.EtaRevision {
			return a.EtaRevision > b.EtaRevision
		}
		if a.Urgency != b.Urgency {
			return a.Urgency > b.Urgency
		}
		if a.PriorityScore != b.PriorityScore {
			return a.PriorityScore > b.PriorityScore
		}
		return a.TripID < b.TripID
	})
	return out
}
