package z1

// VxRoll totals slack minutes for one convoy cluster.
func VxRoll(reserved, used int) int {
	if reserved <= 0 {
		return 0
	}
	if used < 0 {
		used = 0
	}
	if reserved <= used {
		return 0
	}
	return reserved - used
}
