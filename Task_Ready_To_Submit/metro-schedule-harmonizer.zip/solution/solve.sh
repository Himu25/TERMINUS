#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

json_field() {
  local key="$1"
  local file="$2"
  grep -o "\"${key}\"[[:space:]]*:[[:space:]]*[^,}]*" "$file" | head -1 | sed 's/.*:[[:space:]]*//' | tr -d '"'
}

validate_default_report() {
  local report="$1"
  local cfg="$2"
  local status coverage slack prereq inv buf ride
  local min_cov max_slack max_prereq max_inv min_buf min_ride

  status="$(json_field status "$report")"
  [[ "$status" == "ok" ]] || { log "unexpected status: ${status:-missing}"; return 1; }

  min_cov="$(awk -F= '/^min_coverage_rate=/ {gsub(/ /,"",$2); print $2}' "$cfg")"
  max_slack="$(awk -F= '/^max_slack_ratio=/ {gsub(/ /,"",$2); print $2}' "$cfg")"
  max_prereq="$(awk -F= '/^max_prereq_violations=/ {gsub(/ /,"",$2); print $2}' "$cfg")"
  max_inv="$(awk -F= '/^max_queue_inversions=/ {gsub(/ /,"",$2); print $2}' "$cfg")"
  min_buf="$(awk -F= '/^min_recovery_buffer_min=/ {gsub(/ /,"",$2); print $2}' "$cfg")"
  min_ride="$(awk -F= '/^min_ridership_value=/ {gsub(/ /,"",$2); print $2}' "$cfg")"

  coverage="$(json_field coverage_rate "$report")"
  slack="$(json_field slack_ratio "$report")"
  prereq="$(json_field prereq_violations "$report")"
  inv="$(json_field queue_inversions "$report")"
  buf="$(json_field recovery_buffer_min "$report")"
  ride="$(json_field ridership_value "$report")"

  awk -v got="$coverage" -v need="$min_cov" 'BEGIN { exit (got + 0 >= need + 0) ? 0 : 1 }' || return 1
  awk -v got="$slack" -v need="$max_slack" 'BEGIN { exit (got + 0 <= need + 0) ? 0 : 1 }' || return 1
  awk -v got="$prereq" -v need="$max_prereq" 'BEGIN { exit (got + 0 <= need + 0) ? 0 : 1 }' || return 1
  awk -v got="$inv" -v need="$max_inv" 'BEGIN { exit (got + 0 <= need + 0) ? 0 : 1 }' || return 1
  awk -v got="$buf" -v need="$min_buf" 'BEGIN { exit (got + 0 >= need + 0) ? 0 : 1 }' || return 1
  awk -v got="$ride" -v need="$min_ride" 'BEGIN { exit (got + 0 >= need + 0) ? 0 : 1 }' || return 1

  grep -q '"trip_id"[[:space:]]*:[[:space:]]*"t_link_root"' "$report" || return 1
  grep -q '"trip_id"[[:space:]]*:[[:space:]]*"t_convoy_a"' "$report" || return 1
  grep -q '"trip_id"[[:space:]]*:[[:space:]]*"t_fail_rolling"' "$report" || return 1
  grep -q '"trip_id"[[:space:]]*:[[:space:]]*"t_bottle_us"' "$report" || return 1
  return 0
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/network.toml
require_file /app/data/trip_manifest.jsonl
require_file /app/data/station_profiles.csv
require_file /app/data/actual_dwell.csv
mkdir -p /app/bin /app/output

log "apply patched sources"
cp "${ROOT_DIR}/oracle/p2_order.go" /app/q9/p2_order.go
cp "${ROOT_DIR}/oracle/d4_hold.go" /app/k2/d4_hold.go
cp "${ROOT_DIR}/oracle/b7_slot.go" /app/h4/b7_slot.go
cp "${ROOT_DIR}/oracle/w5_roll.go" /app/z1/w5_roll.go
cp "${ROOT_DIR}/oracle/lib.rs" /app/n8/src/lib.rs

log "rebuild harmonizer"
bash /app/scripts/build.sh

log "refresh default trip bundle"
/app/bin/tripack /app/data/trip_manifest.jsonl /app/data/trips_default.jsonl

log "emit harmonize report"
/app/tools/run_harmonizer

log "validate default harmonize report"
validate_default_report /app/output/harmonize_report.json /app/config/network.toml

log "oracle complete"
