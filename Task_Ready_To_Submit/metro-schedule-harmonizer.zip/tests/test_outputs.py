"""Validate /app/output/harmonize_report.json against network.toml guardrails."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "harmonize_report.json"
REQUESTS = APP / "data" / "trips_default.jsonl"
CFG = APP / "config" / "network.toml"
USAGE_LOG = APP / "data" / "actual_dwell.csv"
CASES = Path(__file__).resolve().parent / "data"

_DEFAULT_REQUESTS_TEXT = REQUESTS.read_text(encoding="utf-8") if REQUESTS.is_file() else ""

REPORT_KEYS = frozenset(
    {
        "status",
        "headway_pool_min",
        "hours_assigned",
        "hours_slack",
        "trips_total",
        "trips_served",
        "coverage_rate",
        "slack_ratio",
        "prereq_violations",
        "queue_inversions",
        "recovery_buffer_min",
        "ridership_value",
        "report_digest",
        "trips",
    }
)
ROW_KEYS = frozenset(
    {
        "trip_id",
        "cluster",
        "urgency",
        "hours_reserved",
        "hours_served",
        "slack_hours",
        "served",
        "prereq_ready",
        "queue_rank",
        "convoy_wave",
        "ridership_value",
    }
)

_CAL_BLEND_NUM = 86
_CAL_BLEND_DEN = 100


def _calibration_bill_max(requests_text: str) -> int:
    raw = _request_map_from_text(requests_text)["t_bottle_us"]["act_hours"]
    return (raw * _CAL_BLEND_NUM) // _CAL_BLEND_DEN


def _assert_calibration_blend(report: dict, requests_text: str, *, require_status: bool) -> None:
    bill_max = _calibration_bill_max(requests_text)
    us = next(r for r in report["trips"] if r["trip_id"] == "t_bottle_us")
    eu = next(r for r in report["trips"] if r["trip_id"] == "t_bottle_eu")
    assert us["served"] and eu["served"]
    assert us["hours_reserved"] <= bill_max, us
    assert eu["hours_reserved"] <= bill_max, eu
    assert eu["hours_reserved"] < us["hours_reserved"], (us, eu)
    assert eu["hours_served"] < us["hours_served"], (us, eu)
    if require_status:
        assert report["status"] == "ok"


def _load_usage_logs() -> dict[str, int]:
    usage_logs: dict[str, int] = {}
    if not USAGE_LOG.is_file():
        return usage_logs
    lines = USAGE_LOG.read_text(encoding="utf-8").splitlines()
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        trip_id, act_hours = (part.strip() for part in line.split(",", 1))
        usage_logs[trip_id] = int(act_hours)
    return usage_logs


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "headway_pool_min": 12000,
        "min_coverage_rate": 0.75,
        "max_slack_ratio": 0.35,
        "max_prereq_violations": 0,
        "max_queue_inversions": 1,
        "min_recovery_buffer_min": 3,
        "min_ridership_value": 2.0,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in ("min_coverage_rate", "max_slack_ratio", "min_ridership_value"):
            cfg[key] = float(val)
        elif key in (
            "headway_pool_min",
            "max_prereq_violations",
            "max_queue_inversions",
            "min_recovery_buffer_min",
        ):
            cfg[key] = int(float(val))
    return cfg


def _request_rows_from_text(text: str) -> list[dict]:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def _trip_ids_from_text(text: str) -> list[str]:
    return [row["trip_id"] for row in _request_rows_from_text(text)]


def _request_map_from_text(text: str) -> dict[str, dict]:
    return {row["trip_id"]: row for row in _request_rows_from_text(text)}


def _assert_requests_match_input(report: dict, requests_text: str) -> None:
    expected_ids = _trip_ids_from_text(requests_text)
    report_ids = [row["trip_id"] for row in report["trips"]]
    assert report["trips_total"] == len(expected_ids)
    assert len(report_ids) == len(expected_ids)
    assert set(report_ids) == set(expected_ids)


def _reset_default_bundle() -> None:
    if _DEFAULT_REQUESTS_TEXT:
        _atomic_write_text(REQUESTS, _DEFAULT_REQUESTS_TEXT)
    _invoke_default()


@pytest.fixture(autouse=True)
def restore_default_requests() -> None:
    yield
    if _DEFAULT_REQUESTS_TEXT:
        _atomic_write_text(REQUESTS, _DEFAULT_REQUESTS_TEXT)
    _invoke_default()


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _swap_fixture(stem: str) -> str:
    src = CASES / f"{stem}.jsonl"
    text = src.read_text(encoding="utf-8")
    _atomic_write_text(REQUESTS, text)
    return text


def _expected_digest(report: dict) -> str:
    payload = dict(report)
    payload["report_digest"] = ""
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _invoke_default() -> None:
    proc = subprocess.run(
        ["/app/tools/run_harmonizer"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "harmonize_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    _invoke_default()


def test_report_schema() -> None:
    """Report and trip rows must match the documented schema."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS
    assert report["trips"]
    for row in report["trips"]:
        assert set(row.keys()) == ROW_KEYS
        assert isinstance(row["trip_id"], str) and row["trip_id"]
        assert isinstance(row["cluster"], str) and row["cluster"]
        assert isinstance(row["urgency"], int)
        assert row["hours_reserved"] >= 0
        assert row["hours_served"] >= 0
        assert row["slack_hours"] >= 0
        assert isinstance(row["served"], bool)
        assert isinstance(row["prereq_ready"], bool)
        assert row["queue_rank"] >= 1
        assert row["convoy_wave"] >= 0
        assert row["ridership_value"] >= 0.0


def test_passing_run_contract() -> None:
    """Default bundle must finish ok and meet network.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["headway_pool_min"] == cfg["headway_pool_min"]
    _assert_requests_match_input(report, _DEFAULT_REQUESTS_TEXT)
    assert report["trips_served"] > 0
    assert report["hours_assigned"] > 0
    assert report["hours_slack"] >= 0
    assert report["trips_served"] <= report["trips_total"]
    assert report["coverage_rate"] >= cfg["min_coverage_rate"]
    assert report["slack_ratio"] <= cfg["max_slack_ratio"]
    assert report["prereq_violations"] <= cfg["max_prereq_violations"]
    assert report["queue_inversions"] <= cfg["max_queue_inversions"]
    assert report["recovery_buffer_min"] >= cfg["min_recovery_buffer_min"]
    assert report["ridership_value"] >= cfg["min_ridership_value"]


def test_report_digest() -> None:
    """report_digest must be 64-character lowercase hex of the pre-digest payload."""
    report = _load_report()
    digest = report["report_digest"]
    assert digest == _expected_digest(report)
    assert len(digest) == 64
    assert digest == digest.lower()
    int(digest, 16)


def test_slack_hours_matches_reserved_minus_served() -> None:
    """slack_hours must equal hours_reserved minus hours_served when reserved is larger."""
    report = _load_report()
    for row in report["trips"]:
        if not row["served"]:
            continue
        expected = max(0, row["hours_reserved"] - row["hours_served"])
        assert row["slack_hours"] == expected, row


def test_deterministic_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_dep_chain_order() -> None:
    """Dependency chain rows must complete only after prerequisites."""
    requests_text = _swap_fixture("dep_chain")
    _invoke_default()
    report = _load_report()
    _assert_requests_match_input(report, requests_text)
    assert report["prereq_violations"] == 0
    assert report["status"] == "ok"
    ranks = {row["trip_id"]: row["queue_rank"] for row in report["trips"]}
    assert ranks["t_link_root"] < ranks["t_link_leaf"] < ranks["t_link_chain"]
    for row in report["trips"]:
        if row["trip_id"].startswith("t_link_") and row["served"]:
            assert row["prereq_ready"] is True, row


def test_urgency_flip_order() -> None:
    """Late priority revision rows must finish before stale low-revision peers."""
    cfg = _parse_cfg()
    requests_text = _swap_fixture("urgency_flip")
    _invoke_default()
    report = _load_report()
    _assert_requests_match_input(report, requests_text)
    hot = next(r for r in report["trips"] if r["trip_id"] == "t_delay_hot")
    cold = next(r for r in report["trips"] if r["trip_id"] == "t_delay_cold")
    assert hot["queue_rank"] < cold["queue_rank"]
    assert report["queue_inversions"] <= cfg["max_queue_inversions"]
    assert report["status"] == "ok"


def test_drift_accounting() -> None:
    """Drift rows reserve estimates, bill actuals, record slack, and show waste."""
    _reset_default_bundle()
    report = _load_report()
    inputs = _request_map_from_text(_DEFAULT_REQUESTS_TEXT)
    usage_logs = _load_usage_logs()
    drift_rows = [r for r in report["trips"] if r["trip_id"].startswith("t_slip_")]
    assert drift_rows
    for row in drift_rows:
        if not row["served"]:
            continue
        spec = inputs[row["trip_id"]]
        expected_used = usage_logs.get(row["trip_id"], spec["act_hours"])
        assert row["hours_reserved"] == spec["est_hours"]
        assert row["hours_served"] == expected_used
        assert row["slack_hours"] == max(0, row["hours_reserved"] - row["hours_served"])
    assert any(r["slack_hours"] > 0 for r in drift_rows if r["served"])


def test_equip_rows_finish_in_order() -> None:
    """Equipment-failure rows must complete only after rolling-stock prerequisites."""
    _reset_default_bundle()
    report = _load_report()
    ranks = {row["trip_id"]: row["queue_rank"] for row in report["trips"]}
    assert ranks["t_fail_rolling"] < ranks["t_fail_trailing"]
    for row in report["trips"]:
        if row["trip_id"].startswith("t_fail_") and row["served"]:
            assert row["prereq_ready"] is True, row


def test_convoy_rows_complete() -> None:
    """Convoy rows with the t_convoy_ prefix must complete under the default bundle."""
    _reset_default_bundle()
    report = _load_report()
    burst_rows = [r for r in report["trips"] if r["trip_id"].startswith("t_convoy_")]
    assert burst_rows
    assert all(r["served"] for r in burst_rows), burst_rows


def test_trip_rows_respect_intensity() -> None:
    """Station-bottleneck rows must bill through blended intensity, not raw estimates alone."""
    _reset_default_bundle()
    report = _load_report()
    bill_max = _calibration_bill_max(_DEFAULT_REQUESTS_TEXT)
    us = next(r for r in report["trips"] if r["trip_id"] == "t_bottle_us")
    eu = next(r for r in report["trips"] if r["trip_id"] == "t_bottle_eu")
    assert us["served"] and eu["served"]
    assert us["hours_reserved"] <= bill_max, us
    assert eu["hours_reserved"] <= bill_max, eu
    assert eu["hours_reserved"] < us["hours_reserved"], (us, eu)


def test_renew_late_row_completes() -> None:
    """Delayed recovery row t_recovery_late must complete under the default bundle."""
    _reset_default_bundle()
    report = _load_report()
    renew = next(r for r in report["trips"] if r["trip_id"] == "t_recovery_late")
    assert renew["served"] is True
    assert renew["convoy_wave"] > 0


def test_scenario_est_drift() -> None:
    """Estimate-drift scenario must keep slack_ratio under max_slack_ratio."""
    cfg = _parse_cfg()
    requests_text = _swap_fixture("est_drift")
    _invoke_default()
    report = _load_report()
    _assert_requests_match_input(report, requests_text)
    inputs = _request_map_from_text(requests_text)
    for row in report["trips"]:
        if not row["trip_id"].startswith("t_slip_") or not row["served"]:
            continue
        spec = inputs[row["trip_id"]]
        assert row["hours_reserved"] == spec["est_hours"]
        assert row["slack_hours"] == max(0, row["hours_reserved"] - row["hours_served"])
        assert row["slack_hours"] > 0
    assert report["slack_ratio"] <= cfg["max_slack_ratio"]
    assert report["status"] == "ok"


def test_scenario_convoy_cluster() -> None:
    """Convoy-cluster scenario must absorb enough recovery buffer headroom."""
    cfg = _parse_cfg()
    requests_text = _swap_fixture("burst_cluster")
    _invoke_default()
    report = _load_report()
    _assert_requests_match_input(report, requests_text)
    burst_rows = [r for r in report["trips"] if r["trip_id"].startswith("t_convoy_")]
    assert burst_rows
    assert all(r["served"] for r in burst_rows)
    assert report["recovery_buffer_min"] >= cfg["min_recovery_buffer_min"]
    assert report["status"] == "ok"


def test_scenario_value_mix() -> None:
    """Need-score mix scenario must meet ridership_value floor."""
    cfg = _parse_cfg()
    requests_text = _swap_fixture("value_mix")
    _invoke_default()
    report = _load_report()
    _assert_requests_match_input(report, requests_text)
    assert report["ridership_value"] >= cfg["min_ridership_value"]


def test_scenario_bottle_meter() -> None:
    """Zero-estimate dwell-log row must bill act_hours through the meter."""
    requests_text = _swap_fixture("cal_meter")
    _invoke_default()
    report = _load_report()
    _assert_requests_match_input(report, requests_text)
    usage_logs = _load_usage_logs()
    expected_used = usage_logs["t_bottle_meter"]
    row = next(r for r in report["trips"] if r["trip_id"] == "t_bottle_meter")
    assert row["served"] is True
    assert row["hours_served"] == expected_used
    assert row["hours_reserved"] == expected_used
    assert row["slack_hours"] == 0


def test_scenario_station_mix() -> None:
    """Station-zone variability scenario must bill eu-west below us-east for similar work."""
    requests_text = _swap_fixture("request_mix")
    _invoke_default()
    report = _load_report()
    _assert_requests_match_input(report, requests_text)
    _assert_calibration_blend(report, requests_text, require_status=False)


def test_scenario_renew_delay() -> None:
    """Delayed recovery scenario must complete t_recovery_late with buffer absorption."""
    cfg = _parse_cfg()
    requests_text = _swap_fixture("renew_delay")
    _invoke_default()
    report = _load_report()
    _assert_requests_match_input(report, requests_text)
    renew = next(r for r in report["trips"] if r["trip_id"] == "t_recovery_late")
    assert renew["served"] is True
    assert report["recovery_buffer_min"] >= cfg["min_recovery_buffer_min"]
    assert report["status"] == "ok"


def test_scenario_equip_failure() -> None:
    """Equipment-failure scenario must schedule rolling stock before trailing trips."""
    requests_text = _swap_fixture("equip_failure")
    _invoke_default()
    report = _load_report()
    _assert_requests_match_input(report, requests_text)
    assert report["prereq_violations"] == 0
    ranks = {row["trip_id"]: row["queue_rank"] for row in report["trips"]}
    assert ranks["t_fail_rolling"] < ranks["t_fail_trailing"]


def test_scenario_station_bottle() -> None:
    """Station-bottleneck scenario must bill hub below north for similar dwell work."""
    requests_text = _swap_fixture("station_bottle")
    _invoke_default()
    report = _load_report()
    _assert_requests_match_input(report, requests_text)
    hub = next(r for r in report["trips"] if r["trip_id"] == "t_bottle_hub")
    north = next(r for r in report["trips"] if r["trip_id"] == "t_bottle_north")
    assert hub["served"] and north["served"]
    assert north["hours_reserved"] < hub["hours_reserved"], (hub, north)
