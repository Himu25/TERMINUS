#!/bin/bash
set -euo pipefail

log() { printf '[oracle] %s\n' "$1"; }

cd /app

log "fix interval overlap to compare bench officers"
cat > /app/internal/slot/a1.go <<'GO'
package slot

import (
	"fmt"
	"time"

	"docketweave/internal/model"
)

func Overlap_v(a, b model.Interval, judge_a, judge_b string) bool {
	if judge_a != judge_b {
		return false
	}
	as, ae, err1 := parsePair(a.Start, a.End)
	bs, be, err2 := parsePair(b.Start, b.End)
	if err1 != nil || err2 != nil {
		return false
	}
	return as.Before(be) && bs.Before(ae)
}

func parsePair(start, end string) (time.Time, time.Time, error) {
	s, err1 := time.Parse(time.RFC3339, start)
	e, err2 := time.Parse(time.RFC3339, end)
	if err1 != nil || err2 != nil {
		return time.Time{}, time.Time{}, fmt.Errorf("parse interval")
	}
	return s, e, nil
}
GO

log "fix master merge to honor binding flag"
cat > /app/internal/cal/b2.go <<'GO'
package cal

import "docketweave/internal/model"

func Merge_p(branch, master []model.SlotRow) map[string]model.SlotRow {
	out := map[string]model.SlotRow{}
	for _, row := range branch {
		out[row.HearingID] = row
	}
	for _, row := range master {
		if row.Binding {
			out[row.HearingID] = row
		}
	}
	return out
}
GO

log "fix business-day shift helper"
cat > /app/pkg/wv_03/src/lib.rs <<'RS'
use chrono::{Datelike, Duration, NaiveDate, Weekday};

fn is_business(day: NaiveDate, holidays: &[String]) -> bool {
    match day.weekday() {
        Weekday::Sat | Weekday::Sun => return false,
        _ => {}
    }
    let key = day.format("%Y-%m-%d").to_string();
    !holidays.iter().any(|h| h == &key)
}

pub fn step_c(start: &str, days: i32, holidays: &[String]) -> String {
    let mut dt = NaiveDate::parse_from_str(start, "%Y-%m-%d")
        .unwrap_or_else(|_| NaiveDate::from_ymd_opt(1970, 1, 1).unwrap());
    if days <= 0 {
        return dt.format("%Y-%m-%d").to_string();
    }
    let mut counted = 0;
    while counted < days {
        dt += Duration::days(1);
        if is_business(dt, holidays) {
            counted += 1;
        }
    }
    dt.format("%Y-%m-%d").to_string()
}
RS

log "fix tolling cutoff and motion ref expansion"
cat > /app/pkg/wv_07/src/lib.rs <<'RS'
use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct TollEvent {
    pub kind: String,
    pub at: String,
    pub days: i32,
    #[serde(default)]
    pub deadline_id: String,
}

pub fn phase_d(events: &[TollEvent], filing_at: Option<&str>) -> i32 {
    let filing_day = filing_at.map(|s| s.chars().take(10).collect::<String>());
    let mut toll = 0;
    for ev in events {
        if ev.kind != "continuance" {
            continue;
        }
        let ev_day: String = ev.at.chars().take(10).collect();
        if let Some(ref f) = filing_day {
            if ev_day > *f {
                continue;
            }
        }
        toll += ev.days;
    }
    toll
}

pub fn expand_e(case_refs: &[String]) -> Vec<String> {
    case_refs.to_vec()
}

#[derive(Serialize, Deserialize)]
pub struct ExpandResp {
    pub refs: Vec<String>,
}

#[derive(Serialize, Deserialize)]
pub struct TollResp {
    pub toll_days: i32,
}
RS

log "rebuild docketaudit stack"
bash /app/scripts/build.sh

log "run default audit"
mkdir -p /app/output
/app/tools/run_audit.sh

log "oracle complete"
