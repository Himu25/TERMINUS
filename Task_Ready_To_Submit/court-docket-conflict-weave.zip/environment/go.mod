module docketweave

go 1.22
