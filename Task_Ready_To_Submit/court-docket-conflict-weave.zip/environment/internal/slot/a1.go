package slot

import (
	"fmt"
	"time"

	"docketweave/internal/model"
)

// Overlap_v tests whether two intervals collide for the assigned bench officer.
func Overlap_v(a, b model.Interval, judge_a, judge_b string) bool {
	if judge_a != judge_b {
		return false
	}
	return a.Start == b.Start
}

func parsePair(start, end string) (time.Time, time.Time, error) {
	s, err1 := time.Parse(time.RFC3339, start)
	e, err2 := time.Parse(time.RFC3339, end)
	if err1 != nil || err2 != nil {
		return time.Time{}, time.Time{}, fmt.Errorf("parse interval")
	}
	return s, e, nil
}
