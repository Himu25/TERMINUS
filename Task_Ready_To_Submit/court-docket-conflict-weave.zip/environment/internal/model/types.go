package model

type CasePack struct {
	CaseID           string            `json:"case_id"`
	Timezone         string            `json:"timezone"`
	CalendarID       string            `json:"calendar_id"`
	Hearings         []Hearing         `json:"hearings"`
	Continuances     []Continuance     `json:"continuances"`
	Motions          []Motion          `json:"motions"`
	RecusalBlocks    []RecusalBlock    `json:"recusal_blocks"`
	DeadlineRows     []DeadlineRow     `json:"deadline_rows"`
	TollEvents       []TollEvent       `json:"toll_events"`
	BranchSlots      []SlotRow         `json:"branch_slots"`
	MasterSlots      []SlotRow         `json:"master_slots"`
	PublishedFindings []PublishedFinding `json:"published_findings"`
}

type Hearing struct {
	ID      string `json:"id"`
	JudgeID string `json:"judge_id"`
	Start   string `json:"start"`
	End     string `json:"end"`
	Room    string `json:"room"`
}

type Continuance struct {
	FromHearing         string `json:"from_hearing"`
	ChildHearing        string `json:"child_hearing"`
	GrantDate           string `json:"grant_date"`
	OffsetBusinessDays  int    `json:"offset_business_days"`
}

type Motion struct {
	MotionID  string   `json:"motion_id"`
	JudgeID   string   `json:"judge_id"`
	CaseRefs  []string `json:"case_refs"`
}

type RecusalBlock struct {
	JudgeID   string `json:"judge_id"`
	MotionID  string `json:"motion_id"`
	Start     string `json:"start"`
	End       string `json:"end"`
}

type DeadlineRow struct {
	DeadlineID          string `json:"deadline_id"`
	AnchorHearing       string `json:"anchor_hearing"`
	OffsetBusinessDays  int    `json:"offset_business_days"`
	PublishedDue        string `json:"published_due"`
	PublishedMet        bool   `json:"published_met"`
}

type TollEvent struct {
	Kind       string `json:"kind"`
	At         string `json:"at"`
	Days       int    `json:"days"`
	DeadlineID string `json:"deadline_id,omitempty"`
}

type SlotRow struct {
	SlotID    string `json:"slot_id"`
	HearingID string `json:"hearing_id"`
	Start     string `json:"start"`
	End       string `json:"end"`
	Room      string `json:"room"`
	Binding   bool   `json:"binding,omitempty"`
}

type PublishedFinding struct {
	FindingID      string `json:"finding_id"`
	Kind           string `json:"kind"`
	HearingID      string `json:"hearing_id,omitempty"`
	DeadlineID     string `json:"deadline_id,omitempty"`
	PublishedClear bool   `json:"published_clear"`
	Severity       int    `json:"severity"`
}

type Interval struct {
	Start string
	End   string
}

type FindingOut struct {
	FindingID      string `json:"finding_id"`
	Kind           string `json:"kind"`
	HearingID      string `json:"hearing_id"`
	PublishedClear bool   `json:"published_clear"`
	ComputedClear  bool   `json:"computed_clear"`
	Severity       int    `json:"severity"`
}

type Report struct {
	CaseID            string       `json:"case_id"`
	ConflictsOk       bool         `json:"conflicts_ok"`
	MaxSeverity       int          `json:"max_severity"`
	HearingsProcessed int          `json:"hearings_processed"`
	Findings          []FindingOut `json:"findings"`
	AuditSeal         string       `json:"audit_seal"`
}
