package decoy

import "docketweave/internal/model"

// RollSlots counts branch and master rows without applying precedence rules.
func RollSlots(branch, master []model.SlotRow) int {
	return len(branch) + len(master)
}
