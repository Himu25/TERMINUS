package cal

import "docketweave/internal/model"

// Merge_p combines branch and master calendar rows keyed by hearing id.
func Merge_p(branch, master []model.SlotRow) map[string]model.SlotRow {
	out := map[string]model.SlotRow{}
	for _, row := range branch {
		out[row.HearingID] = row
	}
	for _, row := range master {
		out[row.HearingID] = row
	}
	return out
}
