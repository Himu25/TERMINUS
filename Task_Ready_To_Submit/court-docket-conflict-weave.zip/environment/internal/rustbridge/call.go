package rustbridge

import (
	"bytes"
	"encoding/json"
	"fmt"
	"os/exec"
)

func invoke_r(bin string, payload []byte) ([]byte, error) {
	cmd := exec.Command(bin)
	cmd.Stdin = bytes.NewReader(payload)
	out, err := cmd.Output()
	if err != nil {
		return nil, fmt.Errorf("invoke %s: %w", bin, err)
	}
	return out, nil
}

func ShiftDays(start string, days int, holidays []string) (string, error) {
	req := map[string]any{
		"start":    start,
		"days":     days,
		"holidays": holidays,
	}
	raw, _ := json.Marshal(req)
	out, err := invoke_r("/app/bin/wv03_shift", raw)
	if err != nil {
		return "", err
	}
	var resp struct {
		End string `json:"end"`
	}
	if err := json.Unmarshal(out, &resp); err != nil {
		return "", err
	}
	return resp.End, nil
}

func TollDays(events []map[string]any, filingAt string) (int, error) {
	req := map[string]any{
		"op":        "toll",
		"events":    events,
		"filing_at": filingAt,
	}
	raw, _ := json.Marshal(req)
	out, err := invoke_r("/app/bin/wv07_core", raw)
	if err != nil {
		return 0, err
	}
	var resp struct {
		TollDays int `json:"toll_days"`
	}
	if err := json.Unmarshal(out, &resp); err != nil {
		return 0, err
	}
	return resp.TollDays, nil
}

func ExpandRefs(refs []string) ([]string, error) {
	req := map[string]any{
		"op":        "expand",
		"case_refs": refs,
	}
	raw, _ := json.Marshal(req)
	out, err := invoke_r("/app/bin/wv07_core", raw)
	if err != nil {
		return nil, err
	}
	var resp struct {
		Refs []string `json:"refs"`
	}
	if err := json.Unmarshal(out, &resp); err != nil {
		return nil, err
	}
	return resp.Refs, nil
}
