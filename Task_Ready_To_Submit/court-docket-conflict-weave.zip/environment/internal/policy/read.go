package policy

import (
	"os"
	"strings"
)

type CourtCfg struct {
	CasePath   string
	OutputPath string
}

func ReadCourt(path string) CourtCfg {
	cfg := CourtCfg{
		CasePath:   "/app/cases/default.json",
		OutputPath: "/app/output/docket_audit.json",
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		return cfg
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "case_path":
			cfg.CasePath = val
		case "output_path":
			cfg.OutputPath = val
		}
	}
	return cfg
}
