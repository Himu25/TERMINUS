package engine

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"sort"
	"time"

	"docketweave/internal/cal"
	"docketweave/internal/io"
	"docketweave/internal/model"
	"docketweave/internal/rustbridge"
	"docketweave/internal/slot"
)

type holidayFile struct {
	Holidays []string `json:"holidays"`
}

func RunAudit(casePath string) (*model.Report, error) {
	var pack model.CasePack
	if err := io.ReadJSON(casePath, &pack); err != nil {
		return nil, err
	}
	holidays, err := loadHolidays(pack.CalendarID)
	if err != nil {
		return nil, err
	}

	hearingByID := map[string]model.Hearing{}
	for _, h := range pack.Hearings {
		hearingByID[h.ID] = h
	}

	effective := cal.Merge_p(pack.BranchSlots, pack.MasterSlots)
	findings := make([]model.FindingOut, 0, len(pack.PublishedFindings))
	maxSev := 0
	allOk := true

	for _, pub := range pack.PublishedFindings {
		computed, err := computeClear(pub, pack, hearingByID, effective, holidays)
		if err != nil {
			return nil, err
		}
		sev := pub.Severity
		if computed != pub.PublishedClear {
			allOk = false
			if sev > maxSev {
				maxSev = sev
			}
		}
		row := model.FindingOut{
			FindingID:      pub.FindingID,
			Kind:           pub.Kind,
			HearingID:      pub.HearingID,
			PublishedClear: pub.PublishedClear,
			ComputedClear:  computed,
			Severity:       sev,
		}
		findings = append(findings, row)
	}

	report := &model.Report{
		CaseID:            pack.CaseID,
		ConflictsOk:       allOk,
		MaxSeverity:       maxSev,
		HearingsProcessed: len(pack.Hearings),
		Findings:          findings,
	}
	report.AuditSeal = seal(report)
	return report, nil
}

func computeClear(
	pub model.PublishedFinding,
	pack model.CasePack,
	hearingByID map[string]model.Hearing,
	effective map[string]model.SlotRow,
	holidays []string,
) (bool, error) {
	switch pub.Kind {
	case "double_book":
		return !hasDoubleBook(pub.HearingID, pack.Hearings), nil
	case "recusal_hit":
		return !hasRecusalHit(pub.HearingID, pack), nil
	case "orphan_deadline":
		return deadlineClear(pub.DeadlineID, pack, holidays)
	case "calendar_drift":
		return !hasCalendarDrift(pub.HearingID, pack, effective), nil
	default:
		return false, fmt.Errorf("unknown kind %s", pub.Kind)
	}
}

func hasDoubleBook(target string, hearings []model.Hearing) bool {
	var focus model.Hearing
	for _, h := range hearings {
		if h.ID == target {
			focus = h
			break
		}
	}
	if focus.ID == "" {
		return false
	}
	ivFocus := model.Interval{Start: focus.Start, End: focus.End}
	for _, other := range hearings {
		if other.ID == focus.ID {
			continue
		}
		ivOther := model.Interval{Start: other.Start, End: other.End}
		if slot.Overlap_v(ivFocus, ivOther, focus.JudgeID, other.JudgeID) {
			return true
		}
	}
	return false
}

func hasRecusalHit(target string, pack model.CasePack) bool {
	h, ok := findHearing(pack.Hearings, target)
	if !ok {
		return false
	}
	start, end, err := parseRFC(h.Start, h.End)
	if err != nil {
		return false
	}
	for _, block := range pack.RecusalBlocks {
		if block.JudgeID != h.JudgeID {
			continue
		}
		bs, be, err := parseRFC(block.Start, block.End)
		if err != nil {
			continue
		}
		if !intervalOverlap(start, end, bs, be) {
			continue
		}
		motion := findMotion(pack.Motions, block.MotionID)
		if motion.MotionID == "" {
			continue
		}
		refs, err := rustbridge.ExpandRefs(motion.CaseRefs)
		if err != nil {
			continue
		}
		for _, ref := range refs {
			if ref == pack.CaseID {
				return true
			}
		}
	}
	return false
}

func deadlineClear(deadlineID string, pack model.CasePack, holidays []string) (bool, error) {
	row := findDeadline(pack.DeadlineRows, deadlineID)
	if row.DeadlineID == "" {
		return false, fmt.Errorf("missing deadline %s", deadlineID)
	}
	anchor := findHearingByID(pack.Hearings, row.AnchorHearing)
	if anchor.ID == "" {
		return false, fmt.Errorf("missing anchor hearing")
	}
	anchorDay := anchor.Start[:10]
	baseDue, err := rustbridge.ShiftDays(anchorDay, row.OffsetBusinessDays, holidays)
	if err != nil {
		return false, err
	}
	tollEvents := make([]map[string]any, 0, len(pack.TollEvents))
	for _, ev := range pack.TollEvents {
		if ev.DeadlineID != "" && ev.DeadlineID != deadlineID {
			continue
		}
		tollEvents = append(tollEvents, map[string]any{
			"kind": ev.Kind,
			"at":   ev.At,
			"days": ev.Days,
		})
	}
	filingAt := ""
	for _, ev := range pack.TollEvents {
		if ev.Kind == "filing" && (ev.DeadlineID == deadlineID || ev.DeadlineID == "") {
			filingAt = ev.At
			break
		}
	}
	toll, err := rustbridge.TollDays(tollEvents, filingAt)
	if err != nil {
		return false, err
	}
	finalDue, err := rustbridge.ShiftDays(baseDue, toll, holidays)
	if err != nil {
		return false, err
	}
	if finalDue != row.PublishedDue {
		return false, nil
	}
	for _, cont := range pack.Continuances {
		child := findHearingByID(pack.Hearings, cont.ChildHearing)
		if child.ID == "" {
			continue
		}
		expected, err := rustbridge.ShiftDays(cont.GrantDate, cont.OffsetBusinessDays, holidays)
		if err != nil {
			return false, err
		}
		if child.Start[:10] != expected {
			return false, nil
		}
	}
	return row.PublishedMet, nil
}

func hasCalendarDrift(target string, pack model.CasePack, effective map[string]model.SlotRow) bool {
	h := findHearingByID(pack.Hearings, target)
	if h.ID == "" {
		return false
	}
	slotRow, ok := effective[target]
	if !ok {
		return false
	}
	return slotRow.Room != h.Room
}

func loadHolidays(calendarID string) ([]string, error) {
	path := fmt.Sprintf("/app/registry/holiday_%s.json", calendarID)
	var hf holidayFile
	if err := io.ReadJSON(path, &hf); err != nil {
		return nil, err
	}
	return hf.Holidays, nil
}

func findHearing(list []model.Hearing, id string) (model.Hearing, bool) {
	for _, h := range list {
		if h.ID == id {
			return h, true
		}
	}
	return model.Hearing{}, false
}

func findHearingByID(list []model.Hearing, id string) model.Hearing {
	h, _ := findHearing(list, id)
	return h
}

func findMotion(list []model.Motion, id string) model.Motion {
	for _, m := range list {
		if m.MotionID == id {
			return m
		}
	}
	return model.Motion{}
}

func findDeadline(list []model.DeadlineRow, id string) model.DeadlineRow {
	for _, d := range list {
		if d.DeadlineID == id {
			return d
		}
	}
	return model.DeadlineRow{}
}

func parseRFC(start, end string) (time.Time, time.Time, error) {
	s, err1 := time.Parse(time.RFC3339, start)
	e, err2 := time.Parse(time.RFC3339, end)
	if err1 != nil || err2 != nil {
		return time.Time{}, time.Time{}, fmt.Errorf("parse")
	}
	return s, e, nil
}

func intervalOverlap(aStart, aEnd, bStart, bEnd time.Time) bool {
	return aStart.Before(bEnd) && bStart.Before(aEnd)
}

func seal(report *model.Report) string {
	clone := *report
	clone.AuditSeal = ""
	payload, err := canonicalJSON(clone)
	if err != nil {
		payload, _ = json.Marshal(clone)
	}
	sum := sha256.Sum256(payload)
	return hex.EncodeToString(sum[:4])
}

func canonicalJSON(v any) ([]byte, error) {
	raw, err := json.Marshal(v)
	if err != nil {
		return nil, err
	}
	var decoded any
	if err := json.Unmarshal(raw, &decoded); err != nil {
		return nil, err
	}
	var buf bytes.Buffer
	if err := writeCanonical(&buf, decoded); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

func writeCanonical(buf *bytes.Buffer, v any) error {
	switch x := v.(type) {
	case map[string]any:
		buf.WriteByte('{')
		keys := make([]string, 0, len(x))
		for k := range x {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		for i, k := range keys {
			if i > 0 {
				buf.WriteByte(',')
			}
			keyBytes, _ := json.Marshal(k)
			buf.Write(keyBytes)
			buf.WriteByte(':')
			if err := writeCanonical(buf, x[k]); err != nil {
				return err
			}
		}
		buf.WriteByte('}')
	case []any:
		buf.WriteByte('[')
		for i, elem := range x {
			if i > 0 {
				buf.WriteByte(',')
			}
			if err := writeCanonical(buf, elem); err != nil {
				return err
			}
		}
		buf.WriteByte(']')
	default:
		b, err := json.Marshal(x)
		if err != nil {
			return err
		}
		buf.Write(b)
	}
	return nil
}

func WriteReport(path string, report *model.Report) error {
	payload, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, append(payload, '\n'), 0o644)
}
