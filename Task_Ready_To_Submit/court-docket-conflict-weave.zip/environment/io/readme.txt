import staging area
