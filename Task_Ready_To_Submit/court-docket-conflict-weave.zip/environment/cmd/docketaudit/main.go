package main

import (
	"flag"
	"fmt"
	"os"

	"docketweave/internal/engine"
	"docketweave/internal/policy"
)

func main() {
	casePath := flag.String("case", "/app/cases/default.json", "case pack json")
	outPath := flag.String("out", "/app/output/docket_audit.json", "audit output")
	cfgPath := flag.String("config", "/app/config/court.toml", "court config")
	flag.Parse()

	cfg := policy.ReadCourt(*cfgPath)
	if *casePath == "/app/cases/default.json" && cfg.CasePath != "" {
		*casePath = cfg.CasePath
	}
	if *outPath == "/app/output/docket_audit.json" && cfg.OutputPath != "" {
		*outPath = cfg.OutputPath
	}

	report, err := engine.RunAudit(*casePath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "docketaudit: %v\n", err)
		os.Exit(1)
	}
	if err := engine.WriteReport(*outPath, report); err != nil {
		fmt.Fprintf(os.Stderr, "docketaudit: %v\n", err)
		os.Exit(1)
	}
}
