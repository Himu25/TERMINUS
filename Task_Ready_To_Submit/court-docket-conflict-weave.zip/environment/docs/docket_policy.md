# Docket audit policy

## Interval overlap
Two events for the same bench officer overlap when their half-open intervals `[start, end)` intersect. Room identity does not suppress bench-level overlap.

## Branch vs master rows
Each event may appear on a branch calendar row and a master calendar row. Master rows replace branch rows only when `binding` is true. Non-binding master rows are advisory.

## Continuance offsets
A granted continuance moves the child event by counting business days on the court holiday table, skipping weekends and listed holidays.

## Recusal blocks
When an officer ruled on a prior motion, the recusal window applies to every case listed on that motion, not only the lead case.

## Statutory answer dates
Answer due dates start from the anchor event using business-day offsets on the holiday table. Tolling adds business days from continuance events until a filing timestamp; scheduling events after filing do not extend tolling.
