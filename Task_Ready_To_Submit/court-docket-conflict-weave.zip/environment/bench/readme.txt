bench harness placeholder
