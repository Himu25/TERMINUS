#!/bin/bash
set -euo pipefail
cd /app
export CARGO_TARGET_DIR=/app/output/cargo-target
cargo build --release --locked -p wv_03 -p wv_07
install -d -m 0755 /app/bin
cp /app/output/cargo-target/release/wv03_shift /app/bin/wv03_shift
cp /app/output/cargo-target/release/wv07_core /app/bin/wv07_core
go build -o /app/bin/docketaudit ./cmd/docketaudit
