use serde::{Deserialize, Serialize};
use wv_03::step_c;

#[derive(Deserialize)]
struct ShiftReq {
    start: String,
    days: i32,
    holidays: Vec<String>,
}

#[derive(Serialize)]
struct ShiftResp {
    end: String,
}

fn main() {
    let raw = std::io::read_to_string(std::io::stdin()).unwrap_or_default();
    let req: ShiftReq = serde_json::from_str(&raw).unwrap_or(ShiftReq {
        start: "1970-01-01".into(),
        days: 0,
        holidays: vec![],
    });
    let end = step_c(&req.start, req.days, &req.holidays);
    let resp = ShiftResp { end };
    println!("{}", serde_json::to_string(&resp).unwrap());
}
