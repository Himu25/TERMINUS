use chrono::{Duration, NaiveDate};

pub fn step_c(start: &str, days: i32, _holidays: &[String]) -> String {
    let dt = NaiveDate::parse_from_str(start, "%Y-%m-%d").unwrap_or_else(|_| NaiveDate::from_ymd_opt(1970, 1, 1).unwrap());
    (dt + Duration::days(days as i64))
        .format("%Y-%m-%d")
        .to_string()
}
