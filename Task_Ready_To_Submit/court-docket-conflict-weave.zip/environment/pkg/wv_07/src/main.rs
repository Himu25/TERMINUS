use serde::{Deserialize, Serialize};
use wv_07::{expand_e, phase_d, ExpandResp, TollEvent, TollResp};

#[derive(Deserialize)]
struct TollReq {
    events: Vec<TollEvent>,
    filing_at: Option<String>,
}

#[derive(Deserialize)]
struct ExpandReq {
    case_refs: Vec<String>,
}

#[derive(Deserialize)]
struct Op {
    op: String,
}

fn main() {
    let raw = std::io::read_to_string(std::io::stdin()).unwrap_or_default();
    let head: Op = serde_json::from_str(&raw).unwrap_or(Op { op: String::new() });
    match head.op.as_str() {
        "toll" => {
            let req: TollReq = serde_json::from_str(&raw).unwrap_or(TollReq {
                events: vec![],
                filing_at: None,
            });
            let filing = req.filing_at.as_deref();
            let toll_days = phase_d(&req.events, filing);
            println!("{}", serde_json::to_string(&TollResp { toll_days }).unwrap());
        }
        "expand" => {
            let req: ExpandReq = serde_json::from_str(&raw).unwrap_or(ExpandReq {
                case_refs: vec![],
            });
            let refs = expand_e(&req.case_refs);
            println!("{}", serde_json::to_string(&ExpandResp { refs }).unwrap());
        }
        _ => {
            println!("{}", serde_json::to_string(&TollResp { toll_days: 0 }).unwrap());
        }
    }
}
