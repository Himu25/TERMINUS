use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct TollEvent {
    pub kind: String,
    pub at: String,
    pub days: i32,
    #[serde(default)]
    pub deadline_id: String,
}

pub fn phase_d(events: &[TollEvent], _filing_at: Option<&str>) -> i32 {
    let mut toll = 0;
    for ev in events {
        if ev.kind == "continuance" || ev.kind == "scheduling" {
            toll += ev.days;
        }
    }
    toll
}

pub fn expand_e(case_refs: &[String]) -> Vec<String> {
    if case_refs.is_empty() {
        return vec![];
    }
    vec![case_refs[0].clone()]
}

#[derive(Serialize, Deserialize)]
pub struct ExpandResp {
    pub refs: Vec<String>,
}

#[derive(Serialize, Deserialize)]
pub struct TollResp {
    pub toll_days: i32,
}
