"""Reference seal helper for docket audit checks."""

import hashlib
import json
import sys


def seal_hex(report: dict) -> str:
    clone = dict(report)
    clone["audit_seal"] = ""
    payload = json.dumps(clone, separators=(",", ":"), sort_keys=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:8]


if __name__ == "__main__":
    report = json.loads(sys.stdin.read())
    print(seal_hex(report))
