#!/bin/bash
set -euo pipefail
exec /app/bin/docketaudit \
  --case "${1:-/app/cases/default.json}" \
  --out /app/output/docket_audit.json
