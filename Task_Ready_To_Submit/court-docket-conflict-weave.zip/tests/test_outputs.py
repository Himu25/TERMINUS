"""Verifier for court-docket-conflict-weave."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "docket_audit.json"
AUDIT = Path("/app/bin/docketaudit")
FIXTURES = Path("/tests/fixtures")
SCENARIO_INDEX = APP / "docs" / "scenario_index.txt"
SEAL_REF = Path("/app/tools/seal_ref.py")

REPORT_KEYS = frozenset(
    {
        "case_id",
        "conflicts_ok",
        "max_severity",
        "hearings_processed",
        "findings",
        "audit_seal",
    }
)
FINDING_KEYS = frozenset(
    {
        "finding_id",
        "kind",
        "hearing_id",
        "published_clear",
        "computed_clear",
        "severity",
    }
)


def _run_audit(case: Path) -> None:
    subprocess.run(
        [
            str(AUDIT),
            "--case",
            str(case),
            "--out",
            str(OUT),
        ],
        check=True,
    )


def _load_report() -> dict:
    return json.loads(OUT.read_text(encoding="utf-8"))


def _expected_seal(report: dict) -> str:
    payload = json.dumps(report, separators=(",", ":"), sort_keys=True)
    proc = subprocess.run(
        [sys.executable, str(SEAL_REF)],
        input=payload,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.strip()


def _load_case(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


@pytest.fixture(scope="module")
def default_case() -> dict:
    return _load_case(APP / "cases" / "default.json")


@pytest.fixture(scope="module")
def default_report(default_case: dict) -> dict:
    _run_audit(APP / "cases" / "default.json")
    return _load_report()


def test_default_conflicts_ok(default_report: dict) -> None:
    """Default case pack must reconcile with zero finding gaps."""
    assert default_report["conflicts_ok"] is True


def test_default_case_id(default_report: dict, default_case: dict) -> None:
    """Report case_id must match the bundled default pack."""
    assert default_report["case_id"] == default_case["case_id"]


def test_hearings_processed_count(default_report: dict, default_case: dict) -> None:
    """hearings_processed must equal events in the default pack."""
    assert default_report["hearings_processed"] == len(default_case["hearings"])


def test_report_top_level_schema(default_report: dict) -> None:
    """Audit JSON must expose the contract top-level fields."""
    assert set(default_report.keys()) == REPORT_KEYS


def test_finding_row_schema(default_report: dict) -> None:
    """Each finding row must carry published and computed clearance fields."""
    for row in default_report["findings"]:
        assert set(row.keys()) == FINDING_KEYS


def test_audit_seal_hex(default_report: dict) -> None:
    """audit_seal must be eight lowercase hex digits."""
    seal = default_report["audit_seal"]
    assert len(seal) == 8
    assert seal == seal.lower()
    int(seal, 16)


def test_audit_seal_matches_payload(default_report: dict) -> None:
    """audit_seal must seal the payload with audit_seal blanked."""
    assert default_report["audit_seal"] == _expected_seal(default_report)


def test_default_findings_match_published(default_report: dict, default_case: dict) -> None:
    """Every default finding must match its published clearance bit."""
    pub_by_id = {row["finding_id"]: row for row in default_case["published_findings"]}
    for row in default_report["findings"]:
        pub = pub_by_id[row["finding_id"]]
        assert row["published_clear"] == pub["published_clear"]
        assert row["computed_clear"] == pub["published_clear"]


def test_repeat_run_byte_identical() -> None:
    """Two consecutive default audits must produce identical output bytes."""
    _run_audit(APP / "cases" / "default.json")
    first = OUT.read_bytes()
    _run_audit(APP / "cases" / "default.json")
    second = OUT.read_bytes()
    assert first == second


@pytest.mark.parametrize(
    "stem",
    [
        "nd_continuance_edge",
        "nd_recusal_motion",
        "nd_master_nonbind",
        "nd_toll_filing",
    ],
)
def test_indexed_scenario_stem(stem: str) -> None:
    """Each scenario stem listed for grading must reconcile cleanly."""
    index_text = SCENARIO_INDEX.read_text(encoding="utf-8")
    assert stem in index_text
    case_path = FIXTURES / stem / "case.json"
    assert case_path.is_file()
    _run_audit(case_path)
    report = _load_report()
    assert report["conflicts_ok"] is True


def test_clearance_gap_severity(default_report: dict) -> None:
    """Mismatched clearance must carry the published severity on that finding."""
    for row in default_report["findings"]:
        if row["published_clear"] != row["computed_clear"]:
            assert row["severity"] > 0
