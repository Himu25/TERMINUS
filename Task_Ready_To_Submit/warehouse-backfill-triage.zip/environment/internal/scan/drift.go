package scan

import (
	"lab.local/wh_backfill_triage/internal/config"
	"lab.local/wh_backfill_triage/tagfold"
)

// DriftRows counts row-level tag failures in one slice record.
func DriftRows(rec config.SliceRecord) uint32 {
	return uint32(tagfold.BadRows(rec.Rows))
}
