package walk

import (
	"lab.local/wh_backfill_triage/pkg/depwalk"
	"lab.local/wh_backfill_triage/pkg/partpkg"
)

// Downstream returns expanded keys and view-layer hop count.
func Downstream(direct, view []depwalk.Edge, start partpkg.Key) ([]partpkg.Key, uint32) {
	return depwalk.OpL(direct, view, start)
}
