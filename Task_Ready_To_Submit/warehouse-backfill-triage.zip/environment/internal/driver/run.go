package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"

	"lab.local/wh_backfill_triage/internal/config"
	"lab.local/wh_backfill_triage/internal/engine"
)

// Report is the outward JSON document.
type Report struct {
	SchemaVersion string `json:"schema_version"`
	WarehouseID   string `json:"warehouse_id"`
	SeedCount     uint32 `json:"seed_count"`
	ScopeCount    uint32 `json:"scope_count"`
	RefreshCount  uint32 `json:"refresh_count"`
	SkipCount     uint32 `json:"skip_count"`
	ViewDeps      uint32 `json:"view_deps"`
	PartialHits   uint32 `json:"partial_hits"`
	LateHits      uint32 `json:"late_hits"`
	ScopeDigest   string `json:"scope_digest"`
}

// RunActive loads the active plan and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	plan, slices, err := config.LoadPlan(dir)
	if err != nil {
		return Report{}, err
	}
	return buildReport(plan, slices)
}

func buildReport(plan config.Plan, slices map[string]config.SliceRecord) (Report, error) {
	out := engine.Plan(plan, slices)
	digest := sha256.Sum256([]byte(fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%d|%d",
		plan.WarehouseID,
		out.SeedCount,
		out.ScopeCount,
		out.RefreshCount,
		out.SkipCount,
		out.ViewDeps,
		out.PartialHits,
		out.LateHits,
	)))
	return Report{
		SchemaVersion: "1",
		WarehouseID:   plan.WarehouseID,
		SeedCount:     out.SeedCount,
		ScopeCount:    out.ScopeCount,
		RefreshCount:  out.RefreshCount,
		SkipCount:     out.SkipCount,
		ViewDeps:      out.ViewDeps,
		PartialHits:   out.PartialHits,
		LateHits:      out.LateHits,
		ScopeDigest:   hex.EncodeToString(digest[:]),
	}, nil
}

// EmitReport writes the JSON report.
func EmitReport(path string, rep Report) error {
	if err := os.MkdirAll("/app/output", 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, append(raw, '\n'), 0o644)
}
