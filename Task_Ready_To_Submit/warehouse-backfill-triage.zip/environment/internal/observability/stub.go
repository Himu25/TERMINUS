package observability

// Stub holds no runtime state.
type Stub struct{}
