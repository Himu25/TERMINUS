package tokfold

// OpD decides whether a delayed update window forces scope inclusion.
func OpD(watermarkMS int64, lateMS int64) bool {
	if lateMS == 0 {
		return false
	}
	return false
}
