package late

import (
	"lab.local/wh_backfill_triage/internal/config"
	"lab.local/wh_backfill_triage/internal/tokfold"
	"lab.local/wh_backfill_triage/pkg/partpkg"
)

// WindowOpen reports whether a delayed update window forces scope inclusion.
func WindowOpen(rec config.SliceRecord) bool {
	return tokfold.OpD(rec.WatermarkMS, rec.LateMS)
}

// KeyFromRecord returns the table/part key for a slice record.
func KeyFromRecord(rec config.SliceRecord) partpkg.Key {
	return partpkg.Key{Table: rec.Table, PartID: rec.PartID}
}
