package engine

import (
	"lab.local/wh_backfill_triage/internal/config"
	"lab.local/wh_backfill_triage/internal/late"
	"lab.local/wh_backfill_triage/internal/scan"
	"lab.local/wh_backfill_triage/internal/stale"
	"lab.local/wh_backfill_triage/internal/walk"
	"lab.local/wh_backfill_triage/pkg/partpkg"
)

type Outcome struct {
	SeedCount    uint32
	ScopeCount   uint32
	RefreshCount uint32
	SkipCount    uint32
	ViewDeps     uint32
	PartialHits  uint32
	LateHits     uint32
}

func Plan(plan config.Plan, slices map[string]config.SliceRecord) Outcome {
	scope := map[string]bool{}
	var partialHits uint32
	var lateHits uint32
	var viewDeps uint32
	var seedCount uint32

	expandFrom := func(start partpkg.Key) {
		down, hops := walk.Downstream(plan.DirectEdges, plan.ViewEdges, start)
		viewDeps += hops
		for _, dk := range down {
			scope[dk.String()] = true
		}
	}

	for key, rec := range slices {
		bad := scan.DriftRows(rec)
		partialHits += bad
		if bad > 0 {
			scope[key] = true
		}
		if late.WindowOpen(rec) {
			scope[key] = true
			lateHits++
			expandFrom(late.KeyFromRecord(rec))
		}
		if stale.NeedsRebuild(rec) {
			scope[key] = true
		}
	}

	for _, seed := range plan.SeedParts {
		sk := partpkg.Key{Table: seed.Table, PartID: seed.PartID}
		rec, ok := slices[sk.String()]
		if !ok {
			continue
		}
		if scan.DriftRows(rec) == 0 {
			continue
		}
		seedCount++
		scope[sk.String()] = true
		expandFrom(sk)
	}

	refresh := map[string]bool{}
	for key, rec := range slices {
		if stale.IsRefreshOnly(rec, scope[key]) {
			refresh[key] = true
		}
	}

	var scopeCount uint32
	for range scope {
		scopeCount++
	}
	var refreshCount uint32
	for range refresh {
		refreshCount++
	}
	skipCount := uint32(len(slices)) - scopeCount - refreshCount

	return Outcome{
		SeedCount:    seedCount,
		ScopeCount:   scopeCount,
		RefreshCount: refreshCount,
		SkipCount:    skipCount,
		ViewDeps:     viewDeps,
		PartialHits:  partialHits,
		LateHits:     lateHits,
	}
}
