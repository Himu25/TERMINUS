package stale

import (
	"lab.local/wh_backfill_triage/internal/config"
	"lab.local/wh_backfill_triage/pkg/clockfold"
	"lab.local/wh_backfill_triage/pkg/frame"
)

func rowsValid(rows []frame.Row) bool {
	for _, r := range rows {
		if frame.WireCRC(r.Seq, r.Payload) != r.Tag {
			return false
		}
	}
	return true
}

// NeedsRebuild reports whether a slice should enter full rebuild scope when stale.
func NeedsRebuild(rec config.SliceRecord) bool {
	return clockfold.OpW(rec.WatermarkMS, rec.UpstreamWMMS, rowsValid(rec.Rows))
}

// IsRefreshOnly reports valid rows with watermark behind upstream outside rebuild scope.
func IsRefreshOnly(rec config.SliceRecord, inScope bool) bool {
	if inScope {
		return false
	}
	return rowsValid(rec.Rows) && rec.UpstreamWMMS > rec.WatermarkMS
}
