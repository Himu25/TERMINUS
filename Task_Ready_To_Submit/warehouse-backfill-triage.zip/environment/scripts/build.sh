#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1

mkdir -p /app/bin
cd /app/tagfold
CARGO_TARGET_DIR=/app/tagfold/target cargo build --release --locked 2>/dev/null \
  || CARGO_TARGET_DIR=/app/tagfold/target cargo build --release
cd /app
GOFLAGS=-mod=mod go build -trimpath -buildvcs=false -o /app/bin/wh_triage ./cmd/wh_triage
