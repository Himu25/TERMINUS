#!/bin/bash
set -euo pipefail
cd /app && bash /app/scripts/build.sh && TB_WH_FIXTURE=1 /app/bin/wh_triage
