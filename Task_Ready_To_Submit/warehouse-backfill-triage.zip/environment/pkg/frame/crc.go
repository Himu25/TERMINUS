package frame

// WireCRC folds row sequence and payload into a 16-bit integrity tag.
func WireCRC(seq uint32, payload string) uint16 {
	s := uint32(0)
	for _, b := range []byte(payload) {
		s += uint32(b)
	}
	s ^= seq
	return uint16(s & 0xFFFF)
}
