package depwalk

import (
	"testing"

	"lab.local/wh_backfill_triage/pkg/partpkg"
)

func TestOpLIncludesViewHop(t *testing.T) {
	direct := []Edge{{From: "a", To: "b"}}
	view := []Edge{{From: "b", To: "c"}}
	got, hops := OpL(direct, view, partpkg.Key{Table: "a", PartID: "p1"})
	if hops != 1 {
		t.Fatalf("expected one view hop, got %d", hops)
	}
	if len(got) != 2 {
		t.Fatalf("expected two downstream tables, got %+v", got)
	}
}
