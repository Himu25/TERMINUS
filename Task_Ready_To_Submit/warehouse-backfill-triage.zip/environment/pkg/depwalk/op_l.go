package depwalk

import "lab.local/wh_backfill_triage/pkg/partpkg"

type Edge struct {
	From string `json:"from"`
	To   string `json:"to"`
}

func OpL(direct []Edge, _ []Edge, start partpkg.Key) ([]partpkg.Key, uint32) {
	adj := map[string][]string{}
	for _, e := range direct {
		adj[e.From] = append(adj[e.From], e.To)
	}
	seen := map[string]bool{start.Table: true}
	var out []partpkg.Key
	queue := []string{start.Table}
	for len(queue) > 0 {
		cur := queue[0]
		queue = queue[1:]
		for _, nxt := range adj[cur] {
			if seen[nxt] {
				continue
			}
			seen[nxt] = true
			out = append(out, partpkg.Key{Table: nxt, PartID: start.PartID})
			queue = append(queue, nxt)
		}
	}
	return out, 0
}
