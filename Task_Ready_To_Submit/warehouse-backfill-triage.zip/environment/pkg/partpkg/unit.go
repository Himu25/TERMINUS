package partpkg

// Key identifies a table slice.
type Key struct {
	Table  string
	PartID string
}

func (k Key) String() string {
	return k.Table + "/" + k.PartID
}
