# Warehouse triage stack

Go driver under `cmd/wh_triage` coordinates slice scans, dependency expansion, and plan emission. Rust helpers live in `tagfold/`. Active fixtures sit under `data/active/`.

Build: `/app/scripts/build.sh`
Run: `TB_WH_FIXTURE=1 /app/bin/wh_triage`
