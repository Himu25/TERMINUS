// Plan JSON for /app/output/backfill_plan.json:
//
// schema_version — string, always "1"
// warehouse_id — string, echoes active warehouse plan name
// seed_count — uint32, corruption seeds from the plan that show row-level tag drift
// scope_count — uint32, distinct table/part pairs in minimal rebuild scope
// refresh_count — uint32, slices with valid row tags but watermark behind upstream
// skip_count — uint32, clean slices excluded from scope and refresh
// view_deps — uint32, view-layer edge traversals applied during scope expansion
// partial_hits — uint32, row-level tag failures detected across all slices
// late_hits — uint32, slices where late_ms strictly exceeds watermark_ms and enter scope
// scope_digest — lowercase hex SHA-256 of warehouse_id|seed_count|scope_count|refresh_count|skip_count|view_deps|partial_hits|late_hits
//
// Root object contains only these keys.
package main

import (
	"log"
	"os"

	"lab.local/wh_backfill_triage/internal/driver"
)

func main() {
	if os.Getenv("TB_WH_FIXTURE") != "1" {
		log.Fatal("TB_WH_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/backfill_plan.json", rep); err != nil {
		log.Fatal(err)
	}
}
