"""Verifier for warehouse backfill triage plans."""

import json
import os
import shutil
import subprocess
from collections import deque
from pathlib import Path

import pytest

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = Path("/tests") / "fixtures"
OUT = APP / "output" / "backfill_plan.json"
BIN = "/app/bin/wh_triage"
DIGEST_CLI = "/app/tools/digest_cli"
GO_BIN = "go"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _wire_crc(seq: int, payload: str) -> int:
    s = sum(payload.encode()) & 0xFFFFFFFF
    s ^= seq
    return s & 0xFFFF


def _partial_bad(rows: list[dict]) -> int:
    return sum(1 for r in rows if _wire_crc(r["seq"], r["payload"]) != r["tag"])


def _rows_valid(rows: list[dict]) -> bool:
    return all(_wire_crc(r["seq"], r["payload"]) == r["tag"] for r in rows)


def _op_l(direct: list[dict], view: list[dict], start: tuple[str, str]) -> tuple[list[tuple[str, str]], int]:
    adj_d: dict[str, list[str]] = {}
    adj_v: dict[str, list[str]] = {}
    for e in direct:
        adj_d.setdefault(e["from"], []).append(e["to"])
    for e in view:
        adj_v.setdefault(e["from"], []).append(e["to"])
    seen = {start[0]}
    out: list[tuple[str, str]] = []
    hops = 0
    queue = deque([start[0]])
    while queue:
        cur = queue.popleft()
        for nxt in adj_d.get(cur, []):
            if nxt not in seen:
                seen.add(nxt)
                out.append((nxt, start[1]))
                queue.append(nxt)
        for nxt in adj_v.get(cur, []):
            if nxt not in seen:
                seen.add(nxt)
                out.append((nxt, start[1]))
                hops += 1
                queue.append(nxt)
    return out, hops


def _digest_hex(
    warehouse_id: str,
    seed_count: int,
    scope_count: int,
    refresh_count: int,
    skip_count: int,
    view_deps: int,
    partial_hits: int,
    late_hits: int,
) -> str:
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            DIGEST_CLI,
            warehouse_id,
            str(seed_count),
            str(scope_count),
            str(refresh_count),
            str(skip_count),
            str(view_deps),
            str(partial_hits),
            str(late_hits),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _load_pack(pack_dir: Path) -> tuple[dict, dict[tuple[str, str], dict]]:
    plan = json.loads((pack_dir / "warehouse_plan.json").read_text())
    slices: dict[tuple[str, str], dict] = {}
    for tbl in plan["tables"]:
        tbl_dir = pack_dir / "tables" / tbl
        for path in sorted(tbl_dir.glob("*.json")):
            rec = json.loads(path.read_text())
            slices[(rec["table"], rec["part_id"])] = rec
    return plan, slices


def _expected(plan: dict, slices: dict[tuple[str, str], dict]) -> dict:
    scope: dict[tuple[str, str], bool] = {}
    partial_hits = 0
    late_hits = 0
    view_deps = 0

    def expand(start: tuple[str, str]) -> None:
        nonlocal view_deps
        down, hops = _op_l(plan["direct_edges"], plan["view_edges"], start)
        view_deps += hops
        for dk in down:
            scope[dk] = True

    for key, rec in slices.items():
        bad = _partial_bad(rec["rows"])
        partial_hits += bad
        if bad > 0:
            scope[key] = True
        if rec["late_ms"] > rec["watermark_ms"]:
            scope[key] = True
            late_hits += 1
            expand(key)

    seed_count = 0
    for seed in plan["seed_parts"]:
        sk = (seed["table"], seed["part_id"])
        if _partial_bad(slices[sk]["rows"]) == 0:
            continue
        seed_count += 1
        scope[sk] = True
        expand(sk)

    refresh: dict[tuple[str, str], bool] = {}
    for key, rec in slices.items():
        if key in scope:
            continue
        if _rows_valid(rec["rows"]) and rec["upstream_wm_ms"] > rec["watermark_ms"]:
            refresh[key] = True

    scope_count = len(scope)
    refresh_count = len(refresh)
    skip_count = len(slices) - scope_count - refresh_count
    digest = _digest_hex(
        plan["warehouse_id"],
        seed_count,
        scope_count,
        refresh_count,
        skip_count,
        view_deps,
        partial_hits,
        late_hits,
    )
    return {
        "schema_version": "1",
        "warehouse_id": plan["warehouse_id"],
        "seed_count": seed_count,
        "scope_count": scope_count,
        "refresh_count": refresh_count,
        "skip_count": skip_count,
        "view_deps": view_deps,
        "partial_hits": partial_hits,
        "late_hits": late_hits,
        "scope_digest": digest,
    }


def _run_driver() -> dict:
    env = {**os.environ, "TB_WH_FIXTURE": "1"}
    subprocess.run([BIN], cwd="/app", env=env, check=True)
    return json.loads(OUT.read_text())


def _swap_active(pack_name: str) -> None:
    src = FIXTURES / pack_name
    backup = APP / "data" / "_active_backup"
    if backup.exists():
        shutil.rmtree(backup)
    shutil.move(str(ACTIVE), str(backup))
    shutil.copytree(src, ACTIVE)


def _restore_active() -> None:
    backup = APP / "data" / "_active_backup"
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    if backup.exists():
        shutil.move(str(backup), str(ACTIVE))


class TestBackfillPlan:
    def test_active_plan_matches_contract(self) -> None:
        """Active warehouse plan emits expected triage counters."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got == expected

    def test_scope_digest_is_deterministic(self) -> None:
        """Two consecutive replays produce identical scope_digest."""
        first = _run_driver()
        second = _run_driver()
        assert first["scope_digest"] == second["scope_digest"]
        assert first == second

    def test_partial_hits_detect_row_drift(self) -> None:
        """partial_hits reflects row-level tag failures on corrupted seeds."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got["partial_hits"] == expected["partial_hits"]
        assert got["seed_count"] == expected["seed_count"]

    def test_view_deps_include_materialized_layer(self) -> None:
        """view_deps counts view-layer hops during scope expansion."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got["view_deps"] == expected["view_deps"]

    def test_refresh_excludes_stale_valid_slices(self) -> None:
        """refresh_count covers valid slices whose watermark trails upstream."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got["refresh_count"] == expected["refresh_count"]
        assert got["scope_count"] == expected["scope_count"]

    def test_late_updates_enter_scope(self) -> None:
        """late_hits counts slices with late_ms above watermark_ms."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got["late_hits"] == expected["late_hits"]

    def test_go_unit_tests_pass(self) -> None:
        """Go unit tests under /app pass after repair."""
        env = {
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        }
        subprocess.run([GO_BIN, "test", "./..."], cwd="/app", env=env, check=True)

    def test_pack_tight_replays_clean(self) -> None:
        """pack_tight regression stem replays to an equivalent plan."""
        _swap_active("pack_tight")
        try:
            plan, slices = _load_pack(ACTIVE)
            expected = _expected(plan, slices)
            got = _run_driver()
            assert got == expected
        finally:
            _restore_active()

    def test_pack_wide_replays_clean(self) -> None:
        """pack_wide regression stem replays to an equivalent plan."""
        _swap_active("pack_wide")
        try:
            plan, slices = _load_pack(ACTIVE)
            expected = _expected(plan, slices)
            got = _run_driver()
            assert got == expected
        finally:
            _restore_active()

    def test_skip_count_excludes_clean_slices(self) -> None:
        """skip_count leaves verified-clean slices out of scope and refresh."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got["skip_count"] == expected["skip_count"]

    def test_schema_version_and_warehouse_id(self) -> None:
        """Report carries schema_version and active warehouse_id from the plan."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got["warehouse_id"] == plan["warehouse_id"]
        assert got["schema_version"] == expected["schema_version"]
