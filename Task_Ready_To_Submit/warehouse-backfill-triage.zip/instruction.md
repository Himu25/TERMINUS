Warehouse tables under `/app` carry scrambled partition integrity tags. Derived tables sit on stale watermarks. Full recompute would burn every slice back to origin; most partitions remain clean and several derived copies need a refresh pass. Materialized view hops do not appear on direct-only table walks. Row-level tag drift shows up on some slices with healthy-looking partition headers. Late-arriving updates sit above the recorded watermark on a few slices.

The triage driver at `/app/bin/wh_triage` reads the active warehouse plan under `/app/data/active` and writes `/app/output/backfill_plan.json`. Replay over-scopes rebuild work, under-counts view-layer dependency hops, treats every stale derived slice as a full rebuild, and ignores delayed update windows. The Rust-backed row tag fold in `/app/tagfold` disagrees with the Go-side wire CRC on per-row integrity checks. Repair sources under `/app`, rebuild with `/app/scripts/build.sh`, and rerun with `TB_WH_FIXTURE=1` on the active plan.

Each plan JSON field:
- schema_version — string, always "1"
- warehouse_id — string, echoes active warehouse plan name
- seed_count — uint32, corruption seeds from the plan that show row-level tag drift
- scope_count — uint32, distinct table/part pairs in minimal rebuild scope
- refresh_count — uint32, slices with valid row tags but watermark behind upstream
- skip_count — uint32, clean slices excluded from scope and refresh
- view_deps — uint32, view-layer edge traversals applied during scope expansion
- partial_hits — uint32, row-level tag failures detected across all slices
- late_hits — uint32, slices where late_ms strictly exceeds watermark_ms and enter scope
- scope_digest — lowercase hex SHA-256 of warehouse_id|seed_count|scope_count|refresh_count|skip_count|view_deps|partial_hits|late_hits

Minimal rebuild scope includes every slice transitively downstream of a corrupted seed through both direct and view edges for the same part key. Slices whose row tags all validate but whose watermark trails upstream count toward refresh_count rather than scope_count. Slices with late_ms strictly above watermark_ms belong in scope with valid row tags. Go unit tests under `/app` must pass. Regression stems pack_tight and pack_wide are listed in `/app/docs/fixture_index.txt`. Signal completion once the active plan and listed stems replay to equivalent plans.
