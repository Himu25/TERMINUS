"""Validate /app/output/flow_report.json against flow.toml guardrails."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "flow_report.json"
BATCHES = APP / "data" / "batches_default.jsonl"
MANIFEST = APP / "data" / "batch_manifest.jsonl"
CARGO_TARGET = APP / "output" / "cargo-target"
CFG = APP / "config" / "flow.toml"
METER = APP / "data" / "flow_meter.csv"
CASES = Path(__file__).resolve().parent / "data"

_DEFAULT_BATCHES_TEXT = BATCHES.read_text(encoding="utf-8") if BATCHES.is_file() else ""

REPORT_KEYS = frozenset(
    {
        "status",
        "plant_capacity_l",
        "volume_allocated_l",
        "volume_slack_l",
        "batches_total",
        "batches_finished",
        "coverage_rate",
        "surplus_ratio",
        "stage_violations",
        "priority_inversions",
        "surge_buffer_l",
        "purity_score",
        "overflow_flags",
        "sensor_fault_count",
        "report_digest",
        "batches",
    }
)
ROW_KEYS = frozenset(
    {
        "batch_id",
        "quality_band",
        "turbidity_index",
        "reserve_l",
        "processed_l",
        "slack_l",
        "finished",
        "stage_ready",
        "dispatch_rank",
        "surge_wave",
        "purity_score",
        "overflow_flag",
        "sensor_fault",
    }
)


def _load_meter() -> dict[str, int]:
    readings: dict[str, int] = {}
    if not METER.is_file():
        return readings
    lines = METER.read_text(encoding="utf-8").splitlines()
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        batch_id, act_l = (part.strip() for part in line.split(",", 1))
        readings[batch_id] = int(act_l)
    return readings


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "plant_capacity_l": 12000,
        "min_coverage_rate": 0.75,
        "max_surplus_ratio": 0.35,
        "max_stage_violations": 0,
        "max_priority_inversions": 1,
        "min_surge_buffer_l": 3,
        "min_purity_score": 2.0,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in ("min_coverage_rate", "max_surplus_ratio", "min_purity_score"):
            cfg[key] = float(val)
        elif key in (
            "plant_capacity_l",
            "max_stage_violations",
            "max_priority_inversions",
            "min_surge_buffer_l",
        ):
            cfg[key] = int(float(val))
    return cfg


def _batch_rows_from_text(text: str) -> list[dict]:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def _batch_ids_from_text(text: str) -> list[str]:
    return [row["batch_id"] for row in _batch_rows_from_text(text)]


def _batch_map_from_text(text: str) -> dict[str, dict]:
    return {row["batch_id"]: row for row in _batch_rows_from_text(text)}


def _assert_batches_match_input(report: dict, batches_text: str) -> None:
    expected_ids = _batch_ids_from_text(batches_text)
    report_ids = [row["batch_id"] for row in report["batches"]]
    assert report["batches_total"] == len(expected_ids)
    assert len(report_ids) == len(expected_ids)
    assert set(report_ids) == set(expected_ids)


RUN_TIMEOUT_SEC = 120
BUILD_TIMEOUT_SEC = 600

_fresh_flowdisp_bytes_cache: bytes | None = None


def _is_elf_executable(path: Path) -> bool:
    if not path.is_file() or not os.access(path, os.X_OK):
        return False
    with path.open("rb") as handle:
        header = handle.read(4)
    return len(header) == 4 and header[0] == 0x7F and header[1:4] == b"ELF"


def _fresh_flowdisp_bytes() -> bytes:
    global _fresh_flowdisp_bytes_cache
    if _fresh_flowdisp_bytes_cache is not None:
        return _fresh_flowdisp_bytes_cache
    env = {
        **os.environ,
        "CARGO_TARGET_DIR": str(CARGO_TARGET),
    }
    subprocess.run(
        ["cargo", "build", "--release", "--locked", "-p", "flowdisp"],
        cwd=str(APP),
        env=env,
        check=True,
        timeout=BUILD_TIMEOUT_SEC,
    )
    _fresh_flowdisp_bytes_cache = (CARGO_TARGET / "release" / "flowdisp").read_bytes()
    return _fresh_flowdisp_bytes_cache


@pytest.fixture(autouse=True)
def restore_default_batches() -> None:
    yield
    if _DEFAULT_BATCHES_TEXT:
        _atomic_write_text(BATCHES, _DEFAULT_BATCHES_TEXT)
    stale_tmp = BATCHES.with_suffix(BATCHES.suffix + ".tmp")
    if stale_tmp.is_file():
        stale_tmp.unlink()


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    try:
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, path)
    finally:
        if tmp.is_file():
            tmp.unlink()


def _swap_fixture(stem: str) -> str:
    src = CASES / f"{stem}.jsonl"
    text = src.read_text(encoding="utf-8")
    _atomic_write_text(BATCHES, text)
    return text


def _expected_digest(report: dict) -> str:
    payload = dict(report)
    payload["report_digest"] = ""
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
        timeout=RUN_TIMEOUT_SEC,
    )
    return proc.stdout.split()[0]


def _invoke_default() -> None:
    proc = subprocess.run(
        ["/app/tools/run_flow"],
        capture_output=True,
        text=True,
        check=False,
        timeout=RUN_TIMEOUT_SEC,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "flow_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    _invoke_default()


def test_build_script_present_and_executable() -> None:
    """Documented build helper must exist for rebuilding flowdisp."""
    build_sh = APP / "scripts" / "build.sh"
    assert build_sh.is_file()
    assert os.access(build_sh, os.X_OK)


def test_flowdisp_is_rust_elf_binary() -> None:
    """flowdisp must be an executable ELF binary at the documented path."""
    flowdisp = APP / "bin" / "flowdisp"
    assert _is_elf_executable(flowdisp)


def test_batches_default_matches_manifest() -> None:
    """batches_default.jsonl must mirror every batch_manifest.jsonl row."""
    manifest_rows = _batch_rows_from_text(MANIFEST.read_text(encoding="utf-8"))
    actual_rows = _batch_rows_from_text(BATCHES.read_text(encoding="utf-8"))
    assert actual_rows == manifest_rows


def test_flowdisp_matches_fresh_source_build() -> None:
    """Installed flowdisp must match a release rebuild of the current source tree."""
    installed = (APP / "bin" / "flowdisp").read_bytes()
    assert installed == _fresh_flowdisp_bytes()


def test_report_top_level_keys_exact() -> None:
    """Report must expose only the documented top-level keys."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS


def test_batch_row_schema() -> None:
    """Each batch row must match the documented per-batch schema."""
    report = _load_report()
    assert report["batches"]
    for row in report["batches"]:
        assert set(row.keys()) == ROW_KEYS
        assert isinstance(row["batch_id"], str) and row["batch_id"]
        assert isinstance(row["quality_band"], str) and row["quality_band"]
        assert isinstance(row["turbidity_index"], int)
        assert row["reserve_l"] >= 0
        assert row["processed_l"] >= 0
        assert row["slack_l"] >= 0
        assert isinstance(row["finished"], bool)
        assert isinstance(row["stage_ready"], bool)
        assert row["dispatch_rank"] >= 1
        assert row["surge_wave"] >= 0
        assert row["purity_score"] >= 0.0
        assert isinstance(row["overflow_flag"], bool)
        assert isinstance(row["sensor_fault"], bool)


def test_passing_run_contract() -> None:
    """Default bundle must finish ok and meet flow.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["plant_capacity_l"] == cfg["plant_capacity_l"]
    _assert_batches_match_input(report, _DEFAULT_BATCHES_TEXT)
    assert report["coverage_rate"] >= cfg["min_coverage_rate"]
    assert report["surplus_ratio"] <= cfg["max_surplus_ratio"]
    assert report["stage_violations"] <= cfg["max_stage_violations"]
    assert report["priority_inversions"] <= cfg["max_priority_inversions"]
    assert report["surge_buffer_l"] >= cfg["min_surge_buffer_l"]
    assert report["purity_score"] >= cfg["min_purity_score"]


def test_batches_total_matches_input_rows() -> None:
    """Report batch IDs must cover every input JSONL row with no drops or extras."""
    report = _load_report()
    _assert_batches_match_input(report, _DEFAULT_BATCHES_TEXT)


def test_report_digest_matches_payload() -> None:
    """report_digest must hash the compact pre-digest JSON payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_deterministic_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_stage_rows_finish_in_order() -> None:
    """Stage dependency rows must finish only after prerequisites."""
    report = _load_report()
    ranks = {row["batch_id"]: row["dispatch_rank"] for row in report["batches"]}
    assert ranks["b_stage_root"] < ranks["b_stage_leaf"] < ranks["b_stage_chain"]
    for row in report["batches"]:
        if row["batch_id"].startswith("b_stage_") and row["finished"]:
            assert row["stage_ready"] is True, row


def test_urgency_hot_ranks_before_cold() -> None:
    """Fresh sensor revision rows must finish before stale low-revision peers."""
    report = _load_report()
    hot = next(r for r in report["batches"] if r["batch_id"] == "b_urgency_hot")
    cold = next(r for r in report["batches"] if r["batch_id"] == "b_urgency_cold")
    assert hot["finished"] is True
    assert cold["finished"] is True
    assert hot["dispatch_rank"] < cold["dispatch_rank"], (hot, cold)


def test_meter_accounting_semantics() -> None:
    """Meter drift rows reserve estimates, bill actuals, and record reserve minus processed."""
    report = _load_report()
    inputs = _batch_map_from_text(_DEFAULT_BATCHES_TEXT)
    meter = _load_meter()
    for row in report["batches"]:
        if not row["batch_id"].startswith("b_meter_") or not row["finished"]:
            continue
        spec = inputs[row["batch_id"]]
        expected_used = meter.get(row["batch_id"], spec["act_l"])
        assert row["reserve_l"] == spec["est_l"]
        assert row["processed_l"] == expected_used
        assert row["slack_l"] == max(0, row["reserve_l"] - row["processed_l"])


def test_meter_rows_record_slack() -> None:
    """Drift-prone meter rows with inflated reservations must record slack_l."""
    report = _load_report()
    meter_rows = [r for r in report["batches"] if r["batch_id"].startswith("b_meter_")]
    assert meter_rows
    assert any(r["slack_l"] > 0 for r in meter_rows if r["finished"])


def test_surge_rows_complete() -> None:
    """Surge-wave rows with the b_surge_ prefix must complete under the default bundle."""
    report = _load_report()
    surge_rows = [r for r in report["batches"] if r["batch_id"].startswith("b_surge_")]
    assert surge_rows
    assert all(r["finished"] for r in surge_rows), surge_rows


def test_batch_rows_respect_intensity() -> None:
    """Intake-zone rows must bill through profile scales, not raw volume alone."""
    report = _load_report()
    inputs = _batch_map_from_text(_DEFAULT_BATCHES_TEXT)
    north = next(r for r in report["batches"] if r["batch_id"] == "b_intake_north")
    south = next(r for r in report["batches"] if r["batch_id"] == "b_intake_south")
    south_act = inputs["b_intake_south"]["act_l"]
    assert north["finished"] and south["finished"]
    assert south["reserve_l"] < north["reserve_l"]
    assert south["reserve_l"] < south_act


def test_sensor_renew_row_completes() -> None:
    """Maintenance surge row b_sensor_renew must complete under the default bundle."""
    report = _load_report()
    renew = next(r for r in report["batches"] if r["batch_id"] == "b_sensor_renew")
    assert renew["finished"] is True
    assert renew["surge_wave"] > 0


def test_overflow_flags_on_default_bundle() -> None:
    """Over-capacity b_overflow_ rows must set overflow_flag and increment overflow_flags."""
    report = _load_report()
    overflow_rows = [r for r in report["batches"] if r["batch_id"].startswith("b_overflow_")]
    assert overflow_rows
    assert all(r["overflow_flag"] for r in overflow_rows if r["finished"]), overflow_rows
    assert report["overflow_flags"] >= len([r for r in overflow_rows if r["overflow_flag"]])


def test_sensor_fault_count_on_default_bundle() -> None:
    """b_sensor_ rows with sensor_revision below turbidity_index must set sensor_fault."""
    report = _load_report()
    sensor_rows = [r for r in report["batches"] if r["batch_id"].startswith("b_sensor_")]
    assert sensor_rows
    assert any(r["sensor_fault"] for r in sensor_rows)
    assert report["sensor_fault_count"] >= 1


def test_scenario_urgency_flip() -> None:
    """Revision-flip scenario must schedule fresh telemetry ahead of stale peers."""
    cfg = _parse_cfg()
    batches_text = _swap_fixture("urgency_flip")
    _invoke_default()
    report = _load_report()
    _assert_batches_match_input(report, batches_text)
    hot = next(r for r in report["batches"] if r["batch_id"] == "b_urgency_hot")
    cold = next(r for r in report["batches"] if r["batch_id"] == "b_urgency_cold")
    assert hot["dispatch_rank"] < cold["dispatch_rank"]
    assert report["priority_inversions"] <= cfg["max_priority_inversions"]
    assert report["status"] == "ok"


def test_scenario_value_mix() -> None:
    """Purity-index mix scenario must meet purity_score floor."""
    cfg = _parse_cfg()
    batches_text = _swap_fixture("value_mix")
    _invoke_default()
    report = _load_report()
    _assert_batches_match_input(report, batches_text)
    assert report["purity_score"] >= cfg["min_purity_score"]


def test_scenario_flowprobe() -> None:
    """Zero-estimate flowprobe row must bill act_l through the meter."""
    batches_text = _swap_fixture("flowprobe")
    _invoke_default()
    report = _load_report()
    _assert_batches_match_input(report, batches_text)
    meter = _load_meter()
    expected_used = meter["b_flowprobe"]
    row = next(r for r in report["batches"] if r["batch_id"] == "b_flowprobe")
    assert row["finished"] is True
    assert row["processed_l"] == expected_used
    assert row["reserve_l"] >= row["processed_l"]
    assert row["slack_l"] == max(0, row["reserve_l"] - row["processed_l"])


def test_scenario_stage_chain() -> None:
    """Maintenance outage scenario must schedule stage deps before dependents."""
    batches_text = _swap_fixture("stage_chain")
    _invoke_default()
    report = _load_report()
    _assert_batches_match_input(report, batches_text)
    assert report["stage_violations"] == 0
    assert report["status"] == "ok"
    ranks = {row["batch_id"]: row["dispatch_rank"] for row in report["batches"]}
    assert ranks["b_stage_root"] < ranks["b_stage_leaf"] < ranks["b_stage_chain"]


def test_scenario_est_drift() -> None:
    """Meter-drift scenario must keep surplus_ratio under max_surplus_ratio."""
    cfg = _parse_cfg()
    batches_text = _swap_fixture("est_drift")
    _invoke_default()
    report = _load_report()
    _assert_batches_match_input(report, batches_text)
    inputs = _batch_map_from_text(batches_text)
    for row in report["batches"]:
        if not row["batch_id"].startswith("b_meter_") or not row["finished"]:
            continue
        spec = inputs[row["batch_id"]]
        assert row["reserve_l"] == spec["est_l"]
        assert row["slack_l"] == max(0, row["reserve_l"] - row["processed_l"])
        assert row["slack_l"] > 0
    assert report["surplus_ratio"] <= cfg["max_surplus_ratio"]
    assert report["status"] == "ok"


def test_scenario_surge_cluster() -> None:
    """Surge-cluster scenario must absorb enough buffer headroom."""
    cfg = _parse_cfg()
    batches_text = _swap_fixture("surge_cluster")
    _invoke_default()
    report = _load_report()
    _assert_batches_match_input(report, batches_text)
    surge_rows = [r for r in report["batches"] if r["batch_id"].startswith("b_surge_")]
    assert surge_rows
    assert all(r["finished"] for r in surge_rows)
    assert report["surge_buffer_l"] >= cfg["min_surge_buffer_l"]
    assert report["status"] == "ok"


def test_scenario_intake_mix() -> None:
    """Intake-zone variability scenario must bill south-basin below north-intake for similar work."""
    batches_text = _swap_fixture("intake_mix")
    _invoke_default()
    report = _load_report()
    _assert_batches_match_input(report, batches_text)
    inputs = _batch_map_from_text(batches_text)
    north = next(r for r in report["batches"] if r["batch_id"] == "b_intake_north")
    south = next(r for r in report["batches"] if r["batch_id"] == "b_intake_south")
    south_act = inputs["b_intake_south"]["act_l"]
    assert north["finished"] and south["finished"]
    assert south["reserve_l"] < north["reserve_l"]
    assert south["reserve_l"] < south_act


def test_scenario_sensor_renew() -> None:
    """Maintenance outage scenario must complete b_sensor_renew with buffer absorption."""
    cfg = _parse_cfg()
    batches_text = _swap_fixture("sensor_renew")
    _invoke_default()
    report = _load_report()
    _assert_batches_match_input(report, batches_text)
    renew = next(r for r in report["batches"] if r["batch_id"] == "b_sensor_renew")
    assert renew["finished"] is True
    assert report["surge_buffer_l"] >= cfg["min_surge_buffer_l"]
    assert report["status"] == "ok"


def test_scenario_overflow_mix() -> None:
    """Overflow scenario must flag every over-capacity b_overflow_ row."""
    batches_text = _swap_fixture("overflow_mix")
    _invoke_default()
    report = _load_report()
    _assert_batches_match_input(report, batches_text)
    overflow_rows = [r for r in report["batches"] if r["batch_id"].startswith("b_overflow_")]
    assert overflow_rows
    assert all(r["overflow_flag"] for r in overflow_rows if r["finished"])
    assert report["overflow_flags"] >= len(overflow_rows)
    assert report["status"] == "ok"


def test_scenario_sensor_fault() -> None:
    """Sensor failure scenario must count sensor_fault rows and rank hot revision first."""
    batches_text = _swap_fixture("sensor_fault")
    _invoke_default()
    report = _load_report()
    _assert_batches_match_input(report, batches_text)
    sensor_rows = [r for r in report["batches"] if r["batch_id"].startswith("b_sensor_")]
    assert sensor_rows
    assert all(r["sensor_fault"] for r in sensor_rows)
    assert report["sensor_fault_count"] >= len(sensor_rows)
    hot = next(r for r in report["batches"] if r["batch_id"] == "b_urgency_hot")
    assert hot["dispatch_rank"] == 1
    assert report["status"] == "ok"
