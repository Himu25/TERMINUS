#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/Cargo.toml
require_file /app/config/flow.toml
require_file /app/data/batch_manifest.jsonl
require_file /app/data/intake_profiles.csv
require_file /app/data/flow_meter.csv
mkdir -p /app/bin /app/output

log "apply patched sources"
cp "${ROOT_DIR}/oracle/q9_lib.rs" /app/q9/src/lib.rs
cp "${ROOT_DIR}/oracle/k2_lib.rs" /app/k2/src/lib.rs
cp "${ROOT_DIR}/oracle/h4_lib.rs" /app/h4/src/lib.rs
cp "${ROOT_DIR}/oracle/z1_lib.rs" /app/z1/src/lib.rs
cp "${ROOT_DIR}/oracle/n8_lib.rs" /app/n8/src/lib.rs

log "rebuild flowdisp"
bash /app/scripts/build.sh
rm -rf /app/output/cargo-target

log "refresh default batch bundle"
/app/bin/batchpack /app/data/batch_manifest.jsonl /app/data/batches_default.jsonl

log "emit default flow report"
/app/tools/run_flow

log "post-run validation against flow.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/flow.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k in ("min_coverage_rate", "max_surplus_ratio", "min_purity_score"):
        cfg[k] = float(v)
    elif k.startswith("max_") or k.startswith("min_") or k == "plant_capacity_l":
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/flow_report.json").read_text())
assert report["status"] == "ok", report
assert report["coverage_rate"] >= cfg["min_coverage_rate"]
assert report["surplus_ratio"] <= cfg["max_surplus_ratio"]
assert report["stage_violations"] <= cfg["max_stage_violations"]
assert report["priority_inversions"] <= cfg["max_priority_inversions"]
assert report["surge_buffer_l"] >= cfg["min_surge_buffer_l"]
assert report["purity_score"] >= cfg["min_purity_score"]
for row in report["batches"]:
    if row["batch_id"].startswith("b_stage_") and row["finished"]:
        assert row["stage_ready"], row
    if row["batch_id"].startswith("b_surge_"):
        assert row["finished"], row
    if row["batch_id"].startswith("b_overflow_") and row["finished"]:
        assert row["overflow_flag"], row
print("ok", report["coverage_rate"], report["surplus_ratio"], report["purity_score"])
PY

log "oracle complete"
