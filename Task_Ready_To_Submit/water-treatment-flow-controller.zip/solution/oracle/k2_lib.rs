use std::collections::HashMap;

pub fn px_hold(dep_on: &[String], done: &HashMap<String, bool>) -> bool {
    if dep_on.is_empty() {
        return true;
    }
    dep_on.iter().all(|dep| done.get(dep).copied().unwrap_or(false))
}
