use core_types::BatchCase;

pub fn qx_seq(cases: &[BatchCase]) -> Vec<BatchCase> {
    let mut out = cases.to_vec();
    out.sort_by(|a, b| {
        b.sensor_revision
            .cmp(&a.sensor_revision)
            .then(b.turbidity_index.cmp(&a.turbidity_index))
            .then(
                b.purity_index
                    .partial_cmp(&a.purity_index)
                    .unwrap_or(std::cmp::Ordering::Equal),
            )
            .then(a.batch_id.cmp(&b.batch_id))
    });
    out
}
