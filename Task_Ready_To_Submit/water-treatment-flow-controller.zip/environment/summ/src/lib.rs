use core_types::BatchRow;

pub fn sx_fold(rows: &[BatchRow]) -> i32 {
    rows.iter().map(|r| r.reserve_l).sum()
}
