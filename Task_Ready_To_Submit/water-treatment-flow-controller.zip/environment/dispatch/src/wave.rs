use h4::ux_absorb;

pub fn wave_surge_total(surge_wave: i32, est_l: i32, headroom: i32) -> i32 {
    if surge_wave <= 0 {
        return 0;
    }
    ux_absorb(est_l / 4, headroom)
}
