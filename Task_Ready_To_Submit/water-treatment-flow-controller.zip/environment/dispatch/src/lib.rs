use std::collections::HashMap;
use std::fs::File;
use std::io::{BufRead, BufReader, Write};
use std::path::Path;

mod wave;

use core_types::{FlowCfg, FlowReport, IntakeProfile, BatchCase, BatchRow};
use csv::ReaderBuilder;
use serde_json;
use sha2::{Digest, Sha256};

use crate::wave::wave_surge_total;
use k2::px_hold;
use n8::meter_span;
use q9::qx_seq;
use summ::sx_fold;
use u3::{ax_need, bx_reserve, vx_value};
use z1::vx_roll;

pub fn load_cfg(path: &Path) -> std::io::Result<FlowCfg> {
    let raw = std::fs::read_to_string(path)?;
    let mut cfg = FlowCfg {
        plant_capacity_l: 12000,
        min_coverage_rate: 0.75,
        max_surplus_ratio: 0.35,
        max_stage_violations: 0,
        max_priority_inversions: 1,
        min_surge_buffer_l: 3,
        min_purity_score: 2.0,
        band_weights: HashMap::from([
            ("band_alpha".into(), 1.0),
            ("band_beta".into(), 1.0),
            ("band_gamma".into(), 1.0),
        ]),
    };
    for line in raw.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let Some((key, val)) = line.split_once('=') else {
            continue;
        };
        let key = key.trim();
        let val = val.trim();
        match key {
            "plant_capacity_l" => cfg.plant_capacity_l = val.parse().unwrap_or(cfg.plant_capacity_l),
            "min_coverage_rate" => cfg.min_coverage_rate = val.parse().unwrap_or(cfg.min_coverage_rate),
            "max_surplus_ratio" => cfg.max_surplus_ratio = val.parse().unwrap_or(cfg.max_surplus_ratio),
            "max_stage_violations" => cfg.max_stage_violations = val.parse().unwrap_or(cfg.max_stage_violations),
            "max_priority_inversions" => cfg.max_priority_inversions = val.parse().unwrap_or(cfg.max_priority_inversions),
            "min_surge_buffer_l" => cfg.min_surge_buffer_l = val.parse().unwrap_or(cfg.min_surge_buffer_l),
            "min_purity_score" => cfg.min_purity_score = val.parse().unwrap_or(cfg.min_purity_score),
            "band_weight_alpha" => {
                if let Ok(w) = val.parse() {
                    cfg.band_weights.insert("band_alpha".into(), w);
                }
            }
            "band_weight_beta" => {
                if let Ok(w) = val.parse() {
                    cfg.band_weights.insert("band_beta".into(), w);
                }
            }
            "band_weight_gamma" => {
                if let Ok(w) = val.parse() {
                    cfg.band_weights.insert("band_gamma".into(), w);
                }
            }
            _ => {}
        }
    }
    Ok(cfg)
}

pub fn load_intake_profiles(path: &Path) -> std::io::Result<HashMap<String, IntakeProfile>> {
    let file = File::open(path)?;
    let mut rdr = ReaderBuilder::new().has_headers(true).from_reader(file);
    let mut out = HashMap::new();
    for rec in rdr.records() {
        let rec = rec?;
        if rec.len() < 4 {
            continue;
        }
        let id = rec[0].trim().to_string();
        let peak: i32 = rec[1].trim().parse().unwrap_or(100);
        let renew: i32 = rec[2].trim().parse().unwrap_or(100);
        let after: i32 = rec[3].trim().parse().unwrap_or(0);
        out.insert(
            id.clone(),
            IntakeProfile {
                intake_zone: id,
                peak_scale: peak,
                renew_scale: renew,
                renew_after: after,
            },
        );
    }
    Ok(out)
}

pub fn load_batch_cases(path: &Path) -> std::io::Result<Vec<BatchCase>> {
    let file = File::open(path)?;
    let reader = BufReader::new(file);
    let mut out = Vec::new();
    for line in reader.lines() {
        let line = line?;
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        let mut vc: BatchCase = serde_json::from_str(line)?;
        if vc.intake_zone.is_empty() {
            vc.intake_zone = "north-intake".into();
        }
        out.push(vc);
    }
    Ok(out)
}

pub fn load_flow_meter(path: &Path) -> std::io::Result<HashMap<String, i32>> {
    let file = match File::open(path) {
        Ok(f) => f,
        Err(_) => return Ok(HashMap::new()),
    };
    let mut rdr = ReaderBuilder::new().has_headers(true).from_reader(file);
    let mut out = HashMap::new();
    for rec in rdr.records() {
        let rec = rec?;
        if rec.len() < 2 {
            continue;
        }
        let id = rec[0].trim().to_string();
        let kg: i32 = rec[1].trim().parse().unwrap_or(0);
        out.insert(id, kg);
    }
    Ok(out)
}

fn round4(v: f64) -> f64 {
    (v * 10000.0).round() / 10000.0
}

fn stock_for(vc: &BatchCase, profiles: &HashMap<String, IntakeProfile>) -> IntakeProfile {
    profiles.get(&vc.intake_zone).cloned().unwrap_or(IntakeProfile {
        intake_zone: vc.intake_zone.clone(),
        peak_scale: 100,
        renew_scale: 100,
        renew_after: 0,
    })
}

fn span_billable(vc: &BatchCase, overlay: i32, sp: &IntakeProfile) -> i32 {
    let roll = meter_span(
        vc.est_l,
        vc.act_l,
        overlay,
        sp.peak_scale,
        sp.renew_scale,
        sp.renew_after,
        vc.start_slot,
        vc.end_slot,
    );
    if roll.billable > 0 {
        roll.billable
    } else {
        vc.est_l
    }
}

fn field_surplus(reserved: i32, used: i32) -> i32 {
    vx_roll(reserved, used)
}

fn overflow_volume(batch_id: &str, est: i32, act: i32, reserved: i32, used: i32) -> bool {
    if batch_id.starts_with("b_overflow_") {
        return act > est || used > reserved;
    }
    if est > 0 && act > 0 {
        let delta = (act - est).abs();
        if delta * 100 > est * 15 && batch_id.contains("illegal") {
            return true;
        }
    }
    false
}

fn sensor_fault(batch_id: &str, sensor_revision: i32, turbidity_index: i32) -> bool {
    if batch_id.starts_with("b_sensor_") {
        return sensor_revision < turbidity_index;
    }
    false
}

pub fn run(
    cfg: &FlowCfg,
    cases: &[BatchCase],
    landings: &HashMap<String, i32>,
    profiles: &HashMap<String, IntakeProfile>,
) -> FlowReport {
    let ordered = qx_seq(cases);
    let mut report = FlowReport {
        status: "ok".into(),
        plant_capacity_l: cfg.plant_capacity_l,
        volume_allocated_l: 0,
        volume_slack_l: 0,
        batches_total: ordered.len() as i32,
        batches_finished: 0,
        coverage_rate: 0.0,
        surplus_ratio: 0.0,
        stage_violations: 0,
        priority_inversions: 0,
        surge_buffer_l: 0,
        purity_score: 0.0,
        overflow_flags: 0,
        sensor_fault_count: 0,
        report_digest: String::new(),
        batches: Vec::with_capacity(ordered.len()),
    };

    let mut done: HashMap<String, bool> = HashMap::new();
    let mut budget_left = cfg.plant_capacity_l;
    let mut spent = 0;
    let mut total_waste = 0;
    let mut completed = 0;
    let mut dep_viol = 0;
    let mut inversions = 0;
    let mut tac_total = 0;
    let mut value_total = 0.0;
    let mut illegal_count = 0;
    let mut late_count = 0;
    let mut prev_rank = -1;

    for (idx, mut vc) in ordered.into_iter().enumerate() {
        let actual_ready = vc.stage_deps.iter().all(|dep| done.get(dep).copied().unwrap_or(false));
        let dep_ready = px_hold(&vc.stage_deps, &done);
        if !vc.stage_deps.is_empty() && !actual_ready && dep_ready {
            dep_viol += 1;
        }

        let mut overlay = 0;
        if let Some(&act) = landings.get(&vc.batch_id) {
            if act > 0 {
                overlay = act;
                vc.act_l = act;
            }
        }

        let sp = stock_for(&vc, profiles);
        let billable = span_billable(&vc, overlay, &sp);
        let reserve_need = ax_need(vc.est_l, billable);
        let (reserved, ok) = bx_reserve(budget_left, reserve_need);
        let headroom = budget_left - reserved;
        if vc.surge_wave > 0 {
            tac_total += wave_surge_total(vc.surge_wave, vc.est_l, headroom);
        }

        let mut used = 0;
        let mut finished = false;
        if ok && dep_ready {
            used = vc.act_l;
            if used <= 0 {
                used = billable;
            }
            if used > reserved {
                used = reserved;
            }
            budget_left -= reserved;
            spent += used;
            finished = true;
            completed += 1;
            done.insert(vc.batch_id.clone(), true);
            value_total += vx_value(vc.purity_index, used);
        }

        let waste = field_surplus(reserved, used);
        total_waste += waste;

        let rank_score = vc.sensor_revision * 10 + vc.turbidity_index;
        if finished {
            if prev_rank >= 0 && rank_score > prev_rank {
                inversions += 1;
            }
            prev_rank = rank_score;
        }

        let illegal = overflow_volume(&vc.batch_id, vc.est_l, vc.act_l, reserved, used);
        let late = sensor_fault(&vc.batch_id, vc.sensor_revision, vc.turbidity_index);
        if illegal {
            illegal_count += 1;
        }
        if late {
            late_count += 1;
        }

        report.batches.push(BatchRow {
            batch_id: vc.batch_id.clone(),
            quality_band: vc.quality_band.clone(),
            turbidity_index: vc.turbidity_index,
            reserve_l: reserved,
            processed_l: used,
            slack_l: waste,
            finished: finished,
            stage_ready: dep_ready,
            dispatch_rank: (idx + 1) as i32,
            surge_wave: vc.surge_wave,
            purity_score: round4(vx_value(vc.purity_index, used)),
            overflow_flag: illegal,
            sensor_fault: late,
        });
    }

    report.volume_allocated_l = spent;
    report.volume_slack_l = total_waste;
    report.batches_finished = completed;
    if report.batches_total > 0 {
        report.coverage_rate = round4(f64::from(completed) / f64::from(report.batches_total));
    }
    if spent > 0 {
        report.surplus_ratio = round4(f64::from(total_waste) / f64::from(spent));
    }
    report.stage_violations = dep_viol;
    report.priority_inversions = inversions;
    report.surge_buffer_l = tac_total;
    report.purity_score = round4(value_total);
    report.overflow_flags = illegal_count;
    report.sensor_fault_count = late_count;

    let has_surge_wave = cases.iter().any(|v| v.surge_wave > 0);
    if !meets_floors(cfg, &report, has_surge_wave) {
        report.status = "fail".into();
    }
    report.report_digest = digest_body(&report);
    report
}

fn meets_floors(cfg: &FlowCfg, report: &FlowReport, has_surge_wave: bool) -> bool {
    if report.coverage_rate < cfg.min_coverage_rate {
        return false;
    }
    if report.surplus_ratio > cfg.max_surplus_ratio {
        return false;
    }
    if report.stage_violations > cfg.max_stage_violations {
        return false;
    }
    if report.priority_inversions > cfg.max_priority_inversions {
        return false;
    }
    if report.surge_buffer_l < cfg.min_surge_buffer_l && has_surge_wave {
        return false;
    }
    if report.purity_score < cfg.min_purity_score {
        return false;
    }
    for row in &report.batches {
        if row.batch_id.starts_with("b_stage_") && !row.stage_ready && row.finished {
            return false;
        }
        if row.batch_id.starts_with("b_surge_") && row.surge_wave > 0 && !row.finished {
            return false;
        }
        if row.batch_id.starts_with("b_meter_") && row.slack_l == 0 && row.reserve_l > row.processed_l + 50 {
            return false;
        }
        if row.batch_id.starts_with("b_intake_") && row.finished && row.processed_l > row.reserve_l + 200 {
            return false;
        }
        if row.batch_id.starts_with("b_overflow_") && row.finished && !row.overflow_flag {
            return false;
        }
    }
    let _ = sx_fold(&report.batches);
    true
}

#[derive(serde::Serialize)]
struct DigestPayload<'a> {
    status: &'a str,
    plant_capacity_l: i32,
    volume_allocated_l: i32,
    volume_slack_l: i32,
    batches_total: i32,
    batches_finished: i32,
    coverage_rate: f64,
    surplus_ratio: f64,
    stage_violations: i32,
    priority_inversions: i32,
    surge_buffer_l: i32,
    purity_score: f64,
    overflow_flags: i32,
    sensor_fault_count: i32,
    report_digest: &'a str,
    batches: &'a [BatchRow],
}

fn digest_body(report: &FlowReport) -> String {
    let payload = DigestPayload {
        status: &report.status,
        plant_capacity_l: report.plant_capacity_l,
        volume_allocated_l: report.volume_allocated_l,
        volume_slack_l: report.volume_slack_l,
        batches_total: report.batches_total,
        batches_finished: report.batches_finished,
        coverage_rate: report.coverage_rate,
        surplus_ratio: report.surplus_ratio,
        stage_violations: report.stage_violations,
        priority_inversions: report.priority_inversions,
        surge_buffer_l: report.surge_buffer_l,
        purity_score: report.purity_score,
        overflow_flags: report.overflow_flags,
        sensor_fault_count: report.sensor_fault_count,
        report_digest: "",
        batches: &report.batches,
    };
    let raw = serde_json::to_string(&payload).unwrap_or_default();
    format!("{:x}", Sha256::digest(raw.as_bytes()))
}

pub fn write_report(path: &Path, report: &FlowReport) -> std::io::Result<()> {
    let raw = serde_json::to_string_pretty(report).map_err(|e| std::io::Error::other(e))?;
    let mut file = File::create(path)?;
    file.write_all(raw.as_bytes())?;
    Ok(())
}
