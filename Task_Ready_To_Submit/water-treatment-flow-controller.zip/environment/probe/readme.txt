probe lane for flow smoke checks
