# Flow report contract

## Top-level fields

- status: ok when guardrails pass, otherwise fail
- plant_capacity_l: plant pool from flow.toml
- volume_allocated_l: billable liters allocated to finished batches
- volume_slack_l: capacity slack summed across batches
- batches_total: input JSONL row count
- batches_finished: batches marked finished
- coverage_rate: batches_finished divided by batches_total
- surplus_ratio: volume_slack_l divided by volume_allocated_l
- stage_violations: batches dispatched before stage dependencies finished
- priority_inversions: finished batches whose rank score fell below a prior finish
- surge_buffer_l: surge headroom liters absorbed during waves
- purity_score: weighted purity index total for finished batches
- overflow_flags: count of batch rows with overflow_flag set
- sensor_fault_count: count of batch rows with sensor_fault set
- report_digest: sha256 hex of compact JSON with report_digest empty
- batches: per-batch rows

## Batch row fields

- batch_id, quality_band, turbidity_index
- reserve_l, processed_l, slack_l
- finished, stage_ready, dispatch_rank, surge_wave, purity_score
- overflow_flag, sensor_fault

## Dispatch order

Pending batches are sorted before allocation using, in order:

1. sensor_revision descending (fresh telemetry outranks stale rows)
2. turbidity_index descending
3. purity_index descending
4. batch_id ascending (stable tie-break)

## dispatch_rank

1-based position in the allocator processing order after the sort above. Lower dispatch_rank means the batch was scheduled earlier.

## Priority inversions

For each finished batch, form rank score = sensor_revision * 10 + turbidity_index. priority_inversions counts how often a finished batch's rank score is greater than the rank score of an earlier-finished batch.

## Intake profile

intake_profiles.csv supplies peak_scale, renew_scale, and renew_after per intake_zone. The Rust meter blends peak and renew scales across each batch's start_slot and duration before converting estimates and actuals into billable liters. Duration is end_slot minus start_slot from the batch row. When two intake-zone batches carry the same act_l, the south-basin row must bill lower than the north-intake peer in reserve_l once profile scales are applied.

## Meter drift and volume accounting

- reserve_l: reservation size from est_l when est_l is positive; when est_l is zero, reservation follows billable liters from the flow meter
- processed_l: flow meter act_l when flow_meter.csv supplies a value, otherwise act_l from the batch row
- slack_l: reserve_l minus processed_l (zero when reserve is not greater than processed)
- Conflicting meter drift rows keep the estimate reservation even when actual inflow is lower, so slack_l reflects reserve minus processed

## Overflow batches

Batches prefixed b_overflow_ must set overflow_flag when act_l exceeds est_l or processed_l exceeds reserve_l while finished.

## Sensor faults

Batches prefixed b_sensor_ set sensor_fault when sensor_revision is below turbidity_index.

Digest JSON uses the same keys as the written report with report_digest set to empty string before hashing.
