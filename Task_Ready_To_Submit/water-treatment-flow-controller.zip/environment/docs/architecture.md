# Treatment plant workspace

The flow lab under `/app` is a Rust workspace. `flowdisp` reads batch JSONL, intake profiles, and flow meter data, then writes `/app/output/flow_report.json`. Supporting crates handle ranking, stage gates, surge absorption, slack rolls, and intake-zone metering. Build with `/app/scripts/build.sh`.
