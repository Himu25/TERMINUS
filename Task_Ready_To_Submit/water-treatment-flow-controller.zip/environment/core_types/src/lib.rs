use serde::{Deserialize, Serialize};
use std::collections::HashMap;

#[derive(Debug, Clone)]
pub struct FlowCfg {
    pub plant_capacity_l: i32,
    pub min_coverage_rate: f64,
    pub max_surplus_ratio: f64,
    pub max_stage_violations: i32,
    pub max_priority_inversions: i32,
    pub min_surge_buffer_l: i32,
    pub min_purity_score: f64,
    pub band_weights: HashMap<String, f64>,
}

#[derive(Debug, Clone)]
pub struct IntakeProfile {
    pub intake_zone: String,
    pub peak_scale: i32,
    pub renew_scale: i32,
    pub renew_after: i32,
}

#[derive(Debug, Clone, Deserialize)]
pub struct BatchCase {
    pub batch_id: String,
    pub quality_band: String,
    pub turbidity_index: i32,
    pub sensor_revision: i32,
    #[serde(default)]
    pub est_l: i32,
    #[serde(default)]
    pub act_l: i32,
    #[serde(default)]
    pub stage_deps: Vec<String>,
    #[serde(default)]
    pub surge_wave: i32,
    #[serde(default)]
    pub purity_index: f64,
    #[serde(default = "default_intake_zone")]
    pub intake_zone: String,
    #[serde(default)]
    pub start_slot: i32,
    #[serde(default = "default_end_slot")]
    pub end_slot: i32,
}

fn default_intake_zone() -> String {
    "north-intake".into()
}

fn default_end_slot() -> i32 {
    96
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BatchRow {
    pub batch_id: String,
    pub quality_band: String,
    pub turbidity_index: i32,
    pub reserve_l: i32,
    pub processed_l: i32,
    pub slack_l: i32,
    pub finished: bool,
    pub stage_ready: bool,
    pub dispatch_rank: i32,
    pub surge_wave: i32,
    pub purity_score: f64,
    pub overflow_flag: bool,
    pub sensor_fault: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FlowReport {
    pub status: String,
    pub plant_capacity_l: i32,
    pub volume_allocated_l: i32,
    pub volume_slack_l: i32,
    pub batches_total: i32,
    pub batches_finished: i32,
    pub coverage_rate: f64,
    pub surplus_ratio: f64,
    pub stage_violations: i32,
    pub priority_inversions: i32,
    pub surge_buffer_l: i32,
    pub purity_score: f64,
    pub overflow_flags: i32,
    pub sensor_fault_count: i32,
    pub report_digest: String,
    pub batches: Vec<BatchRow>,
}
