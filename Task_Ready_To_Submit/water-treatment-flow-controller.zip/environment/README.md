Treatment plant flow controller workspace. Build with `/app/scripts/build.sh`, run `/app/tools/run_flow`.
