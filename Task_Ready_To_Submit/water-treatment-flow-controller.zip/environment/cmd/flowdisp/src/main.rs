use std::env;
use std::path::PathBuf;
use std::process;

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() < 3 {
        eprintln!("usage: flowdisp <batches.jsonl> <out.json>");
        process::exit(2);
    }
    let cfg = dispatch::load_cfg(PathBuf::from("/app/config/flow.toml").as_path())
        .unwrap_or_else(|e| {
            eprintln!("{e}");
            process::exit(1);
        });
    let cases = dispatch::load_batch_cases(PathBuf::from(&args[1]).as_path()).unwrap_or_else(|e| {
        eprintln!("{e}");
        process::exit(1);
    });
    let landings =
        dispatch::load_flow_meter(PathBuf::from("/app/data/flow_meter.csv").as_path())
            .unwrap_or_else(|e| {
                eprintln!("{e}");
                process::exit(1);
            });
    let profiles = dispatch::load_intake_profiles(
        PathBuf::from("/app/data/intake_profiles.csv").as_path(),
    )
    .unwrap_or_else(|e| {
        eprintln!("{e}");
        process::exit(1);
    });
    let report = dispatch::run(&cfg, &cases, &landings, &profiles);
    dispatch::write_report(PathBuf::from(&args[2]).as_path(), &report).unwrap_or_else(|e| {
        eprintln!("{e}");
        process::exit(1);
    });
}
