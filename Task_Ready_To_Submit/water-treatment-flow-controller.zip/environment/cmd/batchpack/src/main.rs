use std::env;
use std::fs;
use std::io::{BufRead, BufReader, Write};
use std::process;

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() < 3 {
        eprintln!("usage: batchpack <manifest.jsonl> <out.jsonl>");
        process::exit(2);
    }
    let input = fs::File::open(&args[1]).unwrap_or_else(|e| {
        eprintln!("{e}");
        process::exit(1);
    });
    let reader = BufReader::new(input);
    let mut out = fs::File::create(&args[2]).unwrap_or_else(|e| {
        eprintln!("{e}");
        process::exit(1);
    });
    for line in reader.lines() {
        let line = line.unwrap_or_else(|e| {
            eprintln!("{e}");
            process::exit(1);
        });
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        writeln!(out, "{trimmed}").unwrap_or_else(|e| {
            eprintln!("{e}");
            process::exit(1);
        });
    }
}
