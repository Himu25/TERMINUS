stage queue notes
