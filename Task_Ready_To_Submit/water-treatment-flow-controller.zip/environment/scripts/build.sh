#!/bin/bash
set -euo pipefail

export CARGO_TARGET_DIR=/app/output/cargo-target
mkdir -p /app/bin /app/output/cargo-target

cd /app
cargo build --release --locked -p flowdisp -p batchpack
cp /app/output/cargo-target/release/flowdisp /app/bin/flowdisp
cp /app/output/cargo-target/release/batchpack /app/bin/batchpack
