use core_types::BatchCase;

pub fn qx_seq(cases: &[BatchCase]) -> Vec<BatchCase> {
    let mut out = cases.to_vec();
    out.sort_by(|a, b| a.est_l.cmp(&b.est_l));
    out
}
