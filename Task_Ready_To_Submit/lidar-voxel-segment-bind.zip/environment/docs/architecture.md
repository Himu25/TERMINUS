LiDAR voxel segmentation replay ties together a Go scan ledger, Rust occupancy integrator, and bash runners under `/app`.
The driver reads scan manifests from `/app/data`, motion-compensation profiles, and occupancy logs before emitting the segment report.
