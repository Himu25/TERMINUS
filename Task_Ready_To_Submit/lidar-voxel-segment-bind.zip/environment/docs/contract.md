# Segment report contract

Top-level fields:

- status: ok when every lidar.toml guardrail is satisfied; fail otherwise
- voxel_budget: total voxel pool for the replay batch
- voxels_allocated: billable volume consumed by bound scans
- voxels_slack: reservation surplus summed across scans
- scans_total: input JSONL row count
- scans_bound: scans marked served
- occupancy_rate: scans_bound / scans_total
- sparsity_ratio: voxels_slack / voxels_allocated
- bind_violations: class-binding prerequisite faults
- sequence_inversions: scheduling-order faults among finished scans
- sparsity_tape_ms: absorbed sparsity-wave headroom
- bind_stability_score: weighted bind score total for finished scans
- report_digest: SHA-256 of compact JSON with report_digest empty
- scans: per-scan rows

Each scan row exposes scan_id, class_label, urgency, reserved_voxels, occupied_voxels, spare_voxels, served, class_ready, sequence_rank, sparsity_wave, bind_stability_score.

## Voxel billing

- Positive est_voxels: reserved_voxels follows the estimate; occupied_voxels prefers occupancy_log.csv, else integrated billable volume.
- Zero est_voxels: reserved_voxels and occupied_voxels follow occupancy_log.csv when present, else motion-band billable volume from motion_profile.csv dry peak and wet renew scales blended over the window from origin_slot and wet_after.
- Motion-band rows bill through intensity scales, not raw act_voxels alone; upper_pool yields lower reservations than ground_pool for comparable scans at the same origin_slot.
- spare_voxels: max(0, reserved_voxels - occupied_voxels)
