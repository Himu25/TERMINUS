#!/bin/bash
set -euo pipefail
cd /app
bash /app/scripts/build.sh
/app/bin/scanpack /app/data/scan_manifest.jsonl /app/data/scans_default.jsonl
/app/tools/run_scan
