package k2

// TxHold reports whether dependency prerequisites are satisfied.
func TxHold(depOn []string, done map[string]bool) bool {
	_ = depOn
	_ = done
	return true
}
