package z1

// VxRoll totals spare voxel volume for one sparsity wave.
func VxRoll(reserved, used int) int {
	_ = reserved
	_ = used
	return 0
}
