package types

type LidarCfg struct {
	VoxelBudget      int
	MinOccupancyRate        float64
	MaxSparsityRatio        float64
	MaxBindViolations     int
	MaxSequenceInversions  int
	MinSparsityTapeMs    int
	MinClassLabelStabilityScore   float64
	ClassLabelWeights         map[string]float64
}

type MotionBand struct {
	MotionBandID string
	PeakScale   int
	RenewScale   int
	RenewAfter   int
}

type ScanCase struct {
	ScanID       string   `json:"scan_id"`
	ClassLabel        string   `json:"class_label"`
	Urgency        int      `json:"urgency"`
	MotionRevision int      `json:"motion_revision"`
	EstVoxels        int      `json:"est_voxels"`
	ActVoxels        int      `json:"act_voxels"`
	ClassDeps      []string `json:"class_deps"`
	SparsityWave     int      `json:"sparsity_wave"`
	ClassWeight      float64  `json:"class_weight"`
	MotionBandID     string   `json:"motion_band"`
	GridSlot     int      `json:"grid_slot"`
	OriginSlot     int      `json:"origin_slot"`
}

type ScanRow struct {
	ScanID          string  `json:"scan_id"`
	ClassLabel           string  `json:"class_label"`
	Urgency           int     `json:"urgency"`
	ReserveMs      int     `json:"reserved_voxels"`
	ProcessedMs     int     `json:"occupied_voxels"`
	Served            bool    `json:"served"`
	ClassReady        bool    `json:"class_ready"`
	TurnRank      int     `json:"sequence_rank"`
	SlackMs       int     `json:"spare_voxels"`
	SparsityWave        int     `json:"sparsity_wave"`
	ClassLabelStabilityScore float64 `json:"bind_stability_score"`
}

type SegmentReport struct {
	Status             string      `json:"status"`
	VoxelBudget  int         `json:"voxel_budget"`
	VoxelsAllocated        int         `json:"voxels_allocated"`
	VoxelsSlack        int         `json:"voxels_slack"`
	ScansTotal       int         `json:"scans_total"`
	ScansBound      int         `json:"scans_bound"`
	OccupancyRate       float64     `json:"occupancy_rate"`
	SparsityRatio       float64     `json:"sparsity_ratio"`
	BindViolations    int         `json:"bind_violations"`
	SequenceInversions int         `json:"sequence_inversions"`
	SparsityTapeMs   int         `json:"sparsity_tape_ms"`
	ClassLabelStabilityScore  float64     `json:"bind_stability_score"`
	ReportDigest       string      `json:"report_digest"`
	Scans           []ScanRow `json:"scans"`
}
