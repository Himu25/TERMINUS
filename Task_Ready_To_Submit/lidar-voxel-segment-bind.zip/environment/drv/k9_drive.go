package drv

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"

	"lab.lidar/k2"
	"lab.lidar/pkg/types"
	"lab.lidar/q9"
	"lab.lidar/summ"
	"lab.lidar/u3"
)

func LoadCfg(path string) (types.LidarCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.LidarCfg{}, err
	}
	cfg := types.LidarCfg{
		VoxelBudget:     12000,
		MinOccupancyRate:     0.75,
		MaxSparsityRatio:         0.35,
		MaxBindViolations:      0,
		MaxSequenceInversions: 1,
		MinSparsityTapeMs:      3,
		MinClassLabelStabilityScore:     2.0,
		ClassLabelWeights:           map[string]float64{"class_label_alpha": 1.0, "class_label_beta": 1.0, "class_label_gamma": 1.0},
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "voxel_budget":
			fmt.Sscanf(val, "%d", &cfg.VoxelBudget)
		case "min_occupancy_rate":
			fmt.Sscanf(val, "%f", &cfg.MinOccupancyRate)
		case "max_sparsity_ratio":
			fmt.Sscanf(val, "%f", &cfg.MaxSparsityRatio)
		case "max_bind_violations":
			fmt.Sscanf(val, "%d", &cfg.MaxBindViolations)
		case "max_sequence_inversions":
			fmt.Sscanf(val, "%d", &cfg.MaxSequenceInversions)
		case "min_sparsity_tape_ms":
			fmt.Sscanf(val, "%d", &cfg.MinSparsityTapeMs)
		case "min_bind_stability_score":
			fmt.Sscanf(val, "%f", &cfg.MinClassLabelStabilityScore)
		case "class_label_weight_alpha":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClassLabelWeights["class_label_alpha"] = w
		case "class_label_weight_beta":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClassLabelWeights["class_label_beta"] = w
		case "class_label_weight_gamma":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClassLabelWeights["class_label_gamma"] = w
		}
	}
	return cfg, nil
}

func LoadMotionBands(path string) (map[string]types.MotionBand, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]types.MotionBand)
	for i, row := range rows {
		if i == 0 || len(row) < 4 {
			continue
		}
		var peak, renew, after int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &peak)
		fmt.Sscanf(strings.TrimSpace(row[2]), "%d", &renew)
		fmt.Sscanf(strings.TrimSpace(row[3]), "%d", &after)
		id := strings.TrimSpace(row[0])
		out[id] = types.MotionBand{
			MotionBandID: id,
			PeakScale:  peak,
			RenewScale: renew,
			RenewAfter: after,
		}
	}
	return out, nil
}

func LoadScanCases(path string) ([]types.ScanCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.ScanCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var jc types.ScanCase
		if err := json.Unmarshal([]byte(line), &jc); err != nil {
			return nil, err
		}
		if jc.MotionBandID == "" {
			jc.MotionBandID = "ground_pool"
		}
		out = append(out, jc)
	}
	return out, sc.Err()
}

func LoadOccupancyLog(path string) (map[string]int, error) {
	f, err := os.Open(path)
	if err != nil {
		return map[string]int{}, nil
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]int)
	for i, row := range rows {
		if i == 0 || len(row) < 2 {
			continue
		}
		var actTons int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &actTons)
		out[strings.TrimSpace(row[0])] = actTons
	}
	return out, nil
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

func motionBandFor(jc types.ScanCase, motionBands map[string]types.MotionBand) types.MotionBand {
	if rp, ok := motionBands[jc.MotionBandID]; ok {
		return rp
	}
	return types.MotionBand{MotionBandID: jc.MotionBandID, PeakScale: 100, RenewScale: 100, RenewAfter: 0}
}

func Run(cfg types.LidarCfg, cases []types.ScanCase, occupancyReadings map[string]int, motionBands map[string]types.MotionBand) (types.SegmentReport, error) {
	ordered := q9.RxOrder(cases)
	report := types.SegmentReport{
		Status:            "ok",
		VoxelBudget: cfg.VoxelBudget,
		ScansTotal:         len(ordered),
	}
	done := make(map[string]bool)
	budgetLeft := cfg.VoxelBudget
	var spent, totalWaste, completed, depViol, inversions, renewTotal int
	var valueTotal float64
	prevRank := -1
	report.Scans = make([]types.ScanRow, 0, len(ordered))

	for idx, jc := range ordered {
		actualReady := true
		for _, depID := range jc.ClassDeps {
			if !done[depID] {
				actualReady = false
				break
			}
		}
		depReady := k2.TxHold(jc.ClassDeps, done)
		if len(jc.ClassDeps) > 0 && !actualReady && depReady {
			depViol++
		}
		occupancyReading := 0
		if act, ok := occupancyReadings[jc.ScanID]; ok && act > 0 {
			occupancyReading = act
			jc.ActVoxels = act
		}
		rp := motionBandFor(jc, motionBands)
		billable := motionBillable(jc, occupancyReading, rp)
		reserveNeed := u3.AxNeed(jc.EstVoxels, billable)
		reserved, ok := u3.BxReserve(budgetLeft, reserveNeed)
		headroom := budgetLeft - reserved
		if jc.SparsityWave > 0 {
			renewTotal += sparsityDispatchTotal(jc.SparsityWave, jc.EstVoxels, headroom)
		}
		used := 0
		finished := false
		if ok && depReady {
			used = jc.ActVoxels
			if used <= 0 {
				used = billable
			}
			if used > reserved {
				used = reserved
			}
			budgetLeft -= reserved
			spent += used
			finished = true
			completed++
			done[jc.ScanID] = true
			valueTotal += u3.VxValue(jc.ClassWeight, used)
		}
		wasteAmt := scanSurplus(reserved, used)
		totalWaste += wasteAmt
		rankScore := jc.MotionRevision*10 + jc.Urgency
		if finished {
			if prevRank >= 0 && rankScore > prevRank {
				inversions++
			}
			prevRank = rankScore
		}
		row := types.ScanRow{
			ScanID:          jc.ScanID,
			ClassLabel:           jc.ClassLabel,
			Urgency:       jc.Urgency,
			ReserveMs:  reserved,
			ProcessedMs:      used,
			Served:      finished,
			ClassReady:       depReady,
			TurnRank:   idx + 1,
			SlackMs:     wasteAmt,
			SparsityWave:      jc.SparsityWave,
			ClassLabelStabilityScore: round4(u3.VxValue(jc.ClassWeight, used)),
		}
		report.Scans = append(report.Scans, row)
	}

	report.VoxelsAllocated = spent
	report.VoxelsSlack = totalWaste
	report.ScansBound = completed
	if report.ScansTotal > 0 {
		report.OccupancyRate = round4(float64(completed) / float64(report.ScansTotal))
	}
	if spent > 0 {
		report.SparsityRatio = round4(float64(totalWaste) / float64(spent))
	}
	report.BindViolations = depViol
	report.SequenceInversions = inversions
	report.SparsityTapeMs = renewTotal
	report.ClassLabelStabilityScore = round4(valueTotal)
	hasDispatch := false
	for _, jc := range ordered {
		if jc.SparsityWave > 0 {
			hasDispatch = true
			break
		}
	}
	if !meetsFloors(cfg, report, hasDispatch) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func meetsFloors(cfg types.LidarCfg, report types.SegmentReport, hasDispatch bool) bool {
	if report.OccupancyRate < cfg.MinOccupancyRate {
		return false
	}
	if report.SparsityRatio > cfg.MaxSparsityRatio {
		return false
	}
	if report.BindViolations > cfg.MaxBindViolations {
		return false
	}
	if report.SequenceInversions > cfg.MaxSequenceInversions {
		return false
	}
	if report.SparsityTapeMs < cfg.MinSparsityTapeMs {
		if hasDispatch {
			return false
		}
	}
	if report.ClassLabelStabilityScore < cfg.MinClassLabelStabilityScore {
		return false
	}
	for _, row := range report.Scans {
		if strings.HasPrefix(row.ScanID, "s_class_") && !row.ClassReady && row.Served {
			return false
		}
		if strings.HasPrefix(row.ScanID, "s_sparse_") && row.SparsityWave > 0 && !row.Served {
			return false
		}
		if strings.HasPrefix(row.ScanID, "s_voxel_") && row.SlackMs == 0 && row.ReserveMs > row.ProcessedMs+50 {
			return false
		}
		if strings.HasPrefix(row.ScanID, "s_motion_") && row.Served && row.ProcessedMs > row.ReserveMs+200 {
			return false
		}
	}
	_ = summ.SxFold(report.Scans)
	return true
}

type digestPayload struct {
	Status              string         `json:"status"`
	VoxelBudget   int            `json:"voxel_budget"`
	VoxelsAllocated          int            `json:"voxels_allocated"`
	VoxelsSlack          int            `json:"voxels_slack"`
	ScansTotal           int            `json:"scans_total"`
	ScansBound       int            `json:"scans_bound"`
	OccupancyRate      float64        `json:"occupancy_rate"`
	SparsityRatio          float64        `json:"sparsity_ratio"`
	BindViolations       int            `json:"bind_violations"`
	SequenceInversions  int            `json:"sequence_inversions"`
	SparsityTapeMs    int            `json:"sparsity_tape_ms"`
	ClassLabelStabilityScore   float64        `json:"bind_stability_score"`
	ReportDigest        string         `json:"report_digest"`
	Scans            []types.ScanRow `json:"scans"`
}

func digestBody(report types.SegmentReport) string {
	payload := digestPayload{
		Status:              report.Status,
		VoxelBudget:   report.VoxelBudget,
		VoxelsAllocated:         report.VoxelsAllocated,
		VoxelsSlack:         report.VoxelsSlack,
		ScansTotal:        report.ScansTotal,
		ScansBound:       report.ScansBound,
		OccupancyRate:        report.OccupancyRate,
		SparsityRatio:        report.SparsityRatio,
		BindViolations:     report.BindViolations,
		SequenceInversions:  report.SequenceInversions,
		SparsityTapeMs:    report.SparsityTapeMs,
		ClassLabelStabilityScore:   report.ClassLabelStabilityScore,
		ReportDigest:        "",
		Scans:            report.Scans,
	}
	raw, err := marshalDigestJSON(payload)
	if err != nil {
		return ""
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func marshalDigestJSON(payload digestPayload) ([]byte, error) {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return nil, err
	}
	b := buf.Bytes()
	if n := len(b); n > 0 && b[n-1] == '\n' {
		b = b[:n-1]
	}
	return b, nil
}

func WriteReport(path string, report types.SegmentReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func p95(values []int) int {
	if len(values) == 0 {
		return 0
	}
	cp := append([]int(nil), values...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}
