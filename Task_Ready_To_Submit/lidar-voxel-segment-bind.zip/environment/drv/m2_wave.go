package drv

import "lab.lidar/h4"

func sparsityDispatchTotal(dispatchWave, estTons, headroom int) int {
	if dispatchWave <= 0 {
		return 0
	}
	return h4.UxAbsorb(estTons/4, headroom)
}
