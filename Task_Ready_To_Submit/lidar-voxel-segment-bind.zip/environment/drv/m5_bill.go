package drv

import (
	"lab.lidar/n8"
	"lab.lidar/pkg/types"
	"lab.lidar/z1"
)

func motionBillable(jc types.ScanCase, occupancyReading int, rp types.MotionBand) int {
	dryScale := rp.PeakScale
	wetScale := rp.RenewScale
	wetAfter := rp.RenewAfter
	if occupancyReading > 0 {
		dryScale, wetScale, wetAfter = 100, 100, 0
	}
	roll := n8.LevelSpan(
		jc.EstVoxels, jc.ActVoxels, occupancyReading,
		dryScale, wetScale, wetAfter, jc.GridSlot,
	)
	if roll.Billable > 0 {
		return roll.Billable
	}
	return jc.EstVoxels
}

func scanSurplus(reserved, used int) int {
	return z1.VxRoll(reserved, used)
}
