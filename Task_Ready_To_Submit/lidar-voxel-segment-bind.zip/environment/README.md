3D perception voxel segmentation replay lab. Bundled scan tapes live in `/app/data/scan_manifest.jsonl`. See `/app/docs/architecture.md`.
