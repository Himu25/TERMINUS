package q9

import (
	"sort"

	"lab.lidar/pkg/types"
)

// RxOrder ranks pending scan cases before allocation.
func RxOrder(cases []types.ScanCase) []types.ScanCase {
	out := make([]types.ScanCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		return out[i].EstVoxels < out[j].EstVoxels
	})
	return out
}
