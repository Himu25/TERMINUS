package q9

import "lab.lidar/pkg/types"

// QxShadow mirrors ranking shape for catalog probes (non-dispatch).
func QxShadow(cases []types.ScanCase) []types.ScanCase {
	out := make([]types.ScanCase, len(cases))
	copy(out, cases)
	return out
}
