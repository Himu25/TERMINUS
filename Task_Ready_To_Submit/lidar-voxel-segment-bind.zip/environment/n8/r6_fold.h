#ifndef METER_FOLD_H
#define METER_FOLD_H

#include <stdint.h>

typedef struct {
    int32_t billable;
    int32_t drift_flag;
} FoldOut;

/* Resolve billable volume from level-band scales and the service window. */
FoldOut r6_fold(
    int32_t est,
    int32_t act,
    int32_t overlay,
    int32_t peak_scale,
    int32_t renew_scale,
    int32_t renew_after,
    int32_t origin_slot);

#endif
