package n8

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libr6_level.a -ldl -lm
#include "r6_fold.h"
*/
import "C"

// Roll holds billable volume for one scan row.
type Roll struct {
	Billable  int
	DriftFlag bool
}

// LevelSpan resolves billable volume for a scan row with level-band intensity.
func LevelSpan(est, act, overlay, peakScale, renewScale, renewAfter, startSlot int) Roll {
	ct := C.r6_fold(
		C.int(est), C.int(act), C.int(overlay),
		C.int(peakScale), C.int(renewScale), C.int(renewAfter), C.int(startSlot),
	)
	return Roll{
		Billable:  int(ct.billable),
		DriftFlag: ct.drift_flag != 0,
	}
}

// MeterBatch scores a slice of estimates (decoy helper).
func MeterBatch(estimates []int32) int {
	if len(estimates) == 0 {
		return 0
	}
	sum := 0
	for _, e := range estimates {
		if e > 0 {
			sum += int(e)
		}
	}
	return sum
}
