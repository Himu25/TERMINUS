use std::os::raw::c_int;

#[repr(C)]
pub struct FoldOut {
    pub billable: c_int,
    pub drift_flag: c_int,
}

fn est_chk(est: i32, act: i32) -> bool {
    if est <= 0 {
        return false;
    }
    let delta = (act - est).abs();
    delta * 100 > est * 15
}

#[no_mangle]
pub extern "C" fn r6_fold(
    est: c_int,
    act: c_int,
    overlay: c_int,
    peak_scale: c_int,
    renew_scale: c_int,
    renew_after: c_int,
    origin_slot: c_int,
) -> FoldOut {
    let est_i = est.max(0);
    let act_i = act.max(0);
    let overlay_i = overlay.max(0);
    let _peak = peak_scale.max(1);
    let _renew = renew_scale.max(1);
    let _after = renew_after.max(0);
    let _start = origin_slot.max(0);
    let billable = if overlay_i > 0 { est_i } else { est_i.max(act_i) };
    let flag = if overlay_i > 0 && est_chk(est_i, act_i) {
        1
    } else {
        0
    };
    FoldOut {
        billable,
        drift_flag: flag,
    }
}
