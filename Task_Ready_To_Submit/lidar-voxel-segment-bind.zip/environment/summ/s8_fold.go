package summ

import "lab.lidar/pkg/types"

// SxFold folds scan rows for telemetry export (non-scheduling).
func SxFold(rows []types.ScanRow) int {
	total := 0
	for _, row := range rows {
		total += row.ProcessedMs
	}
	return total
}
