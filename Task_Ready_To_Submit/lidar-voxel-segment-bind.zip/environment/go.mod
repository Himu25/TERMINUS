module lab.lidar

go 1.24
