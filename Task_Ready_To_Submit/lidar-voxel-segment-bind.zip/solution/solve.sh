#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/lidar.toml
require_file /app/data/scan_manifest.jsonl
require_file /app/data/motion_profile.csv
require_file /app/data/occupancy_log.csv
mkdir -p /app/bin /app/output

log "apply patched sources"
cp "${ROOT_DIR}/oracle/p2_order.go" /app/q9/p2_order.go
cp "${ROOT_DIR}/oracle/d4_hold.go" /app/k2/d4_hold.go
cp "${ROOT_DIR}/oracle/b7_slot.go" /app/h4/b7_slot.go
cp "${ROOT_DIR}/oracle/w5_roll.go" /app/z1/w5_roll.go
cp "${ROOT_DIR}/oracle/lib.rs" /app/n8/src/lib.rs

log "rebuild dispatcher"
bash /app/scripts/build.sh

log "refresh default scan bundle"
/app/bin/scanpack /app/data/scan_manifest.jsonl /app/data/scans_default.jsonl

log "emit default segment report"
/app/tools/run_scan

log "post-run validation against lidar.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/lidar.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k in ("min_occupancy_rate", "max_sparsity_ratio", "min_bind_stability_score"):
        cfg[k] = float(v)
    elif k.startswith("max_") or k.startswith("min_") or k == "voxel_budget":
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/segment_report.json").read_text())
assert report["status"] == "ok", report
assert report["occupancy_rate"] >= cfg["min_occupancy_rate"]
assert report["sparsity_ratio"] <= cfg["max_sparsity_ratio"]
assert report["bind_violations"] <= cfg["max_bind_violations"]
assert report["sequence_inversions"] <= cfg["max_sequence_inversions"]
assert report["sparsity_tape_ms"] >= cfg["min_sparsity_tape_ms"]
assert report["bind_stability_score"] >= cfg["min_bind_stability_score"]
for row in report["scans"]:
    if row["scan_id"].startswith("s_class_") and row["served"]:
        assert row["class_ready"], row
    if row["scan_id"].startswith("s_sparse_"):
        assert row["served"], row
print("ok", report["occupancy_rate"], report["sparsity_ratio"], report["bind_stability_score"])
PY

log "oracle complete"
