package q9

import (
	"sort"

	"lab.lidar/pkg/types"
)

// RxOrder ranks pending scan cases before allocation.
func RxOrder(cases []types.ScanCase) []types.ScanCase {
	out := make([]types.ScanCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		a, b := out[i], out[j]
		if a.MotionRevision != b.MotionRevision {
			return a.MotionRevision > b.MotionRevision
		}
		if a.Urgency != b.Urgency {
			return a.Urgency > b.Urgency
		}
		if a.ClassWeight != b.ClassWeight {
			return a.ClassWeight > b.ClassWeight
		}
		return a.ScanID < b.ScanID
	})
	return out
}
