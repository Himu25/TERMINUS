package z1

// VxRoll totals spare voxel volume for one sparsity wave.
func VxRoll(reserved, used int) int {
	if reserved <= used {
		return 0
	}
	return reserved - used
}
