package k2

// TxHold reports whether dependency prerequisites are satisfied.
func TxHold(depOn []string, done map[string]bool) bool {
	if len(depOn) == 0 {
		return true
	}
	for _, depID := range depOn {
		if !done[depID] {
			return false
		}
	}
	return true
}
