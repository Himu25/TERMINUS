"""Validate /app/output/segment_report.json against lidar.toml guardrails for scan replay."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "segment_report.json"
TRANSITS = APP / "data" / "scans_default.jsonl"
CFG = APP / "config" / "lidar.toml"
LEVEL_LOG = APP / "data" / "occupancy_log.csv"
CASES = Path(__file__).resolve().parent / "data"

_DEFAULT_TRANSITS_TEXT = TRANSITS.read_text(encoding="utf-8") if TRANSITS.is_file() else ""

REPORT_KEYS = frozenset(
    {
        "status",
        "voxel_budget",
        "voxels_allocated",
        "voxels_slack",
        "scans_total",
        "scans_bound",
        "occupancy_rate",
        "sparsity_ratio",
        "bind_violations",
        "sequence_inversions",
        "sparsity_tape_ms",
        "bind_stability_score",
        "report_digest",
        "scans",
    }
)
ROW_KEYS = frozenset(
    {
        "scan_id",
        "class_label",
        "urgency",
        "reserved_voxels",
        "occupied_voxels",
        "spare_voxels",
        "served",
        "class_ready",
        "sequence_rank",
        "sparsity_wave",
        "bind_stability_score",
    }
)

# MotionBand bill bands: tight enough that peak-only metering fails, wide enough that
# a mostly-correct meter rebuild can land within ~1-3/10 agent trials.
_LEVEL_BLEND_NUM = 86
_LEVEL_BLEND_DEN = 100


def _motion_band_bill_max(scans_text: str) -> int:
    raw = _scan_map_from_text(scans_text)["s_motion_us"]["act_voxels"]
    return (raw * _LEVEL_BLEND_NUM) // _LEVEL_BLEND_DEN


def _assert_motion_band_blend(report: dict, scans_text: str, *, require_status: bool) -> None:
    bill_max = _motion_band_bill_max(scans_text)
    us = next(r for r in report["scans"] if r["scan_id"] == "s_motion_us")
    eu = next(r for r in report["scans"] if r["scan_id"] == "s_motion_eu")
    assert us["served"] and eu["served"]
    assert us["reserved_voxels"] <= bill_max, us
    assert eu["reserved_voxels"] <= bill_max, eu
    assert eu["reserved_voxels"] < us["reserved_voxels"], (us, eu)
    assert eu["occupied_voxels"] < us["occupied_voxels"], (us, eu)
    if require_status:
        assert report["status"] == "ok"


def _load_level_logs() -> dict[str, int]:
    level_logs: dict[str, int] = {}
    if not LEVEL_LOG.is_file():
        return level_logs
    lines = LEVEL_LOG.read_text(encoding="utf-8").splitlines()
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        scan_id, act_voxels = (part.strip() for part in line.split(",", 1))
        level_logs[scan_id] = int(act_voxels)
    return level_logs


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "voxel_budget": 12000,
        "min_occupancy_rate": 0.75,
        "max_sparsity_ratio": 0.35,
        "max_bind_violations": 0,
        "max_sequence_inversions": 1,
        "min_sparsity_tape_ms": 3,
        "min_bind_stability_score": 2.0,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in ("min_occupancy_rate", "max_sparsity_ratio", "min_bind_stability_score"):
            cfg[key] = float(val)
        elif key in (
            "voxel_budget",
            "max_bind_violations",
            "max_sequence_inversions",
            "min_sparsity_tape_ms",
        ):
            cfg[key] = int(float(val))
    return cfg


def _scan_rows_from_text(text: str) -> list[dict]:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def _scan_ids_from_text(text: str) -> list[str]:
    return [row["scan_id"] for row in _scan_rows_from_text(text)]


def _scan_map_from_text(text: str) -> dict[str, dict]:
    return {row["scan_id"]: row for row in _scan_rows_from_text(text)}


def _assert_scans_match_input(report: dict, scans_text: str) -> None:
    expected_ids = _scan_ids_from_text(scans_text)
    report_ids = [row["scan_id"] for row in report["scans"]]
    assert report["scans_total"] == len(expected_ids)
    assert len(report_ids) == len(expected_ids)
    assert set(report_ids) == set(expected_ids)


@pytest.fixture(autouse=True)
def restore_default_scans() -> None:
    yield
    if _DEFAULT_TRANSITS_TEXT:
        _atomic_write_text(TRANSITS, _DEFAULT_TRANSITS_TEXT)


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _swap_fixture(stem: str) -> str:
    src = CASES / f"{stem}.jsonl"
    text = src.read_text(encoding="utf-8")
    _atomic_write_text(TRANSITS, text)
    return text


def _expected_digest(report: dict) -> str:
    payload = dict(report)
    payload["report_digest"] = ""
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _invoke_default() -> None:
    proc = subprocess.run(
        ["/app/tools/run_scan"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "segment_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    _invoke_default()


def test_report_top_level_keys_exact() -> None:
    """Report must expose only the documented top-level keys."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS


def test_scan_row_schema() -> None:
    """Each scan row must match the documented per-row schema."""
    report = _load_report()
    assert report["scans"]
    for row in report["scans"]:
        assert set(row.keys()) == ROW_KEYS
        assert isinstance(row["scan_id"], str) and row["scan_id"]
        assert isinstance(row["class_label"], str) and row["class_label"]
        assert isinstance(row["urgency"], int)
        assert row["reserved_voxels"] >= 0
        assert row["occupied_voxels"] >= 0
        assert row["spare_voxels"] >= 0
        assert isinstance(row["served"], bool)
        assert isinstance(row["class_ready"], bool)
        assert row["sequence_rank"] >= 1
        assert row["sparsity_wave"] >= 0
        assert row["bind_stability_score"] >= 0.0


def test_passing_run_contract() -> None:
    """Default bundle must finish ok and meet lidar.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["voxel_budget"] == cfg["voxel_budget"]
    _assert_scans_match_input(report, _DEFAULT_TRANSITS_TEXT)
    assert report["occupancy_rate"] >= cfg["min_occupancy_rate"]
    assert report["sparsity_ratio"] <= cfg["max_sparsity_ratio"]
    assert report["bind_violations"] <= cfg["max_bind_violations"]
    assert report["sequence_inversions"] <= cfg["max_sequence_inversions"]
    assert report["sparsity_tape_ms"] >= cfg["min_sparsity_tape_ms"]
    assert report["bind_stability_score"] >= cfg["min_bind_stability_score"]


def test_scans_total_matches_input_rows() -> None:
    """Report scan IDs must cover every input JSONL row with no drops or extras."""
    report = _load_report()
    _assert_scans_match_input(report, _DEFAULT_TRANSITS_TEXT)


def test_report_digest_matches_payload() -> None:
    """report_digest must hash the compact pre-digest JSON payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_deterministic_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_dep_rows_finish_in_order() -> None:
    """Dependency chain rows must complete only after prerequisites."""
    report = _load_report()
    ranks = {row["scan_id"]: row["sequence_rank"] for row in report["scans"]}
    assert ranks["s_class_root"] < ranks["s_class_leaf"] < ranks["s_class_chain"]
    for row in report["scans"]:
        if row["scan_id"].startswith("s_class_") and row["served"]:
            assert row["class_ready"] is True, row


def test_prio_hot_ranks_before_cold() -> None:
    """Late priority revision rows must finish before stale low-revision peers."""
    report = _load_report()
    hot = next(r for r in report["scans"] if r["scan_id"] == "s_sparse_hot")
    cold = next(r for r in report["scans"] if r["scan_id"] == "s_sparse_cold")
    assert hot["served"] is True
    assert cold["served"] is True
    assert hot["sequence_rank"] < cold["sequence_rank"], (hot, cold)


def test_drift_accounting_semantics() -> None:
    """Drift rows reserve estimates, bill actuals, and record reserved minus used."""
    report = _load_report()
    inputs = _scan_map_from_text(_DEFAULT_TRANSITS_TEXT)
    level_logs = _load_level_logs()
    for row in report["scans"]:
        if not row["scan_id"].startswith("s_voxel_") or not row["served"]:
            continue
        spec = inputs[row["scan_id"]]
        expected_used = level_logs.get(row["scan_id"], spec["act_voxels"])
        assert row["reserved_voxels"] == spec["est_voxels"]
        assert row["occupied_voxels"] == expected_used
        assert row["spare_voxels"] == max(0, row["reserved_voxels"] - row["occupied_voxels"])


def test_drift_rows_record_waste() -> None:
    """Drift-prone rows with inflated reservations must record spare_voxels."""
    report = _load_report()
    drift_rows = [r for r in report["scans"] if r["scan_id"].startswith("s_voxel_")]
    assert drift_rows
    assert any(r["spare_voxels"] > 0 for r in drift_rows if r["served"])


def test_burst_rows_complete() -> None:
    """Sparsity-wave rows with the s_sparse_ prefix must complete under the default bundle."""
    report = _load_report()
    burst_rows = [r for r in report["scans"] if r["scan_id"].startswith("s_sparse_")]
    assert burst_rows
    assert all(r["served"] for r in burst_rows), burst_rows


def test_scan_rows_respect_intensity() -> None:
    """Motion-band rows must bill through blended intensity, not raw estimates alone."""
    _invoke_default()
    report = _load_report()
    bill_max = _motion_band_bill_max(_DEFAULT_TRANSITS_TEXT)
    us = next(r for r in report["scans"] if r["scan_id"] == "s_motion_us")
    eu = next(r for r in report["scans"] if r["scan_id"] == "s_motion_eu")
    assert us["served"] and eu["served"]
    assert us["reserved_voxels"] <= bill_max, us
    assert eu["reserved_voxels"] <= bill_max, eu
    assert eu["reserved_voxels"] < us["reserved_voxels"], (us, eu)


def test_sparsity_late_row_completes() -> None:
    """Delayed sparsity-wave row j_overlap_late must complete under the default bundle."""
    report = _load_report()
    renew = next(r for r in report["scans"] if r["scan_id"] == "j_overlap_late")
    assert renew["served"] is True
    assert renew["sparsity_wave"] > 0


def test_scenario_motion_chain() -> None:
    """Dependency-chain scenario must schedule deps before dependents."""
    scans_text = _swap_fixture("motion_chain")
    _invoke_default()
    report = _load_report()
    _assert_scans_match_input(report, scans_text)
    assert report["bind_violations"] == 0
    assert report["status"] == "ok"
    ranks = {row["scan_id"]: row["sequence_rank"] for row in report["scans"]}
    assert ranks["s_class_root"] < ranks["s_class_leaf"] < ranks["s_class_chain"]


def test_scenario_priority_flip() -> None:
    """Urgency-flip scenario must schedule late revisions ahead of stale peers."""
    cfg = _parse_cfg()
    scans_text = _swap_fixture("priority_flip")
    _invoke_default()
    report = _load_report()
    _assert_scans_match_input(report, scans_text)
    hot = next(r for r in report["scans"] if r["scan_id"] == "s_sparse_hot")
    cold = next(r for r in report["scans"] if r["scan_id"] == "s_sparse_cold")
    assert hot["sequence_rank"] < cold["sequence_rank"]
    assert report["sequence_inversions"] <= cfg["max_sequence_inversions"]
    assert report["status"] == "ok"


def test_scenario_voxel_drift() -> None:
    """Estimate-drift scenario must keep sparsity_ratio under max_sparsity_ratio."""
    cfg = _parse_cfg()
    scans_text = _swap_fixture("voxel_drift")
    _invoke_default()
    report = _load_report()
    _assert_scans_match_input(report, scans_text)
    inputs = _scan_map_from_text(scans_text)
    for row in report["scans"]:
        if not row["scan_id"].startswith("s_voxel_") or not row["served"]:
            continue
        spec = inputs[row["scan_id"]]
        assert row["reserved_voxels"] == spec["est_voxels"]
        assert row["spare_voxels"] == max(0, row["reserved_voxels"] - row["occupied_voxels"])
        assert row["spare_voxels"] > 0
    assert report["sparsity_ratio"] <= cfg["max_sparsity_ratio"]
    assert report["status"] == "ok"


def test_scenario_dense_patch() -> None:
    """Dense patch scenario must absorb enough sparsity-tape headroom."""
    cfg = _parse_cfg()
    scans_text = _swap_fixture("dense_patch")
    _invoke_default()
    report = _load_report()
    _assert_scans_match_input(report, scans_text)
    burst_rows = [r for r in report["scans"] if r["scan_id"].startswith("s_sparse_")]
    assert burst_rows
    assert all(r["served"] for r in burst_rows)
    assert report["sparsity_tape_ms"] >= cfg["min_sparsity_tape_ms"]
    assert report["status"] == "ok"


def test_scenario_weight_mix() -> None:
    """Need-score mix scenario must meet bind_stability_score floor."""
    cfg = _parse_cfg()
    scans_text = _swap_fixture("weight_mix")
    _invoke_default()
    report = _load_report()
    _assert_scans_match_input(report, scans_text)
    assert report["bind_stability_score"] >= cfg["min_bind_stability_score"]


def test_scenario_occupancy_meter() -> None:
    """Zero-estimate frame-log row must bill act_voxels through the meter."""
    scans_text = _swap_fixture("occupancy_meter")
    _invoke_default()
    report = _load_report()
    _assert_scans_match_input(report, scans_text)
    level_logs = _load_level_logs()
    expected_used = level_logs["s_motion_meter"]
    row = next(r for r in report["scans"] if r["scan_id"] == "s_motion_meter")
    assert row["served"] is True
    assert row["occupied_voxels"] == expected_used
    assert row["reserved_voxels"] == expected_used
    assert row["spare_voxels"] == 0


def test_scenario_scan_mix() -> None:
    """Motion-band variability scenario must bill upper_pool below ground_pool for similar work."""
    scans_text = _swap_fixture("scan_mix")
    _invoke_default()
    report = _load_report()
    _assert_scans_match_input(report, scans_text)
    _assert_motion_band_blend(report, scans_text, require_status=False)


def test_scenario_sparsity_delay() -> None:
    """Delayed sparsity-wave scenario must complete j_overlap_late with sparsity-tape absorption."""
    cfg = _parse_cfg()
    scans_text = _swap_fixture("sparsity_delay")
    _invoke_default()
    report = _load_report()
    _assert_scans_match_input(report, scans_text)
    renew = next(r for r in report["scans"] if r["scan_id"] == "j_overlap_late")
    assert renew["served"] is True
    assert report["sparsity_tape_ms"] >= cfg["min_sparsity_tape_ms"]
    assert report["status"] == "ok"
