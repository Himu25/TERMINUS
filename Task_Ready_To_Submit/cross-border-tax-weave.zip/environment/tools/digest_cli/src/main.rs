use std::env;

use sha2::{Digest, Sha256};

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    let payload = format!(
        "{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|",
        args.get(0).map(String::as_str).unwrap_or(""),
        args.get(1).map(String::as_str).unwrap_or(""),
        args.get(2).map(String::as_str).unwrap_or("0"),
        args.get(3).map(String::as_str).unwrap_or("0"),
        args.get(4).map(String::as_str).unwrap_or("0"),
        args.get(5).map(String::as_str).unwrap_or("0"),
        args.get(6).map(String::as_str).unwrap_or("0"),
        args.get(7).map(String::as_str).unwrap_or("0"),
        args.get(8).map(String::as_str).unwrap_or("0"),
        args.get(9).map(String::as_str).unwrap_or("0"),
    );
    println!("{:x}", Sha256::digest(payload.as_bytes()));
}
