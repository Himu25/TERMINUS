#!/usr/bin/env bash
set -euo pipefail
test -f /app/data/active/bundle.json
test -x /app/scripts/build.sh
