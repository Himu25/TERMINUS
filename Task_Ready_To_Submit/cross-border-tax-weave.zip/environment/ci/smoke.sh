#!/usr/bin/env bash
set -euo pipefail
cd /app && bash /app/scripts/build.sh && TB_TAX_FIXTURE=1 /app/bin/tax_lab
