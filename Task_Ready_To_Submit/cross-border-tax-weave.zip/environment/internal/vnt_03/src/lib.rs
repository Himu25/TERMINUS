use vnt_01::{FxLane, TaxEntry};

use vnt_06::RunTail;
use vnt_04::ShiftLane;
use vnt_02::MemoStore;
use vnt_dec::SpoolCache;
use vnt_07::AdmitPlan;
use vnt_08::TreatyLane;

pub struct ReplayHub {
    store: MemoStore,
    spool: SpoolCache,
}

impl ReplayHub {
    pub fn mk() -> Self {
        Self {
            store: MemoStore::mk(),
            spool: SpoolCache::mk(),
        }
    }

    pub fn duo_check(&self, a: &TaxEntry, b: &TaxEntry, rev: u32) -> bool {
        self.store.duo_hit(a, b, rev)
    }

    pub fn mirror_check(&self, a: &TaxEntry, b: &TaxEntry, rev: u32) -> bool {
        self.spool.probe(a, b, rev)
    }

    pub fn hop_series(&self, lane: FxLane, deltas: &[i32]) -> (FxLane, u32) {
        ShiftLane::serial_hops(lane, deltas)
    }

    pub fn axis_nudge(&self, lane: &mut FxLane, delta: i32) {
        ShiftLane::nudge(lane, delta);
    }

    pub fn treaty_shift(&self, lane: &mut FxLane, treaty_pri: u32, routine_pri: u32) {
        let delta = TreatyLane::shift_delta(treaty_pri, routine_pri);
        if delta != 0 {
            ShiftLane::nudge(lane, delta);
        }
    }

    pub fn filing_ok(&self, atis_tick: u32, deadline: u32, lane_idx: u32) -> bool {
        AdmitPlan::plain(atis_tick, deadline, lane_idx)
    }

    pub fn filing_ok_with_ceil(&self, atis_tick: u32, lane_idx: u32, base: u32, extra: u32) -> bool {
        AdmitPlan::with_span(atis_tick, lane_idx, base, extra)
    }

    pub fn begin_run(&self) {
        RunTail::begin_run();
    }

    pub fn hold_ids(&self, ids: &[u32]) {
        RunTail::hold_ids(ids);
    }

    pub fn read_hold(&self) -> Vec<u32> {
        RunTail::read_hold()
    }

    pub fn pulse_rev(&self, rev: u32) {
        self.store.rev_pulse(rev);
    }

    pub fn tally_len(&self) -> usize {
        self.store.tally_len()
    }

    pub fn spool_len(&self) -> usize {
        self.spool.slot_count()
    }
}

#[cfg(test)]
mod smoke {
    #[test]
    fn mk_core() {
        let core = crate::ReplayHub::mk();
        assert_eq!(core.tally_len(), 0);
        assert_eq!(core.spool_len(), 0);
    }
}
