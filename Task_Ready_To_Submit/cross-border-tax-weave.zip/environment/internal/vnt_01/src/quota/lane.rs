pub fn within(lane_idx: u32, ceiling: u32) -> bool {
    lane_idx <= ceiling
}
