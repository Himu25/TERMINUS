pub fn within(period_tick: u32, ceiling: u32) -> bool {
    period_tick <= ceiling
}
