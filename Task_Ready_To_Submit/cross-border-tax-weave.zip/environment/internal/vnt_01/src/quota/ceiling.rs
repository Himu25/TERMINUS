pub fn compose(base: u32, extra: u32) -> u32 {
    base.saturating_sub(extra)
}
