#[derive(Debug, Clone)]
pub struct LedgerPt {
    pub x: i32,
    pub y: i32,
    pub tick: u32,
}

#[derive(Debug, Clone)]
pub struct TaxEntry {
    pub id: u32,
    pub waypoints: Vec<LedgerPt>,
    pub filing_deadline: u32,
    pub treaty_priority: u32,
}

#[derive(Debug, Clone)]
pub struct FxLane {
    pub waypoints: Vec<LedgerPt>,
    pub rate_link_id: u32,
    pub lane_idx: u32,
}

impl TaxEntry {
    pub fn mk(id: u32, pts: Vec<(i32, i32, u32)>, deadline: u32, priority: u32) -> Self {
        Self {
            id,
            waypoints: pts
                .into_iter()
                .map(|(x, y, tick)| LedgerPt { x, y, tick })
                .collect(),
            filing_deadline: deadline,
            treaty_priority: priority,
        }
    }
}

impl FxLane {
    pub fn from_entry(entry: &TaxEntry) -> Self {
        Self {
            waypoints: entry.waypoints.clone(),
            rate_link_id: entry.id,
            lane_idx: entry.waypoints.last().map(|p| p.tick).unwrap_or(0),
        }
    }
}
