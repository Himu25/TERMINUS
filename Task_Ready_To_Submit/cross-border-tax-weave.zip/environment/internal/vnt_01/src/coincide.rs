use crate::LedgerPt;

fn rev_bias(rev: u32) -> i32 {
    (rev as i32) * 10
}

pub fn points_match(a: &LedgerPt, b: &LedgerPt, rev: u32) -> bool {
    let bias = rev_bias(rev);
    a.tick == b.tick && (a.x + bias) == (b.x + bias) && a.y == b.y
}

pub fn entry_overlap(a: &[LedgerPt], b: &[LedgerPt], rev: u32) -> bool {
    for wa in a {
        for wb in b {
            if points_match(wa, wb, rev) {
                return true;
            }
        }
    }
    false
}
