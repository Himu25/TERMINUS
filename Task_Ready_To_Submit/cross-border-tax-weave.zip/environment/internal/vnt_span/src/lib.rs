use vnt_01::{LedgerPt, TaxEntry};

pub fn rev_shift(rev: u32) -> i32 {
    (rev as i32) * 10
}

pub fn point_hit(a: &LedgerPt, b: &LedgerPt, rev: u32) -> bool {
    let shift = rev_shift(rev);
    a.tick == b.tick && (a.x + shift) == (b.x + shift) && a.y == b.y
}

pub fn pair_overlap(a: &TaxEntry, b: &TaxEntry, rev: u32) -> bool {
    for wa in &a.waypoints {
        for wb in &b.waypoints {
            if point_hit(wa, wb, rev) {
                return true;
            }
        }
    }
    false
}

#[cfg(test)]
mod smoke {
    use vnt_01::TaxEntry;

    #[test]
    fn disjoint_pair() {
        let a = TaxEntry::mk(1, vec![(0, 0, 1)], 5, 1);
        let b = TaxEntry::mk(2, vec![(9, 0, 1)], 5, 1);
        assert!(!crate::pair_overlap(&a, &b, 0));
    }
}
