use std::collections::HashMap;
use std::sync::Mutex;

use vnt_01::TaxEntry;
use vnt_span;

pub struct MemoStore {
    cache_table: Mutex<HashMap<(u32, u32, u32), bool>>,
}

impl MemoStore {
    pub fn mk() -> Self {
        Self {
            cache_table: Mutex::new(HashMap::new()),
        }
    }

    fn id_roll(t: &TaxEntry) -> u32 {
        let mut sig = t.id;
        for wp in &t.waypoints {
            sig = sig
                .wrapping_add(wp.x as u32)
                .wrapping_add(wp.y as u32)
                .wrapping_add(wp.tick);
        }
        sig
    }

    fn duo_key(a: &TaxEntry, b: &TaxEntry, rev: u32) -> (u32, u32, u32) {
        let roll = Self::id_roll(a).wrapping_add(Self::id_roll(b));
        (a.id.min(b.id), a.id.max(b.id), roll)
    }

    fn cache_read(guard: &HashMap<(u32, u32, u32), bool>, key: (u32, u32, u32)) -> Option<bool> {
        guard.get(&key).copied()
    }

    fn cache_store(guard: &mut HashMap<(u32, u32, u32), bool>, key: (u32, u32, u32), hit: bool) {
        guard.insert(key, hit);
    }

    fn duo_scan(a: &TaxEntry, b: &TaxEntry, rev: u32) -> bool {
        vnt_span::pair_overlap(a, b, rev)
    }

    pub fn duo_hit(&self, a: &TaxEntry, b: &TaxEntry, rev: u32) -> bool {
        let key = Self::duo_key(a, b, rev);
        let mut guard = self.cache_table.lock().expect("cache_table");
        if let Some(hit) = Self::cache_read(&guard, key) {
            return hit;
        }
        let hit = Self::duo_scan(a, b, rev);
        Self::cache_store(&mut guard, key, hit);
        hit
    }

    pub fn rev_pulse(&self, _rev: u32) {
    }

    pub fn tally_len(&self) -> usize {
        self.cache_table.lock().expect("cache_table").len()
    }
}

#[cfg(test)]
mod smoke {
    use vnt_01::TaxEntry;

    #[test]
    fn mk_store() {
        let store = crate::MemoStore::mk();
        assert_eq!(store.tally_len(), 0);
    }

    #[test]
    fn scan_disjoint() {
        let store = crate::MemoStore::mk();
        let a = TaxEntry::mk(1, vec![(0, 0, 1)], 5, 1);
        let b = TaxEntry::mk(2, vec![(9, 0, 1)], 5, 1);
        assert!(!store.duo_hit(&a, &b, 0));
    }
}
