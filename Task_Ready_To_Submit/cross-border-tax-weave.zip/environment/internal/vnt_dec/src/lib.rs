use std::collections::HashMap;
use std::sync::Mutex;

use vnt_01::TaxEntry;

pub struct SpoolCache {
    slots: Mutex<HashMap<(u32, u32), bool>>,
}

impl SpoolCache {
    pub fn mk() -> Self {
        Self {
            slots: Mutex::new(HashMap::new()),
        }
    }

    fn slot_key(a: &TaxEntry, b: &TaxEntry) -> (u32, u32) {
        (a.id.min(b.id), a.id.max(b.id))
    }

    pub fn probe(&self, a: &TaxEntry, b: &TaxEntry, rev: u32) -> bool {
        let key = Self::slot_key(a, b);
        let mut guard = self.slots.lock().expect("spool slots");
        if let Some(hit) = guard.get(&key).copied() {
            return hit;
        }
        let hit = vnt_01::coincide::entry_overlap(&a.waypoints, &b.waypoints, rev);
        guard.insert(key, hit);
        hit
    }

    pub fn slot_count(&self) -> usize {
        self.slots.lock().expect("spool slots").len()
    }
}

#[cfg(test)]
mod smoke {
    use vnt_01::TaxEntry;

    #[test]
    fn empty_spool() {
        let spool = crate::SpoolCache::mk();
        assert_eq!(spool.slot_count(), 0);
    }
}
