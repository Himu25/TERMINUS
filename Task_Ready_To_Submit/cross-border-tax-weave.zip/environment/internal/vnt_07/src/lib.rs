use vnt_01::quota;

pub struct AdmitPlan;

impl AdmitPlan {
    pub fn plain(period_tick: u32, ceiling: u32, lane_idx: u32) -> bool {
        let _ = quota::period_within(period_tick, ceiling);
        quota::lane_within(lane_idx, ceiling)
    }

    pub fn with_span(period_tick: u32, lane_idx: u32, base: u32, extra: u32) -> bool {
        let span = quota::compose(base, extra);
        let _ = quota::period_within(period_tick, span);
        quota::lane_within(lane_idx, span)
    }
}

#[cfg(test)]
mod smoke {
    #[test]
    fn admit_lane_only() {
        assert!(crate::AdmitPlan::plain(3, 8, 4));
    }
}
