use std::path::Path;

use vnt_01::{FxLane, TaxEntry};
use vnt_03::ReplayHub;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

#[derive(Debug, Clone, Deserialize)]
pub struct Bundle {
    pub entity_id: String,
    pub jurisdiction_count: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScenarioRow {
    pub name: String,
    pub finish_reason: String,
    pub obligations_found: u32,
    pub credits_applied: u32,
    pub filing_met: u32,
    pub compliant: u32,
    pub treaty_fresh: u32,
    pub carryover_cleared: u32,
    pub fx_stable: u32,
    pub priority_resolved: u32,
    pub digest_hex: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Report {
    pub schema_version: u32,
    pub entity_id: String,
    pub scenarios: Vec<ScenarioRow>,
}

pub fn load_bundle(path: &Path) -> Bundle {
    let raw = std::fs::read_to_string(path).expect("bundle json");
    serde_json::from_str(&raw).expect("bundle parse")
}

pub fn digest_row(row: &ScenarioRow) -> String {
    let payload = format!(
        "{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|",
        row.name,
        row.finish_reason,
        row.obligations_found,
        row.credits_applied,
        row.filing_met,
        row.compliant,
        row.treaty_fresh,
        row.carryover_cleared,
        row.fx_stable,
        row.priority_resolved,
    );
    format!("{:x}", Sha256::digest(payload.as_bytes()))
}

fn seal(mut row: ScenarioRow) -> ScenarioRow {
    row.digest_hex = digest_row(&row);
    row
}

fn entry_to_lane(entry: &TaxEntry) -> FxLane {
    FxLane::from_entry(entry)
}

pub fn run_dual_claim(_bundle: &Bundle) -> ScenarioRow {
    let core = ReplayHub::mk();
    let a = TaxEntry::mk(1, vec![(0, 0, 2), (5, 0, 4)], 10, 1);
    let b = TaxEntry::mk(2, vec![(5, 0, 4), (10, 0, 6)], 10, 1);
    let hit = core.duo_check(&a, &b, 0);
    seal(ScenarioRow {
        name: "case_dual_claim".into(),
        finish_reason: if hit { "complete" } else { "stuck" }.into(),
        obligations_found: if hit { 1 } else { 0 },
        credits_applied: 0,
        filing_met: 0,
        compliant: 0,
        treaty_fresh: 0,
        carryover_cleared: 0,
        fx_stable: 0,
        priority_resolved: 0,
        digest_hex: String::new(),
    })
}

pub fn run_credit_shift(_bundle: &Bundle) -> ScenarioRow {
    let core = ReplayHub::mk();
    let a = TaxEntry::mk(1, vec![(0, 0, 2), (5, 0, 4)], 12, 1);
    let b = TaxEntry::mk(2, vec![(5, 0, 4), (10, 0, 6)], 12, 1);
    let mut lane = entry_to_lane(&a);
    let hit_before = core.duo_check(&a, &b, 0);
    core.axis_nudge(&mut lane, 8);
    let a2 = TaxEntry::mk(1, lane.waypoints.iter().map(|p| (p.x, p.y, p.tick)).collect(), 12, 1);
    let hit_after = core.duo_check(&a2, &b, 0);
    let clean = hit_before && !hit_after;
    seal(ScenarioRow {
        name: "case_credit_shift".into(),
        finish_reason: if clean { "complete" } else { "stuck" }.into(),
        obligations_found: if hit_before { 1 } else { 0 },
        credits_applied: if clean { 1 } else { 0 },
        filing_met: 0,
        compliant: if clean { 1 } else { 0 },
        treaty_fresh: 0,
        carryover_cleared: 0,
        fx_stable: 0,
        priority_resolved: 0,
        digest_hex: String::new(),
    })
}

pub fn run_filing_window(_bundle: &Bundle) -> ScenarioRow {
    let core = ReplayHub::mk();
    let entry = TaxEntry::mk(3, vec![(0, 0, 1), (4, 0, 5)], 8, 2);
    let mut lane = entry_to_lane(&entry);
    lane.lane_idx = 10;
    core.axis_nudge(&mut lane, 2);
    let period = lane.waypoints.last().map(|p| p.tick).unwrap_or(0);
    let ok = core.filing_ok(period, entry.filing_deadline, lane.lane_idx);
    seal(ScenarioRow {
        name: "case_filing_window".into(),
        finish_reason: if ok { "complete" } else { "stuck" }.into(),
        obligations_found: 0,
        credits_applied: 1,
        filing_met: if ok { 1 } else { 0 },
        compliant: 0,
        treaty_fresh: 0,
        carryover_cleared: 0,
        fx_stable: 0,
        priority_resolved: 0,
        digest_hex: String::new(),
    })
}

pub fn run_clean_entity(_bundle: &Bundle) -> ScenarioRow {
    let core = ReplayHub::mk();
    let a = TaxEntry::mk(4, vec![(0, 0, 1), (0, 5, 3)], 10, 1);
    let b = TaxEntry::mk(5, vec![(10, 0, 1), (10, 5, 3)], 10, 1);
    let hit = core.duo_check(&a, &b, 0);
    seal(ScenarioRow {
        name: "case_clean_entity".into(),
        finish_reason: if !hit { "complete" } else { "blocked" }.into(),
        obligations_found: 0,
        credits_applied: 0,
        filing_met: 0,
        compliant: if !hit { 1 } else { 0 },
        treaty_fresh: 0,
        carryover_cleared: 0,
        fx_stable: 0,
        priority_resolved: 0,
        digest_hex: String::new(),
    })
}

pub fn run_credit_chain(_bundle: &Bundle) -> ScenarioRow {
    let core = ReplayHub::mk();
    let a = TaxEntry::mk(6, vec![(0, 0, 2), (5, 0, 4), (10, 0, 6)], 14, 1);
    let b = TaxEntry::mk(7, vec![(5, 0, 4), (5, 5, 6)], 14, 1);
    let lane = entry_to_lane(&a);
    let hit_before = core.duo_check(&a, &b, 0);
    let (shifted, hops) = core.hop_series(lane, &[6, 4]);
    let a2 = TaxEntry::mk(
        6,
        shifted
            .waypoints
            .iter()
            .map(|p| (p.x, p.y, p.tick))
            .collect(),
        14,
        1,
    );
    let hit_after = core.duo_check(&a2, &b, 0);
    let clean = hit_before && !hit_after && hops == 2;
    seal(ScenarioRow {
        name: "case_credit_chain".into(),
        finish_reason: if clean { "complete" } else { "partial" }.into(),
        obligations_found: if hit_before { 1 } else { 0 },
        credits_applied: hops,
        filing_met: 0,
        compliant: if clean { 1 } else { 0 },
        treaty_fresh: 0,
        carryover_cleared: 0,
        fx_stable: 0,
        priority_resolved: 0,
        digest_hex: String::new(),
    })
}

pub fn run_peak_filings(bundle: &Bundle) -> ScenarioRow {
    let core = ReplayHub::mk();
    let count = bundle.jurisdiction_count.max(4);
    let mut entries = Vec::new();
    for i in 0..count {
        let x = (i as i32) * 3;
        entries.push(TaxEntry::mk(
            100 + i,
            vec![(x, 0, 2), (x + 2, 0, 4)],
            20,
            1,
        ));
    }
    let mut conflicts = 0u32;
    for i in 0..entries.len() {
        for j in (i + 1)..entries.len() {
            if core.duo_check(&entries[i], &entries[j], 0) {
                conflicts += 1;
                let mut lane = entry_to_lane(&entries[i]);
                core.axis_nudge(&mut lane, 15);
                entries[i] = TaxEntry::mk(
                    entries[i].id,
                    lane
                        .waypoints
                        .iter()
                        .map(|p| (p.x, p.y, p.tick))
                        .collect(),
                    20,
                    1,
                );
            }
        }
    }
    let mut residual = 0u32;
    for i in 0..entries.len() {
        for j in (i + 1)..entries.len() {
            let primary = core.duo_check(&entries[i], &entries[j], 0);
            let _mirror = core.mirror_check(&entries[i], &entries[j], 0);
            if primary {
                residual += 1;
            }
        }
    }
    seal(ScenarioRow {
        name: "case_peak_filings".into(),
        finish_reason: if residual == 0 { "complete" } else { "partial" }.into(),
        obligations_found: conflicts,
        credits_applied: conflicts,
        filing_met: 0,
        compliant: if residual == 0 { 1 } else { 0 },
        treaty_fresh: 0,
        carryover_cleared: 0,
        fx_stable: 0,
        priority_resolved: 0,
        digest_hex: String::new(),
    })
}

pub fn run_overlap_regs(_bundle: &Bundle) -> ScenarioRow {
    let core = ReplayHub::mk();
    let a = TaxEntry::mk(8, vec![(0, 0, 3)], 10, 1);
    let b = TaxEntry::mk(9, vec![(10, 0, 3)], 10, 1);
    let miss_rev0 = core.duo_check(&a, &b, 0);
    core.pulse_rev(1);
    let b_shift = TaxEntry::mk(9, vec![(0, 0, 3)], 10, 1);
    let hit_rev1 = core.duo_check(&a, &b_shift, 1);
    let cache_ok = !miss_rev0 && hit_rev1;
    seal(ScenarioRow {
        name: "case_overlap_regs".into(),
        finish_reason: if cache_ok { "complete" } else { "stuck" }.into(),
        obligations_found: if hit_rev1 { 1 } else { 0 },
        credits_applied: 0,
        filing_met: 0,
        compliant: 0,
        treaty_fresh: if cache_ok { 1 } else { 0 },
        carryover_cleared: 0,
        fx_stable: 0,
        priority_resolved: 0,
        digest_hex: String::new(),
    })
}

pub fn run_session_carry(_bundle: &Bundle) -> ScenarioRow {
    let core = ReplayHub::mk();
    core.begin_run();
    let stale_a = TaxEntry::mk(11, vec![(0, 0, 2), (5, 0, 4)], 10, 1);
    let stale_b = TaxEntry::mk(12, vec![(5, 0, 4), (10, 0, 6)], 10, 1);
    if core.duo_check(&stale_a, &stale_b, 0) {
        core.hold_ids(&[stale_a.id, stale_b.id]);
    }
    core.begin_run();
    let fresh_a = TaxEntry::mk(11, vec![(0, 0, 2), (20, 0, 4)], 10, 1);
    let fresh_b = TaxEntry::mk(12, vec![(30, 0, 4), (40, 0, 6)], 10, 1);
    let live_hit = core.duo_check(&fresh_a, &fresh_b, 0);
    let stash = core.read_hold();
    let handled = stash.is_empty() && !live_hit;
    seal(ScenarioRow {
        name: "case_session_carry".into(),
        finish_reason: if handled { "complete" } else { "stuck" }.into(),
        obligations_found: if live_hit { 1 } else { 0 },
        credits_applied: 0,
        filing_met: 0,
        compliant: 0,
        treaty_fresh: 0,
        carryover_cleared: if handled { 1 } else { 0 },
        fx_stable: 0,
        priority_resolved: 0,
        digest_hex: String::new(),
    })
}

pub fn run_bundle_ceil(bundle: &Bundle) -> ScenarioRow {
    let core = ReplayHub::mk();
    let entry = TaxEntry::mk(30, vec![(0, 0, 1), (4, 0, 5)], 8, 2);
    let mut lane = entry_to_lane(&entry);
    lane.lane_idx = 15;
    core.axis_nudge(&mut lane, 2);
    let period = lane.waypoints.last().map(|p| p.tick).unwrap_or(0);
    let ok = core.filing_ok_with_ceil(period, lane.lane_idx, 8, bundle.jurisdiction_count);
    seal(ScenarioRow {
        name: "case_bundle_ceil".into(),
        finish_reason: if ok { "complete" } else { "stuck" }.into(),
        obligations_found: 0,
        credits_applied: 0,
        filing_met: if ok { 1 } else { 0 },
        compliant: 0,
        treaty_fresh: 0,
        carryover_cleared: 0,
        fx_stable: 0,
        priority_resolved: 0,
        digest_hex: String::new(),
    })
}

pub fn run_fx_drift(_bundle: &Bundle) -> ScenarioRow {
    let core = ReplayHub::mk();
    let treaty = TaxEntry::mk(20, vec![(0, 0, 1), (0, 10, 3)], 6, 99);
    let routine = TaxEntry::mk(21, vec![(0, 5, 2), (0, 10, 3)], 12, 1);
    let hit_before = core.duo_check(&treaty, &routine, 0);
    let mut lane = entry_to_lane(&routine);
    core.treaty_shift(&mut lane, treaty.treaty_priority, routine.treaty_priority);
    let routine2 = TaxEntry::mk(
        21,
        lane.waypoints.iter().map(|p| (p.x, p.y, p.tick)).collect(),
        12,
        1,
    );
    let hit_after = core.duo_check(&treaty, &routine2, 0);
    let cleared = hit_before && !hit_after;
    seal(ScenarioRow {
        name: "case_fx_drift".into(),
        finish_reason: if cleared { "complete" } else { "blocked" }.into(),
        obligations_found: if hit_before { 1 } else { 0 },
        credits_applied: if cleared { 1 } else { 0 },
        filing_met: 0,
        compliant: if cleared { 1 } else { 0 },
        treaty_fresh: 0,
        carryover_cleared: 0,
        fx_stable: if cleared { 1 } else { 0 },
        priority_resolved: if cleared { 1 } else { 0 },
        digest_hex: String::new(),
    })
}

pub fn run_triple_hop(_bundle: &Bundle) -> ScenarioRow {
    let core = ReplayHub::mk();
    let a = TaxEntry::mk(40, vec![(0, 0, 2), (5, 0, 4), (10, 0, 6), (15, 0, 8)], 16, 1);
    let b = TaxEntry::mk(41, vec![(5, 0, 4), (5, 5, 6), (10, 5, 8)], 16, 1);
    let lane = entry_to_lane(&a);
    let hit_before = core.duo_check(&a, &b, 0);
    let (shifted, hops) = core.hop_series(lane, &[5, 4, 3]);
    let a2 = TaxEntry::mk(
        40,
        shifted
            .waypoints
            .iter()
            .map(|p| (p.x, p.y, p.tick))
            .collect(),
        16,
        1,
    );
    let hit_after = core.duo_check(&a2, &b, 0);
    let clean = hit_before && !hit_after && hops == 3;
    seal(ScenarioRow {
        name: "case_triple_hop".into(),
        finish_reason: if clean { "complete" } else { "partial" }.into(),
        obligations_found: if hit_before { 1 } else { 0 },
        credits_applied: hops,
        filing_met: 0,
        compliant: if clean { 1 } else { 0 },
        treaty_fresh: 0,
        carryover_cleared: 0,
        fx_stable: 0,
        priority_resolved: 0,
        digest_hex: String::new(),
    })
}

pub fn run_rev_chain(_bundle: &Bundle) -> ScenarioRow {
    let core = ReplayHub::mk();
    let a = TaxEntry::mk(50, vec![(0, 0, 3)], 10, 1);
    let b0 = TaxEntry::mk(51, vec![(10, 0, 3)], 10, 1);
    let miss_r0 = core.duo_check(&a, &b0, 0);
    core.pulse_rev(1);
    let b1 = TaxEntry::mk(51, vec![(0, 0, 3)], 10, 1);
    let hit_r1 = core.duo_check(&a, &b1, 1);
    core.pulse_rev(2);
    let b2 = TaxEntry::mk(51, vec![(20, 0, 3)], 10, 1);
    let miss_r2 = core.duo_check(&a, &b2, 2);
    let fresh = !miss_r0 && hit_r1 && !miss_r2;
    seal(ScenarioRow {
        name: "case_rev_chain".into(),
        finish_reason: if fresh { "complete" } else { "stuck" }.into(),
        obligations_found: if hit_r1 { 1 } else { 0 },
        credits_applied: 0,
        filing_met: 0,
        compliant: 0,
        treaty_fresh: if fresh { 1 } else { 0 },
        carryover_cleared: 0,
        fx_stable: 0,
        priority_resolved: 0,
        digest_hex: String::new(),
    })
}

pub fn run_named(name: &str, bundle: &Bundle) -> ScenarioRow {
    match name {
        "case_dual_claim" => run_dual_claim(bundle),
        "case_credit_shift" => run_credit_shift(bundle),
        "case_filing_window" => run_filing_window(bundle),
        "case_clean_entity" => run_clean_entity(bundle),
        "case_credit_chain" => run_credit_chain(bundle),
        "case_peak_filings" => run_peak_filings(bundle),
        "case_overlap_regs" => run_overlap_regs(bundle),
        "case_session_carry" => run_session_carry(bundle),
        "case_fx_drift" => run_fx_drift(bundle),
        "case_bundle_ceil" => run_bundle_ceil(bundle),
        "case_triple_hop" => run_triple_hop(bundle),
        "case_rev_chain" => run_rev_chain(bundle),
        other => seal(ScenarioRow {
            name: other.into(),
            finish_reason: "unknown".into(),
            obligations_found: 0,
            credits_applied: 0,
            filing_met: 0,
            compliant: 0,
            treaty_fresh: 0,
            carryover_cleared: 0,
            fx_stable: 0,
            priority_resolved: 0,
            digest_hex: String::new(),
        }),
    }
}

pub fn run_bundle(bundle: &Bundle, names: &[String]) -> Report {
    let scenarios = names.iter().map(|n| run_named(n, bundle)).collect();
    Report {
        schema_version: 2,
        entity_id: bundle.entity_id.clone(),
        scenarios,
    }
}
