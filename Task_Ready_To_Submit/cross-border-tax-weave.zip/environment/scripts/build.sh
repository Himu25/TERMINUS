#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:${PATH}"
cd /app
mkdir -p /app/bin /app/output

target_root="${CARGO_TARGET_DIR:-/app/target}"

cargo build --locked --release -p vnt_drv --bin tax_lab
install -m 0755 "${target_root}/release/tax_lab" /app/bin/tax_lab
cargo build --locked --release --bin digest_cli
install -m 0755 "${target_root}/release/digest_cli" /app/bin/digest_cli
