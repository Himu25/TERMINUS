# cross-border-tax-weave

Rust workspace for multinational tax obligation reconciliation replay.

Build: `/app/scripts/build.sh`
Lab: `/app/bin/tax_lab`
Output: `/app/output/tax_report.json`
