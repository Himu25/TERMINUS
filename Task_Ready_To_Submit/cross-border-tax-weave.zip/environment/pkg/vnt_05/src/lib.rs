use vnt_01::FxLane;

pub struct LinkKeeper;

impl LinkKeeper {
    pub fn after_hop(lane: &mut FxLane) {
        lane.rate_link_id = 0;
    }

    pub fn hop_allowed(lane: &FxLane, hops_done: u32) -> bool {
        lane.rate_link_id != 0 || hops_done == 0
    }
}

#[cfg(test)]
mod smoke {
    use vnt_01::{FxLane, LedgerPt};

    use crate::LinkKeeper;

    #[test]
    fn fresh_lane_allows_first_hop() {
        let lane = FxLane {
            waypoints: vec![LedgerPt { x: 0, y: 0, tick: 1 }],
            rate_link_id: 7,
            lane_idx: 1,
        };
        assert!(LinkKeeper::hop_allowed(&lane, 0));
    }
}
