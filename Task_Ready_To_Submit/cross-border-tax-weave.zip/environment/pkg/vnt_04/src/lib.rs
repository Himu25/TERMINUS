use vnt_01::FxLane;

use vnt_05::LinkKeeper;

pub struct ShiftLane;

impl ShiftLane {
    fn hop_once(mut lane: FxLane, delta: i32) -> FxLane {
        for wp in &mut lane.waypoints {
            wp.x += delta;
        }
        LinkKeeper::after_hop(&mut lane);
        lane
    }

    fn offset_lane(lane: &mut FxLane, delta: i32) {
        for wp in &mut lane.waypoints {
            wp.x += delta;
        }
    }

    pub fn serial_hops(mut lane: FxLane, deltas: &[i32]) -> (FxLane, u32) {
        let mut hops = 0u32;
        for &delta in deltas {
            if !LinkKeeper::hop_allowed(&lane, hops) {
                break;
            }
            lane = Self::hop_once(lane, delta);
            hops += 1;
        }
        (lane, hops)
    }

    pub fn nudge(lane: &mut FxLane, delta: i32) {
        Self::offset_lane(lane, delta);
    }

    pub fn hop_count(deltas: &[i32]) -> u32 {
        deltas.len() as u32
    }
}

#[cfg(test)]
mod smoke {
    use vnt_01::{FxLane, LedgerPt};

    use crate::ShiftLane;

    #[test]
    fn nudge_lane() {
        let mut lane = FxLane {
            waypoints: vec![LedgerPt { x: 1, y: 2, tick: 3 }],
            rate_link_id: 9,
            lane_idx: 3,
        };
        ShiftLane::nudge(&mut lane, 4);
        assert_eq!(lane.waypoints[0].x, 5);
    }

    #[test]
    fn hop_count_len() {
        assert_eq!(ShiftLane::hop_count(&[1, 2, 3]), 3);
    }
}
