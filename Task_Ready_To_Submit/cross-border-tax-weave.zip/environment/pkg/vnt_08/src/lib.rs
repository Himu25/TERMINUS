pub struct TreatyLane;

impl TreatyLane {
    pub fn priority_wins(treaty_pri: u32, routine_pri: u32) -> bool {
        treaty_pri > routine_pri
    }

    pub fn shift_delta(treaty_pri: u32, routine_pri: u32) -> i32 {
        if Self::priority_wins(treaty_pri, routine_pri) {
            10
        } else {
            0
        }
    }
}

#[cfg(test)]
mod smoke {
    #[test]
    fn treaty_beats_routine() {
        assert!(crate::TreatyLane::priority_wins(99, 1));
    }
}
