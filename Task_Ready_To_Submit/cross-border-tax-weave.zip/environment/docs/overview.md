Cross-border tax reconciliation replay lab.

The harness models entity ledgers as tick-indexed obligation paths. Overlap detection applies a
revision-dependent zone shift across internal span helpers. Credit planning chains FX hops through
conversion lanes and link keepers. Period and lane admission checks route through a separate admit
plan layer comparing ticks and indices against bundle-derived spans. Session id lists record blocked
entity ids across delayed telemetry passes.

The workspace splits ledger geometry, overlap memo stores, spool caches, conversion utilities,
orchestration hubs, treaty priority helpers, and per-run session state across several internal and
pkg crates wired through the driver. Typical failure modes include stale cache reuse, broken multi-hop
ownership, span limit mismatches, insufficient priority shifts, and session ids carried into later
passes.

Run `/app/scripts/build.sh` then `/app/bin/tax_lab` with TB_TAX_FIXTURE=1.
