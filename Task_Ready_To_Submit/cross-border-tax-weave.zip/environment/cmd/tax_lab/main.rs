//! tax_lab writes /app/output/tax_report.json with schema_version 2,
//! entity_id, scenarios[] where each row has name, finish_reason,
//! obligations_found, credits_applied, filing_met, compliant,
//! treaty_fresh, carryover_cleared, fx_stable, priority_resolved, digest_hex.

use std::env;
use std::fs;
use std::path::PathBuf;

use vnt_drv::{load_bundle, run_bundle};

fn read_stems(path: &PathBuf) -> Vec<String> {
    let raw = fs::read_to_string(path).expect("scenario index");
    raw.lines()
        .map(str::trim)
        .filter(|line| !line.is_empty() && !line.starts_with('#'))
        .map(str::to_string)
        .collect()
}

fn main() {
    let bundle_path = PathBuf::from("/app/data/active/bundle.json");
    let bundle = load_bundle(&bundle_path);
    let mut names = vec![
        "case_dual_claim".to_string(),
        "case_credit_shift".to_string(),
        "case_filing_window".to_string(),
        "case_clean_entity".to_string(),
        "case_peak_filings".to_string(),
    ];
    if env::var("TB_TAX_FIXTURE").ok().as_deref() == Some("1") {
        let stems = read_stems(&PathBuf::from("/app/docs/scenario_index.txt"));
        names.extend(stems);
    }
    names.sort();
    names.dedup();

    let report = run_bundle(&bundle, &names);
    fs::create_dir_all("/app/output").expect("output dir");
    let encoded = serde_json::to_string_pretty(&report).expect("encode report");
    fs::write("/app/output/tax_report.json", encoded).expect("write report");
}
