"""Verifier for cross-border-tax-weave reconciliation reports."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "tax_report.json"
BIN = "/app/bin/tax_lab"
ACTIVE_BUNDLE = APP / "data" / "active" / "bundle.json"
STEM_INDEX = APP / "docs" / "scenario_index.txt"

SCHEMA_VERSION = 2
FINISH_COMPLETE = "complete"

REQUIRED_TOP_FIELDS = ("schema_version", "entity_id", "scenarios")
REQUIRED_ROW_FIELDS = (
    "name",
    "finish_reason",
    "obligations_found",
    "credits_applied",
    "filing_met",
    "compliant",
    "treaty_fresh",
    "carryover_cleared",
    "fx_stable",
    "priority_resolved",
    "digest_hex",
)

# PUBLIC (~70%): dual claim, credit shift, filing window, clean entity, chain, peak.
PUBLIC_EXPECTED = {
    "case_dual_claim": {
        "finish_reason": FINISH_COMPLETE,
        "obligations_found": 1,
    },
    "case_credit_shift": {
        "finish_reason": FINISH_COMPLETE,
        "compliant": 1,
        "credits_applied": 1,
    },
    "case_filing_window": {
        "finish_reason": FINISH_COMPLETE,
        "filing_met": 1,
    },
    "case_clean_entity": {
        "finish_reason": FINISH_COMPLETE,
        "obligations_found": 0,
        "compliant": 1,
    },
    "case_credit_chain": {
        "finish_reason": FINISH_COMPLETE,
        "credits_applied": 2,
        "compliant": 1,
    },
    "case_peak_filings": {
        "finish_reason": FINISH_COMPLETE,
        "compliant": 1,
    },
}

# HIDDEN (~30%): overlapping regulations, session carryover, FX drift, bundle ceiling.
HIDDEN_EXPECTED = {
    "case_overlap_regs": {
        "finish_reason": FINISH_COMPLETE,
        "treaty_fresh": 1,
        "obligations_found": 1,
    },
    "case_session_carry": {
        "finish_reason": FINISH_COMPLETE,
        "carryover_cleared": 1,
    },
    "case_fx_drift": {
        "finish_reason": FINISH_COMPLETE,
        "fx_stable": 1,
        "priority_resolved": 1,
        "compliant": 1,
    },
    "case_bundle_ceil": {
        "finish_reason": FINISH_COMPLETE,
        "filing_met": 1,
    },
    "case_triple_hop": {
        "finish_reason": FINISH_COMPLETE,
        "credits_applied": 3,
        "compliant": 1,
    },
    "case_rev_chain": {
        "finish_reason": FINISH_COMPLETE,
        "treaty_fresh": 1,
        "obligations_found": 1,
    },
}


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    """Build tax_lab once for the verifier session."""
    env = {**os.environ}
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _expected_row_digest(row: dict) -> str:
    """Compute row digest independently of agent-editable workspace binaries."""
    payload = (
        f"{row['name']}|{row['finish_reason']}|"
        f"{row['obligations_found']}|{row['credits_applied']}|"
        f"{row['filing_met']}|{row['compliant']}|"
        f"{row['treaty_fresh']}|{row['carryover_cleared']}|"
        f"{row['fx_stable']}|{row['priority_resolved']}|"
    )
    proc = subprocess.run(
        ["sha256sum"],
        input=payload,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _run_lab(extra_env: dict | None = None) -> dict:
    env = {
        **os.environ,
        "TB_TAX_FIXTURE": "1",
    }
    if extra_env:
        env.update(extra_env)
    subprocess.run([BIN], cwd="/app", env=env, check=True)
    return json.loads(OUT.read_text())


def _by_name(report: dict) -> dict[str, dict]:
    return {row["name"]: row for row in report["scenarios"]}


def _load_stems() -> list[str]:
    lines = STEM_INDEX.read_text().splitlines()
    return [line.strip() for line in lines if line.strip() and not line.startswith("#")]


def test_report_schema_and_entity() -> None:
    """Report uses schema version 2 and the active entity id."""
    report = _run_lab()
    assert report["schema_version"] == SCHEMA_VERSION
    bundle = json.loads(ACTIVE_BUNDLE.read_text())
    assert report["entity_id"] == bundle["entity_id"]
    assert len(report["scenarios"]) >= 12


def test_report_contains_required_fields() -> None:
    """Top-level and per-scenario report rows include every schema field."""
    report = _run_lab()
    for field in REQUIRED_TOP_FIELDS:
        assert field in report
    for row in report["scenarios"]:
        for field in REQUIRED_ROW_FIELDS:
            assert field in row


def test_dual_claim_finds_obligation() -> None:
    """Two entities sharing a ledger period register an obligation."""
    row = _by_name(_run_lab())["case_dual_claim"]
    ex = PUBLIC_EXPECTED["case_dual_claim"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["obligations_found"] == ex["obligations_found"]


def test_credit_shift_clears_conflict() -> None:
    """An FX credit hop clears an overlap and marks compliant."""
    row = _by_name(_run_lab())["case_credit_shift"]
    ex = PUBLIC_EXPECTED["case_credit_shift"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["compliant"] == ex["compliant"]
    assert row["credits_applied"] == ex["credits_applied"]


def test_filing_window_preserved() -> None:
    """Filing-window stem keeps filing_met after a small shift."""
    row = _by_name(_run_lab())["case_filing_window"]
    ex = PUBLIC_EXPECTED["case_filing_window"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["filing_met"] == ex["filing_met"]


def test_clean_entity_no_obligation() -> None:
    """Separated entities report zero obligations and compliant."""
    row = _by_name(_run_lab())["case_clean_entity"]
    ex = PUBLIC_EXPECTED["case_clean_entity"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["obligations_found"] == ex["obligations_found"]
    assert row["compliant"] == ex["compliant"]


def test_credit_chain_both_hops() -> None:
    """Two-hop credit chain applies both shifts and clears the overlap."""
    row = _by_name(_run_lab())["case_credit_chain"]
    ex = PUBLIC_EXPECTED["case_credit_chain"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["credits_applied"] == ex["credits_applied"]
    assert row["compliant"] == ex["compliant"]


def test_peak_filings_complete() -> None:
    """Peak filings stem finishes without residual overlaps."""
    row = _by_name(_run_lab())["case_peak_filings"]
    ex = PUBLIC_EXPECTED["case_peak_filings"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["compliant"] == ex["compliant"]


def test_hidden_overlap_regs_cache() -> None:
    """Regulation revision bump invalidates stale treaty memo entries."""
    row = _by_name(_run_lab())["case_overlap_regs"]
    ex = HIDDEN_EXPECTED["case_overlap_regs"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["treaty_fresh"] == ex["treaty_fresh"]
    assert row["obligations_found"] == ex["obligations_found"]


def test_hidden_session_carry() -> None:
    """Session carryover edge: begin_run clears prior stash before re-checking entities."""
    row = _by_name(_run_lab())["case_session_carry"]
    ex = HIDDEN_EXPECTED["case_session_carry"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["carryover_cleared"] == ex["carryover_cleared"]


def test_hidden_fx_drift_priority() -> None:
    """Cross-module edge: priority treaty insert shifts routine ledger aside with stable FX."""
    row = _by_name(_run_lab())["case_fx_drift"]
    ex = HIDDEN_EXPECTED["case_fx_drift"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["fx_stable"] == ex["fx_stable"]
    assert row["priority_resolved"] == ex["priority_resolved"]
    assert row["compliant"] == ex["compliant"]


def test_hidden_bundle_ceil_filing() -> None:
    """Bundle-derived ceiling lets period pass when lane index exceeds composed limit."""
    row = _by_name(_run_lab())["case_bundle_ceil"]
    ex = HIDDEN_EXPECTED["case_bundle_ceil"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["filing_met"] == ex["filing_met"]


def test_hidden_triple_hop_chain() -> None:
    """Three-hop credit chain applies every planned delta and clears overlap."""
    row = _by_name(_run_lab())["case_triple_hop"]
    ex = HIDDEN_EXPECTED["case_triple_hop"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["credits_applied"] == ex["credits_applied"]
    assert row["compliant"] == ex["compliant"]


def test_hidden_rev_chain_fresh() -> None:
    """Revision chain invalidates stale memo slots across consecutive bumps."""
    row = _by_name(_run_lab())["case_rev_chain"]
    ex = HIDDEN_EXPECTED["case_rev_chain"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["treaty_fresh"] == ex["treaty_fresh"]
    assert row["obligations_found"] == ex["obligations_found"]


def test_regression_stems_complete() -> None:
    """Every stem listed in scenario_index finishes complete."""
    report = _run_lab()
    rows = _by_name(report)
    for stem in _load_stems():
        assert rows[stem]["finish_reason"] == FINISH_COMPLETE


def test_row_digests_seal_outcomes() -> None:
    """Each scenario digest_hex seals the pipe-delimited outcome fields."""
    report = _run_lab()
    for row in report["scenarios"]:
        assert row["digest_hex"] == _expected_row_digest(row)
        assert len(row["digest_hex"]) == 64
        assert row["digest_hex"] == row["digest_hex"].lower()


def test_rust_unit_tests_pass() -> None:
    """Workspace unit tests must pass after the fix."""
    proc = subprocess.run(
        ["cargo", "test", "--locked", "--workspace", "--quiet"],
        cwd="/app",
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout
