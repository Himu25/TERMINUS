#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/app/bin:${PATH}"

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

patch -p1 -d /app < "${ROOT_DIR}/patches/vnt_02.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/vnt_05.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/vnt_07.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/vnt_06.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/vnt_01.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/vnt_08.patch"

bash /app/scripts/build.sh
TB_TAX_FIXTURE=1 /app/bin/tax_lab
