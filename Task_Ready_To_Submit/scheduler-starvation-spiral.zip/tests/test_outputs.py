"""Verifier for scheduler starvation spiral audit."""

import json
import os
import shutil
import subprocess

import pytest
from pathlib import Path

APP = Path("/app")
ACTIVE = APP / "data" / "active" / "run_alpha"
FIXTURES = APP / "data" / "replay"
OUT = APP / "output" / "scheduler_audit.json"
GO_BIN = "/usr/local/go/bin/go"
VERIFY_BIN = "/tmp/scheduler_audit_verify_bin"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)
    subprocess.run(["cp", "/app/bin/scheduler_audit", VERIFY_BIN], check=True)


def _digest_hex(
    run_id: str,
    tick_count: int,
    total_wait: int,
    max_starve: int,
    debt: int,
    inv: int,
    burst: int,
    thr: int,
    rebal: int,
    stale: int,
    starve_hits: int,
) -> str:
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            run_id,
            str(tick_count),
            str(total_wait),
            str(max_starve),
            str(debt),
            str(inv),
            str(burst),
            str(thr),
            str(rebal),
            str(stale),
            str(starve_hits),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _op_t(priority: int, granted: int, floor: int, band: int) -> int:
    if priority < band:
        return 0
    d = floor - granted
    return d if d > 0 else 0


def _op_w(wait: int, oscillation: int, floor: int) -> int:
    if oscillation == 1:
        return min(wait, floor)
    return wait


def _op_f(invert_flag: int) -> int:
    return 1 if invert_flag == 1 else 0


def _op_g(burst: int, granted: int, cap: int) -> int:
    if burst != 1:
        return 0
    return 1 if granted > cap else 0


def _op_h(lane: int, prev: int, first: bool) -> int:
    if first:
        return 0
    return 1 if lane != prev else 0


def _fold_thr(base: int, granted: int) -> int:
    return base + granted


def _starve_gap(priority: int, wait_eff: int, granted: int, band: int) -> int:
    if priority < band:
        return 0
    gap = wait_eff - granted
    return gap if gap > 0 else 0


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = FIXTURES / pack_name
    bundle = json.loads((pack_dir / "queue_bundle.json").read_text())
    rows = []
    for line in (pack_dir / "ticks.jsonl").read_text().splitlines():
        if line.strip():
            rows.append(json.loads(line))
    rows.sort(key=lambda r: r["seq"])

    total_wait = 0
    max_starve = 0
    debt = 0
    inv = 0
    burst = 0
    thr = 0
    rebal = 0
    starve_hits = 0
    ticks = 0
    prev_lane = 0
    first_lane = True

    for row in rows:
        if row["seq"] <= 0:
            continue
        ticks += 1
        wait_eff = _op_w(row["wait_slots"], row["oscillation"], bundle["fair_floor_slots"])
        total_wait += wait_eff
        gap = _starve_gap(
            row["priority"], wait_eff, row["granted_slots"], bundle["low_prio_band"]
        )
        max_starve = max(max_starve, gap)
        debt += _op_t(
            row["priority"],
            row["granted_slots"],
            bundle["fair_floor_slots"],
            bundle["low_prio_band"],
        )
        inv += _op_f(row["invert_flag"])
        burst += _op_g(
            row["burst_phase"], row["granted_slots"], bundle["burst_cap_slots"]
        )
        thr = _fold_thr(thr, row["granted_slots"])
        rebal += _op_h(row["lane_id"], prev_lane, first_lane)
        prev_lane = row["lane_id"]
        first_lane = False
        if gap > bundle["starvation_threshold_slots"]:
            starve_hits += 1

    tick_count = bundle["tick_count"] if bundle["tick_count"] > 0 else ticks
    stale = (
        1
        if bundle["active_revision"] < bundle["schedule_revision"]
        else 0
    )

    digest = _digest_hex(
        bundle["run_id"],
        tick_count,
        total_wait,
        max_starve,
        debt,
        inv,
        burst,
        thr,
        rebal,
        stale,
        starve_hits,
    )
    return {
        "schema_version": "1",
        "run_id": bundle["run_id"],
        "tick_count": tick_count,
        "total_wait_slots": total_wait,
        "max_starvation_slots": max_starve,
        "fairness_debt_total": debt,
        "inversion_events": inv,
        "burst_penalty_count": burst,
        "throughput_units": thr,
        "rebalance_shifts": rebal,
        "schedule_stale_flag": stale,
        "starvation_hits": starve_hits,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    dest = ACTIVE
    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(src, dest)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_SCHEDULER_AUDIT": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_alpha_report_matches_replay() -> None:
    """Active run_alpha pack should replay all scheduler counters including digest."""
    _swap("run_alpha")
    exp = _expected_from_fixture("run_alpha")
    got = _run_tool()
    assert got == exp


def test_alpha_total_wait_matches_replay() -> None:
    """Alpha pack total wait slots should match oscillation-clipped replay."""
    _swap("run_alpha")
    exp = _expected_from_fixture("run_alpha")
    got = _run_tool()
    assert got["total_wait_slots"] == exp["total_wait_slots"]


def test_burst_flood_penalties_match_replay() -> None:
    """Burst flood pack should count only over-cap burst grants."""
    _swap("burst_flood_a")
    exp = _expected_from_fixture("burst_flood_a")
    got = _run_tool()
    assert got["burst_penalty_count"] == exp["burst_penalty_count"]
    assert got["starvation_hits"] == exp["starvation_hits"]


def test_tail_starve_max_gap_matches_replay() -> None:
    """Long-tail starvation pack should match max starvation slots."""
    _swap("tail_starve_b")
    exp = _expected_from_fixture("tail_starve_b")
    got = _run_tool()
    assert got["max_starvation_slots"] == exp["max_starvation_slots"]
    assert got["fairness_debt_total"] == exp["fairness_debt_total"]


def test_prio_flip_inversions_match_replay() -> None:
    """Priority inversion pack should count every invert_flag row."""
    _swap("prio_flip_c")
    exp = _expected_from_fixture("prio_flip_c")
    got = _run_tool()
    assert got["inversion_events"] == exp["inversion_events"]


def test_rebalance_shifts_match_replay() -> None:
    """Queue rebalance stress pack should count lane changes and stale schedule."""
    _swap("rebalance_stress_d")
    exp = _expected_from_fixture("rebalance_stress_d")
    got = _run_tool()
    assert got["rebalance_shifts"] == exp["rebalance_shifts"]
    assert got["schedule_stale_flag"] == exp["schedule_stale_flag"]


def test_alpha_throughput_matches_replay() -> None:
    """Alpha pack throughput units should match faircore fold replay."""
    _swap("run_alpha")
    exp = _expected_from_fixture("run_alpha")
    got = _run_tool()
    assert got["throughput_units"] == exp["throughput_units"]


def test_alpha_fairness_debt_matches_replay() -> None:
    """Alpha pack fairness debt should match low-band floor accounting."""
    _swap("run_alpha")
    exp = _expected_from_fixture("run_alpha")
    got = _run_tool()
    assert got["fairness_debt_total"] == exp["fairness_debt_total"]


def test_go_subsystem_tests_pass() -> None:
    """Go tests under /app must pass after the repair."""
    subprocess.run(
        [
            GO_BIN,
            "test",
            "./pkg/tiergap",
            "./pkg/waveclip",
            "./pkg/flipwatch",
            "./pkg/floodgate",
            "./pkg/shiftlane",
        ],
        cwd="/app",
        env={
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        },
        check=True,
    )
