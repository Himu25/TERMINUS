#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

sed -i 's/d := granted - floor/d := floor - granted/' pkg/tiergap/op_t.go

cat > pkg/waveclip/op_w.go <<'EOF'
package waveclip

// OpW scales wait slots when the queue is oscillating.
func OpW(wait, oscillation, floor int) int {
	if oscillation == 1 {
		if wait < floor {
			return wait
		}
		return floor
	}
	return wait
}
EOF

cat > pkg/flipwatch/op_f.go <<'EOF'
package flipwatch

// OpF counts priority-inversion signals on a tick row.
func OpF(invertFlag, priority int) int {
	_ = priority
	if invertFlag == 1 {
		return 1
	}
	return 0
}
EOF

cat > pkg/floodgate/op_g.go <<'EOF'
package floodgate

// OpG records burst-phase penalties for a tick row.
func OpG(burstPhase, granted, cap int) int {
	if burstPhase != 1 {
		return 0
	}
	if granted > cap {
		return 1
	}
	return 0
}
EOF

cat > pkg/shiftlane/op_h.go <<'EOF'
package shiftlane

// OpH counts lane movement for rebalance accounting.
func OpH(lane, prev int, first bool) int {
	if first {
		return 0
	}
	if lane != prev {
		return 1
	}
	return 0
}
EOF

sed -i 's/base - granted/base + granted/' faircore/src/lib.rs

sed -i 's/func laneRoll(lane int) int/func laneRoll(lane, prev int, first bool) int/' internal/engine/slot_tally.go
sed -i 's/return shiftlane.OpH(lane, 0, true)/return shiftlane.OpH(lane, prev, first)/' internal/engine/slot_tally.go

sed -i 's/ticks := 0/ticks := 0\n\tprevLane := 0\n\tfirstLane := true/' internal/engine/replay.go
sed -i 's/rebalance += laneRoll(row.LaneID)/rebalance += laneRoll(row.LaneID, prevLane, firstLane)/' internal/engine/replay.go
sed -i '/rebalance += laneRoll(row.LaneID, prevLane, firstLane)/a\
\t\tprevLane = row.LaneID\
\t\tfirstLane = false' internal/engine/replay.go
sed -i 's/gap >= bundle.StarvationThresholdSlots/gap > bundle.StarvationThresholdSlots/' internal/engine/replay.go

bash /app/scripts/build.sh

GOFLAGS=-mod=mod CGO_ENABLED=1 go test ./pkg/tiergap ./pkg/waveclip ./pkg/flipwatch ./pkg/floodgate ./pkg/shiftlane -count=1

rm -f /app/output/scheduler_audit.json
TB_SCHEDULER_AUDIT=1 /app/bin/scheduler_audit
test -s /app/output/scheduler_audit.json
