// Report JSON for /app/output/scheduler_audit.json:
//
// schema_version — string, always "1"
// run_id — string, echoes active pack name
// tick_count — scheduler ticks in the bundle schedule (seq > 0 rows)
// total_wait_slots — sum of per-tick effective wait slots after oscillation clipping
// max_starvation_slots — largest wait-minus-granted gap for jobs in the low-priority band
// fairness_debt_total — sum of per-tick fairness debt for the low-priority band
// inversion_events — count of priority-inversion signals on tick rows
// burst_penalty_count — count of burst-phase rows whose granted slots exceed burst_cap_slots
// throughput_units — running fold of granted slots through the faircore helper
// rebalance_shifts — count of lane changes between consecutive tick rows
// schedule_stale_flag — 1 when active revision lags schedule revision, else 0
// starvation_hits — tick rows whose starvation gap exceeds starvation_threshold_slots
// digest_hex — lowercase hex SHA-256 of run_id|tick_count|total_wait_slots|max_starvation_slots|
//   fairness_debt_total|inversion_events|burst_penalty_count|throughput_units|rebalance_shifts|
//   schedule_stale_flag|starvation_hits
//
// Root object contains only these keys.
//
// Replay sorts ticks by seq. Control rows with seq zero are ignored.
// Effective wait uses oscillation clipping from the bundle fair_floor_slots.
// Fairness debt applies only when priority is at or above low_prio_band.
// Burst penalties apply only when burst_phase is set and granted slots exceed burst_cap_slots.
// Inversion events count every tick row with invert_flag set.
// Rebalance shifts increment when lane_id changes from the previous tick row.
// Schedule stale is active revision strictly below schedule revision.
// Starvation hits use a gap strictly greater than starvation_threshold_slots.
package main

import (
	"log"
	"os"

	"lab.local/scheduler_starvation_spiral/internal/driver"
)

func main() {
	if os.Getenv("TB_SCHEDULER_AUDIT") != "1" {
		log.Fatal("TB_SCHEDULER_AUDIT unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/scheduler_audit.json", rep); err != nil {
		log.Fatal(err)
	}
}
