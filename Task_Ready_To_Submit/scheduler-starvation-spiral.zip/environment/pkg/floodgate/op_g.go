package floodgate

// OpG records burst-phase penalties for a tick row.
func OpG(burstPhase, granted, cap int) int {
	if burstPhase == 1 {
		return 1
	}
	return 0
}
