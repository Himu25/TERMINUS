package floodgate

import "testing"

func TestOpGIdle(t *testing.T) {
	if OpG(0, 3, 2) != 0 {
		t.Fatal("expected zero outside burst")
	}
}

func TestOpGOnlyOverCap(t *testing.T) {
	if OpG(1, 3, 2) != 1 {
		t.Fatal("expected penalty when granted exceeds cap")
	}
	if OpG(1, 2, 2) != 0 {
		t.Fatal("expected no penalty at cap")
	}
}
