package tiergap

// OpT accrues fairness debt for jobs in the low-priority band.
func OpT(priority, granted, floor, band int) int {
	if priority < band {
		return 0
	}
	d := granted - floor
	if d <= 0 {
		return 0
	}
	return d
}
