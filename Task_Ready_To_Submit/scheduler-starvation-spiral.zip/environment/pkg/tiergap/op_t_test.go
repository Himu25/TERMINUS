package tiergap

import "testing"

func TestOpTLowBandZero(t *testing.T) {
	if OpT(3, 0, 2, 7) != 0 {
		t.Fatal("expected zero debt below band")
	}
}

func TestOpTDebtWhenUnderServed(t *testing.T) {
	if OpT(8, 1, 2, 7) != 1 {
		t.Fatal("expected debt when granted is below floor")
	}
}
