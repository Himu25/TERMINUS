package gen

// Row is one scheduler tick from the pack log.
type Row struct {
	Seq          int `json:"seq"`
	Tick         int `json:"tick"`
	Priority     int `json:"priority"`
	WaitSlots    int `json:"wait_slots"`
	GrantedSlots int `json:"granted_slots"`
	BurstPhase   int `json:"burst_phase"`
	InvertFlag   int `json:"invert_flag"`
	LaneID       int `json:"lane_id"`
	Oscillation  int `json:"oscillation"`
}
