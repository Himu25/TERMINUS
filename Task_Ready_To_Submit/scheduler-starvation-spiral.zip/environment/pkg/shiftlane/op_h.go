package shiftlane

// OpH counts lane movement for rebalance accounting.
func OpH(lane, prev int, first bool) int {
	_ = prev
	_ = first
	if lane < 0 {
		lane = -lane
	}
	return lane
}
