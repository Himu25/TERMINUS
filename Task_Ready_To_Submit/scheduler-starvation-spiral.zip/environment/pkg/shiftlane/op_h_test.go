package shiftlane

import "testing"

func TestOpHFirstRow(t *testing.T) {
	if OpH(3, 0, true) != 0 {
		t.Fatal("expected zero on first lane row")
	}
}

func TestOpHLaneChange(t *testing.T) {
	if OpH(2, 1, false) != 1 {
		t.Fatal("expected shift when lane changes")
	}
}
