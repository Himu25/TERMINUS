package waveclip

// OpW scales wait slots when the queue is oscillating.
func OpW(wait, oscillation, floor int) int {
	if oscillation == 1 {
		return wait * 2
	}
	return wait
}
