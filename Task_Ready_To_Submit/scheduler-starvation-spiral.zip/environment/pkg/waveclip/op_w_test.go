package waveclip

import "testing"

func TestOpWNoOscillation(t *testing.T) {
	if OpW(5, 0, 2) != 5 {
		t.Fatal("expected unchanged wait")
	}
}

func TestOpWClipsOscillation(t *testing.T) {
	if OpW(4, 1, 2) != 2 {
		t.Fatal("expected clipped wait under oscillation")
	}
}
