package digest

import (
	"crypto/sha256"
	"fmt"
	"strings"
)

// FoldReport hashes the pipe-delimited audit counters.
func FoldReport(runID string, fields ...string) string {
	payload := runID + "|" + strings.Join(fields, "|")
	sum := sha256.Sum256([]byte(payload))
	return fmt.Sprintf("%x", sum)
}
