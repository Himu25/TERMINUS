package flipwatch

import "testing"

func TestOpFNoInvert(t *testing.T) {
	if OpF(0, 8) != 0 {
		t.Fatal("expected zero without invert flag")
	}
}

func TestOpFInvertAnyBand(t *testing.T) {
	if OpF(1, 8) != 1 {
		t.Fatal("expected inversion count for high band row")
	}
}
