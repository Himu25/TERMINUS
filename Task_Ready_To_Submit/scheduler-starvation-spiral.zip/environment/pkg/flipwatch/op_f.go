package flipwatch

// OpF counts priority-inversion signals on a tick row.
func OpF(invertFlag, priority int) int {
	if invertFlag != 1 {
		return 0
	}
	if priority <= 3 {
		return 1
	}
	return 0
}
