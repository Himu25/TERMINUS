module lab.local/scheduler_starvation_spiral

go 1.22
