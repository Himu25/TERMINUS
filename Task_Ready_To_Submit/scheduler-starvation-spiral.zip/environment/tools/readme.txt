Verifier helpers include /tmp/scheduler_audit_verify_bin and /app/tools/digest_cli for digest recomputation.
Package tests invoke /usr/local/go/bin/go with PATH prefixed by /usr/local/cargo/bin for CGO builds.
Subsystem tests run ./pkg/tiergap ./pkg/waveclip ./pkg/flipwatch ./pkg/floodgate after /app/scripts/build.sh.
Verifier pytest runs use python -m pytest with packages from /opt/verifier-requirements.txt baked into the image.
