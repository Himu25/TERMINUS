package main

import (
	"fmt"
	"os"

	"lab.local/scheduler_starvation_spiral/pkg/digest"
)

func main() {
	if len(os.Args) != 12 {
		fmt.Fprintln(os.Stderr, "usage: digest_cli run_id tick_count total_wait max_starve debt inv burst thr rebal stale starve_hits")
		os.Exit(2)
	}
	fmt.Println(digest.FoldReport(
		os.Args[1], os.Args[2], os.Args[3], os.Args[4], os.Args[5],
		os.Args[6], os.Args[7], os.Args[8], os.Args[9], os.Args[10], os.Args[11],
	))
}
