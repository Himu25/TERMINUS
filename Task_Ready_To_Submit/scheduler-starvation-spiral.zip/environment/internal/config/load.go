package config

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"lab.local/scheduler_starvation_spiral/pkg/gen"
)

// Bundle describes one scheduler replay pack.
type Bundle struct {
	RunID                   string `json:"run_id"`
	TickCount               int    `json:"tick_count"`
	FairFloorSlots          int    `json:"fair_floor_slots"`
	BurstCapSlots           int    `json:"burst_cap_slots"`
	StarvationThresholdSlots int    `json:"starvation_threshold_slots"`
	ScheduleRevision        int    `json:"schedule_revision"`
	ActiveRevision          int    `json:"active_revision"`
	LowPrioBand             int    `json:"low_prio_band"`
}

// ActivePaths returns the active pack directory under appRoot.
func ActivePaths(appRoot string) (string, error) {
	dir := filepath.Join(appRoot, "data", "active", "run_alpha")
	if st, err := os.Stat(dir); err != nil || !st.IsDir() {
		return "", fmt.Errorf("active pack missing: %s", dir)
	}
	return dir, nil
}

// LoadBundle reads queue_bundle.json and ticks.jsonl from dir.
func LoadBundle(dir string) (Bundle, []gen.Row, error) {
	raw, err := os.ReadFile(filepath.Join(dir, "queue_bundle.json"))
	if err != nil {
		return Bundle{}, nil, err
	}
	var bundle Bundle
	if err := json.Unmarshal(raw, &bundle); err != nil {
		return Bundle{}, nil, err
	}
	lines, err := os.ReadFile(filepath.Join(dir, "ticks.jsonl"))
	if err != nil {
		return Bundle{}, nil, err
	}
	var rows []gen.Row
	for _, line := range splitLines(string(lines)) {
		if line == "" {
			continue
		}
		var row gen.Row
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return Bundle{}, nil, err
		}
		rows = append(rows, row)
	}
	return bundle, rows, nil
}

func splitLines(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			out = append(out, s[start:i])
			start = i + 1
		}
	}
	if start < len(s) {
		out = append(out, s[start:])
	}
	return out
}
