package engine

import (
	"lab.local/scheduler_starvation_spiral/faircore"
	"lab.local/scheduler_starvation_spiral/pkg/flipwatch"
	"lab.local/scheduler_starvation_spiral/pkg/floodgate"
	"lab.local/scheduler_starvation_spiral/pkg/shiftlane"
	"lab.local/scheduler_starvation_spiral/pkg/tiergap"
	"lab.local/scheduler_starvation_spiral/pkg/waveclip"
)

func waitRoll(wait, oscillation, floor int) int {
	return waveclip.OpW(wait, oscillation, floor)
}

func debtRoll(priority, granted, floor, band int) int {
	return tiergap.OpT(priority, granted, floor, band)
}

func invertRoll(invertFlag, priority int) int {
	return flipwatch.OpF(invertFlag, priority)
}

func burstRoll(burstPhase, granted, cap int) int {
	return floodgate.OpG(burstPhase, granted, cap)
}

func laneRoll(lane int) int {
	return shiftlane.OpH(lane, 0, true)
}

func thrRoll(base, granted int) int {
	return faircore.Fold(base, granted)
}

func schedBit(schedRev, activeRev int) int {
	if activeRev < schedRev {
		return 1
	}
	return 0
}

func starveGap(priority, waitEff, granted, band int) int {
	if priority < band {
		return 0
	}
	gap := waitEff - granted
	if gap <= 0 {
		return 0
	}
	return gap
}
