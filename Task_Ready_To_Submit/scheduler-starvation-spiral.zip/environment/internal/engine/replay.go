package engine

import (
	"lab.local/scheduler_starvation_spiral/internal/config"
	"lab.local/scheduler_starvation_spiral/pkg/gen"
)

// Outcome is folded counters for one pack replay.
type Outcome struct {
	TickCount            int
	TotalWaitSlots       int
	MaxStarvationSlots   int
	FairnessDebtTotal    int
	InversionEvents      int
	BurstPenaltyCount    int
	ThroughputUnits      int
	RebalanceShifts      int
	ScheduleStaleFlag    int
	StarvationHits       int
}

// Replay executes one active pack through the scheduler audit pipeline.
func Replay(bundle config.Bundle, rows []gen.Row) Outcome {
	sortRows(rows)
	totalWait := 0
	maxStarve := 0
	debt := 0
	inversions := 0
	burstPen := 0
	throughput := 0
	rebalance := 0
	starveHits := 0
	ticks := 0

	for _, row := range rows {
		if row.Seq <= 0 {
			continue
		}
		ticks++
		waitEff := waitRoll(row.WaitSlots, row.Oscillation, bundle.FairFloorSlots)
		totalWait += waitEff
		gap := starveGap(row.Priority, waitEff, row.GrantedSlots, bundle.LowPrioBand)
		if gap > maxStarve {
			maxStarve = gap
		}
		debt += debtRoll(row.Priority, row.GrantedSlots, bundle.FairFloorSlots, bundle.LowPrioBand)
		inversions += invertRoll(row.InvertFlag, row.Priority)
		burstPen += burstRoll(row.BurstPhase, row.GrantedSlots, bundle.BurstCapSlots)
		throughput = thrRoll(throughput, row.GrantedSlots)
		rebalance += laneRoll(row.LaneID)
		if gap >= bundle.StarvationThresholdSlots {
			starveHits++
		}
	}

	tickCount := bundle.TickCount
	if tickCount <= 0 {
		tickCount = ticks
	}
	stale := schedBit(bundle.ScheduleRevision, bundle.ActiveRevision)

	return Outcome{
		TickCount:          tickCount,
		TotalWaitSlots:     totalWait,
		MaxStarvationSlots: maxStarve,
		FairnessDebtTotal:  debt,
		InversionEvents:    inversions,
		BurstPenaltyCount:  burstPen,
		ThroughputUnits:    throughput,
		RebalanceShifts:    rebalance,
		ScheduleStaleFlag:  stale,
		StarvationHits:     starveHits,
	}
}

func sortRows(rows []gen.Row) {
	for i := 0; i < len(rows); i++ {
		for j := i + 1; j < len(rows); j++ {
			if rows[j].Seq < rows[i].Seq {
				rows[i], rows[j] = rows[j], rows[i]
			}
		}
	}
}
