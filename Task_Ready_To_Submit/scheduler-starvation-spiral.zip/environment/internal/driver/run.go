package driver

import (
	"encoding/json"
	"os"

	"lab.local/scheduler_starvation_spiral/internal/config"
	"lab.local/scheduler_starvation_spiral/internal/engine"
	"lab.local/scheduler_starvation_spiral/pkg/digest"
)

// Report is the JSON shape written to /app/output/scheduler_audit.json.
type Report struct {
	SchemaVersion        string `json:"schema_version"`
	RunID                string `json:"run_id"`
	TickCount            int    `json:"tick_count"`
	TotalWaitSlots       int    `json:"total_wait_slots"`
	MaxStarvationSlots   int    `json:"max_starvation_slots"`
	FairnessDebtTotal    int    `json:"fairness_debt_total"`
	InversionEvents      int    `json:"inversion_events"`
	BurstPenaltyCount    int    `json:"burst_penalty_count"`
	ThroughputUnits      int    `json:"throughput_units"`
	RebalanceShifts      int    `json:"rebalance_shifts"`
	ScheduleStaleFlag    int    `json:"schedule_stale_flag"`
	StarvationHits       int    `json:"starvation_hits"`
	DigestHex            string `json:"digest_hex"`
}

// RunActive loads the active pack and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	bundle, rows, err := config.LoadBundle(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(bundle, rows)
	digestHex := digest.FoldReport(
		bundle.RunID,
		itoa(out.TickCount),
		itoa(out.TotalWaitSlots),
		itoa(out.MaxStarvationSlots),
		itoa(out.FairnessDebtTotal),
		itoa(out.InversionEvents),
		itoa(out.BurstPenaltyCount),
		itoa(out.ThroughputUnits),
		itoa(out.RebalanceShifts),
		itoa(out.ScheduleStaleFlag),
		itoa(out.StarvationHits),
	)
	return Report{
		SchemaVersion:      "1",
		RunID:              bundle.RunID,
		TickCount:          out.TickCount,
		TotalWaitSlots:     out.TotalWaitSlots,
		MaxStarvationSlots: out.MaxStarvationSlots,
		FairnessDebtTotal:  out.FairnessDebtTotal,
		InversionEvents:    out.InversionEvents,
		BurstPenaltyCount:  out.BurstPenaltyCount,
		ThroughputUnits:    out.ThroughputUnits,
		RebalanceShifts:    out.RebalanceShifts,
		ScheduleStaleFlag:  out.ScheduleStaleFlag,
		StarvationHits:     out.StarvationHits,
		DigestHex:          digestHex,
	}, nil
}

// EmitReport writes rep to path as compact JSON.
func EmitReport(path string, rep Report) error {
	if err := os.MkdirAll("/app/output", 0o755); err != nil {
		return err
	}
	raw, err := json.Marshal(rep)
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func itoa(v int) string {
	if v == 0 {
		return "0"
	}
	var buf [16]byte
	i := len(buf)
	n := v
	neg := false
	if n < 0 {
		neg = true
		n = -n
	}
	for n > 0 {
		i--
		buf[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		buf[i] = '-'
	}
	return string(buf[i:])
}
