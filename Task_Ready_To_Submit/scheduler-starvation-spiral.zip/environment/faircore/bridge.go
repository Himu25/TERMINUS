package faircore

// #cgo LDFLAGS: -L${SRCDIR}/target/release -lfaircore
// #include "fair_fold.h"
import "C"

// Fold applies the native throughput fold across ticks.
func Fold(base, granted int) int {
	return int(C.fq_slot_fold(C.int32_t(base), C.int32_t(granted)))
}
