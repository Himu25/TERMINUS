/// FqSlotFold folds granted slots into a running throughput tally.
#[no_mangle]
pub extern "C" fn fq_slot_fold(base: i32, granted: i32) -> i32 {
    base - granted
}
