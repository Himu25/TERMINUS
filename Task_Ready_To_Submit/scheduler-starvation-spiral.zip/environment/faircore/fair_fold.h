#pragma once
#include <stdint.h>
int32_t fq_slot_fold(int32_t base, int32_t granted);
