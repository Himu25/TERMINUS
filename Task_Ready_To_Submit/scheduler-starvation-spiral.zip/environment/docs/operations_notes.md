# Operations notes

The scheduler audit harness replays tick logs from `/app/data/active` and indexed packs listed in `replay_index.txt`. Fairness accounting spans Go heuristics and the faircore native fold.
