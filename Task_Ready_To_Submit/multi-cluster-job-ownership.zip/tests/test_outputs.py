"""Verifier for multi-cluster job ownership reconciliation."""

from __future__ import annotations

import csv
import json
import re
import subprocess
from pathlib import Path

APP = Path("/app")
RECON = APP / "reconciliation"
AUTH_PATH = RECON / "authoritative_cluster.txt"
DISP_PATH = RECON / "job_dispositions.csv"
MANIFEST = APP / "jobs" / "manifest.toml"
EXEC_LOG = APP / "logs" / "execution_log.jsonl"
ANCHOR_PATH = APP / "control" / "control_time_anchor.json"
EPOCH_PATH = APP / "control" / "epoch.json"


def _read_cluster_epoch(cluster: str) -> int:
    text = (APP / "clusters" / cluster / "cluster.toml").read_text(encoding="utf-8")
    match = re.search(r"^local_epoch\s*=\s*(\d+)", text, re.MULTILINE)
    assert match, f"missing local_epoch for {cluster}"
    return int(match.group(1))


def _expected_authoritative() -> str:
    alpha = _read_cluster_epoch("alpha")
    beta = _read_cluster_epoch("beta")
    if alpha >= beta:
        return "alpha"
    return "beta"


def _manifest_job_ids() -> list[str]:
    jobs: list[str] = []
    for line in MANIFEST.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line.startswith("id ="):
            jobs.append(line.split("=", 1)[1].strip().strip('"'))
    return sorted(jobs)


def _execution_events() -> list[dict]:
    events: list[dict] = []
    for line in EXEC_LOG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            events.append(json.loads(line))
    return events


def _started_clusters(job_id: str) -> set[str]:
    clusters: set[str] = set()
    for event in _execution_events():
        if event.get("job_id") == job_id and event.get("event") == "started":
            clusters.add(str(event["cluster"]))
    return clusters


def _has_checkpoint(job_id: str) -> bool:
    return any(
        event.get("job_id") == job_id and event.get("event") == "checkpoint"
        for event in _execution_events()
    )


def _is_completed(job_id: str) -> bool:
    return any(
        event.get("job_id") == job_id and event.get("event") == "completed"
        for event in _execution_events()
    )


def _active_jobs(cluster: str) -> set[str]:
    payload = json.loads(
        (APP / "clusters" / cluster / "runner_state.json").read_text(encoding="utf-8")
    )
    return set(payload.get("active_jobs", []))


def _lease_valid(cluster: str, acquired_ms: int, ttl_ms: int) -> bool:
    anchor = json.loads(ANCHOR_PATH.read_text(encoding="utf-8"))["anchor_ms"]
    offset = json.loads(
        (APP / "clusters" / cluster / "clock_offset_ms.json").read_text(encoding="utf-8")
    )["offset_ms"]
    return acquired_ms + ttl_ms >= anchor + offset


def _expected_dispositions(auth: str) -> dict[str, str]:
    dispositions: dict[str, str] = {}
    for job_id in _manifest_job_ids():
        if _is_completed(job_id):
            dispositions[job_id] = "completed"
            continue
        starters = _started_clusters(job_id)
        if len(starters) > 1:
            dispositions[job_id] = "fenced"
            continue
        if _has_checkpoint(job_id):
            dispositions[job_id] = "preserved"
            continue
        if job_id in _active_jobs(auth):
            dispositions[job_id] = "running"
            continue
        demoted = "alpha" if auth == "beta" else "beta"
        if job_id in _active_jobs(demoted) and starters and starters.issubset({demoted}):
            dispositions[job_id] = "reassigned"
            continue
        demoted_leases = json.loads(
            (APP / "clusters" / demoted / "leases.json").read_text(encoding="utf-8")
        )
        if job_id in demoted_leases:
            entry = demoted_leases[job_id]
            if not _lease_valid(demoted, int(entry["acquired_ms"]), int(entry["ttl_ms"])):
                dispositions[job_id] = "reassigned"
                continue
        dispositions[job_id] = "queued"
    return dispositions


def _load_dispositions() -> list[tuple[str, str, str]]:
    rows: list[tuple[str, str, str]] = []
    with DISP_PATH.open(newline="", encoding="utf-8") as handle:
        reader = csv.reader(handle)
        header = next(reader)
        assert header == ["job_id", "owner_cluster", "disposition"]
        for record in reader:
            assert len(record) == 3
            rows.append((record[0], record[1], record[2]))
    rows.sort(key=lambda item: item[0])
    return rows


class TestReconciliationArtifacts:
    def test_authoritative_cluster_matches_epoch_semantics(self) -> None:
        """authoritative_cluster.txt matches highest local_epoch cluster."""
        expected = _expected_authoritative()
        assert AUTH_PATH.is_file(), "missing authoritative_cluster.txt"
        got = AUTH_PATH.read_text(encoding="utf-8").strip()
        assert got == expected

    def test_job_dispositions_sorted_and_owned(self) -> None:
        """job_dispositions.csv covers manifest jobs with single authoritative owner."""
        auth = _expected_authoritative()
        expected = _expected_dispositions(auth)
        rows = _load_dispositions()
        assert rows, "job_dispositions.csv must not be empty"
        assert [row[0] for row in rows] == sorted(row[0] for row in rows)
        seen = [row[0] for row in rows]
        assert seen == _manifest_job_ids()
        for job_id, owner, disposition in rows:
            assert owner == auth, f"{job_id} must be owned by {auth}"
            assert disposition == expected[job_id], f"{job_id} disposition mismatch"


class TestControlAuditors:
    def test_ownership_sync_validate(self) -> None:
        """ownership_sync --validate accepts reconciliation artifacts."""
        subprocess.run(["/app/bin/ownership_sync", "--validate"], check=True, cwd="/app")

    def test_epoch_validator_audit(self) -> None:
        """epoch_validator --audit passes after failover completion."""
        subprocess.run(["/app/bin/epoch_validator", "--audit"], check=True, cwd="/app")

    def test_lease_guard_audit(self) -> None:
        """lease_guard --audit passes with demoted leases revoked."""
        subprocess.run(["/app/bin/lease_guard", "--audit"], check=True, cwd="/app")


class TestSchedulerFencing:
    def test_demoted_scheduler_disabled(self) -> None:
        """Non-authoritative cluster scheduler is disabled."""
        auth = _expected_authoritative()
        demoted = "alpha" if auth == "beta" else "beta"
        text = (APP / "clusters" / demoted / "cluster.toml").read_text(encoding="utf-8")
        assert "scheduler_enabled = false" in text
        auth_text = (APP / "clusters" / auth / "cluster.toml").read_text(encoding="utf-8")
        assert "scheduler_enabled = true" in auth_text

    def test_failover_marked_complete(self) -> None:
        """Control epoch marks failover_completed true."""
        epoch = json.loads(EPOCH_PATH.read_text(encoding="utf-8"))
        assert epoch.get("failover_completed") is True

    def test_lane_markers_sealed(self) -> None:
        """Primary rogue dispatch markers match operations.md sealed targets."""
        auth = _expected_authoritative()
        demoted = "alpha" if auth == "beta" else "beta"

        hush = (APP / "telemetry" / "hush_marker.txt").read_text(encoding="utf-8")
        assert "status=sealed" in hush
        stowaway = (APP / "vendor" / "stowaway.ids").read_text(encoding="utf-8")
        assert "lane=closed" in stowaway
        lane = (APP / "flux" / "t0_lane.map").read_text(encoding="utf-8")
        assert f"{demoted}=closed" in lane
        slot = json.loads((APP / "runtime" / "k7_slot.json").read_text(encoding="utf-8"))
        assert slot.get("k7") == "fenced"
        assert slot.get("slot_owner") == auth
