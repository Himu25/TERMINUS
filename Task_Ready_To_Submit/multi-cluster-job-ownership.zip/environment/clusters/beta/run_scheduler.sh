#!/usr/bin/env bash
set -euo pipefail

cluster_dir="/app/clusters/beta"
enabled="$(grep -E '^scheduler_enabled' "$cluster_dir/cluster.toml" | cut -d= -f2 | tr -d ' ')"
if [[ "$enabled" != "true" ]]; then
  exit 0
fi

echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) beta scheduler tick active=2" >> /app/logs/scheduler_audit.log
