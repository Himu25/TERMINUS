#!/usr/bin/env bash
set -euo pipefail

cluster_dir="/app/clusters/alpha"
enabled="$(grep -E '^scheduler_enabled' "$cluster_dir/cluster.toml" | cut -d= -f2 | tr -d ' ')"
if [[ "$enabled" != "true" ]]; then
  echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) alpha scheduler disabled" >> /app/logs/scheduler_audit.log
  exit 0
fi

if ! grep -q '^status=sealed' /app/telemetry/hush_marker.txt; then
  echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) alpha rogue tick hush=open" >> /app/logs/scheduler_audit.log
fi

if ! grep -q '^lane=closed' /app/vendor/stowaway.ids; then
  echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) alpha stowaway lane dispatch overlap job-102" >> /app/logs/scheduler_audit.log
fi

if grep -q '^alpha=open' /app/flux/t0_lane.map; then
  echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) alpha flux t0_lane demotion incomplete" >> /app/logs/scheduler_audit.log
fi

echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) alpha scheduler tick active=3" >> /app/logs/scheduler_audit.log
