package main

import (
	"encoding/csv"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

type epochDoc struct {
	CurrentEpoch         int    `json:"current_epoch"`
	AuthoritativeCluster string `json:"authoritative_cluster"`
	FailoverCompleted    bool   `json:"failover_completed"`
	ReferenceTsControlMs int64  `json:"reference_ts_control_ms"`
}

type dispositionRow struct {
	JobID        string
	OwnerCluster string
	Disposition  string
}

func readJSON(path string, out any) error {
	raw, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	return json.Unmarshal(raw, out)
}

func readClusterEpoch(cluster string) (int, error) {
	path := filepath.Join("/app/clusters", cluster, "cluster.toml")
	raw, err := os.ReadFile(path)
	if err != nil {
		return 0, err
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "local_epoch") {
			parts := strings.SplitN(line, "=", 2)
			if len(parts) != 2 {
				continue
			}
			var value int
			_, err := fmt.Sscanf(strings.TrimSpace(parts[1]), "%d", &value)
			if err != nil {
				return 0, err
			}
			return value, nil
		}
	}
	return 0, fmt.Errorf("local_epoch missing in %s", path)
}

func pickAuthoritative(epoch epochDoc) (string, error) {
	alphaEpoch, err := readClusterEpoch("alpha")
	if err != nil {
		return "", err
	}
	betaEpoch, err := readClusterEpoch("beta")
	if err != nil {
		return "", err
	}
	if alphaEpoch >= betaEpoch {
		return "alpha", nil
	}
	return "beta", nil
}

func loadDispositions(path string) ([]dispositionRow, error) {
	handle, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer handle.Close()

	reader := csv.NewReader(handle)
	records, err := reader.ReadAll()
	if err != nil {
		return nil, err
	}
	if len(records) < 2 {
		return nil, fmt.Errorf("job_dispositions.csv missing rows")
	}
	header := records[0]
	if len(header) != 3 || header[0] != "job_id" || header[1] != "owner_cluster" || header[2] != "disposition" {
		return nil, fmt.Errorf("unexpected csv header")
	}

	rows := make([]dispositionRow, 0, len(records)-1)
	for _, record := range records[1:] {
		if len(record) != 3 {
			return nil, fmt.Errorf("malformed csv row")
		}
		rows = append(rows, dispositionRow{
			JobID:        record[0],
			OwnerCluster: record[1],
			Disposition:  record[2],
		})
	}
	sort.Slice(rows, func(i, j int) bool { return rows[i].JobID < rows[j].JobID })
	return rows, nil
}

func validateArtifacts() error {
	var epoch epochDoc
	if err := readJSON("/app/control/epoch.json", &epoch); err != nil {
		return err
	}

	chosen, err := pickAuthoritative(epoch)
	if err != nil {
		return err
	}

	authPath := "/app/reconciliation/authoritative_cluster.txt"
	authRaw, err := os.ReadFile(authPath)
	if err != nil {
		return err
	}
	auth := strings.TrimSpace(string(authRaw))
	if auth != chosen {
		return fmt.Errorf("authoritative cluster mismatch")
	}

	rows, err := loadDispositions("/app/reconciliation/job_dispositions.csv")
	if err != nil {
		return err
	}
	for _, row := range rows {
		if row.OwnerCluster != auth {
			return fmt.Errorf("job %s owned by %q not %q", row.JobID, row.OwnerCluster, auth)
		}
	}

	fmt.Println("ownership consistent")
	return nil
}

func main() {
	validate := flag.Bool("validate", false, "validate reconciliation artifacts")
	flag.Parse()

	if *validate {
		if err := validateArtifacts(); err != nil {
			fmt.Fprintf(os.Stderr, "validate failed: %v\n", err)
			os.Exit(1)
		}
		return
	}

	fmt.Fprintf(os.Stderr, "plan_audit: pass --validate after writing reconciliation artifacts\n")
	os.Exit(2)
}
