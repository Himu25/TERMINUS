module ownership_sync

go 1.19
