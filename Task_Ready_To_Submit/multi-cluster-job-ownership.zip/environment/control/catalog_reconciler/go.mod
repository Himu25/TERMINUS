module catalog_reconciler

go 1.19
