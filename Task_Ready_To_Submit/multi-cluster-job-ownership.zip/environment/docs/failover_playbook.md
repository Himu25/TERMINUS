# Failover playbook (v3)

Partial failovers leave the demoted cluster scheduling if the stowaway lane and
telemetry hush marker are not sealed. Always reconcile ownership before re-enabling
either scheduler.

Steps recorded in `/app/logs/failover_events.jsonl` must end with
`failover_completed=true` in `/app/control/epoch.json`.

When two clusters overlap on the same job id, fence the duplicate runner before
assigning preserved work to the authoritative cluster.
