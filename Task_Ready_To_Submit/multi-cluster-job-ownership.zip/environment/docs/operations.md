# Operations notes

Cluster schedulers: `/app/clusters/{alpha,beta}/run_scheduler.sh`

Diagnostic dump: `/app/scripts/dump_cluster_state.sh`

Rust auditors:

- `/app/bin/epoch_validator --audit`
- `/app/bin/lease_guard --audit`

Go control utilities under `/app/control/` build to `/app/bin/`.

Legacy warm/failover helpers under `/app/legacy/` predate the current epoch guard;
prefer docs in `/app/docs` and reconciliation artifacts over those scripts.

Primary lane markers gate rogue dispatch when schedulers were not demoted cleanly.
The alpha scheduler probes telemetry hush and vendor stowaway before ticking; audit
logs under `/app/logs/scheduler_audit.log` note open flux lanes. Text markers include
a header comment pointing at the sealed target table below.

## Primary lane marker sealed targets

After demotion, `<auth>` is the authoritative cluster and `<demoted>` is the other cluster.

| Path | Sealed target |
|------|---------------|
| `/app/telemetry/hush_marker.txt` | `status=sealed` |
| `/app/vendor/stowaway.ids` | `lane=closed` |
| `/app/flux/t0_lane.map` | `<demoted>=closed` |
| `/app/runtime/k7_slot.json` | `k7=fenced`, `slot_owner=<auth>` |

Auxiliary markers under `/app/archive`, `/app/glyph`, `/app/nest`, `/app/silo`, and
`/app/wavefront` are legacy probes and are not checked by the demotion audit.
