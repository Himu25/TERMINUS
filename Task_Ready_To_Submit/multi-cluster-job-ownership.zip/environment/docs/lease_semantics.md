# Lease semantics

Control time anchor lives in `/app/control/control_time_anchor.json` (`anchor_ms`).
Each cluster publishes `clock_offset_ms.json` with `offset_ms` skew versus control.

At anchor **T**, a lease on cluster **C** is **valid** when:

    acquired_ms + ttl_ms >= T + offset_ms(C)

A lease is **stale** when the inequality fails. Stale leases on a demoted cluster
must not block preserved jobs on the authoritative owner.

## Authority

Authoritative cluster is the one with the highest `local_epoch` in
`/app/clusters/*/cluster.toml`. When epochs tie, prefer `alpha`.

The `authoritative_cluster` field in `/app/control/epoch.json` reflects intent from
the last failover attempt and may lag `local_epoch` during partial failovers.

## Reconciliation outputs

Write `/app/reconciliation/authoritative_cluster.txt` (single cluster name) and
`/app/reconciliation/job_dispositions.csv` with header
`job_id,owner_cluster,disposition`. Every `owner_cluster` must equal the
authoritative cluster. Sort rows by `job_id`.

Disposition vocabulary used by control tools:

- `running` — actively executing on the authoritative cluster only
- `fenced` — duplicate execution detected; runner must be stopped
- `preserved` — checkpointed unfinished work carried forward
- `completed` — finished before the incident window
- `queued` — leased but not executing
- `reassigned` — stale lease on demoted cluster, ownership moved

Validate with `/app/bin/ownership_sync --validate` after writing artifacts.
