use std::fs;
use std::process;

fn read_cluster_epoch(cluster: &str) -> i32 {
    let path = format!("/app/clusters/{cluster}/cluster.toml");
    let raw = fs::read_to_string(path).unwrap_or_else(|err| {
        eprintln!("epoch_validator: {err}");
        process::exit(1);
    });
    for line in raw.lines() {
        let line = line.trim();
        if let Some(rest) = line.strip_prefix("local_epoch") {
            let value = rest.trim().trim_start_matches('=').trim();
            return value.parse().unwrap_or(0);
        }
    }
    0
}

fn scheduler_enabled(cluster: &str) -> bool {
    let path = format!("/app/clusters/{cluster}/cluster.toml");
    let raw = fs::read_to_string(path).unwrap_or_default();
    raw.lines().any(|line| line.trim() == "scheduler_enabled = true")
}

fn pick_authoritative() -> String {
    let alpha = read_cluster_epoch("alpha");
    let beta = read_cluster_epoch("beta");
    if alpha >= beta {
        "alpha".to_string()
    } else {
        "beta".to_string()
    }
}

fn failover_completed() -> bool {
    let raw = fs::read_to_string("/app/control/epoch.json").unwrap_or_else(|err| {
        eprintln!("epoch_validator: {err}");
        process::exit(1);
    });
    raw.contains("\"failover_completed\": true")
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if !args.iter().any(|arg| arg == "--audit") {
        eprintln!("epoch_validator: pass --audit after reconciliation");
        process::exit(2);
    }

    let chosen = pick_authoritative();
    let auth_raw = fs::read_to_string("/app/reconciliation/authoritative_cluster.txt")
        .unwrap_or_else(|_| String::new());
    let auth = auth_raw.trim();
    if auth != chosen {
        eprintln!("authoritative cluster mismatch");
        process::exit(1);
    }

    if !failover_completed() {
        eprintln!("control epoch incomplete");
        process::exit(1);
    }

    let demoted = if chosen == "alpha" { "beta" } else { "alpha" };
    if scheduler_enabled(demoted) {
        eprintln!("demoted scheduler still active");
        process::exit(1);
    }

    if !std::path::Path::new("/app/reconciliation/job_dispositions.csv").is_file() {
        eprintln!("missing job_dispositions.csv");
        process::exit(1);
    }

    println!("epoch audit ok");
}
