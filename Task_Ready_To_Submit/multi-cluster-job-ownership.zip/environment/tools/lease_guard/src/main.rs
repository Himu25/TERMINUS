use std::collections::{HashMap, HashSet};
use std::fs;
use std::process;

fn read_anchor() -> i64 {
    let raw = fs::read_to_string("/app/control/control_time_anchor.json").unwrap_or_else(|err| {
        eprintln!("lease_guard: {err}");
        process::exit(1);
    });
    parse_i64_field(&raw, "anchor_ms")
}

fn read_offset(cluster: &str) -> i64 {
    let path = format!("/app/clusters/{cluster}/clock_offset_ms.json");
    let raw = fs::read_to_string(path).unwrap_or_else(|err| {
        eprintln!("lease_guard: {err}");
        process::exit(1);
    });
    parse_i64_field(&raw, "offset_ms")
}

fn parse_i64_field(raw: &str, field: &str) -> i64 {
    let needle = format!("\"{field}\":");
    let rest = raw.split(&needle).nth(1).unwrap_or("");
    rest.chars()
        .skip_while(|ch| !ch.is_ascii_digit() && *ch != '-')
        .take_while(|ch| ch.is_ascii_digit() || *ch == '-')
        .collect::<String>()
        .parse()
        .unwrap_or(0)
}

fn read_authoritative() -> String {
    fs::read_to_string("/app/reconciliation/authoritative_cluster.txt")
        .unwrap_or_default()
        .trim()
        .to_string()
}

fn lease_valid(acquired_ms: i64, ttl_ms: i64, anchor: i64, offset: i64) -> bool {
    acquired_ms + ttl_ms >= anchor + offset
}

fn parse_leases(raw: &str) -> HashMap<String, (i64, i64)> {
    let mut out = HashMap::new();
    for job in ["job-101", "job-102", "job-103", "job-104", "job-105", "job-106"] {
        if !raw.contains(job) {
            continue;
        }
        let segment = raw.split(job).nth(1).unwrap_or("");
        let acquired = parse_i64_field(segment, "acquired_ms");
        let ttl = parse_i64_field(segment, "ttl_ms");
        out.insert(job.to_string(), (acquired, ttl));
    }
    out
}

fn load_dispositions() -> HashMap<String, String> {
    let raw = fs::read_to_string("/app/reconciliation/job_dispositions.csv").unwrap_or_else(|err| {
        eprintln!("lease_guard: {err}");
        process::exit(1);
    });
    let mut rows = HashMap::new();
    for (idx, line) in raw.lines().enumerate() {
        if idx == 0 {
            continue;
        }
        let parts: Vec<&str> = line.split(',').collect();
        if parts.len() == 3 {
            rows.insert(parts[0].to_string(), parts[2].to_string());
        }
    }
    rows
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if !args.iter().any(|arg| arg == "--audit") {
        eprintln!("lease_guard: pass --audit after reconciliation");
        process::exit(2);
    }

    let anchor = read_anchor();
    let auth = read_authoritative();
    if auth.is_empty() {
        eprintln!("missing authoritative cluster");
        process::exit(1);
    }

    let demoted = if auth == "alpha" { "beta" } else { "alpha" };
    let demoted_raw = fs::read_to_string(format!("/app/clusters/{demoted}/leases.json")).unwrap_or_default();
    let demoted_offset = read_offset(demoted);
    for (job, (acquired, ttl)) in parse_leases(&demoted_raw) {
        if lease_valid(acquired, ttl, anchor, demoted_offset) {
            eprintln!("demoted cluster lease still valid");
            process::exit(1);
        }
    }

    let alpha_raw = fs::read_to_string("/app/clusters/alpha/leases.json").unwrap_or_default();
    let beta_raw = fs::read_to_string("/app/clusters/beta/leases.json").unwrap_or_default();
    let alpha_offset = read_offset("alpha");
    let beta_offset = read_offset("beta");
    let mut holders: HashMap<String, HashSet<String>> = HashMap::new();
    for (job, (acquired, ttl)) in parse_leases(&alpha_raw) {
        if lease_valid(acquired, ttl, anchor, alpha_offset) {
            holders.entry(job).or_default().insert("alpha".into());
        }
    }
    for (job, (acquired, ttl)) in parse_leases(&beta_raw) {
        if lease_valid(acquired, ttl, anchor, beta_offset) {
            holders.entry(job).or_default().insert("beta".into());
        }
    }

    let dispositions = load_dispositions();
    for (job, clusters) in holders {
        if clusters.len() > 1 && dispositions.get(&job).map(String::as_str) != Some("fenced") {
            eprintln!("duplicate execution not fenced");
            process::exit(1);
        }
    }

    if dispositions.get("job-103").map(String::as_str) != Some("preserved") {
        eprintln!("checkpointed work not preserved");
        process::exit(1);
    }

    println!("lease audit ok");
}
