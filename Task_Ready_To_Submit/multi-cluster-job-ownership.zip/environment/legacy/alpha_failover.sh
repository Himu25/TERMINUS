#!/usr/bin/env bash
set -euo pipefail

echo "alpha failover stub — demote skipped in INC-8842" >> /app/logs/scheduler_audit.log
grep -q '^scheduler_enabled = true' /app/clusters/alpha/cluster.toml
