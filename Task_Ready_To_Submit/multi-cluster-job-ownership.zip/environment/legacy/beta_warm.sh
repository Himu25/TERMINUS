#!/usr/bin/env bash
set -euo pipefail

echo "beta warm complete epoch bump" >> /app/logs/scheduler_audit.log
sed -i 's/^local_epoch = .*/local_epoch = 8/' /app/clusters/beta/cluster.toml || true
