#!/usr/bin/env bash
set -euo pipefail

echo "=== cluster toml ==="
for cluster in alpha beta; do
  echo "--- $cluster ---"
  cat "/app/clusters/$cluster/cluster.toml"
  echo "clock_offset:" 
  cat "/app/clusters/$cluster/clock_offset_ms.json"
  echo "leases:"
  cat "/app/clusters/$cluster/leases.json"
  echo "runner_state:"
  cat "/app/clusters/$cluster/runner_state.json"
done

echo "=== control epoch ==="
cat /app/control/epoch.json

echo "=== recent execution log ==="
tail -n 20 /app/logs/execution_log.jsonl

echo "=== primary lane markers ==="
echo -n "hush_marker: "
grep -E '^status=' /app/telemetry/hush_marker.txt 2>/dev/null || echo "status=open"
echo -n "stowaway: "
grep -E '^lane=' /app/vendor/stowaway.ids 2>/dev/null || echo "lane=open"
echo "t0_lane:"
cat /app/flux/t0_lane.map
echo -n "k7_slot: "
cat /app/runtime/k7_slot.json
