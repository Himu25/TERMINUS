#!/usr/bin/env bash
set -euo pipefail

# STALE: picks authority from active runner counts, not local_epoch in cluster.toml.

mkdir -p /app/reconciliation

echo "reconcile_ownership: WARNING active-runner heuristic (stale vs local_epoch authority)" >&2

alpha_active="$(grep -o 'job-[0-9][0-9][0-9]' /app/clusters/alpha/runner_state.json | wc -l | tr -d ' ')"
beta_active="$(grep -o 'job-[0-9][0-9][0-9]' /app/clusters/beta/runner_state.json | wc -l | tr -d ' ')"

if (( alpha_active > beta_active )); then
  auth="alpha"
else
  auth="beta"
fi

printf '%s\n' "$auth" > /app/reconciliation/authoritative_cluster.txt

{
  echo "job_id,owner_cluster,disposition"
  echo "job-101,$auth,running"
  echo "job-102,$auth,fenced"
  echo "job-103,$auth,preserved"
  echo "job-104,$auth,completed"
  echo "job-105,$auth,queued"
  echo "job-106,$auth,running"
} > /app/reconciliation/job_dispositions.csv

echo "reconcile_ownership wrote artifacts" >&2
