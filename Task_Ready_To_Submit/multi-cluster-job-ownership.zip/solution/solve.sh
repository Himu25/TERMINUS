#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

cd /app

patch -p1 -d /app < "${ROOT_DIR}/patches/hush_marker.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/stowaway.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/k7_slot.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/t0_lane.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/alpha_scheduler.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/alpha_leases.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/epoch_json.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/readme_ops.patch"

cat > /app/scripts/reconcile_ownership.sh <<'SH'
#!/usr/bin/env bash
set -euo pipefail

mkdir -p /app/reconciliation

read_cluster_epoch() {
  local cluster="$1"
  grep -E '^local_epoch' "/app/clusters/${cluster}/cluster.toml" | cut -d= -f2 | tr -d ' '
}

alpha_epoch="$(read_cluster_epoch alpha)"
beta_epoch="$(read_cluster_epoch beta)"

if (( alpha_epoch >= beta_epoch )); then
  auth="alpha"
else
  auth="beta"
fi

printf '%s\n' "$auth" > /app/reconciliation/authoritative_cluster.txt

started_on() {
  local job="$1"
  local cluster="$2"
  grep -F "\"job_id\":\"${job}\"" /app/logs/execution_log.jsonl | grep -F "\"cluster\":\"${cluster}\"" | grep -q '"event":"started"'
}

checkpointed() {
  local job="$1"
  grep -F "\"job_id\":\"${job}\"" /app/logs/execution_log.jsonl | grep -q '"event":"checkpoint"'
}

completed_job() {
  local job="$1"
  grep -F "\"job_id\":\"${job}\"" /app/logs/execution_log.jsonl | grep -q '"event":"completed"'
}

classify_job() {
  local job="$1"
  local auth_cluster="$2"

  if completed_job "$job"; then
    echo "completed"
    return
  fi

  local alpha_start=1
  local beta_start=1
  started_on "$job" "alpha" || alpha_start=0
  started_on "$job" "beta" || beta_start=0

  if (( alpha_start && beta_start )); then
    echo "fenced"
    return
  fi

  if checkpointed "$job"; then
    echo "preserved"
    return
  fi

  if grep -q "\"${job}\"" "/app/clusters/${auth_cluster}/runner_state.json"; then
    echo "running"
    return
  fi

  demoted_cluster="alpha"
  if [[ "$auth_cluster" == "alpha" ]]; then
    demoted_cluster="beta"
  fi

  if grep -q "\"${job}\"" "/app/clusters/${demoted_cluster}/runner_state.json"; then
    echo "reassigned"
    return
  fi

  if grep -q "\"${job}\"" "/app/clusters/${demoted_cluster}/leases.json"; then
    acquired="$(grep -A2 "\"${job}\"" "/app/clusters/${demoted_cluster}/leases.json" | grep acquired_ms | grep -o '[0-9]\+')"
    ttl="$(grep -A2 "\"${job}\"" "/app/clusters/${demoted_cluster}/leases.json" | grep ttl_ms | grep -o '[0-9]\+')"
    anchor="$(grep -o '[0-9]\+' /app/control/control_time_anchor.json | head -1)"
    offset="$(grep -o '[0-9]\+' "/app/clusters/${demoted_cluster}/clock_offset_ms.json" | head -1)"
    if (( acquired + ttl < anchor + offset )); then
      echo "reassigned"
      return
    fi
  fi

  echo "queued"
}

{
  echo "job_id,owner_cluster,disposition"
  for job in job-101 job-102 job-103 job-104 job-105 job-106; do
    disposition="$(classify_job "$job" "$auth")"
    echo "${job},${auth},${disposition}"
  done
} > /app/reconciliation/job_dispositions.csv

echo "reconcile_ownership wrote artifacts" >&2
SH
chmod 0755 /app/scripts/reconcile_ownership.sh

bash /app/scripts/reconcile_ownership.sh

/app/bin/ownership_sync --validate
/app/bin/epoch_validator --audit
/app/bin/lease_guard --audit

bash /app/clusters/alpha/run_scheduler.sh
bash /app/clusters/beta/run_scheduler.sh
