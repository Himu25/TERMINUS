"""Verifier for five-peer gossip mesh heal report."""

import json
import os
import shutil
import subprocess

import pytest
from collections import defaultdict
from pathlib import Path

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = Path("/tests") / "fixtures"
OUT = APP / "output" / "heal_report.json"
GO_BIN = "/usr/local/go/bin/go"
VERIFY_BIN = "/tmp/gossip_heal_verify_bin"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)
    subprocess.run(["cp", "/app/bin/gossip_heal", VERIFY_BIN], check=True)


def _digest_hex(
    ring_id: str,
    master_epoch: int,
    batch_seq: int,
    repair: int,
    loss: int,
    peers_active: int,
    drift: str,
    view_clean: bool,
) -> str:
    ck = "true" if view_clean else "false"
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/heal_digest",
            ring_id,
            str(master_epoch),
            str(batch_seq),
            str(repair),
            str(loss),
            str(peers_active),
            drift,
            ck,
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _crc16(seq: int, payload: str) -> int:
    s = sum(payload.encode()) & 0xFFFFFFFF
    return (s ^ seq) & 0xFFFF


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = FIXTURES / pack_name
    pack = json.loads((pack_dir / "gossip_pack.json").read_text())
    q = pack["q_size"]
    split_epoch = pack["split_epoch"]
    drift_tight = pack["link_tight_ms"]
    offsets: dict[str, int] = {}
    freezes: list[int] = []
    rows: list[dict] = []
    for mid in pack["peers"]:
        meta = json.loads((pack_dir / "peers" / mid / "meta.json").read_text())
        hold = int(meta.get("stale_hold_ms", 0))
        offsets[mid] = int(meta["clock_skew_ms"]) - hold
        freezes.append(meta["snapshot_mark"])
        seg = pack_dir / "peers" / mid / "rum_001.jsonl"
        if not seg.exists():
            continue
        for line in seg.read_text().splitlines():
            if not line.strip():
                continue
            entry = json.loads(line)
            entry["site"] = mid
            rows.append(entry)
    wm = min(freezes) if freezes else 0
    by_seq: dict[int, list] = defaultdict(list)
    all_rows: dict[int, list] = defaultdict(list)
    for entry in rows:
        all_rows[entry["seq"]].append(entry)
        if entry["seq"] > wm:
            by_seq[entry["seq"]].append(entry)
    accepted: dict[int, int] = {}
    repair = 0
    loss = 0
    live: set[str] = set()
    view_clean = True
    for seq in sorted(by_seq):
        buckets: dict[tuple, list] = defaultdict(list)
        for entry in by_seq[seq]:
            buckets[(entry["epoch"], entry["payload"])].append(entry)
        picked = None
        best_adj = None
        for key, items in buckets.items():
            if len({it["site"] for it in items}) < q:
                continue
            valid = [it for it in items if _crc16(it["seq"], it["payload"]) == it["crc"]]
            if len(valid) < q:
                continue
            adj = min(it["emitted_ms"] - offsets[it["site"]] for it in valid)
            if picked is None or adj < best_adj:
                picked, best_adj = key, adj
        if picked is None:
            loss += 1
            continue
        items = buckets[picked]
        repair += sum(1 for it in items if _crc16(it["seq"], it["payload"]) != it["crc"])
        epoch = picked[0]
        valid = [it for it in items if _crc16(it["seq"], it["payload"]) == it["crc"]]
        if epoch > split_epoch and len({it["site"] for it in valid}) < q:
            view_clean = False
        for it in valid:
            live.add(it["site"])
        accepted[seq] = epoch
    batch_seq = 0
    s = 1
    while True:
        if s <= wm or s in accepted:
            batch_seq = s
            s += 1
        else:
            break
    master_epoch = 0
    for seq, seq_rows in all_rows.items():
        if seq > batch_seq:
            continue
        for entry in seq_rows:
            if seq in accepted and entry["epoch"] == accepted[seq]:
                if _crc16(entry["seq"], entry["payload"]) == entry["crc"] and entry["epoch"] > master_epoch:
                    master_epoch = entry["epoch"]
            elif seq <= wm and entry["epoch"] > master_epoch:
                master_epoch = entry["epoch"]
    spread = max(offsets.values()) - min(offsets.values())
    drift = "tight" if spread <= drift_tight else "wide"
    digest = _digest_hex(
        pack["ring_id"], master_epoch, batch_seq, repair, loss, len(live), drift, view_clean
    )
    return {
        "schema_version": "1",
        "ring_id": pack["ring_id"],
        "master_epoch": master_epoch,
        "batch_seq": batch_seq,
        "dedupe_count": repair,
        "gap_count": loss,
        "peers_active": len(live),
        "skew_band": drift,
        "view_clean": view_clean,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_GOSSIP_FIXTURE": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_alpha_report_matches_quorum_replay() -> None:
    """Alpha pack should reach tight link band with full five-peer chain."""
    _swap("gossip_alpha")
    exp = _expected_from_fixture("gossip_alpha")
    got = _run_tool()
    assert got == exp


def test_beta_report_matches_quorum_replay() -> None:
    """Beta pack applies stale hold smear when folding peer skew for replay."""
    _swap("gossip_beta")
    exp = _expected_from_fixture("gossip_beta")
    got = _run_tool()
    assert got == exp


def test_gamma_loss_after_lone_epoch() -> None:
    """Gamma stops the chain when only one peer carries a high epoch row."""
    _swap("gossip_gamma")
    exp = _expected_from_fixture("gossip_gamma")
    got = _run_tool()
    assert got == exp


def test_delta_high_gap_count() -> None:
    """Delta orphan high sweep should not extend the global chain."""
    _swap("gossip_delta")
    exp = _expected_from_fixture("gossip_delta")
    got = _run_tool()
    assert got == exp


def test_epsilon_dedupe_count_nonzero() -> None:
    """Epsilon should count one checksum reconcile on the winning claim group."""
    _swap("gossip_epsilon")
    exp = _expected_from_fixture("gossip_epsilon")
    got = _run_tool()
    assert got == exp


def test_zeta_batch_seq_watermark() -> None:
    """Zeta should stop the chain at the minimum snapshot mark, not the maximum."""
    _swap("gossip_zeta")
    exp = _expected_from_fixture("gossip_zeta")
    got = _run_tool()
    assert got == exp


def test_go_subsystem_tests_pass() -> None:
    """Go unit tests under /app must pass after the repair."""
    subprocess.run(
        [GO_BIN, "test", "./..."],
        cwd="/app",
        env={**os.environ, "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1", "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", "")},
        check=True,
    )
