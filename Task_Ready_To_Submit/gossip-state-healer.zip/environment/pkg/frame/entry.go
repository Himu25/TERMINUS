package frame

// Row is one append-only rumor line from a peer segment.
type Row struct {
	Seq     uint32 `json:"seq"`
	Epoch   uint32 `json:"epoch"`
	WallMS  int64  `json:"emitted_ms"`
	Payload string `json:"payload"`
	CRC     uint16 `json:"crc"`
	Site    string `json:"site"`
}
