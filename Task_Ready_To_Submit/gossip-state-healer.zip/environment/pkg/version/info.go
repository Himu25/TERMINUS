package version

// ToolingTag identifies the bundled heal tooling revision.
const ToolingTag = "gossip-heal-0.9"
