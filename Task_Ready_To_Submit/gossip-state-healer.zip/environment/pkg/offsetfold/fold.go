package offsetfold

import "lab.local/gossip_state_healer/memgate"

// FoldUnitSkew applies optional hold smear to the recorded clock skew baseline.
func FoldUnitSkew(skewMS int64, radioHoldMS int64) int64 {
	return memgate.ApplySmear(skewMS, radioHoldMS)
}
