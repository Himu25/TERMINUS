package unit

// Profile holds per-peer clock and partition marks.
// ClockSkewMS is subtracted from segment emitted_ms when comparing rows for ordering.
type Profile struct {
	UnitID    string `json:"peer_id"`
	ClockSkewMS    int64  `json:"clock_skew_ms"`
	StaleHoldMS int64  `json:"stale_hold_ms"`
	SnapshotMark uint32 `json:"snapshot_mark"`
}
