package digest

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
)

// ReportHex matches the pipe-separated digest in cmd/gossip_heal.
func ReportHex(
	ringID string,
	masterEpoch, batchSeq, dedupeCount, gapCount, peersActive uint32,
	skewBand string,
	viewClean bool,
) string {
	ck := "true"
	if !viewClean {
		ck = "false"
	}
	raw := fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%s|%s",
		ringID, masterEpoch, batchSeq, dedupeCount, gapCount, peersActive, skewBand, ck,
	)
	sum := sha256.Sum256([]byte(raw))
	return hex.EncodeToString(sum[:])
}
