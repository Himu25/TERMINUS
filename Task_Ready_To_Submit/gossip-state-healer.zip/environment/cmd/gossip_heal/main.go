// Report JSON for /app/output/heal_report.json:
//
// schema_version — string, must be "1"
// ring_id — string, echoes active pack name
// master_epoch — highest epoch in the consistent chain
// batch_seq — highest contiguous sequence included in the chain
// dedupe_count — checksum fixes applied during heal
// gap_count — sweep positions without replica agreement
// peers_active — count of units contributing to accepted rows
// skew_band — string, "tight" or "wide"
// view_clean — boolean (not 0/1 strings)
// digest_hex — lowercase hex SHA-256 of ring_id|master_epoch|batch_seq|dedupe_count|gap_count|peers_active|skew_band|view_clean
//
// Root object contains only these keys.
package main

import (
	"log"
	"os"

	"lab.local/gossip_state_healer/internal/driver"
)

func main() {
	if os.Getenv("TB_GOSSIP_FIXTURE") != "1" {
		log.Fatal("TB_GOSSIP_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/heal_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
