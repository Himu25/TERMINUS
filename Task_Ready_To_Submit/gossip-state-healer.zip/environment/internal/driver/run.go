package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"

	"lab.local/gossip_state_healer/internal/config"
	"lab.local/gossip_state_healer/internal/engine"
)

// RunActive loads the active pack and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	pack, profiles, rows, offsets, err := config.LoadPack(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(pack.RingID, pack.QSize, pack.SplitEpoch, pack.LinkTightMS, profiles, rows, offsets)
	ck := "true"
	if !out.ViewClean {
		ck = "false"
	}
	digest := sha256.Sum256([]byte(fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%s|%s",
		pack.RingID,
		out.MasterEpoch,
		out.BatchSeq,
		out.DedupeCount,
		out.GapCount,
		out.PeersActive,
		out.SkewBand,
		ck,
	)))
	return Report{
		SchemaVersion: "1",
		RingID:        pack.RingID,
		MasterEpoch:     out.MasterEpoch,
		BatchSeq:     out.BatchSeq,
		DedupeCount:   out.DedupeCount,
		GapCount:     out.GapCount,
		PeersActive:   out.PeersActive,
		SkewBand:     out.SkewBand,
		ViewClean:    out.ViewClean,
		DigestHex:     hex.EncodeToString(digest[:]),
	}, nil
}
