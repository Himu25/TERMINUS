package freeze

import (
	"lab.local/gossip_state_healer/pkg/markfold"
	"lab.local/gossip_state_healer/pkg/unit"
)

// Watermark collects partition marks from profiles.
func Watermark(profiles []unit.Profile) int64 {
	marks := make([]int64, 0, len(profiles))
	for _, p := range profiles {
		marks = append(marks, int64(p.SnapshotMark))
	}
	return markfold.OpW(marks)
}
