# Mesh layout

Five peers (`n1`–`n5`) append rumor rows under `/app/data/active/peers/`.
Each peer carries `clock_skew_ms`, optional `stale_hold_ms`, and a `snapshot_mark` watermark in `meta.json`.
