# Upgrade fragment (incomplete)

2024-03: rumor checksum widened to xor sequence into sixteen-bit field.

2024-07: emit tie ordering now references drift-adjusted timestamps from peer meta profiles.

2024-11: stale hold windows affect folded clock skew baselines when packs load.
