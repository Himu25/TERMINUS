# Stale hold smear

When a peer rejoins after a partition, its `stale_hold_ms` value represents how long
rumor buffers were pinned while the link was down. The smear fold adjusts the recorded
clock skew baseline so replay tie-breaks reflect mesh timing more accurately than the
uncorrected clock delta alone would imply.
