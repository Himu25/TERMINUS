module lab.local/gossip_state_healer

go 1.22
