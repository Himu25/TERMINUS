Operator tools live outside the heal driver; use /app/bin/gossip_heal for pack replay.
Digest recomputation for spot checks uses /app/tools/heal_digest.
