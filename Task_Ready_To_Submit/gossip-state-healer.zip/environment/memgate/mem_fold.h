#pragma once

long long mg_apply_smear(long long base_ms, long long hold_ms);
