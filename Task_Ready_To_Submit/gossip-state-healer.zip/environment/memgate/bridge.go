package memgate

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libmemgate.a -ldl -lm
#include "mem_fold.h"
*/
import "C"

// ApplySmear combines peer clock skew with an optional hold band.
func ApplySmear(baseMS int64, holdMS int64) int64 {
	return int64(C.mg_apply_smear(C.longlong(baseMS), C.longlong(holdMS)))
}
