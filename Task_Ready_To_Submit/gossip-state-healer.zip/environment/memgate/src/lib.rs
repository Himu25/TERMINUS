/// MgApplySmear folds a hold band into a peer clock skew baseline (milliseconds).
#[no_mangle]
pub extern "C" fn mg_apply_smear(base_ms: i64, hold_ms: i64) -> i64 {
    if hold_ms == 0 {
        return base_ms;
    }
    base_ms + hold_ms
}
