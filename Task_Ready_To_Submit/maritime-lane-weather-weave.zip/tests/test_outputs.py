"""Verifier for the autonomous voyage replay report."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Any

import pytest

APP = Path("/app")
OUT = APP / "output"
REPORT = OUT / "voyage_report.json"
BIN = APP / "bin" / "navsim"
PACK = APP / "data" / "voyage_pack.json"
FIXTURES = APP / "data" / "fixtures"
GOAL_CELL = 7
MIN_SEP = 1

PUBLIC_KEYS = {
    "schema_tag",
    "deliveries_met",
    "berth_stack",
    "lane_honor",
    "log_aligned",
    "cpa_clear",
    "leg_stable",
}

SYN_FIXTURE_GLOB = "syn_*.json"


def fold_key(label: str) -> int:
    acc = 14695981039346656037
    for ch in label.encode():
        acc ^= ch
        acc = (acc * 1099511628211) & 0xFFFFFFFFFFFFFFFF
    return acc


def replay_expected(pack: dict[str, Any]) -> dict[str, Any]:
    """Reference replay using the corrected gate, drift, tie, and trace rules."""
    units = pack.get("vessels") or ["u1", "u2", "u3"]
    tick_count = pack.get("tick_count") or 16
    if tick_count <= 0:
        tick_count = 16
    start_tick = int(pack.get("start_tick") or 10)
    home = pack["home_lane"]
    target = pack["divert_lane"]
    pivot = int(pack["pivot_tick"])

    start_cells = pack.get("start_cells")
    start_legs = pack.get("start_legs")
    if start_cells and len(start_cells) == len(units):
        pos = {unit: start_cells[index] for index, unit in enumerate(units)}
    else:
        pos = {unit: index * 2 for index, unit in enumerate(units)}
    if start_legs and len(start_legs) == len(units):
        last_step = {unit: start_legs[index] for index, unit in enumerate(units)}
    else:
        last_step = dict.fromkeys(units, 0)
    cluster_max = 0
    ghost_ep = 0
    gate_ep = 0
    at_goal: dict[str, bool] = {}
    deliveries_met = True
    lane_honor = True
    log_aligned = True
    cpa_clear = True
    leg_stable = True

    def op_phase(tick: int) -> str:
        return target if tick >= pivot else home

    def fn_span(a: int, b: int, margin: int) -> bool:
        if a == b:
            return False
        return abs(a - b) >= max(margin, 1)

    def fn_rank(prev: int, cur: int, tie: int) -> bool:
        if cur > prev:
            return True
        if cur < prev:
            return False
        if prev == 0 and cur == 0:
            return False
        return tie > 0

    def op_stamp(pres_epoch: int, gate_epoch: int, moved: bool) -> int:
        if not moved:
            return pres_epoch
        if pres_epoch < gate_epoch:
            return gate_epoch
        return pres_epoch

    for step in range(tick_count):
        tick = start_tick + step
        active = op_phase(tick)
        if tick >= pivot and active != target:
            lane_honor = False

        plans: list[tuple[str, int]] = []
        for unit in units:
            cur = pos[unit]
            if cur >= GOAL_CELL:
                at_goal[unit] = True
                continue
            nxt = min(cur + 1, GOAL_CELL)
            tie = fold_key(unit) % 3
            if not fn_rank(last_step[unit], nxt, tie):
                leg_stable = False
                continue
            plans.append((unit, nxt))

        for p_unit, p_next in plans:
            safe = True
            for q_unit, q_next in plans:
                if q_unit == p_unit:
                    continue
                if not fn_span(p_next, q_next, MIN_SEP) or not fn_span(p_next, pos[q_unit], MIN_SEP):
                    safe = False
            if not safe:
                continue
            cur = pos[p_unit]
            if p_next > cur:
                pos[p_unit] = p_next
                last_step[p_unit] = p_next
                gate_ep += 1
                ghost_ep = op_stamp(ghost_ep, gate_ep, True)
                if p_next >= GOAL_CELL:
                    at_goal[p_unit] = True

        occ: dict[int, int] = {}
        for unit in units:
            cell = pos[unit]
            if cell < GOAL_CELL:
                occ[cell] = occ.get(cell, 0) + 1
        for count in occ.values():
            cluster_max = max(cluster_max, count)
        for idx, unit in enumerate(units):
            for other in units[idx + 1 :]:
                if pos[unit] >= GOAL_CELL and pos[other] >= GOAL_CELL:
                    continue
                if not fn_span(pos[unit], pos[other], MIN_SEP):
                    cpa_clear = False

    for unit in units:
        if pos[unit] < GOAL_CELL:
            deliveries_met = False
    if len(at_goal) != len(units):
        deliveries_met = False
    if ghost_ep != gate_ep:
        log_aligned = False
    last_tick = start_tick + tick_count - 1
    if pivot > last_tick:
        lane_honor = False
    if cluster_max > 1:
        cpa_clear = False

    return {
        "deliveries_met": deliveries_met,
        "berth_stack": cluster_max,
        "lane_honor": lane_honor,
        "log_aligned": log_aligned,
        "cpa_clear": cpa_clear and cluster_max <= 1,
        "leg_stable": leg_stable,
    }


def run_checked(cmd: list[str], *, env: dict[str, str] | None = None, timeout: int = 120) -> None:
    result = subprocess.run(cmd, text=True, capture_output=True, timeout=timeout, env=env, check=False)
    if result.returncode != 0:
        raise AssertionError(
            f"command failed: {' '.join(cmd)}\nstdout:\n{result.stdout}\nstderr:\n{result.stderr}"
        )


def run_navsim(out_dir: Path = OUT) -> dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["NAVSIM_OUT"] = str(out_dir)
    run_checked([str(BIN)], env=env)
    return json.loads((out_dir / "voyage_report.json").read_text(encoding="utf-8"))


def run_navsim_with_pack(pack_path: Path, out_dir: Path) -> dict[str, Any]:
    original = PACK.read_text(encoding="utf-8")
    try:
        PACK.write_text(pack_path.read_text(encoding="utf-8"), encoding="utf-8")
        return run_navsim(out_dir)
    finally:
        PACK.write_text(original, encoding="utf-8")


def load_pack(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def assert_matches_reference(report: dict[str, Any], pack: dict[str, Any]) -> None:
    expected = replay_expected(pack)
    for key in (
        "deliveries_met",
        "berth_stack",
        "lane_honor",
        "log_aligned",
        "cpa_clear",
        "leg_stable",
    ):
        got = report.get(key)
        want = expected[key]
        assert got == want, (
            f"{key} for pack {pack.get('pack_id')!r}: got {got!r}, want {want!r}"
        )


def lab_schema_tag() -> str:
    for line in (APP / "metrics" / "labels.go").read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped.startswith('return "tb3-'):
            return stripped.split('"')[1]
    raise AssertionError("LabSchemaTag return not found in labels.go")


@pytest.fixture(scope="module")
def report() -> dict[str, Any]:
    assert BIN.is_file(), "navsim binary missing"
    return run_navsim()


@pytest.fixture(scope="module")
def bundled_pack() -> dict[str, Any]:
    return load_pack(PACK)


def test_m01(report: dict[str, Any]) -> None:
    """Bundled pack declares the lab schema marker from metrics."""
    assert report.get("schema_tag") == lab_schema_tag()


def test_m02(report: dict[str, Any], bundled_pack: dict[str, Any]) -> None:
    """Bundled pack replay matches the reference simulator."""
    assert_matches_reference(report, bundled_pack)


def test_m03(report: dict[str, Any], bundled_pack: dict[str, Any]) -> None:
    """Bundled pack corridor flag matches reference replay."""
    assert report.get("lane_honor") == replay_expected(bundled_pack)["lane_honor"]


def test_m04(report: dict[str, Any], bundled_pack: dict[str, Any]) -> None:
    """Bundled pack hop ordering matches reference replay."""
    assert report.get("leg_stable") == replay_expected(bundled_pack)["leg_stable"]


def test_m05(report: dict[str, Any], bundled_pack: dict[str, Any]) -> None:
    """Bundled pack separation flag matches reference replay."""
    assert report.get("cpa_clear") == replay_expected(bundled_pack)["cpa_clear"]


def test_m06(report: dict[str, Any], bundled_pack: dict[str, Any]) -> None:
    """Bundled pack telemetry sync matches reference replay."""
    assert report.get("log_aligned") == replay_expected(bundled_pack)["log_aligned"]


def test_m07(report: dict[str, Any], bundled_pack: dict[str, Any]) -> None:
    """Bundled pack cluster depth matches reference replay."""
    assert report.get("berth_stack") == replay_expected(bundled_pack)["berth_stack"]


def test_m08(tmp_path: Path) -> None:
    """Wind-surge fixture matches reference replay."""
    pack = load_pack(FIXTURES / "wind_surge.json")
    rep = run_navsim_with_pack(FIXTURES / "wind_surge.json", tmp_path)
    assert_matches_reference(rep, pack)


def test_m09(tmp_path: Path) -> None:
    """Late-pivot fixture matches reference replay."""
    pack = load_pack(FIXTURES / "pivot_late.json")
    rep = run_navsim_with_pack(FIXTURES / "pivot_late.json", tmp_path)
    assert_matches_reference(rep, pack)


def test_m10(report: dict[str, Any]) -> None:
    """Report exposes exactly the seven public fields."""
    assert set(report.keys()) == PUBLIC_KEYS


def test_m11(tmp_path: Path) -> None:
    """Four-unit rush fixture matches reference replay."""
    pack = load_pack(FIXTURES / "four_unit_rush.json")
    rep = run_navsim_with_pack(FIXTURES / "four_unit_rush.json", tmp_path)
    assert_matches_reference(rep, pack)


def test_m12(tmp_path: Path) -> None:
    """Long ghost-run fixture matches reference replay."""
    pack = load_pack(FIXTURES / "long_ghost_run.json")
    rep = run_navsim_with_pack(FIXTURES / "long_ghost_run.json", tmp_path)
    assert_matches_reference(rep, pack)


def syn_fixture_paths() -> list[Path]:
    return sorted(FIXTURES.glob(SYN_FIXTURE_GLOB))


@pytest.mark.parametrize("pack_path", syn_fixture_paths(), ids=lambda p: p.stem)
def test_m13_synthetic_pack(pack_path: Path, tmp_path: Path) -> None:
    """Syn fixture packs match reference replay (no per-pack answer table in schema doc)."""
    pack = load_pack(pack_path)
    rep = run_navsim_with_pack(pack_path, tmp_path)
    assert_matches_reference(rep, pack)


def test_m14(tmp_path: Path) -> None:
    """Syn late-pivot fixture forces lane_honor false per replay rules."""
    pack_path = FIXTURES / "syn_late_pivot.json"
    pack = load_pack(pack_path)
    rep = run_navsim_with_pack(pack_path, tmp_path)
    assert rep.get("lane_honor") is False
    assert replay_expected(pack)["lane_honor"] is False


def test_m15(tmp_path: Path) -> None:
    """Close-quarters start_cells force span gates to block false deliveries."""
    pack_path = FIXTURES / "syn_close_quarters.json"
    pack = load_pack(pack_path)
    rep = run_navsim_with_pack(pack_path, tmp_path)
    assert_matches_reference(rep, pack)
    assert rep.get("deliveries_met") is False
    assert rep.get("berth_stack") >= 2
    assert rep.get("cpa_clear") is False


def test_m16(tmp_path: Path) -> None:
    """Rank-stall pack exercises leg tie-break when next leg equals last recorded leg."""
    pack_path = FIXTURES / "syn_rank_stall.json"
    pack = load_pack(pack_path)
    rep = run_navsim_with_pack(pack_path, tmp_path)
    assert_matches_reference(rep, pack)
    assert rep.get("leg_stable") is False
