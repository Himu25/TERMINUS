package hop

// OpLane mirrors corridor selection for deploy manifests.
func OpLane(home string, alt string, tick int, pivot int) string {
	if tick >= pivot {
		return alt
	}
	return home
}
