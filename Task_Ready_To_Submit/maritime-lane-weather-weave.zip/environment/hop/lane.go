package hop

// LaneLabel tags a grid cell with the active corridor name.
func LaneLabel(cell int, corridor string) string {
	return corridor + "-" + itoa(cell)
}

func itoa(v int) string {
	if v == 0 {
		return "0"
	}
	var buf [12]byte
	i := len(buf)
	n := v
	for n > 0 {
		i--
		buf[i] = byte('0' + n%10)
		n /= 10
	}
	return string(buf[i:])
}
