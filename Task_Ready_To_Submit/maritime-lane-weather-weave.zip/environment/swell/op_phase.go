package swell

// OpPhase is the exported entry for the harness.
func OpPhase(home string, alt string, tick int, pivotTick int) string {
	return op_phase(home, alt, tick, pivotTick)
}

func op_phase(home string, alt string, tick int, pivotTick int) string {
	if tick < pivotTick {
		return alt
	}
	return home
}
