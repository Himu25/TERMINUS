package config

import "os"

// EnvOr returns the environment value or a default.
func EnvOr(key string, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}
