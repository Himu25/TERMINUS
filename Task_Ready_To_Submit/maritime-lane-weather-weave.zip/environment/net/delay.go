package net

// DelayTicks models one-way telemetry latency in ticks.
func DelayTicks(base int, jitter int, seq int) int {
	return base + (seq % (jitter + 1))
}
