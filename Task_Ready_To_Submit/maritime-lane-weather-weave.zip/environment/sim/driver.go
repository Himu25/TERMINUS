package sim

import (
	"lab.local/maritime_lane_weave/keel"
	"lab.local/maritime_lane_weave/metrics"
	"lab.local/maritime_lane_weave/quay"
	"lab.local/maritime_lane_weave/swell"
	"lab.local/maritime_lane_weave/util"
	"lab.local/maritime_lane_weave/wake"
)

const (
	goalCell = 7
	minSep   = 1
)

// RunPack replays one voyage scenario and folds counters.
func RunPack(packPath string) metrics.Stats {
	doc := readPack(packPath)
	pos := make(map[string]int)
	lastStep := make(map[string]int)
	for i, u := range doc.Vessels {
		if len(doc.StartCells) == len(doc.Vessels) {
			pos[u] = doc.StartCells[i]
		} else {
			pos[u] = i * 2
		}
		if len(doc.StartLegs) == len(doc.Vessels) {
			lastStep[u] = doc.StartLegs[i]
		} else {
			lastStep[u] = 0
		}
	}

	var stackMax int
	stampEp := 0
	spanEp := 0
	atGoal := make(map[string]bool)
	deliveriesMet := true
	laneHonor := true
	logAligned := true
	cpaClear := true
	legStable := true

	for i := 0; i < doc.TickCount; i++ {
		tick := int(doc.StartTick) + i
		active := swell.OpPhase(doc.HomeLane, doc.DivertLane, tick, doc.PivotTick)
		if tick >= doc.PivotTick && active != doc.DivertLane {
			laneHonor = false
		}

		type movePlan struct {
			unit string
			next int
			tie  int
		}
		var plans []movePlan
		for _, u := range doc.Vessels {
			cur := pos[u]
			if cur >= goalCell {
				atGoal[u] = true
				continue
			}
			next := cur + 1
			if next > goalCell {
				next = goalCell
			}
			tie := int(util.FoldKey(u) % 3)
			if !keel.FnRank(lastStep[u], next, tie) {
				legStable = false
				continue
			}
			plans = append(plans, movePlan{unit: u, next: next, tie: tie})
		}

		for _, p := range plans {
			safe := true
			for _, q := range plans {
				if q.unit == p.unit {
					continue
				}
				if !quay.FnSpan(p.next, q.next, minSep) {
					safe = false
				}
				if !quay.FnSpan(p.next, pos[q.unit], minSep) {
					safe = false
				}
			}
			if !safe {
				continue
			}
			cur := pos[p.unit]
			if p.next > cur {
				pos[p.unit] = p.next
				lastStep[p.unit] = p.next
				spanEp++
				stampEp = wake.OpStamp(stampEp, spanEp, true)
				if p.next >= goalCell {
					atGoal[p.unit] = true
				}
			}
		}

		occ := map[int]int{}
		for _, u := range doc.Vessels {
			cell := pos[u]
			if cell < goalCell {
				occ[cell]++
			}
		}
		for _, n := range occ {
			if n > stackMax {
				stackMax = n
			}
		}
		for iu, u := range doc.Vessels {
			for _, v := range doc.Vessels[iu+1:] {
				if pos[u] >= goalCell && pos[v] >= goalCell {
					continue
				}
				if !quay.FnSpan(pos[u], pos[v], minSep) {
					cpaClear = false
				}
			}
		}
	}

	for _, u := range doc.Vessels {
		if pos[u] < goalCell {
			deliveriesMet = false
		}
	}
	if len(atGoal) != len(doc.Vessels) {
		deliveriesMet = false
	}
	if stampEp != spanEp {
		logAligned = false
	}
	lastTick := int(doc.StartTick) + doc.TickCount - 1
	if doc.PivotTick > lastTick {
		laneHonor = false
	}
	if stackMax > 1 {
		cpaClear = false
	}

	return metrics.Stats{
		DeliveriesMet: deliveriesMet,
		BerthStack:    stackMax,
		LaneHonor:     laneHonor,
		LogAligned:    logAligned,
		CpaClear:      cpaClear && stackMax <= 1,
		LegStable:     legStable,
	}
}
