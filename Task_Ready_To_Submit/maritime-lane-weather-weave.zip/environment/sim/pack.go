package sim

import (
	"encoding/json"
	"os"
)

// VoyagePack is the JSON scenario document for one lab run.
type VoyagePack struct {
	PackID         string   `json:"pack_id"`
	HomeLane   string   `json:"home_lane"`
	DivertLane string   `json:"divert_lane"`
	PivotTick      int      `json:"pivot_tick"`
	SquallTicks      int      `json:"squall_ticks"`
	Vessels        []string `json:"vessels"`
	TickCount      int      `json:"tick_count"`
	StartTick      int64    `json:"start_tick"`
	StartCells     []int    `json:"start_cells,omitempty"`
	StartLegs      []int    `json:"start_legs,omitempty"`
}

func readPack(path string) VoyagePack {
	b, err := os.ReadFile(path)
	if err != nil {
		panic(err)
	}
	var d VoyagePack
	if err := json.Unmarshal(b, &d); err != nil {
		panic(err)
	}
	if d.TickCount <= 0 {
		d.TickCount = 16
	}
	if len(d.Vessels) == 0 {
		d.Vessels = []string{"u1", "u2", "u3"}
	}
	if d.SquallTicks <= 0 {
		d.SquallTicks = 6
	}
	if d.StartTick <= 0 {
		d.StartTick = 10
	}
	return d
}
