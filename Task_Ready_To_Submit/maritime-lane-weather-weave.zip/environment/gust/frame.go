package gust

import "strings"

// CorridorStress reports whether a lane label exceeds the wind budget.
func CorridorStress(lane string, limit int) bool {
	parts := strings.Split(lane, "-")
	if len(parts) < 2 {
		return false
	}
	cell := 0
	for _, ch := range parts[len(parts)-1] {
		if ch < '0' || ch > '9' {
			continue
		}
		cell = cell*10 + int(ch-'0')
	}
	return cell > limit
}
