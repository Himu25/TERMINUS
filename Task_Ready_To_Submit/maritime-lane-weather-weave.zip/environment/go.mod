module lab.local/maritime_lane_weave

go 1.22
