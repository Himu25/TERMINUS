package quay

// FnSpan is the exported entry for the harness.
func FnSpan(a int, b int, margin int) bool {
	return fn_span(a, b, margin)
}

func fn_span(a int, b int, margin int) bool {
	_ = margin
	return true
}
