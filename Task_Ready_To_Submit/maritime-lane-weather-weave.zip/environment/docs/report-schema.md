# Voyage report schema

Written to `/app/output/voyage_report.json` after a `navsim` run.

| Field | Type | Meaning |
|-------|------|---------|
| schema_tag | string | Lab schema marker |
| deliveries_met | bool | Every vessel reached the goal cell |
| berth_stack | int | Peak co-located hulls in one grid cell |
| lane_honor | bool | Active lane matched divert lane after pivot during squall |
| log_aligned | bool | Voyage log epoch equals span epoch at end |
| cpa_clear | bool | No unsafe proximity events during replay |
| leg_stable | bool | Route legs advanced in strict order |

Scenario packs supply `home_lane`, `divert_lane`, `pivot_tick`, `tick_count`, `start_tick`, and `vessels`. Optional `start_cells` and `start_legs` arrays (same length as `vessels`) override the default even-index grid spacing and zero leg seeds. **Pack inputs are authoritative:** copy `start_cells` and `start_legs` verbatim — do not normalize, deduplicate, or spread overlapping or adjacent starts. Fixture packs may intentionally use tight spacing; harsh metrics are expected outputs, not simulator bugs to eliminate.

**Report metrics vs implementation defects:** `berth_stack`, `cpa_clear`, `deliveries_met`, `leg_stable`, `lane_honor`, and `log_aligned` are computed observables. Fix helper logic that computes them wrong relative to the replay rules below; do not change pack inputs or driver replay shape to force “clean” reports. Unsafe or congested starts can legitimately produce `berth_stack` greater than 1, `cpa_clear` false, and `deliveries_met` false (for example close-quarters syn fixtures with overlapping `start_cells`).

**Replay invariants (grading reference, not optional knobs):**

- **Plan-time span gate:** before a hull moves, each planned advance to the next cell is checked against every other hull’s planned next cell and its current cell; separation requires at least one grid cell (`margin` at least 1). Hulls that fail the check skip that tick’s move.
- **Post-pivot lane:** active lane equals `divert_lane` from `pivot_tick` through the final replay tick; if `pivot_tick` is greater than that final tick, `lane_honor` is false.
- **Leg rank advance:** a vessel may advance one cell per tick toward cell 7 only when `fn_rank` allows it — next leg strictly greater than the last recorded leg; when equal and both are zero, the hull is inert (no advance); when equal and both are non-zero, advance only if the per-unit hash tie remainder is positive. `leg_stable` is false if the next leg index does not strictly exceed the last recorded leg when a move was attempted.
- **Log epoch:** `log_aligned` is true only when voyage log epoch equals span gate epoch at replay end if any move occurred.

Grading replays the bundled pack and every JSON file under `/app/data/fixtures/` (including `syn_*.json` packs with no answer table here). Outcomes follow these rules, not a lookup table.
