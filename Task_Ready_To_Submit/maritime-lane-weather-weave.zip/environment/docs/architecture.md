# Autonomous voyage replay lab

Single-process Go lab modeling distributed leg planners, squall lane pivots, CPA span checks, and voyage log stamping over a shared grid replay. Local detour heuristics can stack hulls in one cell when span gates are too permissive or pivot timing inverts.
