package grid

// CellSpan returns the inclusive distance between two lane cells.
func CellSpan(a int, b int) int {
	d := a - b
	if d < 0 {
		d = -d
	}
	return d
}
