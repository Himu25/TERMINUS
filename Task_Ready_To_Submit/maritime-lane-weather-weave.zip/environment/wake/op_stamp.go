package wake

// OpStamp is the exported entry for the harness.
func OpStamp(presEpoch int, gateEpoch int, moved bool) int {
	return op_stamp(presEpoch, gateEpoch, moved)
}

func op_stamp(presEpoch int, gateEpoch int, moved bool) int {
	_ = gateEpoch
	if !moved {
		return presEpoch
	}
	return presEpoch
}
