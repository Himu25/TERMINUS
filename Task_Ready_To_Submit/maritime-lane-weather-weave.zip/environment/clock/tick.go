package clock

// Advance returns the next lab tick counter.
func Advance(cur int64, delta int) int64 {
	return cur + int64(delta)
}
