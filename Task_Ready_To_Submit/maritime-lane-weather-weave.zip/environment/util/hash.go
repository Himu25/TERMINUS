package util

// FoldKey hashes a unit label for tie material.
func FoldKey(s string) uint64 {
	var acc uint64 = 14695981039346656037
	for i := 0; i < len(s); i++ {
		acc ^= uint64(s[i])
		acc *= 1099511628211
	}
	return acc
}
