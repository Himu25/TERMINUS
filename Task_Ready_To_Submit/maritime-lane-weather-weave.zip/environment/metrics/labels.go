package metrics

// LabSchemaTag is the outward schema marker for this lab.
func LabSchemaTag() string {
	return "tb3-maritime-weave-01"
}
