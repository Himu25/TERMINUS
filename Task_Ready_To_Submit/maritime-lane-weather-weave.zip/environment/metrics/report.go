package metrics

// Stats carries raw counters from the harness.
type Stats struct {
	DeliveriesMet  bool
	BerthStack int
	LaneHonor   bool
	LogAligned    bool
	CpaClear bool
	LegStable    bool
}

// Report is the public JSON contract.
type Report struct {
	SchemaTag    string `json:"schema_tag"`
	DeliveriesMet  bool   `json:"deliveries_met"`
	BerthStack int    `json:"berth_stack"`
	LaneHonor   bool   `json:"lane_honor"`
	LogAligned    bool   `json:"log_aligned"`
	CpaClear bool   `json:"cpa_clear"`
	LegStable    bool   `json:"leg_stable"`
}

// FromStats maps counters to outward labels.
func FromStats(s Stats) Report {
	return Report{
		SchemaTag:    LabSchemaTag(),
		DeliveriesMet:  s.DeliveriesMet,
		BerthStack: s.BerthStack,
		LaneHonor:   s.LaneHonor,
		LogAligned:    s.LogAligned,
		CpaClear: s.CpaClear,
		LegStable:    s.LegStable,
	}
}
