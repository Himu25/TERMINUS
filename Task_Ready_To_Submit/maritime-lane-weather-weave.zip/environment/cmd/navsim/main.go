package main

import (
	"encoding/json"
	"os"
	"path/filepath"

	"lab.local/maritime_lane_weave/metrics"
	"lab.local/maritime_lane_weave/sim"
)

func main() {
	pack := "/app/data/voyage_pack.json"
	if v := os.Getenv("NAVSIM_PACK"); v != "" {
		pack = v
	}
	outDir := "/app/output"
	if v := os.Getenv("NAVSIM_OUT"); v != "" {
		outDir = v
	}
	stats := sim.RunPack(pack)
	rep := metrics.FromStats(stats)
	if err := os.MkdirAll(outDir, 0o755); err != nil {
		panic(err)
	}
	b, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		panic(err)
	}
	target := filepath.Join(outDir, "voyage_report.json")
	if err := os.WriteFile(target, b, 0o644); err != nil {
		panic(err)
	}
}
