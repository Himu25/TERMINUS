package keel

// FnRank is the exported entry for the harness.
func FnRank(prev int, cur int, tie int) bool {
	return fn_rank(prev, cur, tie)
}

func fn_rank(prev int, cur int, tie int) bool {
	_ = tie
	return cur >= prev
}
