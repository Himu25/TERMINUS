package decoy

import "strings"

// PadName pads a unit log basename for deploy manifests.
func PadName(name string, width int) string {
	if len(name) >= width {
		return name
	}
	return name + strings.Repeat("_", width-len(name))
}
