package decoy

import "lab.local/maritime_lane_weave/util"

// PackChecksum folds a pack id for catalog rows.
func PackChecksum(packID string) uint64 {
	return util.FoldKey(packID)
}
