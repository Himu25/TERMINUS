#!/usr/bin/env bash
set -euo pipefail

cd /app

patch_gate() {
  cat > /app/quay/fn_span.go <<'EOF'
package quay

// FnSpan is the exported entry for the harness.
func FnSpan(a int, b int, margin int) bool {
	return fn_span(a, b, margin)
}

func fn_span(a int, b int, margin int) bool {
	if a == b {
		return false
	}
	span := a - b
	if span < 0 {
		span = -span
	}
	if margin < 1 {
		margin = 1
	}
	return span >= margin
}
EOF
}

patch_phase() {
  cat > /app/swell/op_phase.go <<'EOF'
package swell

// OpPhase is the exported entry for the harness.
func OpPhase(home string, alt string, tick int, pivotTick int) string {
	return op_phase(home, alt, tick, pivotTick)
}

func op_phase(home string, alt string, tick int, pivotTick int) string {
	if tick >= pivotTick {
		return alt
	}
	return home
}
EOF
}

patch_tie() {
  cat > /app/keel/fn_rank.go <<'EOF'
package keel

// FnRank is the exported entry for the harness.
func FnRank(prev int, cur int, tie int) bool {
	return fn_rank(prev, cur, tie)
}

func fn_rank(prev int, cur int, tie int) bool {
	if cur > prev {
		return true
	}
	if cur < prev {
		return false
	}
	if prev == 0 && cur == 0 {
		return false
	}
	return tie > 0
}
EOF
}

patch_trace() {
  cat > /app/wake/op_stamp.go <<'EOF'
package wake

// OpStamp is the exported entry for the harness.
func OpStamp(presEpoch int, gateEpoch int, moved bool) int {
	return op_stamp(presEpoch, gateEpoch, moved)
}

func op_stamp(presEpoch int, gateEpoch int, moved bool) int {
	if !moved {
		return presEpoch
	}
	if presEpoch < gateEpoch {
		return gateEpoch
	}
	return presEpoch
}
EOF
}

patch_gate
patch_phase
patch_tie
patch_trace

mkdir -p /app/bin /app/output
go build -buildvcs=false -o /app/bin/navsim ./cmd/navsim
/app/bin/navsim
