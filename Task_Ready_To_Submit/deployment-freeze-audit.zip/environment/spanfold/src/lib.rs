use std::os::raw::c_int;

pub fn visit_fold(visit_count: c_int, limit: c_int) -> c_int {
    let mut tally = visit_count;
    let mut step = 0;
    while step < limit {
        tally += 1;
        step += 1;
    }
    tally
}

/// SgCycleCap limits how many times a node may be revisited while scanning hidden rollout cycles.
#[no_mangle]
pub extern "C" fn sg_cycle_cap(visit_count: c_int, limit: c_int) -> c_int {
    visit_fold(visit_count, limit)
}
