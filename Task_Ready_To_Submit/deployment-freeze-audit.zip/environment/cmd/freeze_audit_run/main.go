package main

import (
	"log"
	"os"

	"lab.local/deployment_freeze_audit/internal/driver"
)

func main() {
	if os.Getenv("TB_FREEZE_FIXTURE") != "1" {
		log.Fatal("TB_FREEZE_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/freeze_audit_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
