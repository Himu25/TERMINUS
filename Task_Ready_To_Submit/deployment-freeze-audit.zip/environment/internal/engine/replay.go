package engine

import (
    "lab.local/deployment_freeze_audit/internal/config"
    "lab.local/deployment_freeze_audit/internal/cycletab"
    "lab.local/deployment_freeze_audit/internal/edgefuse"
    "lab.local/deployment_freeze_audit/internal/reach"
    "lab.local/deployment_freeze_audit/internal/score"
    "lab.local/deployment_freeze_audit/pkg/alert"
    "lab.local/deployment_freeze_audit/pkg/graph"
)

type queueRow struct {
    Service       string `json:"service"`
    PriorityScore int    `json:"priority_score"`
    HopDistance   int    `json:"hop_distance"`
}

// Outcome is the folded counters for one pack replay.
type Outcome struct {
    AnchorService     string
    ImpactServices   int
    BlastDepth int
    ShadowHits    int
    StaleRecords    int
    HiddenRollouts      int
    Queue           []queueRow
}

// Replay executes one incident pack through the freeze audit pipeline.
func Replay(inc config.Incident, reg config.RegistryFile, runtime []graph.Edge, hints []config.SidecarHint, alerts []alert.Row) Outcome {
    merged := edgefuse.Merge(inc, reg, runtime, hints)
    walked := reach.Expand(inc.AnchorService, merged.Edges, inc.MaxDepth)
    ranked := score.Queue(walked.Affected, walked.Hops, alerts)
    cycles := cycletab.Count(merged.Edges, inc.CycleLimit)

    queue := make([]queueRow, len(ranked))
    for i, row := range ranked {
        queue[i] = queueRow{
            Service:       row.Service,
            PriorityScore: row.PriorityScore,
            HopDistance:   row.HopDistance,
        }
    }

    return Outcome{
        AnchorService:     inc.AnchorService,
        ImpactServices:   len(walked.Affected),
        BlastDepth: walked.MaxHop,
        ShadowHits:    merged.ShadowHits,
        StaleRecords:    merged.StaleRecords,
        HiddenRollouts:      cycles,
        Queue:           queue,
    }
}
