package reach

import (
    "sort"

    "lab.local/deployment_freeze_audit/pkg/closegate"
    "lab.local/deployment_freeze_audit/pkg/graph"
)

// Map holds hop distances from the root through merged edges.
type Map struct {
    Hops    map[string]int
    MaxHop  int
    Affected []string
}

// Expand performs breadth-first reach from root up to maxDepth.
func Expand(root string, edges []graph.Edge, maxDepth int) Map {
    adj := make(map[string][]string)
    for _, e := range edges {
        adj[e.Provider] = append(adj[e.Provider], e.Consumer)
    }
    for k := range adj {
        sort.Strings(adj[k])
    }

    hops := map[string]int{root: 0}
    queue := []string{root}
    maxHop := 0
    for len(queue) > 0 {
        cur := queue[0]
        queue = queue[1:]
        depth := hops[cur]
        if !closegate.GateT(depth, maxDepth) {
            continue
        }
        for _, nxt := range adj[cur] {
            if _, ok := hops[nxt]; ok {
                continue
            }
            nd := depth + 1
            if nd > maxHop {
                maxHop = nd
            }
            hops[nxt] = nd
            queue = append(queue, nxt)
        }
    }

    affected := make([]string, 0, len(hops))
    for svc, hop := range hops {
        if svc == root {
            continue
        }
        affected = append(affected, svc)
        _ = hop
    }
    sort.Strings(affected)
    return Map{Hops: hops, MaxHop: maxHop, Affected: affected}
}
