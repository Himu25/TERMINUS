package priority

// OpK scores remediation urgency from manual patch volume and hop distance from the anchor service.
func OpK(alertCount int, hopDistance int) int {
    return alertCount + hopDistance
}
