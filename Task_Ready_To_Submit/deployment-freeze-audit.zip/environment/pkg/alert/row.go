package alert

// Row is one paging row tied to a service name.
type Row struct {
    Service string `json:"service"`
    Count   int    `json:"count"`
}
