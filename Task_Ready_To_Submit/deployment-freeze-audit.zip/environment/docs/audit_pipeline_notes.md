# Deployment freeze audit pipeline notes

The freeze audit driver merges three edge feeds (registry catalog, pipeline events, shadow lane overlays), walks dependency reach from the anchor service, ranks remediation candidates from manual patch volume, and tallies cyclic hidden rollout paths through the Rust spanfold cap.

Cycle tally in `/app/internal/cycletab` folds a running visit counter through `/app/spanfold` for each sorted node on a cyclic path. Once the counter reaches `dedup_cap` from the incident pack, further folds must leave it unchanged.

Subsystems: Go packages under `/app/internal` and `/app/pkg`, Rust staticlib under `/app/spanfold/src`, Go bridge at `/app/spanfold/bridge.go`, build via `/app/scripts/build.sh`. Run `go test ./...` after rebuilding to exercise package-level checks including the spanfold bridge.
