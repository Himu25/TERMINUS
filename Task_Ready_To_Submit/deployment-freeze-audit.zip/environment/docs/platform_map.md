# Platform map

Multi-source deployment history for the freeze audit pipeline:

| Source | Path pattern | Role |
|--------|--------------|------|
| Service registry | `registry.json` | Declared upstream/downstream edges with freshness timestamps |
| Pipeline / K8s | `pipeline_events.jsonl` | Observed rollout edges during the freeze window |
| Shadow lane | `shadow_lane.jsonl` | Hidden rollout sidecar attachments |
| Manual patches | `alerts.jsonl` | Per-service manual patch volume for remediation ranking |

Go helpers live under `/app/internal` and `/app/pkg`. Rust spanfold staticlib at `/app/spanfold` with Go bridge. Build via `/app/scripts/build.sh`.

Verifier harness copies the built audit binary to `/tmp/freeze_audit_run_verify_bin` for isolated replay runs. Go tests invoke `/usr/local/go/bin/go`.
