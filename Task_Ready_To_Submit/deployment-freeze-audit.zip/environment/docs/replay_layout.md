# Deployment freeze audit replay layout

Each replay pack under `/app/data/replay/` is a directory containing:

- `incident.json` — run_id, anchor_service, record_cutoff, max_depth, dedup_cap
- `registry.json` — service dependency edges with as_of timestamps
- `pipeline_events.jsonl` — CI and Kubernetes rollout edges observed during the freeze
- `shadow_lane.jsonl` — optional sidecar lane rows for shadow deployments
- `alerts.jsonl` — manual patch counts per impacted service

The active pack lives at `/app/data/active/`. Run `/app/bin/freeze_audit_run` with `TB_FREEZE_FIXTURE=1` to emit `/app/output/freeze_audit_report.json`.

## Replay merge

Registry rows merge when `as_of` meets `record_cutoff`. Pipeline events append after catalog rows. Shadow-lane rows append when `shadow_lane.jsonl` exists. Edges aim `provider` at `consumer`.

## Reach and scoring

Breadth-first reach from `anchor_service` continues while current hop depth is strictly below `max_depth`. Remediation `priority_score` is manual patch count times one hundred minus hop distance times ten. The remediation queue sorts by descending `priority_score`, then ascending `service`.

## Hidden rollouts

Cyclic rollout nodes are collected from merged edges, visited in sorted service name order. Each visit folds a running counter through the Rust spanfold cap helper using `dedup_cap`; nodes count while the folded counter stays at or below the cap.

## Report digest

`digest_hex` is lowercase hex SHA-256 of pipe-joined fields in order: `run_id`, `impact_services`, `blast_depth`, `shadow_hits`, `stale_records`, `hidden_rollouts`, and the first remediation queue service (empty string when the queue is empty).
