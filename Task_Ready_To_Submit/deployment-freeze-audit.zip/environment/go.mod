module lab.local/deployment_freeze_audit

go 1.22
