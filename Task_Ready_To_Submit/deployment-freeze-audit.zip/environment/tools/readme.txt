Digest helper: go run -mod=mod /app/tools/digest_cli <args>
Run freeze audit with TB_FREEZE_FIXTURE=1 after build.
