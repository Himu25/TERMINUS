#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/pkg/closegate/op_t.go <<'EOF'
package closegate

func depthOpen(currentDepth int, maxDepth int) bool {
	if maxDepth <= 0 {
		return false
	}
	if currentDepth < 0 {
		return false
	}
	return currentDepth < maxDepth
}

func depthClosed(currentDepth int, maxDepth int) bool {
	return !depthOpen(currentDepth, maxDepth)
}

// GateT decides whether graph expansion may continue past the current depth.
func GateT(currentDepth int, maxDepth int) bool {
	return depthOpen(currentDepth, maxDepth)
}
EOF

cat > /app/internal/catalog/op_s.go <<'EOF'
package catalog

// OpS decides whether a registry edge row is fresh enough to merge.
func OpS(asOf int, cutoff int) bool {
	return asOf >= cutoff
}
EOF

cat > /app/pkg/lanehint/op_h.go <<'EOF'
package lanehint

// OpH decides whether a shadow-lane sidecar edge is incorporated into the working graph.
func OpH(lane string, present bool) bool {
	_ = lane
	return present
}
EOF

cat > /app/pkg/priority/op_k.go <<'EOF'
package priority

// OpK scores remediation urgency from manual patch volume and hop distance from the anchor service.
func OpK(alertCount int, hopDistance int) int {
	return alertCount*100 - hopDistance*10
}
EOF

cat > /app/spanfold/src/lib.rs <<'EOF'
use std::os::raw::c_int;

pub fn visit_fold(visit_count: c_int, limit: c_int) -> c_int {
    if visit_count >= limit {
        return visit_count;
    }
    visit_count + 1
}

/// SgCycleCap limits how many times a node may be revisited while scanning hidden rollout cycles.
#[no_mangle]
pub extern "C" fn sg_cycle_cap(visit_count: c_int, limit: c_int) -> c_int {
    visit_fold(visit_count, limit)
}
EOF

bash /app/scripts/build.sh

rm -f /app/output/freeze_audit_report.json
mkdir -p /app/output
TB_FREEZE_FIXTURE=1 /app/bin/freeze_audit_run
test -s /app/output/freeze_audit_report.json

GOFLAGS=-mod=mod go test ./...
