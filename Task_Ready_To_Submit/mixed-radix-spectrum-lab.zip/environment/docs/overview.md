Wave replay lab overview

The lab exercises discrete transforms on seeded stems at lengths that are not
restricted to powers of two. The Go driver reads manifests, builds factor
chains, and calls the Rust static library through CGO. Build orchestration
lives under scripts/.

Active bundle: data/active/manifest.json
Regression bundles: data/regression/<stem>/manifest.json

Stem rows in the report name a lane for each replay: chirp, radix, or stripe.
