#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app
bash /app/scripts/build.sh
TB_WAVE_FIXTURE=1 /app/bin/spectrum_lab
test -s /app/output/spectrum_report.json
