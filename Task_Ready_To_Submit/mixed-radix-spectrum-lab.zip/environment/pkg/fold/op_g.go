package fold

func OpH(seed uint64, slots int) uint64 {
	var acc uint64
	for i := 0; i < slots; i++ {
		seed = seed*1103515245 + 12345
		acc ^= seed >> 16
	}
	return acc
}
