package fold

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
)

func OpF(total, passed int, maxErr float64) uint32 {
	raw := uint64(total)*1000003 + uint64(passed)*1009 + uint64(maxErr*1e9)
	return uint32(raw % 999983)
}

func DigestReport(total, passed int, maxErr float64, inplaceOK, threadOK int) string {
	prefix := OpF(total, passed, maxErr)
	body := fmt.Sprintf("%d|%d|%.12e|%d|%d|%d", total, passed, maxErr, inplaceOK, threadOK, prefix)
	sum := sha256.Sum256([]byte(body))
	return hex.EncodeToString(sum[:])
}

func OpG(capacity uint64) uint64 {
	if capacity == 0 {
		return 4096
	}
	n := capacity - 1
	n |= n >> 1
	n |= n >> 2
	n |= n >> 4
	n |= n >> 8
	n |= n >> 16
	n |= n >> 32
	return n + 1
}
