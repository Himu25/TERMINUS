#ifndef WV_K9_H
#define WV_K9_H

#include <stddef.h>
#include <stdint.h>

int32_t wc_run_pair(
    double *re,
    double *im,
    size_t len,
    const uint32_t *factors,
    size_t factor_count,
    uint32_t flags,
    double *out_err
);

int32_t wc_serial_parallel_delta(
    const double *re,
    const double *im,
    size_t len,
    const uint32_t *factors,
    size_t factor_count,
    uint32_t workers,
    double *out_err
);

#endif
