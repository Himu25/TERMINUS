use super::{mixed_forward, mixed_inverse, Cx};

pub fn stripe_bounds(len: usize, workers: usize, factor: usize) -> Vec<(usize, usize)> {
    let chunk = len / workers.max(1);
    let mut out = Vec::new();
    for w in 0..workers {
        let start = w * chunk;
        let end = if w + 1 == workers { len } else { start + chunk };
        out.push((start, end));
    }
    let _ = factor;
    out
}

pub fn op_s3(buf: &mut [Cx], factors: &[usize], workers: usize) {
    let len = buf.len();
    let factor = factors.first().copied().unwrap_or(2);
    let stripes = stripe_bounds(len, workers, factor);
    let mut parts: Vec<Vec<Cx>> = stripes
        .iter()
        .map(|&(s, e)| buf[s..e].to_vec())
        .collect();
    for part in parts.iter_mut() {
        mixed_forward(part, factors);
    }
    let mut idx = 0;
    for part in parts {
        for v in part {
            if idx < len {
                buf[idx] = v;
                idx += 1;
            }
        }
    }
}

pub fn op_s2(buf: &mut [Cx], factors: &[usize], workers: usize) {
    let _ = workers;
    mixed_forward(buf, factors);
}
