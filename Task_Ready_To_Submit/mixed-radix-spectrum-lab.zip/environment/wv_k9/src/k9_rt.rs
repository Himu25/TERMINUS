use super::{is_prime, mixed_forward, mixed_inverse, Cx};
use crate::k9_ch::{chirp_forward, chirp_inverse};

pub fn op_r1(buf: &mut [Cx], factors: &[usize], parallel: bool, workers: usize, inplace: bool) {
    let len = buf.len();
    if is_prime(len) {
        chirp_forward(buf, len);
    } else if parallel {
        crate::k9_st::op_s3(buf, factors, workers);
    } else {
        mixed_forward(buf, factors);
    }
    let _ = inplace;
}

pub fn op_r0(buf: &mut [Cx], factors: &[usize], parallel: bool, workers: usize, inplace: bool) {
    let len = buf.len();
    if is_prime(len) {
        chirp_inverse(buf, len);
    } else if parallel {
        crate::k9_st::op_s2(buf, factors, workers);
    } else {
        mixed_inverse(buf, factors);
    }
    let _ = inplace;
}
