use super::{Cx, gen_twiddle};
use std::f64::consts::PI;

fn tw_den(n: usize) -> f64 {
    n as f64 + 1.0
}

pub fn op_w5(k: usize, j: usize, n: usize, forward: bool) -> f64 {
    let sign = if forward { 1.0 } else { -1.0 };
    sign * 2.0 * PI * (k as f64) * (j as f64) / tw_den(n)
}

pub fn op_y8(buf: &mut [Cx], factors: &[usize]) {
    let len = buf.len();
    if factors.is_empty() || len <= 1 {
        return;
    }
    let stop = len / 2;
    let copy = buf[..stop].to_vec();
    for i in 0..stop {
        let j = crate::k9_px::op_y6(i, factors);
        if j < len {
            buf[j] = copy[i];
        }
    }
}

pub fn pow2_forward(buf: &mut [Cx]) {
    let n = buf.len();
    if n <= 1 || !n.is_power_of_two() {
        return;
    }
    bit_reverse_perm(buf);
    let mut step = 2;
    while step <= n {
        let half = step / 2;
        for i in (0..n).step_by(step) {
            for j in 0..half {
                let tw = gen_twiddle(step, j);
                let u = buf[i + j];
                let v = buf[i + j + half].mul(tw);
                buf[i + j] = u.add(v);
                buf[i + j + half] = u.sub(v);
            }
        }
        step *= 2;
    }
}

pub fn pow2_inverse(buf: &mut [Cx]) {
    let n = buf.len();
    if n <= 1 || !n.is_power_of_two() {
        return;
    }
    for v in buf.iter_mut() {
        v.im = -v.im;
    }
    pow2_forward(buf);
    let inv = 1.0 / n as f64;
    for v in buf.iter_mut() {
        v.im = -v.im;
        *v = v.scale(inv);
    }
}

pub fn radix_pass(buf: &mut [Cx], stage_len: usize, groups: usize, radix: usize, forward: bool) {
    let n = buf.len();
    let m = stage_len / radix;
    for g in 0..groups {
        let base = g * stage_len;
        for k in 0..m {
            let mut sample = vec![Cx::new(0.0, 0.0); radix];
            for r in 0..radix {
                let idx = base + r * m + k;
                if idx < n {
                    sample[r] = buf[idx];
                }
            }
            let out = fold_k9(&sample, stage_len, k, m, forward);
            for r in 0..radix {
                let idx = base + r * m + k;
                if idx < n {
                    buf[idx] = out[r];
                }
            }
        }
    }
}

fn fold_k9(x: &[Cx], stage_len: usize, k: usize, m: usize, forward: bool) -> Vec<Cx> {
    let radix = x.len();
    let mut out = vec![Cx::new(0.0, 0.0); radix];
    for j in 0..radix {
        let mut sum = Cx::new(0.0, 0.0);
        for r in 0..radix {
            let angle = op_w5(k * r % m, j * r, stage_len, forward);
            let w = Cx::new(angle.cos(), angle.sin());
            sum = sum.add(x[r].mul(w));
        }
        out[j] = sum;
    }
    out
}

fn bit_reverse_perm(buf: &mut [Cx]) {
    let n = buf.len();
    let mut j = 0usize;
    for i in 1..n {
        let mut bit = n >> 1;
        while j & bit != 0 {
            j ^= bit;
            bit >>= 1;
        }
        j ^= bit;
        if i < j {
            buf.swap(i, j);
        }
    }
}
