use super::Cx;

pub fn op_z9(buf: &mut [Cx], len: usize, factors: &[usize]) {
    if !len.is_power_of_two() {
        return;
    }
    op_y7(buf, factors);
}

pub fn op_y6(i: usize, factors: &[usize]) -> usize {
    let mut idx = i;
    let mut n = factors.iter().product::<usize>();
    let mut out = 0usize;
    for &f in factors {
        n /= f;
        out += (idx % f) * n;
        idx /= f;
    }
    out
}

pub fn op_y7(buf: &mut [Cx], factors: &[usize]) {
    let len = buf.len();
    if factors.is_empty() || len <= 1 {
        return;
    }
    let copy = buf.to_vec();
    for i in 0..len {
        let j = op_y6(i, factors);
        if j < len {
            buf[j] = copy[i];
        }
    }
}
