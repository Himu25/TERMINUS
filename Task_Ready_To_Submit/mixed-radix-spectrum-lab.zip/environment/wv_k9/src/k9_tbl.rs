use super::Cx;
use std::f64::consts::PI;

pub fn op_t3(n: usize, k: usize) -> Cx {
    let angle = -2.0 * PI * (k as f64) / (n as f64);
    Cx::new(angle.cos(), angle.sin())
}

pub fn op_t4(buf: &mut [Cx], _n: usize) {
    let len = buf.len();
    if len <= 1 {
        return;
    }
    let mut j = 0usize;
    for i in 1..len {
        let mut bit = len >> 1;
        while j & bit != 0 {
            j ^= bit;
            bit >>= 1;
        }
        j ^= bit;
        if i < j {
            buf.swap(i, j);
        }
    }
}
