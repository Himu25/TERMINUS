use super::{Cx, mixed_forward, mixed_inverse};
use std::f64::consts::PI;

pub fn op_b4(n: usize) -> usize {
    n.next_power_of_two()
}

fn chirp(n: usize, k: usize) -> Cx {
    let angle = -PI * (k * k) as f64 / (n as f64);
    Cx::new(angle.cos(), angle.sin())
}

fn chirp_inv(n: usize, k: usize) -> Cx {
    let angle = PI * (k * k) as f64 / (n as f64);
    Cx::new(angle.cos(), angle.sin())
}

pub fn chirp_forward(buf: &mut [Cx], p: usize) {
    if p < 2 {
        return;
    }
    let m = op_b4(p);
    let mut a = vec![Cx::new(0.0, 0.0); m];
    let mut b = vec![Cx::new(0.0, 0.0); m];

    for k in 0..p {
        a[k] = buf[k].mul(chirp(p, k));
    }
    for k in 0..p {
        b[k] = chirp_inv(p, k);
    }
    for k in 1..p {
        if m > k {
            b[m - k] = b[k];
        }
    }

    let factors = span_fac(m);
    mixed_forward(&mut a, &factors);
    mixed_forward(&mut b, &factors);
    for i in 0..m {
        a[i] = a[i].mul(b[i]);
    }
    mixed_inverse(&mut a, &factors);

    for k in 0..p {
        buf[k] = a[k].mul(chirp(p, k));
    }
}

pub fn chirp_inverse(buf: &mut [Cx], p: usize) {
    if p < 2 {
        return;
    }
    for v in buf.iter_mut() {
        v.im = -v.im;
    }
    chirp_forward(buf, p);
    let inv = 1.0 / p as f64;
    for v in buf.iter_mut() {
        v.im = -v.im;
        *v = v.scale(inv);
    }
}

fn span_fac(n: usize) -> Vec<usize> {
    let mut count = 0usize;
    let mut x = n;
    while x > 1 && x % 2 == 0 {
        count += 1;
        x /= 2;
    }
    let stages = if count > 0 { 1usize } else { 1usize };
    vec![2; stages]
}
