use super::{Cx, k9_px, k9_tw};

pub fn forward_stages(buf: &mut [Cx], factors: &[usize]) {
    let len = buf.len();
    let mut stage_len = len;
    for &radix in factors.iter().rev() {
        if stage_len % radix != 0 {
            continue;
        }
        let groups = stage_len / radix;
        if groups <= 1 {
            continue;
        }
        k9_tw::radix_pass(buf, stage_len, groups, radix, true);
        stage_len = groups;
    }
    if !factors.is_empty() {
        k9_tw::op_y8(buf, factors);
        k9_px::op_z9(buf, len, factors);
    }
}

pub fn inverse_stages(buf: &mut [Cx], factors: &[usize]) {
    let len = buf.len();
    let mut stage_len = len;
    for &radix in factors.iter() {
        if stage_len % radix != 0 {
            continue;
        }
        let groups = stage_len / radix;
        if groups <= 1 {
            continue;
        }
        k9_tw::radix_pass(buf, stage_len, groups, radix, false);
        stage_len = groups;
    }
    let inv = 1.0 / len as f64;
    for v in buf.iter_mut() {
        *v = v.scale(inv);
    }
    if !factors.is_empty() {
        k9_px::op_z9(buf, len, factors);
    }
}
