pub mod k9_tbl;
pub mod k9_tw;
pub mod k9_ch;
pub mod k9_px;
pub mod k9_st;
pub mod k9_rt;
pub mod k9_stg;

use std::f64::consts::PI;

#[derive(Clone, Copy, Debug)]
pub struct Cx {
    pub re: f64,
    pub im: f64,
}

impl Cx {
    pub fn new(re: f64, im: f64) -> Self {
        Self { re, im }
    }

    pub fn add(self, o: Self) -> Self {
        Self {
            re: self.re + o.re,
            im: self.im + o.im,
        }
    }

    pub fn sub(self, o: Self) -> Self {
        Self {
            re: self.re - o.re,
            im: self.im - o.im,
        }
    }

    pub fn mul(self, o: Self) -> Self {
        Self {
            re: self.re * o.re - self.im * o.im,
            im: self.re * o.im + self.im * o.re,
        }
    }

    pub fn scale(self, s: f64) -> Self {
        Self {
            re: self.re * s,
            im: self.im * s,
        }
    }

    pub fn mag(self) -> f64 {
        (self.re * self.re + self.im * self.im).sqrt()
    }
}

pub fn is_prime(n: usize) -> bool {
    if n < 2 {
        return false;
    }
    if n % 2 == 0 {
        return n == 2;
    }
    let mut i = 3usize;
    while i * i <= n {
        if n % i == 0 {
            return false;
        }
        i += 2;
    }
    true
}

pub fn gen_twiddle(n: usize, k: usize) -> Cx {
    let angle = -2.0 * PI * (k as f64) / (n as f64);
    Cx::new(angle.cos(), angle.sin())
}

pub fn mixed_forward(buf: &mut [Cx], factors: &[usize]) {
    let len = buf.len();
    if len <= 1 {
        return;
    }
    if len.is_power_of_two() && (factors.is_empty() || factors.iter().all(|&f| f == 2)) {
        k9_tw::pow2_forward(buf);
        return;
    }
    let mut factors = factors.to_vec();
    if factors.is_empty() {
        factors = default_factors(len);
    }
    k9_stg::forward_stages(buf, &factors);
}

pub fn mixed_inverse(buf: &mut [Cx], factors: &[usize]) {
    let len = buf.len();
    if len <= 1 {
        return;
    }
    if len.is_power_of_two() && (factors.is_empty() || factors.iter().all(|&f| f == 2)) {
        k9_tw::pow2_inverse(buf);
        return;
    }
    let mut factors = factors.to_vec();
    if factors.is_empty() {
        factors = default_factors(len);
    }
    k9_stg::inverse_stages(buf, &factors);
}

fn default_factors(mut n: usize) -> Vec<usize> {
    let mut out = Vec::new();
    for p in [2usize, 3, 5, 7, 11, 13] {
        while n % p == 0 {
            out.push(p);
            n /= p;
        }
    }
    while n > 1 {
        let mut d = 17;
        while d * d <= n {
            if n % d == 0 {
                break;
            }
            d += 2;
        }
        let f = if d * d <= n { d } else { n };
        out.push(f);
        n /= f;
    }
    out
}

pub fn run_pair(buf: &mut [Cx], factors: &[usize], flags: u32) -> f64 {
    let len = buf.len();
    if len == 0 {
        return 0.0;
    }
    let orig = buf.to_vec();
    let workers = ((flags >> 1) & 0xF).max(1) as usize;
    let parallel = flags & 1 != 0 && workers > 1;
    let inplace = flags & 0x100 != 0;

    k9_rt::op_r1(buf, factors, parallel, workers, inplace);

    let mut back = buf.to_vec();
    k9_rt::op_r0(&mut back, factors, parallel, workers, inplace);

    let mut max_err = 0.0f64;
    for (a, b) in orig.iter().zip(back.iter()) {
        max_err = max_err.max((a.re - b.re).abs()).max((a.im - b.im).abs());
    }
    max_err
}

pub fn serial_vs_parallel_delta(buf: &[Cx], factors: &[usize], workers: usize) -> f64 {
    let mut serial = buf.to_vec();
    k9_rt::op_r1(&mut serial, factors, false, 1, false);
    let mut par = buf.to_vec();
    k9_rt::op_r1(&mut par, factors, true, workers, false);
    let mut max_err = 0.0f64;
    for (a, b) in serial.iter().zip(par.iter()) {
        max_err = max_err.max((a.re - b.re).abs()).max((a.im - b.im).abs());
    }
    max_err
}

#[no_mangle]
pub extern "C" fn wc_run_pair(
    re: *mut f64,
    im: *mut f64,
    len: usize,
    factors: *const u32,
    factor_count: usize,
    flags: u32,
    out_err: *mut f64,
) -> i32 {
    if re.is_null() || im.is_null() || len == 0 {
        return -1;
    }
    let mut buf = Vec::with_capacity(len);
    unsafe {
        let rs = std::slice::from_raw_parts(re, len);
        let is = std::slice::from_raw_parts(im, len);
        for i in 0..len {
            buf.push(Cx::new(rs[i], is[i]));
        }
    }
    let facs: Vec<usize> = if factors.is_null() || factor_count == 0 {
        vec![]
    } else {
        unsafe {
            std::slice::from_raw_parts(factors, factor_count)
                .iter()
                .map(|&v| v as usize)
                .collect()
        }
    };
    let err = run_pair(&mut buf, &facs, flags);
    unsafe {
        if !out_err.is_null() {
            *out_err = err;
        }
    }
    0
}

#[no_mangle]
pub extern "C" fn wc_serial_parallel_delta(
    re: *const f64,
    im: *const f64,
    len: usize,
    factors: *const u32,
    factor_count: usize,
    workers: u32,
    out_err: *mut f64,
) -> i32 {
    if re.is_null() || im.is_null() || len == 0 {
        return -1;
    }
    let mut buf = Vec::with_capacity(len);
    unsafe {
        let rs = std::slice::from_raw_parts(re, len);
        let is = std::slice::from_raw_parts(im, len);
        for i in 0..len {
            buf.push(Cx::new(rs[i], is[i]));
        }
    }
    let facs: Vec<usize> = if factors.is_null() || factor_count == 0 {
        vec![]
    } else {
        unsafe {
            std::slice::from_raw_parts(factors, factor_count)
                .iter()
                .map(|&v| v as usize)
                .collect()
        }
    };
    let err = serial_vs_parallel_delta(&buf, &facs, workers.max(1) as usize);
    unsafe {
        if !out_err.is_null() {
            *out_err = err;
        }
    }
    0
}

#[cfg(test)]
mod smoke {
    use super::*;

    #[test]
    fn pow2_roundtrip() {
        let mut buf = vec![Cx::new(0.0, 0.0); 8];
        for i in 0..8 {
            buf[i] = Cx::new((i as f64).sin(), 0.0);
        }
        let err = run_pair(&mut buf, &[2, 2, 2], 0);
        assert!(err < 1e-9);
    }
}
