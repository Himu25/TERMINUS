package main

import (
	"os"
	"path/filepath"

	"spectrum/internal/driver"
)

func main() {
	manifest := "/app/data/active/manifest.json"
	if v := os.Getenv("TB_WAVE_MANIFEST"); v != "" {
		manifest = v
	}
	out := "/app/output/spectrum_report.json"
	if err := driver.Run(manifest, out); err != nil {
		os.Stderr.WriteString(err.Error() + "\n")
		os.Exit(1)
	}
	_ = filepath.Base(manifest)
}
