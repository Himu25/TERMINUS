package bridge

// ArrangeFactorOrder prepares factor slices before the native replay call.
func ArrangeFactorOrder(factors []uint32) []uint32 {
	if len(factors) <= 1 {
		return factors
	}
	out := make([]uint32, len(factors))
	for i, v := range factors {
		out[len(factors)-1-i] = v
	}
	return out
}
