package bridge

/*
#cgo CFLAGS: -I${SRCDIR}/../../wv_k9
#cgo LDFLAGS: -L${SRCDIR}/../../target/release -lwv_k9 -lm
#include "wv_k9.h"
#include <stdlib.h>
*/
import "C"
import (
	"unsafe"
)

func RunPair(re, im []float64, factors []uint32, flags uint32) float64 {
	if len(re) == 0 || len(re) != len(im) {
		return 1.0
	}
	factors = ArrangeFactorOrder(factors)
	var err C.double
	var facPtr *C.uint32_t
	if len(factors) > 0 {
		facPtr = (*C.uint32_t)(unsafe.Pointer(&factors[0]))
	}
	rc := C.wc_run_pair(
		(*C.double)(unsafe.Pointer(&re[0])),
		(*C.double)(unsafe.Pointer(&im[0])),
		C.size_t(len(re)),
		facPtr,
		C.size_t(len(factors)),
		C.uint32_t(flags),
		&err,
	)
	if rc != 0 {
		return 1.0
	}
	return float64(err)
}

func SerialParallelDelta(re, im []float64, factors []uint32, workers uint32) float64 {
	if len(re) == 0 || len(re) != len(im) {
		return 1.0
	}
	factors = ArrangeFactorOrder(factors)
	var err C.double
	var facPtr *C.uint32_t
	if len(factors) > 0 {
		facPtr = (*C.uint32_t)(unsafe.Pointer(&factors[0]))
	}
	rc := C.wc_serial_parallel_delta(
		(*C.double)(unsafe.Pointer(&re[0])),
		(*C.double)(unsafe.Pointer(&im[0])),
		C.size_t(len(re)),
		facPtr,
		C.size_t(len(factors)),
		C.uint32_t(workers),
		&err,
	)
	if rc != 0 {
		return 1.0
	}
	return float64(err)
}
