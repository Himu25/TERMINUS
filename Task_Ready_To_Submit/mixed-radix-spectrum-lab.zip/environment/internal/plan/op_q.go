package plan

// OpQ folds a length into a small lane tag used by profile metadata only.
func OpQ(n uint64) uint64 {
	var acc uint64
	for n > 1 {
		acc += n % 10
		n /= 10
	}
	return acc
}
