package plan

func OpP(n uint64) []uint32 {
	var out []uint32
	for n%2 == 0 {
		out = append(out, 2)
		n /= 2
	}
	for n%5 == 0 {
		out = append(out, 5)
		n /= 5
	}
	if n%3 == 0 {
		out = append(out, 3)
		n /= 3
	}
	if n > 1 {
		out = append(out, uint32(n))
	}
	return out
}
