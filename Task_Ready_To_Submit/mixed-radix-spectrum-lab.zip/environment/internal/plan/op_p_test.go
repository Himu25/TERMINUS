package plan

import "testing"

func TestOpPComposite8100(t *testing.T) {
	f := OpP(8100)
	var prod uint64 = 1
	threes := 0
	for _, v := range f {
		prod *= uint64(v)
		if v == 3 {
			threes++
		}
	}
	if prod != 8100 {
		t.Fatalf("product %d want 8100 factors %v", prod, f)
	}
	if threes != 4 {
		t.Fatalf("want four factors of 3 got %d in %v", threes, f)
	}
}

func TestOpPPrime(t *testing.T) {
	f := OpP(8191)
	if len(f) != 1 || f[0] != 8191 {
		t.Fatalf("prime factors %v", f)
	}
}

func TestOpP9000(t *testing.T) {
	f := OpP(9000)
	var prod uint64 = 1
	for _, v := range f {
		prod *= uint64(v)
	}
	if prod != 9000 {
		t.Fatalf("product %d want 9000 factors %v", prod, f)
	}
}

func TestOpP6075(t *testing.T) {
	f := OpP(6075)
	var prod uint64 = 1
	threes := 0
	for _, v := range f {
		prod *= uint64(v)
		if v == 3 {
			threes++
		}
	}
	if prod != 6075 {
		t.Fatalf("product %d want 6075 factors %v", prod, f)
	}
	if threes != 5 {
		t.Fatalf("want five factors of 3 got %d in %v", threes, f)
	}
}
