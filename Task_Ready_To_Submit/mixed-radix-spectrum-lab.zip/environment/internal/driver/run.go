package driver

import (
	"encoding/json"
	"math"
	"os"
	"path/filepath"

	"spectrum/internal/bridge"
	"spectrum/internal/plan"
	"spectrum/pkg/fold"
)

type StemSpec struct {
	Name   string `json:"name"`
	Length uint64 `json:"length"`
	Seed   uint64 `json:"seed"`
	Mode   string `json:"mode"`
}

type Manifest struct {
	LabID   string     `json:"lab_id"`
	Threads uint32     `json:"threads"`
	Stems   []StemSpec `json:"stems"`
}

type StemRow struct {
	Name        string  `json:"name"`
	Length      uint64  `json:"length"`
	MaxAbsError float64 `json:"max_abs_error"`
	Passed      int     `json:"passed"`
	Lane        string  `json:"lane"`
}

type Report struct {
	SchemaVersion   int       `json:"schema_version"`
	LabID           string    `json:"lab_id"`
	StemsTotal      int       `json:"stems_total"`
	StemsPassed     int       `json:"stems_passed"`
	MaxAbsError     float64   `json:"max_abs_error"`
	InplaceOK       int       `json:"inplace_ok"`
	ThreadParityOK  int       `json:"thread_parity_ok"`
	DigestHex       string    `json:"digest_hex"`
	Stems           []StemRow `json:"stems"`
}

const passTol = 1e-5

func LoadManifest(path string) (*Manifest, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var m Manifest
	if err := json.Unmarshal(raw, &m); err != nil {
		return nil, err
	}
	return &m, nil
}

func Run(manifestPath, outPath string) error {
	m, err := LoadManifest(manifestPath)
	if err != nil {
		return err
	}
	report := Report{
		SchemaVersion:  2,
		LabID:          m.LabID,
		StemsTotal:     len(m.Stems),
		InplaceOK:      1,
		ThreadParityOK: 1,
	}
	var maxAll float64
	for _, stem := range m.Stems {
		re, im := GenSignal(stem.Length, stem.Seed)
		factors := plan.OpP(stem.Length)
		flags := OpE1(stem.Mode, m.Threads)
		_ = plan.OpQ(stem.Length)
		errVal := bridge.RunPair(re, im, factors, flags)
		row := StemRow{
			Name:        stem.Name,
			Length:      stem.Length,
			MaxAbsError: errVal,
			Lane:        laneLabel(stem.Length, stem.Mode),
		}
		if errVal <= passTol {
			row.Passed = 1
			report.StemsPassed++
		}
		if errVal > maxAll {
			maxAll = errVal
		}
		if stem.Mode == "inplace" && errVal > passTol {
			report.InplaceOK = 0
		}
		if stem.Mode == "parallel" {
			delta := bridge.SerialParallelDelta(re, im, factors, m.Threads)
			if delta > passTol {
				report.ThreadParityOK = 0
			}
		}
		report.Stems = append(report.Stems, row)
	}
	report.MaxAbsError = maxAll
	report.DigestHex = fold.DigestReport(report.StemsTotal, report.StemsPassed, report.MaxAbsError, report.InplaceOK, report.ThreadParityOK)
	if err := os.MkdirAll(filepath.Dir(outPath), 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(outPath, raw, 0o644)
}

func laneLabel(length uint64, mode string) string {
	if mode == "parallel" {
		return "stripe"
	}
	if isPrime(length) {
		return "chirp"
	}
	return "radix"
}

func isPrime(n uint64) bool {
	if n < 2 {
		return false
	}
	if n%2 == 0 {
		return n == 2
	}
	for i := uint64(3); i*i <= n; i += 2 {
		if n%i == 0 {
			return false
		}
	}
	return true
}

func GenSignal(length, seed uint64) ([]float64, []float64) {
	re := make([]float64, length)
	im := make([]float64, length)
	state := seed ^ 0x9E3779B97F4A7C15
	for i := uint64(0); i < length; i++ {
		state = state*6364136223846793005 + 1
		phase := float64(i) / float64(length)
		re[i] = math.Sin(2*math.Pi*7*phase) + 0.3*math.Cos(2*math.Pi*13*phase+float64(state%997)/997.0)
		im[i] = 0.15 * math.Sin(2*math.Pi*5*phase)
	}
	return re, im
}
