package driver

// OpE1 packs replay mode and worker count into the native flag word.
func OpE1(mode string, threads uint32) uint32 {
	var flags uint32
	switch mode {
	case "parallel":
		flags |= 1
		flags |= ((threads >> 1) & 0xF) << 1
	case "inplace":
		flags |= 0x100
	}
	return flags
}
