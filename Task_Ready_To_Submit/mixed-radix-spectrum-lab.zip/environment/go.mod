module spectrum

go 1.24
