package main

import (
	"fmt"
	"os"
	"strconv"

	"spectrum/pkg/fold"
)

func main() {
	if len(os.Args) < 6 {
		os.Exit(2)
	}
	total, err := strconv.Atoi(os.Args[1])
	if err != nil {
		os.Exit(2)
	}
	passed, err := strconv.Atoi(os.Args[2])
	if err != nil {
		os.Exit(2)
	}
	maxErr, err := strconv.ParseFloat(os.Args[3], 64)
	if err != nil {
		os.Exit(2)
	}
	inplace, err := strconv.Atoi(os.Args[4])
	if err != nil {
		os.Exit(2)
	}
	threadOK, err := strconv.Atoi(os.Args[5])
	if err != nil {
		os.Exit(2)
	}
	fmt.Println(fold.DigestReport(total, passed, maxErr, inplace, threadOK))
}
