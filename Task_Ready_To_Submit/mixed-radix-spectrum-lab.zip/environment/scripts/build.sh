#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
cd /app

mkdir -p /app/bin /app/output /app/target/release

export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/app/target}"
export RUSTFLAGS="-C target-cpu=generic"

cargo build --release -p wv_k9

export CGO_ENABLED=1
export CGO_CFLAGS="-I/app/wv_k9"
export CGO_LDFLAGS="-L/app/target/release -lwv_k9 -lm"
export GOFLAGS="-mod=mod"
export GOCACHE="${GOCACHE:-/app/output/go-build}"
export GOTMPDIR="${GOTMPDIR:-/tmp}"

install -d -m 0777 /app/output/go-build

go build -trimpath -ldflags="-s -w" -o /app/bin/spectrum_lab ./cmd/spectrum_lab
go build -trimpath -ldflags="-s -w" -o /app/bin/digest_cli ./tools/digest_cli
