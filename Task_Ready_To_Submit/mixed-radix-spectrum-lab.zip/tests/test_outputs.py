"""Verifier for the wave replay lab."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "spectrum_report.json"
BIN = "/app/bin/spectrum_lab"
ACTIVE_MANIFEST = APP / "data/active/manifest.json"
REPORT_EXAMPLE = APP / "schemas/report.example.json"
FIXTURE_INDEX = APP / "docs/fixture_index.txt"
REG_PRIME = APP / "data/regression/stem_prime/manifest.json"
REG_MIXED = APP / "data/regression/stem_mixed/manifest.json"
REG_TRIPLE = APP / "data/regression/stem_triple/manifest.json"

SCHEMA_VERSION = 2
PASS_TOL = 1e-5
REF_TOL = 1e-4


def _run_lab(manifest: Path | None = None) -> dict:
    env = {**os.environ, "TB_WAVE_FIXTURE": "1"}
    if manifest is not None:
        env["TB_WAVE_MANIFEST"] = str(manifest)
    subprocess.run([BIN], cwd="/app", env=env, check=True)
    return json.loads(OUT.read_text())


@pytest.fixture(scope="session")
def active_report() -> dict:
    """Single active-manifest replay shared across behavioral tests."""
    return _run_lab()


def _stem_row(report: dict, name: str) -> dict:
    for row in report["stems"]:
        if row["name"] == name:
            return row
    raise KeyError(name)


def test_r01_report_shape(active_report: dict) -> None:
    """Report carries the lab schema version and active lab id."""
    manifest = json.loads(ACTIVE_MANIFEST.read_text())
    example = json.loads(REPORT_EXAMPLE.read_text())
    assert active_report["schema_version"] == SCHEMA_VERSION
    assert active_report["lab_id"] == manifest["lab_id"]
    assert active_report["stems_total"] == len(manifest["stems"])
    for key in example:
        if key != "stems":
            assert key in active_report


def test_r02_bundle_clean(active_report: dict) -> None:
    """Every active stem completes with low round-trip error."""
    assert active_report["stems_passed"] == active_report["stems_total"]
    assert active_report["max_abs_error"] <= PASS_TOL
    for row in active_report["stems"]:
        assert row["passed"]
        assert row["max_abs_error"] <= PASS_TOL


def test_r03_prime_tol(active_report: dict) -> None:
    """Large prime stem round-trip error stays within the lab tolerance."""
    row = _stem_row(active_report, "stem_prime")
    assert row["max_abs_error"] <= REF_TOL
    assert row["lane"] == "chirp"


def test_r04_mixed_tol(active_report: dict) -> None:
    """Composite stem round-trip error stays within the lab tolerance."""
    row = _stem_row(active_report, "stem_mixed")
    assert row["max_abs_error"] <= REF_TOL
    assert row["lane"] == "radix"


def test_r05_inplace_gate(active_report: dict) -> None:
    """In-place stem round-trips without buffer corruption."""
    assert active_report["inplace_ok"]
    row = _stem_row(active_report, "stem_inplace")
    assert row["passed"]
    assert row["lane"] == "radix"


def test_r06_thread_gate(active_report: dict) -> None:
    """Parallel stem matches serial forward output."""
    assert active_report["thread_parity_ok"]
    row = _stem_row(active_report, "stem_parallel")
    assert row["passed"]
    assert row["lane"] == "stripe"


def test_r07_digest_bind(active_report: dict) -> None:
    """Report digest matches digest_cli over counters."""
    proc = subprocess.run(
        [
            "/app/bin/digest_cli",
            str(active_report["stems_total"]),
            str(active_report["stems_passed"]),
            f"{active_report['max_abs_error']:.12e}",
            str(active_report["inplace_ok"]),
            str(active_report["thread_parity_ok"]),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    assert proc.stdout.strip() == active_report["digest_hex"]


def test_r08_go_units() -> None:
    """Go plan package unit tests pass."""
    env = {
        **os.environ,
        "CGO_ENABLED": "1",
        "CGO_CFLAGS": "-I/app/wv_k9",
        "CGO_LDFLAGS": "-L/app/target/release -lwv_k9 -lm",
        "GOFLAGS": "-mod=mod",
    }
    subprocess.run(
        ["go", "test", "./internal/plan/..."],
        cwd="/app",
        env=env,
        check=True,
    )


def test_r09_rust_units() -> None:
    """Rust workspace smoke test passes."""
    env = {**os.environ, "CARGO_TARGET_DIR": "/app/target"}
    subprocess.run(
        ["cargo", "test", "--release", "-p", "wv_k9", "pow2_roundtrip"],
        cwd="/app",
        env=env,
        check=True,
    )


def test_r10_regression_a() -> None:
    """Prime regression bundle replays within tolerance."""
    report = _run_lab(manifest=REG_PRIME)
    row = _stem_row(report, "stem_prime")
    assert row["max_abs_error"] <= REF_TOL
    assert row["passed"]


def test_r11_regression_b() -> None:
    """Mixed regression bundle replays within tolerance."""
    report = _run_lab(manifest=REG_MIXED)
    row = _stem_row(report, "stem_mixed")
    assert row["max_abs_error"] <= REF_TOL
    assert row["passed"]


def test_r12_fixture_index() -> None:
    """Regression bundles named in the fixture index exist on disk."""
    entries = [
        line.strip()
        for line in FIXTURE_INDEX.read_text().splitlines()
        if line.strip() and not line.startswith("#")
    ]
    names: list[str] = []
    for entry in entries:
        if entry.startswith("/app/data/regression/"):
            names.append(Path(entry).parent.name)
        else:
            names.append(entry)
    assert "stem_prime" in names
    assert "stem_mixed" in names
    assert "stem_triple" in names
    for name in names:
        assert (APP / "data/regression" / name / "manifest.json").is_file()


def test_r13_pow2_baseline(active_report: dict) -> None:
    """Power-of-two stem stays numerically tight."""
    row = _stem_row(active_report, "stem_pow2")
    assert row["max_abs_error"] <= 1e-9
    assert row["lane"] == "radix"


def test_r14_triple_tol(active_report: dict) -> None:
    """Repeated small-prime composite stem round-trips within tolerance."""
    row = _stem_row(active_report, "stem_triple")
    assert row["max_abs_error"] <= REF_TOL
    assert row["passed"]
    assert row["lane"] == "radix"


def test_r15_parallel_tol(active_report: dict) -> None:
    """Parallel lane round-trip error stays within tolerance."""
    row = _stem_row(active_report, "stem_parallel")
    assert row["max_abs_error"] <= REF_TOL
    assert row["passed"]


def test_r16_regression_triple() -> None:
    """Triple-prime regression bundle replays within tolerance."""
    report = _run_lab(manifest=REG_TRIPLE)
    row = _stem_row(report, "stem_triple")
    assert row["max_abs_error"] <= REF_TOL
    assert row["passed"]


def test_r17_fixture_index_triple() -> None:
    """Fixture index lists the triple-prime regression bundle."""
    entries = [
        line.strip()
        for line in FIXTURE_INDEX.read_text().splitlines()
        if line.strip() and not line.startswith("#")
    ]
    names: list[str] = []
    for entry in entries:
        if entry.startswith("/app/data/regression/"):
            names.append(Path(entry).parent.name)
        else:
            names.append(entry)
    assert "stem_triple" in names
