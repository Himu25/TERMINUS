#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

sed -i 's/n as f64 + 1.0/n as f64/' /app/wv_k9/src/k9_tw.rs

sed -i 's/n.next_power_of_two()/(2 * n - 1).next_power_of_two()/' /app/wv_k9/src/k9_ch.rs

sed -i 's/if !len.is_power_of_two()/if factors.is_empty()/' /app/wv_k9/src/k9_px.rs

perl -0pi -e 's/pub fn op_y8\(buf: &mut \[Cx\], factors: &\[usize\]\) \{.*?^\}/pub fn op_y8(buf: \&mut [Cx], factors: \&[usize]) {\n    crate::k9_px::op_y7(buf, factors);\n}/ms' /app/wv_k9/src/k9_tw.rs

perl -0pi -e 's/        if groups <= 1 \{\n            continue;\n        \}\n        //g' /app/wv_k9/src/k9_stg.rs

perl -0pi -e 's/\} else \{\n        mixed_forward\(buf, factors\);\n    \}/} else if !len.is_power_of_two() {\n        chirp_forward(buf, len);\n    } else {\n        mixed_forward(buf, factors);\n    }/s' /app/wv_k9/src/k9_rt.rs
perl -0pi -e 's/\} else \{\n        mixed_inverse\(buf, factors\);\n    \}/} else if !len.is_power_of_two() {\n        chirp_inverse(buf, len);\n    } else {\n        mixed_inverse(buf, factors);\n    }/s' /app/wv_k9/src/k9_rt.rs

sed -i 's/mixed_forward(buf, factors);$/mixed_inverse(buf, factors);/' /app/wv_k9/src/k9_st.rs

perl -0pi -e 's/pub fn op_s3\(buf: &mut \[Cx\], factors: &\[usize\], workers: usize\) \{.*?^}/pub fn op_s3(buf: \&mut [Cx], factors: \&[usize], workers: usize) {\n    let _ = (workers, stripe_bounds(buf.len(), workers, factors.first().copied().unwrap_or(2)));\n    mixed_forward(buf, factors);\n}/ms' /app/wv_k9/src/k9_st.rs

perl -0pi -e 's/pub fn stripe_bounds\(len: usize, workers: usize, factor: usize\) -> Vec<\(usize, usize\)> \{.*?^}/pub fn stripe_bounds(len: usize, workers: usize, factor: usize) -> Vec<(usize, usize)> {\n    let stripes = workers.min(len \/ factor.max(1)).max(1);\n    let chunk = (len \/ stripes \/ factor.max(1)) * factor.max(1);\n    if chunk == 0 {\n        return vec![(0, len)];\n    }\n    let mut out = Vec::new();\n    let mut start = 0usize;\n    for s in 0..stripes {\n        let end = if s + 1 == stripes { len } else { start + chunk };\n        out.push((start, end));\n        start = end;\n    }\n    out\n}/ms' /app/wv_k9/src/k9_st.rs

perl -0pi -e 's/    let stages = if count > 0 \{ 1usize \} else \{ 1usize \};/    let stages = count.max(1);/' /app/wv_k9/src/k9_ch.rs

sed -i 's/((threads >> 1) \& 0xF)/((threads \& 0xF))/' /app/internal/driver/encode.go

cat > /app/internal/plan/op_p.go <<'EOF'
package plan

func OpP(n uint64) []uint32 {
	var out []uint32
	for _, p := range []uint64{2, 3, 5} {
		for n%p == 0 {
			out = append(out, uint32(p))
			n /= p
		}
	}
	for d := uint64(7); d*d <= n; d += 2 {
		for n%d == 0 {
			out = append(out, uint32(d))
			n /= d
		}
	}
	if n > 1 {
		out = append(out, uint32(n))
	}
	return out
}
EOF

perl -0pi -e 's/for i, v := range factors \{\n\t\tout\[len\(factors\)-1-i\] = v\n\t\}/copy(out, factors)/s' /app/internal/bridge/canon.go

bash /app/scripts/build.sh

rm -f /app/output/spectrum_report.json
mkdir -p /app/output
TB_WAVE_FIXTURE=1 /app/bin/spectrum_lab
test -s /app/output/spectrum_report.json

env CGO_ENABLED=1 CGO_CFLAGS="-I/app/wv_k9" CGO_LDFLAGS="-L/app/target/release -lwv_k9 -lm" GOFLAGS=-mod=mod \
  go test ./internal/plan/...

cargo test --release -p wv_k9 pow2_roundtrip
