"""Verifier for synthetic diversity collapse audit."""

import json
import os
import shutil
import subprocess

import pytest
from pathlib import Path

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = APP / "data" / "replay"
OUT = APP / "output" / "diversity_audit.json"
GO_BIN = "/usr/local/go/bin/go"
VERIFY_BIN = "/tmp/gen_audit_verify_bin"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)
    subprocess.run(["cp", "/app/bin/gen_audit", VERIFY_BIN], check=True)


def _digest_hex(
    batch_id: str,
    batch_count: int,
    unique_text_rate_pct: int,
    paraphrase_pair_count: int,
    template_leak_hits: int,
    label_skew_x100: int,
    entropy_score_x100: int,
    collapse_band: str,
) -> str:
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            batch_id,
            str(batch_count),
            str(unique_text_rate_pct),
            str(paraphrase_pair_count),
            str(template_leak_hits),
            str(label_skew_x100),
            str(entropy_score_x100),
            collapse_band,
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _op_l(counts: list[int], target_pct: list[int]) -> int:
    total = sum(counts)
    if total == 0:
        return 0
    max_dev = 0
    for i, c in enumerate(counts):
        if i >= len(target_pct):
            break
        actual = (c * 100) // total
        dev = abs(actual - target_pct[i])
        if dev > max_dev:
            max_dev = dev
    return max_dev * 100


def _op_t(prev_template: str, cur_template: str, rotate_required: bool) -> bool:
    if not rotate_required:
        return False
    return prev_template == cur_template


def _op_n(sig_a: int, sig_b: int, window: int) -> bool:
    if sig_a == sig_b:
        return True
    if window <= 0:
        return False
    return abs(sig_a - sig_b) <= window


def _entropy_fold(base: float, spread: float) -> float:
    return base + spread


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = FIXTURES / pack_name
    bundle = json.loads((pack_dir / "diversity_bundle.json").read_text())
    rows = []
    for line in (pack_dir / "generations.jsonl").read_text().splitlines():
        if line.strip():
            rows.append(json.loads(line))
    rows.sort(key=lambda r: (r["batch"], r["slot"]))

    paraphrase_pairs = 0
    template_leaks = 0
    total_gen = 0
    global_unique: set[int] = set()
    label_counts = [0] * bundle["label_classes"]
    entropy = 50.0

    cur_batch = -1
    batch_sigs: list[int] = []
    batch_unique: set[int] = set()
    prev_template = ""

    for row in rows:
        if row["batch"] != cur_batch:
            if cur_batch >= 0:
                entropy = _entropy_fold(entropy, float(len(batch_unique)) * 5.0)
            cur_batch = row["batch"]
            batch_sigs = []
            batch_unique = set()
            prev_template = ""
        if row["slot"] <= 0:
            continue
        total_gen += 1
        global_unique.add(row["semantic_sig"])
        batch_unique.add(row["semantic_sig"])

        label = row["label"]
        if 0 <= label < bundle["label_classes"]:
            label_counts[label] += 1

        for prev_sig in batch_sigs:
            if _op_n(prev_sig, row["semantic_sig"], bundle["paraphrase_window"]):
                paraphrase_pairs += 1
        batch_sigs.append(row["semantic_sig"])

        rotate_required = row["slot"] > 0 and row["slot"] % bundle["template_rotate_every"] == 0
        if _op_t(prev_template, row["template_id"], rotate_required):
            template_leaks += 1
        prev_template = row["template_id"]

    if cur_batch >= 0:
        entropy = _entropy_fold(entropy, float(len(batch_unique)) * 5.0)

    unique_rate = (len(global_unique) * 100) // total_gen if total_gen else 0
    skew_x100 = _op_l(label_counts, bundle["target_label_pct"])
    score_x100 = max(0, int(entropy * 100))
    band = (
        "spread"
        if score_x100 >= bundle["entropy_floor_x100"]
        else "collapsed"
    )
    batches = bundle["batch_count"]
    digest = _digest_hex(
        bundle["batch_id"],
        batches,
        unique_rate,
        paraphrase_pairs,
        template_leaks,
        skew_x100,
        score_x100,
        band,
    )
    return {
        "schema_version": "1",
        "batch_id": bundle["batch_id"],
        "batch_count": batches,
        "unique_text_rate_pct": unique_rate,
        "paraphrase_pair_count": paraphrase_pairs,
        "template_leak_hits": template_leaks,
        "label_skew_x100": skew_x100,
        "entropy_score_x100": score_x100,
        "collapse_band": band,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_GEN_DIVERSITY": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_alpha_report_matches_replay() -> None:
    """Alpha pack should replay all audit counters including digest."""
    _swap("div_alpha")
    exp = _expected_from_fixture("div_alpha")
    got = _run_tool()
    assert got == exp


def test_alpha_unique_text_rate_matches_replay() -> None:
    """Alpha pack should match replay unique-text rate percentage."""
    _swap("div_alpha")
    exp = _expected_from_fixture("div_alpha")
    got = _run_tool()
    assert got["unique_text_rate_pct"] == exp["unique_text_rate_pct"]


def test_paraphrase_report_matches_replay() -> None:
    """Paraphrase pack should match replay counters for near-duplicate pairs."""
    _swap("div_paraphrase")
    exp = _expected_from_fixture("div_paraphrase")
    got = _run_tool()
    assert got["paraphrase_pair_count"] == exp["paraphrase_pair_count"]


def test_template_report_matches_replay() -> None:
    """Template pack should match replay counters for lane leak hits."""
    _swap("div_template")
    exp = _expected_from_fixture("div_template")
    got = _run_tool()
    assert got["template_leak_hits"] == exp["template_leak_hits"]


def test_label_report_matches_replay() -> None:
    """Label pack should match replay counters for label skew."""
    _swap("div_label")
    exp = _expected_from_fixture("div_label")
    got = _run_tool()
    assert got["label_skew_x100"] == exp["label_skew_x100"]


def test_spread_report_matches_replay() -> None:
    """Spread pack should match replay collapse band and entropy score."""
    _swap("div_spread")
    exp = _expected_from_fixture("div_spread")
    got = _run_tool()
    assert got["collapse_band"] == exp["collapse_band"]
    assert got["entropy_score_x100"] == exp["entropy_score_x100"]


def test_alpha_template_leak_matches_replay() -> None:
    """Alpha should report zero template leak hits with clean rotation."""
    _swap("div_alpha")
    exp = _expected_from_fixture("div_alpha")
    got = _run_tool()
    assert got["template_leak_hits"] == exp["template_leak_hits"]


def test_go_subsystem_tests_pass() -> None:
    """Go tests under /app must pass after the repair."""
    subprocess.run(
        [GO_BIN, "test", "./..."],
        cwd="/app",
        env={
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        },
        check=True,
    )
