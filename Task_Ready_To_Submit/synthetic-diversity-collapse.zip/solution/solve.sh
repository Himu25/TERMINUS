#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

write_op_l() {
  cat > /app/pkg/labelmix/op_l.go <<'EOF'
package labelmix

func maxDev(counts []int, targetPct []int) int {
	total := 0
	for _, c := range counts {
		total += c
	}
	if total == 0 {
		return 0
	}
	max := 0
	for i := 0; i < len(counts) && i < len(targetPct); i++ {
		actual := (counts[i] * 100) / total
		dev := actual - targetPct[i]
		if dev < 0 {
			dev = -dev
		}
		if dev > max {
			max = dev
		}
	}
	return max
}

// OpL returns label-mix skew x100 given observed counts and target percentage shares.
func OpL(counts []int, targetPct []int) int {
	return maxDev(counts, targetPct) * 100
}
EOF
}

write_op_t() {
  cat > /app/pkg/templatelane/op_t.go <<'EOF'
package templatelane

// OpT reports a lane leak when rotation was required but the template id stayed the same.
func OpT(prevTemplate, curTemplate string, rotateRequired bool) bool {
	if !rotateRequired {
		return false
	}
	return prevTemplate == curTemplate
}
EOF
}

write_op_n() {
  cat > /app/pkg/nearfold/op_n.go <<'EOF'
package nearfold

func sigDiff(a, b int) int {
	d := a - b
	if d < 0 {
		return -d
	}
	return d
}

// OpN reports whether two semantic signatures count as a near pair within window.
func OpN(sigA, sigB, window int) bool {
	if sigA == sigB {
		return true
	}
	if window <= 0 {
		return false
	}
	return sigDiff(sigA, sigB) <= window
}
EOF
}

write_foldgate() {
  cat > /app/foldgate/src/lib.rs <<'EOF'
/// DgEntropyFold folds batch spread into the running score.
#[no_mangle]
pub extern "C" fn dg_entropy_fold(base: f64, delta: f64) -> f64 {
    base + delta
}
EOF
}

write_op_l
write_op_t
write_op_n
write_foldgate

bash /app/scripts/build.sh

GOFLAGS=-mod=mod CGO_ENABLED=1 go test ./pkg/labelmix ./pkg/templatelane ./pkg/nearfold -count=1

rm -f /app/output/diversity_audit.json
TB_GEN_DIVERSITY=1 /app/bin/gen_audit
test -s /app/output/diversity_audit.json
