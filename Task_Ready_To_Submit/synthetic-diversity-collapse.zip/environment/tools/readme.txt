Verifier helpers include /tmp/gen_audit_verify_bin and /app/tools/digest_cli for digest recomputation.
Build the audit driver with /app/scripts/build.sh using /usr/local/go/bin/go and cargo.
