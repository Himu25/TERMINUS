package main

import (
	"fmt"
	"os"

	"lab.local/synthetic_diversity_collapse/pkg/digest"
)

func main() {
	if len(os.Args) != 9 {
		fmt.Fprintln(os.Stderr, "usage: digest_cli batch_id batch_count unique_text_rate_pct paraphrase_pair_count template_leak_hits label_skew_x100 entropy_score_x100 collapse_band")
		os.Exit(2)
	}
	fmt.Println(digest.FoldReport(os.Args[1], os.Args[2], os.Args[3], os.Args[4], os.Args[5], os.Args[6], os.Args[7], os.Args[8]))
}
