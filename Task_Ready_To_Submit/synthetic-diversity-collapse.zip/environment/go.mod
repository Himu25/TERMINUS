module lab.local/synthetic_diversity_collapse

go 1.22
