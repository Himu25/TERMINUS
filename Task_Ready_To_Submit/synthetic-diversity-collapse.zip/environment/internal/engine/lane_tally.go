package engine

import "lab.local/synthetic_diversity_collapse/pkg/templatelane"

func tallyLaneLeak(prevTemplate, curTemplate string, rotateRequired bool) bool {
	return templatelane.OpT(prevTemplate, curTemplate, rotateRequired)
}
