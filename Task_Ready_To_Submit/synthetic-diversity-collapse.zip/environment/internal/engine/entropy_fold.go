package engine

import "lab.local/synthetic_diversity_collapse/foldgate"

// foldBatchEntropy applies unique signature spread for a closed batch.
func foldBatchEntropy(entropy float64, uniqueSigs int) float64 {
	spread := float64(uniqueSigs) * 5.0
	return foldgate.EntropyFold(entropy, spread)
}
