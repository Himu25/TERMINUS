package engine

import (
	"lab.local/synthetic_diversity_collapse/internal/config"
	"lab.local/synthetic_diversity_collapse/pkg/gen"
)

// Outcome is the folded counters for one pack replay.
type Outcome struct {
	BatchCount          int
	UniqueTextRatePct   int
	ParaphrasePairCount int
	TemplateLeakHits    int
	LabelSkewX100       int
	EntropyScoreX100    int
	CollapseBand        string
}

// Replay executes one active pack through the audit pipeline.
func Replay(bundle config.Bundle, rows []gen.Row) Outcome {
	sortRows(rows)
	paraphrasePairs := 0
	templateLeaks := 0
	totalGen := 0
	globalUnique := map[int]struct{}{}
	labelCounts := make([]int, bundle.LabelClasses)
	entropy := 50.0

	curBatch := -1
	batchSigs := []int{}
	batchUnique := map[int]struct{}{}
	prevTemplate := ""

	for _, row := range rows {
		if row.Batch != curBatch {
			if curBatch >= 0 {
				entropy = foldBatchEntropy(entropy, len(batchUnique))
			}
			curBatch = row.Batch
			batchSigs = []int{}
			batchUnique = map[int]struct{}{}
			prevTemplate = ""
		}
		if row.Slot <= 0 {
			continue
		}
		totalGen++
		globalUnique[row.SemanticSig] = struct{}{}
		batchUnique[row.SemanticSig] = struct{}{}

		if row.Label >= 0 && row.Label < bundle.LabelClasses {
			labelCounts[row.Label]++
		}

		for _, prevSig := range batchSigs {
			if tallyNearPair(prevSig, row.SemanticSig, bundle.ParaphraseWindow) {
				paraphrasePairs++
			}
		}
		batchSigs = append(batchSigs, row.SemanticSig)

		rotateRequired := row.Slot > 0 && row.Slot%bundle.TemplateRotateEvery == 0
		if tallyLaneLeak(prevTemplate, row.TemplateID, rotateRequired) {
			templateLeaks++
		}
		prevTemplate = row.TemplateID
	}
	if curBatch >= 0 {
		entropy = foldBatchEntropy(entropy, len(batchUnique))
	}

	uniqueRate := 0
	if totalGen > 0 {
		uniqueRate = (len(globalUnique) * 100) / totalGen
	}
	skewX100 := foldMixSkew(labelCounts, bundle.TargetLabelPct)
	scoreX100 := int(entropy * 100)
	if scoreX100 < 0 {
		scoreX100 = 0
	}
	band := "spread"
	if scoreX100 < bundle.EntropyFloorX100 {
		band = "collapsed"
	}
	batches := bundle.BatchCount
	if batches <= 0 {
		batches = curBatch + 1
	}
	return Outcome{
		BatchCount:          batches,
		UniqueTextRatePct:   uniqueRate,
		ParaphrasePairCount: paraphrasePairs,
		TemplateLeakHits:    templateLeaks,
		LabelSkewX100:       skewX100,
		EntropyScoreX100:    scoreX100,
		CollapseBand:        band,
	}
}

func sortRows(rows []gen.Row) {
	for i := 0; i < len(rows); i++ {
		for j := i + 1; j < len(rows); j++ {
			if rows[j].Batch < rows[i].Batch || (rows[j].Batch == rows[i].Batch && rows[j].Slot < rows[i].Slot) {
				rows[i], rows[j] = rows[j], rows[i]
			}
		}
	}
}
