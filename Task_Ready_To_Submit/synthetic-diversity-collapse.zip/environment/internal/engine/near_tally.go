package engine

import "lab.local/synthetic_diversity_collapse/pkg/nearfold"

func tallyNearPair(prevSig, curSig, window int) bool {
	return nearfold.OpN(prevSig, curSig, window)
}
