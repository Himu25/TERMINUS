package engine

import "lab.local/synthetic_diversity_collapse/pkg/labelmix"

func foldMixSkew(counts []int, targetPct []int) int {
	return labelmix.OpL(counts, targetPct)
}
