package driver

import (
	"encoding/json"
	"os"

	"lab.local/synthetic_diversity_collapse/internal/config"
	"lab.local/synthetic_diversity_collapse/internal/engine"
	"lab.local/synthetic_diversity_collapse/pkg/digest"
)

// Report is the JSON shape written to /app/output/diversity_audit.json.
type Report struct {
	SchemaVersion        string `json:"schema_version"`
	BatchID              string `json:"batch_id"`
	BatchCount           int    `json:"batch_count"`
	UniqueTextRatePct    int    `json:"unique_text_rate_pct"`
	ParaphrasePairCount  int    `json:"paraphrase_pair_count"`
	TemplateLeakHits     int    `json:"template_leak_hits"`
	LabelSkewX100        int    `json:"label_skew_x100"`
	EntropyScoreX100     int    `json:"entropy_score_x100"`
	CollapseBand         string `json:"collapse_band"`
	DigestHex            string `json:"digest_hex"`
}

// RunActive loads the active pack and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	bundle, rows, err := config.LoadBundle(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(bundle, rows)
	digestHex := digest.FoldReport(
		bundle.BatchID,
		itoa(out.BatchCount),
		itoa(out.UniqueTextRatePct),
		itoa(out.ParaphrasePairCount),
		itoa(out.TemplateLeakHits),
		itoa(out.LabelSkewX100),
		itoa(out.EntropyScoreX100),
		out.CollapseBand,
	)
	return Report{
		SchemaVersion:       "1",
		BatchID:             bundle.BatchID,
		BatchCount:          out.BatchCount,
		UniqueTextRatePct:   out.UniqueTextRatePct,
		ParaphrasePairCount: out.ParaphrasePairCount,
		TemplateLeakHits:    out.TemplateLeakHits,
		LabelSkewX100:       out.LabelSkewX100,
		EntropyScoreX100:    out.EntropyScoreX100,
		CollapseBand:        out.CollapseBand,
		DigestHex:           digestHex,
	}, nil
}

// EmitReport writes rep to path as compact JSON.
func EmitReport(path string, rep Report) error {
	if err := os.MkdirAll("/app/output", 0o755); err != nil {
		return err
	}
	raw, err := json.Marshal(rep)
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func itoa(v int) string {
	if v == 0 {
		return "0"
	}
	var buf [16]byte
	i := len(buf)
	n := v
	neg := false
	if n < 0 {
		neg = true
		n = -n
	}
	for n > 0 {
		i--
		buf[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		buf[i] = '-'
	}
	return string(buf[i:])
}
