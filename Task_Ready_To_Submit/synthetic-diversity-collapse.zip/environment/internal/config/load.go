package config

import (
	"encoding/json"
	"os"
	"path/filepath"

	"lab.local/synthetic_diversity_collapse/pkg/gen"
)

// Bundle holds replay knobs for one pack.
type Bundle struct {
	BatchID             string `json:"batch_id"`
	BatchCount          int    `json:"batch_count"`
	TemplateRotateEvery int    `json:"template_rotate_every"`
	ParaphraseWindow    int    `json:"paraphrase_window"`
	TargetLabelPct      []int  `json:"target_label_pct"`
	EntropyFloorX100    int    `json:"entropy_floor_x100"`
	LabelClasses        int    `json:"label_classes"`
}

// ActivePaths resolves the active pack directory under appRoot.
func ActivePaths(appRoot string) (string, error) {
	return filepath.Join(appRoot, "data", "active"), nil
}

// LoadBundle reads diversity_bundle.json and generations.jsonl from dir.
func LoadBundle(dir string) (Bundle, []gen.Row, error) {
	raw, err := os.ReadFile(filepath.Join(dir, "diversity_bundle.json"))
	if err != nil {
		return Bundle{}, nil, err
	}
	var bundle Bundle
	if err := json.Unmarshal(raw, &bundle); err != nil {
		return Bundle{}, nil, err
	}
	lines, err := os.ReadFile(filepath.Join(dir, "generations.jsonl"))
	if err != nil {
		return Bundle{}, nil, err
	}
	var rows []gen.Row
	for _, line := range splitLines(string(lines)) {
		if line == "" {
			continue
		}
		var row gen.Row
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return Bundle{}, nil, err
		}
		rows = append(rows, row)
	}
	return bundle, rows, nil
}

func splitLines(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			out = append(out, s[start:i])
			start = i + 1
		}
	}
	if start < len(s) {
		out = append(out, s[start:])
	}
	return out
}
