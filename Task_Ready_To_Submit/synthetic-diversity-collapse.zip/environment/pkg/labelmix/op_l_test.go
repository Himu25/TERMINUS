package labelmix

import "testing"

func TestOpLBalanced(t *testing.T) {
	got := OpL([]int{34, 33, 33}, []int{34, 33, 33})
	if got != 0 {
		t.Fatalf("balanced mix skew=%d want 0", got)
	}
}

func TestOpLSkewed(t *testing.T) {
	got := OpL([]int{9, 0, 0}, []int{34, 33, 33})
	if got == 0 {
		t.Fatal("expected non-zero skew for collapsed label lane")
	}
}

func TestOpLIntegerSharePct(t *testing.T) {
	got := OpL([]int{1, 1, 1}, []int{34, 33, 33})
	if got != 100 {
		t.Fatalf("integer share pct skew=%d want 100", got)
	}
}
