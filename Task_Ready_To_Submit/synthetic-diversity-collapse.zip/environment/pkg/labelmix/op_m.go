package labelmix

import "strings"

// OpM merges two label ids for flat export rows.
func OpM(a, b int) string {
	return strings.Join([]string{itoa(a), itoa(b)}, ":")
}

func itoa(v int) string {
	if v == 0 {
		return "0"
	}
	var buf [16]byte
	i := len(buf)
	n := v
	for n > 0 {
		i--
		buf[i] = byte('0' + n%10)
		n /= 10
	}
	return string(buf[i:])
}
