package labelmix

// OpL returns label-mix skew x100 given observed counts and target percentage shares.
func OpL(counts []int, targetPct []int) int {
	_ = counts
	_ = targetPct
	return 0
}
