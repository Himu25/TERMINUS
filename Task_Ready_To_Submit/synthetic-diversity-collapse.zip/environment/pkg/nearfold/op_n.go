package nearfold

// OpN reports whether two semantic signatures count as a near pair within window.
func OpN(sigA, sigB, window int) bool {
	return sigA == sigB
}
