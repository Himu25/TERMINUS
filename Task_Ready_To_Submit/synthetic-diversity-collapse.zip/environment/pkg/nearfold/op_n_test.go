package nearfold

import "testing"

func TestOpNExact(t *testing.T) {
	if !OpN(10, 10, 3) {
		t.Fatal("exact signatures should pair")
	}
}

func TestOpNWindow(t *testing.T) {
	if !OpN(10, 12, 3) {
		t.Fatal("signatures within window should pair")
	}
	if OpN(10, 20, 3) {
		t.Fatal("signatures outside window should not pair")
	}
}
