package gen

// Row is one generation record from generations.jsonl.
type Row struct {
	Batch       int    `json:"batch"`
	Slot        int    `json:"slot"`
	Label       int    `json:"label"`
	SemanticSig int    `json:"semantic_sig"`
	TemplateID  string `json:"template_id"`
}
