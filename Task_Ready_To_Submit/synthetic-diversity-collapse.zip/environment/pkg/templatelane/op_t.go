package templatelane

// OpT reports a lane leak when rotation was required but the template id stayed the same.
func OpT(prevTemplate, curTemplate string, rotateRequired bool) bool {
	_ = prevTemplate
	_ = curTemplate
	_ = rotateRequired
	return false
}
