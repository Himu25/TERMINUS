package templatelane

import "strings"

// OpS strips unsafe characters from a lane token.
func OpS(raw string) string {
	return strings.Map(func(r rune) rune {
		if r >= 'a' && r <= 'z' {
			return r
		}
		if r >= '0' && r <= '9' {
			return r
		}
		if r == '_' {
			return r
		}
		return -1
	}, raw)
}
