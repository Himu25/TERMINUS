package templatelane

import "testing"

func TestOpTRotated(t *testing.T) {
	if OpT("a", "b", true) {
		t.Fatal("different templates should not leak")
	}
}

func TestOpTStuck(t *testing.T) {
	if !OpT("a", "a", true) {
		t.Fatal("same template at rotation boundary should leak")
	}
}
