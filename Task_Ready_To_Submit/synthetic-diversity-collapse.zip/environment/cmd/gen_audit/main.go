// Report JSON for /app/output/diversity_audit.json:
//
// schema_version — string, always "1"
// batch_id — string, echoes active pack name
// batch_count — batches in the bundle schedule
// unique_text_rate_pct — integer 0-100 share of distinct semantic signatures over all generation slots
// paraphrase_pair_count — generation slots that matched an earlier signature in the same batch within the paraphrase window
// template_leak_hits — generation slots where a template rotation was required but the template id stayed the same
// label_skew_x100 — integer, 100 times the largest absolute gap between target_label_pct
// and observed share percent; for each class, observed share percent is (count * 100) / total
// with integer division on the product before the divide, then compared to target_label_pct
// entropy_score_x100 — integer, running entropy score times 100 after all batches
// collapse_band — string, "spread" or "collapsed"
// digest_hex — lowercase hex SHA-256 of batch_id|batch_count|unique_text_rate_pct|paraphrase_pair_count|template_leak_hits|label_skew_x100|entropy_score_x100|collapse_band
//
// Root object contains only these keys.
//
// Replay sorts generations by batch then slot. Control rows with slot zero are ignored.
// Paraphrase detection compares each generation signature to earlier signatures in the same batch.
// Template rotation is required when slot is positive and slot modulo template_rotate_every is zero;
// a leak is counted when the current template id equals the previous generation template id.
// Label skew folds final label counts against target_label_pct. After each batch the entropy helper
// folds unique semantic signature count into the running score. collapse_band is collapsed when
// entropy_score_x100 sits below entropy_floor_x100.
package main

import (
	"log"
	"os"

	"lab.local/synthetic_diversity_collapse/internal/driver"
)

func main() {
	if os.Getenv("TB_GEN_DIVERSITY") != "1" {
		log.Fatal("TB_GEN_DIVERSITY unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/diversity_audit.json", rep); err != nil {
		log.Fatal(err)
	}
}
