# Generation lane notes

Active packs live under data/active with diversity_bundle.json and
generations.jsonl at the pack root, the same flat layout as replay packs
under data/replay/<pack_id>/. Control rows use slot zero and are excluded
from generation counters.
