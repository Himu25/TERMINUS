package foldgate

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libfoldgate.a -ldl -lm
#include "entropy_fold.h"
*/
import "C"

// EntropyFold applies batch spread into the running score via dg_entropy_fold.
func EntropyFold(base float64, spread float64) float64 {
	return float64(C.dg_entropy_fold(C.double(base), C.double(spread)))
}
