#ifndef ENTROPY_FOLD_H
#define ENTROPY_FOLD_H

double dg_entropy_fold(double base, double delta);

#endif
