/// DgEntropyFold folds batch spread into the running score.
#[no_mangle]
pub extern "C" fn dg_entropy_fold(base: f64, delta: f64) -> f64 {
    base - delta
}
