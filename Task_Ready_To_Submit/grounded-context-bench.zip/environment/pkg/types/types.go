package types

type QueryCase struct {
	CaseID         string   `json:"case_id"`
	Query          string   `json:"query"`
	WantDocs       []string `json:"want_docs"`
	RequiredTokens []string `json:"required_tokens"`
}

type Chunk struct {
	ID     string
	Source string
	Text   string
}

type CaseResult struct {
	CaseID              string  `json:"case_id"`
	AnswerScore         float64 `json:"answer_score"`
	RetrievalPrecision  float64 `json:"retrieval_precision"`
	Grounded            bool    `json:"grounded"`
}

type CaseTrace struct {
	CaseID         string
	Answer         string
	RetrievedDocs  []string
	SpanIDs        []string
	SpanTexts      []string
	RequiredTokens []string
}

type BenchReport struct {
	Status                 string       `json:"status"`
	CasesTotal             int          `json:"cases_total"`
	CasesPassing           int          `json:"cases_passing"`
	MeanAnswerScore        float64      `json:"mean_answer_score"`
	MeanRetrievalPrecision float64      `json:"mean_retrieval_precision"`
	ReportDigest           string       `json:"report_digest"`
	Cases                  []CaseResult `json:"cases"`
}

type PipelineCfg struct {
	WindowTokens              int
	StrideTokens              int
	VectorDim                 int
	SimilarityFloor           float64
	TopK                      int
	MeanAnswerFloor           float64
	MeanPrecisionFloor        float64
	AltPackMeanPrecisionFloor float64
	DecoyCasePrecisionFloor   float64
	CorpusDir                 string
}
