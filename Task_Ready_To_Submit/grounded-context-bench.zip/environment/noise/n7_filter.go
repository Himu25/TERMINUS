package noise

import (
	"os"
	"path/filepath"
	"strings"
)

var scrubLines []string

func init() {
	path := filepath.Join("/app", "config", "noise_stopwords.txt")
	raw, err := os.ReadFile(path)
	if err != nil {
		scrubLines = []string{"copyright", "confidential draft"}
		return
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(strings.ToLower(line))
		if line != "" {
			scrubLines = append(scrubLines, line)
		}
	}
}

func Scrub(body string) string {
	lines := strings.Split(body, "\n")
	kept := make([]string, 0, len(lines))
	for _, line := range lines {
		low := strings.ToLower(strings.TrimSpace(line))
		if low == "" {
			continue
		}
		skip := false
		for _, needle := range scrubLines {
			if strings.Contains(low, needle) {
				skip = true
				break
			}
		}
		if !skip {
			kept = append(kept, line)
		}
	}
	return strings.Join(kept, "\n")
}
