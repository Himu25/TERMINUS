package reply

import (
	"strings"
)

func RunZ(q string, spans []string, required []string) (string, bool) {
	return op_d(q, spans, required)
}

func op_d(q string, spans []string, required []string) (string, bool) {
	union := make(map[string]struct{})
	for _, span := range spans {
		for _, tok := range strings.Fields(strings.ToLower(span)) {
			union[tok] = struct{}{}
		}
	}
	picked := make([]string, 0, len(required))
	qTokens := lex_set(q)
	for _, need := range required {
		need = strings.ToLower(strings.TrimSpace(need))
		if need == "" {
			continue
		}
		if _, ok := union[need]; ok {
			picked = append(picked, need)
			continue
		}
		for tok := range union {
			if strings.Contains(tok, need) || strings.Contains(need, tok) {
				picked = append(picked, tok)
				break
			}
		}
	}
	if len(picked) == 0 {
		for tok := range qTokens {
			if _, ok := union[tok]; ok {
				picked = append(picked, tok)
			}
		}
	}
	body := strings.Join(picked, " ")
	prefix := "according to internal guidance "
	answer := prefix + body
	ok := ok_u(answer, union)
	return answer, ok
}

func lex_set(text string) map[string]struct{} {
	out := make(map[string]struct{})
	for _, tok := range strings.Fields(strings.ToLower(text)) {
		out[tok] = struct{}{}
	}
	return out
}

func ok_u(answer string, union map[string]struct{}) bool {
	for _, tok := range strings.Fields(strings.ToLower(answer)) {
		if _, ok := union[tok]; !ok {
			return false
		}
	}
	return len(strings.Fields(answer)) > 0
}
