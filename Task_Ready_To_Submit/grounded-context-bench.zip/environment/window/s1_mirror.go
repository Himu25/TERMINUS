package window

import "strings"

func MirrorSplit(text string, width int) []string {
	tokens := lex_a(text)
	if width <= 0 || len(tokens) == 0 {
		return nil
	}
	out := make([]string, 0)
	for i := 0; i < len(tokens); i += width {
		end := i + width
		if end > len(tokens) {
			end = len(tokens)
		}
		out = append(out, strings.Join(tokens[i:end], " "))
	}
	return out
}
