package main

import (
	"encoding/json"
	"fmt"
	"os"

	"groundctx.lab/bench"
)

type traceRow struct {
	CaseID         string   `json:"case_id"`
	Answer         string   `json:"answer"`
	RetrievedDocs  []string `json:"retrieved_docs"`
	SpanIDs        []string `json:"span_ids"`
	SpanTexts      []string `json:"span_texts"`
	RequiredTokens []string `json:"required_tokens"`
}

func main() {
	cfgPath := "/app/config/pipeline.toml"
	queryPath := "/app/queries.jsonl"
	if len(os.Args) > 1 {
		queryPath = os.Args[1]
	}
	cfg, err := bench.LoadCfg(cfgPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "config: %v\n", err)
		os.Exit(1)
	}
	cases, err := bench.LoadCases(queryPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "cases: %v\n", err)
		os.Exit(1)
	}
	rows, err := bench.TraceCases(cfg, cases)
	if err != nil {
		fmt.Fprintf(os.Stderr, "trace: %v\n", err)
		os.Exit(1)
	}
	enc := json.NewEncoder(os.Stdout)
	for _, row := range rows {
		out := traceRow{
			CaseID:         row.CaseID,
			Answer:         row.Answer,
			RetrievedDocs:  row.RetrievedDocs,
			SpanIDs:        row.SpanIDs,
			SpanTexts:      row.SpanTexts,
			RequiredTokens: row.RequiredTokens,
		}
		if err := enc.Encode(out); err != nil {
			fmt.Fprintf(os.Stderr, "encode: %v\n", err)
			os.Exit(1)
		}
	}
}
