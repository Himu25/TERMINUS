package main

import (
	"fmt"
	"os"
	"path/filepath"

	"groundctx.lab/bench"
)

func main() {
	cfgPath := "/app/config/pipeline.toml"
	queryPath := "/app/queries.jsonl"
	outPath := "/app/output/bench_report.json"
	if len(os.Args) > 1 {
		queryPath = os.Args[1]
	}
	if len(os.Args) > 2 {
		outPath = os.Args[2]
	}
	cfg, err := bench.LoadCfg(cfgPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "config: %v\n", err)
		os.Exit(1)
	}
	cases, err := bench.LoadCases(queryPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "cases: %v\n", err)
		os.Exit(1)
	}
	report, err := bench.Run(cfg, cases)
	if err != nil {
		fmt.Fprintf(os.Stderr, "run: %v\n", err)
		os.Exit(1)
	}
	if err := bench.WriteReport(outPath, report); err != nil {
		fmt.Fprintf(os.Stderr, "write: %v\n", err)
		os.Exit(1)
	}
	_ = filepath.Base(outPath)
}
