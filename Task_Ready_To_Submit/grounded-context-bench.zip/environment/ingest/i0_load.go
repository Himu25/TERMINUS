package ingest

import (
	"embed"
	"io/fs"
	"os"
	"path/filepath"
	"runtime"
	"strings"

	"groundctx.lab/noise"
)

//go:embed articles/*.md
var articleFS embed.FS

type Doc struct {
	Name string
	Body string
}

func DefaultCorpusDir() string {
	_, file, _, ok := runtime.Caller(0)
	if !ok {
		return "/app/ingest/articles"
	}
	return filepath.Join(filepath.Dir(file), "articles")
}

func LoadCorpus(dir string) ([]Doc, error) {
	if docs, err := loadFromDir(dir); err == nil && len(docs) > 0 {
		return docs, nil
	}
	return loadEmbedded()
}

func loadFromDir(dir string) ([]Doc, error) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}
	out := make([]Doc, 0, len(entries))
	for _, ent := range entries {
		if ent.IsDir() || !strings.HasSuffix(ent.Name(), ".md") {
			continue
		}
		raw, err := os.ReadFile(filepath.Join(dir, ent.Name()))
		if err != nil {
			return nil, err
		}
		body := noise.Scrub(string(raw))
		out = append(out, Doc{Name: ent.Name(), Body: body})
	}
	return out, nil
}

func loadEmbedded() ([]Doc, error) {
	entries, err := fs.ReadDir(articleFS, "articles")
	if err != nil {
		return nil, err
	}
	out := make([]Doc, 0, len(entries))
	for _, ent := range entries {
		if ent.IsDir() || !strings.HasSuffix(ent.Name(), ".md") {
			continue
		}
		raw, err := articleFS.ReadFile(filepath.Join("articles", ent.Name()))
		if err != nil {
			return nil, err
		}
		body := noise.Scrub(string(raw))
		out = append(out, Doc{Name: ent.Name(), Body: body})
	}
	return out, nil
}
