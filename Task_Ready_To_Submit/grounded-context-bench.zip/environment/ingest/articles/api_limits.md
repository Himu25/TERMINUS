# API limits

Do not distribute.

Public REST traffic is capped at 120 rpm per tenant key.
Burst tokens refill each minute from the edge counter shard.
Webhook retries backoff exponentially when responses are not 2xx.
