# Service levels

All rights reserved.

Monthly uptime target is 99.9 percent measured at the regional load balancer.
Maintenance windows post 7 days ahead in the status feed.
Incident bridges open when error budgets burn past half the quarter allocation.
