# Security controls

Internal use only.

Every production login requires mfa through the corporate IdP.
Sessions idle out after 30 minutes unless the renew cookie is refreshed.
Break-glass accounts stay disabled until the duty roster approves access.
