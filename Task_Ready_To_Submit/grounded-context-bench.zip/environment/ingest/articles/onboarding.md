# Workspace onboarding

Confidential draft do not distribute.

New hires receive a workspace invite link that expires after 72 hours.
Admins assign the workspace role before the first deploy hook runs.
The invite email lists the sandbox cluster and default project slug.
