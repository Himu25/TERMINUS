# Billing operations

Copyright all rights reserved. Internal use only.

Customers may request a refund within a 14-day window after charge capture.
Open a support ticket tagged billing-refund so finance can review ledger rows.
Partial credits apply when usage stayed under the committed tier cap.
