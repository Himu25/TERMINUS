package fuse

import (
	"sort"
	"strings"

	"groundctx.lab/embed"
)

func FuseRun(queryText string, query []float64, bank map[string][]float64, texts map[string]string, limit int, floor float64) []string {
	return op_c(queryText, query, bank, texts, limit, floor)
}

func op_c(queryText string, query []float64, bank map[string][]float64, texts map[string]string, limit int, floor float64) []string {
	_ = queryText
	_ = texts
	type pair struct {
		id    string
		score float64
	}
	pairs := make([]pair, 0, len(bank))
	for id, vecBody := range bank {
		aligned := embed.PadV(vecBody, len(query))
		score := embed.DotU(query, aligned)
		if score < floor {
			continue
		}
		pairs = append(pairs, pair{id: id, score: score})
	}
	sort.Slice(pairs, func(i, j int) bool {
		return pairs[i].score > pairs[j].score
	})
	if limit <= 0 || limit > len(pairs) {
		limit = len(pairs)
	}
	out := make([]string, 0, limit)
	for i := 0; i < limit; i++ {
		out = append(out, pairs[i].id)
	}
	return out
}

func tokenSet(text string) map[string]struct{} {
	out := make(map[string]struct{})
	for _, tok := range strings.Fields(strings.ToLower(text)) {
		tok = strings.Trim(tok, ".,;:")
		if tok != "" {
			out[tok] = struct{}{}
		}
	}
	return out
}

func lexBoost(queryText, body string) float64 {
	qset := tokenSet(queryText)
	if len(qset) == 0 {
		return 0
	}
	hits := 0
	for tok := range tokenSet(body) {
		if _, ok := qset[tok]; ok {
			hits++
		}
	}
	return float64(hits) * 0.12
}
