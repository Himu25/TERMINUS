module groundctx.lab

go 1.22
