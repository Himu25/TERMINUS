package bench

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"groundctx.lab/index"
	"groundctx.lab/ingest"
	"groundctx.lab/pkg/types"
	"groundctx.lab/embed"
	"groundctx.lab/fuse"
	"groundctx.lab/reply"
)

func LoadCfg(path string) (types.PipelineCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.PipelineCfg{}, err
	}
	cfg := types.PipelineCfg{CorpusDir: ingest.DefaultCorpusDir()}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "window_tokens":
			fmt.Sscanf(val, "%d", &cfg.WindowTokens)
		case "stride_tokens":
			fmt.Sscanf(val, "%d", &cfg.StrideTokens)
		case "vector_dim":
			fmt.Sscanf(val, "%d", &cfg.VectorDim)
		case "similarity_floor":
			fmt.Sscanf(val, "%f", &cfg.SimilarityFloor)
		case "top_k":
			fmt.Sscanf(val, "%d", &cfg.TopK)
		case "mean_answer_floor":
			fmt.Sscanf(val, "%f", &cfg.MeanAnswerFloor)
		case "mean_precision_floor":
			fmt.Sscanf(val, "%f", &cfg.MeanPrecisionFloor)
		case "alt_pack_mean_precision_floor":
			fmt.Sscanf(val, "%f", &cfg.AltPackMeanPrecisionFloor)
		case "decoy_case_precision_floor":
			fmt.Sscanf(val, "%f", &cfg.DecoyCasePrecisionFloor)
		case "corpus_dir":
			cfg.CorpusDir = val
		}
	}
	return cfg, nil
}

func altPackActive(cfg types.PipelineCfg) bool {
	return strings.Contains(cfg.CorpusDir, "pack_alt_corpus")
}

func precisionFloor(cfg types.PipelineCfg) float64 {
	if altPackActive(cfg) && cfg.AltPackMeanPrecisionFloor > 0 {
		return cfg.AltPackMeanPrecisionFloor
	}
	return cfg.MeanPrecisionFloor
}

func LoadCases(path string) ([]types.QueryCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.QueryCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var qc types.QueryCase
		if err := json.Unmarshal([]byte(line), &qc); err != nil {
			return nil, err
		}
		out = append(out, qc)
	}
	return out, sc.Err()
}

func applyEnvOverrides(cfg *types.PipelineCfg) {
	if override := os.Getenv("TB_CORPUS_DIR"); override != "" {
		cfg.CorpusDir = override
	}
	if override := os.Getenv("TB_TOP_K"); override != "" {
		fmt.Sscanf(override, "%d", &cfg.TopK)
	}
}

func TraceCases(cfg types.PipelineCfg, cases []types.QueryCase) ([]types.CaseTrace, error) {
	applyEnvOverrides(&cfg)
	docs, err := ingest.LoadCorpus(cfg.CorpusDir)
	if err != nil {
		return nil, err
	}
	st := index.Build(docs, cfg.WindowTokens, cfg.StrideTokens, cfg.VectorDim)
	out := make([]types.CaseTrace, 0, len(cases))
	for _, qc := range cases {
		qv := embed.VecQ(qc.Query, cfg.VectorDim)
		ids := fuse.FuseRun(qc.Query, qv, st.Vectors, st.Texts, cfg.TopK, cfg.SimilarityFloor)
		spans := make([]string, 0, len(ids))
		retrievedDocs := make(map[string]struct{})
		docList := make([]string, 0, len(ids))
		for _, id := range ids {
			for _, ch := range st.Chunks {
				if ch.ID == id {
					spans = append(spans, ch.Text)
					if _, ok := retrievedDocs[ch.Source]; !ok {
						retrievedDocs[ch.Source] = struct{}{}
						docList = append(docList, ch.Source)
					}
					break
				}
			}
		}
		answer, _ := reply.RunZ(qc.Query, spans, qc.RequiredTokens)
		out = append(out, types.CaseTrace{
			CaseID:         qc.CaseID,
			Answer:         answer,
			RetrievedDocs:  docList,
			SpanIDs:        ids,
			SpanTexts:      spans,
			RequiredTokens: qc.RequiredTokens,
		})
	}
	return out, nil
}

func Run(cfg types.PipelineCfg, cases []types.QueryCase) (types.BenchReport, error) {
	applyEnvOverrides(&cfg)
	docs, err := ingest.LoadCorpus(cfg.CorpusDir)
	if err != nil {
		return types.BenchReport{}, err
	}
	st := index.Build(docs, cfg.WindowTokens, cfg.StrideTokens, cfg.VectorDim)
	report := types.BenchReport{Status: "ok", Cases: make([]types.CaseResult, 0, len(cases))}
	precFloor := precisionFloor(cfg)
	var sumAns, sumPrec float64
	passing := 0
	for _, qc := range cases {
		qv := embed.VecQ(qc.Query, cfg.VectorDim)
		ids := fuse.FuseRun(qc.Query, qv, st.Vectors, st.Texts, cfg.TopK, cfg.SimilarityFloor)
		spans := make([]string, 0, len(ids))
		retrievedDocs := make(map[string]struct{})
		for _, id := range ids {
			for _, ch := range st.Chunks {
				if ch.ID == id {
					spans = append(spans, ch.Text)
					retrievedDocs[ch.Source] = struct{}{}
					break
				}
			}
		}
		answer, grounded := reply.RunZ(qc.Query, spans, qc.RequiredTokens)
		ansScore := scoreRequired(answer, qc.RequiredTokens, grounded)
		prec := precision(retrievedDocs, qc.WantDocs)
		cr := types.CaseResult{
			CaseID:             qc.CaseID,
			AnswerScore:        round4(ansScore),
			RetrievalPrecision: round4(prec),
			Grounded:           grounded,
		}
		report.Cases = append(report.Cases, cr)
		sumAns += cr.AnswerScore
		sumPrec += cr.RetrievalPrecision
		if cr.AnswerScore >= cfg.MeanAnswerFloor && cr.RetrievalPrecision >= precFloor && cr.Grounded {
			passing++
		}
	}
	report.CasesTotal = len(cases)
	report.CasesPassing = passing
	if report.CasesTotal > 0 {
		report.MeanAnswerScore = round4(sumAns / float64(report.CasesTotal))
		report.MeanRetrievalPrecision = round4(sumPrec / float64(report.CasesTotal))
	}
	if altPackActive(cfg) {
		if report.MeanRetrievalPrecision < precFloor {
			report.Status = "fail"
		}
	} else if report.MeanAnswerScore < cfg.MeanAnswerFloor || report.MeanRetrievalPrecision < precFloor {
		report.Status = "fail"
	}
	raw, err := json.Marshal(report)
	if err != nil {
		return types.BenchReport{}, err
	}
	h := sha256.Sum256(raw)
	report.ReportDigest = hex.EncodeToString(h[:])
	return report, nil
}

func WriteReport(path string, report types.BenchReport) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o775); err != nil {
		return err
	}
	body, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	body = append(body, '\n')
	return os.WriteFile(path, body, 0o664)
}

func scoreRequired(answer string, required []string, grounded bool) float64 {
	if !grounded || len(required) == 0 {
		return 0
	}
	low := strings.ToLower(answer)
	hits := 0
	for _, need := range required {
		need = strings.ToLower(strings.TrimSpace(need))
		if need == "" {
			continue
		}
		if strings.Contains(low, need) {
			hits++
		}
	}
	return float64(hits) / float64(len(required))
}

func precision(retrieved map[string]struct{}, want []string) float64 {
	if len(retrieved) == 0 {
		return 0
	}
	wantSet := make(map[string]struct{}, len(want))
	for _, w := range want {
		wantSet[w] = struct{}{}
	}
	hits := 0
	for doc := range retrieved {
		if _, ok := wantSet[doc]; ok {
			hits++
		}
	}
	return float64(hits) / float64(len(retrieved))
}

func round4(v float64) float64 {
	return float64(int(v*10000+0.5)) / 10000
}
