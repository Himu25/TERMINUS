package index

import (
	"strings"

	"groundctx.lab/ingest"
	"groundctx.lab/pkg/types"
	"groundctx.lab/embed"
	"groundctx.lab/window"
)

type Store struct {
	Chunks  []types.Chunk
	Vectors map[string][]float64
	Texts   map[string]string
}

func Build(docs []ingest.Doc, primary int, secondary int, dim int) *Store {
	st := &Store{Vectors: make(map[string][]float64), Texts: make(map[string]string)}
	for _, doc := range docs {
		rawChunks := window.WinMk(doc.Name, doc.Body, primary, secondary)
		for _, raw := range rawChunks {
			parts := strings.SplitN(raw, "\t", 2)
			if len(parts) != 2 {
				continue
			}
			id := parts[0]
			text := parts[1]
			source := strings.Split(id, "#")[0]
			st.Chunks = append(st.Chunks, types.Chunk{ID: id, Source: source, Text: text})
			st.Texts[id] = text
			st.Vectors[id] = embed.VecD(text, dim)
		}
	}
	return st
}
