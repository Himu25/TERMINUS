Helper scripts are not required for the bench path. Use /app/tools/run_bench.
