package embed

var legacyWidths = map[string]int{
	"snapshot_v1": 32,
	"snapshot_v2": 40,
	"snapshot_v3": 48,
}

func LegacyWidth(tag string) int {
	if w, ok := legacyWidths[tag]; ok {
		return w
	}
	return 32
}
