# Narrow refund note

Internal draft.

Customers may request a refund within the billing queue.
