# Billing operations

Copyright all rights reserved.

Customers may request a refund within a 14-day window after charge capture.
Open a support ticket tagged billing-refund so finance can review ledger rows.
