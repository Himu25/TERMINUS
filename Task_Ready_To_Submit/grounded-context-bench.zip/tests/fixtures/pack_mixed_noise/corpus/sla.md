# Service levels

Confidential draft do not distribute.

Monthly uptime target is 99.9 percent measured at the regional load balancer.
Maintenance windows post 7 days ahead in the status feed.
