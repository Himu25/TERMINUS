# API limits

Internal use only.

Webhook retries backoff exponentially when responses are not 2xx.
Public REST traffic is capped at 120 rpm per tenant key.
