"""Verifier for grounded-context-bench."""

from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "bench_report.json"
CFG = APP / "config" / "pipeline.toml"
RUNNER = APP / "tools" / "run_bench"
FIXTURES = Path(__file__).resolve().parent / "fixtures"
CASETRACE = APP / "bin" / "casetrace"

REPORT_KEYS = frozenset(
    {
        "status",
        "cases_total",
        "cases_passing",
        "mean_answer_score",
        "mean_retrieval_precision",
        "report_digest",
        "cases",
    }
)
CASE_KEYS = frozenset({"case_id", "answer_score", "retrieval_precision", "grounded"})

MIN_ANSWER_FLOOR = 0.85
MIN_PRECISION_FLOOR = 0.80

PARTIAL_MATCH_CASE_ID = "partial_match_case"
PARTIAL_MATCH_ANSWER_SCORE = 1.0
PARTIAL_MATCH_PRECISION = 0.5

AMBIGUOUS_CASE_ID = "ambiguous_retrieval"
AMBIGUOUS_PRECISION = 0.5


def _parse_floors() -> tuple[float, float]:
    answer_floor = MIN_ANSWER_FLOOR
    precision_floor = MIN_PRECISION_FLOOR
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line.startswith("mean_answer_floor"):
            answer_floor = float(line.split("=", 1)[1].strip())
        if line.startswith("mean_precision_floor"):
            precision_floor = float(line.split("=", 1)[1].strip())
    assert answer_floor >= MIN_ANSWER_FLOOR
    assert precision_floor >= MIN_PRECISION_FLOOR
    return answer_floor, precision_floor


def _alt_pack_precision_satisfied(
    report: dict, mean_floor: float, case_floor: float
) -> bool:
    """Alt pack passes on mean floor or any anchor case clearing the case floor."""
    if report["mean_retrieval_precision"] >= mean_floor:
        return True
    anchor_ids = frozenset({"decoy_trap", "real_refund"})
    return any(
        row["retrieval_precision"] >= case_floor
        for row in report["cases"]
        if row["case_id"] in anchor_ids
    )


def _parse_alt_pack_floors() -> tuple[float, float]:
    alt_mean_precision = 0.50
    decoy_precision = 0.50
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line.startswith("alt_pack_mean_precision_floor"):
            alt_mean_precision = float(line.split("=", 1)[1].strip())
        if line.startswith("decoy_case_precision_floor"):
            decoy_precision = float(line.split("=", 1)[1].strip())
    return alt_mean_precision, decoy_precision


def _round4(value: float) -> float:
    return round(value * 10000 + 0.5) / 10000


def _precision_from_retrieved(retrieved_docs: list[str], want_docs: list[str]) -> float:
    if not retrieved_docs:
        return 0.0
    want_set = frozenset(want_docs)
    hits = sum(1 for doc in retrieved_docs if doc in want_set)
    return _round4(hits / len(retrieved_docs))


def _load_query_cases(query_path: Path) -> list[dict]:
    cases: list[dict] = []
    for line in query_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            cases.append(json.loads(line))
    return cases


def _expected_means(cases: list[dict]) -> tuple[float, float]:
    if not cases:
        return 0.0, 0.0
    total = len(cases)
    mean_answer = sum(row["answer_score"] for row in cases) / total
    mean_precision = sum(row["retrieval_precision"] for row in cases) / total
    return _round4(mean_answer), _round4(mean_precision)


def _expected_cases_passing(cases: list[dict], ans_floor: float, prec_floor: float) -> int:
    passing = 0
    for row in cases:
        if (
            row["answer_score"] >= ans_floor
            and row["retrieval_precision"] >= prec_floor
            and row["grounded"] is True
        ):
            passing += 1
    return passing


def _digest_payload(report: dict) -> dict:
    return {
        "status": report["status"],
        "cases_total": report["cases_total"],
        "cases_passing": report["cases_passing"],
        "mean_answer_score": report["mean_answer_score"],
        "mean_retrieval_precision": report["mean_retrieval_precision"],
        "report_digest": "",
        "cases": [
            {
                "case_id": row["case_id"],
                "answer_score": row["answer_score"],
                "retrieval_precision": row["retrieval_precision"],
                "grounded": row["grounded"],
            }
            for row in report["cases"]
        ],
    }


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _load_report() -> dict:
    assert OUT.is_file(), "bench_report.json missing"
    data = json.loads(OUT.read_text(encoding="utf-8"))
    assert set(data) == REPORT_KEYS
    return data


def _ensure_casetrace() -> None:
    if CASETRACE.is_file():
        return
    subprocess.run(
        ["go", "build", "-o", str(CASETRACE), "./cmd/casetrace"],
        cwd=APP,
        check=True,
        capture_output=True,
        text=True,
    )


def _run_bench(
    query_path: Path,
    out_path: Path = OUT,
    corpus_dir: Path | None = None,
    top_k: int | None = None,
) -> None:
    env = os.environ.copy()
    if corpus_dir is not None:
        env["TB_CORPUS_DIR"] = str(corpus_dir)
    else:
        env.pop("TB_CORPUS_DIR", None)
    if top_k is not None:
        env["TB_TOP_K"] = str(top_k)
    else:
        env.pop("TB_TOP_K", None)
    if out_path.exists():
        out_path.unlink()
    subprocess.run(
        ["go", "build", "-o", "/app/bin/benchd", "./cmd/benchd"],
        cwd=APP,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )
    subprocess.run(
        ["/app/bin/benchd", str(query_path), str(out_path)],
        cwd=APP,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )


def _run_case_trace(
    query_path: Path,
    corpus_dir: Path | None = None,
    top_k: int | None = None,
) -> dict[str, dict]:
    _ensure_casetrace()
    env = os.environ.copy()
    if corpus_dir is not None:
        env["TB_CORPUS_DIR"] = str(corpus_dir)
    else:
        env.pop("TB_CORPUS_DIR", None)
    if top_k is not None:
        env["TB_TOP_K"] = str(top_k)
    else:
        env.pop("TB_TOP_K", None)
    proc = subprocess.run(
        [str(CASETRACE), str(query_path)],
        cwd=APP,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )
    rows: dict[str, dict] = {}
    for line in proc.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        row = json.loads(line)
        rows[row["case_id"]] = row
    return rows


def _external_grounding_ok(trace: dict) -> bool:
    answer = trace["answer"].lower()
    if not answer.strip():
        return False
    joined = " ".join(trace.get("span_texts", [])).lower()
    union: set[str] = set()
    for span in trace.get("span_texts", []):
        union.update(span.lower().split())
    for need in trace["required_tokens"]:
        token = need.lower().strip()
        if token and token not in answer:
            return False
    for tok in answer.split():
        if tok in union:
            continue
        if joined and tok in joined:
            continue
        return False
    return True


def _assert_fixture_pack_regression(pack: str) -> None:
    query_path = FIXTURES / pack / "queries.jsonl"
    corpus_dir = FIXTURES / pack / "corpus"
    tmp_out = APP / "output" / f"bench_{pack}.json"
    _run_bench(query_path, tmp_out, corpus_dir if corpus_dir.is_dir() else None)
    report = json.loads(tmp_out.read_text(encoding="utf-8"))
    if pack == "pack_alt_corpus":
        alt_mean_precision, decoy_precision_floor = _parse_alt_pack_floors()
        assert _alt_pack_precision_satisfied(
            report, alt_mean_precision, decoy_precision_floor
        )
        return
    assert report["status"] == "ok"
    assert report["mean_answer_score"] >= MIN_ANSWER_FLOOR
    assert report["mean_retrieval_precision"] >= MIN_PRECISION_FLOOR
    traces = _run_case_trace(
        query_path, corpus_dir if corpus_dir.is_dir() else None
    )
    for row in report["cases"]:
        assert row["grounded"] is True
        assert _external_grounding_ok(traces[row["case_id"]])


@pytest.fixture(scope="session", autouse=True)
def _default_bench_run() -> None:
    _run_bench(APP / "queries.jsonl")


def test_runner_exists() -> None:
    """The documented bench driver script is present and executable."""
    assert RUNNER.is_file() and os.access(RUNNER, os.X_OK)


def test_report_schema() -> None:
    """bench_report.json exposes only the contract top-level keys."""
    report = _load_report()
    assert isinstance(report["cases"], list)


def test_case_row_schema() -> None:
    """Each case row carries only the contract per-case keys."""
    report = _load_report()
    assert report["cases_total"] == len(report["cases"])
    for row in report["cases"]:
        assert set(row) == CASE_KEYS


def test_status_ok() -> None:
    """Summary status is ok on the default query pack."""
    report = _load_report()
    assert report["status"] == "ok"


def test_mean_answer_score_meets_floor() -> None:
    """Default-pack mean answer score clears the minimum quality floor."""
    report = _load_report()
    _parse_floors()
    assert report["mean_answer_score"] >= MIN_ANSWER_FLOOR


def test_mean_retrieval_precision_meets_floor() -> None:
    """Default-pack mean retrieval precision clears the minimum quality floor."""
    report = _load_report()
    _parse_floors()
    assert report["mean_retrieval_precision"] >= MIN_PRECISION_FLOOR


def test_default_cases_externally_grounded() -> None:
    """Default-pack grounded flags match required_tokens present in traced answers."""
    report = _load_report()
    traces = _run_case_trace(APP / "queries.jsonl")
    for row in report["cases"]:
        trace = traces[row["case_id"]]
        if row["grounded"]:
            assert _external_grounding_ok(trace)
        else:
            assert not _external_grounding_ok(trace)


def test_cases_passing_equals_total() -> None:
    """Default pack reports every case as passing."""
    report = _load_report()
    assert report["cases_passing"] == report["cases_total"]


def test_cases_passing_matches_floors() -> None:
    """cases_passing equals rows that individually clear both minimum floors."""
    report = _load_report()
    _parse_floors()
    assert report["cases_passing"] == _expected_cases_passing(
        report["cases"], MIN_ANSWER_FLOOR, MIN_PRECISION_FLOOR
    )


def test_report_digest_format() -> None:
    """report_digest is a 64-character lowercase hex SHA-256 string."""
    report = _load_report()
    digest = report["report_digest"]
    assert isinstance(digest, str)
    assert len(digest) == 64
    assert re.fullmatch(r"[0-9a-f]{64}", digest)


def test_report_digest_matches_body() -> None:
    """report_digest must be the SHA-256 of the compact pre-digest report body."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_summary_means_recomputed_from_cases() -> None:
    """Summary means must match per-case rows, not self-reported constants."""
    report = _load_report()
    want_answer, want_precision = _expected_means(report["cases"])
    assert report["mean_answer_score"] == want_answer
    assert report["mean_retrieval_precision"] == want_precision


def test_repeat_run_byte_identical() -> None:
    """Back-to-back default-pack runs emit identical report bytes."""
    first = OUT.read_bytes()
    _run_bench(APP / "queries.jsonl")
    second = OUT.read_bytes()
    assert first == second


def test_refund_policy_answer_score_meets_floor() -> None:
    """refund_policy row clears the minimum per-case answer floor."""
    report = _load_report()
    _parse_floors()
    refund = next(row for row in report["cases"] if row["case_id"] == "refund_policy")
    assert refund["answer_score"] >= MIN_ANSWER_FLOOR


def test_refund_policy_retrieval_precision_meets_floor() -> None:
    """refund_policy row clears the minimum per-case retrieval floor."""
    report = _load_report()
    _parse_floors()
    refund = next(row for row in report["cases"] if row["case_id"] == "refund_policy")
    assert refund["retrieval_precision"] >= MIN_PRECISION_FLOOR


def test_partial_match_case_scores() -> None:
    """partial_match_case reports a retrieval/answer mismatch with non-trivial scores."""
    query_path = FIXTURES / "pack_partial_match" / "queries.jsonl"
    corpus = FIXTURES / "pack_partial_match" / "corpus"
    spec = _load_query_cases(query_path)[0]
    tmp_out = APP / "output" / "bench_partial_match.json"
    _run_bench(query_path, tmp_out, corpus, top_k=2)
    report = json.loads(tmp_out.read_text(encoding="utf-8"))
    row = next(r for r in report["cases"] if r["case_id"] == PARTIAL_MATCH_CASE_ID)
    trace = _run_case_trace(query_path, corpus, top_k=2)[PARTIAL_MATCH_CASE_ID]

    assert row["answer_score"] == PARTIAL_MATCH_ANSWER_SCORE
    assert row["retrieval_precision"] == PARTIAL_MATCH_PRECISION
    assert 0.0 < row["answer_score"] <= 1.0
    assert 0.0 < row["retrieval_precision"] < 1.0
    assert row["answer_score"] != row["retrieval_precision"]

    want_docs = spec["want_docs"]
    assert len(trace["retrieved_docs"]) >= 2
    assert trace["span_ids"]
    recomputed = _precision_from_retrieved(trace["retrieved_docs"], want_docs)
    assert row["retrieval_precision"] == recomputed
    assert any(doc not in want_docs for doc in trace["retrieved_docs"])
    for need in spec["required_tokens"]:
        assert need.lower() in trace["answer"].lower()


def test_ambiguous_retrieval_exact_precision() -> None:
    """ambiguous_retrieval must score exactly 0.5 precision with mixed retrieved docs."""
    query_path = FIXTURES / "pack_ambiguous_retrieval" / "queries.jsonl"
    spec = _load_query_cases(query_path)[0]
    tmp_out = APP / "output" / "bench_ambiguous.json"
    _run_bench(query_path, tmp_out, top_k=2)
    report = json.loads(tmp_out.read_text(encoding="utf-8"))
    row = next(r for r in report["cases"] if r["case_id"] == AMBIGUOUS_CASE_ID)
    trace = _run_case_trace(query_path, top_k=2)[AMBIGUOUS_CASE_ID]

    assert row["retrieval_precision"] == AMBIGUOUS_PRECISION
    assert row["retrieval_precision"] < 1.0
    assert len(trace["retrieved_docs"]) >= 2
    recomputed = _precision_from_retrieved(trace["retrieved_docs"], spec["want_docs"])
    assert row["retrieval_precision"] == recomputed
    assert any(doc not in spec["want_docs"] for doc in trace["retrieved_docs"])


def test_fixture_pack_tight_queries_regression() -> None:
    """pack_tight_queries meets configured mean floors with externally verified grounding."""
    _assert_fixture_pack_regression("pack_tight_queries")


def test_fixture_pack_alt_corpus_regression() -> None:
    """pack_alt_corpus meets alt-pack mean or per-anchor precision floors."""
    _assert_fixture_pack_regression("pack_alt_corpus")


def test_fixture_pack_mixed_noise_regression() -> None:
    """pack_mixed_noise meets configured mean floors with externally verified grounding."""
    _assert_fixture_pack_regression("pack_mixed_noise")


def test_alt_corpus_decoy_case() -> None:
    """Alt pack meets mean or per-anchor precision floors from pipeline.toml."""
    tmp_out = APP / "output" / "bench_pack_alt.json"
    corpus = FIXTURES / "pack_alt_corpus" / "corpus"
    _run_bench(FIXTURES / "pack_alt_corpus" / "queries.jsonl", tmp_out, corpus)
    report = json.loads(tmp_out.read_text(encoding="utf-8"))
    alt_mean_precision, decoy_precision_floor = _parse_alt_pack_floors()
    assert _alt_pack_precision_satisfied(
        report, alt_mean_precision, decoy_precision_floor
    )


def test_default_case_count_matches_pack() -> None:
    """cases_total matches the number of rows in the default query pack."""
    report = _load_report()
    expected = sum(
        1
        for line in (APP / "queries.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    )
    assert report["cases_total"] == expected
