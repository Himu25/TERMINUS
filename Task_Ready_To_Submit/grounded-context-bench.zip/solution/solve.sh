#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

cp "${ROOT_DIR}/oracle/s1_window.go" /app/window/s1_window.go
cp "${ROOT_DIR}/oracle/v2_project.go" /app/embed/v2_project.go
cp "${ROOT_DIR}/oracle/fuse_r3_score.go" /app/fuse/r3_score.go
cp "${ROOT_DIR}/oracle/reply_s4_compose.go" /app/reply/s4_compose.go

go build -o /app/bin/benchd ./cmd/benchd
/app/tools/run_bench /app/queries.jsonl /app/output/bench_report.json

echo "Oracle complete"
