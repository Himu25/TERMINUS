package embed

import (
	"hash/fnv"
	"math"
	"strings"
)

func VecD(text string, dim int) []float64 {
	return op_b(text, dim, false)
}

func VecQ(text string, dim int) []float64 {
	return op_b(text, dim, true)
}

func op_b(text string, dim int, flag bool) []float64 {
	if dim <= 0 {
		return nil
	}
	_ = flag
	out := make([]float64, dim)
	for _, tok := range lex_split(text) {
		h := fnv.New64a()
		_, _ = h.Write([]byte(tok))
		slot := int(h.Sum64() % uint64(dim))
		out[slot] += 1.0
	}
	unit_scale(out)
	return out
}

func lex_split(text string) []string {
	text = strings.ToLower(text)
	var tokens []string
	var cur strings.Builder
	flush := func() {
		if cur.Len() == 0 {
			return
		}
		tokens = append(tokens, cur.String())
		cur.Reset()
	}
	for _, r := range text {
		if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') || r == '-' || r == '.' {
			cur.WriteRune(r)
			continue
		}
		flush()
	}
	flush()
	return tokens
}

func unit_scale(v []float64) {
	var sum float64
	for _, x := range v {
		sum += x * x
	}
	if sum == 0 {
		return
	}
	inv := 1.0 / math.Sqrt(sum)
	for i := range v {
		v[i] *= inv
	}
}

func DotU(a, b []float64) float64 {
	if len(a) == 0 || len(b) == 0 {
		return 0
	}
	n := len(a)
	if len(b) < n {
		n = len(b)
	}
	var dot float64
	for i := 0; i < n; i++ {
		dot += a[i] * b[i]
	}
	return dot
}

func PadV(a []float64, dim int) []float64 {
	if len(a) == dim {
		return a
	}
	out := make([]float64, dim)
	copy(out, a)
	if len(a) > 0 && !empty_v(a) {
		unit_scale(out)
	}
	return out
}

func empty_v(v []float64) bool {
	for _, x := range v {
		if x != 0 {
			return false
		}
	}
	return true
}
