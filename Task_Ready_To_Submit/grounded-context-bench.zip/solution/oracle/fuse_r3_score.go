package fuse

import (
	"sort"
	"strings"

	"groundctx.lab/embed"
)

func FuseRun(queryText string, query []float64, bank map[string][]float64, texts map[string]string, limit int, floor float64) []string {
	return op_c(queryText, query, bank, texts, limit, floor)
}

func op_c(queryText string, query []float64, bank map[string][]float64, texts map[string]string, limit int, floor float64) []string {
	type pair struct {
		id    string
		score float64
	}
	pairs := make([]pair, 0, len(bank))
	for id, vecBody := range bank {
		body := texts[id]
		score := embed.DotU(query, vecBody) + lexBoost(queryText, body) - disclaimerPenalty(body)
		if score < floor {
			continue
		}
		pairs = append(pairs, pair{id: id, score: score})
	}
	sort.Slice(pairs, func(i, j int) bool {
		return pairs[i].score > pairs[j].score
	})
	if limit <= 0 || limit > len(pairs) {
		limit = len(pairs)
	}
	if len(pairs) == 0 {
		return nil
	}
	bestSource := strings.Split(pairs[0].id, "#")[0]
	out := make([]string, 0, limit)
	seen := make(map[string]struct{})
	for _, p := range pairs {
		src := strings.Split(p.id, "#")[0]
		if src != bestSource {
			continue
		}
		if _, ok := seen[p.id]; ok {
			continue
		}
		seen[p.id] = struct{}{}
		out = append(out, p.id)
		if len(out) >= limit {
			return out
		}
	}
	for _, p := range pairs {
		if _, ok := seen[p.id]; ok {
			continue
		}
		seen[p.id] = struct{}{}
		out = append(out, p.id)
		if len(out) >= limit {
			break
		}
	}
	return out
}

func tokenSet(text string) map[string]struct{} {
	out := make(map[string]struct{})
	for _, tok := range strings.Fields(strings.ToLower(text)) {
		tok = strings.Trim(tok, ".,;:")
		if tok != "" {
			out[tok] = struct{}{}
		}
	}
	return out
}

func disclaimerPenalty(body string) float64 {
	low := strings.ToLower(body)
	if strings.Contains(low, "should not drive") || strings.Contains(low, "not the billing policy") {
		return 2.0
	}
	return 0
}

func lexBoost(queryText, body string) float64 {
	qset := tokenSet(queryText)
	if len(qset) == 0 {
		return 0
	}
	hits := 0
	for tok := range tokenSet(body) {
		if _, ok := qset[tok]; ok {
			hits++
		}
	}
	return float64(hits) * 0.2
}
