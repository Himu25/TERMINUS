package window

import (
	"strings"
)

func lex_a(text string) []string {
	text = strings.ToLower(text)
	var tokens []string
	var cur strings.Builder
	flush := func() {
		if cur.Len() == 0 {
			return
		}
		tokens = append(tokens, cur.String())
		cur.Reset()
	}
	for _, r := range text {
		if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') || r == '-' || r == '.' {
			cur.WriteRune(r)
			continue
		}
		flush()
	}
	flush()
	return tokens
}

func op_a(tokens []string, primary int, secondary int) []string {
	if primary <= 0 {
		return nil
	}
	step := secondary
	if step <= 0 {
		step = primary / 2
		if step <= 0 {
			step = 1
		}
	}
	seen := make(map[string]struct{})
	out := make([]string, 0)
	for start := 0; start < len(tokens); start += step {
		end := start + primary
		if end > len(tokens) {
			end = len(tokens)
		}
		if start >= end {
			break
		}
		chunk := strings.Join(tokens[start:end], " ")
		if _, ok := seen[chunk]; ok {
			continue
		}
		seen[chunk] = struct{}{}
		out = append(out, chunk)
		if end == len(tokens) {
			break
		}
	}
	return out
}

func WinMk(source string, body string, primary int, secondary int) []string {
	tokens := lex_a(body)
	parts := op_a(tokens, primary, secondary)
	out := make([]string, 0, len(parts))
	for idx, part := range parts {
		out = append(out, source+"#"+itoa(idx)+"\t"+part)
	}
	return out
}

func itoa(v int) string {
	if v == 0 {
		return "0"
	}
	digits := make([]byte, 0, 8)
	for v > 0 {
		digits = append(digits, byte('0'+v%10))
		v /= 10
	}
	for i, j := 0, len(digits)-1; i < j; i, j = i+1, j-1 {
		digits[i], digits[j] = digits[j], digits[i]
	}
	return string(digits)
}
