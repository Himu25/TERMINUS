package weave

import "bloodledger/internal/model"

// Merge_w2 merges source units into one destination unit.
func Merge_w2(a []model.Unit, b string, c int) model.Unit {
	if len(a) == 0 {
		return model.Unit{}
	}
	total := 0
	tag := ""
	product := a[0].Product
	loc := a[0].Loc
	abo := a[0].Abo
	rh := a[0].Rh
	for _, u := range a {
		total += u.Qty
		if tag == "" {
			tag = u.Tag
		}
	}
	return model.Unit{
		Tag:          tag,
		Product:      product,
		Loc:          loc,
		Qty:          total,
		ExpiryStamp:  b,
		Abo:          abo,
		Rh:           rh,
		OverrideFlag: false,
	}
}
