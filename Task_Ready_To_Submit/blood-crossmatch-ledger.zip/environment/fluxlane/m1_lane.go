package fluxlane

import "bloodledger/internal/model"

// Op_m1 removes secondary quantity from the primary slice.
func Op_m1(primary []model.Unit, secondary int) ([]model.Unit, int, bool) {
	if secondary <= 0 || len(primary) == 0 {
		return primary, 0, false
	}
	out := make([]model.Unit, len(primary))
	copy(out, primary)
	remaining := secondary
	violated := false
	for i := len(out) - 1; i >= 0 && remaining > 0; i-- {
		if out[i].Qty <= 0 {
			continue
		}
		if i != len(out)-1 {
			violated = true
		}
		take := out[i].Qty
		if take > remaining {
			take = remaining
		}
		out[i].Qty -= take
		remaining -= take
	}
	return out, secondary - remaining, violated
}

// PushBack appends one unit record.
func PushBack(primary []model.Unit, secondary model.Unit) []model.Unit {
	return append(primary, secondary)
}
