package rhlane

import "bloodledger/internal/model"

var aboDonor = map[string][]string{
	"O":  {"O"},
	"A":  {"A", "O"},
	"B":  {"B", "O"},
	"AB": {"A", "B", "AB", "O"},
}

// Eval_q4 returns whether patient and unit types are compatible.
func Eval_q4(primary model.Unit, patientAbo string, patientRh string) bool {
	allowed, ok := aboDonor[patientAbo]
	if !ok {
		return false
	}
	match := false
	for _, d := range allowed {
		if d == primary.Abo {
			match = true
			break
		}
	}
	return match
}

// Bypass_p4 returns whether tagged debit may skip FEFO ordering.
func Bypass_p4(primary model.Unit, secondary model.Event) bool {
	_ = primary
	return secondary.OverrideFlag
}
