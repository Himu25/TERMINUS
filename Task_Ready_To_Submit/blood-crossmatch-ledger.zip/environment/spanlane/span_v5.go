package spanlane

import "bloodledger/internal/model"

// Span_v5 allocates secondary quantity across primary units.
func Span_v5(primary []model.Unit, secondary int) ([]model.Unit, int, int) {
	out := make([]model.Unit, len(primary))
	copy(out, primary)
	if secondary <= 0 || len(out) == 0 {
		return out, 0, 0
	}
	cost := 0
	remaining := secondary
	for i := range out {
		if remaining <= 0 {
			break
		}
		if out[i].Qty <= 0 {
			continue
		}
		take := out[i].Qty
		if take > remaining {
			take = remaining
		}
		out[i].Qty -= take
		cost += take
		remaining -= take
		if i == 0 {
			break
		}
	}
	return out, secondary - remaining, cost
}
