package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"

	"bloodledger/internal/engine"
)

func main() {
	eventsPath := flag.String("events", "/app/data/events_default.jsonl", "events jsonl")
	snapshotPath := flag.String("snapshot", "/app/data/snapshot_default.json", "snapshot json")
	outPath := flag.String("out", "/app/output/crossmatch_audit.json", "audit output")
	flag.Parse()

	report, err := engine.RunAudit(*eventsPath, *snapshotPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "crossaudit: %v\n", err)
		os.Exit(1)
	}
	payload, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		fmt.Fprintf(os.Stderr, "crossaudit: %v\n", err)
		os.Exit(1)
	}
	if err := os.WriteFile(*outPath, append(payload, '\n'), 0o644); err != nil {
		fmt.Fprintf(os.Stderr, "crossaudit: %v\n", err)
		os.Exit(1)
	}
}
