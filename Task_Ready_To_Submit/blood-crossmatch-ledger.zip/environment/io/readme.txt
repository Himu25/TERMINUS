jsonl event loader notes
