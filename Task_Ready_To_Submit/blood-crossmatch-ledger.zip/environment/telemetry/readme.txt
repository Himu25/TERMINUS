telemetry sink placeholder
