package engine

import (
	"bloodledger/internal/model"
	"bloodledger/slotlane"
)

func restoreReturn(cur []model.Unit, rec model.IssueRecord, ev model.Event) []model.Unit {
	src := rec.Taken[0]
	unit := model.Unit{
		Tag:         src.Tag,
		Product:     rec.Product,
		Loc:         rec.Loc,
		ExpiryStamp: findExpiry(cur, src.Tag),
		Abo:         findAbo(cur, ev.Tag),
		Rh:          findRh(cur, ev.Tag),
		Slot:        src.Slot,
	}
	return slotlane.Restore_z3(cur, unit, ev.Qty)
}
