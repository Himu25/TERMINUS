package engine

import (
	"bloodledger/internal/model"
	"bloodledger/weave"
)

func mergePool(sources []model.Unit, ev model.Event) model.Unit {
	merged := weave.Merge_w2(sources, ev.Ts, ev.Qty)
	merged.Tag = ev.DstTag
	merged.Qty = ev.Qty
	return merged
}
