package engine

import (
	"bloodledger/internal/decoy"
	"bloodledger/internal/digest"
	"bloodledger/internal/io"
	"bloodledger/internal/model"
	"bloodledger/fluxlane"
)

type fridgeKey struct {
	product string
	loc     string
}

func RunAudit(eventsPath, snapshotPath string) (*model.Report, error) {
	events, err := io.LoadEvents(eventsPath)
	if err != nil {
		return nil, err
	}
	snap, err := io.LoadSnapshot(snapshotPath)
	if err != nil {
		return nil, err
	}

	stacks := map[fridgeKey][]model.Unit{}
	issues := map[string]model.IssueRecord{}
	bindings := map[string]string{}
	crossmatchMisses := 0
	orphanEvents := 0
	expiryCarryGaps := 0
	slotCounter := 0

	for _, ev := range events {
		key := fridgeKey{product: ev.Product, loc: ev.Loc}
		cur := stacks[key]

		switch ev.Kind {
		case "intake":
			slotCounter++
			unit := model.Unit{
				Tag:          ev.Tag,
				Product:      ev.Product,
				Loc:          ev.Loc,
				Qty:          ev.Qty,
				ExpiryStamp:  ev.Expiry,
				Abo:          ev.Abo,
				Rh:           ev.Rh,
				Slot:         slotCounter,
				OverrideFlag: ev.OverrideFlag,
			}
			cur = fluxlane.PushBack(cur, unit)
			stacks[key] = cur

		case "reserve":
			if ev.Tag == "" || ev.PatientID == "" {
				orphanEvents++
				continue
			}
			if !hasTag(cur, ev.Tag) {
				orphanEvents++
				continue
			}
			bindings[ev.Tag] = ev.PatientID

		case "release":
			if ev.Tag == "" {
				orphanEvents++
				continue
			}
			delete(bindings, ev.Tag)

		case "crossmatch":
			unit, ok := findUnit(cur, ev.Tag)
			if !ok {
				orphanEvents++
				continue
			}
			if crossmatchMismatch(unit, ev) {
				crossmatchMisses++
			}

		case "issue":
			if ev.Qty <= 0 {
				orphanEvents++
				continue
			}
			var updated []model.Unit
			var taken int
			var violated bool
			var rec model.IssueRecord
			if ev.Tag != "" {
				updated, taken, violated, rec = debitTagged(cur, ev)
			} else {
				updated, taken, violated, rec = debitFEFO(cur, ev.Qty)
				rec.EventID = ev.EventID
				rec.Product = ev.Product
				rec.Loc = ev.Loc
			}
			if taken < ev.Qty {
				orphanEvents++
			}
			if violated {
				expiryCarryGaps++
			}
			cur = updated
			stacks[key] = cur
			issues[ev.EventID] = rec
			delete(bindings, ev.Tag)

		case "return_unit":
			rec, ok := issues[ev.RefEvent]
			if !ok || ev.Qty <= 0 {
				orphanEvents++
				continue
			}
			if len(rec.Taken) == 0 {
				orphanEvents++
				continue
			}
			cur = restoreReturn(cur, rec, ev)
			stacks[key] = cur

		case "pool_split_out":
			if len(ev.SrcTags) == 0 {
				orphanEvents++
				continue
			}
			for _, tag := range ev.SrcTags {
				found := false
				for i := range cur {
					if cur[i].Tag == tag {
						if cur[i].Qty < ev.Qty {
							orphanEvents++
						} else {
							cur[i].Qty -= ev.Qty
						}
						found = true
						break
					}
				}
				if !found {
					orphanEvents++
				}
			}
			stacks[key] = cur

		case "pool_split_in":
			var sources []model.Unit
			for _, u := range cur {
				for _, tag := range ev.SrcTags {
					if u.Tag == tag && u.Qty > 0 {
						sources = append(sources, u)
					}
				}
			}
			if len(sources) == 0 {
				orphanEvents++
				continue
			}
			merged := mergePool(sources, ev)
			cur = removeEmptySources(cur, ev.SrcTags)
			cur = fluxlane.PushBack(cur, merged)
			stacks[key] = cur

		default:
			orphanEvents++
		}

		_ = decoy.RollQty(cur)
	}

	unitsRebuilt := 0
	for _, units := range stacks {
		for _, u := range units {
			if u.Qty > 0 {
				unitsRebuilt++
			}
		}
	}

	if !matchesUnits(stacks, snap) {
		expiryCarryGaps++
	}

	bindingDrift := bindingDelta(bindings, snap.Bindings)

	report := &model.Report{
		ScenarioID:       snap.ScenarioID,
		CrossmatchMisses: crossmatchMisses,
		BindingDrift:     bindingDrift,
		ExpiryCarryGaps:  expiryCarryGaps,
		OrphanEvents:     orphanEvents,
		UnitsRebuilt:     unitsRebuilt,
	}
	report.DigestHex = digest.Seal(report)
	return report, nil
}

func matchesUnits(stacks map[fridgeKey][]model.Unit, snap *model.Snapshot) bool {
	seen := map[string]model.Unit{}
	for _, units := range stacks {
		for _, u := range units {
			if u.Qty <= 0 {
				continue
			}
			seen[u.Tag] = u
		}
	}
	if len(seen) != len(snap.Units) {
		return false
	}
	for _, pub := range snap.Units {
		u, ok := seen[pub.Tag]
		if !ok {
			return false
		}
		if u.Qty != pub.Qty || u.ExpiryStamp != pub.ExpiryStamp || u.Abo != pub.Abo || u.Rh != pub.Rh {
			return false
		}
	}
	return true
}

func bindingDelta(active map[string]string, want []model.BindingRow) int {
	wantMap := map[string]string{}
	for _, row := range want {
		wantMap[row.Tag] = row.PatientID
	}
	drift := 0
	for tag, pid := range active {
		if wantMap[tag] != pid {
			drift++
		}
	}
	for tag, pid := range wantMap {
		if active[tag] != pid {
			drift++
		}
	}
	return drift / 2
}

func hasTag(cur []model.Unit, tag string) bool {
	_, ok := findUnit(cur, tag)
	return ok
}

func findUnit(cur []model.Unit, tag string) (model.Unit, bool) {
	for _, u := range cur {
		if u.Tag == tag && u.Qty > 0 {
			return u, true
		}
	}
	return model.Unit{}, false
}

func findExpiry(cur []model.Unit, tag string) string {
	for _, u := range cur {
		if u.Tag == tag {
			return u.ExpiryStamp
		}
	}
	return ""
}

func findAbo(cur []model.Unit, tag string) string {
	for _, u := range cur {
		if u.Tag == tag {
			return u.Abo
		}
	}
	return ""
}

func findRh(cur []model.Unit, tag string) string {
	for _, u := range cur {
		if u.Tag == tag {
			return u.Rh
		}
	}
	return ""
}

func removeEmptySources(cur []model.Unit, tags []string) []model.Unit {
	rm := map[string]bool{}
	for _, t := range tags {
		rm[t] = true
	}
	out := make([]model.Unit, 0, len(cur))
	for _, u := range cur {
		if rm[u.Tag] && u.Qty <= 0 {
			continue
		}
		out = append(out, u)
	}
	return out
}
