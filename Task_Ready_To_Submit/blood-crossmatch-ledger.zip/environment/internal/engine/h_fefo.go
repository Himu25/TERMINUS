package engine

import (
	"bloodledger/fluxlane"
	"bloodledger/internal/model"
	"bloodledger/spanlane"
)

func debitFEFO(cur []model.Unit, qty int) ([]model.Unit, int, bool, model.IssueRecord) {
	rec := model.IssueRecord{}
	updated, taken, violated := fluxlane.Op_m1(cur, qty)
	_, allocTaken, _ := spanlane.Span_v5(cur, qty)
	if allocTaken != taken {
		violated = true
	}
	if taken > 0 && len(cur) > 0 {
		rec.Taken = append(rec.Taken, struct {
			Tag  string
			Qty  int
			Slot int
		}{Tag: cur[0].Tag, Qty: taken, Slot: cur[0].Slot})
	}
	return updated, taken, violated, rec
}
