package engine

import (
	"bloodledger/internal/model"
	"bloodledger/rhlane"
)

func debitTagged(cur []model.Unit, ev model.Event) ([]model.Unit, int, bool, model.IssueRecord) {
	rec := model.IssueRecord{EventID: ev.EventID, Product: ev.Product, Loc: ev.Loc}
	if len(cur) == 0 {
		return cur, 0, false, rec
	}
	for i := range cur {
		if cur[i].Tag != ev.Tag || cur[i].Qty <= 0 {
			continue
		}
		if i > 0 && !rhlane.Bypass_p4(cur[i], ev) {
			return cur, 0, true, rec
		}
		clone := make([]model.Unit, len(cur))
		copy(clone, cur)
		take := ev.Qty
		if clone[i].Qty < take {
			take = clone[i].Qty
		}
		clone[i].Qty -= take
		rec.Taken = append(rec.Taken, struct {
			Tag  string
			Qty  int
			Slot int
		}{Tag: cur[i].Tag, Qty: take, Slot: cur[i].Slot})
		return clone, take, false, rec
	}
	return cur, 0, true, rec
}
