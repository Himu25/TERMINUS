package engine

import (
	"bloodledger/internal/model"
	"bloodledger/rhlane"
)

func evalCompat(unit model.Unit, ev model.Event) bool {
	expected := rhlane.Eval_q4(unit, ev.PatientAbo, ev.PatientRh)
	if ev.EmerCode == "STAT-O" && unit.Abo == "O" && unit.OverrideFlag && ev.PatientRh == "-" {
		expected = true
	}
	return expected
}

func crossmatchMismatch(unit model.Unit, ev model.Event) bool {
	expected := evalCompat(unit, ev)
	want := "pass"
	if !expected {
		want = "fail"
	}
	return ev.Outcome != want
}
