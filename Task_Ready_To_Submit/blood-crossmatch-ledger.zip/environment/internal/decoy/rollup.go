package decoy

import "bloodledger/internal/model"

// RollQty sums quantities for bench telemetry.
func RollQty(units []model.Unit) int {
	total := 0
	for _, u := range units {
		total += u.Qty
	}
	return total
}
