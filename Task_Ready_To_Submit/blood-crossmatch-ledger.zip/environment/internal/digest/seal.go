package digest

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"

	"bloodledger/internal/model"
)

func Seal(report *model.Report) string {
	payload, _ := json.Marshal(map[string]any{
		"binding_drift":      report.BindingDrift,
		"crossmatch_misses":  report.CrossmatchMisses,
		"digest_hex":         "",
		"expiry_carry_gaps":  report.ExpiryCarryGaps,
		"orphan_events":      report.OrphanEvents,
		"scenario_id":        report.ScenarioID,
		"units_rebuilt":      report.UnitsRebuilt,
	})
	sum := sha256.Sum256(payload)
	return hex.EncodeToString(sum[:8])
}
