package model

// Unit is one inventory row at a fridge position.
type Unit struct {
	Tag          string `json:"tag"`
	Product      string `json:"product"`
	Loc          string `json:"loc"`
	Qty          int    `json:"qty"`
	ExpiryStamp  string `json:"expiry_stamp"`
	Abo          string `json:"abo"`
	Rh           string `json:"rh"`
	Slot         int    `json:"-"`
	OverrideFlag bool   `json:"-"`
}

// Event is one ledger row from the tape.
type Event struct {
	EventID      string   `json:"event_id"`
	Product      string   `json:"product"`
	Loc          string   `json:"loc"`
	Kind         string   `json:"kind"`
	Qty          int      `json:"qty"`
	Ts           string   `json:"ts"`
	Tag          string   `json:"tag,omitempty"`
	Abo          string   `json:"abo,omitempty"`
	Rh           string   `json:"rh,omitempty"`
	Expiry       string   `json:"expiry,omitempty"`
	PatientID    string   `json:"patient_id,omitempty"`
	PatientAbo   string   `json:"patient_abo,omitempty"`
	PatientRh    string   `json:"patient_rh,omitempty"`
	Outcome      string   `json:"outcome,omitempty"`
	RefEvent     string   `json:"ref_event,omitempty"`
	SrcTags      []string `json:"src_tags,omitempty"`
	DstTag       string   `json:"dst_tag,omitempty"`
	OverrideFlag bool     `json:"override_flag,omitempty"`
	EmerCode     string   `json:"emer_code,omitempty"`
}

// PublishedUnit is finance snapshot row.
type PublishedUnit struct {
	Product     string `json:"product"`
	Loc         string `json:"loc"`
	Tag         string `json:"tag"`
	Qty         int    `json:"qty"`
	ExpiryStamp string `json:"expiry_stamp"`
	Abo         string `json:"abo"`
	Rh          string `json:"rh"`
}

// BindingRow is an active reserve row in the snapshot.
type BindingRow struct {
	Tag       string `json:"tag"`
	PatientID string `json:"patient_id"`
}

// Snapshot is imported inventory snapshot for one scenario.
type Snapshot struct {
	ScenarioID string          `json:"scenario_id"`
	Units      []PublishedUnit `json:"units"`
	Bindings   []BindingRow    `json:"bindings"`
}

// Report is audit output for one scenario run.
type Report struct {
	ScenarioID        string `json:"scenario_id"`
	CrossmatchMisses  int    `json:"crossmatch_misses"`
	BindingDrift      int    `json:"binding_drift"`
	ExpiryCarryGaps   int    `json:"expiry_carry_gaps"`
	OrphanEvents      int    `json:"orphan_events"`
	UnitsRebuilt      int    `json:"units_rebuilt"`
	DigestHex         string `json:"digest_hex"`
}

// IssueRecord tracks a debit row for later return.
type IssueRecord struct {
	EventID string
	Product string
	Loc     string
	Taken   []struct {
		Tag  string
		Qty  int
		Slot int
	}
}
