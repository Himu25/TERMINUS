package policy

import "os"

// LoadOverrideNote reads the override desk note for display only.
func LoadOverrideNote(path string) (string, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	return string(raw), nil
}
