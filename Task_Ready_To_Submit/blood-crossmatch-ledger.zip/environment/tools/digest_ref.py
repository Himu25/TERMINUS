#!/usr/bin/env python3
"""Reference digest helper for local bench runs."""
import hashlib
import json
import sys

def main() -> None:
    report = json.load(sys.stdin)
    clone = dict(report)
    clone["digest_hex"] = ""
    payload = json.dumps(clone, separators=(",", ":"), sort_keys=True)
    print(hashlib.sha256(payload.encode()).hexdigest()[:16])

if __name__ == "__main__":
    main()
