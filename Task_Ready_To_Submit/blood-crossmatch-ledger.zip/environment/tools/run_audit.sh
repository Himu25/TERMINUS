#!/bin/bash
set -euo pipefail
exec "/app/bin/crossaudit" \
  --events "${1:-/app/data/events_default.jsonl}" \
  --snapshot "${2:-/app/data/snapshot_default.json}" \
  --out /app/output/crossmatch_audit.json
