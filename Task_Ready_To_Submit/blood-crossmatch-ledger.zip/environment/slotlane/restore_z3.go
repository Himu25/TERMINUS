package slotlane

import "bloodledger/internal/model"

// Restore_z3 restores secondary unit quantity into primary slice.
func Restore_z3(primary []model.Unit, secondary model.Unit, tertiary int) []model.Unit {
	out := make([]model.Unit, len(primary))
	copy(out, primary)
	restored := model.Unit{
		Tag:          secondary.Tag,
		Product:      secondary.Product,
		Loc:          secondary.Loc,
		Qty:          tertiary,
		ExpiryStamp:  secondary.ExpiryStamp,
		Abo:          secondary.Abo,
		Rh:           secondary.Rh,
		Slot:         len(out),
		OverrideFlag: secondary.OverrideFlag,
	}
	return append(out, restored)
}
