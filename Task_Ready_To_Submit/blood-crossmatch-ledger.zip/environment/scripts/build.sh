#!/bin/bash
set -euo pipefail
cd /app
go build -o "/app/bin/crossaudit" ./cmd/crossaudit
