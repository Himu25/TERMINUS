# Blood bank compatibility and replay policy

Each product-fridge maintains an ordered stack of units. Index zero is the earliest expiry (FEFO head).

## Intake

- Append a new unit at the stack tail with `expiry_stamp` equal to the intake expiry field.
- `override_flag` on an intake row marks universal-donor units eligible for documented emergency lanes.

## Crossmatch

- Evaluate ABO using the standard donor-to-recipient table.
- Rh-negative recipients may receive only Rh-negative units unless an emergency lane applies.
- Emergency lane `STAT-O` with an O-type unit that has `override_flag` set permits Rh-negative recipients when the crossmatch row carries the same code.
- Recorded `outcome` must agree with the evaluated compatibility (`pass` or `fail`).

## Reserve and release

- `reserve` binds a unit tag to `patient_id` while quantity remains positive.
- `release` clears an active binding without debiting inventory.
- `issue` debits quantity and clears any binding on the issued tag.

## Issue consumption

- Untagged issues consume from the earliest-expiry units first.
- Tagged issues name a specific unit tag. When the tag is not at index zero, issue is allowed only if that unit was received with `override_flag` set on its intake row.
- Partial issues that span more than one unit debit proportional quantity from each unit in FEFO order.

## Return

- A return row references the original issue via `ref_event`.
- Restored quantity returns to the same stack index the original issue debited, not the tail.

## Pool split

- `pool_split_out` debits source tags; `pool_split_in` credits a destination tag.
- Merged destination units inherit the earliest `expiry_stamp` among source units, not the split event timestamp.

## Audit output

The replay writes `/app/output/crossmatch_audit.json` with `scenario_id`, `crossmatch_misses`, `binding_drift`, `expiry_carry_gaps`, `orphan_events`, `units_rebuilt`, and `digest_hex` (sixteen lowercase hex digits sealing the block with `digest_hex` blanked).

## Audit counters

- `crossmatch_misses`: crossmatch rows whose recorded outcome disagrees with evaluated compatibility.
- `binding_drift`: active bindings that disagree with the published snapshot binding list.
- `expiry_carry_gaps`: rebuilt inventory whose unit fields disagree with the published snapshot, including FEFO violations on issue.
- `orphan_events`: rows with dangling references or impossible quantities.
- `units_rebuilt`: units with positive quantity after replay.
