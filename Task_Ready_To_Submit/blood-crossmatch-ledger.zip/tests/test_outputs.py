"""Verifier for blood-crossmatch-ledger."""

from __future__ import annotations

import hashlib
import json
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "crossmatch_audit.json"
AUDIT = APP / "bin" / "crossaudit"
FIXTURES = Path("/tests/fixtures")
SCENARIO_INDEX = APP / "docs" / "scenario_index.txt"

REPORT_KEYS = frozenset(
    {
        "scenario_id",
        "crossmatch_misses",
        "binding_drift",
        "expiry_carry_gaps",
        "orphan_events",
        "units_rebuilt",
        "digest_hex",
    }
)


def _run_audit(events: Path, snapshot: Path) -> None:
    subprocess.run(
        [
            str(AUDIT),
            "--events",
            str(events),
            "--snapshot",
            str(snapshot),
            "--out",
            str(OUT),
        ],
        check=True,
    )


def _load_report() -> dict:
    return json.loads(OUT.read_text(encoding="utf-8"))


def _expected_digest(report: dict) -> str:
    clone = dict(report)
    clone["digest_hex"] = ""
    payload = json.dumps(clone, separators=(",", ":"), sort_keys=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]


def _scenario_stems() -> list[str]:
    stems: list[str] = []
    for line in SCENARIO_INDEX.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        stems.append(line)
    return stems


@pytest.fixture(scope="module")
def default_report() -> dict:
    _run_audit(APP / "data" / "events_default.jsonl", APP / "data" / "snapshot_default.json")
    return _load_report()


def test_default_zero_mismatches(default_report: dict) -> None:
    """Default tape must reconcile with zero mismatch counters."""
    assert default_report["crossmatch_misses"] == 0
    assert default_report["binding_drift"] == 0
    assert default_report["expiry_carry_gaps"] == 0
    assert default_report["orphan_events"] == 0


def test_default_scenario_id(default_report: dict) -> None:
    """Report scenario_id must match the bundled snapshot."""
    snap = json.loads((APP / "data" / "snapshot_default.json").read_text(encoding="utf-8"))
    assert default_report["scenario_id"] == snap["scenario_id"]


def test_crossmatch_misses_zero(default_report: dict) -> None:
    """crossmatch_misses must be zero on the default tape."""
    assert default_report["crossmatch_misses"] == 0


def test_binding_drift_zero(default_report: dict) -> None:
    """binding_drift must be zero on the default tape."""
    assert default_report["binding_drift"] == 0


def test_expiry_carry_gaps_zero(default_report: dict) -> None:
    """expiry_carry_gaps must be zero on the default tape."""
    assert default_report["expiry_carry_gaps"] == 0


def test_orphan_events_zero(default_report: dict) -> None:
    """orphan_events must be zero on the default tape."""
    assert default_report["orphan_events"] == 0


def test_units_rebuilt_count(default_report: dict) -> None:
    """units_rebuilt must count positive units after default replay."""
    assert default_report["units_rebuilt"] >= 2


def test_digest_hex_format(default_report: dict) -> None:
    """digest_hex must be sixteen lowercase hex digits."""
    digest = default_report["digest_hex"]
    assert len(digest) == 16
    assert digest == digest.lower()
    int(digest, 16)


def test_digest_matches_payload(default_report: dict) -> None:
    """digest_hex must seal the scenario block with digest_hex blanked."""
    assert default_report["digest_hex"] == _expected_digest(default_report)


def test_report_schema(default_report: dict) -> None:
    """Audit JSON must expose the contract top-level fields."""
    assert set(default_report.keys()) == REPORT_KEYS


def test_repeat_run_identical() -> None:
    """Two consecutive default audits must produce identical output bytes."""
    _run_audit(APP / "data" / "events_default.jsonl", APP / "data" / "snapshot_default.json")
    first = OUT.read_bytes()
    _run_audit(APP / "data" / "events_default.jsonl", APP / "data" / "snapshot_default.json")
    second = OUT.read_bytes()
    assert first == second


@pytest.mark.parametrize("stem", _scenario_stems())
def test_indexed_scenario_stem(stem: str) -> None:
    """Each scenario stem listed for grading must reconcile cleanly."""
    manifest = FIXTURES / stem / "events.jsonl"
    snapshot = FIXTURES / stem / "snapshot.json"
    assert manifest.is_file()
    assert snapshot.is_file()
    _run_audit(manifest, snapshot)
    report = _load_report()
    assert report["crossmatch_misses"] == 0
    assert report["binding_drift"] == 0
    assert report["expiry_carry_gaps"] == 0
    assert report["orphan_events"] == 0
