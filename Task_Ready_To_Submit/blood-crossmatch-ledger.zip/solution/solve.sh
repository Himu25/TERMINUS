#!/bin/bash
set -euo pipefail

log() { printf '[oracle] %s\n' "$1"; }

cd /app

log "fix FEFO debit to consume earliest expiry first"
cat > /app/fluxlane/m1_lane.go <<'GO'
package fluxlane

import "bloodledger/internal/model"

// Op_m1 removes secondary quantity from the primary slice.
func Op_m1(primary []model.Unit, secondary int) ([]model.Unit, int, bool) {
	if secondary <= 0 || len(primary) == 0 {
		return primary, 0, false
	}
	out := make([]model.Unit, len(primary))
	copy(out, primary)
	remaining := secondary
	for i := 0; i < len(out) && remaining > 0; i++ {
		if out[i].Qty <= 0 {
			continue
		}
		take := out[i].Qty
		if take > remaining {
			take = remaining
		}
		out[i].Qty -= take
		remaining -= take
	}
	return out, secondary - remaining, false
}

// PushBack appends one unit record.
func PushBack(primary []model.Unit, secondary model.Unit) []model.Unit {
	return append(primary, secondary)
}
GO

log "fix pool merge expiry to earliest source stamp"
cat > /app/weave/merge_w2.go <<'GO'
package weave

import "bloodledger/internal/model"

// Merge_w2 merges source units into one destination unit.
func Merge_w2(a []model.Unit, b string, c int) model.Unit {
	if len(a) == 0 {
		return model.Unit{}
	}
	total := 0
	tag := ""
	product := a[0].Product
	loc := a[0].Loc
	abo := a[0].Abo
	rh := a[0].Rh
	oldest := a[0].ExpiryStamp
	for _, u := range a {
		total += u.Qty
		if u.ExpiryStamp < oldest {
			oldest = u.ExpiryStamp
		}
		if tag == "" {
			tag = u.Tag
		}
	}
	return model.Unit{
		Tag:          tag,
		Product:      product,
		Loc:          loc,
		Qty:          total,
		ExpiryStamp:  oldest,
		Abo:          abo,
		Rh:           rh,
		OverrideFlag: false,
	}
}
GO

log "fix return restore to original stack index"
cat > /app/slotlane/restore_z3.go <<'GO'
package slotlane

import "bloodledger/internal/model"

// Restore_z3 restores secondary unit quantity into primary slice.
func Restore_z3(primary []model.Unit, secondary model.Unit, tertiary int) []model.Unit {
	out := make([]model.Unit, len(primary))
	copy(out, primary)
	for i := range out {
		if out[i].Tag == secondary.Tag && out[i].Slot == secondary.Slot {
			out[i].Qty += tertiary
			return out
		}
	}
	idx := secondary.Slot
	if idx < 0 {
		idx = 0
	}
	if idx > len(out) {
		idx = len(out)
	}
	restored := secondary
	restored.Qty = tertiary
	newOut := make([]model.Unit, 0, len(out)+1)
	newOut = append(newOut, out[:idx]...)
	newOut = append(newOut, restored)
	newOut = append(newOut, out[idx:]...)
	return newOut
}
GO

log "fix Rh compatibility on crossmatch evaluation"
cat > /app/rhlane/eval_q4.go <<'GO'
package rhlane

import "bloodledger/internal/model"

var aboDonor = map[string][]string{
	"O":  {"O"},
	"A":  {"A", "O"},
	"B":  {"B", "O"},
	"AB": {"A", "B", "AB", "O"},
}

// Eval_q4 returns whether patient and unit types are compatible.
func Eval_q4(primary model.Unit, patientAbo string, patientRh string) bool {
	allowed, ok := aboDonor[patientAbo]
	if !ok {
		return false
	}
	match := false
	for _, d := range allowed {
		if d == primary.Abo {
			match = true
			break
		}
	}
	if !match {
		return false
	}
	if patientRh == "-" && primary.Rh == "+" {
		return false
	}
	return true
}

// Bypass_p4 returns whether tagged debit may skip FEFO ordering.
func Bypass_p4(primary model.Unit, secondary model.Event) bool {
	return primary.OverrideFlag
}
GO

log "fix partial allocation across multiple units"
cat > /app/spanlane/span_v5.go <<'GO'
package spanlane

import "bloodledger/internal/model"

// Span_v5 allocates secondary quantity across primary units.
func Span_v5(primary []model.Unit, secondary int) ([]model.Unit, int, int) {
	out := make([]model.Unit, len(primary))
	copy(out, primary)
	if secondary <= 0 || len(out) == 0 {
		return out, 0, 0
	}
	cost := 0
	remaining := secondary
	for i := 0; i < len(out) && remaining > 0; i++ {
		if out[i].Qty <= 0 {
			continue
		}
		take := out[i].Qty
		if take > remaining {
			take = remaining
		}
		out[i].Qty -= take
		cost += take
		remaining -= take
	}
	return out, secondary - remaining, cost
}
GO

log "rebuild crossaudit"
bash /app/scripts/build.sh

log "run default audit"
mkdir -p /app/output
/app/tools/run_audit.sh

log "oracle complete"
