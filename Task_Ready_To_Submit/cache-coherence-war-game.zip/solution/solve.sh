#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

patch -p1 -d /app < "${ROOT_DIR}/patches/op_a.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/op_b.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/op_c.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/op_d.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/op_f.patch"
patch -p1 -d /app < "${ROOT_DIR}/patches/scope_g.patch"

bash /app/scripts/build.sh
TB_WAR_FIXTURE=1 /app/bin/war_lab
