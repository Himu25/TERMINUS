"""Verifier for cache-coherence-war-game coherence reports."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "coherence_report.json"
BIN = "/app/bin/war_lab"
ACTIVE_CLUSTER = APP / "data" / "active" / "cluster.json"
STEM_INDEX = APP / "docs" / "scenario_index.txt"

SCHEMA_VERSION = 2
FINISH_COMPLETE = "complete"

REQUIRED_TOP_FIELDS = ("schema_version", "cluster_id", "scenarios")
REQUIRED_ROW_FIELDS = (
    "name",
    "finish_reason",
    "propagation_hops",
    "violations_found",
    "violations_fixed",
    "cascade_depth",
    "stale_reads",
    "races_observed",
    "digest_hex",
)

# PUBLIC (~70%): read path, write bump, L1 hit, restore, trace, shard fill, fanout.
PUBLIC_EXPECTED = {
    "case_read_through": {
        "finish_reason": FINISH_COMPLETE,
        "propagation_hops": 3,
        "stale_reads": 0,
    },
    "case_write_bump": {
        "finish_reason": FINISH_COMPLETE,
        "violations_fixed": 1,
        "stale_reads": 0,
    },
    "case_l1_hit": {
        "finish_reason": FINISH_COMPLETE,
        "propagation_hops": 1,
    },
    "case_restore_fresh": {
        "finish_reason": FINISH_COMPLETE,
        "stale_reads": 0,
        "violations_fixed": 1,
    },
    "case_prop_trace": {
        "finish_reason": FINISH_COMPLETE,
        "violations_fixed": 1,
        "propagation_hops": 3,
    },
    "case_shard_fill": {
        "finish_reason": FINISH_COMPLETE,
        "propagation_hops": 2,
    },
    "case_peak_fanout": {
        "finish_reason": FINISH_COMPLETE,
        "stale_reads": 0,
        "propagation_hops": 3,
    },
}

# HIDDEN (~30%): cascade invalidation, race interleave, stale replica.
HIDDEN_EXPECTED = {
    "case_cascade_inv": {
        "finish_reason": FINISH_COMPLETE,
        "cascade_depth": 2,
        "violations_fixed": 1,
    },
    "case_race_interleave": {
        "finish_reason": FINISH_COMPLETE,
        "races_observed": 0,
        "violations_fixed": 1,
    },
    "case_multi_rev_cache": {
        "finish_reason": FINISH_COMPLETE,
        "propagation_hops": 2,
        "violations_fixed": 1,
        "stale_reads": 0,
    },
    "case_stale_replica": {
        "finish_reason": FINISH_COMPLETE,
        "violations_fixed": 1,
        "stale_reads": 0,
    },
}


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    """Build war_lab and warctl once for the verifier session."""
    env = {**os.environ}
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _row_digest_matches_rust(row: dict) -> str:
    proc = subprocess.run(
        [
            "/app/bin/digest_cli",
            row["name"],
            row["finish_reason"],
            str(row["propagation_hops"]),
            str(row["violations_found"]),
            str(row["violations_fixed"]),
            str(row["cascade_depth"]),
            str(row["stale_reads"]),
            str(row["races_observed"]),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return proc.stdout.strip()


def _run_lab(extra_env: dict | None = None) -> dict:
    env = {
        **os.environ,
        "TB_WAR_FIXTURE": "1",
    }
    if extra_env:
        env.update(extra_env)
    subprocess.run([BIN], cwd="/app", env=env, check=True)
    return json.loads(OUT.read_text())


def _by_name(report: dict) -> dict[str, dict]:
    return {row["name"]: row for row in report["scenarios"]}


def _load_stems() -> list[str]:
    lines = STEM_INDEX.read_text().splitlines()
    return [line.strip() for line in lines if line.strip() and not line.startswith("#")]


def test_report_schema_and_cluster() -> None:
    """Report uses schema version 2 and the active cluster id."""
    report = _run_lab()
    assert report["schema_version"] == SCHEMA_VERSION
    cluster = json.loads(ACTIVE_CLUSTER.read_text())
    assert report["cluster_id"] == cluster["cluster_id"]
    assert len(report["scenarios"]) >= 10


def test_report_contains_required_fields() -> None:
    """Top-level and per-scenario report rows include every schema field."""
    report = _run_lab()
    for field in REQUIRED_TOP_FIELDS:
        assert field in report
    for row in report["scenarios"]:
        for field in REQUIRED_ROW_FIELDS:
            assert field in row


def test_read_through_cold_path() -> None:
    """Cold catalog pull traverses three tiers."""
    row = _by_name(_run_lab())["case_read_through"]
    ex = PUBLIC_EXPECTED["case_read_through"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["propagation_hops"] == ex["propagation_hops"]
    assert row["stale_reads"] == ex["stale_reads"]


def test_write_bump_restores_coherence() -> None:
    """Revision commit survives L1 eviction without stale shard rows."""
    row = _by_name(_run_lab())["case_write_bump"]
    ex = PUBLIC_EXPECTED["case_write_bump"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["violations_fixed"] == ex["violations_fixed"]
    assert row["stale_reads"] == ex["stale_reads"]


def test_l1_hit_on_repeat() -> None:
    """Second read on unchanged revision hits L1 only."""
    row = _by_name(_run_lab())["case_l1_hit"]
    ex = PUBLIC_EXPECTED["case_l1_hit"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["propagation_hops"] == ex["propagation_hops"]


def test_restore_fresh_after_bump() -> None:
    """Post-bump read returns fresh payload with zero stale_reads."""
    row = _by_name(_run_lab())["case_restore_fresh"]
    ex = PUBLIC_EXPECTED["case_restore_fresh"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["stale_reads"] == ex["stale_reads"]
    assert row["violations_fixed"] == ex["violations_fixed"]


def test_prop_trace_matches_warctl() -> None:
    """Propagation trace formatting matches warctl on a three-hop cold read."""
    row = _by_name(_run_lab())["case_prop_trace"]
    ex = PUBLIC_EXPECTED["case_prop_trace"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["violations_fixed"] == ex["violations_fixed"]
    assert row["propagation_hops"] == ex["propagation_hops"]


def test_shard_fill_l2_shortcut() -> None:
    """Primed second tier serves a two-hop read when the local gate is cold."""
    row = _by_name(_run_lab())["case_shard_fill"]
    ex = PUBLIC_EXPECTED["case_shard_fill"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["propagation_hops"] == ex["propagation_hops"]


def test_peak_fanout_clean() -> None:
    """Fanout across shard slots completes without stale reads."""
    row = _by_name(_run_lab())["case_peak_fanout"]
    ex = PUBLIC_EXPECTED["case_peak_fanout"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["stale_reads"] == ex["stale_reads"]
    assert row["propagation_hops"] == ex["propagation_hops"]


def test_hidden_cascade_invalidation() -> None:
    """Parent prefix drop cascades to both child shard rows."""
    row = _by_name(_run_lab())["case_cascade_inv"]
    ex = HIDDEN_EXPECTED["case_cascade_inv"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["cascade_depth"] == ex["cascade_depth"]
    assert row["violations_fixed"] == ex["violations_fixed"]


def test_hidden_race_interleave() -> None:
    """Held slots drain between epochs with zero races observed."""
    row = _by_name(_run_lab())["case_race_interleave"]
    ex = HIDDEN_EXPECTED["case_race_interleave"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["races_observed"] == ex["races_observed"]
    assert row["violations_fixed"] == ex["violations_fixed"]


def test_hidden_multi_rev_cache() -> None:
    """Two revisions of the same slot stay isolated in the shard tier."""
    row = _by_name(_run_lab())["case_multi_rev_cache"]
    ex = HIDDEN_EXPECTED["case_multi_rev_cache"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["propagation_hops"] == ex["propagation_hops"]
    assert row["violations_fixed"] == ex["violations_fixed"]
    assert row["stale_reads"] == ex["stale_reads"]


def test_hidden_stale_replica_pulse() -> None:
    """Revision pulse evicts stale L1 rows before warm pull."""
    row = _by_name(_run_lab())["case_stale_replica"]
    ex = HIDDEN_EXPECTED["case_stale_replica"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["violations_fixed"] == ex["violations_fixed"]
    assert row["stale_reads"] == ex["stale_reads"]


def test_regression_stems_complete() -> None:
    """Every stem listed in scenario_index finishes complete."""
    report = _run_lab()
    rows = _by_name(report)
    for stem in _load_stems():
        assert rows[stem]["finish_reason"] == FINISH_COMPLETE


def test_row_digests_match_helper() -> None:
    """Each scenario digest matches the digest helper."""
    report = _run_lab()
    for row in report["scenarios"]:
        assert row["digest_hex"] == _row_digest_matches_rust(row)


def test_rust_unit_tests_pass() -> None:
    """Workspace unit tests must pass after the fix."""
    proc = subprocess.run(
        ["cargo", "test", "--workspace", "--quiet"],
        cwd="/app",
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout
