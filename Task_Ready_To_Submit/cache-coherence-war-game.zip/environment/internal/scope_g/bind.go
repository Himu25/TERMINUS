package scope_g

import "fmt"

func BindNote(a, b string) string {
	return fmt.Sprintf("%s@%s", a, b)
}
