package scope_g

import "strconv"

func FormatTrace(hops uint32) string {
	switch hops {
	case 1:
		return "l1"
	case 2:
		return "l1>l2"
	case 3:
		return "l1>l2>src"
	default:
		return "unknown:" + strconv.FormatUint(uint64(hops), 10)
	}
}
