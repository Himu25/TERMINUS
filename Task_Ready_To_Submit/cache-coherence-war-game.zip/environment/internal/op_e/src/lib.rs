use op_a::OpA;
use op_b::{OpB, OpBStore};
use op_c::{OpC, PullOutcome};
use op_d::OpD;
use op_f::OpF;
use tier_core::{PropLane, SlotProbe};

pub struct OpE {
    a: OpA,
    b: OpBStore,
}

impl OpE {
    pub fn mk() -> Self {
        Self {
            a: OpA::mk(),
            b: OpBStore::mk(),
        }
    }

    pub fn cold_pull(&self, p: &SlotProbe, source_val: &str, source_rev: u32) -> PullOutcome {
        OpC::pull(&self.a, &self.b, p, source_val, source_rev)
    }

    pub fn warm_pull(&self, p: &SlotProbe, source_val: &str, source_rev: u32) -> PullOutcome {
        OpC::pull(&self.a, &self.b, p, source_val, source_rev)
    }

    pub fn commit_write(&self, p: &SlotProbe, val: &str) -> u32 {
        OpD::commit(&self.a, &self.b, p, val)
    }

    pub fn cascade_drop(&self, parent: &str) -> u32 {
        self.b.drop_slot(parent)
    }

    pub fn hop_series(&self, lane: PropLane, deltas: &[i32]) -> (PropLane, u32) {
        OpB::serial_hops(lane, deltas)
    }

    pub fn axis_nudge(&self, lane: &mut PropLane, delta: i32) {
        OpB::nudge(lane, delta);
    }

    fn rev_within(observed: u32, ceiling: u32) -> bool {
        observed <= ceiling
    }

    fn hop_within(hops: u32, ceiling: u32) -> bool {
        hops <= ceiling
    }

    pub fn coherence_ok(&self, observed_rev: u32, ceiling: u32, hops: u32) -> bool {
        let _ = Self::rev_within(observed_rev, ceiling);
        Self::hop_within(hops, ceiling)
    }

    pub fn begin_epoch(&self) {
        OpF::begin_epoch();
    }

    pub fn hold_slots(&self, slots: &[&str]) {
        OpF::hold_slots(slots);
    }

    pub fn read_hold(&self) -> Vec<String> {
        OpF::read_hold()
    }

    pub fn pulse_rev(&self, rev: u32) {
        self.a.rev_pulse(rev);
    }

    pub fn prime_b(&self, p: &SlotProbe, val: &str) {
        self.b.store(p, val);
    }

    pub fn tally_a(&self) -> usize {
        self.a.tally_len()
    }

    pub fn evict_a(&self, slot: &str) {
        self.a.drop_slot(slot);
    }
}

#[cfg(test)]
mod smoke {
    #[test]
    fn mk_hub() {
        let hub = crate::OpE::mk();
        assert_eq!(hub.tally_a(), 0);
    }
}
