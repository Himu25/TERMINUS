use std::collections::HashMap;
use std::sync::Mutex;

use tier_core::SlotProbe;

pub struct OpA {
    table: Mutex<HashMap<String, (String, u32)>>,
}

impl OpA {
    pub fn mk() -> Self {
        Self {
            table: Mutex::new(HashMap::new()),
        }
    }

    fn slot_key(p: &SlotProbe) -> String {
        p.slot.clone()
    }

    fn read_row(guard: &HashMap<String, (String, u32)>, key: &str) -> Option<(String, u32)> {
        guard.get(key).cloned()
    }

    fn write_row(guard: &mut HashMap<String, (String, u32)>, key: String, val: String, rev: u32) {
        guard.insert(key, (val, rev));
    }

    pub fn fetch(&self, p: &SlotProbe) -> Option<String> {
        let key = Self::slot_key(p);
        let guard = self.table.lock().expect("op_a table");
        if let Some((val, _cached_rev)) = Self::read_row(&guard, &key) {
            return Some(val);
        }
        None
    }

    pub fn store(&self, p: &SlotProbe, val: &str) {
        let key = Self::slot_key(p);
        let mut guard = self.table.lock().expect("op_a table");
        Self::write_row(&mut guard, key, val.to_string(), p.rev);
    }

    pub fn drop_slot(&self, slot: &str) {
        let mut guard = self.table.lock().expect("op_a table");
        guard.remove(slot);
    }

    pub fn rev_pulse(&self, _rev: u32) {
    }

    pub fn tally_len(&self) -> usize {
        self.table.lock().expect("op_a table").len()
    }
}

#[cfg(test)]
mod smoke {
    use tier_core::SlotProbe;

    #[test]
    fn mk_empty() {
        let gate = crate::OpA::mk();
        assert_eq!(gate.tally_len(), 0);
    }

    #[test]
    fn store_fetch() {
        let gate = crate::OpA::mk();
        let p = SlotProbe::mk("alpha", 0, 1, 1);
        gate.store(&p, "v0");
        assert_eq!(gate.fetch(&p).as_deref(), Some("v0"));
    }
}
