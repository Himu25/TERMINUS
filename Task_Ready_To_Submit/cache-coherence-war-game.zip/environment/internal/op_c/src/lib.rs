use op_a::OpA;
use op_b::OpBStore;
use tier_core::SlotProbe;

#[derive(Clone, Debug)]
pub struct PullOutcome {
    pub value: String,
    pub hops: u32,
    pub stale: bool,
}

pub struct OpC;

impl OpC {
    pub fn pull(
        a: &OpA,
        b: &OpBStore,
        p: &SlotProbe,
        source_val: &str,
        source_rev: u32,
    ) -> PullOutcome {
        if let Some(val) = a.fetch(p) {
            return PullOutcome {
                value: val,
                hops: 1,
                stale: false,
            };
        }
        if let Some((val, _rev)) = b.fetch(&p.slot, p.rev) {
            return PullOutcome {
                value: val,
                hops: 2,
                stale: false,
            };
        }
        a.store(p, source_val);
        b.store(p, source_val);
        PullOutcome {
            value: source_val.to_string(),
            hops: 3,
            stale: source_rev != p.rev,
        }
    }
}
