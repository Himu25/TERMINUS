#!/usr/bin/env bash
set -euo pipefail
export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
cd /app
cargo check --workspace --quiet
go build -o /dev/null ./cmd/matrix_ctl
