#!/usr/bin/env bash
set -euo pipefail
export PATH="/app/bin:/usr/local/cargo/bin:${PATH}"
cd /app
bash /app/scripts/build.sh
TB_WAR_FIXTURE=1 /app/bin/war_lab
test -s /app/output/coherence_report.json
