# cache-coherence-war-game environment

Distributed cache hierarchy replay lab. See `/app/docs/architecture.md`.
