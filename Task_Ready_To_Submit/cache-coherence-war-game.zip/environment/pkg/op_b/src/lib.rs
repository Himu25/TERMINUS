use std::collections::HashMap;
use std::sync::Mutex;

use tier_core::{PropLane, SlotProbe};

pub struct OpB;

impl OpB {
    fn hop_once(mut lane: PropLane, delta: i32) -> PropLane {
        for hop in &mut lane.hops {
            if hop.rev > 0 {
                hop.rev = hop.rev.saturating_add(delta as u32);
            }
        }
        lane
    }

    fn hop_ready(lane: &PropLane, hops: u32) -> bool {
        if hops == 0 {
            return true;
        }
        lane.link_gen != 0
    }

    fn offset_lane(lane: &mut PropLane, delta: i32) {
        for hop in &mut lane.hops {
            hop.rev = hop.rev.saturating_add(delta as u32);
        }
    }

    pub fn serial_hops(mut lane: PropLane, deltas: &[i32]) -> (PropLane, u32) {
        let mut hops = 0u32;
        for &delta in deltas {
            if !Self::hop_ready(&lane, hops) {
                break;
            }
            lane = Self::hop_once(lane, delta);
            hops += 1;
        }
        (lane, hops)
    }

    pub fn nudge(lane: &mut PropLane, delta: i32) {
        Self::offset_lane(lane, delta);
    }

    pub fn hop_count(deltas: &[i32]) -> u32 {
        deltas.len() as u32
    }
}

pub struct OpBStore {
    table: Mutex<HashMap<String, (String, u32)>>,
}

impl OpBStore {
    pub fn mk() -> Self {
        Self {
            table: Mutex::new(HashMap::new()),
        }
    }

    pub fn fetch(&self, slot: &str, _rev: u32) -> Option<(String, u32)> {
        let guard = self.table.lock().expect("op_b table");
        guard.get(slot).cloned()
    }

    pub fn store(&self, p: &SlotProbe, val: &str) {
        let mut guard = self.table.lock().expect("op_b table");
        guard.insert(p.slot.clone(), (val.to_string(), p.rev));
    }

    pub fn drop_slot(&self, slot: &str) -> u32 {
        let mut guard = self.table.lock().expect("op_b table");
        if guard.remove(slot).is_some() {
            1
        } else {
            0
        }
    }

    pub fn tally_len(&self) -> usize {
        self.table.lock().expect("op_b table").len()
    }
}

#[cfg(test)]
mod smoke {
    use tier_core::{PropLane, SlotProbe};

    use crate::{OpB, OpBStore};

    #[test]
    fn nudge_lane() {
        let p = SlotProbe::mk("beta", 1, 2, 3);
        let mut lane = PropLane::from_probe(&p);
        OpB::nudge(&mut lane, 1);
        assert_eq!(lane.hops[0].rev, 2);
    }

    #[test]
    fn store_roundtrip() {
        let store = OpBStore::mk();
        let p = SlotProbe::mk("gamma", 0, 1, 1);
        store.store(&p, "x");
        let got = store.fetch("gamma", 0).expect("row");
        assert_eq!(got.0, "x");
    }
}
