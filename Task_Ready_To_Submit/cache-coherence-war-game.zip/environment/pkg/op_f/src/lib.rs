use std::sync::Mutex;

static HELD_SLOTS: Mutex<Vec<String>> = Mutex::new(Vec::new());

pub struct OpF;

impl OpF {
    pub fn begin_epoch() {
    }

    pub fn hold_slots(slots: &[&str]) {
        if let Ok(mut guard) = HELD_SLOTS.lock() {
            *guard = slots.iter().map(|s| s.to_string()).collect();
        }
    }

    pub fn read_hold() -> Vec<String> {
        HELD_SLOTS
            .lock()
            .map(|guard| guard.clone())
            .unwrap_or_default()
    }

    pub fn hold_count() -> usize {
        HELD_SLOTS.lock().map(|guard| guard.len()).unwrap_or(0)
    }

    fn purge_hold(guard: &mut Vec<String>) {
        guard.clear();
    }
}

#[cfg(test)]
mod smoke {
    #[test]
    fn hold_blank() {
        let got = crate::OpF::read_hold();
        assert!(got.is_empty());
    }
}
