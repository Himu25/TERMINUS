use op_a::OpA;
use op_b::OpBStore;
use tier_core::SlotProbe;

pub struct OpD;

impl OpD {
    pub fn commit(a: &OpA, _b: &OpBStore, p: &SlotProbe, val: &str) -> u32 {
        a.drop_slot(&p.slot);
        a.store(p, val);
        1
    }

    pub fn bump_rows(p: &SlotProbe, val: &str) -> (String, u32) {
        (val.to_string(), p.rev)
    }
}
