package api

type CoherenceRow struct {
	Name             string `json:"name"`
	FinishReason     string `json:"finish_reason"`
	PropagationHops  uint32 `json:"propagation_hops"`
	ViolationsFound  uint32 `json:"violations_found"`
	ViolationsFixed  uint32 `json:"violations_fixed"`
	CascadeDepth     uint32 `json:"cascade_depth"`
	StaleReads       uint32 `json:"stale_reads"`
	RacesObserved    uint32 `json:"races_observed"`
	DigestHex        string `json:"digest_hex"`
}

type CoherenceReport struct {
	SchemaVersion uint32         `json:"schema_version"`
	ClusterID     string         `json:"cluster_id"`
	Scenarios     []CoherenceRow `json:"scenarios"`
}
