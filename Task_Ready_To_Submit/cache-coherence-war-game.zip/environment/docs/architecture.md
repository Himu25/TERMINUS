# Cache war hierarchy

The replay harness under `/app` models a three-tier read path: a local gate, a shard store, then the JSON catalog in `/app/data/catalog/source.json`. Go `warctl` formats propagation traces for cold reads. Rust modules under `internal/` and `pkg/` coordinate the read and write relays plus session bookkeeping.

Run `/app/scripts/build.sh`, then `/app/bin/war_lab` with `TB_WAR_FIXTURE=1` for the full stem list in `/app/docs/scenario_index.txt`. Output lands at `/app/output/coherence_report.json`.

Each scenario row carries `name`, `finish_reason`, `propagation_hops`, `violations_found`, `violations_fixed`, `cascade_depth`, `stale_reads`, `races_observed`, and `digest_hex`. Field layout is in `/app/schemas/report.example.json`.
