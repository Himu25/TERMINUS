module cachewar

go 1.22
