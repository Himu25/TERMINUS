#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
cd /app
mkdir -p /app/bin /app/output

target_root="${CARGO_TARGET_DIR:-/app/target}"

cargo build --release --bin war_lab
install -m 0755 "${target_root}/release/war_lab" /app/bin/war_lab
cargo build --release --bin digest_cli
install -m 0755 "${target_root}/release/digest_cli" /app/bin/digest_cli

go build -o /app/bin/warctl ./cmd/matrix_ctl
