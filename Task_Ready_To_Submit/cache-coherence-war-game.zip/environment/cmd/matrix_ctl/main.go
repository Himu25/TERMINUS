package main

import (
	"flag"
	"fmt"
	"os"
	"strconv"

	"cachewar/internal/scope_g"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Fprintln(os.Stderr, "usage: warctl trace --hops N")
		os.Exit(2)
	}
	switch os.Args[1] {
	case "trace":
		fs := flag.NewFlagSet("trace", flag.ExitOnError)
		hopsStr := fs.String("hops", "0", "tier hop count")
		_ = fs.Parse(os.Args[2:])
		n, err := strconv.ParseUint(*hopsStr, 10, 32)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		fmt.Println(scope_g.FormatTrace(uint32(n)))
	default:
		fmt.Fprintln(os.Stderr, "unknown subcommand")
		os.Exit(2)
	}
}
