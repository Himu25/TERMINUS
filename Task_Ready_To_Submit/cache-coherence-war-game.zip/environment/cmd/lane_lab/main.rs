use std::env;
use std::fs;
use std::path::PathBuf;

use lane_driver::{load_cluster, run_bundle};

fn read_stems(path: &PathBuf) -> Vec<String> {
    let raw = fs::read_to_string(path).expect("scenario index");
    raw.lines()
        .map(str::trim)
        .filter(|line| !line.is_empty() && !line.starts_with('#'))
        .map(str::to_string)
        .collect()
}

fn main() {
    let cluster_path = PathBuf::from("/app/data/active/cluster.json");
    let cluster = load_cluster(&cluster_path);
    let mut names = vec![
        "case_read_through".to_string(),
        "case_write_bump".to_string(),
        "case_l1_hit".to_string(),
        "case_restore_fresh".to_string(),
        "case_prop_trace".to_string(),
        "case_shard_fill".to_string(),
        "case_peak_fanout".to_string(),
    ];
    if env::var("TB_WAR_FIXTURE").ok().as_deref() == Some("1") {
        let stems = read_stems(&PathBuf::from("/app/docs/scenario_index.txt"));
        names.extend(stems);
    }
    names.sort();
    names.dedup();

    let report = run_bundle(&cluster, &names);
    fs::create_dir_all("/app/output").expect("output dir");
    let encoded = serde_json::to_string_pretty(&report).expect("encode report");
    fs::write("/app/output/coherence_report.json", encoded).expect("write report");
}
