use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct TierHop {
    pub tier: String,
    pub slot: String,
    pub rev: u32,
}

#[derive(Clone, Debug)]
pub struct SlotProbe {
    pub slot: String,
    pub rev: u32,
    pub lineage: u32,
    pub shard_hint: u32,
}

impl SlotProbe {
    pub fn mk(slot: &str, rev: u32, lineage: u32, shard_hint: u32) -> Self {
        Self {
            slot: slot.to_string(),
            rev,
            lineage,
            shard_hint,
        }
    }
}

#[derive(Clone, Debug)]
pub struct PropLane {
    pub hops: Vec<TierHop>,
    pub link_gen: u32,
    pub shard_hint: u32,
}

impl PropLane {
    pub fn from_probe(p: &SlotProbe) -> Self {
        Self {
            hops: vec![TierHop {
                tier: "l1".into(),
                slot: p.slot.clone(),
                rev: p.rev,
            }],
            link_gen: p.lineage,
            shard_hint: p.shard_hint,
        }
    }
}
