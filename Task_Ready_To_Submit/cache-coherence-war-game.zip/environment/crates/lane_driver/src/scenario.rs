use std::path::Path;
use std::process::Command;

use op_e::OpE;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use tier_core::SlotProbe;

#[derive(Debug, Clone, Deserialize)]
pub struct Cluster {
    pub cluster_id: String,
    pub shard_count: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScenarioRow {
    pub name: String,
    pub finish_reason: String,
    pub propagation_hops: u32,
    pub violations_found: u32,
    pub violations_fixed: u32,
    pub cascade_depth: u32,
    pub stale_reads: u32,
    pub races_observed: u32,
    pub digest_hex: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Report {
    pub schema_version: u32,
    pub cluster_id: String,
    pub scenarios: Vec<ScenarioRow>,
}

pub fn load_cluster(path: &Path) -> Cluster {
    let raw = std::fs::read_to_string(path).expect("cluster json");
    serde_json::from_str(&raw).expect("cluster parse")
}

pub fn digest_row(row: &ScenarioRow) -> String {
    let payload = format!(
        "{}|{}|{}|{}|{}|{}|{}|{}|",
        row.name,
        row.finish_reason,
        row.propagation_hops,
        row.violations_found,
        row.violations_fixed,
        row.cascade_depth,
        row.stale_reads,
        row.races_observed,
    );
    format!("{:x}", Sha256::digest(payload.as_bytes()))
}

fn seal(mut row: ScenarioRow) -> ScenarioRow {
    row.digest_hex = digest_row(&row);
    row
}

fn go_trace(hops: u32) -> bool {
    let expect = match hops {
        1 => "l1",
        2 => "l1->l2",
        3 => "l1->l2->src",
        _ => return false,
    };
    let out = Command::new("/app/bin/warctl")
        .args(["trace", "--hops", &hops.to_string()])
        .output()
        .expect("warctl trace");
    let got = String::from_utf8_lossy(&out.stdout).trim().to_string();
    got == expect
}

pub fn run_read_through(_cluster: &Cluster) -> ScenarioRow {
    let hub = OpE::mk();
    let p = SlotProbe::mk("alpha", 0, 1, 1);
    let out = hub.cold_pull(&p, "A0", 0);
    let ok = out.hops == 3 && out.value == "A0" && !out.stale;
    seal(ScenarioRow {
        name: "case_read_through".into(),
        finish_reason: if ok { "complete" } else { "stuck" }.into(),
        propagation_hops: out.hops,
        violations_found: 0,
        violations_fixed: 0,
        cascade_depth: 0,
        stale_reads: if out.stale { 1 } else { 0 },
        races_observed: 0,
        digest_hex: String::new(),
    })
}

pub fn run_write_bump(_cluster: &Cluster) -> ScenarioRow {
    let hub = OpE::mk();
    let p0 = SlotProbe::mk("beta", 0, 1, 1);
    let _ = hub.cold_pull(&p0, "B0", 0);
    let p1 = SlotProbe::mk("beta", 1, 1, 1);
    let wrote = hub.commit_write(&p1, "B1");
    hub.evict_a("beta");
    let out = hub.warm_pull(&p1, "B1", 1);
    let fixed = out.value == "B1" && wrote >= 1 && !out.stale;
    seal(ScenarioRow {
        name: "case_write_bump".into(),
        finish_reason: if fixed { "complete" } else { "stuck" }.into(),
        propagation_hops: out.hops,
        violations_found: if fixed { 0 } else { 1 },
        violations_fixed: if fixed { 1 } else { 0 },
        cascade_depth: 0,
        stale_reads: if out.value != "B1" { 1 } else { 0 },
        races_observed: 0,
        digest_hex: String::new(),
    })
}

pub fn run_l1_hit(_cluster: &Cluster) -> ScenarioRow {
    let hub = OpE::mk();
    let p = SlotProbe::mk("gamma", 0, 1, 1);
    let _ = hub.cold_pull(&p, "G0", 0);
    let out = hub.warm_pull(&p, "G0", 0);
    let ok = out.hops == 1;
    seal(ScenarioRow {
        name: "case_l1_hit".into(),
        finish_reason: if ok { "complete" } else { "partial" }.into(),
        propagation_hops: out.hops,
        violations_found: 0,
        violations_fixed: 0,
        cascade_depth: 0,
        stale_reads: 0,
        races_observed: 0,
        digest_hex: String::new(),
    })
}

pub fn run_restore_fresh(_cluster: &Cluster) -> ScenarioRow {
    let hub = OpE::mk();
    let p0 = SlotProbe::mk("kappa", 0, 1, 1);
    let _ = hub.cold_pull(&p0, "K0", 0);
    let p1 = SlotProbe::mk("kappa", 1, 2, 1);
    hub.commit_write(&p1, "K1");
    hub.evict_a("kappa");
    let out = hub.warm_pull(&p1, "K1", 1);
    let clean = out.value == "K1" && !out.stale;
    seal(ScenarioRow {
        name: "case_restore_fresh".into(),
        finish_reason: if clean { "complete" } else { "stale" }.into(),
        propagation_hops: out.hops,
        violations_found: if clean { 0 } else { 1 },
        violations_fixed: if clean { 1 } else { 0 },
        cascade_depth: 0,
        stale_reads: if clean { 0 } else { 1 },
        races_observed: 0,
        digest_hex: String::new(),
    })
}

pub fn run_prop_trace(_cluster: &Cluster) -> ScenarioRow {
    let hub = OpE::mk();
    let p = SlotProbe::mk("trace", 0, 1, 1);
    let out = hub.cold_pull(&p, "T0", 0);
    let trace_ok = go_trace(out.hops);
    seal(ScenarioRow {
        name: "case_prop_trace".into(),
        finish_reason: if trace_ok { "complete" } else { "drift" }.into(),
        propagation_hops: out.hops,
        violations_found: if trace_ok { 0 } else { 1 },
        violations_fixed: if trace_ok { 1 } else { 0 },
        cascade_depth: 0,
        stale_reads: 0,
        races_observed: 0,
        digest_hex: String::new(),
    })
}

pub fn run_shard_fill(_cluster: &Cluster) -> ScenarioRow {
    let hub = OpE::mk();
    let p = SlotProbe::mk("shard", 0, 1, 1);
    hub.prime_b(&p, "S0");
    let out = hub.cold_pull(&p, "S0", 0);
    let ok = out.hops == 2 && out.value == "S0";
    seal(ScenarioRow {
        name: "case_shard_fill".into(),
        finish_reason: if ok { "complete" } else { "partial" }.into(),
        propagation_hops: out.hops,
        violations_found: 0,
        violations_fixed: 0,
        cascade_depth: 0,
        stale_reads: if out.stale { 1 } else { 0 },
        races_observed: 0,
        digest_hex: String::new(),
    })
}

pub fn run_cascade_inv(_cluster: &Cluster) -> ScenarioRow {
    let hub = OpE::mk();
    let child_a = SlotProbe::mk("item:foo:bar", 0, 1, 1);
    let child_b = SlotProbe::mk("item:foo:baz", 0, 1, 1);
    hub.prime_b(&child_a, "ca");
    hub.prime_b(&child_b, "cb");
    let depth = hub.cascade_drop("item:foo");
    let a_left = hub.cold_pull(&child_a, "ca2", 1).value == "ca";
    let b_left = hub.cold_pull(&child_b, "cb2", 1).value == "cb";
    let clean = depth >= 2 && !a_left && !b_left;
    seal(ScenarioRow {
        name: "case_cascade_inv".into(),
        finish_reason: if clean { "complete" } else { "stuck" }.into(),
        propagation_hops: 0,
        violations_found: if clean { 0 } else { 1 },
        violations_fixed: if clean { 1 } else { 0 },
        cascade_depth: depth,
        stale_reads: 0,
        races_observed: 0,
        digest_hex: String::new(),
    })
}

pub fn run_race_interleave(_cluster: &Cluster) -> ScenarioRow {
    let hub = OpE::mk();
    hub.begin_epoch();
    let stale_p = SlotProbe::mk("race:a", 0, 1, 1);
    let _ = hub.cold_pull(&stale_p, "R0", 0);
    hub.hold_slots(&["race:a"]);
    hub.begin_epoch();
    let fresh_p = SlotProbe::mk("race:b", 0, 1, 1);
    let out = hub.cold_pull(&fresh_p, "R1", 0);
    let stash = hub.read_hold();
    let handled = stash.is_empty() && out.value == "R1";
    seal(ScenarioRow {
        name: "case_race_interleave".into(),
        finish_reason: if handled { "complete" } else { "stuck" }.into(),
        propagation_hops: out.hops,
        violations_found: if handled { 0 } else { 1 },
        violations_fixed: if handled { 1 } else { 0 },
        cascade_depth: 0,
        stale_reads: 0,
        races_observed: if handled { 0 } else { 1 },
        digest_hex: String::new(),
    })
}

pub fn run_multi_rev_cache(_cluster: &Cluster) -> ScenarioRow {
    let hub = OpE::mk();
    let p0 = SlotProbe::mk("epsilon", 0, 1, 1);
    let p1 = SlotProbe::mk("epsilon", 1, 1, 1);
    hub.prime_b(&p0, "E0");
    hub.prime_b(&p1, "E1");
    let out0 = hub.warm_pull(&p0, "E0", 0);
    let out1 = hub.warm_pull(&p1, "E1", 1);
    let ok = out0.value == "E0"
        && out1.value == "E1"
        && out0.hops == 2
        && out1.hops == 2
        && !out0.stale
        && !out1.stale;
    seal(ScenarioRow {
        name: "case_multi_rev_cache".into(),
        finish_reason: if ok { "complete" } else { "stuck" }.into(),
        propagation_hops: out0.hops.max(out1.hops),
        violations_found: if ok { 0 } else { 1 },
        violations_fixed: if ok { 1 } else { 0 },
        cascade_depth: 0,
        stale_reads: if ok { 0 } else { 1 },
        races_observed: 0,
        digest_hex: String::new(),
    })
}

pub fn run_stale_replica(_cluster: &Cluster) -> ScenarioRow {
    let hub = OpE::mk();
    let p0 = SlotProbe::mk("delta", 0, 1, 1);
    let _ = hub.cold_pull(&p0, "D0", 0);
    hub.pulse_rev(1);
    let p1 = SlotProbe::mk("delta", 1, 1, 1);
    let out = hub.warm_pull(&p1, "D1", 1);
    let fresh = out.value == "D1" && !out.stale;
    seal(ScenarioRow {
        name: "case_stale_replica".into(),
        finish_reason: if fresh { "complete" } else { "stuck" }.into(),
        propagation_hops: out.hops,
        violations_found: if fresh { 0 } else { 1 },
        violations_fixed: if fresh { 1 } else { 0 },
        cascade_depth: 0,
        stale_reads: if fresh { 0 } else { 1 },
        races_observed: 0,
        digest_hex: String::new(),
    })
}

pub fn run_peak_fanout(cluster: &Cluster) -> ScenarioRow {
    let hub = OpE::mk();
    let count = cluster.shard_count.max(4);
    let mut max_hops = 0u32;
    let mut stale_total = 0u32;
    for i in 0..count {
        let slot = format!("fan:{i}");
        let p = SlotProbe::mk(&slot, 0, 1, 1);
        let out = hub.cold_pull(&p, "F0", 0);
        max_hops = max_hops.max(out.hops);
        if out.stale {
            stale_total += 1;
        }
    }
    let clean = stale_total == 0 && max_hops == 3;
    seal(ScenarioRow {
        name: "case_peak_fanout".into(),
        finish_reason: if clean { "complete" } else { "partial" }.into(),
        propagation_hops: max_hops,
        violations_found: stale_total,
        violations_fixed: 0,
        cascade_depth: 0,
        stale_reads: stale_total,
        races_observed: 0,
        digest_hex: String::new(),
    })
}

pub fn run_named(name: &str, cluster: &Cluster) -> ScenarioRow {
    match name {
        "case_read_through" => run_read_through(cluster),
        "case_write_bump" => run_write_bump(cluster),
        "case_l1_hit" => run_l1_hit(cluster),
        "case_restore_fresh" => run_restore_fresh(cluster),
        "case_prop_trace" => run_prop_trace(cluster),
        "case_shard_fill" => run_shard_fill(cluster),
        "case_peak_fanout" => run_peak_fanout(cluster),
        "case_cascade_inv" => run_cascade_inv(cluster),
        "case_race_interleave" => run_race_interleave(cluster),
        "case_multi_rev_cache" => run_multi_rev_cache(cluster),
        "case_stale_replica" => run_stale_replica(cluster),
        other => seal(ScenarioRow {
            name: other.into(),
            finish_reason: "unknown".into(),
            propagation_hops: 0,
            violations_found: 0,
            violations_fixed: 0,
            cascade_depth: 0,
            stale_reads: 0,
            races_observed: 0,
            digest_hex: String::new(),
        }),
    }
}

pub fn run_bundle(cluster: &Cluster, names: &[String]) -> Report {
    let scenarios = names.iter().map(|n| run_named(n, cluster)).collect();
    Report {
        schema_version: 2,
        cluster_id: cluster.cluster_id.clone(),
        scenarios,
    }
}
