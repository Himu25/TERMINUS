"""Verifier for feature store forensic manifest emission."""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

APP = Path("/app")
REPORT = APP / "output" / "feature_forensic.json"
DRIVE_TIMEOUT_SEC = 15


def _stem_tag(stem: str) -> str:
    bundle = json.loads((APP / "packs" / f"{stem}.json").read_text(encoding="utf-8"))
    return str(bundle["scenario_label"])


def _drive(stem: str) -> dict:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    if REPORT.exists():
        REPORT.unlink()
    subprocess.run(
        ["/app/bin/featurerecon"],
        cwd=str(APP),
        env={**os.environ, "tb_feat_pack": stem},
        check=True,
        timeout=DRIVE_TIMEOUT_SEC,
    )
    payload = json.loads(REPORT.read_text(encoding="utf-8"))
    assert "scenario_runs" in payload and len(payload["scenario_runs"]) == 1
    row = payload["scenario_runs"][0]
    assert row.get("scenario_tag") == _stem_tag(stem)
    return row


def _assert_row(
    row: dict,
    *,
    snapshot_materialized: int,
    stream_merged: int,
    cache_stale_blocked: int,
    snapshot_clean: int,
    entity_drift: int,
    replay_collapsed: int,
    export_blocked: int = 0,
) -> None:
    assert row["snapshot_materialized"] == snapshot_materialized
    assert row["stream_merged"] == stream_merged
    assert row["cache_stale_blocked"] == cache_stale_blocked
    assert row["snapshot_clean"] == snapshot_clean
    assert row["entity_drift"] == entity_drift
    assert row["replay_collapsed"] == replay_collapsed
    assert row["export_blocked"] == export_blocked


# Per-pack replay bands: tight enough that unfixed bench output fails, wide
# enough that a mostly-correct rebuild can land within ~1-3/10 agent trials.
def _assert_row_banded(
    row: dict,
    *,
    snapshot_materialized: int | None = None,
    snapshot_materialized_min: int | None = None,
    snapshot_materialized_max: int | None = None,
    stream_merged_min: int,
    stream_merged_max: int | None = None,
    cache_stale_blocked: int = 0,
    snapshot_clean: int = 1,
    entity_drift_min: int | None = None,
    entity_drift_max: int = 0,
    replay_collapsed_min: int = 0,
    replay_collapsed_max: int | None = None,
    export_blocked: int = 0,
) -> None:
    if snapshot_materialized is not None:
        assert row["snapshot_materialized"] == snapshot_materialized
    else:
        lo = 0 if snapshot_materialized_min is None else snapshot_materialized_min
        hi = row["snapshot_materialized"] if snapshot_materialized_max is None else snapshot_materialized_max
        assert lo <= row["snapshot_materialized"] <= hi
    assert row["stream_merged"] >= stream_merged_min
    if stream_merged_max is not None:
        assert row["stream_merged"] <= stream_merged_max
    assert row["cache_stale_blocked"] == cache_stale_blocked
    assert row["snapshot_clean"] == snapshot_clean
    if entity_drift_min is not None:
        assert row["entity_drift"] >= entity_drift_min
    assert row["entity_drift"] <= entity_drift_max
    assert row["replay_collapsed"] >= replay_collapsed_min
    if replay_collapsed_max is not None:
        assert row["replay_collapsed"] <= replay_collapsed_max
    assert row["export_blocked"] == export_blocked



def test_feat_alpha() -> None:
    """Delayed WRITE rows on the same epoch must follow sequence order, not ingest time."""
    row = _drive("feat_alpha")
    _assert_row(
        row,
        snapshot_materialized=2,
        stream_merged=1,
        cache_stale_blocked=0,
        snapshot_clean=1,
        entity_drift=0,
        replay_collapsed=0,
    )


def test_feat_beta() -> None:
    """Contradictory summaries on one epoch resolve to the higher sequence winner."""
    row = _drive("feat_beta")
    _assert_row_banded(
        row,
        snapshot_materialized=2,
        stream_merged_min=2,
        entity_drift_max=1,
    )


def test_feat_canyon() -> None:
    """CACHE_FENCE on one slot leaves a sibling slot free to reach its canonical summary."""
    row = _drive("feat_canyon")
    _assert_row_banded(
        row,
        snapshot_materialized_min=1,
        stream_merged_min=0,
        entity_drift_min=1,
        entity_drift_max=2,
    )


def test_feat_delta() -> None:
    """A CACHE_FENCE row for one slot must not block WRITE rows on another slot."""
    row = _drive("feat_delta")
    _assert_row_banded(
        row,
        snapshot_materialized_min=1,
        stream_merged_min=0,
        entity_drift_min=1,
        entity_drift_max=2,
    )


def test_feat_echo() -> None:
    """Duplicate deliveries with the same sequence on different keys must not collapse."""
    row = _drive("feat_echo")
    _assert_row(
        row,
        snapshot_materialized=2,
        stream_merged=0,
        cache_stale_blocked=0,
        snapshot_clean=1,
        entity_drift=0,
        replay_collapsed=1,
    )


def test_feat_frost() -> None:
    """SNAPSHOT_RESTORE must restore the snapshot epoch without drift from the canonical summary."""
    row = _drive("feat_frost")
    _assert_row(
        row,
        snapshot_materialized=1,
        stream_merged=0,
        cache_stale_blocked=0,
        snapshot_clean=1,
        entity_drift=0,
        replay_collapsed=0,
    )


def test_feat_gamma() -> None:
    """Two WRITE rows on one epoch keep the later sequence value."""
    row = _drive("feat_gamma")
    _assert_row(
        row,
        snapshot_materialized=1,
        stream_merged=1,
        cache_stale_blocked=0,
        snapshot_clean=1,
        entity_drift=0,
        replay_collapsed=0,
    )


def test_feat_haze() -> None:
    """Out-of-order ingest timestamps still merge to sequence-ordered heads."""
    row = _drive("feat_haze")
    _assert_row_banded(
        row,
        snapshot_materialized=3,
        stream_merged_min=1,
        entity_drift_max=1,
    )


def test_feat_iron() -> None:
    """Multiple conflicting summaries resolve through sequence precedence without drift."""
    row = _drive("feat_iron")
    _assert_row_banded(
        row,
        snapshot_materialized=2,
        stream_merged_min=3,
        entity_drift_max=1,
    )


def test_feat_jade() -> None:
    """Shared sequence numbers across keys remain independent after replay dedupe."""
    row = _drive("feat_jade")
    _assert_row(
        row,
        snapshot_materialized=2,
        stream_merged=2,
        cache_stale_blocked=0,
        snapshot_clean=1,
        entity_drift=0,
        replay_collapsed=0,
    )


def test_feat_kite() -> None:
    """Per-slot CACHE_FENCE rows block only the disputed slot."""
    row = _drive("feat_kite")
    _assert_row_banded(
        row,
        snapshot_materialized_min=1,
        stream_merged_min=0,
        entity_drift_min=1,
        entity_drift_max=2,
    )


def test_feat_loom() -> None:
    """Late high-sequence WRITE rows win over early low-sequence summaries on one epoch."""
    row = _drive("feat_loom")
    _assert_row_banded(
        row,
        snapshot_materialized=2,
        stream_merged_min=2,
        entity_drift_max=1,
    )


def test_feat_mist() -> None:
    """Replay dedupe must not drop independent keys sharing a sequence number."""
    row = _drive("feat_mist")
    _assert_row(
        row,
        snapshot_materialized=2,
        stream_merged=1,
        cache_stale_blocked=0,
        snapshot_clean=1,
        entity_drift=0,
        replay_collapsed=1,
    )


def test_feat_nova() -> None:
    """SNAPSHOT_RESTORE on one slot while another slot keeps its WRITE summary."""
    row = _drive("feat_nova")
    _assert_row(
        row,
        snapshot_materialized=2,
        stream_merged=1,
        cache_stale_blocked=0,
        snapshot_clean=1,
        entity_drift=0,
        replay_collapsed=0,
    )


def test_feat_ozone() -> None:
    """Lower-sequence shadow summaries cannot replace a higher-sequence prime summary."""
    row = _drive("feat_ozone")
    _assert_row_banded(
        row,
        snapshot_materialized=2,
        stream_merged_min=2,
        entity_drift_max=1,
    )


def test_feat_peak() -> None:
    """Composite pack mixes dedupe, conflict resolution, and canonical alignment."""
    row = _drive("feat_peak")
    _assert_row_banded(
        row,
        snapshot_materialized=2,
        stream_merged_min=2,
        entity_drift_max=1,
        replay_collapsed_min=0,
        replay_collapsed_max=1,
    )


def test_feat_stale() -> None:
    """After snapshot restore, sub-head sequence writes count as stale blocks."""
    row = _drive("feat_stale")
    _assert_row(
        row,
        snapshot_materialized=1,
        stream_merged=1,
        cache_stale_blocked=1,
        snapshot_clean=1,
        entity_drift=0,
        replay_collapsed=0,
    )


def test_feat_ring() -> None:
    """A LINK row that closes a parent cycle must be rejected and counted in export_blocked."""
    row = _drive("feat_ring")
    _assert_row(
        row,
        snapshot_materialized=1,
        stream_merged=0,
        cache_stale_blocked=0,
        snapshot_clean=1,
        entity_drift=0,
        replay_collapsed=0,
        export_blocked=1,
    )
