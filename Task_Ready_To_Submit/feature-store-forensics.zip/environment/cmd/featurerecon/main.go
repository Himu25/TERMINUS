// featurerecon replays feature-store entity packs and emits forensic manifests.
//
// Invoke with tb_feat_pack set to a stem under /app/packs.
// Output /app/output/feature_forensic.json carries:
//   scenario_runs — exactly one row per invocation.
//
// Each row includes:
//   scenario_tag,
//   snapshot_materialized,
//   stream_merged,
//   cache_stale_blocked,
//   snapshot_clean,
//   entity_drift,
//   replay_collapsed,
//   export_blocked.
//
// Counter semantics are documented in /app/docs/contract.md.
// Identical tb_feat_pack replays emit byte-identical output.
package main

import (
	"os"

	"featbench/internal/runner"
)

func main() {
	os.Exit(runner.MainExit())
}
