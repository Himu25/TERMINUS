module featbench

go 1.22
