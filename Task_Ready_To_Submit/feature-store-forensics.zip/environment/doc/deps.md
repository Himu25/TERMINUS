# Dependencies

Go 1.22 and Rust 1.81 build the featurerecon binary with CGO enabled.
