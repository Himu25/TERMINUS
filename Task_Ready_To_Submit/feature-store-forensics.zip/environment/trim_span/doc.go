// Package trim_span prepares checkpoint rows for the meter pass.
package trim_span
