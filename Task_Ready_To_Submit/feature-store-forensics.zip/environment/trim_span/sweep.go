package trim_span

import "featbench/eventwire"

// SweepSpan tags rollback rows before the seal pass consumes them.
func SweepSpan(rows []eventwire.StreamRow, _ map[string]map[string]eventwire.SnapCell) []eventwire.StreamRow {
	out := make([]eventwire.StreamRow, len(rows))
	copy(out, rows)
	return out
}
