// Package runner drives one scenario pack through the feature reconcile pipeline.
package runner
