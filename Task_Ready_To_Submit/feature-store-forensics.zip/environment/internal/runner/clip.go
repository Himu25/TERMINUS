package runner

import (
	"featbench/eventwire"
	"featbench/clip_lane"
)

func runClip(rows []eventwire.StreamRow) ([]eventwire.StreamRow, int) {
	return clip_lane.ClipSpan(rows)
}
