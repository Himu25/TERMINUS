package runner

import (
	"featbench/eventwire"
	"featbench/wire_rank"
)

func runOrder(rows []eventwire.StreamRow) []eventwire.StreamRow {
	return wire_rank.OrderSpan(rows)
}
