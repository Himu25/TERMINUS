package runner

import (
	"featbench/eventwire"
	"featbench/trim_span"
)

func runSweep(rows []eventwire.StreamRow, snaps map[string]map[string]eventwire.SnapCell) []eventwire.StreamRow {
	return trim_span.SweepSpan(rows, snaps)
}
