package runner

import (
	"featbench/eventwire"
	"featbench/lane_hold"
)

func runGate(rows []eventwire.StreamRow) []eventwire.StreamRow {
	return lane_hold.FilterSpan(rows)
}
