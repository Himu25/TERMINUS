package runner

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"

	"featbench/eventwire"
)

// PackRun is one scenario row in the manifest JSON.
type PackRun struct {
	ScenarioTag     string `json:"scenario_tag"`
	SnapshotMaterialized   int    `json:"snapshot_materialized"`
	StreamMerged   int    `json:"stream_merged"`
	CacheStaleBlocked    int    `json:"cache_stale_blocked"`
	SnapshotClean int    `json:"snapshot_clean"`
	EntityDrift    int    `json:"entity_drift"`
	ReplayCollapsed int    `json:"replay_collapsed"`
	ExportBlocked    int    `json:"export_blocked"`
}

type packPayload struct {
	ScenarioRuns []PackRun `json:"scenario_runs"`
}

// Run loads one pack via tb_feat_pack and writes /app/output/feature_forensic.json.
func Run() error {
	stem := os.Getenv("tb_feat_pack")
	if stem == "" {
		return errors.New("tb_feat_pack must name a stem under /app/packs")
	}
	emit := "/app/output/feature_forensic.json"
	raw, err := os.ReadFile(filepath.Join("/app", "packs", stem+".json"))
	if err != nil {
		return err
	}
	var bundle eventwire.Bundle
	if err := json.Unmarshal(raw, &bundle); err != nil {
		return err
	}
	trimmed, dup := runClip(bundle.Stream)
	filtered := runGate(trimmed)
	ordered := runOrder(filtered)
	linked, cycleBlocked := runLink(ordered)
	swept := runSweep(linked, bundle.Snapshots)
	view := runSeal(swept, bundle.Canonical, bundle.Snapshots)
	run := PackRun{
		ScenarioTag:     bundle.ScenarioLabel,
		SnapshotMaterialized:   view.SnapshotMaterialized,
		StreamMerged:   view.StreamMerged,
		CacheStaleBlocked:    view.CacheStaleBlocked,
		SnapshotClean: view.SnapshotClean,
		EntityDrift:    view.EntityDrift,
		ReplayCollapsed: dup,
		ExportBlocked:    cycleBlocked,
	}
	out := packPayload{ScenarioRuns: []PackRun{run}}
	if err := os.MkdirAll(filepath.Dir(emit), 0o755); err != nil {
		return err
	}
	buf, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		return err
	}
	tmp := emit + ".tmp"
	if err := os.WriteFile(tmp, buf, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, emit)
}

// MainExit is the cmd entry wrapper.
func MainExit() int {
	if err := Run(); err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		return 1
	}
	return 0
}
