package runner

import (
	"featbench/eventwire"
	"featbench/ref_spin"
)

func runLink(rows []eventwire.StreamRow) ([]eventwire.StreamRow, int) {
	return ref_spin.SpinSpan(rows)
}
