package runner

import (
	"featbench/eventwire"
	"featbench/fold_span"
)

func runSeal(rows []eventwire.StreamRow, canonical map[string]string, snaps map[string]map[string]eventwire.SnapCell) fold_span.Manifest {
	return fold_span.MeterSpan(rows, canonical, snaps)
}
