# Feature store forensic worker

Mixed Go and Rust pipeline that replays feature store entity packs from `/app/packs` and emits forensic manifests under `/app/output`.
