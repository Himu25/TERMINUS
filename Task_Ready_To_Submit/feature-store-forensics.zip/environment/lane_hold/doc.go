// Package lane_hold applies reviewer hold rows before human merge.
package lane_hold
