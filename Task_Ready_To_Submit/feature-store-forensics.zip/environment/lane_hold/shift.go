package lane_hold

import "featbench/eventwire"

// FilterSpan applies CACHE_FENCE rows before WRITE summaries merge.
func FilterSpan(rows []eventwire.StreamRow) []eventwire.StreamRow {
	out := make([]eventwire.StreamRow, 0, len(rows))
	frozen := false
	for idx := range rows {
		r := rows[idx]
		if r.Lane == "CACHE_FENCE" && r.Sentinel {
			frozen = true
			out = append(out, r)
			continue
		}
		if frozen && r.Lane == "WRITE" {
			continue
		}
		out = append(out, r)
	}
	return out
}
