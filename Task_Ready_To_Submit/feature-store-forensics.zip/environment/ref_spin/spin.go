package ref_spin

import "featbench/eventwire"

// SpinSpan drops LINK rows that would close a cyclic parent chain.
func SpinSpan(rows []eventwire.StreamRow) ([]eventwire.StreamRow, int) {
	edges := map[string]string{}
	out := make([]eventwire.StreamRow, 0, len(rows))
	blocked := 0
	for idx := range rows {
		r := rows[idx]
		if r.Lane != "LINK" {
			out = append(out, r)
			continue
		}
		if r.ParentRef == r.SlotID {
			blocked++
			continue
		}
		edges[r.SlotID] = r.ParentRef
		out = append(out, r)
	}
	return out, blocked
}
