// Package ref_spin validates parent pointers between entity slots before merge.
package ref_spin
