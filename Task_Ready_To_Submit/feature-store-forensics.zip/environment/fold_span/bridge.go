package fold_span

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libfold_span.a -ldl -lm
#include "seal_fold.h"
#include <stdlib.h>
*/
import "C"

import (
	"encoding/json"
	"unsafe"

	"featbench/eventwire"
)

// Manifest is one scenario emission row.
type Manifest struct {
	SnapshotMaterialized    int
	StreamMerged int
	CacheStaleBlocked     int
	SnapshotClean    int
	EntityDrift int
}

// MeterSpan folds processed rows into manifest counters.
func MeterSpan(rows []eventwire.StreamRow, canonical map[string]string, snaps map[string]map[string]eventwire.SnapCell) Manifest {
	keepers := make([]*C.char, 0, len(rows)*4+2)
	defer freeAll(keepers)

	cRows := make([]C.vf_row, len(rows))
	for idx := range rows {
		r := rows[idx]
		c := C.CString(r.SlotID)
		l := C.CString(r.Lane)
		m := C.CString(r.Summary)
		keepers = append(keepers, c, l, m)
		cRows[idx] = C.vf_row{
			slot_id: c,
			epoch:     C.int(r.Epoch),
			lane:       l,
			mark:       m,
			seq_no:     C.int(r.SeqNo),
			sentinel:   C.bool(r.Sentinel),
		}
	}
	var rowPtr *C.vf_row
	if len(cRows) > 0 {
		rowPtr = (*C.vf_row)(unsafe.Pointer(&cRows[0]))
	}
	canon := cStr(jsonBlob(canonical), &keepers)
	snap := cStr(snapJSON(snaps), &keepers)
	ct := C.vf_meter_span(rowPtr, C.size_t(len(cRows)), canon, snap)
	return manifestFrom(ct)
}

func jsonBlob(v any) string {
	if v == nil {
		return ""
	}
	buf, err := json.Marshal(v)
	if err != nil {
		return ""
	}
	return string(buf)
}

func snapJSON(snaps map[string]map[string]eventwire.SnapCell) string {
	if len(snaps) == 0 {
		return ""
	}
	return jsonBlob(snaps)
}

func cStr(s string, keepers *[]*C.char) *C.char {
	p := C.CString(s)
	*keepers = append(*keepers, p)
	return p
}

func freeAll(ptrs []*C.char) {
	for _, p := range ptrs {
		C.free(unsafe.Pointer(p))
	}
}

func manifestFrom(ct C.vf_roll) Manifest {
	return Manifest{
		SnapshotMaterialized:    int(ct.snapshot_materialized),
		StreamMerged: int(ct.stream_merged),
		CacheStaleBlocked:     int(ct.cache_stale_blocked),
		SnapshotClean:    int(ct.snapshot_clean),
		EntityDrift: int(ct.entity_drift),
	}
}
