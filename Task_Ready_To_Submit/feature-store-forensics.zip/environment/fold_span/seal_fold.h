#pragma once

#include <stdbool.h>
#include <stddef.h>

typedef struct vf_row {
  const char *slot_id;
  int epoch;
  const char *lane;
  const char *mark;
  int seq_no;
  bool sentinel;
} vf_row;

typedef struct vf_roll {
  int snapshot_materialized;
  int stream_merged;
  int cache_stale_blocked;
  int snapshot_clean;
  int entity_drift;
} vf_roll;

struct vf_roll vf_meter_span(const struct vf_row *rows, size_t count,
                             const char *canon_blob, const char *snap_blob);
