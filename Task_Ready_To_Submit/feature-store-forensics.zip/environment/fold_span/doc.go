// Package fold_span binds the Rust fold static library.
package fold_span
