use std::collections::HashMap;
use std::ffi::CStr;
use std::os::raw::{c_char, c_int};

#[repr(C)]
pub struct VfRow {
    pub slot_id: *const c_char,
    pub epoch: c_int,
    pub lane: *const c_char,
    pub mark: *const c_char,
    pub seq_no: c_int,
    pub sentinel: bool,
}

#[repr(C)]
pub struct VfRoll {
    pub snapshot_materialized: c_int,
    pub stream_merged: c_int,
    pub cache_stale_blocked: c_int,
    pub snapshot_clean: c_int,
    pub entity_drift: c_int,
}

#[derive(Clone)]
struct RowView {
    slot: String,
    epoch: i32,
    lane: String,
    summary: String,
    seq_no: i32,
}

#[derive(Clone)]
struct CellView {
    epoch: i32,
    summary: String,
    seq_no: i32,
}

fn decodeMap(blob: &str) -> HashMap<String, String> {
    if blob.is_empty() {
        return HashMap::new();
    }
    serde_json::from_str(blob).unwrap_or_default()
}

fn decodeCells(blob: &str) -> HashMap<String, HashMap<i32, CellView>> {
    let mut out: HashMap<String, HashMap<i32, CellView>> = HashMap::new();
    if blob.is_empty() {
        return out;
    }
    let v: serde_json::Value = match serde_json::from_str(blob) {
        Ok(x) => x,
        Err(_) => return out,
    };
    let Some(obj) = v.as_object() else {
        return out;
    };
    for (slot, revs) in obj {
        let Some(rev_obj) = revs.as_object() else {
            continue;
        };
        let mut table = HashMap::new();
        for (rev_s, cell) in rev_obj {
            let Ok(epoch) = rev_s.parse::<i32>() else {
                continue;
            };
            let summary = cell
                .get("summary")
                .and_then(|m| m.as_str())
                .unwrap_or("")
                .to_string();
            let seq_no = cell.get("seq_no").and_then(|s| s.as_i64()).unwrap_or(0) as i32;
            table.insert(
                epoch,
                CellView {
                    epoch,
                    summary,
                    seq_no,
                },
            );
        }
        out.insert(slot.clone(), table);
    }
    out
}

fn row_at(raw: &VfRow) -> Option<RowView> {
    unsafe {
        Some(RowView {
            slot: CStr::from_ptr(raw.slot_id).to_str().ok()?.to_string(),
            epoch: raw.epoch,
            lane: CStr::from_ptr(raw.lane).to_str().ok()?.to_string(),
            summary: CStr::from_ptr(raw.mark).to_str().ok()?.to_string(),
            seq_no: raw.seq_no,
        })
    }
}

fn pullCell(
    state: &mut HashMap<String, CellView>,
    cells: &HashMap<String, HashMap<i32, CellView>>,
    slot: &str,
    target_epoch: i32,
) -> i32 {
    if let Some(table) = cells.get(slot) {
        if let Some(cell) = table.get(&target_epoch) {
            state.insert(slot.to_string(), cell.clone());
            return 0;
        }
    }
    if let Some(head) = state.get(slot) {
        if head.epoch >= target_epoch {
            state.remove(slot);
        }
    }
    0
}

fn meter(rows: &[RowView], want: &HashMap<String, String>, cells: &HashMap<String, HashMap<i32, CellView>>) -> VfRoll {
    let mut state: HashMap<String, CellView> = HashMap::new();
    let mut cache_stale_blocked = 0;
    let mut stream_merged = 0;
    let mut checkpoint_violations = 0;

    for r in rows {
        if r.lane == "SNAPSHOT_RESTORE" {
            let prev = state.get(&r.slot).cloned();
            checkpoint_violations += pullCell(&mut state, cells, &r.slot, r.epoch);
            if let (Some(mut head), Some(p)) = (state.get_mut(&r.slot).cloned(), prev) {
                if head.seq_no < p.seq_no {
                    head.seq_no = p.seq_no;
                    state.insert(r.slot.clone(), head);
                }
            }
            continue;
        }
        if r.lane != "WRITE" {
            continue;
        }
        if let Some(h) = state.get(&r.slot) {
            if h.epoch == r.epoch && h.summary != r.summary {
                stream_merged += 1;
            }
        }
        state.insert(
            r.slot.clone(),
            CellView {
                epoch: r.epoch,
                summary: r.summary.clone(),
                seq_no: r.seq_no,
            },
        );
    }

    let mut drift = 0;
    for (key, want_val) in want {
        let got = state.get(key).map(|h| h.summary.as_str()).unwrap_or("");
        if got != want_val.as_str() {
            drift += 1;
        }
    }
    let snapshot_clean = if checkpoint_violations == 0 { 1 } else { 0 };
    VfRoll {
        snapshot_materialized: state.len() as c_int,
        stream_merged,
        cache_stale_blocked,
        snapshot_clean,
        entity_drift: drift,
    }
}

#[no_mangle]
pub extern "C" fn vf_meter_span(
    rows: *const VfRow,
    count: usize,
    canon_blob: *const c_char,
    snap_blob: *const c_char,
) -> VfRoll {
    let read_blob = |ptr: *const c_char| -> String {
        if ptr.is_null() {
            return String::new();
        }
        unsafe {
            CStr::from_ptr(ptr)
                .to_str()
                .unwrap_or("")
                .to_string()
        }
    };
    let want = decodeMap(&read_blob(canon_blob));
    let cells = decodeCells(&read_blob(snap_blob));

    let mut parsed = Vec::with_capacity(count);
    if !rows.is_null() {
        let slice = unsafe { std::slice::from_raw_parts(rows, count) };
        for raw in slice {
            if let Some(v) = row_at(raw) {
                parsed.push(v);
            }
        }
    }
    meter(&parsed, &want, &cells)
}
