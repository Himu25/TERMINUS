// Package wire_rank orders inbound stream rows for merge.
package wire_rank
