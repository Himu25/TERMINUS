# Forensic manifest contract

Each `/app/bin/featurerecon` invocation writes one manifest with `scenario_runs` holding exactly 1 row.

- `scenario_tag` — pack label from the bundle spec.
- `snapshot_materialized` — entities with a committed WRITE feature value after merge.
- `stream_merged` — contradictory WRITE values on the same epoch where the higher sequence wins.
- `cache_stale_blocked` — WRITE rows rejected inside the fold meter because sequence does not advance the slot head, including below a snapshot restore head. Upstream stream filtering (for example CACHE_FENCE hold rows) that drops WRITE rows before metering does not increment this counter.
- `snapshot_clean` — `1` when the final merged state, after every stream row has been applied, has no entity whose committed head epoch sits above its restored snapshot cell; else `0`. A higher-epoch head visible only before a `SNAPSHOT_RESTORE` row is processed does not by itself make this `0` when that restore row replaces it.
- `entity_drift` — entities whose final feature value differs from the pack canonical table.
- WRITE rows apply in non-decreasing `seq_no` order; `recv_ms` is ingest telemetry and must not reorder merge precedence.
- `replay_collapsed` — duplicate stream deliveries removed before ordering.
- `export_blocked` — EXPORT link edges rejected because they would close a cyclic reference chain.
- `CACHE_FENCE` rows stay in the replayed stream and silently halt later WRITE rows for the same `slot_id` only; sibling slot ids keep merging and may still show entity drift while the fenced slot is held back. That hold is separate from fold-meter stale rejection and must not increment `cache_stale_blocked`.
