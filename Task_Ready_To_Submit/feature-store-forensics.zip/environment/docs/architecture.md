# Pipeline layout

Entity packs flow through clip dedupe, wire ordering, per-slot lane holds, ref-spin cycle filtering, trim-span snapshot tagging, and the Rust fold pass. Each stage mutates the in-memory row stream before forensic manifest emission. Per-slot CACHE_FENCE holds drop WRITE rows upstream; the fold meter alone increments `cache_stale_blocked` when a WRITE row's sequence fails to advance the slot head.

Sources include daily snapshot cells, live stream updates, cached feature rows, and training export link edges. The reconcile driver at `/app/bin/featurerecon` reads one pack from `/app/packs` selected by `tb_feat_pack`.
