#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TASK_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

if [ -f "/app/go.mod" ] && [ -d "/app/wire_rank" ]; then
  env_dir="/app"
elif [ -d "$TASK_DIR/environment" ]; then
  env_dir="$TASK_DIR/environment"
elif [ -d "/environment" ] && [ -f "/environment/go.mod" ]; then
  env_dir="/environment"
else
  echo "Could not locate task environment layout." >&2
  exit 1
fi

cd "$SCRIPT_DIR"
patch -p1 --forward -d "$env_dir" <fixes.patch

bash "$env_dir/scripts/build.sh"

if [ ! -x "$env_dir/bin/featurerecon" ]; then
  echo "featurerecon binary missing after rebuild" >&2
  exit 1
fi

for probe in feat_alpha feat_stale feat_echo feat_ring; do
  rm -f "$env_dir/output/feature_forensic.json"
  (
    cd "$env_dir"
    export tb_feat_pack="$probe"
    ./bin/featurerecon >/dev/null
  )
  if [ ! -s "$env_dir/output/feature_forensic.json" ]; then
    echo "probe pack $probe produced no manifest" >&2
    exit 1
  fi
done

echo "Oracle repaired wire ordering, clip scope, lane hold scope, ref cycles, pipeline order, and fold span stale rejection."
