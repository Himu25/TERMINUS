"""Validate /app/output/quota_report.json against quota.toml guardrails."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "quota_report.json"
VESSELS = APP / "data" / "vessels_default.jsonl"
CFG = APP / "config" / "quota.toml"
LANDINGS = APP / "data" / "landings_meter.csv"
CASES = Path(__file__).resolve().parent / "data"
RUN_TIMEOUT = 120

_DEFAULT_VESSELS_TEXT = VESSELS.read_text(encoding="utf-8") if VESSELS.is_file() else ""

REPORT_KEYS = frozenset(
    {
        "status",
        "fleet_tac_kg",
        "catch_allocated_kg",
        "catch_surplus_kg",
        "vessels_total",
        "vessels_cleared",
        "coverage_rate",
        "surplus_ratio",
        "port_violations",
        "rank_inversions",
        "tac_buffer_kg",
        "revenue_score",
        "illegal_catch_flags",
        "delayed_report_count",
        "report_digest",
        "vessels",
    }
)
ROW_KEYS = frozenset(
    {
        "vessel_id",
        "species_band",
        "stock_pressure",
        "quota_kg",
        "catch_kg",
        "surplus_kg",
        "cleared",
        "port_ready",
        "allocation_rank",
        "tac_wave",
        "revenue_score",
        "illegal_flag",
        "late_report",
    }
)


def _load_landings() -> dict[str, int]:
    landings: dict[str, int] = {}
    if not LANDINGS.is_file():
        return landings
    lines = LANDINGS.read_text(encoding="utf-8").splitlines()
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        vessel_id, act_kg = (part.strip() for part in line.split(",", 1))
        landings[vessel_id] = int(act_kg)
    return landings


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "fleet_tac_kg": 12000,
        "min_coverage_rate": 0.75,
        "max_surplus_ratio": 0.35,
        "max_port_violations": 0,
        "max_rank_inversions": 1,
        "min_tac_buffer_kg": 3,
        "min_revenue_score": 2.0,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in ("min_coverage_rate", "max_surplus_ratio", "min_revenue_score"):
            cfg[key] = float(val)
        elif key in (
            "fleet_tac_kg",
            "max_port_violations",
            "max_rank_inversions",
            "min_tac_buffer_kg",
        ):
            cfg[key] = int(float(val))
    return cfg


def _vessel_rows_from_text(text: str) -> list[dict]:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def _vessel_ids_from_text(text: str) -> list[str]:
    return [row["vessel_id"] for row in _vessel_rows_from_text(text)]


def _vessel_map_from_text(text: str) -> dict[str, dict]:
    return {row["vessel_id"]: row for row in _vessel_rows_from_text(text)}


def _assert_vessels_match_input(report: dict, vessels_text: str) -> None:
    expected_ids = _vessel_ids_from_text(vessels_text)
    report_ids = [row["vessel_id"] for row in report["vessels"]]
    assert report["vessels_total"] == len(expected_ids)
    assert len(report_ids) == len(expected_ids)
    assert set(report_ids) == set(expected_ids)


@pytest.fixture(autouse=True)
def restore_default_vessels() -> None:
    yield
    if _DEFAULT_VESSELS_TEXT:
        _atomic_write_text(VESSELS, _DEFAULT_VESSELS_TEXT)


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _swap_fixture(stem: str) -> str:
    src = CASES / f"{stem}.jsonl"
    text = src.read_text(encoding="utf-8")
    _atomic_write_text(VESSELS, text)
    return text


def _expected_digest(report: dict) -> str:
    payload = dict(report)
    payload["report_digest"] = ""
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
        timeout=RUN_TIMEOUT,
    )
    return proc.stdout.split()[0]


def _invoke_default() -> None:
    try:
        proc = subprocess.run(
            ["/app/tools/run_quota"],
            capture_output=True,
            text=True,
            check=False,
            timeout=RUN_TIMEOUT,
        )
    except subprocess.TimeoutExpired as exc:
        raise AssertionError(
            f"run_quota timed out after {RUN_TIMEOUT}s"
        ) from exc
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "quota_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    try:
        _invoke_default()
    except (AssertionError, subprocess.TimeoutExpired):
        # Let individual tests fail; do not abort collection if the binary hangs.
        pass


def test_report_top_level_keys_exact() -> None:
    """Report must expose only the documented top-level keys."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS


def test_vessel_row_schema() -> None:
    """Each vessel row must match the documented per-vessel schema."""
    report = _load_report()
    assert report["vessels"]
    for row in report["vessels"]:
        assert set(row.keys()) == ROW_KEYS
        assert isinstance(row["vessel_id"], str) and row["vessel_id"]
        assert isinstance(row["species_band"], str) and row["species_band"]
        assert isinstance(row["stock_pressure"], int)
        assert row["quota_kg"] >= 0
        assert row["catch_kg"] >= 0
        assert row["surplus_kg"] >= 0
        assert isinstance(row["cleared"], bool)
        assert isinstance(row["port_ready"], bool)
        assert row["allocation_rank"] >= 1
        assert row["tac_wave"] >= 0
        assert row["revenue_score"] >= 0.0
        assert isinstance(row["illegal_flag"], bool)
        assert isinstance(row["late_report"], bool)


def test_passing_run_contract() -> None:
    """Default bundle must finish ok and meet quota.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["fleet_tac_kg"] == cfg["fleet_tac_kg"]
    _assert_vessels_match_input(report, _DEFAULT_VESSELS_TEXT)
    assert report["coverage_rate"] >= cfg["min_coverage_rate"]
    assert report["surplus_ratio"] <= cfg["max_surplus_ratio"]
    assert report["port_violations"] <= cfg["max_port_violations"]
    assert report["rank_inversions"] <= cfg["max_rank_inversions"]
    assert report["tac_buffer_kg"] >= cfg["min_tac_buffer_kg"]
    assert report["revenue_score"] >= cfg["min_revenue_score"]


def test_vessels_total_matches_input_rows() -> None:
    """Report vessel IDs must cover every input JSONL row with no drops or extras."""
    report = _load_report()
    _assert_vessels_match_input(report, _DEFAULT_VESSELS_TEXT)


def test_report_digest_matches_payload() -> None:
    """report_digest must hash the compact pre-digest JSON payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_deterministic_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_dep_rows_finish_in_order() -> None:
    """Port dependency rows must clear only after prerequisites."""
    report = _load_report()
    ranks = {row["vessel_id"]: row["allocation_rank"] for row in report["vessels"]}
    assert ranks["v_dep_root"] < ranks["v_dep_leaf"] < ranks["v_dep_chain"]
    for row in report["vessels"]:
        if row["vessel_id"].startswith("v_dep_") and row["cleared"]:
            assert row["port_ready"] is True, row


def test_prio_hot_ranks_before_cold() -> None:
    """Late revision priority rows must finish before stale low-revision peers."""
    report = _load_report()
    hot = next(r for r in report["vessels"] if r["vessel_id"] == "v_prio_hot")
    cold = next(r for r in report["vessels"] if r["vessel_id"] == "v_prio_cold")
    assert hot["cleared"] is True
    assert cold["cleared"] is True
    assert hot["allocation_rank"] < cold["allocation_rank"], (hot, cold)


def test_landing_accounting_semantics() -> None:
    """Landing drift rows reserve estimates, bill actuals, and record quota minus catch."""
    report = _load_report()
    inputs = _vessel_map_from_text(_DEFAULT_VESSELS_TEXT)
    landings = _load_landings()
    for row in report["vessels"]:
        if not row["vessel_id"].startswith("v_landing_") or not row["cleared"]:
            continue
        spec = inputs[row["vessel_id"]]
        expected_used = landings.get(row["vessel_id"], spec["act_kg"])
        assert row["quota_kg"] == spec["est_kg"]
        assert row["catch_kg"] == expected_used
        assert row["surplus_kg"] == max(0, row["quota_kg"] - row["catch_kg"])


def test_landing_rows_record_waste() -> None:
    """Drift-prone landing rows with inflated reservations must record surplus_kg."""
    report = _load_report()
    landing_rows = [r for r in report["vessels"] if r["vessel_id"].startswith("v_landing_")]
    assert landing_rows
    assert any(r["surplus_kg"] > 0 for r in landing_rows if r["cleared"])


def test_tac_rows_complete() -> None:
    """TAC-wave rows with the v_tac_ prefix must complete under the default bundle."""
    report = _load_report()
    tac_rows = [r for r in report["vessels"] if r["vessel_id"].startswith("v_tac_")]
    assert tac_rows
    assert all(r["cleared"] for r in tac_rows), tac_rows


def test_vessel_rows_respect_intensity() -> None:
    """Stock-zone rows must bill through blended intensity, not raw estimates alone."""
    report = _load_report()
    north = next(r for r in report["vessels"] if r["vessel_id"] == "v_stock_north")
    south = next(r for r in report["vessels"] if r["vessel_id"] == "v_stock_south")
    assert north["cleared"] and south["cleared"]
    assert south["quota_kg"] < north["quota_kg"]
    assert south["catch_kg"] < north["catch_kg"]


def test_late_renew_row_completes() -> None:
    """Delayed TAC-wave row v_late_renew must complete under the default bundle."""
    report = _load_report()
    renew = next(r for r in report["vessels"] if r["vessel_id"] == "v_late_renew")
    assert renew["cleared"] is True
    assert renew["tac_wave"] > 0


def test_illegal_catch_flags_on_default_bundle() -> None:
    """Over-quota v_illegal_ rows must set illegal_flag and increment illegal_catch_flags."""
    report = _load_report()
    illegal_rows = [r for r in report["vessels"] if r["vessel_id"].startswith("v_illegal_")]
    assert illegal_rows
    assert all(r["illegal_flag"] for r in illegal_rows if r["cleared"]), illegal_rows
    assert report["illegal_catch_flags"] >= len([r for r in illegal_rows if r["illegal_flag"]])


def test_delayed_report_count_on_default_bundle() -> None:
    """v_late_ rows with report_revision below stock_pressure must set late_report."""
    report = _load_report()
    late_rows = [r for r in report["vessels"] if r["vessel_id"].startswith("v_late_")]
    assert late_rows
    assert any(r["late_report"] for r in late_rows)
    assert report["delayed_report_count"] >= 1


def test_scenario_dep_chain() -> None:
    """Port-dependency scenario must schedule deps before dependents."""
    vessels_text = _swap_fixture("dep_chain")
    _invoke_default()
    report = _load_report()
    _assert_vessels_match_input(report, vessels_text)
    assert report["port_violations"] == 0
    assert report["status"] == "ok"
    ranks = {row["vessel_id"]: row["allocation_rank"] for row in report["vessels"]}
    assert ranks["v_dep_root"] < ranks["v_dep_leaf"] < ranks["v_dep_chain"]


def test_scenario_urgency_flip() -> None:
    """Revision-flip scenario must schedule late revisions ahead of stale peers."""
    cfg = _parse_cfg()
    vessels_text = _swap_fixture("urgency_flip")
    _invoke_default()
    report = _load_report()
    _assert_vessels_match_input(report, vessels_text)
    hot = next(r for r in report["vessels"] if r["vessel_id"] == "v_prio_hot")
    cold = next(r for r in report["vessels"] if r["vessel_id"] == "v_prio_cold")
    assert hot["allocation_rank"] < cold["allocation_rank"]
    assert report["rank_inversions"] <= cfg["max_rank_inversions"]
    assert report["status"] == "ok"


def test_scenario_est_drift() -> None:
    """Landing-drift scenario must keep surplus_ratio under max_surplus_ratio."""
    cfg = _parse_cfg()
    vessels_text = _swap_fixture("est_drift")
    _invoke_default()
    report = _load_report()
    _assert_vessels_match_input(report, vessels_text)
    inputs = _vessel_map_from_text(vessels_text)
    for row in report["vessels"]:
        if not row["vessel_id"].startswith("v_landing_") or not row["cleared"]:
            continue
        spec = inputs[row["vessel_id"]]
        assert row["quota_kg"] == spec["est_kg"]
        assert row["surplus_kg"] == max(0, row["quota_kg"] - row["catch_kg"])
        assert row["surplus_kg"] > 0
    assert report["surplus_ratio"] <= cfg["max_surplus_ratio"]
    assert report["status"] == "ok"


def test_scenario_tac_cluster() -> None:
    """TAC-cluster scenario must absorb enough buffer headroom."""
    cfg = _parse_cfg()
    vessels_text = _swap_fixture("tac_cluster")
    _invoke_default()
    report = _load_report()
    _assert_vessels_match_input(report, vessels_text)
    tac_rows = [r for r in report["vessels"] if r["vessel_id"].startswith("v_tac_")]
    assert tac_rows
    assert all(r["cleared"] for r in tac_rows)
    assert report["tac_buffer_kg"] >= cfg["min_tac_buffer_kg"]
    assert report["status"] == "ok"


def test_scenario_value_mix() -> None:
    """Price-index mix scenario must meet revenue_score floor."""
    cfg = _parse_cfg()
    vessels_text = _swap_fixture("value_mix")
    _invoke_default()
    report = _load_report()
    _assert_vessels_match_input(report, vessels_text)
    assert report["revenue_score"] >= cfg["min_revenue_score"]


def test_scenario_vessel_meter() -> None:
    """Zero-estimate landing-meter row must bill act_kg through the meter."""
    vessels_text = _swap_fixture("vessel_meter")
    _invoke_default()
    report = _load_report()
    _assert_vessels_match_input(report, vessels_text)
    landings = _load_landings()
    expected_used = landings["v_meter"]
    row = next(r for r in report["vessels"] if r["vessel_id"] == "v_meter")
    assert row["cleared"] is True
    assert row["catch_kg"] == expected_used
    assert row["quota_kg"] >= row["catch_kg"]
    assert row["surplus_kg"] == max(0, row["quota_kg"] - row["catch_kg"])


def test_scenario_stock_mix() -> None:
    """Stock-zone variability scenario must bill south-ridge below north-shelf for similar work."""
    vessels_text = _swap_fixture("stock_mix")
    _invoke_default()
    report = _load_report()
    _assert_vessels_match_input(report, vessels_text)
    north = next(r for r in report["vessels"] if r["vessel_id"] == "v_stock_north")
    south = next(r for r in report["vessels"] if r["vessel_id"] == "v_stock_south")
    assert north["cleared"] and south["cleared"]
    assert south["quota_kg"] < north["quota_kg"]


def test_scenario_late_renew() -> None:
    """Delayed TAC-wave scenario must complete v_late_renew with buffer absorption."""
    cfg = _parse_cfg()
    vessels_text = _swap_fixture("late_renew")
    _invoke_default()
    report = _load_report()
    _assert_vessels_match_input(report, vessels_text)
    renew = next(r for r in report["vessels"] if r["vessel_id"] == "v_late_renew")
    assert renew["cleared"] is True
    assert report["tac_buffer_kg"] >= cfg["min_tac_buffer_kg"]
    assert report["status"] == "ok"


def test_scenario_illegal_mix() -> None:
    """Illegal-catch scenario must flag every over-quota v_illegal_ row."""
    vessels_text = _swap_fixture("illegal_mix")
    _invoke_default()
    report = _load_report()
    _assert_vessels_match_input(report, vessels_text)
    illegal_rows = [r for r in report["vessels"] if r["vessel_id"].startswith("v_illegal_")]
    assert illegal_rows
    assert all(r["illegal_flag"] for r in illegal_rows if r["cleared"])
    assert report["illegal_catch_flags"] >= len(illegal_rows)
    assert report["status"] == "ok"


def test_scenario_late_report() -> None:
    """Delayed-report scenario must count late_report rows and rank hot revision first."""
    vessels_text = _swap_fixture("late_report")
    _invoke_default()
    report = _load_report()
    _assert_vessels_match_input(report, vessels_text)
    late_rows = [r for r in report["vessels"] if r["vessel_id"].startswith("v_late_")]
    assert late_rows
    assert all(r["late_report"] for r in late_rows)
    assert report["delayed_report_count"] >= len(late_rows)
    hot = next(r for r in report["vessels"] if r["vessel_id"] == "v_prio_hot")
    late_ranks = [r["allocation_rank"] for r in late_rows]
    assert hot["allocation_rank"] < min(late_ranks)
    assert report["status"] == "ok"
