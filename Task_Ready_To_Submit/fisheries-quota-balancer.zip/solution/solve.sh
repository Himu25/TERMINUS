#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/Cargo.toml
require_file /app/config/quota.toml
require_file /app/data/vessel_manifest.jsonl
require_file /app/data/stock_profiles.csv
require_file /app/data/landings_meter.csv
mkdir -p /app/bin /app/output

log "apply patched sources"
cp "${ROOT_DIR}/oracle/q9_lib.rs" /app/q9/src/lib.rs
cp "${ROOT_DIR}/oracle/k2_lib.rs" /app/k2/src/lib.rs
cp "${ROOT_DIR}/oracle/h4_lib.rs" /app/h4/src/lib.rs
cp "${ROOT_DIR}/oracle/z1_lib.rs" /app/z1/src/lib.rs
cp "${ROOT_DIR}/oracle/n8_lib.rs" /app/n8/src/lib.rs

log "rebuild quotadisp"
bash /app/scripts/build.sh
rm -rf /app/output/cargo-target

log "refresh default vessel bundle"
/app/bin/vesselpack /app/data/vessel_manifest.jsonl /app/data/vessels_default.jsonl

log "emit default quota report"
/app/tools/run_quota

log "post-run validation against quota.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/quota.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k in ("min_coverage_rate", "max_surplus_ratio", "min_revenue_score"):
        cfg[k] = float(v)
    elif k.startswith("max_") or k.startswith("min_") or k == "fleet_tac_kg":
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/quota_report.json").read_text())
assert report["status"] == "ok", report
assert report["coverage_rate"] >= cfg["min_coverage_rate"]
assert report["surplus_ratio"] <= cfg["max_surplus_ratio"]
assert report["port_violations"] <= cfg["max_port_violations"]
assert report["rank_inversions"] <= cfg["max_rank_inversions"]
assert report["tac_buffer_kg"] >= cfg["min_tac_buffer_kg"]
assert report["revenue_score"] >= cfg["min_revenue_score"]
for row in report["vessels"]:
    if row["vessel_id"].startswith("v_dep_") and row["cleared"]:
        assert row["port_ready"], row
    if row["vessel_id"].startswith("v_tac_"):
        assert row["cleared"], row
    if row["vessel_id"].startswith("v_illegal_") and row["cleared"]:
        assert row["illegal_flag"], row
print("ok", report["coverage_rate"], report["surplus_ratio"], report["revenue_score"])
PY

log "oracle complete"
