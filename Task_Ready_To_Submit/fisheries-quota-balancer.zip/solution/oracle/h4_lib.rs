pub fn ux_absorb(burst_need: i32, headroom: i32) -> i32 {
    if burst_need <= 0 || headroom <= 0 {
        return 0;
    }
    if burst_need > headroom {
        headroom
    } else {
        burst_need
    }
}
