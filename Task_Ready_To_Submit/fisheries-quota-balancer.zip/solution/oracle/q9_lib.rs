mod decoy;

use core_types::VesselCase;

pub fn qx_seq(cases: &[VesselCase]) -> Vec<VesselCase> {
    let mut out = cases.to_vec();
    out.sort_by(|a, b| {
        b.report_revision
            .cmp(&a.report_revision)
            .then(b.stock_pressure.cmp(&a.stock_pressure))
            .then(
                b.price_index
                    .partial_cmp(&a.price_index)
                    .unwrap_or(std::cmp::Ordering::Equal),
            )
            .then(a.vessel_id.cmp(&b.vessel_id))
    });
    out
}
