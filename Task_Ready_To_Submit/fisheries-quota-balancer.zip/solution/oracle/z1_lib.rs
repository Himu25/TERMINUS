pub fn vx_roll(reserved: i32, used: i32) -> i32 {
    if reserved <= used {
        0
    } else {
        reserved - used
    }
}
