pub struct FoldOut {
    pub billable: i32,
    pub drift_flag: i32,
}

fn est_chk(est: i32, act: i32) -> bool {
    if est <= 0 {
        return false;
    }
    let delta = (act - est).abs();
    delta * 100 > est * 15
}

fn effective_scale(peak: i32, renew: i32, renew_after: i32, start: i32, duration: i32) -> i32 {
    let peak = peak.max(1);
    let renew = renew.max(1);
    let after = renew_after.max(0);
    let start = start.max(0);
    let duration = duration.max(1);
    let end = start + duration;
    if end <= after {
        return peak;
    }
    if start >= after {
        return renew;
    }
    let pre = (after - start).max(0);
    let post = duration - pre;
    let blended = (pre * peak + post * renew) / duration;
    blended.max(1)
}

#[allow(clippy::too_many_arguments)]
pub fn span_fold(
    est: i32,
    act: i32,
    overlay: i32,
    peak_scale: i32,
    renew_scale: i32,
    renew_after: i32,
    start_slot: i32,
) -> FoldOut {
    let est_i = est.max(0);
    let act_i = act.max(0);
    let overlay_i = overlay.max(0);
    let duration = if act_i > 0 { act_i } else { est_i.max(1) };
    let scale = effective_scale(peak_scale, renew_scale, renew_after, start_slot, duration);
    let scaled_est = ((est_i as i64) * (scale as i64) / 100).max(1) as i32;
    let scaled_act = if act_i > 0 {
        ((act_i as i64) * (scale as i64) / 100).max(1) as i32
    } else {
        0
    };
    let billable = if overlay_i > 0 && est_chk(scaled_est, scaled_act) {
        scaled_act.max(1)
    } else if scaled_act > 0 {
        scaled_act
    } else {
        scaled_est.max(1)
    };
    let flag = if overlay_i > 0 && est_chk(scaled_est, scaled_act) {
        1
    } else {
        0
    };
    FoldOut {
        billable,
        drift_flag: flag,
    }
}

pub fn meter_span(
    est: i32,
    act: i32,
    overlay: i32,
    peak_scale: i32,
    renew_scale: i32,
    renew_after: i32,
    start_slot: i32,
) -> FoldOut {
    span_fold(
        est,
        act,
        overlay,
        peak_scale,
        renew_scale,
        renew_after,
        start_slot,
    )
}

pub fn meter_batch(estimates: &[i32]) -> i32 {
    estimates.iter().filter(|&&e| e > 0).sum()
}
