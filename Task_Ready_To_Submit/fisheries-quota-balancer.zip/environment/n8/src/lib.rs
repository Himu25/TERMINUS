//! Stock-zone meter: blends peak_scale and renew_scale across start_slot and
//! slot span (duration = act_kg when positive, else max(est_kg, 1)) before
//! scaling est_kg and act_kg into billable kg. See contract.md Stock profile.

pub struct FoldOut {
    pub billable: i32,
    pub drift_flag: i32,
}

fn est_chk(est: i32, act: i32) -> bool {
    if est <= 0 {
        return false;
    }
    let delta = (act - est).abs();
    delta * 100 > est * 15
}

#[allow(clippy::too_many_arguments)]
pub fn span_fold(
    est: i32,
    act: i32,
    overlay: i32,
    peak_scale: i32,
    renew_scale: i32,
    renew_after: i32,
    start_slot: i32,
) -> FoldOut {
    let est_i = est.max(0);
    let act_i = act.max(0);
    let overlay_i = overlay.max(0);
    let _peak = peak_scale.max(1);
    let _renew = renew_scale.max(1);
    let _after = renew_after.max(0);
    let _start = start_slot.max(0);
    let billable = if overlay_i > 0 { est_i } else { est_i.max(act_i) };
    let flag = if overlay_i > 0 && est_chk(est_i, act_i) {
        1
    } else {
        0
    };
    FoldOut {
        billable,
        drift_flag: flag,
    }
}

pub fn meter_span(
    est: i32,
    act: i32,
    overlay: i32,
    peak_scale: i32,
    renew_scale: i32,
    renew_after: i32,
    start_slot: i32,
) -> FoldOut {
    span_fold(
        est,
        act,
        overlay,
        peak_scale,
        renew_scale,
        renew_after,
        start_slot,
    )
}

pub fn meter_batch(estimates: &[i32]) -> i32 {
    estimates.iter().filter(|&&e| e > 0).sum()
}
