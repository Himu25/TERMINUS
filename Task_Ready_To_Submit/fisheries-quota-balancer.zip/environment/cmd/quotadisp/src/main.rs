use std::env;
use std::path::PathBuf;
use std::process;

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() < 3 {
        eprintln!("usage: quotadisp <vessels.jsonl> <out.json>");
        process::exit(2);
    }
    let cfg = dispatch::load_cfg(PathBuf::from("/app/config/quota.toml").as_path())
        .unwrap_or_else(|e| {
            eprintln!("{e}");
            process::exit(1);
        });
    let cases = dispatch::load_vessel_cases(PathBuf::from(&args[1]).as_path()).unwrap_or_else(|e| {
        eprintln!("{e}");
        process::exit(1);
    });
    let landings =
        dispatch::load_landings_meter(PathBuf::from("/app/data/landings_meter.csv").as_path())
            .unwrap_or_else(|e| {
                eprintln!("{e}");
                process::exit(1);
            });
    let profiles = dispatch::load_stock_profiles(
        PathBuf::from("/app/data/stock_profiles.csv").as_path(),
    )
    .unwrap_or_else(|e| {
        eprintln!("{e}");
        process::exit(1);
    });
    let report = dispatch::run(&cfg, &cases, &landings, &profiles);
    dispatch::write_report(PathBuf::from(&args[2]).as_path(), &report).unwrap_or_else(|e| {
        eprintln!("{e}");
        process::exit(1);
    });
}
