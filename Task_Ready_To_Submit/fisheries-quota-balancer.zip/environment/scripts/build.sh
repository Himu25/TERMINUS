#!/bin/bash
set -euo pipefail

export CARGO_TARGET_DIR=/app/output/cargo-target
export CARGO_BUILD_JOBS="${CARGO_BUILD_JOBS:-1}"
mkdir -p /app/bin /app/output/cargo-target

cd /app
cargo build --release --locked -p quotadisp -p vesselpack
cp /app/output/cargo-target/release/quotadisp /app/bin/quotadisp
cp /app/output/cargo-target/release/vesselpack /app/bin/vesselpack
