use h4::ux_absorb;

pub fn wave_tac_total(tac_wave: i32, est_kg: i32, headroom: i32) -> i32 {
    if tac_wave <= 0 {
        return 0;
    }
    ux_absorb(est_kg / 4, headroom)
}
