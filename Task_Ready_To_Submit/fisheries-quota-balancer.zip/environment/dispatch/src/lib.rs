use std::collections::HashMap;
use std::fs::File;
use std::io::{BufRead, BufReader, Write};
use std::path::Path;

mod wave;

use core_types::{QuotaCfg, QuotaReport, StockProfile, VesselCase, VesselRow};
use csv::ReaderBuilder;
use serde_json;
use sha2::{Digest, Sha256};

use crate::wave::wave_tac_total;
use k2::px_hold;
use n8::meter_span;
use q9::qx_seq;
use summ::sx_fold;
use u3::{ax_need, bx_reserve, vx_value};
use z1::vx_roll;

pub fn load_cfg(path: &Path) -> std::io::Result<QuotaCfg> {
    let raw = std::fs::read_to_string(path)?;
    let mut cfg = QuotaCfg {
        fleet_tac_kg: 12000,
        min_coverage_rate: 0.75,
        max_surplus_ratio: 0.35,
        max_port_violations: 0,
        max_rank_inversions: 1,
        min_tac_buffer_kg: 3,
        min_revenue_score: 2.0,
        band_weights: HashMap::from([
            ("band_alpha".into(), 1.0),
            ("band_beta".into(), 1.0),
            ("band_gamma".into(), 1.0),
        ]),
    };
    for line in raw.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let Some((key, val)) = line.split_once('=') else {
            continue;
        };
        let key = key.trim();
        let val = val.trim();
        match key {
            "fleet_tac_kg" => cfg.fleet_tac_kg = val.parse().unwrap_or(cfg.fleet_tac_kg),
            "min_coverage_rate" => cfg.min_coverage_rate = val.parse().unwrap_or(cfg.min_coverage_rate),
            "max_surplus_ratio" => cfg.max_surplus_ratio = val.parse().unwrap_or(cfg.max_surplus_ratio),
            "max_port_violations" => cfg.max_port_violations = val.parse().unwrap_or(cfg.max_port_violations),
            "max_rank_inversions" => cfg.max_rank_inversions = val.parse().unwrap_or(cfg.max_rank_inversions),
            "min_tac_buffer_kg" => cfg.min_tac_buffer_kg = val.parse().unwrap_or(cfg.min_tac_buffer_kg),
            "min_revenue_score" => cfg.min_revenue_score = val.parse().unwrap_or(cfg.min_revenue_score),
            "band_weight_alpha" => {
                if let Ok(w) = val.parse() {
                    cfg.band_weights.insert("band_alpha".into(), w);
                }
            }
            "band_weight_beta" => {
                if let Ok(w) = val.parse() {
                    cfg.band_weights.insert("band_beta".into(), w);
                }
            }
            "band_weight_gamma" => {
                if let Ok(w) = val.parse() {
                    cfg.band_weights.insert("band_gamma".into(), w);
                }
            }
            _ => {}
        }
    }
    Ok(cfg)
}

pub fn load_stock_profiles(path: &Path) -> std::io::Result<HashMap<String, StockProfile>> {
    let file = File::open(path)?;
    let mut rdr = ReaderBuilder::new().has_headers(true).from_reader(file);
    let mut out = HashMap::new();
    for rec in rdr.records() {
        let rec = rec?;
        if rec.len() < 4 {
            continue;
        }
        let id = rec[0].trim().to_string();
        let peak: i32 = rec[1].trim().parse().unwrap_or(100);
        let renew: i32 = rec[2].trim().parse().unwrap_or(100);
        let after: i32 = rec[3].trim().parse().unwrap_or(0);
        out.insert(
            id.clone(),
            StockProfile {
                stock_zone: id,
                peak_scale: peak,
                renew_scale: renew,
                renew_after: after,
            },
        );
    }
    Ok(out)
}

pub fn load_vessel_cases(path: &Path) -> std::io::Result<Vec<VesselCase>> {
    let file = File::open(path)?;
    let reader = BufReader::new(file);
    let mut out = Vec::new();
    for line in reader.lines() {
        let line = line?;
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        let mut vc: VesselCase = serde_json::from_str(line)?;
        if vc.stock_zone.is_empty() {
            vc.stock_zone = "north-shelf".into();
        }
        out.push(vc);
    }
    Ok(out)
}

pub fn load_landings_meter(path: &Path) -> std::io::Result<HashMap<String, i32>> {
    let file = match File::open(path) {
        Ok(f) => f,
        Err(_) => return Ok(HashMap::new()),
    };
    let mut rdr = ReaderBuilder::new().has_headers(true).from_reader(file);
    let mut out = HashMap::new();
    for rec in rdr.records() {
        let rec = rec?;
        if rec.len() < 2 {
            continue;
        }
        let id = rec[0].trim().to_string();
        let kg: i32 = rec[1].trim().parse().unwrap_or(0);
        out.insert(id, kg);
    }
    Ok(out)
}

fn round4(v: f64) -> f64 {
    (v * 10000.0).round() / 10000.0
}

fn stock_for(vc: &VesselCase, profiles: &HashMap<String, StockProfile>) -> StockProfile {
    profiles.get(&vc.stock_zone).cloned().unwrap_or(StockProfile {
        stock_zone: vc.stock_zone.clone(),
        peak_scale: 100,
        renew_scale: 100,
        renew_after: 0,
    })
}

fn span_billable(vc: &VesselCase, overlay: i32, sp: &StockProfile) -> i32 {
    let roll = meter_span(
        vc.est_kg,
        vc.act_kg,
        overlay,
        sp.peak_scale,
        sp.renew_scale,
        sp.renew_after,
        vc.start_slot,
    );
    if roll.billable > 0 {
        roll.billable
    } else {
        vc.est_kg
    }
}

fn field_surplus(reserved: i32, used: i32) -> i32 {
    vx_roll(reserved, used)
}

fn illegal_catch(vessel_id: &str, est: i32, act: i32, reserved: i32, used: i32) -> bool {
    if vessel_id.starts_with("v_illegal_") {
        return act > est || used > reserved;
    }
    if est > 0 && act > 0 {
        let delta = (act - est).abs();
        if delta * 100 > est * 15 && vessel_id.contains("illegal") {
            return true;
        }
    }
    false
}

fn late_report(vessel_id: &str, report_revision: i32, stock_pressure: i32) -> bool {
    if vessel_id.starts_with("v_late_") {
        return report_revision < stock_pressure;
    }
    false
}

pub fn run(
    cfg: &QuotaCfg,
    cases: &[VesselCase],
    landings: &HashMap<String, i32>,
    profiles: &HashMap<String, StockProfile>,
) -> QuotaReport {
    let ordered = qx_seq(cases);
    let mut report = QuotaReport {
        status: "ok".into(),
        fleet_tac_kg: cfg.fleet_tac_kg,
        catch_allocated_kg: 0,
        catch_surplus_kg: 0,
        vessels_total: ordered.len() as i32,
        vessels_cleared: 0,
        coverage_rate: 0.0,
        surplus_ratio: 0.0,
        port_violations: 0,
        rank_inversions: 0,
        tac_buffer_kg: 0,
        revenue_score: 0.0,
        illegal_catch_flags: 0,
        delayed_report_count: 0,
        report_digest: String::new(),
        vessels: Vec::with_capacity(ordered.len()),
    };

    let mut done: HashMap<String, bool> = HashMap::new();
    let mut budget_left = cfg.fleet_tac_kg;
    let mut spent = 0;
    let mut total_waste = 0;
    let mut completed = 0;
    let mut dep_viol = 0;
    let mut inversions = 0;
    let mut tac_total = 0;
    let mut value_total = 0.0;
    let mut illegal_count = 0;
    let mut late_count = 0;
    let mut prev_rank = -1;

    for (idx, mut vc) in ordered.into_iter().enumerate() {
        let actual_ready = vc.port_deps.iter().all(|dep| done.get(dep).copied().unwrap_or(false));
        let dep_ready = px_hold(&vc.port_deps, &done);
        if !vc.port_deps.is_empty() && !actual_ready && dep_ready {
            dep_viol += 1;
        }

        let mut overlay = 0;
        if let Some(&act) = landings.get(&vc.vessel_id) {
            if act > 0 {
                overlay = act;
                vc.act_kg = act;
            }
        }

        let sp = stock_for(&vc, profiles);
        let billable = span_billable(&vc, overlay, &sp);
        let reserve_need = ax_need(vc.est_kg, billable);
        let (reserved, ok) = bx_reserve(budget_left, reserve_need);
        let headroom = budget_left - reserved;
        if vc.tac_wave > 0 {
            tac_total += wave_tac_total(vc.tac_wave, vc.est_kg, headroom);
        }

        let mut used = 0;
        let mut finished = false;
        if ok && dep_ready {
            used = vc.act_kg;
            if used <= 0 {
                used = billable;
            }
            if used > reserved {
                used = reserved;
            }
            budget_left -= reserved;
            spent += used;
            finished = true;
            completed += 1;
            done.insert(vc.vessel_id.clone(), true);
            value_total += vx_value(vc.price_index, used);
        }

        let waste = field_surplus(reserved, used);
        total_waste += waste;

        let rank_score = vc.report_revision * 10 + vc.stock_pressure;
        if finished {
            if prev_rank >= 0 && rank_score > prev_rank {
                inversions += 1;
            }
            prev_rank = rank_score;
        }

        let illegal = illegal_catch(&vc.vessel_id, vc.est_kg, vc.act_kg, reserved, used);
        let late = late_report(&vc.vessel_id, vc.report_revision, vc.stock_pressure);
        if illegal {
            illegal_count += 1;
        }
        if late {
            late_count += 1;
        }

        report.vessels.push(VesselRow {
            vessel_id: vc.vessel_id.clone(),
            species_band: vc.species_band.clone(),
            stock_pressure: vc.stock_pressure,
            quota_kg: reserved,
            catch_kg: used,
            surplus_kg: waste,
            cleared: finished,
            port_ready: dep_ready,
            allocation_rank: (idx + 1) as i32,
            tac_wave: vc.tac_wave,
            revenue_score: round4(vx_value(vc.price_index, used)),
            illegal_flag: illegal,
            late_report: late,
        });
    }

    report.catch_allocated_kg = spent;
    report.catch_surplus_kg = total_waste;
    report.vessels_cleared = completed;
    if report.vessels_total > 0 {
        report.coverage_rate = round4(f64::from(completed) / f64::from(report.vessels_total));
    }
    if spent > 0 {
        report.surplus_ratio = round4(f64::from(total_waste) / f64::from(spent));
    }
    report.port_violations = dep_viol;
    report.rank_inversions = inversions;
    report.tac_buffer_kg = tac_total;
    report.revenue_score = round4(value_total);
    report.illegal_catch_flags = illegal_count;
    report.delayed_report_count = late_count;

    let has_tac_wave = cases.iter().any(|v| v.tac_wave > 0);
    if !meets_floors(cfg, &report, has_tac_wave) {
        report.status = "fail".into();
    }
    report.report_digest = digest_body(&report);
    report
}

fn meets_floors(cfg: &QuotaCfg, report: &QuotaReport, has_tac_wave: bool) -> bool {
    if report.coverage_rate < cfg.min_coverage_rate {
        return false;
    }
    if report.surplus_ratio > cfg.max_surplus_ratio {
        return false;
    }
    if report.port_violations > cfg.max_port_violations {
        return false;
    }
    if report.rank_inversions > cfg.max_rank_inversions {
        return false;
    }
    if report.tac_buffer_kg < cfg.min_tac_buffer_kg && has_tac_wave {
        return false;
    }
    if report.revenue_score < cfg.min_revenue_score {
        return false;
    }
    for row in &report.vessels {
        if row.vessel_id.starts_with("v_dep_") && !row.port_ready && row.cleared {
            return false;
        }
        if row.vessel_id.starts_with("v_tac_") && row.tac_wave > 0 && !row.cleared {
            return false;
        }
        if row.vessel_id.starts_with("v_landing_") && row.surplus_kg == 0 && row.quota_kg > row.catch_kg + 50 {
            return false;
        }
        if row.vessel_id.starts_with("v_stock_") && row.cleared && row.catch_kg > row.quota_kg + 200 {
            return false;
        }
        if row.vessel_id.starts_with("v_illegal_") && row.cleared && !row.illegal_flag {
            return false;
        }
    }
    let _ = sx_fold(&report.vessels);
    true
}

#[derive(serde::Serialize)]
struct DigestPayload<'a> {
    status: &'a str,
    fleet_tac_kg: i32,
    catch_allocated_kg: i32,
    catch_surplus_kg: i32,
    vessels_total: i32,
    vessels_cleared: i32,
    coverage_rate: f64,
    surplus_ratio: f64,
    port_violations: i32,
    rank_inversions: i32,
    tac_buffer_kg: i32,
    revenue_score: f64,
    illegal_catch_flags: i32,
    delayed_report_count: i32,
    report_digest: &'a str,
    vessels: &'a [VesselRow],
}

fn digest_body(report: &QuotaReport) -> String {
    let payload = DigestPayload {
        status: &report.status,
        fleet_tac_kg: report.fleet_tac_kg,
        catch_allocated_kg: report.catch_allocated_kg,
        catch_surplus_kg: report.catch_surplus_kg,
        vessels_total: report.vessels_total,
        vessels_cleared: report.vessels_cleared,
        coverage_rate: report.coverage_rate,
        surplus_ratio: report.surplus_ratio,
        port_violations: report.port_violations,
        rank_inversions: report.rank_inversions,
        tac_buffer_kg: report.tac_buffer_kg,
        revenue_score: report.revenue_score,
        illegal_catch_flags: report.illegal_catch_flags,
        delayed_report_count: report.delayed_report_count,
        report_digest: "",
        vessels: &report.vessels,
    };
    let raw = serde_json::to_string(&payload).unwrap_or_default();
    format!("{:x}", Sha256::digest(raw.as_bytes()))
}

pub fn write_report(path: &Path, report: &QuotaReport) -> std::io::Result<()> {
    let raw = serde_json::to_string_pretty(report).map_err(|e| std::io::Error::other(e))?;
    let mut file = File::create(path)?;
    file.write_all(raw.as_bytes())?;
    Ok(())
}
