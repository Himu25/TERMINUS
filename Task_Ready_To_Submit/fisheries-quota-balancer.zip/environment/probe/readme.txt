probe lane for quota smoke checks
