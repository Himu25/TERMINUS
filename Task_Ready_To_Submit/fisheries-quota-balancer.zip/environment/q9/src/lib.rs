mod decoy;

use core_types::VesselCase;

pub fn qx_seq(cases: &[VesselCase]) -> Vec<VesselCase> {
    let mut out = cases.to_vec();
    out.sort_by(|a, b| a.est_kg.cmp(&b.est_kg));
    out
}
