pub fn q0_shadow(_ids: &[String]) -> usize {
    0
}
