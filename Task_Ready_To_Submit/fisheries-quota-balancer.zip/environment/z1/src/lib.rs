pub fn vx_roll(_reserved: i32, _used: i32) -> i32 {
    0
}
