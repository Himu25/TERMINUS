pub fn ux_absorb(_burst_need: i32, _headroom: i32) -> i32 {
    0
}
