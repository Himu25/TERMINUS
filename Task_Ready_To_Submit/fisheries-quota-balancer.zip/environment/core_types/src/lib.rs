use serde::{Deserialize, Serialize};
use std::collections::HashMap;

#[derive(Debug, Clone)]
pub struct QuotaCfg {
    pub fleet_tac_kg: i32,
    pub min_coverage_rate: f64,
    pub max_surplus_ratio: f64,
    pub max_port_violations: i32,
    pub max_rank_inversions: i32,
    pub min_tac_buffer_kg: i32,
    pub min_revenue_score: f64,
    pub band_weights: HashMap<String, f64>,
}

#[derive(Debug, Clone)]
pub struct StockProfile {
    pub stock_zone: String,
    pub peak_scale: i32,
    pub renew_scale: i32,
    pub renew_after: i32,
}

#[derive(Debug, Clone, Deserialize)]
pub struct VesselCase {
    pub vessel_id: String,
    pub species_band: String,
    pub stock_pressure: i32,
    pub report_revision: i32,
    #[serde(default)]
    pub est_kg: i32,
    #[serde(default)]
    pub act_kg: i32,
    #[serde(default)]
    pub port_deps: Vec<String>,
    #[serde(default)]
    pub tac_wave: i32,
    #[serde(default)]
    pub price_index: f64,
    #[serde(default = "default_stock_zone")]
    pub stock_zone: String,
    #[serde(default)]
    pub start_slot: i32,
    #[serde(default = "default_end_slot")]
    pub end_slot: i32,
}

fn default_stock_zone() -> String {
    "north-shelf".into()
}

fn default_end_slot() -> i32 {
    96
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VesselRow {
    pub vessel_id: String,
    pub species_band: String,
    pub stock_pressure: i32,
    pub quota_kg: i32,
    pub catch_kg: i32,
    pub surplus_kg: i32,
    pub cleared: bool,
    pub port_ready: bool,
    pub allocation_rank: i32,
    pub tac_wave: i32,
    pub revenue_score: f64,
    pub illegal_flag: bool,
    pub late_report: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QuotaReport {
    pub status: String,
    pub fleet_tac_kg: i32,
    pub catch_allocated_kg: i32,
    pub catch_surplus_kg: i32,
    pub vessels_total: i32,
    pub vessels_cleared: i32,
    pub coverage_rate: f64,
    pub surplus_ratio: f64,
    pub port_violations: i32,
    pub rank_inversions: i32,
    pub tac_buffer_kg: i32,
    pub revenue_score: f64,
    pub illegal_catch_flags: i32,
    pub delayed_report_count: i32,
    pub report_digest: String,
    pub vessels: Vec<VesselRow>,
}
