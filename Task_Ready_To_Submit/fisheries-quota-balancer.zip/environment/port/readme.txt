port queue notes
