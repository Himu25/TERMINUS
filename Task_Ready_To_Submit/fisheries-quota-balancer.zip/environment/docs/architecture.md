# Architecture

The quota lab under `/app` is a Rust workspace. `quotadisp` reads vessel JSONL, stock profiles, and landings meter data, then writes `/app/output/quota_report.json`. Supporting crates handle ranking, port gates, TAC absorption, surplus rolls, and stock-zone metering. Build with `/app/scripts/build.sh`.
