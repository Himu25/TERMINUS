# Quota report contract

## Top-level fields

- status: ok when guardrails pass, otherwise fail
- fleet_tac_kg: season pool from quota.toml
- catch_allocated_kg: billable kg allocated to cleared vessels
- catch_surplus_kg: quota surplus summed across vessels
- vessels_total: input JSONL row count
- vessels_cleared: vessels marked cleared
- coverage_rate: vessels_cleared divided by vessels_total
- surplus_ratio: catch_surplus_kg divided by catch_allocated_kg
- port_violations: vessels dispatched before port dependencies finished
- rank_inversions: cleared vessels whose rank score fell below a prior finish
- tac_buffer_kg: TAC headroom kg absorbed during waves
- revenue_score: weighted price index total for cleared vessels
- illegal_catch_flags: count of vessel rows with illegal_flag set
- delayed_report_count: count of vessel rows with late_report set
- report_digest: sha256 hex of compact JSON with report_digest empty
- vessels: per-vessel rows

## Vessel row fields

- vessel_id, species_band, stock_pressure
- quota_kg, catch_kg, surplus_kg
- cleared, port_ready, allocation_rank, tac_wave, revenue_score
- illegal_flag, late_report

## Allocation order

Pending vessels are sorted before allocation using, in order:

1. report_revision descending (late landings outrank stale rows)
2. stock_pressure descending
3. price_index descending
4. vessel_id ascending (stable tie-break)

## allocation_rank

1-based position in the allocator processing order after the sort above. Lower allocation_rank means the vessel was scheduled earlier.

## Rank inversions

For each cleared vessel, form rank score = report_revision * 10 + stock_pressure. rank_inversions counts how often a cleared vessel's rank score is greater than the rank score of an earlier-cleared vessel.

## Stock profile

stock_profiles.csv supplies peak_scale, renew_scale, and renew_after per stock_zone. The Rust meter (`meter_span` / `span_fold` in the n8 crate) blends peak and renew scales across each vessel's start_slot and slot span before converting estimates and actuals into billable kg.

Slot span duration is act_kg when act_kg is positive, otherwise max(est_kg, 1). Let end_slot = start_slot + duration and renew_after come from the vessel's stock_zone row.

Effective intensity scale across the span:

- end_slot <= renew_after: peak_scale
- start_slot >= renew_after: renew_scale
- otherwise: (pre_slots * peak_scale + post_slots * renew_scale) / duration, where pre_slots = renew_after - start_slot, post_slots = duration - pre_slots, and the quotient is floored to at least 1

Scaled kg: scaled_est = est_kg * effective_scale / 100 (at least 1 when est_kg > 0); scaled_act = act_kg * effective_scale / 100 (at least 1 when act_kg > 0).

Billable kg from the meter:

- when a landing overlay is active and scaled estimate/actual drift exceeds 15% of the scaled estimate, billable is scaled_act
- when act_kg > 0, billable is scaled_act
- otherwise billable is scaled_est

Stock-zone rows with est_kg = 0 (for example v_stock_north in north-shelf vs v_stock_south in south-ridge) must bill through this blend, so south-ridge renew_scale 70 with renew_after 24 yields lower quota_kg and catch_kg than north-shelf at scale 100 for the same raw act_kg.

## Landing drift and kg accounting

- quota_kg: reservation size from est_kg when est_kg is positive; when est_kg is zero, reservation follows blended billable kg from the stock profile meter (and the landings meter when it supplies overlay act_kg)
- catch_kg: when landings_meter.csv supplies act_kg, that value is scaled through the stock profile meter; otherwise act_kg from the vessel row is scaled the same way. catch_kg is capped to quota_kg when raw actuals exceed the blended reservation
- surplus_kg: quota_kg minus catch_kg (zero when quota is not greater than catch)
- Conflicting-landing drift rows keep the estimate reservation even when actual unload is lower, so surplus_kg reflects quota minus catch

## Illegal catches

Vessels prefixed v_illegal_ must set illegal_flag when act_kg exceeds est_kg or catch_kg exceeds quota_kg while cleared.

## Delayed reporting

Vessels prefixed v_late_ set late_report when report_revision is below stock_pressure.

Digest JSON uses the same keys as the written report with report_digest set to empty string before hashing.
