use core_types::VesselRow;

pub fn sx_fold(rows: &[VesselRow]) -> i32 {
    rows.iter().map(|r| r.quota_kg).sum()
}
