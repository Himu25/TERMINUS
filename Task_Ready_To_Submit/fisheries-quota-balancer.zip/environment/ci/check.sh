#!/bin/bash
set -euo pipefail
cargo test --workspace --quiet 2>/dev/null || cargo test --workspace
