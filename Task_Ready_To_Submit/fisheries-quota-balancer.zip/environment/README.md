Quota lab workspace for seasonal TAC balancing.

Build: `/app/scripts/build.sh` (offline; `cargo` and `rustc` live under `/usr/local/cargo/bin` on PATH)
Run: `/app/tools/run_quota`

See `/app/docs/contract.md` for report schema and stock-zone meter_span blending.
