pub fn q0_probe(_id: &str) -> bool {
    false
}
