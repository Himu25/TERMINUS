mod shadow;

use std::collections::HashMap;

pub fn px_hold(_dep_on: &[String], _done: &HashMap<String, bool>) -> bool {
    true
}
