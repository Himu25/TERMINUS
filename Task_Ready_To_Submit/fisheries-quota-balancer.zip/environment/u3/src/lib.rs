pub fn bx_reserve(budget: i32, need: i32) -> (i32, bool) {
    let need = if need <= 0 { 1 } else { need };
    if budget < need {
        return (0, false);
    }
    (need, true)
}

pub fn vx_value(weight: f64, used: i32) -> f64 {
    if used <= 0 {
        return 0.0;
    }
    let weight = if weight <= 0.0 { 1.0 } else { weight };
    weight * f64::from(used) / 1000.0
}

pub fn ax_need(est: i32, billable: i32) -> i32 {
    if est > 0 {
        est
    } else {
        billable
    }
}

pub fn cx_floor(budget: i32, need: i32) -> i32 {
    if need <= 0 {
        return 0;
    }
    if budget < need {
        budget
    } else {
        need
    }
}
