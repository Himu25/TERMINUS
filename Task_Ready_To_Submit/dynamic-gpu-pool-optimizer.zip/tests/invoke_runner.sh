#!/bin/bash
set -euo pipefail
exec /app/bin/poolopt /app/data/jobs_default.jsonl /app/output/schedule_report.json
