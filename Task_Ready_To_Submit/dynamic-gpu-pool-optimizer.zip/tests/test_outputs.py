"""Validate /app/output/schedule_report.json against pool.toml guardrails."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from contextlib import contextmanager
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "schedule_report.json"
JOBS = APP / "data" / "jobs_default.jsonl"
CFG = APP / "config" / "pool.toml"
POOLD = "/app/bin/poolopt"
INVOKER = Path(__file__).resolve().parent / "invoke_runner.sh"
FX = Path(__file__).resolve().parent / "fx"
FIXTURES = Path(__file__).resolve().parent / "fixtures"
MEAN_TOLERANCE = 2e-4

_DEFAULT_JOBS_TEXT = JOBS.read_text(encoding="utf-8") if JOBS.is_file() else ""

REPORT_KEYS = frozenset(
    {
        "status",
        "gpu_count",
        "jobs_total",
        "mean_throughput",
        "idle_ratio",
        "fairness_index",
        "mean_frag_score",
        "starvation_events",
        "rebalance_moves",
        "report_digest",
        "jobs",
    }
)
ROW_KEYS = frozenset(
    {
        "job_id",
        "tenant",
        "batch_size",
        "mem_mib",
        "wait_ticks",
        "active_gpus",
        "throughput",
        "idle_ticks",
        "frag_score",
        "fair_share",
        "starved",
    }
)


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "gpu_count": 8,
        "mem_per_gpu_mib": 16384,
        "throughput_floor": 0.55,
        "max_idle_ratio": 0.35,
        "min_fairness_index": 0.70,
        "max_frag_score": 0.45,
        "max_starvation_events": 2,
        "min_rebalance_moves": 2,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in ("throughput_floor", "max_idle_ratio", "min_fairness_index", "max_frag_score"):
            cfg[key] = float(val)
        elif key in (
            "gpu_count",
            "mem_per_gpu_mib",
            "max_starvation_events",
            "min_rebalance_moves",
        ):
            cfg[key] = int(float(val))
    return cfg


@pytest.fixture(autouse=True)
def restore_default_jobs() -> None:
    yield
    if _DEFAULT_JOBS_TEXT:
        _atomic_write_text(JOBS, _DEFAULT_JOBS_TEXT)


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _swap_fixture(stem: str) -> None:
    src = FIXTURES / f"{stem}.jsonl"
    _atomic_write_text(JOBS, src.read_text(encoding="utf-8"))


def _round4(value: float) -> float:
    return round(value * 10000 + 0.5) / 10000


def _expected_means(rows: list[dict]) -> tuple[float, float]:
    if not rows:
        return (0.0, 0.0)
    total = len(rows)
    tput = sum(row["throughput"] for row in rows) / total
    frag = sum(row["frag_score"] for row in rows) / total
    return (_round4(tput), _round4(frag))


def _digest_payload(report: dict) -> dict:
    return {
        "status": report["status"],
        "gpu_count": report["gpu_count"],
        "jobs_total": report["jobs_total"],
        "mean_throughput": report["mean_throughput"],
        "idle_ratio": report["idle_ratio"],
        "fairness_index": report["fairness_index"],
        "mean_frag_score": report["mean_frag_score"],
        "starvation_events": report["starvation_events"],
        "rebalance_moves": report["rebalance_moves"],
        "report_digest": "",
        "jobs": report["jobs"],
    }


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _run_pool(job_path: Path, out_path: Path) -> None:
    proc = subprocess.run(
        [POOLD, str(job_path), str(out_path)],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _invoke_default() -> None:
    proc = subprocess.run(
        ["bash", str(INVOKER)],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "schedule_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


class _AblationBuildFailed(Exception):
    """Raised when the broken file causes a compile error."""


@contextmanager
def _swap_go(rel_path: str, fixture_name: str):
    target = APP / rel_path
    backup = target.read_text(encoding="utf-8")
    shutil.copy(FX / fixture_name, target)
    try:
        proc = subprocess.run(
            ["bash", "/app/scripts/build.sh"],
            cwd=str(APP),
            capture_output=True,
            text=True,
            check=False,
        )
        if proc.returncode != 0:
            raise _AblationBuildFailed(proc.stderr or proc.stdout)
        yield
    finally:
        target.write_text(backup, encoding="utf-8")
        proc = subprocess.run(
            ["bash", "/app/scripts/build.sh"],
            cwd=str(APP),
            capture_output=True,
            text=True,
            check=False,
        )
        assert proc.returncode == 0, proc.stderr or proc.stdout
        _invoke_default()


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    assert INVOKER.is_file(), "runner script missing"
    _invoke_default()


def test_report_top_level_keys_exact() -> None:
    """Report must expose only the documented top-level keys."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS


def test_job_row_schema() -> None:
    """Each job row must match the documented per-job schema."""
    report = _load_report()
    assert report["jobs"]
    for row in report["jobs"]:
        assert set(row.keys()) == ROW_KEYS
        assert isinstance(row["job_id"], str) and row["job_id"]
        assert isinstance(row["tenant"], str) and row["tenant"]
        assert isinstance(row["batch_size"], int) and row["batch_size"] > 0
        assert row["mem_mib"] > 0
        assert row["wait_ticks"] >= 0
        assert row["active_gpus"] >= 0
        assert row["throughput"] >= 0.0
        assert row["idle_ticks"] >= 0
        assert row["frag_score"] >= 0.0
        assert 0.0 <= row["fair_share"] <= 1.0
        assert isinstance(row["starved"], bool)


def test_passing_run_contract() -> None:
    """Default bundle must finish ok and meet pool.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["gpu_count"] == cfg["gpu_count"]
    assert report["jobs_total"] == len(report["jobs"])
    assert report["mean_throughput"] >= cfg["throughput_floor"]
    assert report["idle_ratio"] <= cfg["max_idle_ratio"]
    assert report["fairness_index"] >= cfg["min_fairness_index"]
    assert report["mean_frag_score"] <= cfg["max_frag_score"]
    assert report["starvation_events"] <= cfg["max_starvation_events"]
    assert report["rebalance_moves"] >= cfg["min_rebalance_moves"]


def test_mean_fields_recomputed_from_jobs() -> None:
    """Summary means must match per-job rows within tolerance."""
    report = _load_report()
    exp_tput, exp_frag = _expected_means(report["jobs"])
    assert abs(report["mean_throughput"] - exp_tput) <= MEAN_TOLERANCE
    assert abs(report["mean_frag_score"] - exp_frag) <= MEAN_TOLERANCE


def test_report_digest_matches_payload() -> None:
    """report_digest must hash the compact pre-digest JSON payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_deterministic_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_starve_rows_not_marked() -> None:
    """High-priority starve rows must receive GPUs and stay unstarved."""
    report = _load_report()
    for row in report["jobs"]:
        if row["job_id"].startswith("j_starve_"):
            assert row["active_gpus"] >= 1, row
            assert row["starved"] is False, row


def test_fair_mix_rows_meet_share_floor() -> None:
    """Fairness-mix rows must finish with fair_share at or above the index floor."""
    cfg = _parse_cfg()
    report = _load_report()
    fair_rows = [row for row in report["jobs"] if row["job_id"].startswith("j_fair_")]
    assert len(fair_rows) >= 3
    assert fair_rows[-1]["fair_share"] >= cfg["min_fairness_index"], fair_rows[-1]


def test_underassigned_waves_record_gaps() -> None:
    """Waves that miss all device assignments must record full-pool idle ticks."""
    report = _load_report()
    for row in report["jobs"]:
        if row["active_gpus"] == 0:
            assert row["idle_ticks"] == report["gpu_count"], row


def test_batch_wide_row_throughput() -> None:
    """Wide-batch row must meet throughput floor after variable batch sizing."""
    cfg = _parse_cfg()
    report = _load_report()
    row = next(r for r in report["jobs"] if r["job_id"] == "j_batch_wide")
    assert row["batch_size"] > 16
    assert row["throughput"] >= cfg["throughput_floor"], row


def test_frag_rows_under_ceiling() -> None:
    """Fragmentation rows must stay at or below max_frag_score."""
    cfg = _parse_cfg()
    report = _load_report()
    frag_rows = [row for row in report["jobs"] if row["job_id"].startswith("j_frag_")]
    assert frag_rows
    for row in frag_rows:
        assert row["frag_score"] <= cfg["max_frag_score"], row


def test_scenario_frag_storm() -> None:
    """Fragmentation storm scenario must keep mean_frag_score under ceiling."""
    cfg = _parse_cfg()
    _swap_fixture("scenario_frag_storm")
    _invoke_default()
    report = _load_report()
    assert report["mean_frag_score"] <= cfg["max_frag_score"]
    assert report["status"] == "ok"


def test_scenario_starve_burst() -> None:
    """Starve-burst scenario must record zero starvation events."""
    _swap_fixture("scenario_starve_burst")
    _invoke_default()
    report = _load_report()
    assert report["starvation_events"] == 0
    assert report["status"] == "ok"


def test_scenario_fair_ladder() -> None:
    """Fair-ladder scenario must meet fairness_index floor."""
    cfg = _parse_cfg()
    _swap_fixture("scenario_fair_ladder")
    _invoke_default()
    report = _load_report()
    assert report["fairness_index"] >= cfg["min_fairness_index"]


def test_scenario_idle_wave() -> None:
    """Idle-wave scenario must keep idle_ratio under max_idle_ratio."""
    cfg = _parse_cfg()
    _swap_fixture("scenario_idle_wave")
    _invoke_default()
    report = _load_report()
    assert report["idle_ratio"] <= cfg["max_idle_ratio"]


def test_scenario_batch_swing() -> None:
    """Batch-swing scenario must keep mean_throughput above floor."""
    cfg = _parse_cfg()
    _swap_fixture("scenario_batch_swing")
    _invoke_default()
    report = _load_report()
    assert report["mean_throughput"] >= cfg["throughput_floor"]


def test_scenario_rebal_spread() -> None:
    """Rebalance-spread scenario must record enough rebalance_moves."""
    cfg = _parse_cfg()
    _swap_fixture("scenario_rebal_spread")
    _invoke_default()
    report = _load_report()
    assert report["rebalance_moves"] >= cfg["min_rebalance_moves"]


def test_broken_fairness_ablation_fails_index() -> None:
    """Constant fairness share must drop fairness_index below the floor."""
    cfg = _parse_cfg()
    baseline = _load_report()
    try:
        with _swap_go("fair/f6_share.go", "broken_f6_share.go"):
            _invoke_default()
            report = _load_report()
    except _AblationBuildFailed:
        return
    assert report["fairness_index"] < cfg["min_fairness_index"] or (
        baseline["fairness_index"] - report["fairness_index"] > 0.15
    )


def test_broken_idle_ablation_fails_ratio() -> None:
    """Zero idle gap tracking must inflate idle_ratio above ceiling."""
    cfg = _parse_cfg()
    try:
        with _swap_go("idle/i5_gap.go", "broken_i5_gap.go"):
            _invoke_default()
            report = _load_report()
    except _AblationBuildFailed:
        return
    assert report["idle_ratio"] > cfg["max_idle_ratio"]


def test_broken_batch_ablation_fails_throughput() -> None:
    """Underscaled batch units must drop wide-batch throughput below floor."""
    cfg = _parse_cfg()
    baseline = _load_report()
    try:
        with _swap_go("alloc/a3_var.go", "broken_a3_var.go"):
            _invoke_default()
            report = _load_report()
    except _AblationBuildFailed:
        return
    wide_rows = [r for r in report["jobs"] if r["job_id"] == "j_batch_wide"]
    assert wide_rows, "expected j_batch_wide in default bundle report"
    wide = wide_rows[0]
    assert wide["throughput"] < cfg["throughput_floor"] or (
        baseline["mean_throughput"] - report["mean_throughput"] > 5.0
    )
