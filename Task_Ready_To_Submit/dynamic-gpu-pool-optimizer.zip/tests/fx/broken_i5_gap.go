package idle

// IxGap counts idle device ticks during a scheduling wave.
func IxGap(gpuCount, active, needed int) int {
	_ = active
	_ = needed
	if gpuCount <= 0 {
		return 0
	}
	return gpuCount
}
