package drv

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"

	"pool.lab/alloc"
	"pool.lab/fair"
	"pool.lab/idle"
	"pool.lab/meter"
	"pool.lab/pkg/types"
	"pool.lab/queue"
	"pool.lab/rebal"
	"pool.lab/summ"
)

func LoadCfg(path string) (types.PoolCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.PoolCfg{}, err
	}
	cfg := types.PoolCfg{
		GpuCount:            8,
		MemPerGpuMib:        16384,
		ThroughputFloor:     0.55,
		MaxIdleRatio:        0.35,
		MinFairnessIndex:    0.70,
		MaxFragScore:        0.45,
		MaxStarvationEvents: 2,
        MinRebalanceMoves:   2,
		TenantWeights:       map[string]float64{"team_a": 1.0, "team_b": 1.0, "team_c": 1.0},
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "gpu_count":
			fmt.Sscanf(val, "%d", &cfg.GpuCount)
		case "mem_per_gpu_mib":
			fmt.Sscanf(val, "%d", &cfg.MemPerGpuMib)
		case "throughput_floor":
			fmt.Sscanf(val, "%f", &cfg.ThroughputFloor)
		case "max_idle_ratio":
			fmt.Sscanf(val, "%f", &cfg.MaxIdleRatio)
		case "min_fairness_index":
			fmt.Sscanf(val, "%f", &cfg.MinFairnessIndex)
		case "max_frag_score":
			fmt.Sscanf(val, "%f", &cfg.MaxFragScore)
		case "max_starvation_events":
			fmt.Sscanf(val, "%d", &cfg.MaxStarvationEvents)
		case "min_rebalance_moves":
			fmt.Sscanf(val, "%d", &cfg.MinRebalanceMoves)
		case "tenant_weight_team_a":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.TenantWeights["team_a"] = w
		case "tenant_weight_team_b":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.TenantWeights["team_b"] = w
		case "tenant_weight_team_c":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.TenantWeights["team_c"] = w
		}
	}
	return cfg, nil
}

func LoadJobs(path string) ([]types.JobCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.JobCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var jc types.JobCase
		if err := json.Unmarshal([]byte(line), &jc); err != nil {
			return nil, err
		}
		out = append(out, jc)
	}
	return out, sc.Err()
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

func Run(cfg types.PoolCfg, cases []types.JobCase) (types.ScheduleReport, error) {
	ordered := queue.QxOrder(cases)
	report := types.ScheduleReport{
		Status:    "ok",
		GpuCount:  cfg.GpuCount,
		JobsTotal: len(ordered),
	}
	remaining := make([]int, cfg.GpuCount)
	for i := range remaining {
		remaining[i] = cfg.MemPerGpuMib
	}
	activePerDev := make([]int, cfg.GpuCount)
	tenantUnits := make(map[string]float64)
	var sumTput, sumFrag, sumIdle float64
	totalIdle := 0
	totalCap := cfg.GpuCount
	starved := 0
	rebalanceTotal := 0
	report.Jobs = make([]types.JobRow, 0, len(ordered))

	for _, jc := range ordered {
		pad := alloc.BxPad(jc.MemMib, jc.BatchSize)
		gpuIdx := -1
		for i := 0; i < cfg.GpuCount; i++ {
			if alloc.BxFit(remaining[i], jc.MemMib, pad) {
				gpuIdx = i
				break
			}
		}
		active := 0
		need := jc.GpuNeed
		if need <= 0 {
			need = 1
		}
		if gpuIdx >= 0 {
			active = need
			if active > cfg.GpuCount {
				active = cfg.GpuCount
			}
			used := jc.MemMib + pad
			for k := 0; k < active && k < cfg.GpuCount; k++ {
				idx := (gpuIdx + k) % cfg.GpuCount
				remaining[idx] -= used
				if remaining[idx] < 0 {
					remaining[idx] = 0
				}
				activePerDev[idx]++
			}
		}
		pads := make([]int32, active)
		for i := range pads {
			pads[i] = int32(pad)
		}
		frag := meter.MeterSpan(pads, cfg.MemPerGpuMib).FragScore
		tput := alloc.VxUnits(jc.BatchSize, jc.GpuNeed)
		isStarved := false
		if jc.WaitTicks > 12 && active == 0 {
			isStarved = true
		}
		if strings.HasPrefix(jc.JobID, "j_starve_") && active < jc.GpuNeed {
			isStarved = true
		}
		if isStarved {
			starved++
		}
		idleTicks := idle.IxGap(cfg.GpuCount, active, need)
		totalIdle += idleTicks
		weight := jc.TenantWt
		if weight <= 0 {
			weight = cfg.TenantWeights[jc.Tenant]
		}
		if weight <= 0 {
			weight = 1.0
		}
		if active > 0 {
			tenantUnits[jc.Tenant] += tput * weight
		}
		share := fair.FxShare(tenantUnits, cfg.TenantWeights)
		if jc.BurstLoad && active == 0 {
			tput *= 0.2
		}
		if strings.HasPrefix(jc.JobID, "j_frag_") && frag > cfg.MaxFragScore {
			tput *= 0.4
		}
		row := types.JobRow{
			JobID:      jc.JobID,
			Tenant:     jc.Tenant,
			BatchSize:  jc.BatchSize,
			MemMib:     jc.MemMib,
			WaitTicks:  jc.WaitTicks,
			ActiveGpus: active,
			Throughput: round4(tput),
			IdleTicks:  idleTicks,
			FragScore:  round4(frag),
			FairShare:  round4(share),
			Starved:    isStarved,
		}
		report.Jobs = append(report.Jobs, row)
		sumTput += tput
		sumFrag += frag
		sumIdle += float64(idleTicks)
	}
	rebalanceTotal = rebal.RxMoves(activePerDev)
	n := float64(len(ordered))
	if n > 0 {
		report.MeanThroughput = round4(sumTput / n)
		report.MeanFragScore = round4(sumFrag / n)
	}
	waves := int(n)
	if waves <= 0 {
		waves = 1
	}
	if capTicks := totalCap * waves; capTicks > 0 {
		report.IdleRatio = round4(float64(totalIdle) / float64(capTicks))
	}
	report.FairnessIndex = round4(fair.FxShare(tenantUnits, cfg.TenantWeights))
	report.StarvationEvents = starved
	report.RebalanceMoves = rebalanceTotal
	if !meetsFloors(cfg, report) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func meetsFloors(cfg types.PoolCfg, report types.ScheduleReport) bool {
	if report.MeanThroughput < cfg.ThroughputFloor {
		return false
	}
	if report.IdleRatio > cfg.MaxIdleRatio {
		return false
	}
	if report.FairnessIndex < cfg.MinFairnessIndex {
		return false
	}
	if report.MeanFragScore > cfg.MaxFragScore {
		return false
	}
	if report.StarvationEvents > cfg.MaxStarvationEvents {
		return false
	}
	if report.RebalanceMoves < cfg.MinRebalanceMoves {
		return false
	}
	for _, row := range report.Jobs {
		if strings.HasPrefix(row.JobID, "j_starve_") && row.Starved {
			return false
		}
		if strings.HasPrefix(row.JobID, "j_fair_") && row.FairShare < cfg.MinFairnessIndex {
			return false
		}
		if row.ActiveGpus == 0 && row.IdleTicks == 0 && row.WaitTicks > 0 {
			return false
		}
		if strings.HasPrefix(row.JobID, "j_frag_") && row.FragScore > cfg.MaxFragScore {
			return false
		}
		if strings.HasPrefix(row.JobID, "j_batch_") && row.BatchSize > 16 && row.Throughput < cfg.ThroughputFloor {
			return false
		}
	}
	_ = summ.SxFold(report.Jobs)
	return true
}

type digestPayload struct {
	Status           string          `json:"status"`
	GpuCount         int             `json:"gpu_count"`
	JobsTotal        int             `json:"jobs_total"`
	MeanThroughput   float64         `json:"mean_throughput"`
	IdleRatio        float64         `json:"idle_ratio"`
	FairnessIndex    float64         `json:"fairness_index"`
	MeanFragScore    float64         `json:"mean_frag_score"`
	StarvationEvents int             `json:"starvation_events"`
	RebalanceMoves   int             `json:"rebalance_moves"`
	ReportDigest     string          `json:"report_digest"`
	Jobs             []types.JobRow  `json:"jobs"`
}

func digestBody(report types.ScheduleReport) string {
	payload := digestPayload{
		Status:           report.Status,
		GpuCount:         report.GpuCount,
		JobsTotal:        report.JobsTotal,
		MeanThroughput:   report.MeanThroughput,
		IdleRatio:        report.IdleRatio,
		FairnessIndex:    report.FairnessIndex,
		MeanFragScore:    report.MeanFragScore,
		StarvationEvents: report.StarvationEvents,
		RebalanceMoves:   report.RebalanceMoves,
		ReportDigest:     "",
		Jobs:             report.Jobs,
	}
	raw, err := marshalDigestJSON(payload)
	if err != nil {
		return ""
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func marshalDigestJSON(payload digestPayload) ([]byte, error) {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return nil, err
	}
	b := buf.Bytes()
	if n := len(b); n > 0 && b[n-1] == '\n' {
		b = b[:n-1]
	}
	return b, nil
}

func WriteReport(path string, report types.ScheduleReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func p95(values []int) int {
	if len(values) == 0 {
		return 0
	}
	cp := append([]int(nil), values...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}
