# Pool optimizer architecture

poolopt loads pool.toml and a jobs JSONL bundle, ranks pending work, assigns memory blocks across the device pool, tracks idle gaps, scores tenant fairness, and folds fragmentation through the Rust meter bridge.

Default bundle job stems include j_base_01, j_batch_wide, j_batch_narrow, j_frag_alpha, j_starve_long, j_fair_mix_a, j_idle_wave, and j_rebal_spread. Scenario packs listed in scenario_index.txt swap into jobs_default.jsonl for grading.

Default verifier refresh uses `/app/tools/run_pool` via `invoke_runner.sh` in the verifier test tree. Indexed scenario packs are listed in `/app/docs/scenario_index.txt`; graded substitution bundles live under the verifier `fixtures` tree as `scenario_*.jsonl`. Partial-regression sources include `broken_f6_share.go`, `broken_i5_gap.go`, and `broken_a3_var.go` alongside `fair/f6_share.go`, `idle/i5_gap.go`, and `alloc/a3_var.go`.

Packages:
- queue: dispatch ordering
- alloc: bin fit and batch throughput units
- rebal: cross-device shift counting
- idle: gap tracking per wave
- fair: tenant share scoring
- meter: Rust fragmentation bridge
- summ: report rollups
- drv: orchestration and digest

Entry: /app/bin/poolopt
Harness: /app/tools/run_pool
