# Schedule report contract

## Top-level fields

- status: ok when all guardrails pass, otherwise fail
- gpu_count: device pool size from pool.toml
- jobs_total: count of input JSONL rows
- mean_throughput: average per-job throughput units
- idle_ratio: idle device ticks divided by capacity ticks
- fairness_index: tenant share score after all waves
- mean_frag_score: average fragmentation score from the meter
- starvation_events: jobs marked starved under burst load
- rebalance_moves: cross-device shifts recorded during the run
- report_digest: sha256 hex of compact JSON with report_digest empty
- jobs: per-job rows

## Job row fields

- job_id, tenant, batch_size, mem_mib, wait_ticks
- active_gpus: devices assigned for the wave
- throughput: normalized units for the wave
- idle_ticks: unused device ticks during the wave
- frag_score: fragmentation score from the Rust meter
- fair_share: tenant fairness contribution for the wave
- starved: true when wait exceeded threshold without assignment

Digest JSON uses the same keys as the written report with report_digest set to empty string before hashing.
