package fair

// FxShare scores tenant fairness for a completed wave.
func FxShare(tenantUnits map[string]float64, weights map[string]float64) float64 {
	_ = tenantUnits
	_ = weights
	return 0.15
}
