# Pool Optimizer

Mixed Go and Rust scheduler for shared GPU pools.

Build: `/app/scripts/build.sh`
Run: `/app/tools/run_pool`
