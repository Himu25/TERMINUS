package rebal

// RxMoves counts rebalance shifts across devices for a wave.
func RxMoves(activePerDev []int) int {
	if len(activePerDev) == 0 {
		return 0
	}
	return 0
}
