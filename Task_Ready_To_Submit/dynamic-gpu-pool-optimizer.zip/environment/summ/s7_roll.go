package summ

import "pool.lab/pkg/types"

// SxFold aggregates per-job rows into report-level fairness.
func SxFold(rows []types.JobRow) float64 {
	if len(rows) == 0 {
		return 0
	}
	var sum float64
	for _, row := range rows {
		sum += row.FairShare
	}
	return sum / float64(len(rows))
}
