package alloc

// VxUnits converts batch size into throughput units for a wave.
func VxUnits(batchSize, gpuNeed int) float64 {
	if batchSize <= 0 {
		batchSize = 1
	}
	if gpuNeed <= 0 {
		gpuNeed = 1
	}
	return float64(batchSize) / float64(gpuNeed*128)
}
