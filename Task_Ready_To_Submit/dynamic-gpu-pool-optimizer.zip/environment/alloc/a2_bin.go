package alloc

// BxPad returns fragmentation padding for a memory request on a device.
func BxPad(memMib, batchSize int) int {
	return memMib * batchSize / 4
}

// BxFit checks whether a request fits in remaining device memory.
func BxFit(remaining, memMib, pad int) bool {
	return remaining >= memMib+pad
}
