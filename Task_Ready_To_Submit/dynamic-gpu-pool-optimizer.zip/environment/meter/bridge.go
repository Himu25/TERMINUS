package meter

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libfrag_meter.a -ldl -lm
#include "frag_fold.h"
*/
import "C"
import "unsafe"

// Roll holds fragmentation metrics for one device wave.
type Roll struct {
	FragScore float64
	HoleCount int
}

// MeterSpan scores fragmentation for memory blocks on one device.
func MeterSpan(blocks []int32, capacity int) Roll {
	if len(blocks) == 0 || capacity <= 0 {
		return Roll{}
	}
	ct := C.frag_meter_span((*C.int)(unsafe.Pointer(&blocks[0])), C.int(len(blocks)), C.int(capacity))
	return Roll{
		FragScore: float64(ct.frag_score),
		HoleCount: int(ct.hole_count),
	}
}
