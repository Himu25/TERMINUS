#ifndef FRAG_FOLD_H
#define FRAG_FOLD_H

typedef struct {
    double frag_score;
    int hole_count;
} frag_roll;

frag_roll frag_meter_span(const int *blocks, int count, int capacity);

#endif
