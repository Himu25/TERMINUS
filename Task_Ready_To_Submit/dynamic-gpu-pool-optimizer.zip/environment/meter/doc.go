// Package meter bridges the Rust fragmentation meter.
package meter
