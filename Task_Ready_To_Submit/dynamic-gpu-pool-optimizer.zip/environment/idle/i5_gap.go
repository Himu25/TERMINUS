package idle

// IxGap counts idle device ticks during a scheduling wave.
func IxGap(gpuCount, active, needed int) int {
	_ = gpuCount
	_ = active
	_ = needed
	return 0
}
