package queue

import "pool.lab/pkg/types"

// QxOrder ranks pending jobs for dispatch.
func QxOrder(cases []types.JobCase) []types.JobCase {
	out := make([]types.JobCase, len(cases))
	copy(out, cases)
	return out
}
