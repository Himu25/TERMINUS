probe stub for device telemetry
