station notes for cluster ops
