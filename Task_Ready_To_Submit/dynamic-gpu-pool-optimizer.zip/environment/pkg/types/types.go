package types

type PoolCfg struct {
	GpuCount            int
	MemPerGpuMib        int
	ThroughputFloor     float64
	MaxIdleRatio        float64
	MinFairnessIndex    float64
	MaxFragScore        float64
	MaxStarvationEvents int
	MinRebalanceMoves   int
	TenantWeights       map[string]float64
}

type JobCase struct {
	JobID     string  `json:"job_id"`
	Tenant    string  `json:"tenant"`
	BatchSize int     `json:"batch_size"`
	MemMib    int     `json:"mem_mib"`
	Priority  int     `json:"priority"`
	WaitTicks int     `json:"wait_ticks"`
	GpuNeed   int     `json:"gpu_need"`
	BurstLoad bool    `json:"burst_load"`
	TenantWt  float64 `json:"tenant_weight"`
}

type JobRow struct {
	JobID       string  `json:"job_id"`
	Tenant      string  `json:"tenant"`
	BatchSize   int     `json:"batch_size"`
	MemMib      int     `json:"mem_mib"`
	WaitTicks   int     `json:"wait_ticks"`
	ActiveGpus  int     `json:"active_gpus"`
	Throughput  float64 `json:"throughput"`
	IdleTicks   int     `json:"idle_ticks"`
	FragScore   float64 `json:"frag_score"`
	FairShare   float64 `json:"fair_share"`
	Starved     bool    `json:"starved"`
}

type ScheduleReport struct {
	Status            string   `json:"status"`
	GpuCount          int      `json:"gpu_count"`
	JobsTotal         int      `json:"jobs_total"`
	MeanThroughput    float64  `json:"mean_throughput"`
	IdleRatio         float64  `json:"idle_ratio"`
	FairnessIndex     float64  `json:"fairness_index"`
	MeanFragScore     float64  `json:"mean_frag_score"`
	StarvationEvents  int      `json:"starvation_events"`
	RebalanceMoves    int      `json:"rebalance_moves"`
	ReportDigest      string   `json:"report_digest"`
	Jobs              []JobRow `json:"jobs"`
}
