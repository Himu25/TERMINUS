#!/bin/bash
set -euo pipefail
test -x /app/bin/poolopt
test -f /app/config/pool.toml
test -f /app/data/job_specs.jsonl
