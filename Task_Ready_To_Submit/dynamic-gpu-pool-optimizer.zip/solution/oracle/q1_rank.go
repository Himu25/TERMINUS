package queue

import (
	"sort"

	"pool.lab/pkg/types"
)

// QxOrder ranks pending jobs for dispatch.
func QxOrder(cases []types.JobCase) []types.JobCase {
	out := make([]types.JobCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		a, b := out[i], out[j]
		if a.Priority != b.Priority {
			return a.Priority > b.Priority
		}
		wa, wb := a.TenantWt, b.TenantWt
		if wa != wb {
			return wa > wb
		}
		return a.WaitTicks > b.WaitTicks
	})
	return out
}
