package rebal

// RxMoves counts rebalance shifts across devices for a wave.
func RxMoves(activePerDev []int) int {
	if len(activePerDev) <= 1 {
		return 0
	}
	minV, maxV := activePerDev[0], activePerDev[0]
	for _, v := range activePerDev[1:] {
		if v < minV {
			minV = v
		}
		if v > maxV {
			maxV = v
		}
	}
	if maxV <= minV {
		return 0
	}
	return maxV - minV
}
