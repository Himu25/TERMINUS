use std::os::raw::c_int;

#[repr(C)]
pub struct FragRoll {
    pub frag_score: f64,
    pub hole_count: c_int,
}

fn pad_total(blocks: &[i32]) -> i32 {
    blocks.iter().copied().filter(|&b| b > 0).sum()
}

fn hole_tally(blocks: &[i32]) -> i32 {
    blocks.iter().filter(|&&b| b > 0).count() as i32
}

fn pad_ratio(pad: i32, capacity: i32) -> f64 {
    if capacity <= 0 {
        0.0
    } else {
        pad as f64 / capacity as f64
    }
}

#[no_mangle]
pub extern "C" fn frag_meter_span(blocks: *const c_int, count: c_int, capacity: c_int) -> FragRoll {
    if blocks.is_null() || count <= 0 || capacity <= 0 {
        return FragRoll {
            frag_score: 0.0,
            hole_count: 0,
        };
    }
    let slice = unsafe { std::slice::from_raw_parts(blocks, count as usize) };
    let pad = pad_total(slice);
    let holes = hole_tally(slice);
    let score = pad_ratio(pad, capacity);
    FragRoll {
        frag_score: score,
        hole_count: holes,
    }
}
