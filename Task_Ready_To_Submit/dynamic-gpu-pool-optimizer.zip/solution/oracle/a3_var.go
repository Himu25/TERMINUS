package alloc

import "math"

// VxUnits converts batch size into throughput units for a wave.
func VxUnits(batchSize, gpuNeed int) float64 {
	if batchSize <= 0 {
		batchSize = 1
	}
	if gpuNeed <= 0 {
		gpuNeed = 1
	}
	bs := float64(batchSize)
	return bs * math.Sqrt(bs) / float64(gpuNeed)
}
