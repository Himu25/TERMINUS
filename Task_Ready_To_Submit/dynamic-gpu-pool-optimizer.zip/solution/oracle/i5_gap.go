package idle

// IxGap counts idle device ticks during a scheduling wave.
func IxGap(gpuCount, active, needed int) int {
	if gpuCount <= 0 {
		return 0
	}
	if needed <= 0 {
		needed = 1
	}
	if active >= needed {
		return 0
	}
	if active >= gpuCount {
		return 0
	}
	return gpuCount - active
}
