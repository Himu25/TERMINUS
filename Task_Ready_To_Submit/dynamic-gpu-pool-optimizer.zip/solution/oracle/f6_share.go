package fair

// FxShare scores tenant fairness for a completed wave.
func FxShare(tenantUnits map[string]float64, weights map[string]float64) float64 {
	if len(tenantUnits) == 0 {
		return 0
	}
	var sum, sumSq float64
	for tenant, units := range tenantUnits {
		w := weights[tenant]
		if w <= 0 {
			w = 1.0
		}
		adj := units / w
		sum += adj
		sumSq += adj * adj
	}
	n := float64(len(tenantUnits))
	if n <= 0 || sumSq <= 0 {
		return 0
	}
	idx := (sum * sum) / (n * sumSq)
	if idx > 1 {
		idx = 1
	}
	if idx < 0 {
		idx = 0
	}
	return idx
}
