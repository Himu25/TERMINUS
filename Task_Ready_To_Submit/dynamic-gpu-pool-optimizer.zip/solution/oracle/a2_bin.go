package alloc

// BxPad returns fragmentation padding for a memory request on a device.
func BxPad(memMib, batchSize int) int {
	pad := memMib / 64
	if batchSize > 0 {
		pad += batchSize / 8
	}
	return pad
}

// BxFit checks whether a request fits in remaining device memory.
func BxFit(remaining, memMib, pad int) bool {
	return remaining >= memMib+pad
}
