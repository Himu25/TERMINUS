#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/pool.toml
require_file /app/data/job_specs.jsonl
mkdir -p /app/bin /app/output

log "apply patched sources"
cp "${ROOT_DIR}/oracle/q1_rank.go" /app/queue/q1_rank.go
cp "${ROOT_DIR}/oracle/a2_bin.go" /app/alloc/a2_bin.go
cp "${ROOT_DIR}/oracle/a3_var.go" /app/alloc/a3_var.go
cp "${ROOT_DIR}/oracle/r4_move.go" /app/rebal/r4_move.go
cp "${ROOT_DIR}/oracle/i5_gap.go" /app/idle/i5_gap.go
cp "${ROOT_DIR}/oracle/f6_share.go" /app/fair/f6_share.go
cp "${ROOT_DIR}/oracle/lib.rs" /app/meter/src/lib.rs

log "rebuild scheduler"
bash /app/scripts/build.sh

log "refresh default job bundle"
/app/bin/jobgen /app/data/job_specs.jsonl /app/data/jobs_default.jsonl

log "emit default schedule report"
/app/tools/run_pool

log "post-run validation against pool.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/pool.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k.endswith("_floor") or k.endswith("_index") or k.startswith("max_") and "ratio" in k or k == "max_frag_score":
        cfg[k] = float(v)
    elif k.startswith("max_") or k.startswith("min_") or k == "gpu_count" or k == "mem_per_gpu_mib":
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/schedule_report.json").read_text())
assert report["status"] == "ok", report
assert report["mean_throughput"] >= cfg["throughput_floor"]
assert report["idle_ratio"] <= cfg["max_idle_ratio"]
assert report["fairness_index"] >= cfg["min_fairness_index"]
assert report["mean_frag_score"] <= cfg["max_frag_score"]
assert report["starvation_events"] <= cfg["max_starvation_events"]
assert report["rebalance_moves"] >= cfg["min_rebalance_moves"]
for row in report["jobs"]:
    if row["job_id"].startswith("j_starve_"):
        assert not row["starved"], row
print("ok", report["mean_throughput"], report["fairness_index"], report["idle_ratio"])
PY

log "oracle complete"
