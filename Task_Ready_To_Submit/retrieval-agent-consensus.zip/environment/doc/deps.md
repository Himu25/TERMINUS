Vendor `face` values are HIT or ALT.
