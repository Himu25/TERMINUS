package spar_k2

import "meshbench/hitwire"

// InkTally counts distinct ink tokens for bench telemetry only.
func InkTally(rows []hitwire.HitRow) int {
	seen := map[string]struct{}{}
	for _, r := range rows {
		if r.Ink == "" {
			continue
		}
		seen[r.Ink] = struct{}{}
	}
	return len(seen)
}
