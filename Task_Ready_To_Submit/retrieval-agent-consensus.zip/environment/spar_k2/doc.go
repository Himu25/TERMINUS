// Package spar_k2 holds offline telemetry helpers not wired into meshvote.
package spar_k2
