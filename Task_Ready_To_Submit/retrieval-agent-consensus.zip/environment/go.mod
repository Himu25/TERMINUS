module meshbench

go 1.22
