package keel_m8

import "meshbench/hitwire"

// ShiftSpan applies vendor ordering rules after narrowing.
func ShiftSpan(rows []hitwire.HitRow, _ string) []hitwire.HitRow {
	out := make([]hitwire.HitRow, 0, len(rows))
	stopped := false
	for idx := range rows {
		r := rows[idx]
		if r.Sentinel {
			stopped = true
			out = append(out, r)
			continue
		}
		if stopped {
			continue
		}
		out = append(out, r)
	}
	return out
}
