package runner

import (
	"meshbench/keel_m8"
	"meshbench/hitwire"
)

func runShift(rows []hitwire.HitRow, pair string) []hitwire.HitRow {
	return keel_m8.ShiftSpan(rows, pair)
}
