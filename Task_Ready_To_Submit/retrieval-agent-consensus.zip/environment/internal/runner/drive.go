package runner

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"

	"meshbench/hitwire"
)

// AgentRun is the JSON shape for one scenario emission.
type AgentRun struct {
	ScenarioTag string `json:"scenario_tag"`
	PrimaryScore int    `json:"primary_score"`
	DiversityScore int    `json:"diversity_score"`
	ScoreDelta    int    `json:"score_delta"`
	ConflictNoise int    `json:"conflict_noise"`
	StaleSkips int    `json:"stale_skips"`
}

type agentPayload struct {
	AgentRuns []AgentRun `json:"agent_runs"`
}

// Run loads one bundle using tb_lane, writes /app/output/consensus_audit.json.
func Run() error {
	stem := os.Getenv("tb_lane")
	if stem == "" {
		return errors.New("tb_lane must name a stem under /app/cases")
	}
	emit := "/app/output/consensus_audit.json"
	raw, err := os.ReadFile(filepath.Join("/app", "cases", stem+".json"))
	if err != nil {
		return err
	}
	var bundle hitwire.Bundle
	if err := json.Unmarshal(raw, &bundle); err != nil {
		return err
	}
	trimmed, noise := runClip(bundle.Hits)
	carried := runShift(trimmed, bundle.PairStaleWire)
	view := runSeal(carried, bundle.LiveLaneToken, bundle.RankAnchorHint)
	run := AgentRun{
		ScenarioTag: bundle.ScenarioLabel,
		PrimaryScore: view.PrimaryScore,
		DiversityScore: view.DiversityScore,
		ScoreDelta:    view.ScoreDelta,
		ConflictNoise: noise,
		StaleSkips: view.StaleSkips,
	}
	out := agentPayload{AgentRuns: []AgentRun{run}}
	if err := os.MkdirAll(filepath.Dir(emit), 0o755); err != nil {
		return err
	}
	buf, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		return err
	}
	tmp := emit + ".tmp"
	if err := os.WriteFile(tmp, buf, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, emit)
}

// MainExit is a thin wrapper for cmd.
func MainExit() int {
	if err := Run(); err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		return 1
	}
	return 0
}
