package runner

import (
	"meshbench/hitwire"
	"meshbench/moor_n4"
)

func runSeal(rows []hitwire.HitRow, posted string, anchor *int) moor_n4.Consensus {
	return moor_n4.FoldSpan(rows, posted, anchor)
}
