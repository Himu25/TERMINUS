package runner

import (
	"meshbench/flux_p2"
	"meshbench/hitwire"
)

func runClip(rows []hitwire.HitRow) ([]hitwire.HitRow, int) {
	return flux_p2.ClipSpan(rows)
}
