# Architecture sketch

- `cmd/meshvote` CLI entry (reads `tb_lane` for the cases stem)
- `flux_p2` hit narrowing
- `keel_m8` stale-sentinel walk
- `moor_n4` live-lane / diversity fold via cgo
- `internal/runner` wires stages in that order

## Output shape

`/app/output/consensus_audit.json` carries agent_runs as a single-element array. Each row includes scenario_tag, primary_score, diversity_score, score_delta, conflict_noise, and stale_skips. score_delta is primary_score minus diversity_score.

Bundle JSON under `/app/cases` may include live_lane_token, rank_anchor_hint, and pair_stale_wire alongside the hit tape.

## Scoring semantics

- `primary_score` sums HIT grains whose band matches live_lane_token.
- `diversity_score` sums ALT grains outside the HELD band, unless rank_anchor_hint overrides the total (negative hints clamp to zero).
- Sentinel rows halt later ALT acceptance on the same wire only; other wires keep pairing.
- `stale_skips` counts live-lane HIT rows on wires with no ALT partner in the narrowed tape.
- `conflict_noise` counts duplicate keys dropped during flux narrowing.
