Local smoke: `go build -o /tmp/meshvote ./cmd/meshvote && tb_lane=lane_alpha /tmp/meshvote`
