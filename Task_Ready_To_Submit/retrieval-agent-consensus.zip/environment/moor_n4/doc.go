// Package moor_n4 binds numeric views through a Rust fold library.
package moor_n4
