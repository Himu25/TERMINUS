package main

import (
	"os"

	"meshbench/internal/runner"
)

func main() {
	os.Exit(runner.MainExit())
}
