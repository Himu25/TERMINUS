package hitwire

// HitRow is one replayed line from the vendor or booking side.
type HitRow struct {
	Wire     string `json:"wire_tag"`
	Ink      string `json:"ink"`
	Grain    int    `json:"grain"`
	Face     string `json:"face"`
	Band     string `json:"band"`
	Sentinel bool   `json:"sentinel"`
}

// Bundle is one deterministic scenario under /app/cases.
type Bundle struct {
	ScenarioLabel    string    `json:"scenario_label"`
	LiveLaneToken  string    `json:"live_lane_token"`
	RankAnchorHint *int      `json:"rank_anchor_hint"`
	PairStaleWire string    `json:"pair_stale_wire"`
	Hits             []HitRow `json:"hits"`
}
