// Package hitwire holds wire-tape shapes shared across packages.
package hitwire
