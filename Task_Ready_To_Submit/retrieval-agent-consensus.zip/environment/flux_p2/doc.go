// Package flux_p2 narrows inbound tape rows before pairing.
package flux_p2
