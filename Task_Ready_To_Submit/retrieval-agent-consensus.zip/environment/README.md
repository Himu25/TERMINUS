# Multi-agent retrieval consensus lab

Offline replay harness for parallel retrieval agents under `/app`. Bundled hit tapes live in `/app/cases`; the meshvote binary folds agent lanes into `/app/output/consensus_audit.json`.

Build with `/app/scripts/build.sh`. Run one scenario with `tb_lane=<stem> /app/bin/meshvote`.
