#!/bin/bash
set -euo pipefail

# Mixed Rust/Go link step: CGO_ENABLED=1 binds the Go binary to libmoor_fold.a.
export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1

mkdir -p /app/bin
cd /app/moor_n4
cargo build --release --locked
cd /app
GOFLAGS=-mod=mod go build -o /app/bin/meshvote ./cmd/meshvote
