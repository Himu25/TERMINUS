"""Verifier for multi-agent retrieval consensus audits."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

APP = Path("/app")
REPORT = APP / "output" / "consensus_audit.json"


def _stem_tag(stem: str) -> str:
    bundle = json.loads((APP / "cases" / f"{stem}.json").read_text(encoding="utf-8"))
    return str(bundle["scenario_label"])


def _drive(stem: str) -> dict:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    if REPORT.exists():
        REPORT.unlink()
    subprocess.run(
        ["/app/bin/meshvote"],
        cwd=str(APP),
        env={**os.environ, "tb_lane": stem},
        check=True,
    )
    payload = json.loads(REPORT.read_text(encoding="utf-8"))
    assert "agent_runs" in payload and len(payload["agent_runs"]) == 1
    row = payload["agent_runs"][0]
    assert row.get("scenario_tag") == _stem_tag(stem)
    return row


def _assert_row(
    row: dict,
    *,
    primary_score: int,
    diversity_score: int,
    score_delta: int,
    conflict_noise: int,
    stale_skips: int,
) -> None:
    assert row["primary_score"] == primary_score
    assert row["diversity_score"] == diversity_score
    assert row["score_delta"] == score_delta
    assert row["conflict_noise"] == conflict_noise
    assert row["stale_skips"] == stale_skips


def test_lane_alpha_conflicting_evidence_across_agents() -> None:
    """Shared document fingerprint across agent wires must not collapse distinct retrieval hits."""
    row = _drive("lane_alpha")
    _assert_row(row, primary_score=161, diversity_score=161, score_delta=0, conflict_noise=1, stale_skips=0)


def test_lane_beta_stale_marker_scope() -> None:
    """A stale sentinel on one agent wire must not freeze unrelated agents still expecting ALT lines."""
    row = _drive("lane_beta")
    _assert_row(row, primary_score=70, diversity_score=70, score_delta=0, conflict_noise=0, stale_skips=0)


def test_lane_gamma_shadow_lane_excluded() -> None:
    """Consensus totals must ignore shadow-band hits outside the live lane contract."""
    row = _drive("lane_gamma")
    _assert_row(row, primary_score=10, diversity_score=10, score_delta=0, conflict_noise=0, stale_skips=0)


def test_lane_delta_replay_and_halt() -> None:
    """Duplicate retrieval replay plus per-agent ALT freeze after a stale sentinel."""
    row = _drive("lane_delta")
    _assert_row(row, primary_score=35, diversity_score=35, score_delta=0, conflict_noise=1, stale_skips=0)


def test_lane_peak_composite() -> None:
    """Composite lane mixes duplicate suppression, stale scope, and late ALT lines."""
    row = _drive("lane_peak")
    _assert_row(row, primary_score=16, diversity_score=16, score_delta=0, conflict_noise=1, stale_skips=0)


def test_lane_ozone_anchor_overrides_diversity_sum() -> None:
    """Rank anchor hints interact with live-lane primary score sums."""
    row = _drive("lane_ozone")
    _assert_row(row, primary_score=100, diversity_score=90, score_delta=10, conflict_noise=0, stale_skips=0)


def test_lane_canyon_cross_agent_doc_collision() -> None:
    """Shared document ink on distinct agent wires must survive narrowing with trailing replays."""
    row = _drive("lane_canyon")
    _assert_row(row, primary_score=100, diversity_score=75, score_delta=25, conflict_noise=2, stale_skips=0)


def test_lane_iron_replay_stale_shadow_orphan() -> None:
    """Replay collapse, per-agent halt, shadow exclusion, and stale skip count interact."""
    row = _drive("lane_iron")
    _assert_row(row, primary_score=27, diversity_score=20, score_delta=7, conflict_noise=1, stale_skips=1)


def test_lane_jade_triple_replay_same_agent() -> None:
    """Three identical uploads on one agent wire must count as two conflict_noise events."""
    row = _drive("lane_jade")
    _assert_row(row, primary_score=7, diversity_score=7, score_delta=0, conflict_noise=2, stale_skips=0)


def test_lane_kite_stale_unrelated_agent_alt() -> None:
    """Halting one agent wire must not block ALT or HIT lines on a different agent."""
    row = _drive("lane_kite")
    _assert_row(row, primary_score=125, diversity_score=125, score_delta=0, conflict_noise=0, stale_skips=0)


def test_lane_loom_interleaved_dup_stale() -> None:
    """Interleaved agents with shared document ink and a mid-feed stale marker preserve unrelated pairing."""
    row = _drive("lane_loom")
    _assert_row(row, primary_score=18, diversity_score=18, score_delta=0, conflict_noise=1, stale_skips=0)


def test_lane_nova_full_stack_stress() -> None:
    """Cross-agent dedupe, stale scope, shadow exclusion, and diversity sum divergence together."""
    row = _drive("lane_nova")
    _assert_row(row, primary_score=48, diversity_score=70, score_delta=-22, conflict_noise=1, stale_skips=0)


def test_lane_ridge_trimmed_dedup_and_anchor() -> None:
    """Whitespace-normalized dedup keys, held mirror exclusion, and rank anchor override interact."""
    row = _drive("lane_ridge")
    _assert_row(row, primary_score=35, diversity_score=25, score_delta=10, conflict_noise=1, stale_skips=0)

