The retrieval stack under `/app` replays parallel agent lanes against bundled hit tapes and writes a consensus audit for each scenario. Replays today are unstable: the same bundle can yield different totals, and the reported counters do not match what the hit evidence describes.

Observed mismatches include parallel agents disagreeing on the same document fingerprint across different wires, unrelated feeds stalling once a stale snapshot marker appears, shadow-band rows in live totals, and ranked diversity totals diverging from mirror evidence.

Repair sources under `/app`, run `/app/scripts/build.sh`, set tb_lane to the stem of `/app/cases/<stem>.json`, and run `/app/bin/meshvote`. Output is `/app/output/consensus_audit.json` with agent_runs as a single-entry array. Each row has scenario_tag, primary_score, diversity_score, score_delta, conflict_noise, and stale_skips. Field semantics and pipeline stages are documented in `/app/docs/arch.md`.
