# platform map

Incident tooling lives under `/app/cmd/blast_run` with libraries in `/app/internal` and `/app/pkg`. Rust spanfold staticlib sits at `/app/spanfold` and links through CGO. Archive packs and replay copies sit under `/app/data/`. Output lands at `/app/output/blast_report.json`.

Digest helper for verifier spot checks: `/app/tools/digest_cli`.
