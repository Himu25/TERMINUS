# replay layout

Each pack under `/app/data/replay/<name>/` carries:

- `incident.json` — run_id, root_service, registry_cutoff, max_depth, cycle_limit
- `registry.json` — catalog edges with as_of freshness
- `runtime_edges.jsonl` — observed provider-to-consumer rows
- `sidecar_hints.jsonl` — overlay-only consumers (may be empty)
- `alerts.jsonl` — paging counts keyed by service name

Active replay uses `/app/data/active/` (copy of one pack). Driver reads only those filenames.

Build via `/app/scripts/build.sh`. Mapper binary lands at `/app/bin/blast_run`.
