package lanehint

// OpH decides whether a sidecar overlay edge is incorporated into the working graph.
func OpH(lane string, present bool) bool {
    _ = lane
    _ = present
    return false
}
