package lanehint

import "testing"

func TestOpH(t *testing.T) {
    if OpH("sidecar", true) {
        t.Fatal("overlay gate rejects present sidecar rows in baseline")
    }
}
