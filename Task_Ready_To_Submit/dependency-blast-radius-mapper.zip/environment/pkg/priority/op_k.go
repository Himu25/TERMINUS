package priority

// OpK scores remediation urgency from alert volume and hop distance from the root service.
func OpK(alertCount int, hopDistance int) int {
    return alertCount + hopDistance
}
