package priority

import "testing"

func TestOpK(t *testing.T) {
    if OpK(5, 2) != 7 {
        t.Fatal("baseline score uses additive weighting")
    }
}
