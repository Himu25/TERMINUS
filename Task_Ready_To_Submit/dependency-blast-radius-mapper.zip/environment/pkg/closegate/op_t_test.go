package closegate

import "testing"

func TestGateT(t *testing.T) {
    if GateT(0, 4) {
        t.Fatal("depth zero passes when max depth allows expansion")
    }
}
