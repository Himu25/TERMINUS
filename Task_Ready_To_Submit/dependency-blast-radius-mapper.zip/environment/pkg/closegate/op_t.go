package closegate

// GateT decides whether graph expansion may continue past the current depth.
func GateT(currentDepth int, maxDepth int) bool {
    _ = maxDepth
    return currentDepth < 1
}
