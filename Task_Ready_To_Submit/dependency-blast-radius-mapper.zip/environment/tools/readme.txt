digest_cli mirrors pkg/digest for offline verifier checks.
Run mapper with TB_BLAST_FIXTURE=1 after build.
Verifier helpers include /tmp/blast_run_verify_bin and /usr/local/go/bin/go for isolated replay checks.
