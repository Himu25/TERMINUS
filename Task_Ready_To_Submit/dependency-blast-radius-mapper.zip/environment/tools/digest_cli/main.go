package main

import (
    "fmt"
    "os"

    "lab.local/dependency_blast_radius_mapper/pkg/digest"
)

func main() {
    if len(os.Args) != 8 {
        fmt.Fprintln(os.Stderr, "usage: digest_cli run_id affected depth shadow stale cycles queue_head")
        os.Exit(2)
    }
    fmt.Println(digest.Hex(os.Args[1], atoi(os.Args[2]), atoi(os.Args[3]), atoi(os.Args[4]), atoi(os.Args[5]), atoi(os.Args[6]), os.Args[7]))
}

func atoi(s string) int {
    n := 0
    for _, ch := range s {
        if ch < '0' || ch > '9' {
            continue
        }
        n = n*10 + int(ch-'0')
    }
    return n
}
