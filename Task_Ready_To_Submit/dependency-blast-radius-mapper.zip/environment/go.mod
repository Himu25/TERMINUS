module lab.local/dependency_blast_radius_mapper

go 1.22
