// Report JSON for /app/output/blast_report.json:
//
// schema_version — string, must be "1"
// run_id — string, echoes active pack name
// root_service — failed upstream named in incident.json
// affected_count — downstream services reachable from root through merged edges
// transitive_depth — maximum hop distance from root among affected services
// shadow_merged — count of sidecar overlay edges incorporated
// stale_dropped — registry rows rejected for sitting below registry_cutoff
// cycle_nodes — services flagged while scanning cyclic reach under cycle_limit
// remediation_queue — array sorted by priority_score descending then service ascending;
//   each row carries service, priority_score, hop_distance
// digest_hex — lowercase hex SHA-256 of run_id|affected_count|transitive_depth|shadow_merged|stale_dropped|cycle_nodes|first_queue_service
//
// Root object contains only these keys.
//
// Replay merges registry rows passing freshness cutoff, runtime_edges.jsonl, and
// sidecar_hints.jsonl when the overlay lane is present. Edges aim provider to consumer.
// Breadth-first expansion from root_service continues while depth stays below max_depth.
// Remediation priority_score is alertCount times one hundred minus hopDistance times ten.
// Cycle tally revisits nodes through the spanfold cycle cap helper using cycle_limit.
package main

import (
    "log"
    "os"

    "lab.local/dependency_blast_radius_mapper/internal/driver"
)

func main() {
    if os.Getenv("TB_BLAST_FIXTURE") != "1" {
        log.Fatal("TB_BLAST_FIXTURE unset or not 1")
    }
    rep, err := driver.RunActive("/app")
    if err != nil {
        log.Fatal(err)
    }
    if err := driver.EmitReport("/app/output/blast_report.json", rep); err != nil {
        log.Fatal(err)
    }
}
