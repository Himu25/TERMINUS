package catalog

import "testing"

func TestOpS(t *testing.T) {
    if !OpS(1, 99) {
        t.Fatal("freshness gate rejects all rows in baseline")
    }
}
