package engine

import (
    "lab.local/dependency_blast_radius_mapper/internal/config"
    "lab.local/dependency_blast_radius_mapper/internal/cycletab"
    "lab.local/dependency_blast_radius_mapper/internal/edgefuse"
    "lab.local/dependency_blast_radius_mapper/internal/reach"
    "lab.local/dependency_blast_radius_mapper/internal/score"
    "lab.local/dependency_blast_radius_mapper/pkg/alert"
    "lab.local/dependency_blast_radius_mapper/pkg/graph"
)

type queueRow struct {
    Service       string `json:"service"`
    PriorityScore int    `json:"priority_score"`
    HopDistance   int    `json:"hop_distance"`
}

// Outcome is the folded counters for one pack replay.
type Outcome struct {
    RootService     string
    AffectedCount   int
    TransitiveDepth int
    ShadowMerged    int
    StaleDropped    int
    CycleNodes      int
    Queue           []queueRow
}

// Replay executes one incident pack through the mapper pipeline.
func Replay(inc config.Incident, reg config.RegistryFile, runtime []graph.Edge, hints []config.SidecarHint, alerts []alert.Row) Outcome {
    merged := edgefuse.Merge(inc, reg, runtime, hints)
    walked := reach.Expand(inc.RootService, merged.Edges, inc.MaxDepth)
    ranked := score.Queue(walked.Affected, walked.Hops, alerts)
    cycles := cycletab.Count(merged.Edges, inc.CycleLimit)

    queue := make([]queueRow, len(ranked))
    for i, row := range ranked {
        queue[i] = queueRow{
            Service:       row.Service,
            PriorityScore: row.PriorityScore,
            HopDistance:   row.HopDistance,
        }
    }

    return Outcome{
        RootService:     inc.RootService,
        AffectedCount:   len(walked.Affected),
        TransitiveDepth: walked.MaxHop,
        ShadowMerged:    merged.ShadowMerged,
        StaleDropped:    merged.StaleDropped,
        CycleNodes:      cycles,
        Queue:           queue,
    }
}
