package edgefuse

import (
    "lab.local/dependency_blast_radius_mapper/internal/catalog"
    "lab.local/dependency_blast_radius_mapper/internal/config"
    "lab.local/dependency_blast_radius_mapper/pkg/graph"
    "lab.local/dependency_blast_radius_mapper/pkg/lanehint"
)

// Bundle holds merged edges plus bookkeeping counters.
type Bundle struct {
    Edges        []graph.Edge
    StaleDropped int
    ShadowMerged int
}

// Merge combines catalog, runtime, and overlay inputs into one edge list.
func Merge(inc config.Incident, reg config.RegistryFile, runtime []graph.Edge, hints []config.SidecarHint) Bundle {
    edges := make([]graph.Edge, 0, len(reg.Edges)+len(runtime)+len(hints))
    stale := 0
    for _, row := range reg.Edges {
        if catalog.OpS(row.AsOf, inc.RegistryCutoff) {
            edges = append(edges, graph.Edge{Provider: row.Provider, Consumer: row.Consumer})
            continue
        }
        stale++
    }
    edges = append(edges, runtime...)
    shadow := 0
    for _, hint := range hints {
        if lanehint.OpH(hint.Lane, hint.Provider != "" && hint.Consumer != "") {
            edges = append(edges, graph.Edge{Provider: hint.Provider, Consumer: hint.Consumer})
            shadow++
        }
    }
    return Bundle{Edges: edges, StaleDropped: stale, ShadowMerged: shadow}
}
