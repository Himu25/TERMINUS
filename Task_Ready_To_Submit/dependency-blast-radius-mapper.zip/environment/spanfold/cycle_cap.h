#ifndef SPANFOLD_CYCLE_CAP_H
#define SPANFOLD_CYCLE_CAP_H

#include <stdint.h>

int sg_cycle_cap(int visit_count, int limit);

#endif
