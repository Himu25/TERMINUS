package spanfold

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libspanfold.a -ldl -lm
#include "cycle_cap.h"
*/
import "C"

// CycleCap advances a cycle visit counter under the configured limit.
func CycleCap(visitCount int, limit int) int {
	return int(C.sg_cycle_cap(C.int(visitCount), C.int(limit)))
}
