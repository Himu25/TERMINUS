"""Validate /app/output/feature_fresh_bench.json against fresh.toml guardrails."""

from __future__ import annotations

import contextlib
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "feature_fresh_bench.json"
CFG = APP / "config" / "fresh.toml"
MANIFEST = APP / "registry" / "fresh_manifest.json"
STREAMS = APP / "data" / "streams_default.jsonl"


def _fixture(name: str) -> Path:
    root = Path(__file__).resolve().parent
    for child in root.iterdir():
        if child.is_dir():
            candidate = child / name
            if candidate.is_file():
                return candidate
    raise FileNotFoundError(name)

REPORT_KEYS = frozenset(
    {
        "status",
        "entity_total",
        "consumer_count",
        "fresh_profile",
        "streams_total",
        "mean_feature_integrity",
        "mean_freshness_score",
        "mean_propagation_units",
        "mean_stale_units",
        "p95_material_units",
        "mean_balance_score",
        "dedup_purity_rate",
        "timestamp_order_rate",
        "mean_consumer_lag_units",
        "report_digest",
        "streams",
    }
)
STREAM_KEYS = frozenset(
    {
        "stream_id",
        "feature_integrity",
        "freshness_score",
        "propagation_units",
        "stale_units",
        "consumer_lag_units",
        "dedup_purity",
        "timestamp_order_rate",
        "workers_active",
        "balance_score",
        "entity_ids",
    }
)

_SUBPROC_ENV = os.environ.copy()
_path_prefix = "/usr/local/go/bin:/app/bin:"
_SUBPROC_ENV["PATH"] = _path_prefix + _SUBPROC_ENV.get("PATH", "")
_SUBPROC_ENV["LD_LIBRARY_PATH"] = "/app/lib:" + _SUBPROC_ENV.get("LD_LIBRARY_PATH", "")
_GO_BUILD_TIMEOUT = 45
_RUST_BUILD_TIMEOUT = 90
_RUN_TIMEOUT = 30

# Shipped fresh.toml defaults; enforced so lowering fresh.toml cannot pass quality checks.
ENFORCED_FLOORS: dict[str, float] = {
    "integrity_floor": 0.98,
    "freshness_floor": 0.95,
    "balance_floor": 0.72,
    "dedup_purity_floor": 0.95,
    "timestamp_order_floor": 0.95,
    "failover_integrity_floor": 0.9,
    "skew_balance_min": 0.65,
    "unicode_mix_integrity_floor": 0.9999,
}
ENFORCED_CEILINGS: dict[str, float | int] = {
    "max_mean_propagation_units": 2200,
    "max_mean_stale_units": 1200,
    "max_p95_material_units": 9000,
    "max_mean_consumer_lag_units": 800,
    "unicode_mix_max_stale_units": 0,
}

REQUIRED_STREAM_IDS = frozenset(
    {
        "s_unicode_mix",
        "s_size_skew",
        "s_consumer_lag",
        "s_clock_skew",
        "s_dup_burst",
        "s_failover_lane",
        "s_failover_multi",
    }
)

VF_HARNESS = Path("/opt/tb-vf-harness/rebuild.sh")


def _stream_spec_count() -> int:
    specs = APP / "data" / "stream_specs.jsonl"
    return len([ln for ln in specs.read_text(encoding="utf-8").splitlines() if ln.strip()])


def _stream_ids_from_specs() -> set[str]:
    specs = APP / "data" / "stream_specs.jsonl"
    ids: set[str] = set()
    for line in specs.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        ids.add(json.loads(line)["stream_id"])
    return ids


def _effective_floor(cfg: dict, key: str) -> float:
    return max(cfg[key], ENFORCED_FLOORS[key])


def _effective_ceiling(cfg: dict, key: str) -> float | int:
    return min(cfg[key], ENFORCED_CEILINGS[key])


def _parse_cfg() -> dict:
    cfg: dict = {
        "consumer_count": 4,
        "fresh_profile": "v3",
        "integrity_floor": 0.98,
        "freshness_floor": 0.95,
        "max_mean_propagation_units": 2200,
        "max_mean_stale_units": 1200,
        "max_p95_material_units": 9000,
        "balance_floor": 0.72,
        "dedup_purity_floor": 0.95,
        "timestamp_order_floor": 0.95,
        "max_mean_consumer_lag_units": 800,
        "failover_integrity_floor": 0.9,
        "skew_balance_min": 0.65,
        "unicode_mix_integrity_floor": 0.9999,
        "unicode_mix_max_stale_units": 0,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in (
            "integrity_floor",
            "freshness_floor",
            "balance_floor",
            "dedup_purity_floor",
            "timestamp_order_floor",
            "failover_integrity_floor",
            "skew_balance_min",
            "unicode_mix_integrity_floor",
        ):
            cfg[key] = float(val)
        elif key in (
            "consumer_count",
            "max_mean_propagation_units",
            "max_mean_stale_units",
            "max_p95_material_units",
            "max_mean_consumer_lag_units",
            "unicode_mix_max_stale_units",
        ):
            cfg[key] = int(float(val))
        elif key == "fresh_profile":
            cfg[key] = val
    return cfg


def _digest_payload(report: dict) -> dict:
    return {
        "status": report["status"],
        "entity_total": report["entity_total"],
        "consumer_count": report["consumer_count"],
        "fresh_profile": report["fresh_profile"],
        "streams_total": report["streams_total"],
        "mean_feature_integrity": report["mean_feature_integrity"],
        "mean_freshness_score": report["mean_freshness_score"],
        "mean_propagation_units": report["mean_propagation_units"],
        "mean_stale_units": report["mean_stale_units"],
        "p95_material_units": report["p95_material_units"],
        "mean_balance_score": report["mean_balance_score"],
        "dedup_purity_rate": report["dedup_purity_rate"],
        "timestamp_order_rate": report["timestamp_order_rate"],
        "mean_consumer_lag_units": report["mean_consumer_lag_units"],
        "report_digest": "",
        "streams": report["streams"],
    }


def _report_digest_hex(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _verifier_full_rebuild() -> None:
    """Rebuild Rust and Go artifacts using the verifier-frozen harness script."""
    assert VF_HARNESS.is_file(), "missing verifier-controlled rebuild harness"
    subprocess.run(
        ["bash", str(VF_HARNESS)],
        cwd=APP,
        check=True,
        timeout=_RUST_BUILD_TIMEOUT + _GO_BUILD_TIMEOUT,
        env=_SUBPROC_ENV,
    )


def _rebuild_rust_lib() -> None:
    """Rebuild only the Rust helper; Go binaries are rebuilt separately."""
    env = dict(_SUBPROC_ENV)
    env["CARGO_TARGET_DIR"] = str(APP / "output" / "cargo-target")
    subprocess.run(
        ["cargo", "build", "--release", "--locked"],
        cwd=APP / "zfold",
        check=True,
        timeout=_RUST_BUILD_TIMEOUT,
        env=env,
    )
    lib_src = APP / "output" / "cargo-target" / "release" / "libzetacore.so"
    subprocess.run(
        ["install", "-m", "0644", str(lib_src), str(APP / "lib" / "libzetacore.so")],
        check=True,
        timeout=10,
    )


def _go_rebuild_and_run(
    streams_path: Path | None = None,
    out_path: Path | None = None,
) -> dict:
    """Rebuild only featurebench and run on the default stream pack."""
    streams_path = streams_path or STREAMS
    out_path = out_path or OUT
    env = dict(_SUBPROC_ENV)
    lib_dir = str(APP / "lib")
    env["CGO_LDFLAGS"] = f"-L{lib_dir} -lzetacore"
    out_path.unlink(missing_ok=True)
    subprocess.run(
        ["go", "build", "-o", str(APP / "bin" / "featurebench"), "./cmd/featurebench"],
        cwd=APP,
        check=True,
        timeout=_GO_BUILD_TIMEOUT,
        env=env,
    )
    subprocess.run(
        ["/app/bin/featurebench", streams_path.as_posix(), out_path.as_posix()],
        cwd=APP,
        check=True,
        timeout=_RUN_TIMEOUT,
        env=env,
    )
    return json.loads(out_path.read_text(encoding="utf-8"))


def _rebuild_and_run(
    streams_path: Path | None = None,
    out_path: Path | None = None,
) -> dict:
    """Rust lib + featurebench rebuild for ablation swaps that touch lib.rs."""
    streams_path = streams_path or STREAMS
    out_path = out_path or OUT
    out_path.unlink(missing_ok=True)
    _rebuild_rust_lib()
    return _go_rebuild_and_run(streams_path=streams_path, out_path=out_path)


@contextlib.contextmanager
def _swap_file(src: Path, dst: Path):
    """Temporarily replace dst with src, restoring original on exit."""
    backup = dst.read_bytes()
    shutil.copy2(src, dst)
    os.utime(dst)
    try:
        yield
    finally:
        dst.write_bytes(backup)


def _stream_rows(report: dict) -> dict[str, dict]:
    return {row["stream_id"]: row for row in report["streams"]}


@pytest.fixture(scope="module", autouse=True)
def _warm_verifier_build_cache() -> None:
    """Prime Go/Rust build caches once so ablation rebuilds stay incremental."""
    if not (APP / "bin" / "featurebench").is_file():
        _verifier_full_rebuild()


@pytest.fixture(scope="module")
def cfg() -> dict:
    return _parse_cfg()


@pytest.fixture(scope="module")
def default_report() -> dict:
    if not OUT.is_file():
        pytest.fail(f"missing agent output at {OUT}")
    try:
        return json.loads(OUT.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        pytest.fail(f"invalid JSON at {OUT}: {exc}")


def test_fresh_toml_floors_not_lowered(cfg: dict) -> None:
    """Shipped fresh.toml quality floors must not be lowered or ceilings raised."""
    for key, minimum in ENFORCED_FLOORS.items():
        assert cfg[key] == minimum, f"{key} changed from shipped floor {minimum}"
    for key, maximum in ENFORCED_CEILINGS.items():
        assert cfg[key] == maximum, f"{key} changed from shipped ceiling {maximum}"


def test_stream_specs_cover_instruction_scenarios() -> None:
    """Default stream_specs.jsonl must retain every instruction-named scenario row."""
    assert REQUIRED_STREAM_IDS <= _stream_ids_from_specs()


def test_report_schema_and_digest(default_report: dict) -> None:
    """Top-level schema and report_digest must match compact pre-digest JSON."""
    assert set(default_report.keys()) == REPORT_KEYS
    assert re.fullmatch(r"[0-9a-f]{64}", default_report["report_digest"])
    assert default_report["report_digest"] == _report_digest_hex(default_report)
    for row in default_report["streams"]:
        assert set(row.keys()) == STREAM_KEYS


def test_default_pack_quality_floors(default_report: dict, cfg: dict) -> None:
    """Default stream pack must meet fresh.toml mean floors and ceilings."""
    assert default_report["status"] == "ok"
    assert default_report["streams_total"] == _stream_spec_count()
    assert default_report["mean_feature_integrity"] >= _effective_floor(cfg, "integrity_floor")
    assert default_report["mean_freshness_score"] >= _effective_floor(cfg, "freshness_floor")
    assert int(default_report["mean_propagation_units"]) <= _effective_ceiling(
        cfg, "max_mean_propagation_units"
    )
    assert int(default_report["mean_stale_units"]) <= _effective_ceiling(cfg, "max_mean_stale_units")
    assert default_report["p95_material_units"] <= _effective_ceiling(cfg, "max_p95_material_units")
    assert default_report["mean_balance_score"] >= _effective_floor(cfg, "balance_floor")
    assert default_report["dedup_purity_rate"] >= _effective_floor(cfg, "dedup_purity_floor")
    assert default_report["timestamp_order_rate"] >= _effective_floor(cfg, "timestamp_order_floor")
    assert int(default_report["mean_consumer_lag_units"]) <= _effective_ceiling(
        cfg, "max_mean_consumer_lag_units"
    )


def test_unicode_mix_stream_row(default_report: dict, cfg: dict) -> None:
    """s_unicode_mix must reach full feature integrity on unicode-heavy entities."""
    row = _stream_rows(default_report)["s_unicode_mix"]
    assert row["feature_integrity"] >= _effective_floor(cfg, "unicode_mix_integrity_floor")
    assert row["stale_units"] <= _effective_ceiling(cfg, "unicode_mix_max_stale_units")


def test_consumer_lag_stream_freshness(default_report: dict, cfg: dict) -> None:
    """Delayed read window on s_consumer_lag must still meet freshness_floor."""
    row = _stream_rows(default_report)["s_consumer_lag"]
    assert row["freshness_score"] >= _effective_floor(cfg, "freshness_floor")
    assert row["feature_integrity"] >= _effective_floor(cfg, "integrity_floor")


def test_clock_skew_timestamp_order(default_report: dict, cfg: dict) -> None:
    """Ingest skew on s_clock_skew must still yield timestamp_order_rate at floor."""
    row = _stream_rows(default_report)["s_clock_skew"]
    assert row["timestamp_order_rate"] >= _effective_floor(cfg, "timestamp_order_floor")


def test_dup_burst_dedup_purity(default_report: dict, cfg: dict) -> None:
    """Duplicate replay on s_dup_burst must meet dedup_purity on the stream row."""
    row = _stream_rows(default_report)["s_dup_burst"]
    assert row["dedup_purity"] >= _effective_floor(cfg, "dedup_purity_floor")


def test_failover_streams_keep_integrity(default_report: dict, cfg: dict) -> None:
    """Failover streams must stay above failover_integrity_floor with reduced workers_active."""
    rows = _stream_rows(default_report)
    fail = rows["s_failover_lane"]
    multi = rows["s_failover_multi"]
    assert fail["workers_active"] == cfg["consumer_count"] - 1
    assert multi["workers_active"] == cfg["consumer_count"] - 2
    assert fail["feature_integrity"] >= _effective_floor(cfg, "failover_integrity_floor")
    assert multi["feature_integrity"] >= _effective_floor(cfg, "failover_integrity_floor")


def test_size_skew_balance_floor(default_report: dict, cfg: dict) -> None:
    """Uneven entity payload sizes must still yield balance_score at or above skew_balance_min."""
    row = _stream_rows(default_report)["s_size_skew"]
    assert row["balance_score"] >= _effective_floor(cfg, "skew_balance_min")


def test_fresh_profile_matches_manifest(default_report: dict, cfg: dict) -> None:
    """fresh_profile in the report must match registry fresh_manifest.json."""
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    assert default_report["fresh_profile"] == manifest["fresh_profile"]
    assert default_report["fresh_profile"] == cfg["fresh_profile"]


def test_determinism_repeat_run(default_report: dict) -> None:
    """Identical inputs must yield byte-identical feature_fresh_bench.json."""
    first = OUT.read_bytes()
    OUT.unlink(missing_ok=True)
    subprocess.run(
        ["/app/bin/featurebench", STREAMS.as_posix(), OUT.as_posix()],
        cwd=APP,
        check=True,
        timeout=_RUN_TIMEOUT,
        env=_SUBPROC_ENV,
    )
    second = OUT.read_bytes()
    assert first == second


def test_z_ablation_m1_fails_freshness() -> None:
    """Truncated read window must not satisfy freshness on s_consumer_lag."""
    with _swap_file(_fixture("z_w1.go"), APP / "ax" / "w1.go"):
        report = _go_rebuild_and_run(out_path=APP / "output" / "feature_ablation_m1.json")
    cfg = _parse_cfg()
    row = _stream_rows(report)["s_consumer_lag"]
    assert report["status"] == "fail" or row["freshness_score"] < _effective_floor(
        cfg, "freshness_floor"
    )


def test_z_ablation_m2_fails_timestamp_rate() -> None:
    """Ingest-time sort key must drop timestamp_order_rate on s_clock_skew."""
    with _swap_file(_fixture("z_w2.go"), APP / "bx" / "w2.go"):
        report = _go_rebuild_and_run(out_path=APP / "output" / "feature_ablation_m2.json")
    cfg = _parse_cfg()
    row = _stream_rows(report)["s_clock_skew"]
    assert row["timestamp_order_rate"] < _effective_floor(cfg, "timestamp_order_floor")


def test_z_ablation_m3_fails_purity() -> None:
    """Entity-only seq gate must collapse dedup_purity on s_dup_burst."""
    with _swap_file(_fixture("z_w3.go"), APP / "cx" / "w3.go"):
        report = _go_rebuild_and_run(out_path=APP / "output" / "feature_ablation_m3.json")
    cfg = _parse_cfg()
    row = _stream_rows(report)["s_dup_burst"]
    assert row["dedup_purity"] < _effective_floor(cfg, "dedup_purity_floor")


def test_z_ablation_m4_fails_integrity() -> None:
    """Prefix-only slot keys must drop feature_integrity on s_consumer_lag."""
    with _swap_file(_fixture("z_w6.go"), APP / "dx" / "w6.go"):
        report = _go_rebuild_and_run(out_path=APP / "output" / "feature_ablation_m4.json")
    row = _stream_rows(report)["s_consumer_lag"]
    assert row["feature_integrity"] < 1.0
    assert row["stale_units"] > 0


def test_z_ablation_m5_fails_balance() -> None:
    """Single-lane assignment must fail balance on s_size_skew."""
    with _swap_file(_fixture("z_w5.go"), APP / "cx" / "w5.go"):
        report = _go_rebuild_and_run(out_path=APP / "output" / "feature_ablation_m5.json")
    cfg = _parse_cfg()
    row = _stream_rows(report)["s_size_skew"]
    assert row["balance_score"] < _effective_floor(cfg, "skew_balance_min")


def test_z_ablation_m6_fails_unicode() -> None:
    """Broken Rust normalization must collapse feature_integrity on s_unicode_mix."""
    with _swap_file(_fixture("z_r1.rs"), APP / "zfold" / "src" / "lib.rs"):
        report = _rebuild_and_run(out_path=APP / "output" / "feature_ablation_m6.json")
    row = _stream_rows(report)["s_unicode_mix"]
    assert row["feature_integrity"] < 0.95
