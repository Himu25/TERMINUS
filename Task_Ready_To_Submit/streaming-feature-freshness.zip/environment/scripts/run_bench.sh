#!/bin/bash
set -euo pipefail

STREAMS="${1:-/app/data/streams_default.jsonl}"
OUT="${2:-/app/output/feature_fresh_bench.json}"

export LD_LIBRARY_PATH="/app/lib:${LD_LIBRARY_PATH:-}"
exec /app/bin/featurebench "${STREAMS}" "${OUT}"
