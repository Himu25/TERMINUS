#!/bin/bash
set -euo pipefail

ROOT="/app"
export CGO_LDFLAGS="-L${ROOT}/lib -lzetacore"
export LD_LIBRARY_PATH="${ROOT}/lib:${LD_LIBRARY_PATH:-}"
cd "${ROOT}"
go build -o "${ROOT}/bin/featurebench" ./cmd/featurebench
