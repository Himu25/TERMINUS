package corpus

import (
	"encoding/json"
	"os"

	"freshlab.dev/featurestream/pkg/types"
)

const DefaultCorpusPath = "/app/data/entities_default.json"

func Load(path string) ([]types.Entity, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var entities []types.Entity
	if err := json.Unmarshal(raw, &entities); err != nil {
		return nil, err
	}
	return entities, nil
}

func ByID(entities []types.Entity) map[string]types.Entity {
	out := make(map[string]types.Entity, len(entities))
	for _, e := range entities {
		out[e.ID] = e
	}
	return out
}
