package cx

import (
	"freshlab.dev/featurestream/pkg/types"
)

// KpBx assigns entities to consumer lanes for one stream scenario.
func KpBx(entities []types.Entity, workers int) [][]types.Entity {
	if workers < 1 {
		workers = 1
	}
	out := make([][]types.Entity, workers)
	for _, ent := range entities {
		out[0] = append(out[0], ent)
	}
	return out
}
