# Architecture notes

Entity snapshots live at `/app/data/entities_default.json`. Stream scenarios are JSONL with stream_id, entity_ids, and optional dead_workers, ingest_skew_ms, dup_replay, or lag_cap_units. The Go driver `/app/bin/featurebench` loads `/app/config/fresh.toml`, materializes payloads through the Rust helper built from `/app/zfold`, and writes `/app/output/feature_fresh_bench.json`. Rebuild with `/app/scripts/build_all.sh`, use `/app/scripts/rebuild_go.sh` after Go-only hook edits, and run `/app/scripts/run_bench.sh`.

Top-level report keys: status, entity_total, consumer_count, fresh_profile, streams_total, mean_feature_integrity, mean_freshness_score, mean_propagation_units, mean_stale_units, p95_material_units, mean_balance_score, dedup_purity_rate, timestamp_order_rate, mean_consumer_lag_units, report_digest, streams.

Each streams row: stream_id, feature_integrity, freshness_score, propagation_units, stale_units, consumer_lag_units, dedup_purity, timestamp_order_rate, workers_active, balance_score, entity_ids. feature_integrity is the fraction of entities whose materialized digest matches the canonical fold in `ledger/fold.go`. Unit fields are synthetic cost tallies, not wall-clock timings.

## Digest contracts

Two digest rules apply; do not mix them.

**report_digest** — Take every top-level report field except report_digest. Build a JSON object with those values, set report_digest to the empty string, and serialize as compact JSON (no insignificant whitespace; non-ASCII string content preserved). Hash the UTF-8 bytes of that serialization with SHA-256; report_digest is the lowercase hex digest. featurebench computes this from the final rounded metrics before writing the indented report file.

**Canonical payload fold** (`ledger/fold.go` `DgFold`, used for feature_integrity and refgen digest maps) — Start from the full entity payload string (the `text` field). Apply Unicode NFKC normalization, convert to lowercase, split on Unicode whitespace runs, drop empty tokens, join the remaining tokens with one ASCII space (0x20), UTF-8-encode that joined string, SHA-256 those bytes, emit lowercase hex. Materialized digests from the Rust helper must match this fold for integrity credit.

propagation_units adds a serial penalty when fewer consumers are active than consumer_count. stale_units counts extra rune work when a hot slot returns a digest that does not match the canonical fold. mean_consumer_lag_units averages synthetic lag tallies from the ordered event log.

## Hygiene metrics

**dedup_purity** (per stream) and **dedup_purity_rate** (report mean) count events accepted by the dedup gate versus every event presented after the read window, before lane assignment. Rejections at the gate reduce the ratio; measuring only unique entities in the accepted batch does not.

**timestamp_order_rate** (per stream and report mean) is computed on the event log after it is sorted with the ordering key from the bx module. Among adjacent pairs in that sorted order, the rate is the fraction whose event-time field is non-decreasing. Clock-skew scenarios only pass when the ordering key follows event time, not ingest time.

**balance_score** (per stream) and **mean_balance_score** (report mean) compare rune load across live lanes that received work: one minus the spread between the heaviest and lightest lane divided by total runes. When multiple consumers are configured and no lanes are marked dead, routing all payload runes through a single active lane yields zero balance.

## Pipeline stages

The driver invokes package modules in a fixed chain; repairs belong inside these hooks rather than bypassing them in the driver.

1. **ax** — read-window trimming and lag tallies on the ordered log.
2. **bx** — ordering key selection and event-time watermark after sort.
3. **cx** — dedup gate (`KpAccept` tracks entity plus sequence pairs; `KpReset` clears state between stream scenarios), active worker count, and lane assignment for accepted entities.
4. **dx** — digest cache slots and materialization calls into the Rust helper.
5. **zfold** — canonical payload fold used for integrity credit and refgen digests.

feature_integrity and stale_units must continue to flow through the dx cache path so prefix-only or colliding slot keys surface as stale work. Freshness credit uses the bx watermark on accepted events.

Quality gates compare means against floors and ceilings in fresh.toml. Failover streams list dead_workers; only live consumers participate. Regenerate the default stream pack with `/app/bin/refgen` after entity edits.

Verifier runs may write scratch JSON under `/app/output/` (for example `feature_fresh_bench.json` and internal ablation copies). Grading prepends `/usr/local/go/bin:/app/bin:` to PATH when invoking featurebench.
