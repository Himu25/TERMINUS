Streaming feature freshness lab under /app simulates online feature updates with Go consumers and a Rust materializer. See architecture.md for report schema and bench entrypoints.
