package types

type FreshCfg struct {
	CorpusPath               string
	ConsumerCount            int
	FreshProfile             string
	IntegrityFloor           float64
	MaxMeanPropagationUnits  int
	MaxMeanStaleUnits        int
	MaxP95MaterialUnits      int
	BalanceFloor             float64
	FreshnessFloor           float64
	DedupPurityFloor         float64
	TimestampOrderFloor      float64
	MaxMeanConsumerLagUnits  int
	FailoverIntegrityFloor   float64
	SkewBalanceMin           float64
}

type Entity struct {
	ID      string `json:"id"`
	Payload string `json:"text"`
	Lang    string `json:"lang"`
}

type StreamEvent struct {
	EntityID string `json:"entity_id"`
	Seq      uint64 `json:"seq"`
	EventMs  int64  `json:"event_ms"`
	IngestMs int64  `json:"ingest_ms"`
	Payload  string `json:"payload"`
}

type StreamCase struct {
	StreamID      string   `json:"stream_id"`
	EntityIDs     []string `json:"entity_ids"`
	DeadWorkers   []int    `json:"dead_workers"`
	IngestSkewMs  int      `json:"ingest_skew_ms"`
	DupReplay     int      `json:"dup_replay"`
	LagCapUnits   int      `json:"lag_cap_units"`
}

type StreamRow struct {
	StreamID           string   `json:"stream_id"`
	FeatureIntegrity   float64  `json:"feature_integrity"`
	FreshnessScore     float64  `json:"freshness_score"`
	PropagationUnits   int      `json:"propagation_units"`
	StaleUnits         int      `json:"stale_units"`
	ConsumerLagUnits   int      `json:"consumer_lag_units"`
	DedupPurity        float64  `json:"dedup_purity"`
	TimestampOrderRate float64  `json:"timestamp_order_rate"`
	WorkersActive      int      `json:"workers_active"`
	BalanceScore       float64  `json:"balance_score"`
	EntityIDs          []string `json:"entity_ids"`
}

type FreshReport struct {
	Status                 string      `json:"status"`
	EntityTotal            int         `json:"entity_total"`
	ConsumerCount          int         `json:"consumer_count"`
	FreshProfile           string      `json:"fresh_profile"`
	StreamsTotal           int         `json:"streams_total"`
	MeanFeatureIntegrity   float64     `json:"mean_feature_integrity"`
	MeanFreshnessScore     float64     `json:"mean_freshness_score"`
	MeanPropagationUnits   float64     `json:"mean_propagation_units"`
	MeanStaleUnits         float64     `json:"mean_stale_units"`
	P95MaterialUnits       int         `json:"p95_material_units"`
	MeanBalanceScore       float64     `json:"mean_balance_score"`
	DedupPurityRate        float64     `json:"dedup_purity_rate"`
	TimestampOrderRate     float64     `json:"timestamp_order_rate"`
	MeanConsumerLagUnits   float64     `json:"mean_consumer_lag_units"`
	ReportDigest           string      `json:"report_digest"`
	Streams                []StreamRow `json:"streams"`
}
