package bench

import (
	"bufio"
	"encoding/json"
	"os"
	"strconv"
	"strings"

	"freshlab.dev/featurestream/pkg/types"
)

func LoadCfg(path string) (types.FreshCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.FreshCfg{}, err
	}
	cfg := types.FreshCfg{
		CorpusPath:              "/app/data/entities_default.json",
		ConsumerCount:           4,
		FreshProfile:            "v3",
		IntegrityFloor:          0.98,
		MaxMeanPropagationUnits: 2200,
		MaxMeanStaleUnits:       1200,
		MaxP95MaterialUnits:     9000,
		BalanceFloor:            0.72,
		FreshnessFloor:          0.95,
		DedupPurityFloor:        0.95,
		TimestampOrderFloor:     0.95,
		MaxMeanConsumerLagUnits: 800,
		FailoverIntegrityFloor:  0.90,
		SkewBalanceMin:          0.65,
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		parts := strings.SplitN(line, "=", 2)
		if len(parts) != 2 {
			continue
		}
		key := strings.TrimSpace(parts[0])
		val := strings.TrimSpace(parts[1])
		switch key {
		case "corpus_path":
			cfg.CorpusPath = val
		case "consumer_count":
			cfg.ConsumerCount, _ = strconv.Atoi(val)
		case "fresh_profile":
			cfg.FreshProfile = val
		case "integrity_floor", "freshness_floor", "balance_floor", "dedup_purity_floor",
			"timestamp_order_floor", "failover_integrity_floor", "skew_balance_min":
			cfg, err = setFloatField(cfg, key, val)
			if err != nil {
				return types.FreshCfg{}, err
			}
		case "max_mean_propagation_units", "max_mean_stale_units", "max_p95_material_units",
			"max_mean_consumer_lag_units":
			cfg, err = setIntField(cfg, key, val)
			if err != nil {
				return types.FreshCfg{}, err
			}
		}
	}
	return cfg, nil
}

func setFloatField(cfg types.FreshCfg, key, val string) (types.FreshCfg, error) {
	f, err := strconv.ParseFloat(val, 64)
	if err != nil {
		return cfg, err
	}
	switch key {
	case "integrity_floor":
		cfg.IntegrityFloor = f
	case "freshness_floor":
		cfg.FreshnessFloor = f
	case "balance_floor":
		cfg.BalanceFloor = f
	case "dedup_purity_floor":
		cfg.DedupPurityFloor = f
	case "timestamp_order_floor":
		cfg.TimestampOrderFloor = f
	case "failover_integrity_floor":
		cfg.FailoverIntegrityFloor = f
	case "skew_balance_min":
		cfg.SkewBalanceMin = f
	}
	return cfg, nil
}

func setIntField(cfg types.FreshCfg, key, val string) (types.FreshCfg, error) {
	i, err := strconv.Atoi(val)
	if err != nil {
		return cfg, err
	}
	switch key {
	case "max_mean_propagation_units":
		cfg.MaxMeanPropagationUnits = i
	case "max_mean_stale_units":
		cfg.MaxMeanStaleUnits = i
	case "max_p95_material_units":
		cfg.MaxP95MaterialUnits = i
	case "max_mean_consumer_lag_units":
		cfg.MaxMeanConsumerLagUnits = i
	}
	return cfg, nil
}

func LoadStreams(path string) ([]types.StreamCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	var out []types.StreamCase
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var row types.StreamCase
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return nil, err
		}
		out = append(out, row)
	}
	return out, sc.Err()
}
