#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

log "preflight: streaming feature freshness workspace"
test -f /app/go.mod
test -f /app/config/fresh.toml
test -f /app/data/entities_default.json
test -f /app/data/stream_specs.jsonl
mkdir -p /app/bin /app/lib /app/output

log "survey: guardrails and subsystem layout"
grep -nE 'freshness|propagation|integrity|timestamp|lag' \
  /app/config/fresh.toml /app/metrics/guardrails.txt /app/policies/retention.txt 2>/dev/null | head -n 20 || true
wc -l /app/bench/drive.go /app/scripts/build_all.sh

log "apply oracle patches to streaming subsystems (idempotent overwrite)"
for pair in \
  w1.go:ax/w1.go \
  w2.go:bx/w2.go \
  w3.go:cx/w3.go \
  w4.go:cx/w4.go \
  w5.go:cx/w5.go \
  w6.go:dx/w6.go; do
  src="${ROOT_DIR}/oracle/${pair%%:*}"
  dst="/app/${pair#*:}"
  test -f "${src}"
  install -m 0644 "${src}" "${dst}"
done
install -m 0644 "${ROOT_DIR}/oracle/r1.rs" /app/zfold/src/lib.rs

log "rebuild Rust shared library and Go featurebench driver"
bash /app/scripts/build_all.sh

log "regenerate default stream pack after materializer repair"
/app/bin/refgen \
  /app/data/entities_default.json \
  /app/data/stream_specs.jsonl \
  /app/data/streams_default.jsonl

log "run default feature freshness bench report"
export LD_LIBRARY_PATH="/app/lib:${LD_LIBRARY_PATH:-}"
chmod +x /app/scripts/run_bench.sh
/app/scripts/run_bench.sh /app/data/streams_default.jsonl /app/output/feature_fresh_bench.json

log "done"
