#!/bin/bash
set -euo pipefail

export PATH="/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/phase_k2/scan.go <<'EOF'
package phase_k2

import (
	"regexp"
	"strconv"
	"strings"

	"auroracomp/pack_io"
)

var (
	openRe = regexp.MustCompile(`^<<<DECISION seq=(\d+) status=(\w+)(?: supersedes=([\d,]+))?>>>`)
	closeT = "<<<END>>>"
)

// ScanRaw walks the dossier and collects decision payloads in file order.
func ScanRaw(raw string) ([]pack_io.DecisionBlock, int) {
	lines := strings.Split(raw, "\n")
	out := make([]pack_io.DecisionBlock, 0)
	rejected := 0
	i := 0
	for i < len(lines) {
		line := strings.TrimSpace(lines[i])
		m := openRe.FindStringSubmatch(line)
		if m == nil {
			i++
			continue
		}
		seq, _ := strconv.Atoi(m[1])
		status := strings.ToLower(m[2])
		var sup []int
		if m[3] != "" {
			for _, part := range strings.Split(m[3], ",") {
				part = strings.TrimSpace(part)
				if part == "" {
					continue
				}
				n, _ := strconv.Atoi(part)
				sup = append(sup, n)
			}
		}
		fields := map[string]string{}
		runName := ""
		i++
		for i < len(lines) && strings.TrimSpace(lines[i]) != closeT {
			row := strings.TrimSpace(lines[i])
			if row == "" {
				i++
				continue
			}
			if idx := strings.Index(row, ":"); idx > 0 {
				key := strings.TrimSpace(row[:idx])
				val := strings.TrimSpace(row[idx+1:])
				fields[key] = val
				if key == "run_name" {
					runName = val
				}
			}
			i++
		}
		if status == "rejected" {
			rejected++
		}
		out = append(out, pack_io.DecisionBlock{
			Seq:        seq,
			Status:     status,
			Supersedes: sup,
			Fields:     fields,
			RunName:    runName,
		})
		i++
	}
	return out, rejected
}
EOF

cat > /app/ridge_t7/collect.go <<'EOF'
package ridge_t7

import (
	"auroracomp/pack_io"
	"auroracomp/phase_k2"
)

// Collect scans raw dossier text into decision blocks.
func Collect(raw string) ([]pack_io.DecisionBlock, int) {
	return phase_k2.ScanRaw(raw)
}
EOF

cat > /app/ridge_t7/reconcile.go <<'EOF'
package ridge_t7

import "auroracomp/pack_io"

// StepB drops superseded approved rows while keeping first-seen winners.
func StepB(blocks []pack_io.DecisionBlock) ([]pack_io.DecisionBlock, int) {
	superseded := map[int]bool{}
	for _, blk := range blocks {
		for _, id := range blk.Supersedes {
			superseded[id] = true
		}
	}
	out := make([]pack_io.DecisionBlock, 0, len(blocks))
	for _, blk := range blocks {
		if blk.Status != "approved" {
			continue
		}
		if superseded[blk.Seq] {
			continue
		}
		out = append(out, blk)
	}
	return out, len(superseded)
}
EOF

cat > /app/moor_s9/profile.go <<'EOF'
package moor_s9

import (
	"os"
	"regexp"
	"strings"
)

var profileRe = regexp.MustCompile(`(?m)^rank_profile\s*=\s*"([^"]+)"`)

// ActiveRankProfile reads the pipeline rank profile from defaults.toml.
func ActiveRankProfile() string {
	raw, err := os.ReadFile("/app/config/defaults.toml")
	if err != nil {
		return "stable_seq"
	}
	m := profileRe.FindSubmatch(raw)
	if m == nil {
		return "stable_seq"
	}
	return strings.TrimSpace(string(m[1]))
}
EOF

cat > /app/internal/stitch/compose.go <<'EOF'
package stitch

import (
	"auroracomp/flux_w1"
	"auroracomp/keel_p4"
	"auroracomp/moor_s9"
	"auroracomp/pack_io"
)

// LinkQ finalizes ordering and export rows.
func LinkQ(blocks []pack_io.DecisionBlock, raw string) ([]pack_io.RunEntry, int) {
	profile := moor_s9.ActiveRankProfile()
	ordered := flux_w1.RankBlocks(blocks, profile)
	return keel_p4.PackD(ordered, raw)
}
EOF

cat > /app/cove_v8/amend.go <<'EOF'
package cove_v8

import "auroracomp/pack_io"

// OverlayRows merges appendix rows onto one block field map and returns hit count.
func OverlayRows(fields map[string]string, seq int, patches []pack_io.ErrataRow) int {
	hits := 0
	for _, patch := range patches {
		if patch.Seq != seq {
			continue
		}
		fields[patch.Field] = patch.Value
		hits++
	}
	return hits
}
EOF

sed -i 's/fields\["metric.secondary"\], fields\["metric.primary"\]/fields["metric.primary"], fields["metric.secondary"]/' /app/keel_p4/emit.go

bash /app/scripts/build.sh

rm -f /app/output/run_plan.json
tb_dossier=aurora_dossier.md /app/bin/auroracompile >/dev/null
test -s /app/output/run_plan.json

echo "Oracle rebuilt auroracompile pipeline and validated dossier export."
