"""Verifier for Aurora dossier MLflow run-plan compilation."""
from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
SCHEMAS = APP / "schemas"
GLOSSARY = APP / "docs" / "metric_glossary.md"
PLAN = APP / "output" / "run_plan.json"
DOSSIER = APP / "data" / "aurora_dossier.md"

OPEN = re.compile(r"^<<<DECISION seq=(\d+) status=(\w+)(?: supersedes=([\d,]+))?>>>")
ERRATA = re.compile(r"^<<<ERRATA seq=(\d+) field=([\w.]+) value=(.+?)>>>")


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "PATH": "/usr/local/go/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _parse_dossier(text: str) -> tuple[list[dict], list[dict], int]:
    blocks: list[dict] = []
    errata: list[dict] = []
    rejected = 0
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        m = OPEN.match(line)
        if m:
            seq = int(m.group(1))
            status = m.group(2).lower()
            sup = [int(x) for x in m.group(3).split(",")] if m.group(3) else []
            fields: dict[str, str] = {}
            run_name = ""
            i += 1
            while i < len(lines) and lines[i].strip() != "<<<END>>>":
                row = lines[i].strip()
                if row and ":" in row:
                    key, val = row.split(":", 1)
                    key = key.strip()
                    val = val.strip()
                    fields[key] = val
                    if key == "run_name":
                        run_name = val
                i += 1
            if status == "rejected":
                rejected += 1
            blocks.append(
                {"seq": seq, "status": status, "supersedes": sup, "fields": fields, "run_name": run_name}
            )
        elif (em := ERRATA.match(line)) is not None:
            errata.append({"seq": int(em.group(1)), "field": em.group(2), "value": em.group(3).strip()})
        i += 1
    return blocks, errata, rejected


def _expected_plan(text: str) -> dict:
    blocks, errata, rejected = _parse_dossier(text)
    superseded: set[int] = set()
    for blk in blocks:
        superseded.update(blk["supersedes"])
    survivors = [
        blk
        for blk in blocks
        if blk["status"] == "approved" and blk["seq"] not in superseded
    ]
    survivors.sort(key=lambda b: b["seq"])
    runs = []
    for blk in survivors:
        fields = dict(blk["fields"])
        applied = 0
        for patch in errata:
            if patch["seq"] == blk["seq"]:
                fields[patch["field"]] = patch["value"]
                applied += 1
        runs.append(
            {
                "seq": blk["seq"],
                "run_name": blk["run_name"],
                "flavor": fields["flavor"],
                "parameters": {
                    "lr": float(fields["param.lr"]),
                    "horizon": int(fields["param.horizon"]),
                },
                "metrics": [fields["metric.primary"], fields["metric.secondary"]],
                "lineage": {
                    "dataset": fields["lineage.dataset"],
                    "version": fields["lineage.version"],
                    "split": fields["lineage.split"],
                },
                "promotion_gates": {
                    "min_wape": float(fields["gate.min_wape"]),
                    "max_latency_ms": int(fields["gate.max_latency_ms"]),
                },
            }
        )
    return {
        "experiment_name": "aurora-demand-forecast",
        "runs": runs,
        "reconciliation": {
            "superseded_count": len(superseded),
            "rejected_skipped": rejected,
            "errata_applied": sum(1 for p in errata for b in survivors if b["seq"] == p["seq"]),
        },
    }


def _drive(dossier: str = "aurora_dossier.md") -> dict:
    PLAN.parent.mkdir(parents=True, exist_ok=True)
    if PLAN.exists():
        PLAN.unlink()
    subprocess.run(
        ["/app/bin/auroracompile"],
        cwd=str(APP),
        env={**os.environ, "tb_dossier": dossier},
        check=True,
    )
    return json.loads(PLAN.read_text(encoding="utf-8"))


def _require_keys(obj: dict, keys: set[str], label: str) -> None:
    missing = keys - obj.keys()
    assert not missing, f"{label} missing keys {sorted(missing)}"


def _metric_defaults() -> tuple[str, str, str]:
    text = GLOSSARY.read_text(encoding="utf-8")
    primary = re.search(r"Primary metric is `(\w+)`", text)
    secondary = re.search(r"secondary is `(\w+)`", text)
    dataset = re.search(r"dataset is `([\w_]+)`", text)
    assert primary and secondary and dataset, "metric glossary missing canonical defaults"
    return primary.group(1), secondary.group(1), dataset.group(1)


def _validate_run_plan_schema(plan: dict) -> None:
    run_plan_schema = json.loads((SCHEMAS / "run_plan.schema.json").read_text(encoding="utf-8"))
    run_entry_schema = json.loads((SCHEMAS / "run_entry.schema.json").read_text(encoding="utf-8"))
    _require_keys(plan, set(run_plan_schema["required"]), "plan")
    rec = plan["reconciliation"]
    rec_required = set(run_plan_schema["properties"]["reconciliation"]["required"])
    _require_keys(rec, rec_required, "reconciliation")
    for key in rec_required:
        assert isinstance(rec[key], int) and rec[key] >= 0, f"reconciliation.{key} must be a non-negative int"
    entry_required = set(run_entry_schema["required"])
    allowed_flavors = set(run_entry_schema["properties"]["flavor"]["enum"])
    for row in plan["runs"]:
        _require_keys(row, entry_required, "run")
        assert isinstance(row["seq"], int)
        assert row["flavor"] in allowed_flavors
        params = row["parameters"]
        _require_keys(params, {"lr", "horizon"}, "parameters")
        assert isinstance(params["lr"], (int, float))
        assert isinstance(params["horizon"], int)
        assert isinstance(row["metrics"], list) and len(row["metrics"]) >= 2
        lineage = row["lineage"]
        _require_keys(lineage, {"dataset", "version", "split"}, "lineage")
        gates = row["promotion_gates"]
        _require_keys(gates, {"min_wape", "max_latency_ms"}, "promotion_gates")
        assert isinstance(gates["min_wape"], (int, float))
        assert isinstance(gates["max_latency_ms"], int)


@pytest.fixture(scope="module")
def default_plan() -> dict:
    """Compile the primary dossier once for tests that share the same input."""
    return _drive()


def test_experiment_envelope(default_plan: dict) -> None:
    """Plan must name the aurora-demand-forecast experiment."""
    assert default_plan["experiment_name"] == "aurora-demand-forecast"
    _require_keys(default_plan, {"experiment_name", "runs", "reconciliation"}, "plan")


def test_run_plan_schema(default_plan: dict) -> None:
    """Compiled run plan must validate against /app/schemas."""
    _validate_run_plan_schema(default_plan)


def test_run_count_after_reconciliation(default_plan: dict) -> None:
    """Only approved, non-superseded rows survive reconciliation."""
    text = DOSSIER.read_text(encoding="utf-8")
    assert len(default_plan["runs"]) == len(_expected_plan(text)["runs"])


def test_document_order_by_seq(default_plan: dict) -> None:
    """Runs must follow dossier seq order, not lexical run_name order."""
    text = DOSSIER.read_text(encoding="utf-8")
    seqs = [row["seq"] for row in default_plan["runs"]]
    assert seqs == sorted(seqs)
    assert seqs == [row["seq"] for row in _expected_plan(text)["runs"]]


def test_rejected_rows_absent(default_plan: dict) -> None:
    """Rejected markers never enter the training matrix."""
    names = {row["run_name"] for row in default_plan["runs"]}
    assert not any(name.startswith("aurora-draft-") for name in names)


def test_reconciliation_counters(default_plan: dict) -> None:
    """Reconciliation tallies superseded, rejected, and errata counts."""
    text = DOSSIER.read_text(encoding="utf-8")
    want = _expected_plan(text)["reconciliation"]
    rec = default_plan["reconciliation"]
    assert rec["superseded_count"] == want["superseded_count"]
    assert rec["rejected_skipped"] == want["rejected_skipped"]
    assert rec["errata_applied"] == want["errata_applied"]


def test_errata_lineage_versions(default_plan: dict) -> None:
    """Appendix errata patches lineage.version on affected seq values."""
    text = DOSSIER.read_text(encoding="utf-8")
    want = {row["seq"]: row for row in _expected_plan(text)["runs"]}
    by_seq = {row["seq"]: row for row in default_plan["runs"]}
    for seq, row in want.items():
        if "lineage.version" in {
            p["field"] for p in _parse_dossier(text)[1] if p["seq"] == seq
        }:
            assert by_seq[seq]["lineage"]["version"] == row["lineage"]["version"]


def test_errata_gate_patches(default_plan: dict) -> None:
    """Appendix errata patches promotion gate fields on affected seq values."""
    text = DOSSIER.read_text(encoding="utf-8")
    want = {row["seq"]: row for row in _expected_plan(text)["runs"]}
    by_seq = {row["seq"]: row for row in default_plan["runs"]}
    for seq, row in want.items():
        if "gate.min_wape" in {
            p["field"] for p in _parse_dossier(text)[1] if p["seq"] == seq
        }:
            assert by_seq[seq]["promotion_gates"]["min_wape"] == row["promotion_gates"]["min_wape"]


def test_parameters_shape(default_plan: dict) -> None:
    """Each run parameters block carries lr and horizon."""
    for row in default_plan["runs"]:
        _require_keys(row, {"seq", "run_name", "flavor", "parameters", "metrics", "lineage", "promotion_gates"}, "run")
        assert isinstance(row["parameters"]["lr"], (int, float))
        assert isinstance(row["parameters"]["horizon"], int)


def test_metrics_from_glossary(default_plan: dict) -> None:
    """Primary and secondary metrics match the glossary defaults on every run."""
    primary, secondary, _ = _metric_defaults()
    for row in default_plan["runs"]:
        assert row["metrics"][0] == primary
        assert secondary in row["metrics"]


def test_lineage_dataset_from_glossary(default_plan: dict) -> None:
    """Lineage dataset matches the glossary warehouse export on every run."""
    _, _, dataset = _metric_defaults()
    for row in default_plan["runs"]:
        assert row["lineage"]["dataset"] == dataset


def test_promotion_gate_bounds(default_plan: dict) -> None:
    """Promotion gates expose min_wape and max_latency_ms."""
    for row in default_plan["runs"]:
        gates = row["promotion_gates"]
        assert 0 <= gates["min_wape"] <= 1
        assert gates["max_latency_ms"] >= 100


def test_full_matrix_matches_dossier(default_plan: dict) -> None:
    """Compiled runs must match the reconciled training matrix."""
    text = DOSSIER.read_text(encoding="utf-8")
    assert default_plan["runs"] == _expected_plan(text)["runs"]


def test_superseded_seq_ids_absent(default_plan: dict) -> None:
    """Retired seq ids referenced by later blocks must not appear in runs."""
    text = DOSSIER.read_text(encoding="utf-8")
    blocks, _, _ = _parse_dossier(text)
    retired: set[int] = set()
    for blk in blocks:
        retired.update(blk["supersedes"])
    exported = {row["seq"] for row in default_plan["runs"]}
    assert not exported & retired


def test_dossier_index_stem() -> None:
    """The index dossier stem named in dossier_index.txt compiles cleanly."""
    index = (APP / "docs" / "dossier_index.txt").read_text(encoding="utf-8").strip()
    text = (APP / "data" / index).read_text(encoding="utf-8")
    plan = _drive(index)
    want = _expected_plan(text)
    assert plan["experiment_name"] == want["experiment_name"]
    assert plan["runs"] == want["runs"]
    assert plan["reconciliation"] == want["reconciliation"]
