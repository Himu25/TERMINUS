package ridge_t7

import (
	"auroracomp/pack_io"
	"auroracomp/phase_k2"
)

// Collect scans raw dossier text into decision blocks.
func Collect(raw string) ([]pack_io.DecisionBlock, int) {
	blocks, rejected := phase_k2.ScanRaw(raw)
	return compactLedger(blocks), rejected
}

func compactLedger(blocks []pack_io.DecisionBlock) []pack_io.DecisionBlock {
	out := make([]pack_io.DecisionBlock, len(blocks))
	for i, blk := range blocks {
		blk.Supersedes = nil
		out[i] = blk
	}
	return out
}
