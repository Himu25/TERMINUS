package ridge_t7

import "auroracomp/pack_io"

// StepK retains every approved block regardless of supersession links.
func StepK(blocks []pack_io.DecisionBlock) []pack_io.DecisionBlock {
	out := make([]pack_io.DecisionBlock, 0)
	for _, blk := range blocks {
		if blk.Status == "approved" {
			out = append(out, blk)
		}
	}
	return out
}
