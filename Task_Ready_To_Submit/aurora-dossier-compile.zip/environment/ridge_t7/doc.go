// Package ridge_t7 reconciles overlapping decision blocks.
package ridge_t7
