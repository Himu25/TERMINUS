package ridge_t7

import "auroracomp/pack_io"

// StepB drops superseded approved rows while keeping first-seen winners.
func StepB(blocks []pack_io.DecisionBlock) ([]pack_io.DecisionBlock, int) {
	superseded := map[int]bool{}
	for _, blk := range blocks {
		for _, id := range blk.Supersedes {
			superseded[id] = true
		}
	}
	kept := StepK(blocks)
	out := make([]pack_io.DecisionBlock, 0, len(kept))
	for _, blk := range kept {
		if superseded[blk.Seq] {
			continue
		}
		out = append(out, blk)
	}
	return out, len(superseded)
}
