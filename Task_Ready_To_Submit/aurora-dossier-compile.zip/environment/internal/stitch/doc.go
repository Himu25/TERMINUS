// Package stitch binds ordering and export stages.
package stitch
