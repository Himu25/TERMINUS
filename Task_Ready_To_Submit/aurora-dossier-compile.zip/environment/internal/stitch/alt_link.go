package stitch

import (
	"auroracomp/flux_w1"
	"auroracomp/keel_p4"
	"auroracomp/pack_io"
)

// LinkFold is a bench-only export path that keeps fold-style ordering.
func LinkFold(blocks []pack_io.DecisionBlock, raw string) ([]pack_io.RunEntry, int) {
	ordered := flux_w1.RankBlocks(blocks, "fold_run")
	return keel_p4.PackD(ordered, raw)
}
