package stitch

import (
	"auroracomp/flux_w1"
	"auroracomp/keel_p4"
	"auroracomp/moor_s9"
	"auroracomp/pack_io"
)

// LinkQ finalizes ordering and export rows.
func LinkQ(blocks []pack_io.DecisionBlock, raw string) ([]pack_io.RunEntry, int) {
	profile := moor_s9.ActiveRankProfile()
	_ = profile
	ordered := flux_w1.RankBlocks(blocks, "lex_run")
	return keel_p4.PackD(ordered, raw)
}
