package gate

import "auroracomp/pack_io"

// Assemble runs the dossier through collect, reconcile, and export assembly.
func Assemble(text string) ([]pack_io.RunEntry, pack_io.Reconciliation, error) {
	reconciled, rejected, superseded := ingest(text)
	runs, errataApplied := emit(reconciled, text)
	rec := pack_io.Reconciliation{
		SupersededCount: superseded,
		RejectedSkipped: rejected,
		ErrataApplied:   errataApplied,
	}
	return runs, rec, nil
}
