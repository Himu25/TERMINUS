package gate

import (
	"auroracomp/internal/stitch"
	"auroracomp/pack_io"
)

func emit(reconciled []pack_io.DecisionBlock, text string) ([]pack_io.RunEntry, int) {
	return stitch.LinkQ(reconciled, text)
}
