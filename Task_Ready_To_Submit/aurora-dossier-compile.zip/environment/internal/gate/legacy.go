package gate

import (
	"auroracomp/flux_w1"
	"auroracomp/keel_p4"
	"auroracomp/pack_io"
	"auroracomp/ridge_t7"
)

// CompileLegacy retains every approved row and uses fold-style ordering.
func CompileLegacy(text string) ([]pack_io.RunEntry, pack_io.Reconciliation, error) {
	blocks, rejected := ridge_t7.Collect(text)
	kept := ridge_t7.StepK(blocks)
	ordered := flux_w1.RankBlocks(kept, "fold_run")
	runs, errataApplied := keel_p4.PackD(ordered, text)
	rec := pack_io.Reconciliation{
		SupersededCount: 0,
		RejectedSkipped: rejected,
		ErrataApplied:   errataApplied,
	}
	return runs, rec, nil
}
