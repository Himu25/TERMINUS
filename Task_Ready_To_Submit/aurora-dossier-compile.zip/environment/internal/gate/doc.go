// Package gate wires dossier ingestion into export assembly stages.
package gate
