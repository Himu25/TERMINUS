package gate

import (
	"auroracomp/pack_io"
	"auroracomp/ridge_t7"
)

func ingest(text string) ([]pack_io.DecisionBlock, int, int) {
	blocks, rejected := ridge_t7.Collect(text)
	reconciled, superseded := ridge_t7.StepB(blocks)
	return reconciled, rejected, superseded
}
