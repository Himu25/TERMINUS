package driver

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"auroracomp/internal/gate"
	"auroracomp/pack_io"
)

const experimentName = "aurora-demand-forecast"

// Run loads the dossier and writes the MLflow run plan.
func Run() error {
	src := os.Getenv("tb_dossier")
	if src == "" {
		src = "aurora_dossier.md"
	}
	emit := "/app/output/run_plan.json"
	raw, err := os.ReadFile(filepath.Join("/app", "data", src))
	if err != nil {
		return err
	}
	text := string(raw)
	runs, rec, err := gate.Assemble(text)
	if err != nil {
		return err
	}
	plan := pack_io.RunPlan{
		ExperimentName: experimentName,
		Runs:           runs,
		Reconciliation: rec,
	}
	if err := os.MkdirAll(filepath.Dir(emit), 0o755); err != nil {
		return err
	}
	buf, err := json.MarshalIndent(plan, "", "  ")
	if err != nil {
		return err
	}
	tmp := emit + ".tmp"
	if err := os.WriteFile(tmp, buf, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, emit)
}

func MainExit() int {
	if err := Run(); err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		return 1
	}
	return 0
}
