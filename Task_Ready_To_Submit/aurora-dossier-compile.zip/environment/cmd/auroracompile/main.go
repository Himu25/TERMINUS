package main

import (
	"os"

	"auroracomp/internal/driver"
)

func main() {
	os.Exit(driver.MainExit())
}
