package flux_w1

import (
	"sort"
	"strings"

	"auroracomp/pack_io"
)

// RankBlocks orders rows using the configured export profile.
func RankBlocks(blocks []pack_io.DecisionBlock, profile string) []pack_io.DecisionBlock {
	switch profile {
	case "stable_seq":
		return rankStable(blocks)
	case "fold_run":
		return rankFold(blocks)
	default:
		return rankLex(blocks)
	}
}

func rankStable(blocks []pack_io.DecisionBlock) []pack_io.DecisionBlock {
	out := make([]pack_io.DecisionBlock, len(blocks))
	copy(out, blocks)
	sort.Slice(out, func(i, j int) bool {
		if out[i].Seq == out[j].Seq {
			return out[i].RunName < out[j].RunName
		}
		return out[i].Seq < out[j].Seq
	})
	return out
}

func rankLex(blocks []pack_io.DecisionBlock) []pack_io.DecisionBlock {
	out := make([]pack_io.DecisionBlock, len(blocks))
	copy(out, blocks)
	sort.Slice(out, func(i, j int) bool {
		return out[i].RunName < out[j].RunName
	})
	return out
}

func rankFold(blocks []pack_io.DecisionBlock) []pack_io.DecisionBlock {
	out := make([]pack_io.DecisionBlock, len(blocks))
	copy(out, blocks)
	sort.Slice(out, func(i, j int) bool {
		left := strings.ToLower(out[i].RunName)
		right := strings.ToLower(out[j].RunName)
		if left == right {
			return out[i].Seq < out[j].Seq
		}
		return left < right
	})
	return out
}
