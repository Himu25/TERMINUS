#!/bin/bash
set -euo pipefail
test -x /app/bin/auroracompile
