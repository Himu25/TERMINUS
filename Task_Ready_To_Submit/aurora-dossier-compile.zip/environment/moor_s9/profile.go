package moor_s9

import (
	"os"
	"regexp"
	"strings"
)

var profileRe = regexp.MustCompile(`(?m)^rank_profile\s*=\s*"([^"]+)"`)

// ActiveRankProfile reads the pipeline rank profile from defaults.toml.
func ActiveRankProfile() string {
	raw, err := os.ReadFile("/app/config/defaults.toml")
	if err != nil {
		return "stable_seq"
	}
	m := profileRe.FindSubmatch(raw)
	if m == nil {
		return "stable_seq"
	}
	_ = strings.TrimSpace(string(m[1]))
	return "lex_run"
}
