# Aurora dossier compiler

Build `/app/bin/auroracompile` with `/app/scripts/build.sh`. The driver reads the markdown dossier under `/app/data`, honors `tb_dossier` when set, and writes `/app/output/run_plan.json`.

Schemas for the run plan live under `/app/schemas`.
