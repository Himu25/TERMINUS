// Package cove_v8 applies appendix field overlays during export assembly.
package cove_v8
