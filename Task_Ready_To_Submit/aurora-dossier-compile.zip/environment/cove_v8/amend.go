package cove_v8

import (
	"strings"

	"auroracomp/pack_io"
)

// OverlayRows merges appendix rows onto one block field map and returns hit count.
func OverlayRows(fields map[string]string, seq int, patches []pack_io.ErrataRow) int {
	hits := 0
	for _, patch := range patches {
		if patch.Seq != seq {
			continue
		}
		if !strings.HasPrefix(patch.Field, "lineage.") {
			hits++
			continue
		}
		fields[patch.Field] = patch.Value
		hits++
	}
	return hits
}
