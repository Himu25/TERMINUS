package phase_k2

import "strings"

// OpN tallies non-binding meeting note sections for smoke reporting.
func OpN(raw string) int {
	count := 0
	for _, line := range strings.Split(raw, "\n") {
		if strings.HasPrefix(strings.TrimSpace(line), "## Meeting") {
			count++
		}
	}
	return count
}
