// Package phase_k2 scans dossier markers.
package phase_k2
