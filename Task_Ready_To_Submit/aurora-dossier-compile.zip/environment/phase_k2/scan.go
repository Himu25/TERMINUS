package phase_k2

import (
	"regexp"
	"strconv"
	"strings"

	"auroracomp/pack_io"
)

var (
	openRe = regexp.MustCompile(`^<<<DECISION seq=(\d+) status=(\w+)(?: supersedes=([\d,]+))?>>>`)
	closeT = "<<<END>>>"
)

// ScanRaw walks the dossier and collects decision payloads in file order.
func ScanRaw(raw string) ([]pack_io.DecisionBlock, int) {
	lines := strings.Split(raw, "\n")
	out := make([]pack_io.DecisionBlock, 0)
	rejected := 0
	i := 0
	for i < len(lines) {
		line := strings.TrimSpace(lines[i])
		m := openRe.FindStringSubmatch(line)
		if m == nil {
			i++
			continue
		}
		seq, _ := strconv.Atoi(m[1])
		status := strings.ToLower(m[2])
		fields := map[string]string{}
		runName := ""
		i++
		for i < len(lines) && strings.TrimSpace(lines[i]) != closeT {
			row := strings.TrimSpace(lines[i])
			if row == "" {
				i++
				continue
			}
			if idx := strings.Index(row, ":"); idx > 0 {
				key := strings.TrimSpace(row[:idx])
				val := strings.TrimSpace(row[idx+1:])
				fields[key] = val
				if key == "run_name" {
					runName = val
				}
			}
			i++
		}
		if status == "rejected" {
			rejected++
		}
		out = append(out, pack_io.DecisionBlock{
			Seq:        seq,
			Status:     status,
			Supersedes: nil,
			Fields:     fields,
			RunName:    runName,
		})
		i++
	}
	return out, rejected
}
