package pack_io

type DecisionBlock struct {
	Seq        int
	Status     string
	Supersedes []int
	Fields     map[string]string
	RunName    string
}

type ErrataRow struct {
	Seq   int
	Field string
	Value string
}

type RunPlan struct {
	ExperimentName string         `json:"experiment_name"`
	Runs           []RunEntry     `json:"runs"`
	Reconciliation Reconciliation `json:"reconciliation"`
}

type RunEntry struct {
	Seq            int               `json:"seq"`
	RunName        string            `json:"run_name"`
	Flavor         string            `json:"flavor"`
	Parameters     map[string]any    `json:"parameters"`
	Metrics        []string          `json:"metrics"`
	Lineage        map[string]string `json:"lineage"`
	PromotionGates map[string]any    `json:"promotion_gates"`
}

type Reconciliation struct {
	SupersededCount int `json:"superseded_count"`
	RejectedSkipped int `json:"rejected_skipped"`
	ErrataApplied   int `json:"errata_applied"`
}
