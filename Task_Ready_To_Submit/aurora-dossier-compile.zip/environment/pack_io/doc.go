// Package pack_io holds shared dossier record shapes.
package pack_io
