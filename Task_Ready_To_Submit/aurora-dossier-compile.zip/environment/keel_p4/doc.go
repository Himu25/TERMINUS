// Package keel_p4 emits MLflow-compatible run rows.
package keel_p4
