package keel_p4

import (
	"regexp"
	"strconv"
	"strings"

	"auroracomp/cove_v8"
	"auroracomp/pack_io"
)

var errataRe = regexp.MustCompile(`^<<<ERRATA seq=(\d+) field=([\w.]+) value=(.+?)>>>`)

// PackD converts reconciled blocks into MLflow-shaped run entries.
func PackD(blocks []pack_io.DecisionBlock, raw string) ([]pack_io.RunEntry, int) {
	patches := pullAmends(raw)
	applied := 0
	out := make([]pack_io.RunEntry, 0, len(blocks))
	for _, blk := range blocks {
		fields := cloneFields(blk.Fields)
		applied += cove_v8.OverlayRows(fields, blk.Seq, patches)
		out = append(out, rowFromFields(blk, fields))
	}
	return out, applied
}

func cloneFields(src map[string]string) map[string]string {
	out := make(map[string]string, len(src))
	for k, v := range src {
		out[k] = v
	}
	return out
}

func rowFromFields(blk pack_io.DecisionBlock, fields map[string]string) pack_io.RunEntry {
	return pack_io.RunEntry{
		Seq:     blk.Seq,
		RunName: blk.RunName,
		Flavor:  fields["flavor"],
		Parameters: map[string]any{
			"lr":      atof(fields["param.lr"]),
			"horizon": atoi(fields["param.horizon"]),
		},
		Metrics: []string{fields["metric.secondary"], fields["metric.primary"]},
		Lineage: map[string]string{
			"dataset": fields["lineage.dataset"],
			"version": fields["lineage.version"],
			"split":   fields["lineage.split"],
		},
		PromotionGates: map[string]any{
			"min_wape":        atof(fields["gate.min_wape"]),
			"max_latency_ms": atoi(fields["gate.max_latency_ms"]),
		},
	}
}

func pullAmends(raw string) []pack_io.ErrataRow {
	rows := make([]pack_io.ErrataRow, 0)
	for _, line := range strings.Split(raw, "\n") {
		m := errataRe.FindStringSubmatch(strings.TrimSpace(line))
		if m == nil {
			continue
		}
		seq, _ := strconv.Atoi(m[1])
		rows = append(rows, pack_io.ErrataRow{Seq: seq, Field: m[2], Value: strings.TrimSpace(m[3])})
	}
	return rows
}

func atof(s string) float64 {
	v, _ := strconv.ParseFloat(strings.TrimSpace(s), 64)
	return v
}

func atoi(s string) int {
	v, _ := strconv.Atoi(strings.TrimSpace(s))
	return v
}
