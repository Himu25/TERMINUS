module auroracomp

go 1.22
