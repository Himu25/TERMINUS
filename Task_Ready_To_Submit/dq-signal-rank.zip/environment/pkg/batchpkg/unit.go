package batchpkg

// Key identifies one stage bundle partition.
type Key struct {
	Table  string
	PartID string
}

func (k Key) String() string {
	return k.Table + "/" + k.PartID
}
