package linewalk

// OpK lists direct edges for display only.
func OpK(edges []Edge) []string {
	out := make([]string, 0, len(edges))
	for _, e := range edges {
		out = append(out, e.From+"->"+e.To)
	}
	return out
}
