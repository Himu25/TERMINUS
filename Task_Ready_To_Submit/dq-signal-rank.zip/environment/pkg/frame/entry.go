package frame

// Row is one alert bundle row with an integrity fingerprint.
type Row struct {
	Seq     uint32 `json:"seq"`
	Payload string `json:"payload"`
	Tag     uint16 `json:"tag"`
}
