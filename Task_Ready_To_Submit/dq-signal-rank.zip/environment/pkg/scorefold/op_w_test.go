package scorefold

import "testing"

func TestOpWStaleIsRefresh(t *testing.T) {
	if OpW(100, 200, true) {
		t.Fatal("valid stale slice should not enter rebuild scope")
	}
	if !OpW(100, 200, false) {
		t.Fatal("invalid rows must enter rebuild scope")
	}
}
