package scorefold

import "fmt"

// OpC formats a watermark pair for logs.
func OpC(watermarkMS int64, upstreamMS int64) string {
	return fmt.Sprintf("%d/%d", watermarkMS, upstreamMS)
}
