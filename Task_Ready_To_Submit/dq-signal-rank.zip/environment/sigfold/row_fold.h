#ifndef SG_ROW_FOLD_H
#define SG_ROW_FOLD_H

#include <stdint.h>

int32_t sf_gate_i32(uint32_t row_sum, uint16_t stored_tag);

#endif
