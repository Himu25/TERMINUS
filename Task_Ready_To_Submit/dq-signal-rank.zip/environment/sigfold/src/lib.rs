#[no_mangle]
pub extern "C" fn sf_gate_i32(row_sum: u32, stored_tag: u16) -> i32 {
    let folded = (row_sum & 0xFFFF) as u16;
    if folded != stored_tag {
        return 1;
    }
    0
}
