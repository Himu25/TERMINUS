package sigfold

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libsigfold.a -ldl -lm
#include "row_fold.h"
*/
import "C"

import "lab.local/dq_signal_rank/pkg/frame"

func BadRows(rows []frame.Row) int {
	if len(rows) == 0 {
		return 0
	}
	var sum uint32
	for _, r := range rows {
		sum += r.Seq
	}
	stored := rows[0].Tag
	if C.sf_gate_i32(C.uint(sum), C.ushort(stored)) != 0 {
		return 1
	}
	return 0
}
