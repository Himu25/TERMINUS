# Pipeline alert layout

Stage bundles live under `data/active/tables/<stage>/<part_id>.json`. Direct edges model ingestion hops; materialized edges model rollup layers that do not appear in direct-only walks.

The active plan names seed bundles where metric drift was first reported. Row fingerprints use the shared WireCRC helper in `pkg/frame`. Digest replay helper lives at `/app/tools/digest_cli`.
