# Data-quality signal ranking stack

Go driver under `cmd/dq_ranker` coordinates bundle scans, lineage expansion, and rank-plan emission. Rust fingerprint helpers live in `sigfold/`. Active fixtures sit under `data/active/`.

Build: `/app/scripts/build.sh`
Run: `TB_DQ_FIXTURE=1 /app/bin/dq_ranker`
