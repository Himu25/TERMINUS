package blendfold

import "testing"

func TestOpDLateWindow(t *testing.T) {
	if !OpD(200, 250) {
		t.Fatal("late_ms above watermark must force scope")
	}
	if OpD(200, 0) {
		t.Fatal("zero late_ms must not force scope")
	}
}
