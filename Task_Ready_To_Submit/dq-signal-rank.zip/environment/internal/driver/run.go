package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"

	"lab.local/dq_signal_rank/internal/config"
	"lab.local/dq_signal_rank/internal/engine"
)

// Report is the outward JSON document.
type Report struct {
	SchemaVersion string `json:"schema_version"`
	PipelineID   string `json:"pipeline_id"`
	SymptomSeeds     uint32 `json:"symptom_seeds"`
	ImpactScope    uint32 `json:"impact_scope"`
	WatchRefresh  uint32 `json:"watch_refresh"`
	NoiseSkip     uint32 `json:"noise_skip"`
	LineageHops      uint32 `json:"lineage_hops"`
	MetricDriftHits   uint32 `json:"metric_drift_hits"`
	FreshnessTrapHits      uint32 `json:"freshness_trap_hits"`
	RankDigest   string `json:"rank_digest"`
}

// RunActive loads the active plan and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	plan, slices, err := config.LoadPlan(dir)
	if err != nil {
		return Report{}, err
	}
	return buildReport(plan, slices)
}

func buildReport(plan config.Plan, slices map[string]config.SliceRecord) (Report, error) {
	out := engine.Plan(plan, slices)
	digest := sha256.Sum256([]byte(fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%d|%d",
		plan.PipelineID,
		out.SymptomSeeds,
		out.ImpactScope,
		out.WatchRefresh,
		out.NoiseSkip,
		out.LineageHops,
		out.MetricDriftHits,
		out.FreshnessTrapHits,
	)))
	return Report{
		SchemaVersion: "1",
		PipelineID:   plan.PipelineID,
		SymptomSeeds:     out.SymptomSeeds,
		ImpactScope:    out.ImpactScope,
		WatchRefresh:  out.WatchRefresh,
		NoiseSkip:     out.NoiseSkip,
		LineageHops:      out.LineageHops,
		MetricDriftHits:   out.MetricDriftHits,
		FreshnessTrapHits:      out.FreshnessTrapHits,
		RankDigest:   hex.EncodeToString(digest[:]),
	}, nil
}

// EmitReport writes the JSON report.
func EmitReport(path string, rep Report) error {
	if err := os.MkdirAll("/app/output", 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, append(raw, '\n'), 0o644)
}
