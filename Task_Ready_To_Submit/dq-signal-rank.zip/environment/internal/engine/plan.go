package engine

import (
	"lab.local/dq_signal_rank/internal/config"
	"lab.local/dq_signal_rank/internal/late"
	"lab.local/dq_signal_rank/internal/scan"
	"lab.local/dq_signal_rank/internal/stale"
	"lab.local/dq_signal_rank/internal/walk"
	"lab.local/dq_signal_rank/pkg/batchpkg"
)

type Outcome struct {
	SymptomSeeds    uint32
	ImpactScope   uint32
	WatchRefresh uint32
	NoiseSkip    uint32
	LineageHops     uint32
	MetricDriftHits  uint32
	FreshnessTrapHits     uint32
}

func Plan(plan config.Plan, slices map[string]config.SliceRecord) Outcome {
	scope := map[string]bool{}
	var partialHits uint32
	var lateHits uint32
	var viewDeps uint32
	var seedCount uint32

	expandFrom := func(start batchpkg.Key) {
		down, hops := walk.Downstream(plan.DirectEdges, plan.ViewEdges, start)
		viewDeps += hops
		for _, dk := range down {
			scope[dk.String()] = true
		}
	}

	for key, rec := range slices {
		bad := scan.DriftRows(rec)
		partialHits += bad
		if bad > 0 {
			scope[key] = true
		}
		if late.WindowOpen(rec) {
			scope[key] = true
			lateHits++
			expandFrom(late.KeyFromRecord(rec))
		}
		if stale.NeedsRebuild(rec) {
			scope[key] = true
		}
	}

	for _, seed := range plan.SeedParts {
		sk := batchpkg.Key{Table: seed.Table, PartID: seed.PartID}
		rec, ok := slices[sk.String()]
		if !ok {
			continue
		}
		if scan.DriftRows(rec) == 0 {
			continue
		}
		seedCount++
		scope[sk.String()] = true
		expandFrom(sk)
	}

	refresh := map[string]bool{}
	for key, rec := range slices {
		if stale.IsRefreshOnly(rec, scope[key]) {
			refresh[key] = true
		}
	}

	var scopeCount uint32
	for range scope {
		scopeCount++
	}
	var refreshCount uint32
	for range refresh {
		refreshCount++
	}
	skipCount := uint32(len(slices)) - scopeCount - refreshCount

	return Outcome{
		SymptomSeeds:    seedCount,
		ImpactScope:   scopeCount,
		WatchRefresh: refreshCount,
		NoiseSkip:    skipCount,
		LineageHops:     viewDeps,
		MetricDriftHits:  partialHits,
		FreshnessTrapHits:     lateHits,
	}
}
