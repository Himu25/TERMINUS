package scan

import (
	"lab.local/dq_signal_rank/internal/config"
	"lab.local/dq_signal_rank/sigfold"
)

// DriftRows counts row-level tag failures in one slice record.
func DriftRows(rec config.SliceRecord) uint32 {
	return uint32(sigfold.BadRows(rec.Rows))
}
