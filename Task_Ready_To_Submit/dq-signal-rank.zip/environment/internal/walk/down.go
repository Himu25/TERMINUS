package walk

import (
	"lab.local/dq_signal_rank/pkg/linewalk"
	"lab.local/dq_signal_rank/pkg/batchpkg"
)

// Downstream returns expanded keys and view-layer hop count.
func Downstream(direct, view []linewalk.Edge, start batchpkg.Key) ([]batchpkg.Key, uint32) {
	return linewalk.OpL(direct, view, start)
}
