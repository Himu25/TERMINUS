package config

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"lab.local/dq_signal_rank/pkg/frame"
	"lab.local/dq_signal_rank/pkg/linewalk"
)

// Plan is the active pipeline layout.
type Plan struct {
	PipelineID string         `json:"pipeline_id"`
	ViewLayer   string         `json:"view_layer"`
	Tables      []string       `json:"tables"`
	DirectEdges []linewalk.Edge `json:"direct_edges"`
	ViewEdges   []linewalk.Edge `json:"view_edges"`
	SeedParts   []PartRef      `json:"seed_parts"`
}

// PartRef names one slice key.
type PartRef struct {
	Table  string `json:"table"`
	PartID string `json:"part_id"`
}

// SliceRecord is one on-disk partition manifest.
type SliceRecord struct {
	Table        string      `json:"table"`
	PartID       string      `json:"part_id"`
	Rows         []frame.Row `json:"rows"`
	WatermarkMS  int64       `json:"watermark_ms"`
	LateMS       int64       `json:"late_ms"`
	UpstreamWMMS int64       `json:"upstream_wm_ms"`
}

// ActivePaths resolves the active data directory.
func ActivePaths(appRoot string) (string, error) {
	dir := filepath.Join(appRoot, "data", "active")
	if st, err := os.Stat(dir); err != nil || !st.IsDir() {
		return "", fmt.Errorf("active data missing")
	}
	return dir, nil
}

// LoadPlan reads the pipeline plan and all bundle manifests.
func LoadPlan(activeDir string) (Plan, map[string]SliceRecord, error) {
	raw, err := os.ReadFile(filepath.Join(activeDir, "pipeline_plan.json"))
	if err != nil {
		return Plan{}, nil, err
	}
	var plan Plan
	if err := json.Unmarshal(raw, &plan); err != nil {
		return Plan{}, nil, err
	}
	slices := map[string]SliceRecord{}
	for _, tbl := range plan.Tables {
		dir := filepath.Join(activeDir, "tables", tbl)
		entries, err := os.ReadDir(dir)
		if err != nil {
			return Plan{}, nil, err
		}
		for _, ent := range entries {
			if ent.IsDir() {
				continue
			}
			body, err := os.ReadFile(filepath.Join(dir, ent.Name()))
			if err != nil {
				return Plan{}, nil, err
			}
			var rec SliceRecord
			if err := json.Unmarshal(body, &rec); err != nil {
				return Plan{}, nil, err
			}
			key := rec.Table + "/" + rec.PartID
			slices[key] = rec
		}
	}
	return plan, slices, nil
}

// LoadFixturePlan loads a named regression pack from TB_DQ_PACK env override.
func LoadFixturePlan(appRoot, pack string) (Plan, map[string]SliceRecord, error) {
	dir := filepath.Join(appRoot, "data", "fixtures", pack)
	if st, err := os.Stat(dir); err != nil || !st.IsDir() {
		return Plan{}, nil, fmt.Errorf("fixture pack missing")
	}
	raw, err := os.ReadFile(filepath.Join(dir, "pipeline_plan.json"))
	if err != nil {
		return Plan{}, nil, err
	}
	var plan Plan
	if err := json.Unmarshal(raw, &plan); err != nil {
		return Plan{}, nil, err
	}
	slices := map[string]SliceRecord{}
	for _, tbl := range plan.Tables {
		tblDir := filepath.Join(dir, "tables", tbl)
		entries, err := os.ReadDir(tblDir)
		if err != nil {
			return Plan{}, nil, err
		}
		for _, ent := range entries {
			if ent.IsDir() {
				continue
			}
			body, err := os.ReadFile(filepath.Join(tblDir, ent.Name()))
			if err != nil {
				return Plan{}, nil, err
			}
			var rec SliceRecord
			if err := json.Unmarshal(body, &rec); err != nil {
				return Plan{}, nil, err
			}
			key := rec.Table + "/" + rec.PartID
			slices[key] = rec
		}
	}
	return plan, slices, nil
}
