package late

import (
	"lab.local/dq_signal_rank/internal/config"
	"lab.local/dq_signal_rank/internal/blendfold"
	"lab.local/dq_signal_rank/pkg/batchpkg"
)

// WindowOpen reports whether a delayed update window forces scope inclusion.
func WindowOpen(rec config.SliceRecord) bool {
	return blendfold.OpD(rec.WatermarkMS, rec.LateMS)
}

// KeyFromRecord returns the table/part key for a slice record.
func KeyFromRecord(rec config.SliceRecord) batchpkg.Key {
	return batchpkg.Key{Table: rec.Table, PartID: rec.PartID}
}
