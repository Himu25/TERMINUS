module lab.local/dq_signal_rank

go 1.22
