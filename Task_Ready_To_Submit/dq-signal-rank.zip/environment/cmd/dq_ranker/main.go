// Plan JSON for /app/output/rank_plan.json:
//
// schema_version — string, always "1"
// pipeline_id — string, echoes active pipeline plan name
// symptom_seeds — uint32, seed bundles from the plan that show row-level fingerprint drift
// impact_scope — uint32, distinct stage/part bundles in minimal fix scope
// watch_refresh — uint32, bundles with valid fingerprints but watermark behind upstream
// noise_skip — uint32, clean bundles excluded from scope and refresh
// lineage_hops — uint32, materialized-layer edge traversals applied during scope expansion
// metric_drift_hits — uint32, row-level fingerprint failures detected across all bundles
// freshness_trap_hits — uint32, bundles where late_ms strictly exceeds watermark_ms and enter scope
// rank_digest — lowercase hex SHA-256 of pipeline_id|symptom_seeds|impact_scope|watch_refresh|noise_skip|lineage_hops|metric_drift_hits|freshness_trap_hits
//
// Root object contains only these keys.
package main

import (
	"log"
	"os"

	"lab.local/dq_signal_rank/internal/driver"
)

func main() {
	if os.Getenv("TB_DQ_FIXTURE") != "1" {
		log.Fatal("TB_DQ_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/rank_plan.json", rep); err != nil {
		log.Fatal(err)
	}
}
