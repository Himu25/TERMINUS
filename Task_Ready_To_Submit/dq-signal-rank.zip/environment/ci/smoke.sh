#!/bin/bash
set -euo pipefail
cd /app && bash /app/scripts/build.sh && TB_DQ_FIXTURE=1 /app/bin/dq_ranker
