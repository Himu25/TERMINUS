"""Verifier for data-quality signal ranking plans."""

import json
import os
import shutil
import subprocess
from collections import deque
from pathlib import Path

import pytest

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = Path("/tests") / "fixtures"
OUT = APP / "output" / "rank_plan.json"
BIN = "/app/bin/dq_ranker"
DIGEST_CLI = "/app/tools/digest_cli"
GO_BIN = "go"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _wire_crc(seq: int, payload: str) -> int:
    s = sum(payload.encode()) & 0xFFFFFFFF
    s ^= seq
    return s & 0xFFFF


def _partial_bad(rows: list[dict]) -> int:
    return sum(1 for r in rows if _wire_crc(r["seq"], r["payload"]) != r["tag"])


def _rows_valid(rows: list[dict]) -> bool:
    return all(_wire_crc(r["seq"], r["payload"]) == r["tag"] for r in rows)


def _op_l(direct: list[dict], view: list[dict], start: tuple[str, str]) -> tuple[list[tuple[str, str]], int]:
    adj_d: dict[str, list[str]] = {}
    adj_v: dict[str, list[str]] = {}
    for e in direct:
        adj_d.setdefault(e["from"], []).append(e["to"])
    for e in view:
        adj_v.setdefault(e["from"], []).append(e["to"])
    seen = {start[0]}
    out: list[tuple[str, str]] = []
    hops = 0
    queue = deque([start[0]])
    while queue:
        cur = queue.popleft()
        for nxt in adj_d.get(cur, []):
            if nxt not in seen:
                seen.add(nxt)
                out.append((nxt, start[1]))
                queue.append(nxt)
        for nxt in adj_v.get(cur, []):
            if nxt not in seen:
                seen.add(nxt)
                out.append((nxt, start[1]))
                hops += 1
                queue.append(nxt)
    return out, hops


def _digest_hex(
    pipeline_id: str,
    symptom_seeds: int,
    impact_scope: int,
    watch_refresh: int,
    noise_skip: int,
    lineage_hops: int,
    metric_drift_hits: int,
    freshness_trap_hits: int,
) -> str:
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            DIGEST_CLI,
            pipeline_id,
            str(symptom_seeds),
            str(impact_scope),
            str(watch_refresh),
            str(noise_skip),
            str(lineage_hops),
            str(metric_drift_hits),
            str(freshness_trap_hits),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _load_pack(pack_dir: Path) -> tuple[dict, dict[tuple[str, str], dict]]:
    plan = json.loads((pack_dir / "pipeline_plan.json").read_text())
    slices: dict[tuple[str, str], dict] = {}
    for tbl in plan["tables"]:
        tbl_dir = pack_dir / "tables" / tbl
        for path in sorted(tbl_dir.glob("*.json")):
            rec = json.loads(path.read_text())
            slices[(rec["table"], rec["part_id"])] = rec
    return plan, slices


def _expected(plan: dict, slices: dict[tuple[str, str], dict]) -> dict:
    scope: dict[tuple[str, str], bool] = {}
    metric_drift_hits = 0
    freshness_trap_hits = 0
    lineage_hops = 0

    def expand(start: tuple[str, str]) -> None:
        nonlocal lineage_hops
        down, hops = _op_l(plan["direct_edges"], plan["view_edges"], start)
        lineage_hops += hops
        for dk in down:
            scope[dk] = True

    for key, rec in slices.items():
        bad = _partial_bad(rec["rows"])
        metric_drift_hits += bad
        if bad > 0:
            scope[key] = True
        if rec["late_ms"] > rec["watermark_ms"]:
            scope[key] = True
            freshness_trap_hits += 1
            expand(key)

    symptom_seeds = 0
    for seed in plan["seed_parts"]:
        sk = (seed["table"], seed["part_id"])
        if _partial_bad(slices[sk]["rows"]) == 0:
            continue
        symptom_seeds += 1
        scope[sk] = True
        expand(sk)

    refresh: dict[tuple[str, str], bool] = {}
    for key, rec in slices.items():
        if key in scope:
            continue
        if _rows_valid(rec["rows"]) and rec["upstream_wm_ms"] > rec["watermark_ms"]:
            refresh[key] = True

    impact_scope = len(scope)
    watch_refresh = len(refresh)
    noise_skip = len(slices) - impact_scope - watch_refresh
    digest = _digest_hex(
        plan["pipeline_id"],
        symptom_seeds,
        impact_scope,
        watch_refresh,
        noise_skip,
        lineage_hops,
        metric_drift_hits,
        freshness_trap_hits,
    )
    return {
        "schema_version": "1",
        "pipeline_id": plan["pipeline_id"],
        "symptom_seeds": symptom_seeds,
        "impact_scope": impact_scope,
        "watch_refresh": watch_refresh,
        "noise_skip": noise_skip,
        "lineage_hops": lineage_hops,
        "metric_drift_hits": metric_drift_hits,
        "freshness_trap_hits": freshness_trap_hits,
        "rank_digest": digest,
    }


def _run_driver() -> dict:
    env = {**os.environ, "TB_DQ_FIXTURE": "1"}
    subprocess.run([BIN], cwd="/app", env=env, check=True)
    return json.loads(OUT.read_text())


def _swap_active(pack_name: str) -> None:
    src = FIXTURES / pack_name
    backup = APP / "data" / "_active_backup"
    if backup.exists():
        shutil.rmtree(backup)
    shutil.move(str(ACTIVE), str(backup))
    shutil.copytree(src, ACTIVE)


def _restore_active() -> None:
    backup = APP / "data" / "_active_backup"
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    if backup.exists():
        shutil.move(str(backup), str(ACTIVE))


class TestRankPlan:
    def test_active_plan_matches_contract(self) -> None:
        """Active pipeline bundle emits expected ranking counters."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got == expected

    def test_rank_digest_is_deterministic(self) -> None:
        """Two consecutive replays produce identical rank_digest."""
        first = _run_driver()
        second = _run_driver()
        assert first["rank_digest"] == second["rank_digest"]
        assert first == second

    def test_metric_drift_hits_detect_row_drift(self) -> None:
        """metric_drift_hits reflects row-level tag failures on corrupted seeds."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got["metric_drift_hits"] == expected["metric_drift_hits"]
        assert got["symptom_seeds"] == expected["symptom_seeds"]

    def test_lineage_hops_include_materialized_layer(self) -> None:
        """lineage_hops counts view-layer hops during scope expansion."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got["lineage_hops"] == expected["lineage_hops"]

    def test_refresh_excludes_stale_valid_slices(self) -> None:
        """watch_refresh covers valid slices whose watermark trails upstream."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got["watch_refresh"] == expected["watch_refresh"]
        assert got["impact_scope"] == expected["impact_scope"]

    def test_late_updates_enter_scope(self) -> None:
        """freshness_trap_hits counts slices with late_ms above watermark_ms."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got["freshness_trap_hits"] == expected["freshness_trap_hits"]

    def test_go_unit_tests_pass(self) -> None:
        """Go unit tests under /app pass after repair."""
        env = {
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        }
        subprocess.run([GO_BIN, "test", "./..."], cwd="/app", env=env, check=True)

    def test_stem_tight_replays_clean(self) -> None:
        """stem_tight regression stem replays to an equivalent plan."""
        _swap_active("stem_tight")
        try:
            plan, slices = _load_pack(ACTIVE)
            expected = _expected(plan, slices)
            got = _run_driver()
            assert got == expected
        finally:
            _restore_active()

    def test_stem_wide_replays_clean(self) -> None:
        """stem_wide regression stem replays to an equivalent plan."""
        _swap_active("stem_wide")
        try:
            plan, slices = _load_pack(ACTIVE)
            expected = _expected(plan, slices)
            got = _run_driver()
            assert got == expected
        finally:
            _restore_active()

    def test_noise_skip_excludes_clean_slices(self) -> None:
        """noise_skip leaves verified-clean slices out of scope and refresh."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got["noise_skip"] == expected["noise_skip"]

    def test_schema_version_and_pipeline_id(self) -> None:
        """Report carries schema_version and active pipeline_id from the plan."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got["pipeline_id"] == plan["pipeline_id"]
        assert got["schema_version"] == expected["schema_version"]
