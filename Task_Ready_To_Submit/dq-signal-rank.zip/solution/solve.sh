#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/pkg/linewalk/op_l.go <<'EOF'
package linewalk

import "lab.local/dq_signal_rank/pkg/batchpkg"

type Edge struct {
	From string `json:"from"`
	To   string `json:"to"`
}

func OpL(direct []Edge, view []Edge, start batchpkg.Key) ([]batchpkg.Key, uint32) {
	adjD := map[string][]string{}
	adjV := map[string][]string{}
	for _, e := range direct {
		adjD[e.From] = append(adjD[e.From], e.To)
	}
	for _, e := range view {
		adjV[e.From] = append(adjV[e.From], e.To)
	}
	seen := map[string]bool{start.Table: true}
	var out []batchpkg.Key
	var hops uint32
	queue := []string{start.Table}
	for len(queue) > 0 {
		cur := queue[0]
		queue = queue[1:]
		for _, nxt := range adjD[cur] {
			if seen[nxt] {
				continue
			}
			seen[nxt] = true
			out = append(out, batchpkg.Key{Table: nxt, PartID: start.PartID})
			queue = append(queue, nxt)
		}
		for _, nxt := range adjV[cur] {
			if seen[nxt] {
				continue
			}
			seen[nxt] = true
			out = append(out, batchpkg.Key{Table: nxt, PartID: start.PartID})
			hops++
			queue = append(queue, nxt)
		}
	}
	return out, hops
}
EOF

cat > /app/pkg/scorefold/op_w.go <<'EOF'
package scorefold

func OpW(watermarkMS int64, upstreamMS int64, rowsValid bool) bool {
	if !rowsValid {
		return true
	}
	return false
}
EOF

cat > /app/internal/blendfold/op_d.go <<'EOF'
package blendfold

func OpD(watermarkMS int64, lateMS int64) bool {
	if lateMS == 0 {
		return false
	}
	return lateMS > watermarkMS
}
EOF

cat > /app/sigfold/src/lib.rs <<'EOF'
#[no_mangle]
pub extern "C" fn sf_fold_u16(seq: u32, ptr: *const u8, len: usize) -> u16 {
    if ptr.is_null() || len == 0 {
        return 0;
    }
    let slice = unsafe { std::slice::from_raw_parts(ptr, len) };
    let mut s: u32 = 0;
    for &b in slice {
        s = s.wrapping_add(b as u32);
    }
    s ^= seq;
    (s & 0xFFFF) as u16
}
EOF

cat > /app/sigfold/row_fold.h <<'EOF'
#ifndef SG_ROW_FOLD_H
#define SG_ROW_FOLD_H

#include <stdint.h>

uint16_t sf_fold_u16(uint32_t seq, const uint8_t *ptr, size_t len);

#endif
EOF

cat > /app/sigfold/bridge.go <<'EOF'
package sigfold

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libsigfold.a -ldl -lm
#include "row_fold.h"
#include <stdlib.h>
*/
import "C"
import (
	"lab.local/dq_signal_rank/pkg/frame"
	"unsafe"
)

func BadRows(rows []frame.Row) int {
	bad := 0
	for _, r := range rows {
		payload := []byte(r.Payload)
		var ptr *C.uint8_t
		if len(payload) > 0 {
			ptr = (*C.uint8_t)(unsafe.Pointer(&payload[0]))
		}
		want := uint16(C.sf_fold_u16(C.uint(r.Seq), ptr, C.size_t(len(payload))))
		if want != r.Tag {
			bad++
		}
	}
	return bad
}
EOF

bash /app/scripts/build.sh

rm -f /app/output/rank_plan.json
mkdir -p /app/output
TB_DQ_FIXTURE=1 /app/bin/dq_ranker
test -s /app/output/rank_plan.json

GOFLAGS=-mod=mod go test ./...
