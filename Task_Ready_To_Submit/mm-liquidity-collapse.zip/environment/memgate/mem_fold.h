#ifndef MEM_FOLD_H
#define MEM_FOLD_H

int mg_reap_fold(int total, int orphan);

#endif
