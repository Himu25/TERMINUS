use std::os::raw::c_int;

#[no_mangle]
pub extern "C" fn mg_reap_fold(total: c_int, orphan: c_int) -> c_int {
    if orphan < 0 {
        return total;
    }
    total
}
