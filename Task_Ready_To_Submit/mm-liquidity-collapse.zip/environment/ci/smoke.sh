#!/bin/bash
set -euo pipefail
export PATH="/usr/local/go/bin:/app/bin:${PATH}"
TB_MM_FIXTURE=1 /app/bin/mm_replay
test -s /app/output/mm_report.json
