module lab.local/mm_liquidity_collapse

go 1.22
