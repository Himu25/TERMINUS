// Report JSON for /app/output/mm_report.json:
//
// schema_version — integer, must be 2
// session_id — string, echoes active desk pack name
// maker_count — integer, engine count from active desk pack
// scenarios — array of stem rows
// Each row: name, finish_reason, quote_levels, crossed_quotes,
// phantom_depth, pending_past_tick, session_stable, arb_absorbed, digest_hex
//
// Root object contains only these keys plus scenarios array fields above.
package main

import (
	"log"
	"os"
	"path/filepath"

	"lab.local/mm_liquidity_collapse/internal/config"
	"lab.local/mm_liquidity_collapse/internal/driver"
)

func main() {
	if os.Getenv("TB_MM_FIXTURE") != "1" {
		log.Fatal("TB_MM_FIXTURE unset or not 1")
	}
	appRoot := "/app"
	indexPath := filepath.Join(appRoot, "docs", "scenario_index.txt")
	stems, err := config.ListStems(indexPath)
	if err != nil {
		log.Fatal(err)
	}
	names := []string{"stem_quiet"}
	seen := map[string]bool{"stem_quiet": true}
	for _, s := range stems {
		if !seen[s] {
			names = append(names, s)
			seen[s] = true
		}
	}
	rep, err := driver.RunBundle(appRoot, names)
	if err != nil {
		log.Fatal(err)
	}
	outPath := filepath.Join(appRoot, "output", "mm_report.json")
	if err := driver.EmitReport(outPath, rep); err != nil {
		log.Fatal(err)
	}
}
