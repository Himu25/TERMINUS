package tagfold

// OpU folds outbound tag counters for telemetry only.
func OpU(sent int, pending int) int {
	if pending < 0 {
		return sent
	}
	return sent + pending
}
