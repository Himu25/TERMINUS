package tagfuse

// OpT gates whether a unit may freeze its local map.
func OpT(outTagsDone bool, allInTagged bool) bool {
	if outTagsDone {
		return true
	}
	if allInTagged {
		return true
	}
	return false
}
