package tagfuse_test

import "testing"

import "lab.local/mm_liquidity_collapse/pkg/tagfuse"

func TestOpTRequiresBoth(t *testing.T) {
	if tagfuse.OpT(false, false) {
		t.Fatal("expected false when neither gate is set")
	}
}
