package frame

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
)

// RowDigest seals one scenario row for cross-checking.
func RowDigest(name, finish string, keys, dup, unreach, inflight, closed, late int) string {
	raw := fmt.Sprintf(
		"%s|%s|%d|%d|%d|%d|%d|%d",
		name, finish, keys, dup, unreach, inflight, closed, late,
	)
	sum := sha256.Sum256([]byte(raw))
	return hex.EncodeToString(sum[:])
}
