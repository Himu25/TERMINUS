package reachfold

import "lab.local/mm_liquidity_collapse/internal/metrics"

// Count returns the reachable quote level total after ghost removal.
func Count(total int, orphan int) int {
	return metrics.ReachTally(total, orphan)
}
