Eight-engine two-sided quote replay lab. Driver binary lives at cmd/mm_replay.
Regression stems under data/regression each carry spec.json and trace.jsonl.
