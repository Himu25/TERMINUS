package main

import (
	"fmt"
	"os"
	"strconv"

	"lab.local/mm_liquidity_collapse/pkg/frame"
)

func main() {
	if len(os.Args) < 9 {
		fmt.Fprintln(os.Stderr, "usage: digest_cli name finish keys dup unreach inflight closed late")
		os.Exit(2)
	}
	name := os.Args[1]
	finish := os.Args[2]
	keys, _ := strconv.Atoi(os.Args[3])
	dup, _ := strconv.Atoi(os.Args[4])
	unreach, _ := strconv.Atoi(os.Args[5])
	inflight, _ := strconv.Atoi(os.Args[6])
	closed, _ := strconv.Atoi(os.Args[7])
	late, _ := strconv.Atoi(os.Args[8])
	fmt.Println(frame.RowDigest(name, finish, keys, dup, unreach, inflight, closed, late))
}
