digest_cli mirrors frame.RowDigest for verifier cross-checks.
