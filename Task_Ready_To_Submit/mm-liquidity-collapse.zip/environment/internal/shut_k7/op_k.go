package shut_k7

// OpK decides whether the venue session may stabilize.
func OpK(totalUnits int, recorded int, latePending bool) bool {
	return recorded >= totalUnits-1
}
