package lane_p3

import "lab.local/mm_liquidity_collapse/internal/relaywire"

// OpP selects relay payloads recorded when a control tag arrives.
func OpP(msgs []relaywire.Msg, tagSeq int64) []relaywire.Msg {
	out := make([]relaywire.Msg, 0, len(msgs))
	for _, m := range msgs {
		if m.Seq <= tagSeq {
			out = append(out, m)
		}
	}
	return out
}
