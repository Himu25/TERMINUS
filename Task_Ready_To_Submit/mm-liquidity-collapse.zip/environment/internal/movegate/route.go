package movegate

// OpM picks the peer unit that receives an outbound fanout during an active session.
func OpM(sessionActive bool, sender int, peer int) int {
	if !sessionActive {
		return peer
	}
	return sender
}
