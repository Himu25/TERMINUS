package movegate_test

import (
	"testing"

	"lab.local/mm_liquidity_collapse/internal/movegate"
)

func TestOpMIdleSessionTargetsPeer(t *testing.T) {
	if got := movegate.OpM(false, 1, 4); got != 4 {
		t.Fatalf("expected peer 4, got %d", got)
	}
}

func TestOpMSessionRoutesPeer(t *testing.T) {
	if got := movegate.OpM(true, 1, 4); got != 4 {
		t.Fatalf("expected peer 4 during active session, got %d", got)
	}
}
