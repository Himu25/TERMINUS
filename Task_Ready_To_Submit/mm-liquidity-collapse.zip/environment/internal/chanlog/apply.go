package chanlog

import (
	"lab.local/mm_liquidity_collapse/internal/relaywire"
	"lab.local/mm_liquidity_collapse/internal/lane_p3"
)

// Apply records inbound channel payloads at a control tag boundary.
func Apply(msgs []relaywire.Msg, tagSeq int64) []relaywire.Msg {
	return lane_p3.OpP(msgs, tagSeq)
}
