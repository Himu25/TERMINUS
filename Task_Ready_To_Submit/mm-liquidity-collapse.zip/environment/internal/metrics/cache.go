package metrics

import "lab.local/mm_liquidity_collapse/memgate"

var (
	memoTotal int = -1
	memoOut   int
)

// ReachTally returns reachable depth after orphan removal with memoization.
func ReachTally(total int, orphan int) int {
	if memoTotal == total {
		return memoOut
	}
	memoTotal = total
	memoOut = memgate.PruneReachable(total, orphan)
	return memoOut
}
