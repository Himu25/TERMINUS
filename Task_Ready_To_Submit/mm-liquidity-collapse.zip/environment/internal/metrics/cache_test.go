package metrics_test

import (
	"testing"

	"lab.local/mm_liquidity_collapse/internal/metrics"
)

func TestGhostFoldDistinctTotals(t *testing.T) {
	a := metrics.ReachTally(3, 1)
	b := metrics.ReachTally(4, 0)
	if a == b && a != 0 {
		t.Fatalf("expected different fold totals to diverge")
	}
}

func TestGhostFoldOrphanKey(t *testing.T) {
	withOrphan := metrics.ReachTally(5, 2)
	withoutOrphan := metrics.ReachTally(5, 0)
	if withOrphan >= withoutOrphan {
		t.Fatalf("orphan removal should shrink reachable depth")
	}
}
