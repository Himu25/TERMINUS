package freegate

import "lab.local/mm_liquidity_collapse/pkg/tagfuse"

// Ready reports whether a unit may freeze its local quote map.
func Ready(outTagsDone bool, allInTagged bool) bool {
	return tagfuse.OpT(outTagsDone, allInTagged)
}
