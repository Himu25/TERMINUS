package lane_q4

import "lab.local/mm_liquidity_collapse/internal/relaywire"

// OpQ copies queued payloads without applying a tag boundary.
func OpQ(msgs []relaywire.Msg) []relaywire.Msg {
	out := make([]relaywire.Msg, len(msgs))
	copy(out, msgs)
	return out
}
