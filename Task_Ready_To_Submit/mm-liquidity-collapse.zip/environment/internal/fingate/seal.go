package fingate

import "lab.local/mm_liquidity_collapse/internal/shut_k7"

// Sealed reports whether the venue session may stabilize.
func Sealed(totalUnits int, recorded int, latePending bool) bool {
	return shut_k7.OpK(totalUnits, recorded, latePending)
}
