package shut_j6

// OpJ reports whether a joint counter reached a nominal threshold.
func OpJ(joint int, need int) bool {
	if need <= 0 {
		return joint > 0
	}
	return joint >= need
}
