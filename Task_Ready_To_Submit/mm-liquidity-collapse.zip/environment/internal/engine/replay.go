package engine

import (
	"lab.local/mm_liquidity_collapse/internal/chanlog"
	"lab.local/mm_liquidity_collapse/internal/movegate"
	"lab.local/mm_liquidity_collapse/internal/relaywire"
	"lab.local/mm_liquidity_collapse/internal/freegate"
	"lab.local/mm_liquidity_collapse/pkg/reachfold"
)

type unitSim struct {
	store       map[string]string
	inChan      map[int][]relaywire.Msg
	inTagged    map[int]bool
	outTagged   map[int]bool
	localFrozen bool
	crashed     bool
}

// RawStem holds replay metrics before finalize gating.
type RawStem struct {
	KeysCaptured     int
	DuplicateKeys    int
	UnreachableKeys  int
	InFlightCaptured int
	LateWaveAbsorbed int
	Recorded         int
	LatePending      bool
	TotalUnits       int
}

// ReplayStem executes one stem trace through the venue session protocol.
func ReplayStem(spec relaywire.Spec, events []relaywire.Event) RawStem {
	n := spec.UnitCount
	if n <= 0 {
		n = 8
	}
	units := make([]*unitSim, n)
	for i := range units {
		units[i] = &unitSim{
			store:     make(map[string]string),
			inChan:    make(map[int][]relaywire.Msg),
			inTagged:  make(map[int]bool),
			outTagged: make(map[int]bool),
		}
	}

	sessionActive := false
	initiator := spec.Initiator
	latePending := false
	lateAbsorbed := false
	orphans := make(map[string]bool)
	levelSet := make(map[string]int)
	inFlight := 0

	applyPut := func(u int, key, val string) {
		units[u].store[key] = val
	}

	recordMsg := func(from, to int, key, val string, seq int64) {
		msg := relaywire.Msg{Seq: seq, Key: key, Value: val, From: from}
		units[to].inChan[from] = append(units[to].inChan[from], msg)
	}

	sendTags := func(u int, seq int64) {
		if units[u].crashed {
			return
		}
		for v := 0; v < n; v++ {
			if v == u || units[u].outTagged[v] {
				continue
			}
			units[u].outTagged[v] = true
			recordMsg(u, v, "__tag__", "", seq)
		}
	}

	tryFreeze := func(u int) {
		if units[u].crashed || units[u].localFrozen {
			return
		}
		allIn := true
		allOut := true
		for v := 0; v < n; v++ {
			if v == u {
				continue
			}
			if !units[u].inTagged[v] {
				allIn = false
			}
			if !units[u].outTagged[v] {
				allOut = false
			}
		}
		if freegate.Ready(allOut, allIn) {
			units[u].localFrozen = true
			for k := range units[u].store {
				levelSet[k]++
			}
		}
	}

	onFirstTag := func(u, from int, seq int64) {
		if units[u].inTagged[from] {
			return
		}
		units[u].inTagged[from] = true
		msgs := chanlog.Apply(units[u].inChan[from], seq)
		for _, m := range msgs {
			if m.Key == "__tag__" {
				continue
			}
			inFlight++
			units[u].store[m.Key] = m.Value
		}
		sendTags(u, seq)
		tryFreeze(u)
	}

	floodTags := func(from int, seq int64) {
		sendTags(from, seq)
		for v := 0; v < n; v++ {
			if v == from {
				continue
			}
			onFirstTag(v, from, seq)
		}
	}

	liveUnits := func() int {
		c := 0
		for i := 0; i < n; i++ {
			if !units[i].crashed {
				c++
			}
		}
		return c
	}
	_ = liveUnits

	recordedCount := func() int {
		c := 0
		for i := 0; i < n; i++ {
			if units[i].localFrozen {
				c++
			}
		}
		return c
	}

	runPropagate := func() {
		for pass := 0; pass < n*2; pass++ {
			moved := false
			for u := 0; u < n; u++ {
				if units[u].crashed {
					continue
				}
				for v := 0; v < n; v++ {
					if u == v || units[u].inTagged[v] {
						continue
					}
					for _, m := range units[u].inChan[v] {
						if m.Key == "__tag__" {
							onFirstTag(u, v, m.Seq)
							moved = true
							break
						}
					}
				}
				tryFreeze(u)
			}
			if !moved {
				break
			}
		}
	}

	for _, ev := range events {
		switch ev.Kind {
		case "seed":
			applyPut(ev.Unit, ev.Key, ev.Value)
		case "put":
			applyPut(ev.Unit, ev.Key, ev.Value)
			if sessionActive {
				u := ev.Unit
				for v := 0; v < n; v++ {
					if v != u && units[u].outTagged[v] {
						dest := movegate.OpM(sessionActive, u, v)
						recordMsg(u, dest, ev.Key, ev.Value, ev.Seq)
					}
				}
			}
		case "move":
			from, to := ev.From, ev.To
			delete(units[from].store, ev.Key)
			if sessionActive {
				dest := movegate.OpM(sessionActive, from, to)
				recordMsg(from, dest, ev.Key, ev.Value, ev.Seq)
			} else {
				applyPut(to, ev.Key, ev.Value)
			}
		case "begin", "begin_session":
			sessionActive = true
			units[initiator].inTagged[initiator] = true
			floodTags(initiator, ev.Seq)
			if ev.Kind == "begin" {
				runPropagate()
			}
		case "propagate":
			runPropagate()
		case "tag_arrive":
			onFirstTag(ev.To, ev.From, ev.Seq)
		case "crash_after_local":
			units[ev.Unit].localFrozen = true
			for k := range units[ev.Unit].store {
				levelSet[k]++
			}
			units[ev.Unit].crashed = true
		case "crash_before_emit":
			units[ev.Unit].localFrozen = true
			for k := range units[ev.Unit].store {
				levelSet[k]++
			}
			units[ev.Unit].crashed = true
		case "queue_late_tag":
			latePending = true
			recordMsg(ev.From, ev.To, "__tag__", "", ev.Seq)
		case "deliver_late":
			latePending = false
			onFirstTag(ev.To, ev.From, ev.Seq)
			lateAbsorbed = true
		case "orphan":
			orphans[ev.Key] = true
			delete(units[ev.Unit].store, ev.Key)
			if sessionActive {
				levelSet[ev.Key]++
			}
		}
	}

	dup := 0
	for _, cnt := range levelSet {
		if cnt > 1 {
			dup++
		}
	}

	totalKeys := len(levelSet)
	orphanInSession := 0
	for k := range levelSet {
		if orphans[k] {
			orphanInSession++
		}
	}
	reachable := reachfold.Count(totalKeys, orphanInSession)
	unreach := orphanInSession
	if reachable < totalKeys {
		unreach = 0
	}

	return RawStem{
		KeysCaptured:     reachable,
		DuplicateKeys:    dup,
		UnreachableKeys:  unreach,
		InFlightCaptured: inFlight,
		LateWaveAbsorbed: boolToInt(lateAbsorbed),
		Recorded:         recordedCount(),
		LatePending:      latePending,
		TotalUnits:       n,
	}
}

func boolToInt(v bool) int {
	if v {
		return 1
	}
	return 0
}
