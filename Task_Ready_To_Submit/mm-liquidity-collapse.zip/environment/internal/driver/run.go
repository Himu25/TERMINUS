package driver

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"lab.local/mm_liquidity_collapse/internal/config"
	"lab.local/mm_liquidity_collapse/internal/engine"
	"lab.local/mm_liquidity_collapse/internal/fingate"
	"lab.local/mm_liquidity_collapse/pkg/frame"
)

const (
	schemaVersion = 2
	finishStable  = "stable"
	finishCollaps = "collapsed"
)

// ScenarioRow is one stem outcome in the report.
type ScenarioRow struct {
	Name             string `json:"name"`
	FinishReason     string `json:"finish_reason"`
	QuoteLevels      int    `json:"quote_levels"`
	CrossedQuotes    int    `json:"crossed_quotes"`
	PhantomDepth     int    `json:"phantom_depth"`
	PendingPastTick  int    `json:"pending_past_tick"`
	SessionStable    int    `json:"session_stable"`
	ArbAbsorbed      int    `json:"arb_absorbed"`
	DigestHex        string `json:"digest_hex"`
}

// Report is written to /app/output/mm_report.json.
type Report struct {
	SchemaVersion int           `json:"schema_version"`
	SessionID     string        `json:"session_id"`
	MakerCount    int           `json:"maker_count"`
	Scenarios     []ScenarioRow `json:"scenarios"`
}

// RunBundle executes all requested stems and returns a report.
func RunBundle(appRoot string, stemNames []string) (Report, error) {
	packPath := filepath.Join(appRoot, "data", "active", "desk_pack.json")
	pack, err := config.LoadPack(packPath)
	if err != nil {
		return Report{}, err
	}

	rows := make([]ScenarioRow, 0, len(stemNames))
	for _, name := range stemNames {
		spec, events, err := config.LoadStem(appRoot, name)
		if err != nil {
			return Report{}, fmt.Errorf("stem %s: %w", name, err)
		}
		raw := engine.ReplayStem(spec, events)
		stable := 0
		finish := finishCollaps
		if fingate.Sealed(raw.TotalUnits, raw.Recorded, raw.LatePending) {
			stable = 1
			finish = finishStable
		}
		row := ScenarioRow{
			Name:            name,
			FinishReason:    finish,
			QuoteLevels:     raw.KeysCaptured,
			CrossedQuotes:   raw.DuplicateKeys,
			PhantomDepth:    raw.UnreachableKeys,
			PendingPastTick: raw.InFlightCaptured,
			SessionStable:   stable,
			ArbAbsorbed:     raw.LateWaveAbsorbed,
		}
		row.DigestHex = frame.RowDigest(
			row.Name, row.FinishReason,
			row.QuoteLevels, row.CrossedQuotes, row.PhantomDepth,
			row.PendingPastTick, row.SessionStable, row.ArbAbsorbed,
		)
		rows = append(rows, row)
	}

	return Report{
		SchemaVersion: schemaVersion,
		SessionID:     pack.SessionID,
		MakerCount:    pack.MakerCount,
		Scenarios:     rows,
	}, nil
}

// EmitReport writes the JSON report file.
func EmitReport(path string, rep Report) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}
