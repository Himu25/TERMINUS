package relaywire

// Msg is one queued inter-desk relay payload.
type Msg struct {
	Seq   int64
	Key   string
	Value string
	From  int
}

// Event is one replay step from a stem trace.
type Event struct {
	Seq   int64  `json:"seq"`
	Kind  string `json:"kind"`
	Unit  int    `json:"unit,omitempty"`
	From  int    `json:"from,omitempty"`
	To    int    `json:"to,omitempty"`
	Key   string `json:"key,omitempty"`
	Value string `json:"value,omitempty"`
}

// Spec holds stem metadata.
type Spec struct {
	StemID     string `json:"stem_id"`
	UnitCount  int    `json:"unit_count"`
	Initiator  int    `json:"initiator"`
	OrphanKeys int    `json:"orphan_keys"`
}
