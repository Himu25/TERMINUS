Offline replay lab for two-sided quote engine validation.

Build: bash /app/scripts/build.sh
Run: TB_MM_FIXTURE=1 /app/bin/mm_replay
