#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1
export GOCACHE="${GOCACHE:-/app/output/go-build}"

mkdir -p /app/bin /app/output "${GOCACHE}"
cd /app/memgate
CARGO_TARGET_DIR=/app/memgate/target cargo build --release --locked
cd /app
GOFLAGS=-mod=mod go build -trimpath -buildvcs=false -o /app/bin/mm_replay ./cmd/mm_replay
GOFLAGS=-mod=mod go build -trimpath -buildvcs=false -o /app/bin/digest_cli ./tools/digest_cli
