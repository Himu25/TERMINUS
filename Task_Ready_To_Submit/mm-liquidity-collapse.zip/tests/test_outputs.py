"""Verifier for mm liquidity collapse lab reports."""

from __future__ import annotations

import json
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "mm_report.json"
BIN = "/app/bin/mm_replay"
ACTIVE_PACK = APP / "data" / "active" / "desk_pack.json"
STEM_INDEX = APP / "docs" / "scenario_index.txt"

SCHEMA_VERSION = 2
FINISH_STABLE = "stable"
FINISH_COLLAPSED = "collapsed"

K_SCHEMA = "schema_version"
K_SESSION = "session_id"
K_MAKER = "maker_count"
K_SCENARIOS = "scenarios"
K_NAME = "name"
K_FINISH = "finish_reason"
K_CROSSED = "crossed_quotes"
K_PHANTOM = "phantom_depth"
K_PENDING_TICK = "pending_past_tick"
K_SESSION_STABLE = "session_stable"
K_ARB = "arb_absorbed"
K_DIGEST = "digest_hex"

STEM_QUIET = "stem_quiet"
STEM_FEEDBACK = "stem_feedback_spiral"
STEM_PENDING = "stem_pending_refresh"
STEM_CROSS = "stem_cross_venue_fill"
STEM_INVENTORY = "stem_inventory_shift"
STEM_TICK = "stem_tick_boundary"
STEM_PHANTOM = "stem_phantom_depth"

REQUIRED_TOP_FIELDS = (K_SCHEMA, K_SESSION, K_MAKER, K_SCENARIOS)
REQUIRED_ROW_FIELDS = (
    K_NAME,
    K_FINISH,
    "quote_levels",
    K_CROSSED,
    K_PHANTOM,
    K_PENDING_TICK,
    K_SESSION_STABLE,
    K_ARB,
    K_DIGEST,
)

# PUBLIC (~70%): quiet baseline, feedback spiral, pending refresh, cross-venue, inventory.
PUBLIC_EXPECTED = {
    STEM_QUIET: {
        K_FINISH: FINISH_STABLE,
        K_CROSSED: 0,
        K_PHANTOM: 0,
        K_SESSION_STABLE: 1,
    },
    STEM_FEEDBACK: {
        K_FINISH: FINISH_STABLE,
        K_SESSION_STABLE: 1,
        K_CROSSED: 0,
    },
    STEM_PENDING: {
        K_FINISH: FINISH_COLLAPSED,
        K_SESSION_STABLE: 0,
        K_ARB: 0,
    },
    STEM_CROSS: {
        K_FINISH: FINISH_STABLE,
        K_ARB: 1,
        K_SESSION_STABLE: 1,
    },
    STEM_INVENTORY: {
        K_FINISH: FINISH_STABLE,
        K_CROSSED: 0,
    },
}

# HIDDEN (~30%): tick-boundary capture, phantom fold memo, digest cross-check edge cases.
HIDDEN_EXPECTED = {
    STEM_TICK: {
        K_PENDING_TICK: 0,
    },
    STEM_PHANTOM: {
        K_FINISH: FINISH_STABLE,
        K_PHANTOM: 0,
        K_CROSSED: 0,
    },
}


@dataclass
class _LabSession:
    ready: bool = False
    report: dict | None = None
    setup_error: str = ""
    ran_go_tests: bool = False


_lab = _LabSession()


def _expect(row: dict, **fields: object) -> None:
    for key, value in fields.items():
        assert row[key] == value


def _run_checked(
    cmd: list[str],
    *,
    cwd: Path = APP,
    env: dict[str, str] | None = None,
    timeout: int = 600,
) -> None:
    merged = {**os.environ, **(env or {})}
    subprocess.run(cmd, cwd=cwd, env=merged, check=True, timeout=timeout)


def _prepare_lab_session() -> None:
    """One build, one go test pass, one replay — shared by every test."""
    try:
        _run_checked(["bash", "/app/scripts/build.sh"], timeout=540)
        _run_checked(
            ["go", "test", "./..."],
            env={"GOFLAGS": "-mod=mod"},
            timeout=180,
        )
        _lab.ran_go_tests = True
        _run_checked(
            [BIN],
            env={"TB_MM_FIXTURE": "1"},
            timeout=120,
        )
        _lab.report = json.loads(OUT.read_text())
        _lab.ready = True
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError) as exc:
        _lab.ready = False
        _lab.setup_error = str(exc)


@pytest.fixture(scope="session", autouse=True)
def _lab_session() -> None:
    _prepare_lab_session()


@pytest.fixture
def lab_report() -> dict:
    if not _lab.ready or _lab.report is None:
        pytest.fail(
            f"Lab setup failed before tests could run: {_lab.setup_error or 'unknown'}"
        )
    return _lab.report


def _row_digest(row: dict) -> str:
    proc = subprocess.run(
        [
            "/app/bin/digest_cli",
            row[K_NAME],
            row[K_FINISH],
            str(row["quote_levels"]),
            str(row[K_CROSSED]),
            str(row[K_PHANTOM]),
            str(row[K_PENDING_TICK]),
            str(row[K_SESSION_STABLE]),
            str(row[K_ARB]),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
        timeout=30,
    )
    return proc.stdout.strip()


def _by_name(report: dict) -> dict[str, dict]:
    return {row[K_NAME]: row for row in report[K_SCENARIOS]}


def _load_stems() -> list[str]:
    lines = STEM_INDEX.read_text().splitlines()
    return [line.strip() for line in lines if line.strip() and not line.startswith("#")]


def test_lab_build_replay_ready() -> None:
    """Build, Go tests, and fixture replay completed."""
    assert _lab.ready, _lab.setup_error or "lab session did not initialize"
    assert _lab.ran_go_tests
    assert _lab.report is not None


def test_report_schema_and_pack(lab_report: dict) -> None:
    """Report uses schema version 2 and the active session id."""
    _expect(lab_report, **{K_SCHEMA: SCHEMA_VERSION})
    pack = json.loads(ACTIVE_PACK.read_text())
    _expect(
        lab_report,
        **{K_SESSION: pack[K_SESSION], K_MAKER: pack[K_MAKER]},
    )
    assert len(lab_report[K_SCENARIOS]) >= 7


def test_report_contains_required_fields(lab_report: dict) -> None:
    """Top-level and per-scenario report rows include every schema field."""
    for field in REQUIRED_TOP_FIELDS:
        assert field in lab_report
    for row in lab_report[K_SCENARIOS]:
        for field in REQUIRED_ROW_FIELDS:
            assert field in row


def test_quiet_baseline_clean(lab_report: dict) -> None:
    """Quiet stem finishes stable with no crossed or phantom rows."""
    _expect(_by_name(lab_report)[STEM_QUIET], **PUBLIC_EXPECTED[STEM_QUIET])


def test_feedback_spiral_closes(lab_report: dict) -> None:
    """Feedback spiral stem closes stable without crossed quotes."""
    _expect(_by_name(lab_report)[STEM_FEEDBACK], **PUBLIC_EXPECTED[STEM_FEEDBACK])


def test_pending_refresh_holds_open(lab_report: dict) -> None:
    """Pending refresh stem stays collapsed while a refresh wave is pending."""
    _expect(_by_name(lab_report)[STEM_PENDING], **PUBLIC_EXPECTED[STEM_PENDING])


def test_cross_venue_fill_absorbs(lab_report: dict) -> None:
    """Cross-venue fill stem records the absorbed arb leg."""
    _expect(_by_name(lab_report)[STEM_CROSS], **PUBLIC_EXPECTED[STEM_CROSS])


def test_inventory_shift_no_cross(lab_report: dict) -> None:
    """Inventory shift stem finishes stable without crossed quotes."""
    _expect(_by_name(lab_report)[STEM_INVENTORY], **PUBLIC_EXPECTED[STEM_INVENTORY])


def test_public_stem_pass_markers(lab_report: dict) -> None:
    """Every public stem pass marker from the instruction is satisfied."""
    rows = _by_name(lab_report)
    for stem, expected in PUBLIC_EXPECTED.items():
        _expect(rows[stem], **expected)


def test_regression_stems_present(lab_report: dict) -> None:
    """Every stem listed in the scenario index appears in the report."""
    names = {row[K_NAME] for row in lab_report[K_SCENARIOS]}
    for stem in _load_stems():
        assert stem in names


def test_hidden_tick_boundary_pending(lab_report: dict) -> None:
    """Tick-boundary stem records zero pending_past_tick past the control tag."""
    _expect(_by_name(lab_report)[STEM_TICK], **HIDDEN_EXPECTED[STEM_TICK])


def test_hidden_phantom_depth_trimmed(lab_report: dict) -> None:
    """Phantom-depth stem reports zero phantom_depth after orphan pruning."""
    _expect(_by_name(lab_report)[STEM_PHANTOM], **HIDDEN_EXPECTED[STEM_PHANTOM])


def test_hidden_stem_pass_markers(lab_report: dict) -> None:
    """Hidden edge-case stems satisfy the instruction markers."""
    rows = _by_name(lab_report)
    for stem, expected in HIDDEN_EXPECTED.items():
        _expect(rows[stem], **expected)


def test_hidden_row_digests_match_cli(lab_report: dict) -> None:
    """Each scenario digest matches the digest helper."""
    for row in lab_report[K_SCENARIOS]:
        assert row[K_DIGEST] == _row_digest(row)
