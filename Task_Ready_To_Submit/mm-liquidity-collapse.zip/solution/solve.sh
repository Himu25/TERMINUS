#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

patch_op_p() {
cat > /app/internal/lane_p3/op_p.go <<'EOF'
package lane_p3

import "lab.local/mm_liquidity_collapse/internal/relaywire"

func strictlyBefore(seq int64, tagSeq int64) bool {
	if tagSeq <= 0 {
		return false
	}
	return seq < tagSeq
}

// OpP selects relay payloads recorded when a control tag arrives.
func OpP(msgs []relaywire.Msg, tagSeq int64) []relaywire.Msg {
	out := make([]relaywire.Msg, 0, len(msgs))
	for _, m := range msgs {
		if strictlyBefore(m.Seq, tagSeq) {
			out = append(out, m)
		}
	}
	return out
}
EOF
}

patch_op_t() {
cat > /app/pkg/tagfuse/op_t.go <<'EOF'
package tagfuse

func gatesSatisfied(outTagsDone bool, allInTagged bool) bool {
	if !outTagsDone {
		return false
	}
	if !allInTagged {
		return false
	}
	return true
}

// OpT gates whether a unit may freeze its local quote map.
func OpT(outTagsDone bool, allInTagged bool) bool {
	return gatesSatisfied(outTagsDone, allInTagged)
}
EOF
}

patch_op_k() {
cat > /app/internal/shut_k7/op_k.go <<'EOF'
package shut_k7

func quorumMet(totalUnits int, recorded int) bool {
	if totalUnits <= 0 {
		return false
	}
	return recorded >= totalUnits
}

// OpK decides whether the venue session may stabilize.
func OpK(totalUnits int, recorded int, latePending bool) bool {
	if latePending {
		return false
	}
	return quorumMet(totalUnits, recorded)
}
EOF
}

patch_memgate() {
cat > /app/memgate/src/lib.rs <<'EOF'
use std::os::raw::c_int;

fn clamp_orphan(total: c_int, orphan: c_int) -> c_int {
	if orphan < 0 {
		return 0;
	}
	if orphan > total {
		return total;
	}
	orphan
}

#[no_mangle]
pub extern "C" fn mg_reap_fold(total: c_int, orphan: c_int) -> c_int {
	if total <= 0 {
		return 0;
	}
	let drop = clamp_orphan(total, orphan);
	total - drop
}
EOF
}

patch_metrics_cache() {
cat > /app/internal/metrics/cache.go <<'EOF'
package metrics

import "lab.local/mm_liquidity_collapse/memgate"

var (
	memoTotal int = -1
	memoOrph  int = -1
	memoOut   int
)

func cacheHit(total int, orphan int) bool {
	return memoTotal == total && memoOrph == orphan
}

func storeMemo(total int, orphan int, out int) {
	memoTotal = total
	memoOrph = orphan
	memoOut = out
}

// ReachTally returns reachable depth after orphan removal with memoization.
func ReachTally(total int, orphan int) int {
	if cacheHit(total, orphan) {
		return memoOut
	}
	out := memgate.PruneReachable(total, orphan)
	storeMemo(total, orphan, out)
	return out
}
EOF
}

patch_movegate() {
cat > /app/internal/movegate/route.go <<'EOF'
package movegate

// OpM picks the peer unit that receives an outbound fanout during an active session.
func OpM(sessionActive bool, sender int, peer int) int {
	if !sessionActive {
		return peer
	}
	return peer
}
EOF
}

patch_op_p
patch_op_t
patch_op_k
patch_memgate
patch_metrics_cache
patch_movegate

bash /app/scripts/build.sh

rm -f /app/output/mm_report.json
mkdir -p /app/output
TB_MM_FIXTURE=1 /app/bin/mm_replay
test -s /app/output/mm_report.json

GOFLAGS=-mod=mod go test ./...
