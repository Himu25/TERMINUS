# Runbook fragment

Export `TB_EDGE_CORD` prior to invoking the probe so the harness can open the wire client. Default image wiring sets this to the loopback endpoint.

## Module map

Replays assume `runtime.props` defines two prefixes `U` and `V` that form paired Redis keys per mark.

- `src/pier/e3_orbit.rs` — replay driver and audit envelope
- `src/gate/c1_fan.rs` — mutate-row entry; delegates facet push and cord touch to `src/stripe_lane/mod.rs`
- `src/stripe_lane/mod.rs` — row_ink facet persistence and vex_hook cord follow-up after mutates
- `src/quay/d2_lift.rs` — lift-row label fetch and route classification; file-route promotion must SET both `${U}:{w}` and `${V}:{w}` to the same tag; clip consults U first, moor consults V second
- `src/relay/b0_sink.rs` — cord slot maintenance helpers used by stripe_lane touch; mutate follow-up must DELETE both prefix keys for the mark
- `src/shim_probe.rs` — loads props, seeds the store, flushes cord, writes `/app/output/coherence_audit.json`

These rules apply to bundled data and to every `/tests/fixtures/scenario_*.json` verifier pair, not only the lab churn file.

Verifier stress runs may rewrite `runtime.props` U/V lines with alternate nonce prefixes; automation examples include `cordU9z` and `cordV9z` (any non-empty distinct pair is valid if the probe and Redis stay in sync).
