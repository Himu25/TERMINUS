# Intro

This tree holds a small Rust harness that talks to a local key-value wire and a JSON backing file under `/app/var`. Operations are driven from `/app/data/churn.json` for lab replays.
