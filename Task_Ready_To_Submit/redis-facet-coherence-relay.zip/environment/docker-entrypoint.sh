#!/bin/sh
set -eu
# TB_EDGE_CORD selects the Redis endpoint for the replay harness (see instruction.md).
redis-server --save "" --appendonly no --daemonize yes --bind 127.0.0.1 --port 6379
exec "$@"
