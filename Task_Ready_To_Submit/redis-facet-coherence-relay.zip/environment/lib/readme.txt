Shared helpers for facet pushes and cord lane experiments; the probe replay imports stripe_lane on the mutate path.
