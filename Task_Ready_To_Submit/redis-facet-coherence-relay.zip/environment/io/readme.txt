IO adapters are not wired in this lab slice.
