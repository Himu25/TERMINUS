#!/usr/bin/env python3
"""Invoke the release shim_probe binary for churn replay."""

import subprocess
import sys


def main() -> int:
    proc = subprocess.run(["/app/bin/shim_probe"], check=False)
    return proc.returncode


if __name__ == "__main__":
    sys.exit(main())
