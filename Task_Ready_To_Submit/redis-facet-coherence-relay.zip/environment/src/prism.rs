use std::path::Path;

#[derive(Clone, Debug)]
pub struct Prism {
    pub u: String,
    pub v: String,
    pub knot: u32,
}

pub fn load_prism(raw: &str) -> Prism {
    let mut prism = Prism {
        u: String::new(),
        v: String::new(),
        knot: 0,
    };
    for line in raw.split('\n') {
        let t = line.trim();
        if t.is_empty() || t.starts_with('#') {
            continue;
        }
        let Some((k, rest)) = t.split_once('=') else {
            continue;
        };
        let val = rest.trim();
        match k {
            "U" => prism.u = val.to_string(),
            "V" => prism.v = val.to_string(),
            "KNOT" => prism.knot = val.parse::<u32>().unwrap_or(0),
            _ => {}
        }
    }
    prism
}

pub async fn read_props(path: &Path) -> std::io::Result<Prism> {
    let raw = tokio::fs::read_to_string(path).await?;
    Ok(load_prism(&raw))
}
