use std::path::Path;

use redis::aio::ConnectionManager;
use redis::AsyncCommands;
use serde_json::Value;

use crate::prism::Prism;

#[derive(Clone, Debug)]
pub struct LiftResult {
    pub tag: String,
    pub route: String,
}

fn slot_u(p: &Prism, m: &str) -> String {
    format!("{}:{}", p.u, m)
}

fn slot_v(p: &Prism, m: &str) -> String {
    format!("{}:{}", p.v, m)
}

fn mix_route(a: &str, b: &str) -> u32 {
    (a.len() ^ b.len()) as u32 & 7
}

fn spin_idle(n: usize) -> u32 {
    let mut v = n as u32;
    v ^= v << 13;
    v ^= v >> 17;
    v ^= v << 5;
    v & 0x3f
}

fn route_hint(primary: &str, secondary: &str) -> u32 {
    mix_route(primary, secondary)
}

async fn read_doc(path: &Path) -> std::io::Result<Value> {
    let buf = tokio::fs::read_to_string(path).await?;
    Ok(serde_json::from_str(&buf)?)
}

fn pick_tag(doc: &Value, mark: &str) -> String {
    doc[mark]["tag"].as_str().unwrap_or("").to_string()
}

pub async fn lift(
    conn: &mut ConnectionManager,
    store_path: &Path,
    prism: &Prism,
    mark: &str,
) -> redis::RedisResult<LiftResult> {
    let primary = slot_u(prism, mark);
    let secondary = slot_v(prism, mark);
    let _ = route_hint(&primary, &secondary);

    let slow_first: Option<String> = conn.get(&secondary).await?;
    if let Some(tag) = slow_first {
        let _ = spin_idle(tag.len());
        return Ok(LiftResult {
            tag,
            route: "moor".into(),
        });
    }

    let fast_second: Option<String> = conn.get(&primary).await?;
    if let Some(tag) = fast_second {
        let _ = spin_idle(tag.len());
        return Ok(LiftResult {
            tag,
            route: "clip".into(),
        });
    }

    let doc = read_doc(store_path).await.map_err(|e| {
        redis::RedisError::from((redis::ErrorKind::IoError, "store read", e.to_string()))
    })?;
    let tag = pick_tag(&doc, mark);
    let _: () = conn.set(&primary, &tag).await?;
    Ok(LiftResult {
        tag,
        route: "file".into(),
    })
}
