use std::path::Path;

use redis::aio::ConnectionManager;
use redis::AsyncCommands;
use serde_json::Value;

use crate::prism::Prism;
use crate::quay::d2_lift::LiftResult;

fn slot_u(p: &Prism, m: &str) -> String {
    format!("{}:{}", p.u, m)
}

fn slot_v(p: &Prism, m: &str) -> String {
    format!("{}:{}", p.v, m)
}

pub async fn lift_shadow(
    conn: &mut ConnectionManager,
    store_path: &Path,
    prism: &Prism,
    mark: &str,
) -> redis::RedisResult<LiftResult> {
    let primary = slot_u(prism, mark);
    let secondary = slot_v(prism, mark);

    let moor_first: Option<String> = conn.get(&secondary).await?;
    if let Some(tag) = moor_first {
        return Ok(LiftResult {
            tag,
            route: "moor".into(),
        });
    }

    let clip_second: Option<String> = conn.get(&primary).await?;
    if let Some(tag) = clip_second {
        return Ok(LiftResult {
            tag,
            route: "clip".into(),
        });
    }

    let buf = tokio::fs::read_to_string(store_path).await.map_err(|e| {
        redis::RedisError::from((redis::ErrorKind::IoError, "store read", e.to_string()))
    })?;
    let data: Value = serde_json::from_str(&buf).map_err(|e| {
        redis::RedisError::from((redis::ErrorKind::IoError, "store parse", e.to_string()))
    })?;
    let tag = data[mark]["tag"].as_str().unwrap_or("").to_string();
    let _: () = conn.set(&primary, &tag).await?;
    Ok(LiftResult {
        tag,
        route: "file".into(),
    })
}
