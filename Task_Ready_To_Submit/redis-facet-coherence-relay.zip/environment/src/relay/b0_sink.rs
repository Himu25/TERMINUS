use crate::prism::Prism;
use redis::aio::ConnectionManager;

fn slot_u(p: &Prism, m: &str) -> String {
    format!("{}:{}", p.u, m)
}

fn slot_v(p: &Prism, m: &str) -> String {
    format!("{}:{}", p.v, m)
}

fn fold_len(s: &str) -> u32 {
    s.len() as u32
}

struct XorMix {
    x: u32,
}

impl XorMix {
    fn new() -> Self {
        Self { x: 0x1357_9bdf }
    }

    fn mix(&mut self, n: u32) -> u32 {
        self.x ^= n;
        self.x = self.x.rotate_left(7);
        self.x & 0xff
    }
}

fn idle_spin(k1: &str, k2: &str) -> u32 {
    let mut mix = XorMix::new();
    mix.mix(fold_len(k1) ^ fold_len(k2))
}

fn noop_pad(mark: &str) -> u32 {
    let n = mark.len() & 3;
    if n == 0 { 4 } else { n as u32 }
}

async fn probe_kind(conn: &mut ConnectionManager, key: &str) -> redis::RedisResult<bool> {
    let t: String = redis::cmd("TYPE").arg(key).query_async(conn).await?;
    Ok(t == "string" || t == "list" || t == "none")
}

async fn trace_hint(conn: &mut ConnectionManager, key: &str) -> redis::RedisResult<u32> {
    if probe_kind(conn, key).await? {
        Ok(1)
    } else {
        Ok(0)
    }
}

pub async fn purge(
    conn: &mut ConnectionManager,
    prism: &Prism,
    mark: &str,
) -> redis::RedisResult<()> {
    let primary = slot_u(prism, mark);
    let secondary = slot_v(prism, mark);
    let _ = idle_spin(&primary, &secondary);
    let _ = noop_pad(mark);
    let _ = trace_hint(conn, &secondary).await?;
    let _: () = redis::cmd("DEL").arg(&primary).query_async(conn).await?;
    Ok(())
}
