//! Churn replay contract (machine-readable):
//! - Each row has "op" of boot | lift | mutate.
//! - lift rows carry "w" (string key into the backing map).
//! - mutate rows carry "w" and "text" for the new label.
//!
//! fold_digest: start from KNOT in runtime.props, then add each UTF-16 code unit
//! of every lifted label in order (charCodeAt stepping; supplementary-plane
//! glyphs contribute two units). Emit eight lowercase hex digits (low 32 bits).
//! route_histogram buckets: clip -> r0, moor -> r1, file -> r2.
//! momentum_flag steady only when hollow_state is quiet and r1 is zero.
//!
//! Cord slots: each mark uses `{U}:{w}` and `{V}:{w}` from runtime.props.
//! File-route lifts SET both keys to the same backing tag; mutates DELETE both.
//! Clip reads U first; moor reads V second.

use std::path::PathBuf;

use facet_coherence_relay::pier::e3_orbit::run_replay;
use facet_coherence_relay::prism::load_prism;
use redis::aio::ConnectionManager;
use serde_json::Value;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let cord = std::env::var("TB_EDGE_CORD").map_err(|_| "TB_EDGE_CORD is not set")?;

    let props_path = PathBuf::from("/app/config/runtime.props");
    let churn_path = PathBuf::from("/app/data/churn.json");
    let seed_path = PathBuf::from("/app/data/seed.json");
    let store_path = PathBuf::from("/app/var/facet_store.json");
    let out_path = PathBuf::from("/app/output/coherence_audit.json");

    let props_raw = tokio::fs::read_to_string(&props_path).await?;
    let churn_raw = tokio::fs::read_to_string(&churn_path).await?;
    let seed_raw = tokio::fs::read_to_string(&seed_path).await?;

    let prism = load_prism(&props_raw);
    let steps: Vec<Value> = serde_json::from_str(&churn_raw)?;
    let seed: Value = serde_json::from_str(&seed_raw)?;

    let client = redis::Client::open(cord.as_str())?;
    let mut conn = ConnectionManager::new(client).await?;
    let _: () = redis::cmd("FLUSHALL").query_async(&mut conn).await?;

    let seed_pretty = serde_json::to_string_pretty(&seed)?;
    tokio::fs::write(&store_path, seed_pretty).await?;

    let report = run_replay(&mut conn, &store_path, &prism, &steps).await?;

    if let Some(parent) = out_path.parent() {
        tokio::fs::create_dir_all(parent).await?;
    }
    let out = serde_json::to_string_pretty(&report)?;
    tokio::fs::write(&out_path, out).await?;

    Ok(())
}
