use std::path::Path;

use redis::aio::ConnectionManager;

use crate::prism::Prism;
use crate::stripe_lane::{row_ink, vex_hook};

fn bump_slot(mark: &str) -> u32 {
    ((mark.len() & 0xff) ^ 0x5a) as u32
}

fn noop_echo(n: usize) -> u32 {
    let n = n as u32;
    (n << 1) ^ (n >> 3)
}

pub async fn relay(
    conn: &mut ConnectionManager,
    store_path: &Path,
    prism: &Prism,
    mark: &str,
    text: &str,
) -> redis::RedisResult<()> {
    let _ = bump_slot(mark);
    let _ = noop_echo(text.len() | mark.len());
    row_ink(store_path, mark, text).await.map_err(|e| {
        redis::RedisError::from((redis::ErrorKind::IoError, "row ink", e.to_string()))
    })?;
    vex_hook(conn, prism, mark).await
}
