pub fn spin_counter(n: u32) -> u32 {
    let mut v = n;
    v ^= v.wrapping_mul(0x9e37_79b9);
    v & 0xffff
}
