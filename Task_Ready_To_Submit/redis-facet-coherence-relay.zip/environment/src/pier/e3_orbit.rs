use std::path::Path;

use redis::aio::ConnectionManager;
use serde_json::Value;

use crate::gate::c1_fan::relay;
use crate::prism::Prism;
use crate::quay::d2_lift::lift;

#[derive(Debug, serde::Serialize)]
pub struct AuditReport {
    pub momentum_flag: String,
    pub hollow_state: String,
    pub clip_hits: u32,
    pub fold_digest: String,
    pub route_histogram: RouteHistogram,
}

#[derive(Debug, serde::Serialize)]
pub struct RouteHistogram {
    pub r0: u32,
    pub r1: u32,
    pub r2: u32,
}

fn fold_digest(labels: &[String], knot: u32) -> String {
    let mut t = knot;
    for s in labels {
        for cu in s.encode_utf16() {
            t = t.wrapping_add(cu as u32);
        }
    }
    format!("{:08x}", t)
}

async fn read_truth(store_path: &Path, mark: &str) -> std::io::Result<String> {
    let buf = tokio::fs::read_to_string(store_path).await?;
    let data: Value = serde_json::from_str(&buf)?;
    Ok(data[mark]["tag"].as_str().unwrap_or("").to_string())
}

pub async fn run_replay(
    conn: &mut ConnectionManager,
    store_path: &Path,
    prism: &Prism,
    steps: &[Value],
) -> redis::RedisResult<AuditReport> {
    let mut labels: Vec<String> = Vec::new();
    let mut routes: Vec<String> = Vec::new();
    let mut clip_hits = 0u32;
    let mut noisy = false;

    for step in steps {
        let op = step["op"].as_str().unwrap_or("");
        if op == "boot" {
            continue;
        }
        if op == "lift" {
            let mark = step["w"].as_str().unwrap_or("");
            let truth = read_truth(store_path, mark).await.map_err(|e| {
                redis::RedisError::from((redis::ErrorKind::IoError, "truth read", e.to_string()))
            })?;
            let r = lift(conn, store_path, prism, mark).await?;
            labels.push(r.tag.clone());
            routes.push(r.route.clone());
            if r.route == "clip" {
                clip_hits += 1;
            }
            if r.tag != truth {
                noisy = true;
            }
        } else if op == "mutate" {
            let mark = step["w"].as_str().unwrap_or("");
            let text = step["text"].as_str().unwrap_or("");
            relay(conn, store_path, prism, mark, text).await?;
        }
    }

    let mut hist = RouteHistogram { r0: 0, r1: 0, r2: 0 };
    for r in &routes {
        match r.as_str() {
            "clip" => hist.r0 += 1,
            "moor" => hist.r1 += 1,
            _ => hist.r2 += 1,
        }
    }

    let hollow = if noisy { "noisy" } else { "quiet" };
    let momentum = if hollow == "quiet" && hist.r1 == 0 {
        "steady"
    } else {
        "torn"
    };

    Ok(AuditReport {
        momentum_flag: momentum.into(),
        hollow_state: hollow.into(),
        clip_hits,
        fold_digest: fold_digest(&labels, prism.knot),
        route_histogram: hist,
    })
}
