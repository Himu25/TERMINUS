use std::path::Path;

pub async fn measure_bundle(root: &Path) -> std::io::Result<usize> {
    let mut entries = tokio::fs::read_dir(root).await?;
    let mut count = 0usize;
    while let Some(entry) = entries.next_entry().await? {
        if entry.file_type().await?.is_file() {
            count += 1;
        }
    }
    Ok(count)
}
