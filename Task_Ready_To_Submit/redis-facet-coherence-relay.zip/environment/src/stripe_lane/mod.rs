pub mod cache_lane;

use std::path::Path;

use redis::aio::ConnectionManager;
use serde_json::Value;

use crate::prism::Prism;

fn tag_span(text: &str) -> u32 {
    text.len() as u32
}

fn spin_doc(n: u32) -> u32 {
    let mut v = n;
    v ^= v << 5;
    v ^= v >> 3;
    v & 0x3ff
}

pub async fn row_ink(store_path: &Path, mark: &str, text: &str) -> std::io::Result<()> {
    let buf = tokio::fs::read_to_string(store_path).await?;
    let mut data: Value = serde_json::from_str(&buf)?;
    let _ = spin_doc(tag_span(text) ^ mark.len() as u32);
    data[mark] = serde_json::json!({ "tag": text });
    let out = serde_json::to_string_pretty(&data)?;
    tokio::fs::write(store_path, out).await?;
    Ok(())
}

pub async fn vex_hook(
    _conn: &mut ConnectionManager,
    _prism: &Prism,
    _mark: &str,
) -> redis::RedisResult<()> {
    Ok(())
}
