"""Validate redis facet relay coherence: audit JSON, facet store, and cord slots.

Runs /app/tools/run_probe.py against bundled and fixture churn/seed pairs and checks
that projection labels, Redis cord keys, and /app/output/coherence_audit.json stay
aligned with the instruction contract.
"""

from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path
from typing import Any

import pytest

APP = Path("/app")
RUN_PROBE = Path("/app/tools/run_probe.py")
OUT = APP / "output" / "coherence_audit.json"
CHURN = APP / "data" / "churn.json"
SEED = APP / "data" / "seed.json"
STORE = APP / "var" / "facet_store.json"
PROPS = APP / "config" / "runtime.props"
FIXTURES = Path(__file__).resolve().parent / "fixtures"

SCENARIO_STEMS = (
    "scenario_boot_only",
    "scenario_triple_file",
    "scenario_two_mutates",
    "scenario_utf8_roundtrip",
    "scenario_four_marks",
    "scenario_interleaved_ab",
    "scenario_p2_solo_stress",
    "scenario_surrogate_glyph_chain",
    "scenario_surrogate_mixed_glyph",
    "scenario_ledger_wave",
    "scenario_bridge_turnstile",
    "scenario_cache_poison_p1",
    "scenario_ping_pong_ab",
    "scenario_zwnj_fold",
    "scenario_emoji_ladder",
    "scenario_seven_mark_spiral",
    "scenario_clip_storm",
    "scenario_mutate_sandwich",
    "scenario_cross_mark_matrix",
    "scenario_terminal_mutate",
    "scenario_ten_mark_gyre",
    "scenario_k_triple_lift_mutate",
    "scenario_bidi_surrogate_burst",
    "scenario_mark_key_edge_chars",
)


def _ensure_redis_live() -> None:
    """Start loopback Redis when entrypoint did not leave a live cord (self-contained verifier)."""
    ping = subprocess.run(
        ["redis-cli", "-h", "127.0.0.1", "-p", "6379", "ping"],
        capture_output=True,
        text=True,
        timeout=5,
    )
    if "PONG" in (ping.stdout or ""):
        return
    subprocess.run(
        [
            "redis-server",
            "--save",
            "",
            "--appendonly",
            "no",
            "--daemonize",
            "yes",
            "--bind",
            "127.0.0.1",
            "--port",
            "6379",
        ],
        check=True,
        timeout=30,
    )
    for _ in range(50):
        ping = subprocess.run(
            ["redis-cli", "-h", "127.0.0.1", "-p", "6379", "ping"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if "PONG" in (ping.stdout or ""):
            return
        time.sleep(0.2)
    raise RuntimeError(
        "redis liveness guard failed: 127.0.0.1:6379 did not answer PING"
    )


@pytest.fixture(scope="session", autouse=True)
def _redis_liveness_guard() -> None:
    _ensure_redis_live()


def _atomic_write_text(path: Path, text: str) -> None:
    """Atomically replace file contents so the probe never reads a half-written churn/seed."""
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)
    if hasattr(os, "sync"):
        os.sync()


def _facet_tag_map(store: dict[str, Any]) -> dict[str, str]:
    """Order-independent view of mark -> tag for facet_store.json comparisons."""
    return {mark: store[mark]["tag"] for mark in sorted(store)}


def _assert_report_equal(got: dict[str, Any], want: dict[str, Any]) -> None:
    """Compare audit payloads with tolerant numeric typing (JSON may use int or float)."""
    g = json.loads(json.dumps(got))
    w = json.loads(json.dumps(want))
    g["clip_hits"] = int(g["clip_hits"])
    w["clip_hits"] = int(w["clip_hits"])
    for k in ("r0", "r1", "r2"):
        g["route_histogram"][k] = int(g["route_histogram"][k])
        w["route_histogram"][k] = int(w["route_histogram"][k])
    assert g == w


def _assert_facet_store_equal(got: dict[str, Any], want: dict[str, Any]) -> None:
    assert set(got) == set(want)
    assert _facet_tag_map(got) == _facet_tag_map(want)
    for mark in got:
        assert set(got[mark].keys()) == {"tag"}


def _runtime_props_with_overrides(
    raw: str,
    *,
    knot: int | None = None,
    u: str | None = None,
    v: str | None = None,
) -> str:
    """Rewrite U/V/KNOT lines for anti-cheat runs; preserve comments and blank lines."""
    out: list[str] = []
    for line in raw.splitlines():
        st = line.strip()
        if not st or st.startswith("#"):
            out.append(line)
            continue
        key, _, _rest = line.partition("=")
        k = key.strip()
        if k == "KNOT" and knot is not None:
            out.append(f"KNOT={int(knot) & 0xFFFFFFFF}")
        elif k == "U" and u is not None:
            out.append(f"U={u}")
        elif k == "V" and v is not None:
            out.append(f"V={v}")
        else:
            out.append(line)
    ending = "\n" if raw.endswith("\n") else ""
    return "\n".join(out) + ending


def _redis_get(key: str) -> str | None:
    """Read a cord slot value from loopback Redis after a probe run."""
    proc = subprocess.run(
        ["redis-cli", "-h", "127.0.0.1", "-p", "6379", "GET", key],
        capture_output=True,
        text=True,
        timeout=5,
    )
    out = (proc.stdout or "").strip()
    if proc.returncode != 0 or out in ("", "(nil)"):
        return None
    return out


def _cord_keys(u: str, v: str, mark: str) -> tuple[str, str]:
    return f"{u}:{mark}", f"{v}:{mark}"


def _assert_cord_pair(u: str, v: str, mark: str, tag: str) -> None:
    """Both U/V cord keys for a mark must hold the same tag (instruction contract)."""
    ku, kv = _cord_keys(u, v, mark)
    got_u, got_v = _redis_get(ku), _redis_get(kv)
    assert got_u == tag, f"{ku} expected {tag!r}, got {got_u!r}"
    assert got_v == tag, f"{kv} expected {tag!r}, got {got_v!r}"


def _load_props() -> tuple[str, str, int]:
    u = v = ""
    knot = 0
    for raw in PROPS.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        key, _, rest = line.partition("=")
        key = key.strip()
        val = rest.strip()
        if key == "U":
            u = val
        elif key == "V":
            v = val
        elif key == "KNOT":
            knot = int(val) & 0xFFFFFFFF
    return u, v, knot


def _utf16_code_units(s: str) -> list[int]:
    """Match pier/e3_orbit fold_digest: UTF-16 code units (same as charCodeAt stepping)."""
    raw = s.encode("utf-16-le")
    return [int.from_bytes(raw[i : i + 2], "little") for i in range(0, len(raw), 2)]


def _fold_digest(labels: list[str], knot: int) -> str:
    """Match pier/e3_orbit fold_digest: sum knot with each UTF-16 code unit."""
    t = knot & 0xFFFFFFFF
    for s in labels:
        for cu in _utf16_code_units(s):
            t = (t + cu) & 0xFFFFFFFF
    return f"{t & 0xFFFFFFFF:08x}"[-8:]


def simulate_replay_full(
    steps: list[dict],
    seed_doc: dict,
    u: str,
    v: str,
    knot: int,
) -> tuple[dict, dict]:
    """Mirror pier/e3_orbit.js semantics with healthy purge/lift/relay (reference oracle)."""
    db: dict[str, str] = {}
    for mark, payload in seed_doc.items():
        db[mark] = payload["tag"] if isinstance(payload, dict) else str(payload)
    cache: dict[str, str] = {}

    def kf(mark: str) -> str:
        return f"{u}:{mark}"

    def ks(mark: str) -> str:
        return f"{v}:{mark}"

    def purge_local(mark: str) -> None:
        cache.pop(kf(mark), None)
        cache.pop(ks(mark), None)

    def lift_local(mark: str) -> tuple[str, str]:
        if kf(mark) in cache:
            return cache[kf(mark)], "clip"
        if ks(mark) in cache:
            return cache[ks(mark)], "moor"
        tag = db[mark]
        cache[kf(mark)] = tag
        cache[ks(mark)] = tag
        return tag, "file"

    def relay_local(mark: str, text: str) -> None:
        db[mark] = text
        purge_local(mark)

    labels: list[str] = []
    routes: list[str] = []
    clip_hits = 0
    noisy = False
    for s in steps:
        if s["op"] == "boot":
            continue
        if s["op"] == "lift":
            mark = s["w"]
            truth = db[mark]
            tag, route = lift_local(mark)
            labels.append(tag)
            routes.append(route)
            if route == "clip":
                clip_hits += 1
            if tag != truth:
                noisy = True
        elif s["op"] == "mutate":
            relay_local(s["w"], s["text"])
    hist = {"r0": 0, "r1": 0, "r2": 0}
    for r in routes:
        if r == "clip":
            hist["r0"] += 1
        elif r == "moor":
            hist["r1"] += 1
        else:
            hist["r2"] += 1
    hollow = "noisy" if noisy else "quiet"
    momentum = "steady" if hollow == "quiet" and hist["r1"] == 0 else "torn"
    report = {
        "momentum_flag": momentum,
        "hollow_state": hollow,
        "clip_hits": clip_hits,
        "fold_digest": _fold_digest(labels, knot),
        "route_histogram": hist,
    }
    final_store = {m: {"tag": db[m]} for m in db}
    return report, final_store


def simulate_fixed_replay() -> dict:
    """Healthy reference: dual purge, fast-first lift, dual promotion."""
    u, v, knot = _load_props()
    steps = json.loads(CHURN.read_text(encoding="utf-8"))
    seed_doc = json.loads(SEED.read_text(encoding="utf-8"))
    rep, _ = simulate_replay_full(steps, seed_doc, u, v, knot)
    return rep


def _load_scenario(name: str) -> tuple[list[dict], dict]:
    raw = json.loads((FIXTURES / f"{name}.json").read_text(encoding="utf-8"))
    return raw["churn"], raw["seed"]


def _run_probe_with_churn_and_seed(
    churn: list[dict],
    seed_doc: dict,
    *,
    cord: str | None = None,
) -> dict:
    """Temporarily replace churn + seed, run probe, restore originals; return audit dict."""
    churn_bytes = CHURN.read_bytes()
    seed_bytes = SEED.read_bytes()
    churn_text = json.dumps(churn, separators=(",", ":"), ensure_ascii=False)
    seed_text = json.dumps(seed_doc, separators=(",", ":"), ensure_ascii=False)
    try:
        _atomic_write_text(CHURN, churn_text)
        _atomic_write_text(SEED, seed_text)
        _run_probe(cord=cord)
        return json.loads(OUT.read_text(encoding="utf-8"))
    finally:
        CHURN.write_bytes(churn_bytes)
        SEED.write_bytes(seed_bytes)
        if hasattr(os, "sync"):
            os.sync()


def _run_probe(cord: str | None = None) -> None:
    env = os.environ.copy()
    env["TB_EDGE_CORD"] = cord or os.environ.get("TB_EDGE_CORD", "redis://127.0.0.1:6379")
    subprocess.run(
        ["python3", str(RUN_PROBE)],
        cwd=str(APP),
        env=env,
        check=True,
        timeout=120,
    )


@pytest.fixture(scope="module")
def golden() -> dict:
    return simulate_fixed_replay()


@pytest.fixture(scope="module")
def report(golden: dict) -> dict:
    assert golden["momentum_flag"] == "steady"
    _run_probe()
    return json.loads(OUT.read_text(encoding="utf-8"))


def test_output_file_exists_after_probe() -> None:
    """Probe should materialize the audit JSON at the declared output path."""
    _run_probe()
    assert OUT.is_file()


def test_audit_json_top_level_keys(report: dict) -> None:
    """Audit object should not grow extra top-level keys beyond the contract."""
    assert set(report.keys()) == {
        "momentum_flag",
        "hollow_state",
        "clip_hits",
        "fold_digest",
        "route_histogram",
    }


def test_momentum_flag_reads_steady(report: dict, golden: dict) -> None:
    """Momentum indicator should match the healthy reference replay."""
    assert report["momentum_flag"] == golden["momentum_flag"] == "steady"


def test_hollow_state_reads_quiet(report: dict, golden: dict) -> None:
    """Hollow indicator should stay quiet when lifts track backing truth."""
    assert report["hollow_state"] == golden["hollow_state"] == "quiet"


def test_clip_hits_match_reference_counter(report: dict, golden: dict) -> None:
    """Clip tally should match the bundled churn reference."""
    assert report["clip_hits"] == golden["clip_hits"] == 1


def test_fold_digest_matches_reference_blend(report: dict, golden: dict) -> None:
    """Fold digest should match the additive walk over lifted labels."""
    assert report["fold_digest"] == golden["fold_digest"]


def test_route_histogram_matches_reference(report: dict, golden: dict) -> None:
    """Route buckets should match the bundled churn reference counts."""
    assert report["route_histogram"] == golden["route_histogram"] == {
        "r0": 1,
        "r1": 0,
        "r2": 4,
    }


def test_fold_digest_is_lowercase_hex_width_eight(report: dict) -> None:
    """Fold digest must remain an eight-digit lowercase hex token."""
    s = report["fold_digest"]
    assert len(s) == 8
    assert s == s.lower()
    int(s, 16)


def test_clip_hits_non_negative_integer(report: dict) -> None:
    """Clip hits should be a sane non-negative integer tally."""
    assert isinstance(report["clip_hits"], int)
    assert report["clip_hits"] >= 0


def test_route_histogram_counts_sum_to_lift_ops() -> None:
    """Histogram buckets should partition the lift operations exactly."""
    lifts = sum(1 for s in json.loads(CHURN.read_text(encoding="utf-8")) if s.get("op") == "lift")
    _run_probe()
    rep = json.loads(OUT.read_text(encoding="utf-8"))
    h = rep["route_histogram"]
    assert h["r0"] + h["r1"] + h["r2"] == lifts


# --- Complex regression scenarios (swap churn/seed vs reference simulation) ---


def test_probe_determinism_two_runs_match_byte_for_byte_audit() -> None:
    """Two consecutive probes on the bundled lab inputs must emit identical audits."""
    _run_probe()
    a = OUT.read_text(encoding="utf-8")
    _run_probe()
    b = OUT.read_text(encoding="utf-8")
    assert a == b


def test_momentum_flag_ties_to_quiet_hollow_and_zero_moor_bucket() -> None:
    """steady iff quiet hollow and no moor-route lifts; torn otherwise (replay contract)."""
    _run_probe()
    rep = json.loads(OUT.read_text(encoding="utf-8"))
    h = rep["route_histogram"]
    steady_ok = rep["hollow_state"] == "quiet" and h["r1"] == 0
    assert (rep["momentum_flag"] == "steady") == steady_ok
    assert (rep["momentum_flag"] == "torn") == (not steady_ok)


def test_scenario_boot_only_fold_digest_is_knot_only_walk() -> None:
    """Boot-only churn: no lifts, digest equals KNOT additive walk over an empty label list."""
    churn, seed = _load_scenario("scenario_boot_only")
    u, v, knot = _load_props()
    want, _ = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)


def test_scenario_triple_file_then_clip_routes_match_simulation() -> None:
    """Three lifts on one mark after file seeding: first file, then clip projections."""
    churn, seed = _load_scenario("scenario_triple_file")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)
    _assert_cord_pair(u, v, "p1", seed["p1"]["tag"])


def test_scenario_double_mutate_then_lift_coherent_with_store() -> None:
    """Two mutates on one mark then lift: audit and facet_store match simulated finals."""
    churn, seed = _load_scenario("scenario_two_mutates")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_scenario_utf8_tags_digest_and_hollow_stay_quiet() -> None:
    """UTF-8 mutate labels: digest stays 8-char hex; hollow quiet when lifts match truth."""
    churn, seed = _load_scenario("scenario_utf8_roundtrip")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    assert got["hollow_state"] == "quiet"
    assert len(got["fold_digest"]) == 8
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_scenario_four_marks_heavy_interleave_matches_simulation() -> None:
    """Four marks with interleaved lifts and mutates must match full reference replay."""
    churn, seed = _load_scenario("scenario_four_marks")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_scenario_interleaved_ab_marks_under_mutations() -> None:
    """Alternating p1/p2 lifts with cross-marks mutates: histogram and digest match oracle sim."""
    churn, seed = _load_scenario("scenario_interleaved_ab")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_scenario_p2_solo_stress_unused_mark_left_intact() -> None:
    """Stress path on p2 only: untouched seed marks remain in final facet_store."""
    churn, seed = _load_scenario("scenario_p2_solo_stress")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    assert want_store["p1"]["tag"] == seed["p1"]["tag"]
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_scenario_surrogate_glyph_chain_matches_simulation() -> None:
    """Supplementary-plane mutates: fold_digest must follow UTF-16 code units like the probe."""
    churn, seed = _load_scenario("scenario_surrogate_glyph_chain")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_scenario_surrogate_mixed_glyph_matches_simulation() -> None:
    """Mixed BMP and supplementary labels in one replay: audit and store track UTF-16 folding."""
    churn, seed = _load_scenario("scenario_surrogate_mixed_glyph")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_bundled_facet_store_matches_simulated_final_tags() -> None:
    """Bundled lab churn: on-disk facet_store after probe matches simulated final map."""
    u, v, knot = _load_props()
    steps = json.loads(CHURN.read_text(encoding="utf-8"))
    seed_doc = json.loads(SEED.read_text(encoding="utf-8"))
    _, want_store = simulate_replay_full(steps, seed_doc, u, v, knot)
    _run_probe()
    got_store = json.loads(STORE.read_text(encoding="utf-8"))
    _assert_facet_store_equal(got_store, want_store)


# --- Anti-cheat: runtime.props must drive prism math (static golden JSON is insufficient) ---


@pytest.mark.parametrize("alt_knot", (1, 0x7FFFFFFF, 0xA5A5A5A5))
def test_boot_only_fold_digest_tracks_prism_knot_each_value(alt_knot: int) -> None:
    """Mutating KNOT alone changes boot-only digest; probe must track file-backed prism."""
    orig = PROPS.read_text(encoding="utf-8")
    u0, v0, k0 = _load_props()
    churn, seed = _load_scenario("scenario_boot_only")
    baseline_boot, _ = simulate_replay_full(churn, seed, u0, v0, k0)
    try:
        _atomic_write_text(PROPS, _runtime_props_with_overrides(orig, knot=alt_knot))
        churn, seed = _load_scenario("scenario_boot_only")
        u, v, knot = _load_props()
        assert knot == (int(alt_knot) & 0xFFFFFFFF)
        want, want_store = simulate_replay_full(churn, seed, u, v, knot)
        got = _run_probe_with_churn_and_seed(churn, seed)
        _assert_report_equal(got, want)
        _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)
        assert got["fold_digest"] != baseline_boot["fold_digest"]
    finally:
        _atomic_write_text(PROPS, orig)


def test_bundled_lab_full_audit_tracks_alternate_knot_value() -> None:
    """Full bundled churn/seed under a non-default KNOT must match simulator, not ship defaults."""
    orig = PROPS.read_text(encoding="utf-8")
    default_bundle = simulate_fixed_replay()
    alt_knot = 0x305419896
    try:
        _atomic_write_text(PROPS, _runtime_props_with_overrides(orig, knot=alt_knot))
        steps = json.loads(CHURN.read_text(encoding="utf-8"))
        seed_doc = json.loads(SEED.read_text(encoding="utf-8"))
        u, v, knot = _load_props()
        want, want_store = simulate_replay_full(steps, seed_doc, u, v, knot)
        _run_probe()
        got = json.loads(OUT.read_text(encoding="utf-8"))
        _assert_report_equal(got, want)
        _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)
        assert want["fold_digest"] != default_bundle["fold_digest"]
    finally:
        _atomic_write_text(PROPS, orig)


def test_runtime_props_restore_round_trip_restores_default_lab_audit() -> None:
    """After prism mutation + probe, restoring props reproduces the canonical bundled audit."""
    orig = PROPS.read_text(encoding="utf-8")
    canonical = simulate_fixed_replay()
    try:
        _atomic_write_text(PROPS, _runtime_props_with_overrides(orig, knot=0x11111111))
        _run_probe()
        twiddle = json.loads(OUT.read_text(encoding="utf-8"))
        assert twiddle["fold_digest"] != canonical["fold_digest"]
    finally:
        _atomic_write_text(PROPS, orig)
    _run_probe()
    got = json.loads(OUT.read_text(encoding="utf-8"))
    assert got == canonical


def test_custom_u_v_prefixes_bundled_lab_matches_simulator() -> None:
    """Non-default U/V prefixes must flow into Redis keys and remain consistent with the oracle sim."""
    orig = PROPS.read_text(encoding="utf-8")
    try:
        _atomic_write_text(
            PROPS,
            _runtime_props_with_overrides(orig, u="cordU9z", v="cordV9z"),
        )
        steps = json.loads(CHURN.read_text(encoding="utf-8"))
        seed_doc = json.loads(SEED.read_text(encoding="utf-8"))
        u, v, knot = _load_props()
        assert u == "cordU9z" and v == "cordV9z"
        want, want_store = simulate_replay_full(steps, seed_doc, u, v, knot)
        _run_probe()
        got = json.loads(OUT.read_text(encoding="utf-8"))
        _assert_report_equal(got, want)
        _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)
    finally:
        _atomic_write_text(PROPS, orig)


def test_scenario_ledger_wave_five_marks_matches_simulation() -> None:
    """Five marks with staggered mutates and a long tail of lifts: stresses purge ordering and digests."""
    churn, seed = _load_scenario("scenario_ledger_wave")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_scenario_bridge_turnstile_matches_simulation() -> None:
    """BMP plus supplementary-plane labels on three marks with tight alternation."""
    churn, seed = _load_scenario("scenario_bridge_turnstile")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_bundled_lab_matches_simulator_under_named_redis_db_url() -> None:
    """TB_EDGE_CORD with an explicit DB index must still run the full bundled lab against the simulator."""
    steps = json.loads(CHURN.read_text(encoding="utf-8"))
    seed_doc = json.loads(SEED.read_text(encoding="utf-8"))
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(steps, seed_doc, u, v, knot)
    got = _run_probe_with_churn_and_seed(
        steps,
        seed_doc,
        cord="redis://127.0.0.1:6379/4",
    )
    _assert_report_equal(got, want)
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_horseshoe_dense_mutate_lift_matches_simulator() -> None:
    """Dense horseshoe pattern across four marks; not mirrored in any checked-in JSON fixture."""
    churn = [
        {"op": "boot"},
        {"op": "lift", "w": "q0"},
        {"op": "lift", "w": "q1"},
        {"op": "mutate", "w": "q0", "text": "h0"},
        {"op": "lift", "w": "q2"},
        {"op": "mutate", "w": "q1", "text": "h1"},
        {"op": "lift", "w": "q3"},
        {"op": "lift", "w": "q0"},
        {"op": "mutate", "w": "q2", "text": "h2"},
        {"op": "lift", "w": "q1"},
        {"op": "mutate", "w": "q3", "text": "h3"},
        {"op": "lift", "w": "q2"},
        {"op": "lift", "w": "q0"},
        {"op": "mutate", "w": "q0", "text": "h0b"},
        {"op": "lift", "w": "q3"},
        {"op": "lift", "w": "q1"},
        {"op": "mutate", "w": "q1", "text": "h1b"},
        {"op": "lift", "w": "q2"},
        {"op": "lift", "w": "q3"},
        {"op": "mutate", "w": "q2", "text": "h2b"},
        {"op": "lift", "w": "q0"},
        {"op": "lift", "w": "q1"},
        {"op": "mutate", "w": "q3", "text": "h3b"},
        {"op": "lift", "w": "q2"},
        {"op": "lift", "w": "q3"},
        {"op": "lift", "w": "q0"},
        {"op": "lift", "w": "q1"},
    ]
    seed_doc = {
        "q0": {"tag": "t0"},
        "q1": {"tag": "t1"},
        "q2": {"tag": "t2"},
        "q3": {"tag": "t3"},
    }
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed_doc, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed_doc)
    _assert_report_equal(got, want)
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)
    n_lift = sum(1 for row in churn if row.get("op") == "lift")
    assert sum(want["route_histogram"].values()) == n_lift


def test_deep_inline_churn_stress_matches_simulator() -> None:
    """Long synthetic churn not present in fixtures: catches emitters that only handle lab files."""
    churn = [
        {"op": "boot"},
        {"op": "lift", "w": "a"},
        {"op": "mutate", "w": "a", "text": "α1"},
        {"op": "lift", "w": "b"},
        {"op": "mutate", "w": "b", "text": "β2"},
        {"op": "lift", "w": "a"},
        {"op": "mutate", "w": "a", "text": "γ3"},
        {"op": "lift", "w": "b"},
        {"op": "lift", "w": "a"},
        {"op": "mutate", "w": "b", "text": "δ4"},
        {"op": "lift", "w": "b"},
        {"op": "lift", "w": "a"},
        {"op": "mutate", "w": "a", "text": "ε5"},
        {"op": "lift", "w": "a"},
        {"op": "lift", "w": "b"},
    ]
    seed_doc = {
        "a": {"tag": "z0"},
        "b": {"tag": "z1"},
    }
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed_doc, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed_doc)
    _assert_report_equal(got, want)
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)
    n_lift = sum(1 for row in churn if row.get("op") == "lift")
    assert sum(want["route_histogram"].values()) == n_lift


# --- Additional complex scenarios (cache purge, UTF-16, high clip load) ---


def test_scenario_cache_poison_p1_stays_quiet_after_mutate_lift() -> None:
    """Mutate between lifts on p1 must purge cord slots so the next lift matches store truth."""
    churn, seed = _load_scenario("scenario_cache_poison_p1")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_scenario_ping_pong_ab_twelve_file_lifts_no_stale_bleed() -> None:
    """Six ping-pong rounds across two marks: every lift must track the latest mutate text."""
    churn, seed = _load_scenario("scenario_ping_pong_ab")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    n_lift = sum(1 for row in churn if row.get("op") == "lift")
    assert sum(got["route_histogram"].values()) == n_lift
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_scenario_zwnj_fold_counts_zwj_and_combining_units() -> None:
    """ZWJ and combining-character mutates must fold with two UTF-16 steps per code unit."""
    churn, seed = _load_scenario("scenario_zwnj_fold")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    assert len(got["fold_digest"]) == 8
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_scenario_emoji_ladder_family_sequence_matches_simulation() -> None:
    """Progressive emoji-family mutates stress supplementary-plane UTF-16 folding in the digest."""
    churn, seed = _load_scenario("scenario_emoji_ladder")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_scenario_seven_mark_spiral_round_trip_matches_simulation() -> None:
    """Seven marks each mutated once then lifted again: facet_store and audit stay aligned."""
    churn, seed = _load_scenario("scenario_seven_mark_spiral")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    n_lift = sum(1 for row in churn if row.get("op") == "lift")
    assert sum(got["route_histogram"].values()) == n_lift == 14
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_scenario_clip_storm_twelve_clip_hits_after_triple_lift() -> None:
    """Six marks with three lifts each: first file then two clip routes per mark when slots stay primed."""
    churn, seed = _load_scenario("scenario_clip_storm")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    n_lift = sum(1 for row in churn if row.get("op") == "lift")
    assert got["clip_hits"] == want["clip_hits"]
    assert sum(got["route_histogram"].values()) == n_lift
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_scenario_mutate_sandwich_back_to_back_lifts_on_x() -> None:
    """Back-to-back lifts on x around mutates require dual-slot purge and clip classification."""
    churn, seed = _load_scenario("scenario_mutate_sandwich")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_ledger_wave_under_alternate_knot_matches_simulation() -> None:
    """scenario_ledger_wave with a non-default KNOT must track runtime.props, not baked defaults."""
    orig = PROPS.read_text(encoding="utf-8")
    alt_knot = 0xDEADBEEF
    churn, seed = _load_scenario("scenario_ledger_wave")
    try:
        _atomic_write_text(PROPS, _runtime_props_with_overrides(orig, knot=alt_knot))
        u, v, knot = _load_props()
        assert knot == alt_knot
        want, want_store = simulate_replay_full(churn, seed, u, v, knot)
        got = _run_probe_with_churn_and_seed(churn, seed)
        _assert_report_equal(got, want)
        _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)
    finally:
        _atomic_write_text(PROPS, orig)


def test_whirlpool_eight_mark_three_wave_inline_matches_simulator() -> None:
    """Eight marks, three mutate waves plus a closing lift sweep — not present in any fixture file."""
    churn = [{"op": "boot"}]
    seed_doc = {f"q{i}": {"tag": f"t{i}"} for i in range(8)}
    for wave in range(3):
        for i in range(8):
            churn.append({"op": "lift", "w": f"q{i}"})
            churn.append({"op": "mutate", "w": f"q{i}", "text": f"h{i}{wave}"})
    for i in range(8):
        churn.append({"op": "lift", "w": f"q{i}"})
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed_doc, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed_doc)
    _assert_report_equal(got, want)
    assert sum(got["route_histogram"].values()) == 32
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_mutate_burst_single_mark_eleven_lifts_inline_matches_simulator() -> None:
    """Ten mutate/lift pairs on one mark catch relay paths that skip dual-slot invalidation."""
    churn = [{"op": "boot"}, {"op": "lift", "w": "solo"}]
    for i in range(10):
        churn.append({"op": "mutate", "w": "solo", "text": f"v{i}"})
        churn.append({"op": "lift", "w": "solo"})
    seed_doc = {"solo": {"tag": "v-1"}}
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed_doc, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed_doc)
    _assert_report_equal(got, want)
    n_lift = sum(1 for row in churn if row.get("op") == "lift")
    assert sum(got["route_histogram"].values()) == n_lift
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


# --- Parametrized fixture matrix + Redis cord slot behavioral checks ---


@pytest.mark.parametrize("stem", SCENARIO_STEMS)
def test_listed_fixture_pair_matches_full_simulation(stem: str) -> None:
    """Every instruction-named fixture must match the reference replay (audit + facet_store)."""
    churn, seed = _load_scenario(stem)
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)
    n_lift = sum(1 for row in churn if row.get("op") == "lift")
    assert sum(got["route_histogram"].values()) == n_lift


def test_scenario_cross_mark_matrix_quiet_under_cross_mutations() -> None:
    """Three marks with staggered cross-marks mutates must stay quiet with coherent clip/file mix."""
    churn, seed = _load_scenario("scenario_cross_mark_matrix")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    assert got["hollow_state"] == want["hollow_state"] == "quiet"
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)
    _assert_cord_pair(u, v, "b", want_store["b"]["tag"])


def test_scenario_terminal_mutate_matches_simulation() -> None:
    """Replay ending on mutate: audit matches simulator and backing row holds final text."""
    churn, seed = _load_scenario("scenario_terminal_mutate")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_scenario_ten_mark_gyre_twenty_file_lifts_matches_simulation() -> None:
    """Ten marks each mutated once then lifted again: twenty file routes, zero moor."""
    churn, seed = _load_scenario("scenario_ten_mark_gyre")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    assert got["route_histogram"]["r1"] == want["route_histogram"]["r1"] == 0
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_scenario_k_triple_lift_mutate_clip_after_purge() -> None:
    """File then mutate-purge then two lifts: second lift must be clip, not moor."""
    churn, seed = _load_scenario("scenario_k_triple_lift_mutate")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    assert got["clip_hits"] == want["clip_hits"]
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_scenario_bidi_surrogate_burst_matches_simulation() -> None:
    """RTL, emoji, and ZWSP mutates on one mark: UTF-16 digest and quiet hollow."""
    churn, seed = _load_scenario("scenario_bidi_surrogate_burst")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_scenario_mark_key_edge_chars_matches_simulation() -> None:
    """Mark keys with punctuation must not break prism slot naming or store updates."""
    churn, seed = _load_scenario("scenario_mark_key_edge_chars")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_scenario_clip_storm_heavy_clip_load_matches_simulation() -> None:
    """Six marks with triple lifts each: clip tally and buckets must match reference replay."""
    churn, seed = _load_scenario("scenario_clip_storm")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    assert got["clip_hits"] == want["clip_hits"]
    assert got["clip_hits"] > 0
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)
    for mark in ("c0", "c5"):
        _assert_cord_pair(u, v, mark, seed[mark]["tag"])


def test_terminal_mutate_clears_both_cord_slots() -> None:
    """When replay ends on mutate, both U/V cord keys for that mark must be absent."""
    churn, seed = _load_scenario("scenario_terminal_mutate")
    u, v, _knot = _load_props()
    _run_probe_with_churn_and_seed(churn, seed)
    mark = "fin"
    ku, kv = _cord_keys(u, v, mark)
    assert _redis_get(ku) is None
    assert _redis_get(kv) is None


def test_file_lift_populates_both_cord_slots() -> None:
    """scenario_triple_file: after file then clip lifts, both cord slots still hold the seed tag."""
    churn, seed = _load_scenario("scenario_triple_file")
    u, v, _knot = _load_props()
    got = _run_probe_with_churn_and_seed(churn, seed)
    want, _ = simulate_replay_full(churn, seed, u, v, _knot)
    _assert_report_equal(got, want)
    _assert_cord_pair(u, v, "p1", seed["p1"]["tag"])


def test_clip_storm_dual_slots_hold_final_seed_tags() -> None:
    """After clip_storm, endpoint marks c0 and c5 must still hold seed tags in both cord slots."""
    churn, seed = _load_scenario("scenario_clip_storm")
    u, v, knot = _load_props()
    got = _run_probe_with_churn_and_seed(churn, seed)
    want, _ = simulate_replay_full(churn, seed, u, v, knot)
    _assert_report_equal(got, want)
    for mark in ("c0", "c5"):
        _assert_cord_pair(u, v, mark, seed[mark]["tag"])


def test_cross_mark_matrix_final_cord_slots_match_store_tags() -> None:
    """Cross-mark matrix: mark b cord slots must match facet_store after staggered mutates."""
    churn, seed = _load_scenario("scenario_cross_mark_matrix")
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed)
    _assert_report_equal(got, want)
    _assert_cord_pair(u, v, "b", want_store["b"]["tag"])


def test_sixteen_mark_ring_inline_matches_simulator() -> None:
    """Sixteen marks, one mutate wave, second lift sweep — inline only, not in fixtures."""
    churn = [{"op": "boot"}]
    seed_doc = {f"z{i}": {"tag": f"t{i}"} for i in range(16)}
    for i in range(16):
        churn.append({"op": "lift", "w": f"z{i}"})
        churn.append({"op": "mutate", "w": f"z{i}", "text": f"h{i}"})
    for i in range(16):
        churn.append({"op": "lift", "w": f"z{i}"})
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed_doc, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed_doc)
    _assert_report_equal(got, want)
    assert sum(got["route_histogram"].values()) == 32
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_alternating_ab_sixteen_rounds_inline_matches_simulator() -> None:
    """Sixteen ping-pong rounds on two marks with mutates every round."""
    churn = [{"op": "boot"}]
    seed_doc = {"a": {"tag": "A0"}, "b": {"tag": "B0"}}
    for i in range(16):
        churn.append({"op": "lift", "w": "a"})
        churn.append({"op": "mutate", "w": "a", "text": f"A{i}"})
        churn.append({"op": "lift", "w": "b"})
        churn.append({"op": "mutate", "w": "b", "text": f"B{i}"})
    churn.append({"op": "lift", "w": "a"})
    churn.append({"op": "lift", "w": "b"})
    u, v, knot = _load_props()
    want, want_store = simulate_replay_full(churn, seed_doc, u, v, knot)
    got = _run_probe_with_churn_and_seed(churn, seed_doc)
    _assert_report_equal(got, want)
    assert got["hollow_state"] == "quiet"
    _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)


def test_custom_u_v_prefixes_clip_storm_matches_simulation() -> None:
    """scenario_clip_storm under alternate U/V must match simulator and keep cord slots coherent."""
    orig = PROPS.read_text(encoding="utf-8")
    churn, seed = _load_scenario("scenario_clip_storm")
    alt_u, alt_v = "cordU9z", "cordV9z"
    try:
        _atomic_write_text(
            PROPS,
            _runtime_props_with_overrides(orig, u=alt_u, v=alt_v),
        )
        u, v, knot = _load_props()
        assert u == alt_u and v == alt_v
        want, want_store = simulate_replay_full(churn, seed, u, v, knot)
        got = _run_probe_with_churn_and_seed(churn, seed)
        _assert_report_equal(got, want)
        _assert_facet_store_equal(json.loads(STORE.read_text(encoding="utf-8")), want_store)
    finally:
        _atomic_write_text(PROPS, orig)
