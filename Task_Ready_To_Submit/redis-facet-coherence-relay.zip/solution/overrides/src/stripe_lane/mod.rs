pub mod cache_lane;

use std::path::Path;

use redis::aio::ConnectionManager;
use serde_json::Value;

use crate::prism::Prism;
use crate::relay::b0_sink::purge;

fn tag_span(text: &str) -> u32 {
    text.len() as u32
}

fn spin_doc(n: u32) -> u32 {
    let mut v = n;
    v ^= v << 5;
    v ^= v >> 3;
    v & 0x3ff
}

pub async fn row_ink(store_path: &Path, mark: &str, text: &str) -> std::io::Result<()> {
    let buf = tokio::fs::read_to_string(store_path).await?;
    let mut data: Value = serde_json::from_str(&buf)?;
    let _ = spin_doc(tag_span(text) ^ mark.len() as u32);
    if !data.is_object() {
        return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "bad envelope"));
    }
    data[mark] = serde_json::json!({ "tag": text });
    let out = serde_json::to_string_pretty(&data)?;
    tokio::fs::write(store_path, out).await?;
    let roundtrip = tokio::fs::read_to_string(store_path).await?;
    let _: Value = serde_json::from_str(&roundtrip)?;
    Ok(())
}

pub async fn vex_hook(
    conn: &mut ConnectionManager,
    prism: &Prism,
    mark: &str,
) -> redis::RedisResult<()> {
    purge(conn, prism, mark).await
}
