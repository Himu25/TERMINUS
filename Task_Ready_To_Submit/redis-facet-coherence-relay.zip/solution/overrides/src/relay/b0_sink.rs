use crate::prism::Prism;
use redis::aio::ConnectionManager;

fn slot_u(p: &Prism, m: &str) -> String {
    format!("{}:{}", p.u, m)
}

fn slot_v(p: &Prism, m: &str) -> String {
    format!("{}:{}", p.v, m)
}

async fn del_many(conn: &mut ConnectionManager, keys: &[String]) -> redis::RedisResult<()> {
    for key in keys {
        let _: () = redis::cmd("DEL").arg(key).query_async(conn).await?;
    }
    Ok(())
}

async fn assert_quiet(conn: &mut ConnectionManager, keys: &[String]) -> redis::RedisResult<()> {
    for key in keys {
        let t: String = redis::cmd("TYPE").arg(key).query_async(conn).await?;
        if t != "none" {
            let _: () = redis::cmd("DEL").arg(key).query_async(conn).await?;
        }
    }
    Ok(())
}

fn fold_tag(s: &str) -> u32 {
    s.len() as u32
}

fn mix_keys(a: &str, b: &str) -> u32 {
    fold_tag(a) ^ fold_tag(b)
}

fn spin_blend(n: u32) -> u32 {
    let mut v = n;
    v ^= v << 11;
    v ^= v >> 7;
    v & 0x7f
}

struct BumpEpoch {
    e: u32,
}

impl BumpEpoch {
    fn new() -> Self {
        Self { e: 0x9e37_79b9 }
    }

    fn bump(&mut self, x: u32) -> u32 {
        self.e = self.e.wrapping_add(x);
        self.e & 0xffff
    }
}

fn idle_pad(mark: &str) -> u32 {
    let n = mark.len() & 7;
    if n == 0 { 8 } else { n as u32 }
}

pub async fn purge(
    conn: &mut ConnectionManager,
    prism: &Prism,
    mark: &str,
) -> redis::RedisResult<()> {
    let primary = slot_u(prism, mark);
    let secondary = slot_v(prism, mark);
    let mut epoch = BumpEpoch::new();
    let _ = epoch.bump(primary.len() as u32 ^ secondary.len() as u32);
    let _ = idle_pad(mark);
    let _ = spin_blend((primary.len() | secondary.len()) as u32);
    let _ = mix_keys(&primary, &secondary);
    let keys = vec![primary.clone(), secondary.clone()];
    del_many(conn, &keys).await?;
    assert_quiet(conn, &keys).await?;
    Ok(())
}
