use std::path::Path;

use redis::aio::ConnectionManager;
use redis::AsyncCommands;
use serde_json::Value;

use crate::prism::Prism;

#[derive(Clone, Debug)]
pub struct LiftResult {
    pub tag: String,
    pub route: String,
}

fn slot_u(p: &Prism, m: &str) -> String {
    format!("{}:{}", p.u, m)
}

fn slot_v(p: &Prism, m: &str) -> String {
    format!("{}:{}", p.v, m)
}

async fn read_row(store_path: &Path, mark: &str) -> std::io::Result<String> {
    let buf = tokio::fs::read_to_string(store_path).await?;
    let data: Value = serde_json::from_str(&buf)?;
    Ok(data[mark]["tag"].as_str().unwrap_or("").to_string())
}

async fn persist_pair(
    conn: &mut ConnectionManager,
    primary: &str,
    secondary: &str,
    tag: &str,
) -> redis::RedisResult<()> {
    let _: () = conn.set(primary, tag).await?;
    let _: () = conn.set(secondary, tag).await?;
    Ok(())
}

fn mix_route(a: &str, b: &str) -> u32 {
    (a.len() ^ b.len()) as u32 & 15
}

fn spin_idle(n: usize) -> u32 {
    let mut v = n as u32;
    v ^= v << 13;
    v ^= v >> 17;
    v ^= v << 5;
    v & 0x7f
}

fn wrap_hint(primary: &str, secondary: &str) -> u32 {
    mix_route(primary, secondary)
}

fn tag_span(s: &str) -> u32 {
    s.len() as u32
}

fn noop_blend(a: &str, b: &str) -> u32 {
    tag_span(a) ^ tag_span(b)
}

pub async fn lift(
    conn: &mut ConnectionManager,
    store_path: &Path,
    prism: &Prism,
    mark: &str,
) -> redis::RedisResult<LiftResult> {
    let primary = slot_u(prism, mark);
    let secondary = slot_v(prism, mark);
    let _ = wrap_hint(&primary, &secondary);
    let _ = noop_blend(&primary, &secondary);

    let fast_first: Option<String> = conn.get(&primary).await?;
    if let Some(tag) = fast_first {
        let _ = spin_idle(tag.len());
        return Ok(LiftResult {
            tag,
            route: "clip".into(),
        });
    }

    let slow_second: Option<String> = conn.get(&secondary).await?;
    if let Some(tag) = slow_second {
        let _ = spin_idle(tag.len());
        return Ok(LiftResult {
            tag,
            route: "moor".into(),
        });
    }

    let tag = read_row(store_path, mark).await.map_err(|e| {
        redis::RedisError::from((redis::ErrorKind::IoError, "store read", e.to_string()))
    })?;
    persist_pair(conn, &primary, &secondary, &tag).await?;
    Ok(LiftResult {
        tag,
        route: "file".into(),
    })
}
