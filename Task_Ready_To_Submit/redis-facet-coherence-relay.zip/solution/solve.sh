#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

ensure_redis() {
  if redis-cli -h 127.0.0.1 -p 6379 ping 2>/dev/null | grep -q PONG; then
    return 0
  fi
  redis-server --save "" --appendonly no --daemonize yes --bind 127.0.0.1 --port 6379
  for _ in $(seq 1 50); do
    if redis-cli -h 127.0.0.1 -p 6379 ping 2>/dev/null | grep -q PONG; then
      return 0
    fi
    sleep 0.2
  done
  echo "redis liveness guard failed: 127.0.0.1:6379 did not answer PING" >&2
  return 1
}

read_props_prefixes() {
  local u="" v=""
  while IFS= read -r line; do
    local st="${line#"${line%%[![:space:]]*}"}"
    st="${st%"${st##*[![:space:]]}"}"
    [[ -z "$st" || "$st" == \#* ]] && continue
    local key="${line%%=*}"
    local val="${line#*=}"
    key="${key//[[:space:]]/}"
    val="${val#"${val%%[![:space:]]*}"}"
    val="${val%"${val##*[![:space:]]}"}"
    case "$key" in
      U) u="$val" ;;
      V) v="$val" ;;
    esac
  done < /app/config/runtime.props
  printf '%s\n%s\n' "$u" "$v"
}

verify_cord_quiet_for_mark() {
  local u="$1" v="$2" mark="$3"
  local ku="${u}:${mark}"
  local kv="${v}:${mark}"
  local tu tv
  tu="$(redis-cli -h 127.0.0.1 -p 6379 TYPE "$ku" 2>/dev/null | tr -d '\r')"
  tv="$(redis-cli -h 127.0.0.1 -p 6379 TYPE "$kv" 2>/dev/null | tr -d '\r')"
  if [[ "$tu" != "none" || "$tv" != "none" ]]; then
    echo "cord slots not quiet for mark ${mark}: ${ku}=${tu} ${kv}=${tv}" >&2
    return 1
  fi
}

ensure_redis

if [[ ! -f "${ROOT_DIR}/overrides/src/quay/d2_lift.rs" ]]; then
  echo "missing oracle sources under ${ROOT_DIR}/overrides/src" >&2
  exit 1
fi

install -m 0644 "${ROOT_DIR}/overrides/src/stripe_lane/mod.rs" /app/src/stripe_lane/mod.rs
install -m 0644 "${ROOT_DIR}/overrides/src/relay/b0_sink.rs" /app/src/relay/b0_sink.rs
install -m 0644 "${ROOT_DIR}/overrides/src/quay/d2_lift.rs" /app/src/quay/d2_lift.rs

cargo build --release --manifest-path /app/Cargo.toml
install -m 0755 /app/target/release/shim_probe /app/bin/shim_probe
python3 /app/tools/run_probe.py

mapfile -t prefixes < <(read_props_prefixes)
prop_u="${prefixes[0]}"
prop_v="${prefixes[1]}"

python3 <<'PY'
import json
from pathlib import Path

out = Path("/app/output/coherence_audit.json")
store = Path("/app/var/facet_store.json")
audit = json.loads(out.read_text(encoding="utf-8"))
data = json.loads(store.read_text(encoding="utf-8"))
allowed = {
    "momentum_flag",
    "hollow_state",
    "clip_hits",
    "fold_digest",
    "route_histogram",
}
if set(audit) != allowed:
    raise SystemExit(f"unexpected audit keys: {sorted(audit)}")
hist = audit["route_histogram"]
for key in ("r0", "r1", "r2"):
    if key not in hist:
        raise SystemExit(f"missing histogram bucket {key}")
if not isinstance(data, dict):
    raise SystemExit("facet_store not an object")
for mark, row in data.items():
    if set(row) != {"tag"}:
        raise SystemExit(f"bad row shape for {mark}")
PY

while IFS= read -r mark; do
  [[ -z "$mark" ]] && continue
  verify_cord_quiet_for_mark "$prop_u" "$prop_v" "$mark"
done < <(python3 -c 'import json; d=json.load(open("/app/data/seed.json")); print("\n".join(d))')
