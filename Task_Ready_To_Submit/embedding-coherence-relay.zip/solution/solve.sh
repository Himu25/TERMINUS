#!/bin/bash
set -euo pipefail

log() { printf '[oracle] %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

log "preflight: relay workspace layout"
require_file /app/Cargo.toml
require_file /app/config/relay.toml
require_file /app/registry/embed_manifest.json
require_file /app/data/corpus_default.json
require_file /app/data/query_specs.jsonl
for src in token_lane.rs vec_core.rs norm_hub.rs blend_gate.rs weight_vault.rs relay_scan.rs; do
  require_file "${ROOT_DIR}/oracle/${src}"
done
mkdir -p /app/bin /app/output

log "survey: registry contract vs bench thresholds"
python3 - <<'PY'
import json
from pathlib import Path

manifest = json.loads(Path("/app/registry/embed_manifest.json").read_text())
print("manifest tokenizer_rev", manifest.get("tokenizer_rev"))
print("manifest weight_rev", manifest.get("weight_rev"))
print("manifest weight_active", manifest.get("weight_active"))
for line in Path("/app/config/relay.toml").read_text().splitlines():
    if any(tok in line for tok in ("floor", "integrity", "parity", "billing")):
        print(line.strip())
PY

log "restore manifest-driven tokenizer table"
cp "${ROOT_DIR}/oracle/token_lane.rs" /app/token_lane/mod.rs

log "restore full-width lane materialization"
cp "${ROOT_DIR}/oracle/vec_core.rs" /app/vec_core/mod.rs

log "align index and query normalization stages"
sed -i '/^pub fn apply_index/,/^}$/ s/l1_unit(slice)/l2_unit(slice)/' /app/norm_hub/mod.rs

log "neutralize index-side taper gain"
cp "${ROOT_DIR}/oracle/blend_gate.rs" /app/blend_gate/mod.rs

log "load complete migrated weight table from manifest"
cp "${ROOT_DIR}/oracle/weight_vault.rs" /app/weight_vault/mod.rs

log "restore full-vector retrieval scoring and realm filter"
cp "${ROOT_DIR}/oracle/relay_scan.rs" /app/relay_scan/mod.rs

log "patch bench driver active dimension reporting"
sed -i 's/active_embed_dim: vec_core::lane_width(dim.max(1)),/active_embed_dim: dim,/' /app/src/report_driver.rs

log "patch gold label depth to match bench top_k"
sed -i 's/take(3.min(cfg.top_k))/take(cfg.top_k)/' /app/src/goldgen.rs

log "release build"
export CARGO_TARGET_DIR=/app/output/cargo-target
cd /app
cargo build --release --manifest-path /app/Cargo.toml
install -m 0755 /app/output/cargo-target/release/goldgen /app/bin/goldgen
install -m 0755 /app/output/cargo-target/release/relay_bench /app/bin/relay_bench

log "regenerate default query gold labels"
/app/bin/goldgen \
  /app/data/corpus_default.json \
  /app/data/query_specs.jsonl \
  /app/data/queries_default.jsonl

log "write default bench report"
/app/bin/relay_bench \
  /app/data/queries_default.jsonl \
  /app/output/embed_relay_bench.json

log "post-run validation against relay.toml"
python3 - <<'PY'
import json
from pathlib import Path

cfg = {}
for line in Path("/app/config/relay.toml").read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    key, val = line.split("=", 1)
    key, val = key.strip(), val.strip()
    if key.endswith("_floor") or key.startswith("min_"):
        cfg[key] = float(val)
    elif key == "billing_pack_min_gold_hits":
        cfg[key] = int(float(val))

report = json.loads(Path("/app/output/embed_relay_bench.json").read_text())
manifest = json.loads(Path("/app/registry/embed_manifest.json").read_text())
assert report["status"] == "ok", report
assert report["active_embed_dim"] == report["vector_dim"], report
assert report["embed_integrity"] >= cfg["min_embed_integrity"], report
assert report["norm_parity_rate"] >= cfg["min_norm_parity"], report
assert report["weight_rev_loaded"] == report["weight_rev_manifest"], report
assert report["tokenizer_rev_manifest"] == manifest["tokenizer_rev"], report
assert report["mean_recall_at_10"] >= cfg["recall_floor"], report
assert report["mean_ndcg_at_10"] >= cfg["ndcg_floor"], report
billing = next(q for q in report["queries"] if q["query_id"] == "q_billing_refund")
assert billing["recall_at_10"] >= cfg["billing_pack_recall_floor"], billing
assert billing["gold_hits"] >= cfg["billing_pack_min_gold_hits"], billing
print(
    "ok",
    report["embed_integrity"],
    report["mean_recall_at_10"],
    report["norm_parity_rate"],
    report["weight_rev_loaded"],
    report["tokenizer_rev_manifest"],
)
PY

log "oracle complete"
