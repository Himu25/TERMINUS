fn l2_unit(slice: &mut [f64]) {
    let mut sum = 0.0;
    for v in slice.iter() {
        sum += v * v;
    }
    if sum == 0.0 {
        return;
    }
    let inv = 1.0 / sum.sqrt();
    for v in slice.iter_mut() {
        *v *= inv;
    }
}

fn l1_unit(slice: &mut [f64]) {
    let mut sum = 0.0;
    for v in slice.iter() {
        sum += v.abs();
    }
    if sum == 0.0 {
        return;
    }
    for v in slice.iter_mut() {
        *v /= sum;
    }
}

fn legacy_mix(slice: &mut [f64], query_style: bool) {
    if query_style {
        l2_unit(slice);
    } else {
        l1_unit(slice);
    }
    let _ = slice.len();
}

/// Normalize vectors on the query encoding path.
pub fn apply_query(slice: &mut [f64]) {
    l2_unit(slice);
}

/// Normalize vectors on the index materialization path.
pub fn apply_index(slice: &mut [f64]) {
    l2_unit(slice);
}

pub fn head_energy(slice: &[f64]) -> f64 {
    slice.iter().map(|v| v * v).sum::<f64>().sqrt()
}

pub fn parity_probe(query_slice: &[f64], index_slice: &[f64]) -> f64 {
    let qn = head_energy(query_slice);
    let dn = head_energy(index_slice);
    if qn == 0.0 || dn == 0.0 {
        return 0.0;
    }
    1.0 - (qn - dn).abs()
}
