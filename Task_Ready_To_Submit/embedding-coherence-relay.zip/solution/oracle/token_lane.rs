use std::collections::HashSet;
use std::fs;
use std::sync::OnceLock;

static STOPS: OnceLock<HashSet<String>> = OnceLock::new();

fn stop_set() -> &'static HashSet<String> {
    STOPS.get_or_init(|| {
        let mut out = HashSet::new();
        if let Ok(raw) = fs::read_to_string("/app/config/stopwords.txt") {
            for tok in raw.split_whitespace() {
                out.insert(tok.to_ascii_lowercase());
            }
        }
        out
    })
}

#[derive(serde::Deserialize)]
struct Manifest {
    tokenizer_rev: u32,
    tokenizer_active: String,
}

fn read_manifest() -> Option<Manifest> {
    let raw = fs::read_to_string("/app/registry/embed_manifest.json").ok()?;
    serde_json::from_str(&raw).ok()
}

fn vocab_source(active: &str, _rev: u32) -> String {
    format!("/app/registry/{active}")
}

fn load_merges() -> Vec<String> {
    let (active, rev) = read_manifest()
        .map(|m| (m.tokenizer_active, m.tokenizer_rev))
        .unwrap_or_else(|| ("vocab_r4.txt".to_string(), 4));
    let path = vocab_source(&active, rev);
    let Ok(body) = fs::read_to_string(&path) else {
        return Vec::new();
    };
    body.lines()
        .map(str::trim)
        .filter(|line| !line.is_empty() && !line.starts_with('#'))
        .map(str::to_string)
        .collect()
}

fn strip_realm_tags(raw: &str) -> String {
    raw.split_whitespace()
        .filter(|part| !part.starts_with("realm:"))
        .collect::<Vec<_>>()
        .join(" ")
}

fn split_legacy(raw: &str) -> Vec<String> {
    strip_realm_tags(raw)
        .to_ascii_lowercase()
        .split_whitespace()
        .map(str::to_string)
        .collect()
}

fn split_current(raw: &str) -> Vec<String> {
    let mut tokens = Vec::new();
    let mut cur = String::new();
    let flush = |cur: &mut String, tokens: &mut Vec<String>| {
        if !cur.is_empty() {
            tokens.push(cur.clone());
            cur.clear();
        }
    };
    for ch in strip_realm_tags(raw).to_ascii_lowercase().chars() {
        if ch.is_ascii_alphanumeric() || ch == '-' || ch == '.' {
            cur.push(ch);
        } else {
            flush(&mut cur, &mut tokens);
        }
    }
    flush(&mut cur, &mut tokens);
    let stops = stop_set();
    tokens
        .into_iter()
        .filter(|t| !stops.contains(t))
        .collect()
}

/// Tokenize user text for the embedding lane.
pub fn split(raw: &str) -> Vec<String> {
    let merges = load_merges();
    if merges.is_empty() {
        return split_legacy(raw);
    }
    let mut tokens = split_current(raw);
    for pair in merges {
        let parts: Vec<&str> = pair.split_whitespace().collect();
        if parts.len() >= 3 {
            let needle = format!("{} {}", parts[0], parts[1]);
            let glued = parts[2].to_string();
            tokens = tokens
                .into_iter()
                .flat_map(|t| {
                    if t == needle {
                        vec![glued.clone()]
                    } else {
                        vec![t]
                    }
                })
                .collect();
        } else if parts.len() == 2 {
            let needle = format!("{} {}", parts[0], parts[1]);
            let glued = format!("{}{}", parts[0], parts[1]);
            tokens = tokens
                .into_iter()
                .flat_map(|t| {
                    if t == needle {
                        vec![glued.clone()]
                    } else {
                        vec![t]
                    }
                })
                .collect();
        }
    }
    tokens
}
