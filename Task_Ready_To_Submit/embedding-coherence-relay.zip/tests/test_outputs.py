"""Validate embed_relay_bench.json after embedding relay pipeline repair.

Checks /app/output/embed_relay_bench.json against /app/config/relay.toml guardrails,
schema contracts in /app/docs/architecture.md, and regression packs named in
/app/docs/fixture_queries.txt. Fixture packs ship pre-baked gold labels independent
of the agent's goldgen output; default-run recall floors are not re-checked against
regenerated gold.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
from collections import Counter
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "embed_relay_bench.json"
CFG = APP / "config" / "relay.toml"
# Realm population counts are derived from corpus_default.json at verify time.
CORPUS = APP / "data" / "corpus_default.json"
DEFAULT_QUERIES = APP / "data" / "queries_default.jsonl"
FIXTURES = Path("/tests/fixtures")
# Isolated from /app/output/cargo-target so a partial agent build cannot block verifier rebuilds.
VERIFIER_CARGO_TARGET = Path("/tmp/tbench-verifier-cargo-target")
CARGO_BUILD_TIMEOUT_SEC = 540

REPORT_KEYS = frozenset(
    {
        "status",
        "corpus_vectors",
        "vector_dim",
        "active_embed_dim",
        "queries_total",
        "embed_integrity",
        "norm_parity_rate",
        "weight_rev_loaded",
        "weight_rev_manifest",
        "tokenizer_rev_manifest",
        "mean_recall_at_10",
        "mean_ndcg_at_10",
        "report_digest",
        "queries",
    }
)
QUERY_KEYS = frozenset({"query_id", "recall_at_10", "ndcg_at_10", "gold_hits", "filter_kept"})

# Shipped relay.toml defaults; enforced in tests so lowering relay.toml cannot pass.
ENFORCED_FLOORS: dict[str, float | int] = {
    "recall_floor": 0.75,
    "ndcg_floor": 0.75,
    "min_embed_integrity": 0.95,
    "min_norm_parity": 0.95,
    "tight_security_recall_floor": 0.5,
    "billing_pack_recall_floor": 0.6667,
    "billing_pack_min_gold_hits": 2,
}


def _effective_floor(cfg: dict[str, float | int], key: str) -> float | int:
    """Max of relay.toml value and shipped minimum (anti-tamper)."""
    return max(cfg[key], ENFORCED_FLOORS[key])


def _pass_status() -> str:
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line.startswith("pass_status"):
            return line.split("=", 1)[1].strip()
    return "ok"


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "vector_dim": 64,
        "top_k": 10,
        "recall_floor": 0.75,
        "ndcg_floor": 0.75,
        "min_embed_integrity": 0.95,
        "min_norm_parity": 0.95,
        "tight_security_recall_floor": 0.5,
        "billing_pack_recall_floor": 0.6667,
        "billing_pack_min_gold_hits": 2,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in (
            "recall_floor",
            "ndcg_floor",
            "min_embed_integrity",
            "min_norm_parity",
            "tight_security_recall_floor",
            "billing_pack_recall_floor",
        ):
            cfg[key] = float(val)
        elif key == "billing_pack_min_gold_hits":
            cfg[key] = int(float(val))
        elif key in ("vector_dim", "top_k"):
            cfg[key] = int(float(val))
    return cfg


def _digest_payload(report: dict) -> dict:
    return {
        "status": report["status"],
        "corpus_vectors": report["corpus_vectors"],
        "vector_dim": report["vector_dim"],
        "active_embed_dim": report["active_embed_dim"],
        "queries_total": report["queries_total"],
        "embed_integrity": report["embed_integrity"],
        "norm_parity_rate": report["norm_parity_rate"],
        "weight_rev_loaded": report["weight_rev_loaded"],
        "weight_rev_manifest": report["weight_rev_manifest"],
        "tokenizer_rev_manifest": report["tokenizer_rev_manifest"],
        "mean_recall_at_10": report["mean_recall_at_10"],
        "mean_ndcg_at_10": report["mean_ndcg_at_10"],
        "report_digest": "",
        "queries": report["queries"],
    }


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


_VERIFIER_BUILD_ERROR: str | None = None


def _rebuild_relay_bench(env: dict[str, str] | None = None) -> None:
    global _VERIFIER_BUILD_ERROR  # noqa: PLW0603
    build_env = dict(env or os.environ.copy())
    build_env["CARGO_TARGET_DIR"] = str(VERIFIER_CARGO_TARGET)
    result = subprocess.run(
        ["cargo", "build", "--release", "--manifest-path", str(APP / "Cargo.toml")],
        cwd=APP,
        env=build_env,
        capture_output=True,
        text=True,
        timeout=CARGO_BUILD_TIMEOUT_SEC,
    )
    if result.returncode != 0:
        _VERIFIER_BUILD_ERROR = result.stderr[:2000] or "cargo build failed"
        return
    release = VERIFIER_CARGO_TARGET / "release"
    inst = subprocess.run(
        ["install", "-m", "0755", str(release / "relay_bench"), "/app/bin/relay_bench"],
        capture_output=True,
        text=True,
    )
    if inst.returncode != 0:
        _VERIFIER_BUILD_ERROR = inst.stderr[:500] or "install failed"


def _assert_query_row(row: dict) -> None:
    assert set(row) == QUERY_KEYS
    assert isinstance(row["query_id"], str) and row["query_id"]
    for key in ("recall_at_10", "ndcg_at_10"):
        assert isinstance(row[key], (int, float))
        assert 0.0 <= float(row[key]) <= 1.0
    assert isinstance(row["gold_hits"], int)
    assert isinstance(row["filter_kept"], int)
    assert row["gold_hits"] >= 0
    assert row["filter_kept"] >= 0


def _assert_report_schema(data: dict) -> None:
    assert set(data) == REPORT_KEYS
    assert isinstance(data["status"], str) and data["status"] in {_pass_status(), "fail"}
    for int_key in (
        "corpus_vectors",
        "vector_dim",
        "active_embed_dim",
        "queries_total",
        "weight_rev_loaded",
        "weight_rev_manifest",
        "tokenizer_rev_manifest",
    ):
        assert isinstance(data[int_key], int), int_key
        assert data[int_key] >= 0, int_key
    for float_key in (
        "embed_integrity",
        "norm_parity_rate",
        "mean_recall_at_10",
        "mean_ndcg_at_10",
    ):
        assert isinstance(data[float_key], (int, float)), float_key
        assert float(data[float_key]) >= 0.0, float_key
    digest = data["report_digest"]
    assert isinstance(digest, str) and len(digest) == 64
    assert digest == digest.lower()
    assert re.fullmatch(r"[0-9a-f]{64}", digest)
    assert isinstance(data["queries"], list)
    for row in data["queries"]:
        _assert_query_row(row)


def _load_report(path: Path = OUT) -> dict:
    assert path.is_file(), f"missing report at {path}"
    data = json.loads(path.read_text(encoding="utf-8"))
    _assert_report_schema(data)
    return data


def _run_bench(
    query_path: Path,
    out_path: Path = OUT,
    corpus_path: Path | None = None,
    *,
    rebuild: bool = False,
) -> None:
    if rebuild:
        _rebuild_relay_bench()
    assert _VERIFIER_BUILD_ERROR is None, (
        f"verifier cargo build failed; fixture-pack replay impossible: {_VERIFIER_BUILD_ERROR}"
    )
    bench_bin = Path("/app/bin/relay_bench")
    assert bench_bin.is_file(), "relay_bench binary missing after build"
    env = os.environ.copy()
    if corpus_path is not None:
        env["TB_CORPUS_PATH"] = str(corpus_path)
    else:
        env.pop("TB_CORPUS_PATH", None)
    if out_path.exists():
        out_path.unlink()
    result = subprocess.run(
        [
            str(bench_bin),
            query_path.as_posix(),
            out_path.as_posix(),
        ],
        cwd=APP,
        env=env,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, (
        f"relay_bench exited {result.returncode}: {result.stderr[:1000]}"
    )
    assert json.loads(out_path.read_text(encoding="utf-8"))["queries_total"] >= 0


def _query_row(report: dict, query_id: str) -> dict:
    return next(q for q in report["queries"] if q["query_id"] == query_id)


def _jsonl_lines(path: Path) -> int:
    return sum(1 for line in path.read_text(encoding="utf-8").splitlines() if line.strip())


def _load_queries_jsonl(path: Path) -> list[dict]:
    rows: list[dict] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            rows.append(json.loads(line))
    return rows


def _realm_hint(query: str) -> str | None:
    for part in query.split():
        if part.startswith("realm:"):
            return part.split(":", 1)[1]
    return None


def _realm_counts_from_corpus() -> dict[str, int]:
    corpus = json.loads(CORPUS.read_text(encoding="utf-8"))
    counts = Counter(doc["realm"] for doc in corpus["vectors"])
    return dict(counts)


def _expected_filter_kept(realm: str | None, corpus_vectors: int, realm_counts: dict[str, int]) -> int:
    if realm is None:
        return corpus_vectors
    return realm_counts[realm]


def _assert_filter_kept_for_queries(report: dict, queries_path: Path) -> None:
    """filter_kept must match the tagged realm's corpus population."""
    corpus_vectors = report["corpus_vectors"]
    realm_counts = _realm_counts_from_corpus()
    assert sum(realm_counts.values()) == corpus_vectors
    for spec in _load_queries_jsonl(queries_path):
        realm = _realm_hint(spec["query"])
        row = _query_row(report, spec["query_id"])
        expected = _expected_filter_kept(realm, corpus_vectors, realm_counts)
        assert realm is not None, spec["query_id"]
        assert realm_counts[realm] == expected, realm
        assert row["filter_kept"] == expected, (
            f"{spec['query_id']} filter_kept={row['filter_kept']} expected {expected} "
            f"for realm:{realm}"
        )
        assert row["filter_kept"] < corpus_vectors, spec["query_id"]


@pytest.fixture(scope="session", autouse=True)
def _verifier_relay_bench() -> None:
    """Rebuild relay_bench for fixture replays; do not regenerate default gold."""
    _rebuild_relay_bench()
    # Build failure is non-fatal here; tests that need the binary will assert on it.


def test_default_pass_status() -> None:
    """Default bench report status matches pass_status in relay.toml."""
    bench = APP / "bin" / "relay_bench"
    assert bench.is_file() and os.access(bench, os.X_OK)
    report = _load_report()
    assert report["status"] == _pass_status()


def test_corpus_vectors_populated() -> None:
    """Report indexes the full default corpus."""
    report = _load_report()
    assert report["corpus_vectors"] > 0


def test_report_schema_and_digest() -> None:
    """Default bench report matches architecture schema and digest contract."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_active_dim_matches_vector_dim() -> None:
    """Healthy relay uses the full configured vector width."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["vector_dim"] == cfg["vector_dim"]
    assert report["active_embed_dim"] == report["vector_dim"]


def test_relay_guardrails_not_neutered() -> None:
    """relay.toml quality floors remain at shipped thresholds."""
    cfg = _parse_cfg()
    for key, minimum in ENFORCED_FLOORS.items():
        if key in cfg:
            assert cfg[key] >= minimum, f"{key} lowered below shipped floor"


def test_embed_integrity_floor() -> None:
    """Index-side vectors are unit-normalized across the corpus."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["embed_integrity"] >= _effective_floor(cfg, "min_embed_integrity")


def test_norm_parity_floor() -> None:
    """Query and index paths share normalization behavior."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["norm_parity_rate"] >= _effective_floor(cfg, "min_norm_parity")


def test_weight_revision_aligned() -> None:
    """Loaded weight revision matches registry manifest."""
    report = _load_report()
    assert report["weight_rev_loaded"] == report["weight_rev_manifest"]


def test_tokenizer_revision_aligned() -> None:
    """Reported tokenizer revision matches embed_manifest.json."""
    manifest = json.loads((APP / "registry" / "embed_manifest.json").read_text(encoding="utf-8"))
    report = _load_report()
    assert report["tokenizer_rev_manifest"] == manifest["tokenizer_rev"]


def test_queries_total_matches_jsonl() -> None:
    """Report query count matches non-empty default JSONL lines."""
    report = _load_report()
    expected = _jsonl_lines(DEFAULT_QUERIES)
    assert report["queries_total"] == expected
    assert len(report["queries"]) == expected


def test_default_filter_kept_matches_realm_population() -> None:
    """Realm-tagged default queries report filter_kept equal to realm corpus counts."""
    report = _load_report()
    _assert_filter_kept_for_queries(report, DEFAULT_QUERIES)


def test_deterministic_default_run() -> None:
    """Identical default inputs yield byte-identical bench output."""
    first = OUT.read_bytes()
    _run_bench(DEFAULT_QUERIES, OUT, rebuild=True)
    second = OUT.read_bytes()
    assert first == second


def test_tight_recall_pack() -> None:
    """pack_tight_recall satisfies tight_security floor for q_tight_security (pre-baked gold)."""
    pack = FIXTURES / "pack_tight_recall"
    queries = pack / "queries.jsonl"
    assert queries.is_file(), "fixture queries.jsonl missing — regenerate from oracle"
    out = APP / "output" / "bench_pack_tight.json"
    _run_bench(queries, out, CORPUS)
    report = _load_report(out)
    row = _query_row(report, "q_tight_security")
    assert row["recall_at_10"] >= ENFORCED_FLOORS["tight_security_recall_floor"]
    _assert_filter_kept_for_queries(report, queries)


def test_skew_query_pack() -> None:
    """pack_skew_queries benches clean on default corpus (pre-baked gold, hard recall floor)."""
    pack = FIXTURES / "pack_skew_queries"
    queries = pack / "queries.jsonl"
    assert queries.is_file(), "fixture queries.jsonl missing — regenerate from oracle"
    out = APP / "output" / "bench_pack_skew.json"
    _run_bench(queries, out, CORPUS)
    report = _load_report(out)
    floor = _effective_floor(_parse_cfg(), "recall_floor")
    assert report["mean_recall_at_10"] >= floor
    _assert_filter_kept_for_queries(report, queries)


def test_skew_pack_ndcg_floor() -> None:
    """pack_skew_queries aggregate ndcg meets relay.toml ndcg_floor."""
    pack = FIXTURES / "pack_skew_queries"
    queries = pack / "queries.jsonl"
    out = APP / "output" / "bench_pack_skew_ndcg.json"
    _run_bench(queries, out, CORPUS)
    report = _load_report(out)
    cfg = _parse_cfg()
    floor = _effective_floor(cfg, "ndcg_floor")
    assert report["mean_ndcg_at_10"] >= floor


def test_realm_gate_pack() -> None:
    """pack_realm_gate requires realm filtering against pre-baked cross-realm gold."""
    pack = FIXTURES / "pack_realm_gate"
    queries = pack / "queries.jsonl"
    assert queries.is_file(), "fixture queries.jsonl missing — regenerate from oracle"
    out = APP / "output" / "bench_pack_realm_gate.json"
    _run_bench(queries, out, CORPUS)
    report = _load_report(out)
    _assert_filter_kept_for_queries(report, queries)
    min_hit_ratio = 0.7
    for spec in _load_queries_jsonl(queries):
        row = _query_row(report, spec["query_id"])
        gold_total = len(spec["gold_ids"])
        min_hits = int(gold_total * min_hit_ratio)
        assert row["gold_hits"] >= min_hits, (
            f"{spec['query_id']} gold_hits={row['gold_hits']} below floor {min_hits}"
        )
        assert row["recall_at_10"] >= min_hit_ratio, (
            f"{spec['query_id']} recall_at_10={row['recall_at_10']} below floor {min_hit_ratio}"
        )
