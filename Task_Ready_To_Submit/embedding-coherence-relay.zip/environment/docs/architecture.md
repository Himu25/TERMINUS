# Architecture notes

The embedding relay path is corpus JSON → token_lane → vec_core with weight_vault slots → norm_hub → blend_gate (index path only) → relay_scan top-k recall. On the index path, vec_core applies norm_hub to the active lane span before blend_gate tail taper; reversing that call order breaks fixture-pack recall.

`/app/output/embed_relay_bench.json` top-level keys: status, corpus_vectors, vector_dim, active_embed_dim, queries_total, embed_integrity, norm_parity_rate, weight_rev_loaded, weight_rev_manifest, tokenizer_rev_manifest, mean_recall_at_10, mean_ndcg_at_10, report_digest, queries.

Each queries row: query_id, recall_at_10, ndcg_at_10, gold_hits, filter_kept. Ranking metrics are between zero and one. gold_hits counts gold neighbors in the top-k set. filter_kept counts corpus documents in the query's tagged realm (or the full corpus when no realm tag is present). queries_total must equal the number of non-empty lines in the input JSONL.

Verifier replay may write auxiliary bench reports under `/app/output/bench_pack_tight.json`, `/app/output/bench_pack_skew.json`, `/app/output/bench_pack_skew_ndcg.json`, or `/app/output/bench_pack_realm_gate.json` when exercising fixture packs.

Quality gates compare mean recall, mean ndcg, embed_integrity, norm_parity_rate, and active_embed_dim against floors in `relay.toml`. Queries carry `realm:` tags that relay_scan filtering must honor.

Digest covers every report field except `report_digest`, serialized as compact JSON with `report_digest` set to an empty string.

Gold labels are materialized with `/app/bin/goldgen` from `/app/data/query_specs.jsonl`; do not hand-edit queries after regeneration. goldgen must label with the same top_k the bench driver uses.

Registry manifest `/app/registry/embed_manifest.json` names the active tokenizer table and weight revision. Tokenizer merge rows are whitespace-separated triples: left token, right token, merged token. Active lane width must equal vector_dim in vec_core source; shell-level `RELAY_LANE_PAD` overrides are not honored on verifier rebuilds.

Release builds use `CARGO_TARGET_DIR=/app/output/cargo-target`. Install release binaries from `/app/output/cargo-target/release/` into `/app/bin/` after `cargo build --release`.
