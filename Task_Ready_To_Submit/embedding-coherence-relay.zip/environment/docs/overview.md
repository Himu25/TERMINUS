Cross-service embedding relay under `/app` serves online retrieval from a shared corpus index.
