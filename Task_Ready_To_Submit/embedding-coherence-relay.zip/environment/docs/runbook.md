Build artifacts land under `/app/output/cargo-target`; install from `/app/output/cargo-target/release/` into `/app/bin/` after `cargo build --release`. Do not invoke `/app/target/release/` — that path is unused in this workspace. The Rust toolchain ships in the image at `/usr/local/cargo/bin` (also linked as `/usr/bin/cargo`).
Regenerate `/app/data/queries_default.jsonl` when the embedding path changes.
Manifest lives at `/app/registry/embed_manifest.json`.
Bench scoring rebuilds release artifacts from `/app` sources before evaluation.
