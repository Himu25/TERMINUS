/// Diagnostic helpers for lane energy audits (not on the hot bench path).
pub fn lane_energy(slice: &[f64]) -> f64 {
    slice.iter().map(|v| v * v).sum::<f64>().sqrt()
}

pub fn head_tail_ratio(slice: &[f64]) -> f64 {
    if slice.len() < 2 {
        return 1.0;
    }
    let mid = slice.len() / 2;
    let head: f64 = slice[..mid].iter().map(|v| v.abs()).sum();
    let tail: f64 = slice[mid..].iter().map(|v| v.abs()).sum();
    if tail == 0.0 {
        1.0
    } else {
        head / tail
    }
}
