/// Post-normalization gain on index-side lanes before scoring.
pub fn taper_index_tail(slice: &mut [f64]) {
    if slice.is_empty() {
        return;
    }
    let half = slice.len() / 2;
    for (i, v) in slice.iter_mut().enumerate() {
        if i >= half {
            *v *= 0.02;
        }
    }
}

pub fn query_gate(_slice: &mut [f64]) {}

pub fn lane_balance(slice: &[f64]) -> f64 {
    if slice.is_empty() {
        return 0.0;
    }
    let mid = slice.len() / 2;
    let head: f64 = slice[..mid].iter().map(|v| v * v).sum();
    let tail: f64 = slice[mid..].iter().map(|v| v * v).sum();
    (head - tail).abs()
}

pub fn tail_floor(slice: &[f64]) -> f64 {
    if slice.len() < 2 {
        return 0.0;
    }
    let mid = slice.len() / 2;
    slice[mid..].iter().map(|v| v.abs()).fold(0.0, f64::max)
}
