use serde::Deserialize;

#[derive(Debug, Clone)]
pub struct RelayCfg {
    pub vector_dim: usize,
    pub top_k: usize,
    pub recall_floor: f64,
    pub ndcg_floor: f64,
    pub min_embed_integrity: f64,
    pub min_norm_parity: f64,
    pub corpus_path: String,
    pub pass_status: String,
    pub tight_security_recall_floor: f64,
}

pub fn load(path: &str) -> Result<RelayCfg, String> {
    let body = std::fs::read_to_string(path).map_err(|e| e.to_string())?;
    let mut cfg = RelayCfg {
        vector_dim: 64,
        top_k: 10,
        recall_floor: 0.75,
        ndcg_floor: 0.75,
        min_embed_integrity: 0.95,
        min_norm_parity: 0.95,
        corpus_path: "/app/data/corpus_default.json".to_string(),
        pass_status: "ok".to_string(),
        tight_security_recall_floor: 0.5,
    };
    for line in body.lines() {
        let line = line.split('#').next().unwrap_or("").trim();
        if line.is_empty() || !line.contains('=') {
            continue;
        }
        let (key, val) = line.split_once('=').unwrap();
        match key.trim() {
            "vector_dim" => cfg.vector_dim = val.trim().parse().map_err(|e: std::num::ParseIntError| e.to_string())?,
            "top_k" => cfg.top_k = val.trim().parse().map_err(|e: std::num::ParseIntError| e.to_string())?,
            "recall_floor" => cfg.recall_floor = val.trim().parse().map_err(|e: std::num::ParseFloatError| e.to_string())?,
            "ndcg_floor" => cfg.ndcg_floor = val.trim().parse().map_err(|e: std::num::ParseFloatError| e.to_string())?,
            "min_embed_integrity" => cfg.min_embed_integrity = val.trim().parse().map_err(|e: std::num::ParseFloatError| e.to_string())?,
            "min_norm_parity" => cfg.min_norm_parity = val.trim().parse().map_err(|e: std::num::ParseFloatError| e.to_string())?,
            "corpus_path" => cfg.corpus_path = val.trim().to_string(),
            "pass_status" => cfg.pass_status = val.trim().to_string(),
            "tight_security_recall_floor" => cfg.tight_security_recall_floor = val.trim().parse().map_err(|e: std::num::ParseFloatError| e.to_string())?,
            _ => {}
        }
    }
    Ok(cfg)
}

#[derive(Debug, Deserialize)]
pub struct QueryRow {
    pub query_id: String,
    pub query: String,
    #[serde(default)]
    pub gold_ids: Vec<String>,
}

#[derive(Debug, Deserialize)]
pub struct CorpusDoc {
    pub id: String,
    pub text: String,
    pub realm: String,
}

#[derive(Debug, Deserialize)]
pub struct CorpusFile {
    pub vectors: Vec<CorpusDoc>,
}
