use crate::corpus;
use crate::relay_cfg::{QueryRow, RelayCfg};
use crate::relay_scan::{self, IndexedDoc};
use crate::vec_core;
use crate::weight_vault::SlotTable;
use serde::Serialize;
use sha2::{Digest, Sha256};
use std::path::Path;

#[derive(Debug, Clone, Serialize)]
pub struct QueryStat {
    pub query_id: String,
    pub recall_at_10: f64,
    pub ndcg_at_10: f64,
    pub gold_hits: u32,
    pub filter_kept: u32,
}

#[derive(Debug, Serialize)]
pub struct RelayReport {
    pub status: String,
    pub corpus_vectors: usize,
    pub vector_dim: usize,
    pub active_embed_dim: usize,
    pub queries_total: usize,
    pub embed_integrity: f64,
    pub norm_parity_rate: f64,
    pub weight_rev_loaded: u32,
    pub weight_rev_manifest: u32,
    pub tokenizer_rev_manifest: u32,
    pub mean_recall_at_10: f64,
    pub mean_ndcg_at_10: f64,
    pub report_digest: String,
    pub queries: Vec<QueryStat>,
}

fn round4(v: f64) -> f64 {
    (v * 10000.0).round() / 10000.0
}

fn embed_integrity(docs: &[IndexedDoc], dim: usize) -> f64 {
    if docs.is_empty() {
        return 0.0;
    }
    let span = vec_core::lane_width(dim);
    let mut ok = 0usize;
    for d in docs {
        let norm: f64 = d.vec[..span.min(d.vec.len())]
            .iter()
            .map(|x| x * x)
            .sum::<f64>()
            .sqrt();
        if norm > 0.0 && (norm - 1.0).abs() < 1e-4 {
            ok += 1;
        }
    }
    round4(ok as f64 / docs.len() as f64)
}

fn norm_parity(slots: &SlotTable, dim: usize) -> f64 {
    let probe = "billing refund chargeback policy semantic retrieval";
    let q = vec_core::materialize_query(probe, dim, slots);
    let d = vec_core::materialize_index(probe, dim, slots);
    let qn: f64 = q[..vec_core::lane_width(dim)]
        .iter()
        .map(|x| x * x)
        .sum::<f64>()
        .sqrt();
    let dn: f64 = d[..vec_core::lane_width(dim)]
        .iter()
        .map(|x| x * x)
        .sum::<f64>()
        .sqrt();
    if (qn - 1.0).abs() < 1e-6 && (dn - 1.0).abs() < 1e-6 {
        1.0
    } else if (qn - 1.0).abs() < 1e-6 && (dn - 1.0).abs() > 0.5 {
        0.0
    } else {
        round4(1.0 - (qn - dn).abs())
    }
}

fn digest_payload(report: &RelayReport) -> String {
    let stub = RelayReport {
        report_digest: String::new(),
        ..RelayReport {
            status: report.status.clone(),
            corpus_vectors: report.corpus_vectors,
            vector_dim: report.vector_dim,
            active_embed_dim: report.active_embed_dim,
            queries_total: report.queries_total,
            embed_integrity: report.embed_integrity,
            norm_parity_rate: report.norm_parity_rate,
            weight_rev_loaded: report.weight_rev_loaded,
            weight_rev_manifest: report.weight_rev_manifest,
            tokenizer_rev_manifest: report.tokenizer_rev_manifest,
            mean_recall_at_10: report.mean_recall_at_10,
            mean_ndcg_at_10: report.mean_ndcg_at_10,
            report_digest: String::new(),
            queries: report.queries.clone(),
        }
    };
    serde_json::to_string(&stub).unwrap_or_default()
}

pub fn load_queries(path: &Path) -> Result<Vec<QueryRow>, String> {
    let raw = std::fs::read_to_string(path).map_err(|e| e.to_string())?;
    let mut out = Vec::new();
    for line in raw.lines() {
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        out.push(serde_json::from_str(line).map_err(|e| e.to_string())?);
    }
    Ok(out)
}

pub fn run(cfg: &RelayCfg, cases: &[QueryRow]) -> Result<RelayReport, String> {
    let corpus_path = std::env::var("TB_CORPUS_PATH")
        .ok()
        .filter(|value| !value.is_empty())
        .unwrap_or_else(|| cfg.corpus_path.clone());
    let docs = corpus::load(Path::new(&corpus_path))?;
    let slots = SlotTable::load()?;
    let dim = cfg.vector_dim;
    let mut indexed = Vec::with_capacity(docs.len());
    for doc in &docs {
        indexed.push(IndexedDoc {
            id: doc.id.clone(),
            realm: doc.realm.clone(),
            vec: vec_core::materialize_index(&doc.text, dim, &slots),
        });
    }
    let integrity = embed_integrity(&indexed, dim);
    let parity = norm_parity(&slots, dim);
    let mut rows = Vec::new();
    for case in cases {
        let realm = relay_scan::realm_hint(&case.query);
        let qv = vec_core::materialize_query(&case.query, dim, &slots);
        let ranked = relay_scan::top_k(&qv, &indexed, cfg.top_k, realm.as_deref());
        let recall = round4(relay_scan::recall_at_k(&case.gold_ids, &ranked, cfg.top_k));
        let ndcg = round4(relay_scan::ndcg_at_k(&case.gold_ids, &ranked, cfg.top_k));
        let hits = relay_scan::gold_hits(&case.gold_ids, &ranked, cfg.top_k);
        let kept = if let Some(r) = &realm {
            indexed.iter().filter(|d| d.realm == *r).count() as u32
        } else {
            indexed.len() as u32
        };
        rows.push(QueryStat {
            query_id: case.query_id.clone(),
            recall_at_10: recall,
            ndcg_at_10: ndcg,
            gold_hits: hits,
            filter_kept: kept,
        });
    }
    let mean_recall = if rows.is_empty() {
        0.0
    } else {
        round4(rows.iter().map(|r| r.recall_at_10).sum::<f64>() / rows.len() as f64)
    };
    let mean_ndcg = if rows.is_empty() {
        0.0
    } else {
        round4(rows.iter().map(|r| r.ndcg_at_10).sum::<f64>() / rows.len() as f64)
    };
    let manifest_raw =
        std::fs::read_to_string("/app/registry/embed_manifest.json").unwrap_or_default();
    let tok_rev = serde_json::from_str::<serde_json::Value>(&manifest_raw)
        .ok()
        .and_then(|v| v.get("tokenizer_rev").and_then(|x| x.as_u64()))
        .unwrap_or(0) as u32;
    let mut report = RelayReport {
        status: cfg.pass_status.clone(),
        corpus_vectors: indexed.len(),
        vector_dim: dim,
        active_embed_dim: vec_core::lane_width(dim.max(1)),
        queries_total: cases.len(),
        embed_integrity: integrity,
        norm_parity_rate: parity,
        weight_rev_loaded: slots.loaded_rev,
        weight_rev_manifest: slots.manifest_rev,
        tokenizer_rev_manifest: tok_rev,
        mean_recall_at_10: mean_recall,
        mean_ndcg_at_10: mean_ndcg,
        report_digest: String::new(),
        queries: rows,
    };
    let digest = Sha256::digest(digest_payload(&report).as_bytes());
    report.report_digest = format!("{:x}", digest);
    Ok(report)
}

pub fn write_report(path: &Path, report: &RelayReport) -> Result<(), String> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    let body = serde_json::to_string_pretty(report).map_err(|e| e.to_string())?;
    std::fs::write(path, format!("{body}\n")).map_err(|e| e.to_string())
}
