use embed_relay::report_driver;
use embed_relay::corpus;
use embed_relay::relay_cfg::{QueryRow, RelayCfg};
use embed_relay::relay_scan::{self, IndexedDoc};
use embed_relay::vec_core;
use embed_relay::SlotTable;
use std::path::PathBuf;

#[derive(serde::Serialize)]
struct OutRow {
    query_id: String,
    query: String,
    gold_ids: Vec<String>,
}

fn main() -> Result<(), String> {
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.len() < 3 {
        eprintln!("usage: goldgen <corpus.json> <specs.jsonl> <out.jsonl>");
        std::process::exit(2);
    }
    let cfg = RelayCfg {
        vector_dim: 64,
        top_k: 10,
        recall_floor: 0.75,
        ndcg_floor: 0.75,
        min_embed_integrity: 0.95,
        min_norm_parity: 0.95,
        corpus_path: args[0].clone(),
        pass_status: "ok".to_string(),
        tight_security_recall_floor: 0.5,
    };
    let docs = corpus::load(PathBuf::from(&args[0]).as_path())?;
    let specs = report_driver::load_queries(PathBuf::from(&args[1]).as_path())?;
    let slots = SlotTable::load()?;
    let dim = cfg.vector_dim;
    let mut indexed = Vec::new();
    for doc in &docs {
        indexed.push(IndexedDoc {
            id: doc.id.clone(),
            realm: doc.realm.clone(),
            vec: vec_core::materialize_index(&doc.text, dim, &slots),
        });
    }
    let mut out_lines = Vec::new();
    for spec in specs {
        let realm = relay_scan::realm_hint(&spec.query);
        let qv = vec_core::materialize_query(&spec.query, dim, &slots);
        let ranked = relay_scan::top_k(&qv, &indexed, cfg.top_k, realm.as_deref());
        let gold: Vec<String> = ranked.into_iter().take(3.min(cfg.top_k)).collect();
        let row = OutRow {
            query_id: spec.query_id,
            query: spec.query,
            gold_ids: gold,
        };
        out_lines.push(serde_json::to_string(&row).map_err(|e| e.to_string())?);
    }
    std::fs::write(&args[2], out_lines.join("\n") + "\n").map_err(|e| e.to_string())?;
    Ok(())
}
