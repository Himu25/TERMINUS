use embed_relay::report_driver;
use embed_relay::relay_cfg::load as load_cfg;
use std::path::PathBuf;

fn main() -> Result<(), String> {
    let cfg_path = "/app/config/relay.toml";
    let query_path = PathBuf::from(
        std::env::args()
            .nth(1)
            .unwrap_or_else(|| "/app/data/queries_default.jsonl".to_string()),
    );
    let out_path = PathBuf::from(
        std::env::args()
            .nth(2)
            .unwrap_or_else(|| "/app/output/embed_relay_bench.json".to_string()),
    );
    let cfg = load_cfg(cfg_path)?;
    let cases = report_driver::load_queries(&query_path)?;
    let report = report_driver::run(&cfg, &cases)?;
    report_driver::write_report(&out_path, &report)
}
