use crate::relay_cfg::{CorpusDoc, CorpusFile};
use std::path::Path;

pub fn load(path: &Path) -> Result<Vec<CorpusDoc>, String> {
    let raw = std::fs::read_to_string(path).map_err(|e| e.to_string())?;
    let parsed: CorpusFile = serde_json::from_str(&raw).map_err(|e| e.to_string())?;
    Ok(parsed.vectors)
}
