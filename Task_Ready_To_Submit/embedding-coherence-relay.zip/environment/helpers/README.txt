Helper scripts are optional; primary entry is /app/tools/run_bench.
