use serde::Deserialize;
use std::collections::HashMap;
use std::fs;

#[derive(Debug, Deserialize)]
struct Manifest {
    weight_rev: u32,
    weight_active: String,
    tokenizer_rev: u32,
    tokenizer_active: String,
    vector_dim: usize,
}

#[derive(Debug, Deserialize)]
struct SlotFile {
    rev: u32,
    slots: HashMap<String, f64>,
}

pub struct SlotTable {
    pub loaded_rev: u32,
    pub manifest_rev: u32,
    map: HashMap<String, f64>,
    default_gain: f64,
}

impl SlotTable {
    fn read_manifest() -> Result<Manifest, String> {
        let manifest_raw =
            fs::read_to_string("/app/registry/embed_manifest.json").map_err(|e| e.to_string())?;
        serde_json::from_str(&manifest_raw).map_err(|e| e.to_string())
    }

    fn load_slots(path: &str) -> Result<SlotFile, String> {
        let body = fs::read_to_string(path).map_err(|e| e.to_string())?;
        serde_json::from_str(&body).map_err(|e| e.to_string())
    }

    pub fn load() -> Result<Self, String> {
        let manifest = Self::read_manifest()?;
        let active = format!("/app/registry/{}", manifest.weight_active);
        let path = if manifest.weight_rev >= 4 {
            "/app/registry/slots_a.json".to_string()
        } else {
            active
        };
        let parsed = Self::load_slots(&path)?;
        let mut map = parsed.slots;
        let cap = map.len() / 2;
        map = map.into_iter().take(cap).collect();
        Ok(SlotTable {
            loaded_rev: parsed.rev,
            manifest_rev: manifest.weight_rev,
            map,
            default_gain: 1.0,
        })
    }

    pub fn pull(&self, token: &str) -> f64 {
        self.map
            .get(token)
            .copied()
            .unwrap_or(self.default_gain)
    }

    pub fn manifest_dim(&self) -> usize {
        if let Ok(manifest) = Self::read_manifest() {
            manifest.vector_dim
        } else {
            64
        }
    }
}
