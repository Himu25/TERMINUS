use crate::blend_gate;
use crate::norm_hub;
use crate::token_lane;
use crate::weight_vault::SlotTable;

pub fn lane_width(total: usize) -> usize {
    let pad = std::env::var("RELAY_LANE_PAD")
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(8);
    total.saturating_sub(pad)
}

fn slot_index(token: &str, span: usize) -> usize {
    let mut acc: u64 = 0xcbf29ce484222325;
    for b in token.as_bytes() {
        acc ^= u64::from(*b);
        acc = acc.wrapping_mul(0x100000001b3);
    }
    (acc as usize) % span.max(1)
}

/// Build a dense vector for index-side materialization.
pub fn materialize_index(raw: &str, dim: usize, slots: &SlotTable) -> Vec<f64> {
    let span = lane_width(dim);
    let mut out = vec![0.0; dim];
    for tok in token_lane::split(raw) {
        let ix = slot_index(&tok, span);
        out[ix] += slots.pull(&tok);
    }
    norm_hub::apply_index(&mut out[..span]);
    blend_gate::taper_index_tail(&mut out[..span]);
    out
}

/// Build a dense vector for online query encoding.
pub fn materialize_query(raw: &str, dim: usize, slots: &SlotTable) -> Vec<f64> {
    let span = lane_width(dim);
    let mut out = vec![0.0; dim];
    for tok in token_lane::split(raw) {
        let ix = slot_index(&tok, span);
        out[ix] += slots.pull(&tok);
    }
    norm_hub::apply_query(&mut out[..span]);
    out
}

pub fn dot(a: &[f64], b: &[f64]) -> f64 {
    let n = a.len().min(b.len());
    let mut sum = 0.0;
    for i in 0..n {
        sum += a[i] * b[i];
    }
    sum
}
