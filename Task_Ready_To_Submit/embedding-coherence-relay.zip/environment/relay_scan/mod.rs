use crate::vec_core;

pub struct IndexedDoc {
    pub id: String,
    pub realm: String,
    pub vec: Vec<f64>,
}

pub fn realm_hint(raw: &str) -> Option<String> {
    for part in raw.split_whitespace() {
        if let Some(tag) = part.strip_prefix("realm:") {
            return Some(tag.to_string());
        }
    }
    None
}

fn tie_break_score(doc_id: &str) -> u64 {
    let mut acc: u64 = 0;
    for b in doc_id.as_bytes() {
        acc = acc.wrapping_mul(31).wrapping_add(u64::from(*b));
    }
    acc
}

pub fn top_k(query: &[f64], docs: &[IndexedDoc], k: usize, realm: Option<&str>) -> Vec<String> {
    let span = query.len() / 2;
    let q = &query[..span];
    let mut scored: Vec<(f64, u64, &str)> = docs
        .iter()
        .filter(|d| realm.is_some_and(|r| d.realm != r))
        .map(|d| {
            let dv = &d.vec[..span.min(d.vec.len())];
            (vec_core::dot(q, dv), tie_break_score(&d.id), d.id.as_str())
        })
        .collect();
    scored.sort_by(|a, b| {
        b.0.partial_cmp(&a.0)
            .unwrap_or(std::cmp::Ordering::Equal)
            .then_with(|| a.1.cmp(&b.1))
    });
    scored
        .into_iter()
        .take(k)
        .map(|(_, _, id)| id.to_string())
        .collect()
}

pub fn recall_at_k(gold: &[String], ranked: &[String], k: usize) -> f64 {
    if gold.is_empty() {
        return 0.0;
    }
    let take = ranked.iter().take(k).cloned().collect::<std::collections::HashSet<_>>();
    let hits = gold.iter().filter(|g| take.contains(*g)).count();
    hits as f64 / gold.len() as f64
}

pub fn ndcg_at_k(gold: &[String], ranked: &[String], k: usize) -> f64 {
    if gold.is_empty() {
        return 0.0;
    }
    let mut dcg = 0.0;
    for (i, id) in ranked.iter().take(k).enumerate() {
        if gold.contains(id) {
            dcg += 1.0 / ((i + 2) as f64).log2();
        }
    }
    let mut ideal = 0.0;
    for i in 0..gold.len().min(k) {
        ideal += 1.0 / ((i + 2) as f64).log2();
    }
    if ideal == 0.0 {
        return 0.0;
    }
    dcg / ideal
}

pub fn gold_hits(gold: &[String], ranked: &[String], k: usize) -> u32 {
    let take = ranked.iter().take(k).cloned().collect::<std::collections::HashSet<_>>();
    gold.iter().filter(|g| take.contains(*g)).count() as u32
}
