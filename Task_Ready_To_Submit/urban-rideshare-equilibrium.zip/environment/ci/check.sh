#!/bin/bash
set -euo pipefail
cd /app
bash /app/scripts/build.sh
/app/bin/zonepack /app/data/zone_manifest.jsonl /app/data/zones_default.jsonl
/app/tools/run_equilibrium
