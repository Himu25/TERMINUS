package types

type PoolCfg struct {
	DriverPoolSlots      int
	MinCoverageRate        float64
	MaxIdleRatio        float64
	MaxLinkViolations     int
	MaxEarningsInversions  int
	MinSurgeBufferSlots    int
	MinServiceValue   float64
	ClusterWeights         map[string]float64
}

type TrafficProfile struct {
	TrafficID string
	ClearScale   int
	CongestScale   int
	CongestAfter   int
}

type ZoneCase struct {
	ZoneID       string   `json:"zone_id"`
	Cluster        string   `json:"cluster"`
	Demand        int      `json:"demand"`
	DemandRevision int      `json:"demand_revision"`
	EstTons        int      `json:"est_slots"`
	ActTons        int      `json:"act_slots"`
	LinkDeps      []string `json:"link_deps"`
	ConvoyWave     int      `json:"surge_wave"`
	FareScore      float64  `json:"fare_score"`
	TrafficID     string   `json:"traffic_id"`
	DepartSlot     int      `json:"depart_slot"`
	ArriveSlot     int      `json:"arrive_slot"`
}

type ZoneRow struct {
	ZoneID          string  `json:"zone_id"`
	Cluster           string  `json:"cluster"`
	Demand           int     `json:"demand"`
	TonsReserved      int     `json:"slots_reserved"`
	TonsDelivered     int     `json:"slots_served"`
	Served            bool    `json:"served"`
	RouteReady        bool    `json:"link_ready"`
	DispatchRank      int     `json:"queue_rank"`
	SurplusTons       int     `json:"idle_slots"`
	ConvoyWave        int     `json:"surge_wave"`
	HumanitarianValue float64 `json:"service_value"`
}

type EquilibriumReport struct {
	Status             string      `json:"status"`
	DriverPoolSlots  int         `json:"driver_pool_slots"`
	TonsShipped        int         `json:"slots_assigned"`
	TonsSurplus        int         `json:"slots_idle"`
	RegionsTotal       int         `json:"zones_total"`
	RegionsServed      int         `json:"zones_covered"`
	CoverageRate       float64     `json:"coverage_rate"`
	SurplusRatio       float64     `json:"idle_ratio"`
	RouteViolations    int         `json:"link_violations"`
	PriorityInversions int         `json:"earnings_inversions"`
	ConvoyBufferTons   int         `json:"surge_buffer_slots"`
	HumanitarianValue  float64     `json:"service_value"`
	ReportDigest       string      `json:"report_digest"`
	Zones              []ZoneRow `json:"zones"`
}
