module ure.rideshare

go 1.22
