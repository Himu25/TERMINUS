package drv

import (
	"ure.rideshare/n8"
	"ure.rideshare/pkg/types"
	"ure.rideshare/z1"
)

func meterBillable(jc types.ZoneCase, fieldReportVal int, rp types.TrafficProfile) int {
	dryScale := rp.ClearScale
	wetScale := rp.CongestScale
	wetAfter := rp.CongestAfter
	if fieldReportVal > 0 {
		dryScale, wetScale, wetAfter = 100, 100, 0
	}
	roll := n8.MeterSpan(
		jc.EstTons, jc.ActTons, fieldReportVal,
		dryScale, wetScale, wetAfter, jc.DepartSlot,
	)
	if roll.Billable > 0 {
		return roll.Billable
	}
	return jc.EstTons
}

func regionSurplus(reserved, used int) int {
	return z1.VxRoll(reserved, used)
}
