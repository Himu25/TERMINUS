package drv

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"

	"ure.rideshare/k2"
	"ure.rideshare/pkg/types"
	"ure.rideshare/q9"
	"ure.rideshare/summ"
	"ure.rideshare/u3"
)

func LoadCfg(path string) (types.PoolCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.PoolCfg{}, err
	}
	cfg := types.PoolCfg{
		DriverPoolSlots:     12000,
		MinCoverageRate:     0.75,
		MaxIdleRatio:         0.35,
		MaxLinkViolations:      0,
		MaxEarningsInversions: 1,
		MinSurgeBufferSlots:      3,
		MinServiceValue:     2.0,
		ClusterWeights:           map[string]float64{"cluster_alpha": 1.0, "cluster_beta": 1.0, "cluster_gamma": 1.0},
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "driver_pool_slots":
			fmt.Sscanf(val, "%d", &cfg.DriverPoolSlots)
		case "min_coverage_rate":
			fmt.Sscanf(val, "%f", &cfg.MinCoverageRate)
		case "max_idle_ratio":
			fmt.Sscanf(val, "%f", &cfg.MaxIdleRatio)
		case "max_link_violations":
			fmt.Sscanf(val, "%d", &cfg.MaxLinkViolations)
		case "max_earnings_inversions":
			fmt.Sscanf(val, "%d", &cfg.MaxEarningsInversions)
		case "min_surge_buffer_slots":
			fmt.Sscanf(val, "%d", &cfg.MinSurgeBufferSlots)
		case "min_service_value":
			fmt.Sscanf(val, "%f", &cfg.MinServiceValue)
		case "cluster_weight_alpha":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClusterWeights["cluster_alpha"] = w
		case "cluster_weight_beta":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClusterWeights["cluster_beta"] = w
		case "cluster_weight_gamma":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClusterWeights["cluster_gamma"] = w
		}
	}
	return cfg, nil
}

func LoadTraffic(path string) (map[string]types.TrafficProfile, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]types.TrafficProfile)
	for i, row := range rows {
		if i == 0 || len(row) < 4 {
			continue
		}
		var peak, renew, after int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &peak)
		fmt.Sscanf(strings.TrimSpace(row[2]), "%d", &renew)
		fmt.Sscanf(strings.TrimSpace(row[3]), "%d", &after)
		id := strings.TrimSpace(row[0])
		out[id] = types.TrafficProfile{
			TrafficID: id,
			ClearScale:  peak,
			CongestScale: renew,
			CongestAfter: after,
		}
	}
	return out, nil
}

func LoadZoneCases(path string) ([]types.ZoneCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.ZoneCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var jc types.ZoneCase
		if err := json.Unmarshal([]byte(line), &jc); err != nil {
			return nil, err
		}
		if jc.TrafficID == "" {
			jc.TrafficID = "us-east"
		}
		out = append(out, jc)
	}
	return out, sc.Err()
}

func LoadTripLog(path string) (map[string]int, error) {
	f, err := os.Open(path)
	if err != nil {
		return map[string]int{}, nil
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]int)
	for i, row := range rows {
		if i == 0 || len(row) < 2 {
			continue
		}
		var actTons int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &actTons)
		out[strings.TrimSpace(row[0])] = actTons
	}
	return out, nil
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

func corridorFor(jc types.ZoneCase, corridors map[string]types.TrafficProfile) types.TrafficProfile {
	if rp, ok := corridors[jc.TrafficID]; ok {
		return rp
	}
	return types.TrafficProfile{TrafficID: jc.TrafficID, ClearScale: 100, CongestScale: 100, CongestAfter: 0}
}

func Run(cfg types.PoolCfg, cases []types.ZoneCase, fieldReports map[string]int, corridors map[string]types.TrafficProfile) (types.EquilibriumReport, error) {
	ordered := q9.RxOrder(cases)
	report := types.EquilibriumReport{
		Status:            "ok",
		DriverPoolSlots: cfg.DriverPoolSlots,
		RegionsTotal:         len(ordered),
	}
	done := make(map[string]bool)
	budgetLeft := cfg.DriverPoolSlots
	var spent, totalWaste, completed, depViol, inversions, renewTotal int
	var valueTotal float64
	prevRank := -1
	report.Zones = make([]types.ZoneRow, 0, len(ordered))

	for idx, jc := range ordered {
		actualReady := true
		for _, depID := range jc.LinkDeps {
			if !done[depID] {
				actualReady = false
				break
			}
		}
		depReady := k2.DxGate(jc.LinkDeps, done)
		if len(jc.LinkDeps) > 0 && !actualReady && depReady {
			depViol++
		}
		fieldReportVal := 0
		if act, ok := fieldReports[jc.ZoneID]; ok && act > 0 {
			fieldReportVal = act
			jc.ActTons = act
		}
		rp := corridorFor(jc, corridors)
		billable := meterBillable(jc, fieldReportVal, rp)
		reserveNeed := u3.AxNeed(jc.EstTons, billable)
		reserved, ok := u3.BxReserve(budgetLeft, reserveNeed)
		headroom := budgetLeft - reserved
		if jc.ConvoyWave > 0 {
			renewTotal += waveConvoyTotal(jc.ConvoyWave, jc.EstTons, headroom)
		}
		used := 0
		finished := false
		if ok && depReady {
			used = jc.ActTons
			if used <= 0 {
				used = billable
			}
			if used > reserved {
				used = reserved
			}
			budgetLeft -= reserved
			spent += used
			finished = true
			completed++
			done[jc.ZoneID] = true
			valueTotal += u3.VxValue(jc.FareScore, used)
		}
		wasteAmt := regionSurplus(reserved, used)
		totalWaste += wasteAmt
		rankScore := jc.DemandRevision*10 + jc.Demand
		if finished {
			if prevRank >= 0 && rankScore > prevRank {
				inversions++
			}
			prevRank = rankScore
		}
		row := types.ZoneRow{
			ZoneID:          jc.ZoneID,
			Cluster:           jc.Cluster,
			Demand:       jc.Demand,
			TonsReserved:  reserved,
			TonsDelivered:      used,
			Served:      finished,
			RouteReady:       depReady,
			DispatchRank:   idx + 1,
			SurplusTons:     wasteAmt,
			ConvoyWave:      jc.ConvoyWave,
			HumanitarianValue: round4(u3.VxValue(jc.FareScore, used)),
		}
		report.Zones = append(report.Zones, row)
	}

	report.TonsShipped = spent
	report.TonsSurplus = totalWaste
	report.RegionsServed = completed
	if report.RegionsTotal > 0 {
		report.CoverageRate = round4(float64(completed) / float64(report.RegionsTotal))
	}
	if spent > 0 {
		report.SurplusRatio = round4(float64(totalWaste) / float64(spent))
	}
	report.RouteViolations = depViol
	report.PriorityInversions = inversions
	report.ConvoyBufferTons = renewTotal
	report.HumanitarianValue = round4(valueTotal)
	hasConvoy := false
	for _, jc := range ordered {
		if jc.ConvoyWave > 0 {
			hasConvoy = true
			break
		}
	}
	if !meetsFloors(cfg, report, hasConvoy) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func meetsFloors(cfg types.PoolCfg, report types.EquilibriumReport, hasConvoy bool) bool {
	if report.CoverageRate < cfg.MinCoverageRate {
		return false
	}
	if report.SurplusRatio > cfg.MaxIdleRatio {
		return false
	}
	if report.RouteViolations > cfg.MaxLinkViolations {
		return false
	}
	if report.PriorityInversions > cfg.MaxEarningsInversions {
		return false
	}
	if report.ConvoyBufferTons < cfg.MinSurgeBufferSlots {
		if hasConvoy {
			return false
		}
	}
	if report.HumanitarianValue < cfg.MinServiceValue {
		return false
	}
	for _, row := range report.Zones {
		if strings.HasPrefix(row.ZoneID, "z_link_") && !row.RouteReady && row.Served {
			return false
		}
		if strings.HasPrefix(row.ZoneID, "z_surge_") && row.ConvoyWave > 0 && !row.Served {
			return false
		}
		if strings.HasPrefix(row.ZoneID, "z_trip_") && row.SurplusTons == 0 && row.TonsReserved > row.TonsDelivered+50 {
			return false
		}
		if strings.HasPrefix(row.ZoneID, "z_traffic_") && row.Served && row.TonsDelivered > row.TonsReserved+200 {
			return false
		}
	}
	_ = summ.SxFold(report.Zones)
	return true
}

type digestPayload struct {
	Status              string         `json:"status"`
	DriverPoolSlots   int            `json:"driver_pool_slots"`
	TonsShipped          int            `json:"slots_assigned"`
	TonsSurplus          int            `json:"slots_idle"`
	RegionsTotal           int            `json:"zones_total"`
	RegionsServed       int            `json:"zones_covered"`
	CoverageRate      float64        `json:"coverage_rate"`
	SurplusRatio          float64        `json:"idle_ratio"`
	RouteViolations       int            `json:"link_violations"`
	PriorityInversions  int            `json:"earnings_inversions"`
	ConvoyBufferTons    int            `json:"surge_buffer_slots"`
	HumanitarianValue   float64        `json:"service_value"`
	ReportDigest        string         `json:"report_digest"`
	Zones               []types.ZoneRow `json:"zones"`
}

func digestBody(report types.EquilibriumReport) string {
	payload := digestPayload{
		Status:              report.Status,
		DriverPoolSlots:   report.DriverPoolSlots,
		TonsShipped:         report.TonsShipped,
		TonsSurplus:         report.TonsSurplus,
		RegionsTotal:        report.RegionsTotal,
		RegionsServed:       report.RegionsServed,
		CoverageRate:        report.CoverageRate,
		SurplusRatio:        report.SurplusRatio,
		RouteViolations:     report.RouteViolations,
		PriorityInversions:  report.PriorityInversions,
		ConvoyBufferTons:    report.ConvoyBufferTons,
		HumanitarianValue:   report.HumanitarianValue,
		ReportDigest:        "",
		Zones:               report.Zones,
	}
	raw, err := marshalDigestJSON(payload)
	if err != nil {
		return ""
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func marshalDigestJSON(payload digestPayload) ([]byte, error) {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return nil, err
	}
	b := buf.Bytes()
	if n := len(b); n > 0 && b[n-1] == '\n' {
		b = b[:n-1]
	}
	return b, nil
}

func WriteReport(path string, report types.EquilibriumReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func p95(values []int) int {
	if len(values) == 0 {
		return 0
	}
	cp := append([]int(nil), values...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}
