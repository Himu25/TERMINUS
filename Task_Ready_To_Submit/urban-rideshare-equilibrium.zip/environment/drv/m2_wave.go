package drv

import "ure.rideshare/h4"

func waveConvoyTotal(convoyWave, estTons, headroom int) int {
	if convoyWave <= 0 {
		return 0
	}
	return h4.UxAbsorb(estTons/4, headroom)
}
