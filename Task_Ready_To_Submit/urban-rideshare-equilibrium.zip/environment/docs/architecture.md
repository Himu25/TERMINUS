Urban rideshare equilibrium ties together a Go driver, Rust traffic meter, and bash runners under /app.
The driver reads zone manifests, traffic congestion tables, and trip logs.
The Rust crate in n8 resolves billable slots per zone row.
The bash runner rebuilds binaries and invokes the equilibrium packager.
