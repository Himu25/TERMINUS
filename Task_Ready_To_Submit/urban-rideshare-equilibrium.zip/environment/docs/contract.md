# Equilibrium report contract

## Top-level fields

- status: ok when guardrails pass, otherwise fail
- driver_pool_slots: daily pool from rideshare.toml
- slots_assigned: billable slots consumed by served zones
- slots_idle: reservation idle summed across zones
- zones_total: input JSONL row count
- zones_covered: count of zone rows marked served
- coverage_rate: zones_covered divided by zones_total
- idle_ratio: slots_idle divided by slots_assigned
- link_violations: zones dispatched before link dependencies finished
- earnings_inversions: served zones whose rank score fell below a prior finish
- surge_buffer_slots: surge headroom slots absorbed during waves
- service_value: weighted fare score total for served zones
- report_digest: sha256 hex of compact JSON with report_digest empty
- zones: per-zone rows

## Zone row fields

- zone_id, cluster, demand
- slots_reserved, slots_served, idle_slots
- served, link_ready, queue_rank, surge_wave, service_value

## Queue order

Pending zones are sorted before allocation using, in order:

1. demand_revision descending (late trip logs outrank stale rows)
2. demand descending
3. fare_score descending
4. zone_id ascending (stable tie-break)

## queue_rank

1-based position in the scheduler processing order after the sort above. Lower queue_rank means the zone was scheduled earlier.

## Earnings inversions

For each served zone, form rank score = demand_revision * 10 + demand. earnings_inversions counts how often a served zone's rank score is greater than the rank score of an earlier-served zone.

## Traffic congestion

traffic_conditions.csv supplies clear_scale, congest_scale, and congest_after per traffic_id. The Rust meter spans each zone from depart_slot for a duration in slot units taken from act_slots when positive, otherwise est_slots (minimum 1). When depart_slot plus duration is at or before congest_after, clear_scale applies; when depart_slot is at or after congest_after, congest_scale applies; when the span crosses congest_after, scale is the duration-weighted blend of clear_scale over pre-congest slots and congest_scale over post-congest slots. Billable slots multiply raw estimate or actual by the blended scale and divide by 100. Without a matching trip log, traffic scaling shapes slots_reserved and can cap slots_served; eu-west scales below us-east for the same raw act_slots when the traffic tables diverge.

## Drift and slot accounting

- slots_reserved: reservation size from est_slots when est_slots is positive; when est_slots is zero, reservation follows billable slots from the trip log meter
- slots_served: trip-log act_slots verbatim when trip_log.csv supplies a value (this overrides traffic scaling); otherwise traffic-scaled actual served capped by slots_reserved when zone act_slots is positive, or blended billable actual when act_slots is zero
- idle_slots: slots_reserved minus slots_served (zero when reserved is not greater than served)
- Conflicting-trip drift rows keep the estimate reservation even when actual served is lower, so idle_slots reflects reserved minus served

Digest JSON uses the same keys as the written report with report_digest set to empty string before hashing.
