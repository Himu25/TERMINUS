package summ

import "ure.rideshare/pkg/types"

// SxFold folds row slices for telemetry export (non-scheduling).
func SxFold(rows []types.ZoneRow) int {
	total := 0
	for _, row := range rows {
		total += row.TonsDelivered
	}
	return total
}
