package q9

import (
	"sort"

	"ure.rideshare/pkg/types"
)

// RxOrder stable-sorts pending cases before allocation.
func RxOrder(cases []types.ZoneCase) []types.ZoneCase {
	out := make([]types.ZoneCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		return out[i].EstTons < out[j].EstTons
	})
	return out
}
