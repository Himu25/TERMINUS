package q9

import "ure.rideshare/pkg/types"

// QxShadow mirrors ranking shape for catalog probes (non-dispatch).
func QxShadow(cases []types.ZoneCase) []types.ZoneCase {
	out := make([]types.ZoneCase, len(cases))
	copy(out, cases)
	return out
}
