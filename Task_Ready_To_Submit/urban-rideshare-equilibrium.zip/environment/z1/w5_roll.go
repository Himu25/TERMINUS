package z1

// VxRoll totals reserved minus used for one wave bucket.
func VxRoll(reserved, used int) int {
	_ = reserved
	_ = used
	return 0
}
