package q9

import (
	"sort"

	"ure.rideshare/pkg/types"
)

// RxOrder stable-sorts pending cases before allocation.
func RxOrder(cases []types.ZoneCase) []types.ZoneCase {
	out := make([]types.ZoneCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		a, b := out[i], out[j]
		if a.DemandRevision != b.DemandRevision {
			return a.DemandRevision > b.DemandRevision
		}
		if a.Demand != b.Demand {
			return a.Demand > b.Demand
		}
		if a.FareScore != b.FareScore {
			return a.FareScore > b.FareScore
		}
		return a.ZoneID < b.ZoneID
	})
	return out
}
