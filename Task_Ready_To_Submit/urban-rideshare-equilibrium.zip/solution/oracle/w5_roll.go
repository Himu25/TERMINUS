package z1

// VxRoll totals reserved minus used for one wave bucket.
func VxRoll(reserved, used int) int {
	if reserved <= used {
		return 0
	}
	return reserved - used
}
