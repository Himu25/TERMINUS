#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/rideshare.toml
require_file /app/data/zone_manifest.jsonl
require_file /app/data/traffic_conditions.csv
require_file /app/data/trip_log.csv
mkdir -p /app/bin /app/output

log "apply patched sources"
cp "${ROOT_DIR}/oracle/p2_order.go" /app/q9/p2_order.go
cp "${ROOT_DIR}/oracle/d4_hold.go" /app/k2/d4_hold.go
cp "${ROOT_DIR}/oracle/b7_slot.go" /app/h4/b7_slot.go
cp "${ROOT_DIR}/oracle/w5_roll.go" /app/z1/w5_roll.go
cp "${ROOT_DIR}/oracle/lib.rs" /app/n8/src/lib.rs

log "rebuild dispatcher"
bash /app/scripts/build.sh
rm -rf /app/n8/target /app/output/go-build

log "refresh default zone bundle"
/app/bin/zonepack /app/data/zone_manifest.jsonl /app/data/zones_default.jsonl

log "emit default equilibrium report"
/app/tools/run_equilibrium

log "post-run validation against rideshare.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/rideshare.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k in ("min_coverage_rate", "max_idle_ratio", "min_service_value"):
        cfg[k] = float(v)
    elif k.startswith("max_") or k.startswith("min_") or k == "driver_pool_slots":
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/equilibrium_report.json").read_text())
assert report["status"] == "ok", report
assert report["coverage_rate"] >= cfg["min_coverage_rate"]
assert report["idle_ratio"] <= cfg["max_idle_ratio"]
assert report["link_violations"] <= cfg["max_link_violations"]
assert report["earnings_inversions"] <= cfg["max_earnings_inversions"]
assert report["surge_buffer_slots"] >= cfg["min_surge_buffer_slots"]
assert report["service_value"] >= cfg["min_service_value"]
for row in report["zones"]:
    if row["zone_id"].startswith("z_link_") and row["served"]:
        assert row["link_ready"], row
    if row["zone_id"].startswith("z_surge_"):
        assert row["served"], row
print("ok", report["coverage_rate"], report["idle_ratio"], report["service_value"])
PY

log "oracle complete"
