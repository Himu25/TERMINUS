"""Validate /app/output/equilibrium_report.json against rideshare.toml guardrails."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "equilibrium_report.json"
ZONES = APP / "data" / "zones_default.jsonl"
CFG = APP / "config" / "rideshare.toml"
TRIP_LOG = APP / "data" / "trip_log.csv"
CASES = Path(__file__).resolve().parent / "data"

_DEFAULT_ZONES_TEXT = ZONES.read_text(encoding="utf-8") if ZONES.is_file() else ""

REPORT_KEYS = frozenset(
    {
        "status",
        "driver_pool_slots",
        "slots_assigned",
        "slots_idle",
        "zones_total",
        "zones_covered",
        "coverage_rate",
        "idle_ratio",
        "link_violations",
        "earnings_inversions",
        "surge_buffer_slots",
        "service_value",
        "report_digest",
        "zones",
    }
)
RUN_TIMEOUT_SEC = 120

ROW_KEYS = frozenset(
    {
        "zone_id",
        "cluster",
        "demand",
        "slots_reserved",
        "slots_served",
        "idle_slots",
        "served",
        "link_ready",
        "queue_rank",
        "surge_wave",
        "service_value",
    }
)

def _traffic_raw_act(zones_text: str) -> int:
    return _zone_map_from_text(zones_text)["z_traffic_us"]["act_slots"]


def _assert_traffic_blend(report: dict, zones_text: str, *, require_status: bool) -> None:
    """Traffic rows must scale below raw act_slots with eu-west below us-east."""
    raw = _traffic_raw_act(zones_text)
    us = next(r for r in report["zones"] if r["zone_id"] == "z_traffic_us")
    eu = next(r for r in report["zones"] if r["zone_id"] == "z_traffic_eu")
    assert us["served"] and eu["served"]
    assert min(us["slots_reserved"], eu["slots_reserved"]) < raw
    assert eu["slots_reserved"] < us["slots_reserved"], (us, eu)
    assert eu["slots_served"] < us["slots_served"], (us, eu)
    if require_status:
        assert report["status"] == "ok"


def _load_trip_log() -> dict[str, int]:
    trip_log: dict[str, int] = {}
    if not TRIP_LOG.is_file():
        return trip_log
    lines = TRIP_LOG.read_text(encoding="utf-8").splitlines()
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        zone_id, act_slots = (part.strip() for part in line.split(",", 1))
        trip_log[zone_id] = int(act_slots)
    return trip_log


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "driver_pool_slots": 12000,
        "min_coverage_rate": 0.75,
        "max_idle_ratio": 0.35,
        "max_link_violations": 0,
        "max_earnings_inversions": 1,
        "min_surge_buffer_slots": 3,
        "min_service_value": 2.0,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in ("min_coverage_rate", "max_idle_ratio", "min_service_value"):
            cfg[key] = float(val)
        elif key in (
            "driver_pool_slots",
            "max_link_violations",
            "max_earnings_inversions",
            "min_surge_buffer_slots",
        ):
            cfg[key] = int(float(val))
    return cfg


def _zone_rows_from_text(text: str) -> list[dict]:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def _zone_ids_from_text(text: str) -> list[str]:
    return [row["zone_id"] for row in _zone_rows_from_text(text)]


def _zone_map_from_text(text: str) -> dict[str, dict]:
    return {row["zone_id"]: row for row in _zone_rows_from_text(text)}


def _assert_zones_match_input(report: dict, zones_text: str) -> None:
    expected_ids = _zone_ids_from_text(zones_text)
    report_ids = [row["zone_id"] for row in report["zones"]]
    assert report["zones_total"] == len(expected_ids)
    assert len(report_ids) == len(expected_ids)
    assert set(report_ids) == set(expected_ids)


@pytest.fixture(autouse=True)
def restore_default_zones() -> None:
    yield
    if _DEFAULT_ZONES_TEXT:
        _atomic_write_text(ZONES, _DEFAULT_ZONES_TEXT)
    stale_tmp = ZONES.with_suffix(ZONES.suffix + ".tmp")
    if stale_tmp.is_file():
        stale_tmp.unlink()


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    try:
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, path)
    finally:
        if tmp.is_file():
            tmp.unlink()


def _swap_fixture(stem: str) -> str:
    src = CASES / f"{stem}.jsonl"
    text = src.read_text(encoding="utf-8")
    _atomic_write_text(ZONES, text)
    return text


def _expected_digest(report: dict) -> str:
    payload = dict(report)
    payload["report_digest"] = ""
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
        timeout=RUN_TIMEOUT_SEC,
    )
    return proc.stdout.split()[0]


def _invoke_default() -> None:
    proc = subprocess.run(
        ["/app/tools/run_equilibrium"],
        capture_output=True,
        text=True,
        check=False,
        timeout=RUN_TIMEOUT_SEC,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "equilibrium_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    _invoke_default()


def test_report_top_level_keys_exact() -> None:
    """Report must expose only the documented top-level keys."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS


def test_zone_row_schema() -> None:
    """Each zone row must match the documented per-zone schema."""
    report = _load_report()
    assert report["zones"]
    for row in report["zones"]:
        assert set(row.keys()) == ROW_KEYS
        assert isinstance(row["zone_id"], str) and row["zone_id"]
        assert isinstance(row["cluster"], str) and row["cluster"]
        assert isinstance(row["demand"], int)
        assert row["slots_reserved"] >= 0
        assert row["slots_served"] >= 0
        assert row["idle_slots"] >= 0
        assert isinstance(row["served"], bool)
        assert isinstance(row["link_ready"], bool)
        assert row["queue_rank"] >= 1
        assert row["surge_wave"] >= 0
        assert row["service_value"] >= 0.0


def test_passing_run_contract() -> None:
    """Default bundle must finish ok and meet rideshare.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["driver_pool_slots"] == cfg["driver_pool_slots"]
    _assert_zones_match_input(report, _DEFAULT_ZONES_TEXT)
    served_count = sum(1 for row in report["zones"] if row["served"])
    assert report["zones_covered"] == served_count
    assert report["coverage_rate"] >= cfg["min_coverage_rate"]
    assert report["idle_ratio"] <= cfg["max_idle_ratio"]
    assert report["link_violations"] <= cfg["max_link_violations"]
    assert report["earnings_inversions"] <= cfg["max_earnings_inversions"]
    assert report["surge_buffer_slots"] >= cfg["min_surge_buffer_slots"]
    assert report["service_value"] >= cfg["min_service_value"]


def test_zones_total_matches_input_rows() -> None:
    """Report zone IDs must cover every input JSONL row with no drops or extras."""
    report = _load_report()
    _assert_zones_match_input(report, _DEFAULT_ZONES_TEXT)


def test_report_digest_matches_payload() -> None:
    """report_digest must hash the compact pre-digest JSON payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_report_digest_lowercase_hex64() -> None:
    """report_digest must be 64-character lowercase hexadecimal."""
    report = _load_report()
    digest = report["report_digest"]
    assert len(digest) == 64
    assert digest == digest.lower()
    int(digest, 16)


def test_deterministic_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_dep_rows_finish_in_order() -> None:
    """Dependency chain rows must complete only after prerequisites."""
    report = _load_report()
    ranks = {row["zone_id"]: row["queue_rank"] for row in report["zones"]}
    assert ranks["z_link_root"] < ranks["z_link_leaf"] < ranks["z_link_chain"]
    for row in report["zones"]:
        if row["zone_id"].startswith("z_link_") and row["served"]:
            assert row["link_ready"] is True, row


def test_prio_hot_ranks_before_cold() -> None:
    """Late demand revision rows must finish before stale low-revision peers."""
    report = _load_report()
    hot = next(r for r in report["zones"] if r["zone_id"] == "z_demand_hot")
    cold = next(r for r in report["zones"] if r["zone_id"] == "z_demand_cold")
    assert hot["served"] is True
    assert cold["served"] is True
    assert hot["queue_rank"] < cold["queue_rank"], (hot, cold)


def test_drift_accounting_semantics() -> None:
    """Drift rows reserve estimates, bill actuals, and record reserved minus used."""
    report = _load_report()
    inputs = _zone_map_from_text(_DEFAULT_ZONES_TEXT)
    trip_log = _load_trip_log()
    for row in report["zones"]:
        if not row["zone_id"].startswith("z_trip_") or not row["served"]:
            continue
        spec = inputs[row["zone_id"]]
        expected_used = trip_log.get(row["zone_id"], spec["act_slots"])
        assert row["slots_reserved"] == spec["est_slots"]
        assert row["slots_served"] == expected_used
        assert row["idle_slots"] == max(0, row["slots_reserved"] - row["slots_served"])


def test_idle_slots_reserved_minus_served() -> None:
    """idle_slots must equal reserved minus served for every served zone row."""
    report = _load_report()
    for row in report["zones"]:
        if not row["served"]:
            continue
        assert row["idle_slots"] == max(0, row["slots_reserved"] - row["slots_served"])


def test_drift_rows_record_waste() -> None:
    """Drift-prone rows with inflated reservations must record idle_slots."""
    report = _load_report()
    drift_rows = [r for r in report["zones"] if r["zone_id"].startswith("z_trip_")]
    assert drift_rows
    assert any(r["idle_slots"] > 0 for r in drift_rows if r["served"])


def test_burst_rows_complete() -> None:
    """Event-surge rows with the z_surge_ prefix must complete under the default bundle."""
    report = _load_report()
    burst_rows = [r for r in report["zones"] if r["zone_id"].startswith("z_surge_")]
    assert burst_rows
    assert all(r["served"] for r in burst_rows), burst_rows


def test_zone_rows_respect_intensity() -> None:
    """Traffic rows must bill through blended intensity, not raw estimates alone."""
    _invoke_default()
    report = _load_report()
    _assert_traffic_blend(report, _DEFAULT_ZONES_TEXT, require_status=False)


def test_renew_late_row_completes() -> None:
    """Delayed surge-wave row k_shift_late must complete under the default bundle."""
    report = _load_report()
    renew = next(r for r in report["zones"] if r["zone_id"] == "k_shift_late")
    assert renew["served"] is True
    assert renew["surge_wave"] > 0


def test_scenario_dep_chain() -> None:
    """Dependency-chain scenario must schedule deps before dependents."""
    zones_text = _swap_fixture("dep_chain")
    _invoke_default()
    report = _load_report()
    _assert_zones_match_input(report, zones_text)
    assert report["link_violations"] == 0
    assert report["status"] == "ok"
    ranks = {row["zone_id"]: row["queue_rank"] for row in report["zones"]}
    assert ranks["z_link_root"] < ranks["z_link_leaf"] < ranks["z_link_chain"]


def test_scenario_demand_flip() -> None:
    """Demand-flip scenario must schedule late revisions ahead of stale peers."""
    cfg = _parse_cfg()
    zones_text = _swap_fixture("demand_flip")
    _invoke_default()
    report = _load_report()
    _assert_zones_match_input(report, zones_text)
    hot = next(r for r in report["zones"] if r["zone_id"] == "z_demand_hot")
    cold = next(r for r in report["zones"] if r["zone_id"] == "z_demand_cold")
    assert hot["queue_rank"] < cold["queue_rank"]
    assert report["earnings_inversions"] <= cfg["max_earnings_inversions"]
    assert report["status"] == "ok"


def test_scenario_est_drift() -> None:
    """Estimate-drift scenario must keep idle_ratio under max_idle_ratio."""
    cfg = _parse_cfg()
    zones_text = _swap_fixture("est_drift")
    _invoke_default()
    report = _load_report()
    _assert_zones_match_input(report, zones_text)
    inputs = _zone_map_from_text(zones_text)
    for row in report["zones"]:
        if not row["zone_id"].startswith("z_trip_") or not row["served"]:
            continue
        spec = inputs[row["zone_id"]]
        assert row["slots_reserved"] == spec["est_slots"]
        assert row["idle_slots"] == max(0, row["slots_reserved"] - row["slots_served"])
        assert row["idle_slots"] > 0
    assert report["idle_ratio"] <= cfg["max_idle_ratio"]
    assert report["status"] == "ok"


def test_scenario_event_surge() -> None:
    """Event-surge scenario must absorb enough surge buffer headroom."""
    cfg = _parse_cfg()
    zones_text = _swap_fixture("event_surge")
    _invoke_default()
    report = _load_report()
    _assert_zones_match_input(report, zones_text)
    burst_rows = [r for r in report["zones"] if r["zone_id"].startswith("z_surge_")]
    assert burst_rows
    assert all(r["served"] for r in burst_rows)
    assert report["surge_buffer_slots"] >= cfg["min_surge_buffer_slots"]
    assert report["status"] == "ok"


def test_scenario_value_mix() -> None:
    """Need-score mix scenario must meet service_value floor."""
    cfg = _parse_cfg()
    zones_text = _swap_fixture("value_mix")
    _invoke_default()
    report = _load_report()
    _assert_zones_match_input(report, zones_text)
    assert report["service_value"] >= cfg["min_service_value"]


def test_scenario_trip_meter() -> None:
    """Zero-estimate trip-log row must bill act_slots through the meter."""
    zones_text = _swap_fixture("trip_meter")
    _invoke_default()
    report = _load_report()
    _assert_zones_match_input(report, zones_text)
    trip_log = _load_trip_log()
    expected_used = trip_log["z_trip_meter"]
    row = next(r for r in report["zones"] if r["zone_id"] == "z_trip_meter")
    assert row["served"] is True
    assert row["slots_served"] == expected_used
    assert row["slots_reserved"] >= row["slots_served"]
    assert row["idle_slots"] == max(0, row["slots_reserved"] - row["slots_served"])


def test_scenario_traffic_shift() -> None:
    """Traffic-shift scenario must bill eu-west below us-east for similar work."""
    zones_text = _swap_fixture("traffic_shift")
    _invoke_default()
    report = _load_report()
    _assert_zones_match_input(report, zones_text)
    _assert_traffic_blend(report, zones_text, require_status=False)


def test_scenario_shift_delay() -> None:
    """Delayed surge-wave scenario must complete k_shift_late with surge buffer absorption."""
    cfg = _parse_cfg()
    zones_text = _swap_fixture("shift_delay")
    _invoke_default()
    report = _load_report()
    _assert_zones_match_input(report, zones_text)
    renew = next(r for r in report["zones"] if r["zone_id"] == "k_shift_late")
    assert renew["served"] is True
    assert report["surge_buffer_slots"] >= cfg["min_surge_buffer_slots"]
    assert report["status"] == "ok"
