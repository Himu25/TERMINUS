package sigma

import (
	"sync"

	"preplab.dev/multiprep/pipeline"
)

type Entry struct {
	Digest string
	Tokens uint32
}

var globalMu sync.Mutex
var globalTable = map[string]Entry{}

// SgHx derives a cache slot for a document id.
func SgHx(docID string) string {
	if len(docID) >= 4 {
		return docID[:4]
	}
	return docID
}

// SgRd returns cached digest when present.
func SgRd(key string) (Entry, bool) {
	globalMu.Lock()
	defer globalMu.Unlock()
	e, ok := globalTable[key]
	return e, ok
}

// SgWr records a digest under key.
func SgWr(key, digest string, tokens uint32) {
	globalMu.Lock()
	defer globalMu.Unlock()
	globalTable[key] = Entry{Digest: digest, Tokens: tokens}
}

// SgZc runs tokenizer under the global cache lock.
func SgZc(text string) (digest string, tokens uint32, alloc int, err error) {
	globalMu.Lock()
	defer globalMu.Unlock()
	d, t, a, err := pipeline.TxEncode(text)
	return d, t, a, err
}
