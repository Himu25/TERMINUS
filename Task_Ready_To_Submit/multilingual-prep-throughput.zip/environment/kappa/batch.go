package kappa

import (
	"preplab.dev/multiprep/pkg/types"
)

// KpBx assigns documents to worker lanes for one shard.
func KpBx(docs []types.Doc, workers int) [][]types.Doc {
	if workers < 1 {
		workers = 1
	}
	out := make([][]types.Doc, workers)
	for _, doc := range docs {
		out[0] = append(out[0], doc)
	}
	return out
}
