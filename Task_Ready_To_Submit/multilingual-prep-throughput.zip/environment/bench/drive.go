package bench

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"
	"unicode/utf8"

	"preplab.dev/multiprep/sigma"
	"preplab.dev/multiprep/corpus"
	"preplab.dev/multiprep/pipeline"
	"preplab.dev/multiprep/pkg/types"
	"preplab.dev/multiprep/kappa"
	"preplab.dev/multiprep/ledger"
)

func Run(cfg types.PrepCfg, cases []types.ShardCase) (types.PrepReport, error) {
	if override := os.Getenv("TB_CORPUS_PATH"); override != "" {
		cfg.CorpusPath = override
	}
	docs, err := corpus.Load(cfg.CorpusPath)
	if err != nil {
		return types.PrepReport{}, err
	}
	byID := corpus.ByID(docs)
	report := types.PrepReport{
		Status:      "ok",
		CorpusDocs:  len(docs),
		WorkerCount: cfg.WorkerCount,
		PrepProfile: cfg.PrepProfile,
		ShardsTotal: len(cases),
	}
	var sumFid, sumPrep, sumMiss, sumBal, sumCont float64
	allocVals := make([]int, 0, len(cases))
	unicodeHits, unicodeTotal := 0, 0
	report.Shards = make([]types.ShardRow, 0, len(cases))

	for _, sc := range cases {
		shardDocs := make([]types.Doc, 0, len(sc.DocIDs))
		for _, id := range sc.DocIDs {
			if d, ok := byID[id]; ok {
				shardDocs = append(shardDocs, d)
			}
		}
		active := kappa.KpWx(cfg.WorkerCount, sc.DeadWorkers)
		lanes := kappa.KpBx(shardDocs, cfg.WorkerCount)
		var spill []types.Doc
		firstLive := -1
		for lane, batch := range lanes {
			if lane >= cfg.WorkerCount {
				continue
			}
			if isDead(lane, sc.DeadWorkers) {
				spill = append(spill, batch...)
				lanes[lane] = nil
				continue
			}
			if firstLive < 0 {
				firstLive = lane
			}
		}
		if firstLive >= 0 && len(spill) > 0 {
			lanes[firstLive] = append(lanes[firstLive], spill...)
		}
		matches := 0
		prepUnits := 0
		cacheMiss := 0
		allocUnits := 0
		perLaneRunes := make([]int, cfg.WorkerCount)

		for lane, batch := range lanes {
			if lane >= cfg.WorkerCount {
				continue
			}
			if isDead(lane, sc.DeadWorkers) {
				continue
			}
			for _, doc := range batch {
				runes := utf8.RuneCountInString(doc.Text)
				perLaneRunes[lane] += runes
				key := sigma.SgHx(doc.ID)
				var digest string
				if cached, ok := sigma.SgRd(key); ok {
					digest = cached.Digest
					if digest != ledger.DgFold(doc.Text) {
						cacheMiss += runes
					}
				} else {
					dg, _, alloc, err := sigma.SgZc(doc.Text)
					if err != nil {
						return types.PrepReport{}, err
					}
					digest = dg
					sigma.SgWr(key, digest, 0)
					allocUnits += alloc
				}
				if digest == ledger.DgFold(doc.Text) {
					matches++
				}
				if pipeline.HasUnicodeRunes(doc.Text) {
					unicodeTotal++
					if digest == ledger.DgFold(doc.Text) {
						unicodeHits++
					}
				}
			}
		}

		baseRunes := 0
		for _, r := range perLaneRunes {
			baseRunes += r
		}
		prepUnits = baseRunes
		if active < cfg.WorkerCount {
			prepUnits = baseRunes * cfg.WorkerCount
		}

		fidelity := 0.0
		if len(shardDocs) > 0 {
			fidelity = float64(matches) / float64(len(shardDocs))
		}
		balance := balanceScore(perLaneRunes, sc.DeadWorkers)
		row := types.ShardRow{
			ShardID:        sc.ShardID,
			TokenFidelity:  round4(fidelity),
			PrepUnits:      prepUnits,
			CacheMissUnits: cacheMiss,
			AllocUnits:     allocUnits,
			WorkersActive:  active,
			BalanceScore:   round4(balance),
			DocIDs:         append([]string(nil), sc.DocIDs...),
		}
		report.Shards = append(report.Shards, row)
		sumFid += fidelity
		sumPrep += float64(prepUnits)
		sumMiss += float64(cacheMiss)
		sumBal += balance
		allocVals = append(allocVals, allocUnits)
		if len(shardDocs) > 0 && baseRunes > 0 {
			sumCont += float64(cacheMiss) / float64(baseRunes)
		}
	}

	n := float64(len(cases))
	if n > 0 {
		report.MeanTokenFidelity = round4(sumFid / n)
		report.MeanPrepUnits = round4(sumPrep / n)
		report.MeanCacheMissUnits = round4(sumMiss / n)
		report.MeanBalanceScore = round4(sumBal / n)
		report.MeanCacheContention = round4(sumCont / n)
	}
	if unicodeTotal > 0 {
		report.UnicodeParityRate = round4(float64(unicodeHits) / float64(unicodeTotal))
	} else {
		report.UnicodeParityRate = 1.0
	}
	report.P95AllocUnits = p95(allocVals)
	if !meetsFloors(cfg, report) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func isDead(lane int, dead []int) bool {
	for _, d := range dead {
		if d == lane {
			return true
		}
	}
	return false
}

func balanceScore(perLane []int, dead []int) float64 {
	vals := make([]int, 0, len(perLane))
	total := 0
	for i, v := range perLane {
		if isDead(i, dead) || v == 0 {
			continue
		}
		vals = append(vals, v)
		total += v
	}
	if total == 0 || len(vals) == 0 {
		return 1.0
	}
	minV, maxV := vals[0], vals[0]
	for _, v := range vals {
		if v < minV {
			minV = v
		}
		if v > maxV {
			maxV = v
		}
	}
	spread := float64(maxV-minV) / float64(total)
	score := 1.0 - spread
	if score < 0 {
		return 0
	}
	if score > 1 {
		return 1
	}
	return score
}

func meetsFloors(cfg types.PrepCfg, report types.PrepReport) bool {
	if report.MeanTokenFidelity < cfg.FidelityFloor {
		return false
	}
	if int(report.MeanPrepUnits) > cfg.MaxMeanPrepUnits {
		return false
	}
	if int(report.MeanCacheMissUnits) > cfg.MaxMeanCacheMissUnits {
		return false
	}
	if report.P95AllocUnits > cfg.MaxP95AllocUnits {
		return false
	}
	if report.MeanBalanceScore < cfg.BalanceFloor {
		return false
	}
	if report.UnicodeParityRate < cfg.UnicodeParityFloor {
		return false
	}
	if report.MeanCacheContention > cfg.MaxMeanContention {
		return false
	}
	return true
}

func round4(v float64) float64 {
	if v > 1 {
		return 1
	}
	if v < 0 {
		return 0
	}
	return math.Round(v*10000+0.5) / 10000
}

func p95(vals []int) int {
	if len(vals) == 0 {
		return 0
	}
	cp := append([]int(nil), vals...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}

type digestPayload struct {
	Status              string           `json:"status"`
	CorpusDocs          int              `json:"corpus_docs"`
	WorkerCount         int              `json:"worker_count"`
	PrepProfile         string           `json:"prep_profile"`
	ShardsTotal         int              `json:"shards_total"`
	MeanTokenFidelity   float64          `json:"mean_token_fidelity"`
	MeanPrepUnits       float64          `json:"mean_prep_units"`
	MeanCacheMissUnits  float64          `json:"mean_cache_miss_units"`
	P95AllocUnits       int              `json:"p95_alloc_units"`
	MeanBalanceScore    float64          `json:"mean_balance_score"`
	UnicodeParityRate   float64          `json:"unicode_parity_rate"`
	MeanCacheContention float64          `json:"mean_cache_contention"`
	ReportDigest        string           `json:"report_digest"`
	Shards              []types.ShardRow `json:"shards"`
}

func digestBody(report types.PrepReport) string {
	payload := digestPayload{
		Status:              report.Status,
		CorpusDocs:          report.CorpusDocs,
		WorkerCount:         report.WorkerCount,
		PrepProfile:         report.PrepProfile,
		ShardsTotal:         report.ShardsTotal,
		MeanTokenFidelity:   report.MeanTokenFidelity,
		MeanPrepUnits:       report.MeanPrepUnits,
		MeanCacheMissUnits:  report.MeanCacheMissUnits,
		P95AllocUnits:       report.P95AllocUnits,
		MeanBalanceScore:    report.MeanBalanceScore,
		UnicodeParityRate:   report.UnicodeParityRate,
		MeanCacheContention: report.MeanCacheContention,
		ReportDigest:        "",
		Shards:              report.Shards,
	}
	raw, _ := json.Marshal(payload)
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func WriteReport(path string, report types.PrepReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}

func FormatDigestPreview(report types.PrepReport) string {
	body := report
	body.ReportDigest = ""
	raw, _ := json.Marshal(body)
	return string(raw)
}

func SanityProfile(profile string) error {
	if strings.TrimSpace(profile) == "" {
		return fmt.Errorf("empty prep profile")
	}
	return nil
}
