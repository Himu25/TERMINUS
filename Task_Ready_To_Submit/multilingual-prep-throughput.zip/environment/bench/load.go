package bench

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"strings"

	"preplab.dev/multiprep/pkg/types"
)

func LoadCfg(path string) (types.PrepCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.PrepCfg{}, err
	}
	cfg := types.PrepCfg{
		CorpusPath:            "/app/data/corpus_default.json",
		WorkerCount:           4,
		PrepProfile:           "v2",
		FidelityFloor:         0.98,
		MaxMeanPrepUnits:      48000,
		MaxMeanCacheMissUnits: 1200,
		MaxP95AllocUnits:      9000,
		BalanceFloor:          0.72,
		UnicodeParityFloor:    0.95,
		MaxMeanContention:     0.15,
		FailoverFidelityFloor: 0.9,
		SkewBalanceMin:        0.65,
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "worker_count":
			fmt.Sscanf(val, "%d", &cfg.WorkerCount)
		case "prep_profile":
			cfg.PrepProfile = val
		case "fidelity_floor":
			fmt.Sscanf(val, "%f", &cfg.FidelityFloor)
		case "max_mean_prep_units":
			fmt.Sscanf(val, "%d", &cfg.MaxMeanPrepUnits)
		case "max_mean_cache_miss_units":
			fmt.Sscanf(val, "%d", &cfg.MaxMeanCacheMissUnits)
		case "max_p95_alloc_units":
			fmt.Sscanf(val, "%d", &cfg.MaxP95AllocUnits)
		case "balance_floor":
			fmt.Sscanf(val, "%f", &cfg.BalanceFloor)
		case "unicode_parity_floor":
			fmt.Sscanf(val, "%f", &cfg.UnicodeParityFloor)
		case "max_mean_cache_contention":
			fmt.Sscanf(val, "%f", &cfg.MaxMeanContention)
		case "failover_fidelity_floor":
			fmt.Sscanf(val, "%f", &cfg.FailoverFidelityFloor)
		case "skew_balance_min":
			fmt.Sscanf(val, "%f", &cfg.SkewBalanceMin)
		case "corpus_path":
			cfg.CorpusPath = val
		}
	}
	return cfg, nil
}

func LoadShards(path string) ([]types.ShardCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.ShardCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var scase types.ShardCase
		if err := json.Unmarshal([]byte(line), &scase); err != nil {
			return nil, err
		}
		out = append(out, scase)
	}
	return out, sc.Err()
}
