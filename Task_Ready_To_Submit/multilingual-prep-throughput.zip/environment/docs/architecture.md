# Architecture notes

Corpus JSON lives at `/app/data/corpus_default.json`. Shard packs are JSONL with shard_id, doc_ids, and optional dead_workers. The Go driver `/app/bin/prepbench` loads `/app/config/prep.toml`, encodes text through the Rust helper built from `/app/xi_core`, and writes `/app/output/prep_bench.json`. Rebuild with `/app/scripts/build_all.sh` and run `/app/scripts/run_bench.sh`.

Top-level report keys: status, corpus_docs, worker_count, prep_profile, shards_total, mean_token_fidelity, mean_prep_units, mean_cache_miss_units, p95_alloc_units, mean_balance_score, unicode_parity_rate, mean_cache_contention, report_digest, shards.

Each shards row: shard_id, token_fidelity, prep_units, cache_miss_units, alloc_units, workers_active, balance_score, doc_ids. token_fidelity is the fraction of documents whose encoder digest matches the canonical fold in `ledger/digest.go`. Unit fields are synthetic cost tallies, not wall-clock timings.

Digest covers every report field except report_digest, serialized as compact JSON with report_digest set to an empty string. prepbench computes the digest from that payload before writing the indented report file.

prep_units adds a serial penalty when fewer workers are active than worker_count. cache_miss_units counts extra rune work when a hot slot returns a digest that does not match the canonical fold. mean_cache_contention is the mean per-shard ratio of encode operations that took the exclusive lock path. balance_score rewards even per-lane rune totals among active workers. unicode_parity_rate is the fraction of unicode-heavy documents that match the canonical fold.

Quality gates compare means against floors and ceilings in prep.toml. Failover shards list dead_workers; only live workers participate, and workers_active on each row equals worker_count minus the number of dead workers listed for that shard. Regenerate the default shard pack with `/app/bin/refgen` after corpus edits.

Verifier fixture benches may write under `/app/output/` including `prep_bench.json`, `prep_ablation_pool.json`, `prep_ablation_lane.json`, `prep_ablation_batch.json`, `prep_ablation_xi.json`, `prep_pack_failover.json`, and `prep_pack_skew.json`. Ablation copies may land in `kappa`, `sigma`, or `xi_core` sources from the verifier fixture tree (`z_pool.go`, `z_lane.go`, `z_batch.go`, `z_tokcore.rs`). Grading prepends `/usr/local/go/bin:/app/bin:` to PATH when invoking prepbench.
