#!/bin/bash
set -euo pipefail

ROOT="/app"
mkdir -p "${ROOT}/bin" "${ROOT}/lib" "${ROOT}/output" "${ROOT}/output/cargo-target"

export CARGO_TARGET_DIR="${ROOT}/output/cargo-target"
export CARGO_HOME="${CARGO_HOME:-/usr/local/cargo}"
export CGO_LDFLAGS="-L${ROOT}/lib -ltokcore"
export LD_LIBRARY_PATH="${ROOT}/lib:${LD_LIBRARY_PATH:-}"

cd "${ROOT}/xi_core"
cargo build --release --locked
install -m 0644 "${CARGO_TARGET_DIR}/release/libtokcore.so" "${ROOT}/lib/libtokcore.so"

cd "${ROOT}"
go build -o "${ROOT}/bin/prepbench" ./cmd/prepbench
go build -o "${ROOT}/bin/refgen" ./cmd/refgen

export LD_LIBRARY_PATH="${ROOT}/lib:${LD_LIBRARY_PATH:-}"

"${ROOT}/bin/refgen" \
  "${ROOT}/data/corpus_default.json" \
  "${ROOT}/data/shard_specs.jsonl" \
  "${ROOT}/data/shards_default.jsonl"

install -m 0755 "${ROOT}/bin/prepbench" "${ROOT}/bin/tokcore"
