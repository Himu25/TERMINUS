#!/bin/bash
set -euo pipefail

if [[ $# -lt 2 ]]; then
  echo "usage: run_bench.sh <shards.jsonl> <out.json>" >&2
  exit 2
fi

exec /app/bin/prepbench "$1" "$2"
