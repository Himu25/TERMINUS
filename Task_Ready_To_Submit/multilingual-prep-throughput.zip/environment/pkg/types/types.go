package types

type PrepCfg struct {
	CorpusPath            string
	WorkerCount           int
	PrepProfile           string
	FidelityFloor         float64
	MaxMeanPrepUnits      int
	MaxMeanCacheMissUnits int
	MaxP95AllocUnits      int
	BalanceFloor          float64
	UnicodeParityFloor    float64
	MaxMeanContention     float64
	FailoverFidelityFloor float64
	SkewBalanceMin        float64
}

type Doc struct {
	ID   string `json:"id"`
	Text string `json:"text"`
	Lang string `json:"lang"`
}

type ShardCase struct {
	ShardID     string   `json:"shard_id"`
	DocIDs      []string `json:"doc_ids"`
	DeadWorkers []int    `json:"dead_workers"`
}

type ShardRow struct {
	ShardID        string   `json:"shard_id"`
	TokenFidelity  float64  `json:"token_fidelity"`
	PrepUnits      int      `json:"prep_units"`
	CacheMissUnits int      `json:"cache_miss_units"`
	AllocUnits     int      `json:"alloc_units"`
	WorkersActive  int      `json:"workers_active"`
	BalanceScore   float64  `json:"balance_score"`
	DocIDs         []string `json:"doc_ids"`
}

type PrepReport struct {
	Status              string     `json:"status"`
	CorpusDocs          int        `json:"corpus_docs"`
	WorkerCount         int        `json:"worker_count"`
	PrepProfile         string     `json:"prep_profile"`
	ShardsTotal         int        `json:"shards_total"`
	MeanTokenFidelity   float64    `json:"mean_token_fidelity"`
	MeanPrepUnits       float64    `json:"mean_prep_units"`
	MeanCacheMissUnits  float64    `json:"mean_cache_miss_units"`
	P95AllocUnits       int        `json:"p95_alloc_units"`
	MeanBalanceScore    float64    `json:"mean_balance_score"`
	UnicodeParityRate   float64    `json:"unicode_parity_rate"`
	MeanCacheContention float64    `json:"mean_cache_contention"`
	ReportDigest        string     `json:"report_digest"`
	Shards              []ShardRow `json:"shards"`
}
