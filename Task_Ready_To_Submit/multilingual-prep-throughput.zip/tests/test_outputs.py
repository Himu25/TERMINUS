"""Validate /app/output/prep_bench.json against prep.toml guardrails."""

from __future__ import annotations

import contextlib
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "prep_bench.json"
CFG = APP / "config" / "prep.toml"
MANIFEST = APP / "registry" / "prep_manifest.json"
SHARDS = APP / "data" / "shards_default.jsonl"
FIXTURES = Path(__file__).resolve().parent / "fixtures"

REPORT_KEYS = frozenset(
    {
        "status",
        "corpus_docs",
        "worker_count",
        "prep_profile",
        "shards_total",
        "mean_token_fidelity",
        "mean_prep_units",
        "mean_cache_miss_units",
        "p95_alloc_units",
        "mean_balance_score",
        "unicode_parity_rate",
        "mean_cache_contention",
        "report_digest",
        "shards",
    }
)
SHARD_KEYS = frozenset(
    {
        "shard_id",
        "token_fidelity",
        "prep_units",
        "cache_miss_units",
        "alloc_units",
        "workers_active",
        "balance_score",
        "doc_ids",
    }
)

_SUBPROC_ENV = os.environ.copy()
_path_prefix = "/usr/local/go/bin:/app/bin:"
_SUBPROC_ENV["PATH"] = _path_prefix + _SUBPROC_ENV.get("PATH", "")
_SUBPROC_ENV["LD_LIBRARY_PATH"] = "/app/lib:" + _SUBPROC_ENV.get("LD_LIBRARY_PATH", "")
_BUILD_TIMEOUT = 240
_RUN_TIMEOUT = 120


def _parse_cfg() -> dict:
    cfg: dict = {
        "worker_count": 4,
        "prep_profile": "v2",
        "fidelity_floor": 0.98,
        "max_mean_prep_units": 48000,
        "max_mean_cache_miss_units": 1200,
        "max_p95_alloc_units": 9000,
        "balance_floor": 0.72,
        "unicode_parity_floor": 0.95,
        "max_mean_cache_contention": 0.15,
        "failover_fidelity_floor": 0.9,
        "skew_balance_min": 0.65,
        "unicode_mix_max_cache_miss_units": 0,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in (
            "fidelity_floor",
            "balance_floor",
            "unicode_parity_floor",
            "max_mean_cache_contention",
        "failover_fidelity_floor",
        "skew_balance_min",
        "unicode_mix_max_cache_miss_units",
        ):
            cfg[key] = float(val)
        elif key in (
            "worker_count",
            "max_mean_prep_units",
            "max_mean_cache_miss_units",
            "max_p95_alloc_units",
            "unicode_mix_max_cache_miss_units",
        ):
            cfg[key] = int(float(val))
        elif key == "prep_profile":
            cfg[key] = val
    return cfg


def _digest_payload(report: dict) -> dict:
    return {
        "status": report["status"],
        "corpus_docs": report["corpus_docs"],
        "worker_count": report["worker_count"],
        "prep_profile": report["prep_profile"],
        "shards_total": report["shards_total"],
        "mean_token_fidelity": report["mean_token_fidelity"],
        "mean_prep_units": report["mean_prep_units"],
        "mean_cache_miss_units": report["mean_cache_miss_units"],
        "p95_alloc_units": report["p95_alloc_units"],
        "mean_balance_score": report["mean_balance_score"],
        "unicode_parity_rate": report["unicode_parity_rate"],
        "mean_cache_contention": report["mean_cache_contention"],
        "report_digest": "",
        "shards": report["shards"],
    }


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _rebuild_and_run(
    shards_path: Path | None = None,
    out_path: Path | None = None,
    corpus_path: Path | None = None,
) -> dict:
    shards_path = shards_path or SHARDS
    out_path = out_path or OUT
    env = dict(_SUBPROC_ENV)
    if corpus_path is not None:
        env["TB_CORPUS_PATH"] = str(corpus_path)
    out_path.unlink(missing_ok=True)
    subprocess.run(
        ["bash", "/app/scripts/build_all.sh"],
        cwd=APP,
        check=True,
        timeout=_BUILD_TIMEOUT,
        env=env,
    )
    subprocess.run(
        ["/app/bin/prepbench", shards_path.as_posix(), out_path.as_posix()],
        cwd=APP,
        check=True,
        timeout=_RUN_TIMEOUT,
        env=env,
    )
    return json.loads(out_path.read_text(encoding="utf-8"))


@contextlib.contextmanager
def _swap_file(src: Path, dst: Path):
    """Temporarily replace dst with src, restoring original on exit."""
    backup = dst.read_bytes()
    shutil.copy2(src, dst)
    os.utime(dst)
    try:
        yield
    finally:
        dst.write_bytes(backup)


def _shard_rows(report: dict) -> dict[str, dict]:
    return {row["shard_id"]: row for row in report["shards"]}


@pytest.fixture(scope="module")
def cfg() -> dict:
    return _parse_cfg()


@pytest.fixture(scope="module")
def default_report() -> dict:
    if not OUT.is_file():
        pytest.fail(f"missing agent output at {OUT}")
    try:
        return json.loads(OUT.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        pytest.fail(f"invalid JSON at {OUT}: {exc}")


def test_report_schema_and_digest(default_report: dict) -> None:
    """Top-level schema and report_digest must match compact pre-digest JSON."""
    assert set(default_report.keys()) == REPORT_KEYS
    assert re.fullmatch(r"[0-9a-f]{64}", default_report["report_digest"])
    assert default_report["report_digest"] == _expected_digest(default_report)
    for row in default_report["shards"]:
        assert set(row.keys()) == SHARD_KEYS


def test_default_pack_quality_floors(default_report: dict, cfg: dict) -> None:
    """Default shard pack must meet prep.toml mean floors and ceilings."""
    assert default_report["status"] == "ok"
    assert default_report["shards_total"] == len(
        [ln for ln in SHARDS.read_text(encoding="utf-8").splitlines() if ln.strip()]
    )
    assert default_report["mean_token_fidelity"] >= cfg["fidelity_floor"]
    assert default_report["unicode_parity_rate"] >= cfg["unicode_parity_floor"]
    assert int(default_report["mean_prep_units"]) <= cfg["max_mean_prep_units"]
    assert int(default_report["mean_cache_miss_units"]) <= cfg["max_mean_cache_miss_units"]
    assert default_report["p95_alloc_units"] <= cfg["max_p95_alloc_units"]
    assert default_report["mean_balance_score"] >= cfg["balance_floor"]
    assert default_report["mean_cache_contention"] <= cfg["max_mean_cache_contention"]


def test_unicode_mix_shard_row(default_report: dict, cfg: dict) -> None:
    """s_unicode_mix must reach full token fidelity on unicode-heavy docs."""
    row = _shard_rows(default_report)["s_unicode_mix"]
    assert row["token_fidelity"] >= 0.9999
    assert row["cache_miss_units"] <= cfg["unicode_mix_max_cache_miss_units"]


def test_failover_shards_keep_fidelity(default_report: dict, cfg: dict) -> None:
    """Failover shards must stay above failover_fidelity_floor with reduced workers_active."""
    rows = _shard_rows(default_report)
    fail = rows["s_failover_lane"]
    multi = rows["s_failover_multi"]
    assert fail["workers_active"] == cfg["worker_count"] - 1
    assert multi["workers_active"] == cfg["worker_count"] - 2
    assert fail["token_fidelity"] >= cfg["failover_fidelity_floor"]
    assert multi["token_fidelity"] >= cfg["failover_fidelity_floor"]


def test_size_skew_balance_floor(default_report: dict, cfg: dict) -> None:
    """Uneven document sizes must still yield balance_score at or above skew_balance_min."""
    row = _shard_rows(default_report)["s_size_skew"]
    assert row["balance_score"] >= cfg["skew_balance_min"]


def test_prep_profile_matches_manifest(default_report: dict) -> None:
    """prep_profile in the report must match registry prep_manifest.json."""
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    assert default_report["prep_profile"] == manifest["prep_profile"]


def test_determinism_repeat_run(default_report: dict) -> None:
    """Identical inputs must yield byte-identical prep_bench.json."""
    first = OUT.read_bytes()
    OUT.unlink(missing_ok=True)
    subprocess.run(
        ["/app/bin/prepbench", SHARDS.as_posix(), OUT.as_posix()],
        cwd=APP,
        check=True,
        timeout=_RUN_TIMEOUT,
        env=_SUBPROC_ENV,
    )
    second = OUT.read_bytes()
    assert first == second


def test_z_ablation_serial_pool_fails_floors() -> None:
    """Restoring only the single-lane worker gate must not satisfy prep unit ceilings."""
    with _swap_file(FIXTURES / "z_pool.go", APP / "kappa" / "pool.go"):
        report = _rebuild_and_run(out_path=APP / "output" / "prep_ablation_pool.json")
    cfg = _parse_cfg()
    max_shard_units = max(row["prep_units"] for row in report["shards"])
    assert report["status"] == "fail" or max_shard_units > cfg["max_mean_prep_units"]


def test_z_ablation_lane_prefix_fails_fidelity() -> None:
    """Prefix-only lookup keys must drop token fidelity on s_cache_storm."""
    with _swap_file(FIXTURES / "z_lane.go", APP / "sigma" / "lane.go"):
        report = _rebuild_and_run(out_path=APP / "output" / "prep_ablation_lane.json")
    row = _shard_rows(report)["s_cache_storm"]
    assert row["token_fidelity"] < 1.0
    assert row["cache_miss_units"] > 0


def test_z_ablation_batch_skew_fails_balance() -> None:
    """Assigning all heavy docs to lane zero must fail balance on s_size_skew."""
    with _swap_file(FIXTURES / "z_batch.go", APP / "kappa" / "batch.go"):
        report = _rebuild_and_run(out_path=APP / "output" / "prep_ablation_batch.json")
    cfg = _parse_cfg()
    row = _shard_rows(report)["s_size_skew"]
    assert row["balance_score"] < cfg["skew_balance_min"]


def test_z_ablation_xi_core_fails_unicode() -> None:
    """Broken Rust normalization must collapse unicode_parity_rate."""
    with _swap_file(FIXTURES / "z_tokcore.rs", APP / "xi_core" / "src" / "lib.rs"):
        report = _rebuild_and_run(out_path=APP / "output" / "prep_ablation_xi.json")
    cfg = _parse_cfg()
    assert report["unicode_parity_rate"] < cfg["unicode_parity_floor"]
