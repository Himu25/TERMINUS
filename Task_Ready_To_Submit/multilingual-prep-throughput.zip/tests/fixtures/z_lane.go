package sigma

import (
	"sync"

	"preplab.dev/multiprep/pipeline"
)

type Entry struct {
	Digest string
	Tokens uint32
}

var globalMu sync.Mutex
var globalTable = map[string]Entry{}

func SgHx(docID string) string {
	if len(docID) >= 4 {
		return docID[:4]
	}
	return docID
}

func SgRd(key string) (Entry, bool) {
	globalMu.Lock()
	defer globalMu.Unlock()
	e, ok := globalTable[key]
	return e, ok
}

func SgWr(key, digest string, tokens uint32) {
	globalMu.Lock()
	defer globalMu.Unlock()
	globalTable[key] = Entry{Digest: digest, Tokens: tokens}
}

func SgZc(text string) (digest string, tokens uint32, alloc int, err error) {
	globalMu.Lock()
	defer globalMu.Unlock()
	return pipeline.TxEncode(text)
}
