package kappa

import (
	"sort"

	"preplab.dev/multiprep/pkg/types"
)

func KpBx(docs []types.Doc, workers int) [][]types.Doc {
	sort.Slice(docs, func(i, j int) bool {
		return len(docs[i].Text) > len(docs[j].Text)
	})
	out := make([][]types.Doc, workers)
	for _, doc := range docs {
		if len(doc.Text) > 80 {
			out[0] = append(out[0], doc)
		} else {
			out[1] = append(out[1], doc)
		}
	}
	return out
}
