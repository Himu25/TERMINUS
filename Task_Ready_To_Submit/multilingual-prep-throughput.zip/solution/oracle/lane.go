package sigma

import (
	"hash/fnv"
	"sync"

	"preplab.dev/multiprep/pipeline"
)

type Entry struct {
	Digest string
	Tokens uint32
}

type shardCache struct {
	mu    sync.RWMutex
	table map[string]Entry
}

var shardCaches []*shardCache

func laneFor(key string) int {
	h := fnv.New32a()
	_, _ = h.Write([]byte(key))
	return int(h.Sum32() % uint32(len(shardCaches)+1))
}

func laneCache(lane int) *shardCache {
	for len(shardCaches) <= lane {
		shardCaches = append(shardCaches, &shardCache{table: make(map[string]Entry)})
	}
	return shardCaches[lane]
}

// SgHx derives a cache slot for a document id.
func SgHx(docID string) string {
	return docID
}

// SgRd returns cached digest when present.
func SgRd(key string) (Entry, bool) {
	lane := laneFor(key)
	c := laneCache(lane)
	c.mu.RLock()
	defer c.mu.RUnlock()
	e, ok := c.table[key]
	return e, ok
}

// SgWr records a digest under key.
func SgWr(key, digest string, tokens uint32) {
	lane := laneFor(key)
	c := laneCache(lane)
	c.mu.Lock()
	defer c.mu.Unlock()
	c.table[key] = Entry{Digest: digest, Tokens: tokens}
}

// SgZc runs tokenizer without holding table locks.
func SgZc(text string) (digest string, tokens uint32, alloc int, err error) {
	return pipeline.TxEncode(text)
}
