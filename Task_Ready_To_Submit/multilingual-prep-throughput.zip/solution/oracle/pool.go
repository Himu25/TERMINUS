package kappa

// KpWx returns how many prep workers may run concurrently.
func KpWx(cfgWorkers int, dead []int) int {
	deadSet := make(map[int]struct{}, len(dead))
	for _, d := range dead {
		deadSet[d] = struct{}{}
	}
	active := 0
	for i := 0; i < cfgWorkers; i++ {
		if _, off := deadSet[i]; !off {
			active++
		}
	}
	if active < 1 {
		return 1
	}
	return active
}
