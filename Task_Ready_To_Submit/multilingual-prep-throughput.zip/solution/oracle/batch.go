package kappa

import (
	"sort"
	"unicode/utf8"

	"preplab.dev/multiprep/pkg/types"
)

// KpBx assigns documents to worker lanes for one shard.
func KpBx(docs []types.Doc, workers int) [][]types.Doc {
	if workers < 1 {
		workers = 1
	}
	sort.Slice(docs, func(i, j int) bool {
		return utf8.RuneCountInString(docs[i].Text) > utf8.RuneCountInString(docs[j].Text)
	})
	out := make([][]types.Doc, workers)
	loads := make([]int, workers)
	left, right := 0, len(docs)-1
	for left <= right {
		if left == right {
			lane := minLoadLane(loads)
			out[lane] = append(out[lane], docs[left])
			loads[lane] += utf8.RuneCountInString(docs[left].Text)
			break
		}
		lane := minLoadLane(loads)
		out[lane] = append(out[lane], docs[left], docs[right])
		loads[lane] += utf8.RuneCountInString(docs[left].Text) + utf8.RuneCountInString(docs[right].Text)
		left++
		right--
	}
	return out
}

func minLoadLane(loads []int) int {
	lane := 0
	for i := 1; i < len(loads); i++ {
		if loads[i] < loads[lane] {
			lane = i
		}
	}
	return lane
}
