#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

log "preflight: multilingual prep throughput workspace"
test -f /app/go.mod
test -f /app/config/prep.toml
test -f /app/data/corpus_default.json
test -f /app/data/shard_specs.jsonl
mkdir -p /app/bin /app/lib /app/output

log "survey: guardrails and subsystem layout"
grep -nE 'fidelity|prep_units|cache_miss|unicode|contention|balance' \
  /app/config/prep.toml /app/metrics/guardrails.txt /app/policies/retention.txt 2>/dev/null | head -n 20 || true
wc -l /app/kappa/pool.go /app/kappa/batch.go /app/sigma/lane.go /app/xi_core/src/lib.rs /app/bench/drive.go

log "restore parallel worker activation across live lanes"
cp "${ROOT_DIR}/oracle/pool.go" /app/kappa/pool.go

log "restore per-lane lookup table with full document keys"
cp "${ROOT_DIR}/oracle/lane.go" /app/sigma/lane.go

log "restore bounded-allocation unicode encoder core"
cp "${ROOT_DIR}/oracle/xi_core.rs" /app/xi_core/src/lib.rs

log "restore load-balanced document pairing across worker lanes"
cp "${ROOT_DIR}/oracle/batch.go" /app/kappa/batch.go

log "rebuild Rust shared library and Go bench driver"
bash /app/scripts/build_all.sh

log "regenerate default shard pack after encoder repair"
/app/bin/refgen \
  /app/data/corpus_default.json \
  /app/data/shard_specs.jsonl \
  /app/data/shards_default.jsonl

log "run default prep throughput bench report"
export LD_LIBRARY_PATH="/app/lib:${LD_LIBRARY_PATH:-}"
chmod +x /app/scripts/run_bench.sh
/app/scripts/run_bench.sh /app/data/shards_default.jsonl /app/output/prep_bench.json

log "done"
