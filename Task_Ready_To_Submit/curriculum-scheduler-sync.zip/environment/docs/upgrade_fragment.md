# Upgrade fragment (incomplete)

2024-03: stage row checksum widened to xor sequence into sixteen-bit field.

2024-07: tie ordering now references lag-adjusted timestamps from worker meta profiles.

2024-11: lag hold windows affect folded process lag baselines when packs load.
