# Active pack layout

Five workers (`w1`–`w5`) append stage rows under `/app/data/active/workers/`.
Each worker carries `meta.json` with snapshot marks and lag skew fields.
Segment files use JSONL with one row per training step.
