# Lag hold notes

Workers record `clock_skew_ms` from their onboard process clock. During scheduler lag hold windows,
`lag_hold_ms` smears the effective skew baseline folded through the stagegate bridge. That replay
offset drives both lag-adjusted process-time ordering and the worker spread behind stability_band.
