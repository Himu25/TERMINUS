# Archived curriculum snapshots

Past distributed training runs are frozen under `/app/data/replay/` as self-contained worker trees with a `train_pack.json` manifest per snapshot. Each archive retains segment JSONL, per-worker meta profiles, and the quorum and stability parameters observed when the run was captured.

Operations copy one archive into `/app/data/active/` when reproducing a partition or skew incident, or when regression-testing sync driver changes against historical data. The active tree uses the same layout documented in `worker_layout.md`.

Snapshot directories follow the `curriculum_*` prefix from original run identifiers (for example
`curriculum_alpha`, `curriculum_beta`, `curriculum_gamma`, `curriculum_delta`, `curriculum_epsilon`).
Retention policy defers to ops notes under `/app/ops/`.
