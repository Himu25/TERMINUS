Operator tools live outside the heal driver; use /app/bin/curriculum_sync for pack replay.
Standalone /app/tools/digest_cli recomputes report digests from field tuples for manual cross-checks.
