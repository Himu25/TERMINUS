package main

import (
	"fmt"
	"os"
	"strconv"

	"lab.local/curriculum_scheduler_sync/pkg/digest"
)

func main() {
	if len(os.Args) < 9 {
		fmt.Fprintln(os.Stderr, "usage: digest_cli run_id global_stage sync_epoch rebalance gap workers_active stability_band converge_clean")
		os.Exit(2)
	}
	ring, _ := strconv.ParseUint(os.Args[2], 10, 32)
	global, _ := strconv.ParseUint(os.Args[3], 10, 32)
	repair, _ := strconv.ParseUint(os.Args[4], 10, 32)
	loss, _ := strconv.ParseUint(os.Args[5], 10, 32)
	live, _ := strconv.ParseUint(os.Args[6], 10, 32)
	clean := os.Args[8] == "true"
	fmt.Print(digest.ReportHex(
		os.Args[1],
		uint32(ring),
		uint32(global),
		uint32(repair),
		uint32(loss),
		uint32(live),
		os.Args[7],
		clean,
	))
}
