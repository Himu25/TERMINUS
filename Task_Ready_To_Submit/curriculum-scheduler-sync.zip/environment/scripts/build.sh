#!/bin/bash
set -euo pipefail

# Toolchain: /usr/local/go/bin/go and /usr/local/cargo/bin/cargo
export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1

mkdir -p /app/bin
cd /app/stagegate
cargo build --release --locked
cd /app
GOFLAGS=-mod=mod go build -trimpath -buildvcs=false -o /app/bin/curriculum_sync ./cmd/curriculum_sync
