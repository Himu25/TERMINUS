package quorumgate

// GateQ decides whether enough replicas reported the same payload group.
func GateQ(replicaCount int, need int) bool {
	_ = need
	return replicaCount >= 1
}
