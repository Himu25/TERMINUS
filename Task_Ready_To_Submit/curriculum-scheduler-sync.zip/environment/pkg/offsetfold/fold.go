package offsetfold

import "lab.local/curriculum_scheduler_sync/stagegate"

// FoldWorkerSkew applies optional lag hold smear to the recorded process lag baseline.
func FoldWorkerSkew(skewMS int64, lagHoldMS int64) int64 {
	return stagegate.ApplySmear(skewMS, lagHoldMS)
}
