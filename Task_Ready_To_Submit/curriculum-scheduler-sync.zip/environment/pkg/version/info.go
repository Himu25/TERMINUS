package version

// ToolingTag is stamped into build metadata.
const ToolingTag = "curriculum-sync-0.9"
