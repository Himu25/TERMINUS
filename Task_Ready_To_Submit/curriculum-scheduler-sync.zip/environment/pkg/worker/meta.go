package worker

// Profile holds per-worker clock and snapshot marks.
// ClockSkewMS is subtracted from segment gps_ms when comparing rows for ordering.
type Profile struct {
	WorkerID       string `json:"worker_id"`
	ClockSkewMS    int64  `json:"clock_skew_ms"`
	LagHoldMS      int64  `json:"lag_hold_ms"`
	SnapshotMark   uint32 `json:"snapshot_mark"`
}
