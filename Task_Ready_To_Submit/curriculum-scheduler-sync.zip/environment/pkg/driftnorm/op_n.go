package driftnorm

// OpN adjusts wall time for drift comparisons.
func OpN(wall int64, offset int64) int64 {
	return wall + offset
}
