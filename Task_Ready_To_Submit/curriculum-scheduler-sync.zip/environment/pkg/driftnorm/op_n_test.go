package driftnorm

import "testing"

func TestOpTSubtractsMemberOffset(t *testing.T) {
	const wall int64 = 1000
	const offset int64 = 40
	got := OpN(wall, offset)
	want := wall - offset
	if got != want {
		t.Fatalf("OpN(%d,%d)=%d want %d (wall minus offset)", wall, offset, got, want)
	}
}
