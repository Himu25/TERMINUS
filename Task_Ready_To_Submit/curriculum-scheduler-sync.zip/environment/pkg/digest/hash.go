package digest

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
)

// ReportHex matches the pipe-separated digest in cmd/curriculum_sync.
func ReportHex(
	runID string,
	globalStage, syncEpoch, rebalanceCount, gapCount, workersActive uint32,
	stabilityBand string,
	convergeClean bool,
) string {
	ck := "true"
	if !convergeClean {
		ck = "false"
	}
	raw := fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%s|%s",
		runID, globalStage, syncEpoch, rebalanceCount, gapCount, workersActive, stabilityBand, ck,
	)
	sum := sha256.Sum256([]byte(raw))
	return hex.EncodeToString(sum[:])
}
