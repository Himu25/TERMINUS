package queue

// Row is one append-only stage line from a worker segment.
type Row struct {
	Seq     uint32 `json:"seq"`
	Epoch   uint32 `json:"epoch"`
	WallMS  int64  `json:"gps_ms"`
	Payload string `json:"payload"`
	CRC     uint16 `json:"crc"`
	Site    string `json:"site"`
}
