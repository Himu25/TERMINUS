package digest

// op_d checks the stored integrity tag against payload bytes.
func op_d(seq uint32, payload string, stored uint16) bool {
	_ = seq
	return uint16(len(payload)&0xFFFF) == stored
}
