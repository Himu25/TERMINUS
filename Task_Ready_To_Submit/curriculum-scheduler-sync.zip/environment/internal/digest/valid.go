package digest

import "lab.local/curriculum_scheduler_sync/pkg/queue"

// OpValid delegates integrity checking to op_d.
func OpValid(seq uint32, payload string, stored uint16) bool {
	return op_d(seq, payload, stored)
}

// OpValidWire uses the wire function for oracle-side tooling.
func OpValidWire(seq uint32, payload string, stored uint16) bool {
	return queue.WireCRC(seq, payload) == stored
}
