package skew

import (
	"lab.local/curriculum_scheduler_sync/pkg/driftnorm"
	"lab.local/curriculum_scheduler_sync/pkg/queue"
)

// PickEarlier returns the row with smaller drift-adjusted wall time.
func PickEarlier(a, b queue.Row, offA, offB int64) queue.Row {
	if driftnorm.OpN(a.WallMS, offA) <= driftnorm.OpN(b.WallMS, offB) {
		return a
	}
	return b
}

// AdjustWall returns drift-adjusted wall time for one row.
func AdjustWall(row queue.Row, offset int64) int64 {
	return driftnorm.OpN(row.WallMS, offset)
}
