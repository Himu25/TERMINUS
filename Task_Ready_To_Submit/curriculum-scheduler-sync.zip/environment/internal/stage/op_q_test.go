package stage

import "testing"

func TestOpRStable(t *testing.T) {
	got := op_r([]string{"w3", "w1", "w2"})
	if len(got) != 3 || got[0] != "w1" {
		t.Fatalf("sort order: %v", got)
	}
}
