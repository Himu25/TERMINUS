package engine

import (
	"lab.local/curriculum_scheduler_sync/internal/snap"
	"lab.local/curriculum_scheduler_sync/internal/stage"
	"lab.local/curriculum_scheduler_sync/pkg/queue"
	"lab.local/curriculum_scheduler_sync/pkg/worker"
)

// Replay executes one pack through freeze and merge stages.
func Replay(
	packID string,
	qSize int,
	sepEpoch uint32,
	linkTight int64,
	profiles []worker.Profile,
	allRows map[uint32][]queue.Row,
	offsets map[string]int64,
) stage.Outcome {
	wm := snap.Watermark(profiles)
	above := make(map[uint32][]queue.Row)
	for seq, rows := range allRows {
		if seq > uint32(wm) {
			above[seq] = rows
		}
	}
	out := stage.StagePack(uint32(wm), qSize, sepEpoch, linkTight, offsets, above, allRows)
	_ = packID
	return out
}
