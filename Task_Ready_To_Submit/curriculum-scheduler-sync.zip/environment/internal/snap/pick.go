package snap

import (
	"lab.local/curriculum_scheduler_sync/pkg/snapfold"
	"lab.local/curriculum_scheduler_sync/pkg/worker"
)

// Watermark collects partition marks from profiles.
func Watermark(profiles []worker.Profile) int64 {
	marks := make([]int64, 0, len(profiles))
	for _, p := range profiles {
		marks = append(marks, int64(p.SnapshotMark))
	}
	return snapfold.OpK(marks)
}
