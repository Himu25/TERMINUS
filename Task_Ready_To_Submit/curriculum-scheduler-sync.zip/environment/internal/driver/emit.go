package driver

import (
	"encoding/json"
	"os"
)

// Report is the outward JSON envelope.
type Report struct {
	SchemaVersion string `json:"schema_version"`
	RunID        string `json:"run_id"`
	GlobalStage     uint32 `json:"global_stage"`
	SyncEpoch     uint32 `json:"sync_epoch"`
	RebalanceCount   uint32 `json:"rebalance_count"`
	GapCount     uint32 `json:"gap_count"`
	WorkersActive   uint32 `json:"workers_active"`
	StabilityBand     string `json:"stability_band"`
	ConvergeClean    bool   `json:"converge_clean"`
	DigestHex     string `json:"digest_hex"`
}

// EmitReport writes the heal output document.
func EmitReport(path string, rep Report) error {
	raw, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}
