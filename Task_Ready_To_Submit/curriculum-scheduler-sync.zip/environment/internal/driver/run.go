package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"

	"lab.local/curriculum_scheduler_sync/internal/config"
	"lab.local/curriculum_scheduler_sync/internal/engine"
)

// RunActive loads the active pack and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	pack, profiles, rows, offsets, err := config.LoadPack(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(pack.RunID, pack.QSize, pack.GateStage, pack.StabilityTightMS, profiles, rows, offsets)
	ck := "true"
	if !out.ConvergeClean {
		ck = "false"
	}
	digest := sha256.Sum256([]byte(fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%s|%s",
		pack.RunID,
		out.GlobalStage,
		out.SyncEpoch,
		out.RebalanceCount,
		out.GapCount,
		out.WorkersActive,
		out.StabilityBand,
		ck,
	)))
	return Report{
		SchemaVersion: "1",
		RunID:        pack.RunID,
		GlobalStage:     out.GlobalStage,
		SyncEpoch:     out.SyncEpoch,
		RebalanceCount:   out.RebalanceCount,
		GapCount:     out.GapCount,
		WorkersActive:   out.WorkersActive,
		StabilityBand:     out.StabilityBand,
		ConvergeClean:    out.ConvergeClean,
		DigestHex:     hex.EncodeToString(digest[:]),
	}, nil
}
