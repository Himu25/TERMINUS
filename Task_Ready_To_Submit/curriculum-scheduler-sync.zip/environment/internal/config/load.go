package config

import (
	"encoding/json"
	"os"
	"path/filepath"

	"lab.local/curriculum_scheduler_sync/pkg/queue"
	"lab.local/curriculum_scheduler_sync/pkg/offsetfold"
	"lab.local/curriculum_scheduler_sync/pkg/worker"
)

// Pack describes one heal scenario root.
type Pack struct {
	RunID       string   `json:"run_id"`
	QSize        int      `json:"q_size"`
	GateStage   uint32   `json:"gate_stage"`
	StabilityTightMS int64    `json:"stability_tight_ms"`
	Units        []string `json:"workers"`
}

// ActivePaths resolves the bundled active pack directory.
func ActivePaths(root string) (string, error) {
	return filepath.Join(root, "data", "active"), nil
}

// LoadPack reads train_pack.json and worker trees.
func LoadPack(dir string) (Pack, []worker.Profile, map[uint32][]queue.Row, map[string]int64, error) {
	raw, err := os.ReadFile(filepath.Join(dir, "train_pack.json"))
	if err != nil {
		return Pack{}, nil, nil, nil, err
	}
	var doc Pack
	if err := json.Unmarshal(raw, &doc); err != nil {
		return Pack{}, nil, nil, nil, err
	}
	profiles := make([]worker.Profile, 0, len(doc.Units))
	offsets := make(map[string]int64, len(doc.Units))
	rows := make(map[uint32][]queue.Row)
	for _, mid := range doc.Units {
		metaPath := filepath.Join(dir, "workers", mid, "meta.json")
		metaRaw, err := os.ReadFile(metaPath)
		if err != nil {
			return Pack{}, nil, nil, nil, err
		}
		var prof worker.Profile
		if err := json.Unmarshal(metaRaw, &prof); err != nil {
			return Pack{}, nil, nil, nil, err
		}
		profiles = append(profiles, prof)
		offsets[mid] = offsetfold.FoldWorkerSkew(prof.ClockSkewMS, prof.LagHoldMS)
		seg := filepath.Join(dir, "workers", mid, "seg_001.jsonl")
		data, err := os.ReadFile(seg)
		if err != nil {
			if os.IsNotExist(err) {
				continue
			}
			return Pack{}, nil, nil, nil, err
		}
		for _, line := range splitLines(string(data)) {
			if line == "" {
				continue
			}
			var row queue.Row
			if err := json.Unmarshal([]byte(line), &row); err != nil {
				continue
			}
			row.Site = mid
			rows[row.Seq] = append(rows[row.Seq], row)
		}
	}
	return doc, profiles, rows, offsets, nil
}

func splitLines(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			out = append(out, s[start:i])
			start = i + 1
		}
	}
	if start < len(s) {
		out = append(out, s[start:])
	}
	return out
}
