module lab.local/curriculum_scheduler_sync

go 1.22
