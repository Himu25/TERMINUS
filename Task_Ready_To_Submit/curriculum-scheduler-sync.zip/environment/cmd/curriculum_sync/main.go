// Report JSON for /app/output/curriculum_report.json:
//
// schema_version — string, must be "1"
// run_id — string, echoes active pack name
// global_stage — highest epoch in the consistent chain; scan worker rows at every
// sequence up through sync_epoch, including watermark-covered positions whose stage
// groups were never admitted above the watermark
// sync_epoch — highest contiguous sequence included in the chain; positions at or
// below the watermark count as already covered when extending the chain
// rebalance_count — integrity repairs applied during sync
// gap_count — training steps without worker agreement
// workers_active — count of workers contributing to accepted rows
// stability_band — string, "stable" or "marginal"
// converge_clean — boolean (not 0/1 strings)
// digest_hex — lowercase hex SHA-256 of run_id|global_stage|sync_epoch|rebalance_count|gap_count|workers_active|stability_band|converge_clean
//
// Root object contains only these keys.
//
// Replay derives one watermark from the five worker snapshot_mark values in each
// worker meta.json; use the lowest mark across the run. At each training step above
// that watermark, rows sharing the same stage epoch and payload form a stage group.
// A group is admitted only when it has worker quorum: at least q_size distinct workers
// and at least q_size integrity-valid rows in that group (q_size from the active pack).
// Only sequence positions present in worker logs above the watermark are steps; positions
// with no worker rows are not counted. Steps with no admitted group increment gap_count.
// When several groups qualify at one
// step, the winning group is the one whose earliest lag-adjusted process time wins —
// raw gps_ms minus that worker's effective skew (clock_skew_ms minus any lag_hold_ms
// smear applied through the native stagegate bridge when folding worker skew).
// rebalance_count tallies integrity repairs applied only to replicas in the
// admitted group for each step. stability_band is stable when spread of those same
// replay offsets across workers is within stability_tight_ms from the pack, otherwise
// marginal. After gate_stage,
// admitted groups must retain q_size distinct workers or converge_clean becomes false.
package main

import (
	"log"
	"os"

	"lab.local/curriculum_scheduler_sync/internal/driver"
)

func main() {
	if os.Getenv("TB_CURRICULUM_FIXTURE") != "1" {
		log.Fatal("TB_CURRICULUM_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/curriculum_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
