/// SgApplyLag folds a lag hold band into a worker process lag baseline (milliseconds).
#[no_mangle]
pub extern "C" fn sg_apply_lag(base_ms: i64, hold_ms: i64) -> i64 {
    if hold_ms == 0 {
        return base_ms;
    }
    base_ms + hold_ms
}
