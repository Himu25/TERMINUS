#pragma once

long long sg_apply_lag(long long base_ms, long long hold_ms);
