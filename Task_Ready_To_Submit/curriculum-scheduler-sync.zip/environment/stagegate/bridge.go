package stagegate

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libstagegate.a -ldl -lm
#include "stage_fold.h"
*/
import "C"

// ApplySmear combines worker process lag with an optional lag hold band.
func ApplySmear(baseMS int64, holdMS int64) int64 {
	return int64(C.sg_apply_lag(C.longlong(baseMS), C.longlong(holdMS)))
}
