#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/pkg/quorumgate/op_q.go <<'EOF'
package quorumgate

func quorumMet(count int, need int) bool {
	if need <= 0 {
		return false
	}
	if count < 0 {
		return false
	}
	return count >= need
}

// GateQ decides whether enough replicas reported the same payload group.
func GateQ(replicaCount int, need int) bool {
	return quorumMet(replicaCount, need)
}
EOF

cat > /app/internal/digest/op_d.go <<'EOF'
package digest

import "lab.local/curriculum_scheduler_sync/pkg/queue"

func wireMatch(seq uint32, payload string, stored uint16) bool {
	want := queue.WireCRC(seq, payload)
	return want == stored
}

// op_d checks the stored integrity tag against payload bytes.
func op_d(seq uint32, payload string, stored uint16) bool {
	if payload == "" {
		return stored == 0 && seq == 0
	}
	return wireMatch(seq, payload, stored)
}
EOF

cat > /app/pkg/driftnorm/op_n.go <<'EOF'
package driftnorm

func normalizeWall(wall int64, offset int64) int64 {
	return wall - offset
}

// OpN adjusts wall time for drift comparisons.
func OpN(wall int64, offset int64) int64 {
	return normalizeWall(wall, offset)
}
EOF

cat > /app/pkg/snapfold/op_k.go <<'EOF'
package snapfold

func minMark(marks []int64) int64 {
	if len(marks) == 0 {
		return 0
	}
	best := marks[0]
	for _, m := range marks[1:] {
		if m < best {
			best = m
		}
	}
	return best
}

// OpK folds member marks into one replay watermark.
func OpK(marks []int64) int64 {
	return minMark(marks)
}
EOF

cat > /app/stagegate/src/lib.rs <<'EOF'
use std::os::raw::c_longlong;

/// SgApplyLag folds a lag hold band into a worker process lag baseline (milliseconds).
#[no_mangle]
pub extern "C" fn sg_apply_lag(base_ms: c_longlong, hold_ms: c_longlong) -> c_longlong {
    if hold_ms == 0 {
        return base_ms;
    }
    base_ms - hold_ms
}
EOF

bash /app/scripts/build.sh

rm -f /app/output/curriculum_report.json
mkdir -p /app/output
TB_CURRICULUM_FIXTURE=1 /app/bin/curriculum_sync
test -s /app/output/curriculum_report.json

GOFLAGS=-mod=mod go test ./...
