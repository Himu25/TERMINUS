Multi-tenant ML feature platform. Materializes snapshots under feature_store/, publishes training_exports/, serves online_features/, and retains audit_logs/ for replay.

The leakaudit driver replays pack bundles and emits /app/output/leakage_audit.json.

Build: /app/scripts/build.sh
Run: tb_leak_pack=<pack_stem> /app/bin/leakaudit
