#!/bin/bash
set -euo pipefail
test -f /app/go.mod
test -f /app/config/isolation.toml
echo "layout ok"
