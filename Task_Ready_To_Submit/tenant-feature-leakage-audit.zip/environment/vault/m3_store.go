package vault

// M3Store is a minimal in-memory hot cache for feature values.
type M3Store struct {
	data map[string]entry
}

type entry struct {
	val      float64
	tenantID string
}

func NewM3Store() *M3Store {
	return &M3Store{data: make(map[string]entry)}
}

func (s *M3Store) Put(key, tenantID string, val float64) {
	s.data[key] = entry{val: val, tenantID: tenantID}
}

func (s *M3Store) Get(key string) (float64, string, bool) {
	e, ok := s.data[key]
	if !ok {
		return 0, "", false
	}
	return e.val, e.tenantID, true
}
