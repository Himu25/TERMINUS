package normfold

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libnormfold.a -ldl -lm
#include <stdlib.h>
extern double nf_blend(double raw, double tenant_mean, double tenant_std);
extern void nf_stats(double* values, int len, double* out_mean, double* out_std);
*/
import "C"
import "unsafe"

// NfBlend normalizes a raw feature using tenant statistics.
func NfBlend(raw, tenantMean, tenantStd float64) float64 {
	return float64(C.nf_blend(C.double(raw), C.double(tenantMean), C.double(tenantStd)))
}

// NfStats computes mean and standard deviation for values.
func NfStats(values []float64) (mean, std float64) {
	if len(values) == 0 {
		return 0, 1
	}
	cvals := make([]C.double, len(values))
	for i, v := range values {
		cvals[i] = C.double(v)
	}
	var cmean, cstd C.double
	C.nf_stats((*C.double)(unsafe.Pointer(&cvals[0])), C.int(len(cvals)), &cmean, &cstd)
	return float64(cmean), float64(cstd)
}
