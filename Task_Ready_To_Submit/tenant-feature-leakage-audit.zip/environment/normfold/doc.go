// Package normfold binds the Rust normalization static library.
package normfold
