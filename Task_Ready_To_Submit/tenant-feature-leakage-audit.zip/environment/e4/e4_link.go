package e4

import (
	"leakbench.dev/leakaudit/pkg/types"
	"leakbench.dev/leakaudit/vault"
)

func E4Bind(rows []types.FeatureRow) map[string]types.FeatureRow {
	out := make(map[string]types.FeatureRow, len(rows))
	for _, row := range rows {
		out[vault.M3Compose(row.TenantID, row.EntityID)] = row
	}
	return out
}
