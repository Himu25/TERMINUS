package s5

import "leakbench.dev/leakaudit/pkg/types"

func S5Resolve(rows []types.FeatureRow, tenantID string) int {
	maxVer := 0
	fallback := 0
	for _, row := range rows {
		if row.ExportVer > maxVer {
			maxVer = row.ExportVer
		}
		if row.ExportVer > fallback {
			fallback = row.ExportVer
		}
	}
	if maxVer == 0 {
		return fallback
	}
	return maxVer
}
