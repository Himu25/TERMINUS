#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1
export GOCACHE="${GOCACHE:-/app/output/go-build}"

ROOT="${APP_ROOT:-/app}"
mkdir -p "${ROOT}/bin" "${GOCACHE}"
cd "${ROOT}/normfold"
cargo build --release
cd "${ROOT}"
GOFLAGS=-mod=mod go build -a -trimpath -buildvcs=false -o "${ROOT}/bin/leakaudit" ./cmd/leakaudit
