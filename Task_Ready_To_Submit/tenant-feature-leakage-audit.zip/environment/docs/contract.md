# Leakage audit counter semantics

Successful driver runs write status ok in /app/output/leakage_audit.json. Counters below are emitted by the rebuilt replay driver, not adjusted after the fact.

Each scenario_runs row reports replay counters from one pack under /app/packs.

- cross_tenant_hits: foreign feature values observed during cache or export replay
- stale_export_rows: rows served from export versions below the tenant-visible cutoff
- cache_bleed_count: partition-local cache collisions across tenant boundaries
- duplicate_entity_collisions: entity identifiers reused under different tenant scopes
- indirect_leak_units: rows whose normalized values diverge from tenant-local expectations
- isolation_purity: fraction of reads that stayed tenant-local (0.0 to 1.0)
- lineage_edges: reconstructed edges linking feature_store, training_exports, and online_features

Identical tb_leak_pack replays emit byte-identical /app/output/leakage_audit.json.
