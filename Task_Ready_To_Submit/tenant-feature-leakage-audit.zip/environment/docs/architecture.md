Feature platform layout: feature_store snapshots, training_exports manifests, online_features serving layer, audit_logs tail.

Materialization, export binding, online serving, and normalization stages feed the replay driver before audit counters are emitted.
