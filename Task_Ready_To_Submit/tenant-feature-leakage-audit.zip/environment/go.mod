module leakbench.dev/leakaudit

go 1.22
