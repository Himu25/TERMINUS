// leakaudit replays multi-tenant feature packs and emits leakage audit reports.
//
// Invoke with tb_leak_pack set to a stem under /app/packs.
// Output /app/output/leakage_audit.json carries scenario_runs with exactly one row.
package main

import (
	"os"

	"leakbench.dev/leakaudit/internal/pipeline"
)

func main() {
	os.Exit(pipeline.MainExit())
}
