package pipeline

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"sort"

	"leakbench.dev/leakaudit/e4"
	"leakbench.dev/leakaudit/normfold"
	"leakbench.dev/leakaudit/pkg/types"
	"leakbench.dev/leakaudit/s5"
	"leakbench.dev/leakaudit/p2"
	"leakbench.dev/leakaudit/vault"
)

const targetTenant = "t-aurora-17"
const tenantCount = 50
const bucketCount = 8

func MainExit() int {
	packStem := os.Getenv("tb_leak_pack")
	if packStem == "" {
		packStem = "pack_default"
	}
	packPath := filepath.Join("/app/packs", packStem+".json")
	raw, err := os.ReadFile(packPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "pack read: %v\n", err)
		return 2
	}
	var bundle types.PackBundle
	if err := json.Unmarshal(raw, &bundle); err != nil {
		fmt.Fprintf(os.Stderr, "pack decode: %v\n", err)
		return 2
	}
	run, lineage := LaneDrive(bundle)
	report := types.AuditReport{
		Status:           "ok",
		TenantCount:      tenantCount,
		TargetTenant:     targetTenant,
		ScenarioRuns:     []types.ScenarioRun{run},
		LineageEdgeCount: lineage,
		RepairReady:      run.CrossTenantHits == 0 && run.IndirectLeakUnits == 0 && run.IsolationPurity >= 0.95,
	}
	report.ReportDigest = sealHx(report)
	outDir := "/app/output"
	if err := os.MkdirAll(outDir, 0o755); err != nil {
		fmt.Fprintf(os.Stderr, "mkdir: %v\n", err)
		return 2
	}
	payload, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		fmt.Fprintf(os.Stderr, "marshal: %v\n", err)
		return 2
	}
	payload = append(payload, '\n')
	if err := os.WriteFile(filepath.Join(outDir, "leakage_audit.json"), payload, 0o644); err != nil {
		fmt.Fprintf(os.Stderr, "write: %v\n", err)
		return 2
	}
	return 0
}

func LaneDrive(bundle types.PackBundle) (types.ScenarioRun, int) {
	rows := append([]types.FeatureRow(nil), bundle.Rows...)
	sort.Slice(rows, func(i, j int) bool {
		if rows[i].TenantID != rows[j].TenantID {
			return rows[i].TenantID < rows[j].TenantID
		}
		if rows[i].EntityID != rows[j].EntityID {
			return rows[i].EntityID < rows[j].EntityID
		}
		return rows[i].Seq < rows[j].Seq
	})

	cache := vault.NewM3Store()
	crossHits := 0
	cacheBleed := 0
	dupCollisions := 0
	staleRows := 0
	indirectUnits := 0
	lineage := 0
	totalReads := 0
	cleanReads := 0

	serveVer := s5.S5Resolve(rows, targetTenant)
	linked := e4.E4Bind(rows)
	groups := p2.P2Group(rows, bucketCount)

	tenantVals := make(map[string][]float64)
	for _, row := range rows {
		tenantVals[row.TenantID] = append(tenantVals[row.TenantID], row.Value)
	}
	tenantStats := make(map[string][2]float64)
	for tid, vals := range tenantVals {
		m, s := normfold.NfStats(vals)
		tenantStats[tid] = [2]float64{m, s}
	}

	seenEntity := make(map[string]string)
	for _, row := range rows {
		if prev, ok := seenEntity[row.EntityID]; ok && prev != row.TenantID {
			dupCollisions++
		}
		seenEntity[row.EntityID] = row.TenantID
	}

	for _, row := range rows {
		key := vault.M3Compose(row.TenantID, row.EntityID)
		if cached, owner, ok := cache.Get(key); ok {
			totalReads++
			if owner != row.TenantID {
				crossHits++
			} else if math.Abs(cached-row.Value) > 1e-6 && row.Seq > 1 {
				cleanReads++
			} else {
				cleanReads++
			}
		}
		cache.Put(key, row.TenantID, row.Value)
		lineage++

		linkKey := vault.M3Compose(row.TenantID, row.EntityID)
		if linkedRow, ok := linked[linkKey]; ok {
			lineage++
			if linkedRow.TenantID != row.TenantID {
				crossHits++
			}
			if row.TenantID == targetTenant && linkedRow.ExportVer < serveVer && row.ExportVer < bundle.StaleCutoff {
				staleRows++
			}
		}

		stats := tenantStats[row.TenantID]
		normed := normfold.NfBlend(row.Value, stats[0], stats[1])
		expected := (row.Value - stats[0]) / stats[1]
		if math.Abs(normed-expected) > 0.05 {
			indirectUnits++
		}
	}

	for _, batch := range groups {
		tenantsInBucket := make(map[string]struct{})
		for _, row := range batch {
			tenantsInBucket[row.TenantID] = struct{}{}
		}
		if len(tenantsInBucket) <= 1 {
			continue
		}
		for i := range batch {
			for j := i + 1; j < len(batch); j++ {
				if batch[i].TenantID != batch[j].TenantID && batch[i].EntityID == batch[j].EntityID {
					cacheBleed++
				}
			}
		}
	}

	purity := 0.0
	if totalReads > 0 {
		purity = float64(cleanReads) / float64(totalReads)
	} else if crossHits == 0 && indirectUnits == 0 {
		purity = 1.0
	}

	return types.ScenarioRun{
		ScenarioTag:               bundle.ScenarioLabel,
		CrossTenantHits:           crossHits,
		StaleExportRows:           staleRows,
		CacheBleedCount:           cacheBleed,
		DuplicateEntityCollisions: dupCollisions,
		IndirectLeakUnits:         indirectUnits,
		IsolationPurity:           round3(purity),
		LineageEdges:              lineage,
	}, lineage
}

func round3(v float64) float64 {
	return math.Round(v*1000) / 1000
}

func sealHx(r types.AuditReport) string {
	h := sha256.New()
	for _, row := range r.ScenarioRuns {
		fmt.Fprintf(h, "%s:%d:%d:%d:%d:%d:%.3f:%d\n",
			row.ScenarioTag,
			row.CrossTenantHits,
			row.StaleExportRows,
			row.CacheBleedCount,
			row.DuplicateEntityCollisions,
			row.IndirectLeakUnits,
			row.IsolationPurity,
			row.LineageEdges,
		)
	}
	return hex.EncodeToString(h.Sum(nil))
}
