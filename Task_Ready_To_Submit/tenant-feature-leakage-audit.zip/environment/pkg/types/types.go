package types

// FeatureRow is one materialized feature observation.
type FeatureRow struct {
	TenantID   string  `json:"tenant_id"`
	EntityID   string  `json:"entity_id"`
	Value      float64 `json:"value"`
	ExportVer  int     `json:"export_ver"`
	CacheEpoch int     `json:"cache_epoch"`
	Seq        int     `json:"seq"`
}

// PackBundle drives one audit scenario replay.
type PackBundle struct {
	ScenarioLabel string       `json:"scenario_label"`
	Rows          []FeatureRow `json:"rows"`
	StaleCutoff   int          `json:"stale_cutoff"`
}

// ScenarioRun is one row in the audit report.
type ScenarioRun struct {
	ScenarioTag               string  `json:"scenario_tag"`
	CrossTenantHits           int     `json:"cross_tenant_hits"`
	StaleExportRows           int     `json:"stale_export_rows"`
	CacheBleedCount           int     `json:"cache_bleed_count"`
	DuplicateEntityCollisions int     `json:"duplicate_entity_collisions"`
	IndirectLeakUnits         int     `json:"indirect_leak_units"`
	IsolationPurity           float64 `json:"isolation_purity"`
	LineageEdges              int     `json:"lineage_edges"`
}

// AuditReport is written to /app/output/leakage_audit.json.
type AuditReport struct {
	Status           string        `json:"status"`
	TenantCount      int           `json:"tenant_count"`
	TargetTenant     string        `json:"target_tenant"`
	ScenarioRuns     []ScenarioRun `json:"scenario_runs"`
	LineageEdgeCount int           `json:"lineage_edge_count"`
	ReportDigest     string        `json:"report_digest"`
	RepairReady      bool          `json:"repair_ready"`
}
