package p2

import "leakbench.dev/leakaudit/pkg/types"

// P2Group buckets rows by partition id.
func P2Group(rows []types.FeatureRow, bucketCount int) map[int][]types.FeatureRow {
	out := make(map[int][]types.FeatureRow)
	for _, row := range rows {
		b := P2Shard(row.TenantID, row.EntityID, bucketCount)
		out[b] = append(out[b], row)
	}
	return out
}
