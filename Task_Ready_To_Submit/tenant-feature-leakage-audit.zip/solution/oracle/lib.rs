use std::os::raw::c_double;

/// nf_blend applies tenant-local normalization stats to raw feature values.
#[no_mangle]
pub extern "C" fn nf_blend(raw: c_double, tenant_mean: c_double, tenant_std: c_double) -> c_double {
    if tenant_std.abs() < 1e-9 {
        return raw;
    }
    (raw - tenant_mean) / tenant_std
}

/// nf_stats computes mean and std for a slice of values.
#[no_mangle]
pub extern "C" fn nf_stats(values: *const c_double, len: i32, out_mean: *mut c_double, out_std: *mut c_double) {
    if values.is_null() || out_mean.is_null() || out_std.is_null() || len <= 0 {
        unsafe {
            *out_mean = 0.0;
            *out_std = 1.0;
        }
        return;
    }
    let slice = unsafe { std::slice::from_raw_parts(values, len as usize) };
    let sum: f64 = slice.iter().sum();
    let mean = sum / slice.len() as f64;
    let var: f64 = slice.iter().map(|v| (v - mean).powi(2)).sum::<f64>() / slice.len() as f64;
    unsafe {
        *out_mean = mean;
        *out_std = var.sqrt().max(1e-9);
    }
}
