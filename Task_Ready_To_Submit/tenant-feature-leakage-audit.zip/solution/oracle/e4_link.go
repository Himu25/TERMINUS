package e4

import (
	"fmt"

	"leakbench.dev/leakaudit/pkg/types"
)

func E4Bind(rows []types.FeatureRow) map[string]types.FeatureRow {
	out := make(map[string]types.FeatureRow, len(rows))
	for _, row := range rows {
		key := fmt.Sprintf("%s:%s", row.TenantID, row.EntityID)
		out[key] = row
	}
	return out
}
