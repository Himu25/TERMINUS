package s5

import "leakbench.dev/leakaudit/pkg/types"

func S5Resolve(rows []types.FeatureRow, tenantID string) int {
	maxVer := 0
	for _, row := range rows {
		if row.TenantID != tenantID {
			continue
		}
		if row.ExportVer > maxVer {
			maxVer = row.ExportVer
		}
	}
	return maxVer
}
