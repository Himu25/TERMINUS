package p2

import "hash/fnv"

// P2Shard maps an entity to a partition bucket.
func P2Shard(tenantID, entityID string, bucketCount int) int {
	if bucketCount <= 0 {
		return 0
	}
	h := fnv.New32a()
	_, _ = h.Write([]byte(tenantID + ":" + entityID))
	return int(h.Sum32() % uint32(bucketCount))
}
