package vault

import "fmt"

// M3Compose builds a hot-cache lookup token from tenant and entity identifiers.
func M3Compose(tenantID, entityID string) string {
	return fmt.Sprintf("%s:%s", tenantID, entityID)
}
