#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TASK_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

if [ -f "/app/go.mod" ] && [ -d "/app/vault" ]; then
  env_dir="/app"
elif [ -d "$TASK_DIR/environment" ]; then
  env_dir="$TASK_DIR/environment"
elif [ -d "/environment" ] && [ -f "/environment/go.mod" ]; then
  env_dir="/environment"
else
  echo "Could not locate task environment layout." >&2
  exit 1
fi

log() { printf '==> %s\n' "$1"; }

log "survey tenant isolation workspace under feature_store and online_features"
grep -nE 'tenant|export|cache|partition' \
  "$env_dir/config/isolation.toml" \
  "$env_dir/feature_store/registry.conf" \
  "$env_dir/training_exports/policy.toml" \
  "$env_dir/online_features/serve.toml" 2>/dev/null | head -n 20 || true

log "apply leakage repair patch across vault, p2, e4, serve, normfold, pipeline"
cd "$SCRIPT_DIR"
patch -p1 --forward -d "$env_dir" <fixes.patch

log "rebuild leakaudit driver and normfold static library"
bash "$env_dir/scripts/build.sh"

if [ ! -x "$env_dir/bin/leakaudit" ]; then
  echo "leakaudit binary missing after rebuild" >&2
  exit 1
fi

log "smoke replay regression packs"
python3 <<PY
import json
import os
import subprocess
import sys
from pathlib import Path

env = Path("$env_dir")
probes = {
    "pack_clean": {"cross_tenant_hits": 0, "indirect_leak_units": 0, "isolation_purity_min": 0.95},
    "pack_cache_bleed": {"cross_tenant_hits": 0, "isolation_purity_min": 0.95},
    "pack_stale_export": {"cross_tenant_hits": 0, "stale_export_rows_min": 1},
    "pack_dup_entity": {"cross_tenant_hits": 0, "duplicate_entity_collisions_min": 2},
    "pack_indirect": {"cross_tenant_hits": 0, "indirect_leak_units": 0},
    "pack_shard_mix": {"cross_tenant_hits": 0, "cache_bleed_count": 0},
    "pack_lineage": {"cross_tenant_hits": 0, "lineage_edges_min": 1},
}
for probe, expect in probes.items():
    out = env / "output" / "leakage_audit.json"
    out.unlink(missing_ok=True)
    subprocess.run(
        [str(env / "bin" / "leakaudit")],
        cwd=env,
        env={**os.environ, "tb_leak_pack": probe},
        check=True,
        stdout=subprocess.DEVNULL,
    )
    if not out.is_file():
        print(f"probe {probe} produced no report", file=sys.stderr)
        sys.exit(1)
    row = json.loads(out.read_text(encoding="utf-8"))["scenario_runs"][0]
    if row.get("cross_tenant_hits") != expect.get("cross_tenant_hits", 0):
        print(f"probe {probe} cross-tenant leak: {row}", file=sys.stderr)
        sys.exit(1)
    if "indirect_leak_units" in expect and row.get("indirect_leak_units") != expect["indirect_leak_units"]:
        print(f"probe {probe} indirect leak: {row}", file=sys.stderr)
        sys.exit(1)
    if "cache_bleed_count" in expect and row.get("cache_bleed_count") != expect["cache_bleed_count"]:
        print(f"probe {probe} cache bleed: {row}", file=sys.stderr)
        sys.exit(1)
    if "isolation_purity_min" in expect and row.get("isolation_purity", 0) < expect["isolation_purity_min"]:
        print(f"probe {probe} purity floor miss: {row}", file=sys.stderr)
        sys.exit(1)
    if "stale_export_rows_min" in expect and row.get("stale_export_rows", 0) < expect["stale_export_rows_min"]:
        print(f"probe {probe} stale export miss: {row}", file=sys.stderr)
        sys.exit(1)
    if "duplicate_entity_collisions_min" in expect and row.get("duplicate_entity_collisions", 0) < expect["duplicate_entity_collisions_min"]:
        print(f"probe {probe} dup collision miss: {row}", file=sys.stderr)
        sys.exit(1)
    if "lineage_edges_min" in expect and row.get("lineage_edges", 0) < expect["lineage_edges_min"]:
        print(f"probe {probe} lineage miss: {row}", file=sys.stderr)
        sys.exit(1)
PY

log "oracle repaired tenant-scoped cache keys, shard routing, export binding, serve version resolution, normfold blending, and pipeline link lookup"
