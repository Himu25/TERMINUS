"""Verifier for multi-tenant feature leakage audit."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

APP = Path("/app")
APP_ROOT = "/app"

FIXTURES = Path("/tests/fixtures")
REPORT = APP / "output" / "leakage_audit.json"
TARGET_TENANT = "t-aurora-17"
TENANT_COUNT = 50
BUCKET_COUNT = 8
DRIVE_TIMEOUT = 20


def _load_pack(stem: str) -> dict:
    return json.loads((APP / "packs" / f"{stem}.json").read_text(encoding="utf-8"))


def _stem_tag(stem: str) -> str:
    return str(_load_pack(stem)["scenario_label"])


def _m3_compose(tenant_id: str, entity_id: str) -> str:
    return f"{tenant_id}:{entity_id}"


def _fnv1a32(data: bytes) -> int:
    h = 2166136261
    for b in data:
        h ^= b
        h = (h * 16777619) & 0xFFFFFFFF
    return h


def _p2_shard(tenant_id: str, entity_id: str) -> int:
    key = f"{tenant_id}:{entity_id}".encode()
    return _fnv1a32(key) % BUCKET_COUNT


def _nf_stats(values: list[float]) -> tuple[float, float]:
    if not values:
        return 0.0, 1.0
    mean = sum(values) / len(values)
    var = sum((v - mean) ** 2 for v in values) / len(values)
    return mean, max(var**0.5, 1e-9)


def _nf_blend(raw: float, mean: float, std: float) -> float:
    if std < 1e-9:
        return raw
    return (raw - mean) / std


def _ref_row(stem: str) -> dict:
    """Independent reference replay using tenant-scoped fixed semantics."""
    bundle = _load_pack(stem)
    rows = sorted(
        bundle["rows"],
        key=lambda r: (r["tenant_id"], r["entity_id"], r["seq"]),
    )
    cache: dict[str, tuple[float, str]] = {}
    cross_hits = 0
    cache_bleed = 0
    dup_collisions = 0
    stale_rows = 0
    indirect_units = 0
    lineage = 0
    total_reads = 0
    clean_reads = 0

    serve_ver = max(
        (r["export_ver"] for r in rows if r["tenant_id"] == TARGET_TENANT),
        default=0,
    )
    linked = {_m3_compose(r["tenant_id"], r["entity_id"]): r for r in rows}
    groups: dict[int, list[dict]] = {}
    for row in rows:
        groups.setdefault(_p2_shard(row["tenant_id"], row["entity_id"]), []).append(row)

    tenant_vals: dict[str, list[float]] = {}
    for row in rows:
        tenant_vals.setdefault(row["tenant_id"], []).append(row["value"])
    tenant_stats = {tid: _nf_stats(vals) for tid, vals in tenant_vals.items()}

    seen_entity: dict[str, str] = {}
    for row in rows:
        prev = seen_entity.get(row["entity_id"])
        if prev is not None and prev != row["tenant_id"]:
            dup_collisions += 1
        seen_entity[row["entity_id"]] = row["tenant_id"]

    for row in rows:
        key = _m3_compose(row["tenant_id"], row["entity_id"])
        if key in cache:
            cached, owner = cache[key]
            total_reads += 1
            if owner != row["tenant_id"]:
                cross_hits += 1
            else:
                clean_reads += 1
        cache[key] = (row["value"], row["tenant_id"])
        lineage += 1

        link_key = _m3_compose(row["tenant_id"], row["entity_id"])
        if link_key in linked:
            lineage += 1
            linked_row = linked[link_key]
            if linked_row["tenant_id"] != row["tenant_id"]:
                cross_hits += 1
            if (
                row["tenant_id"] == TARGET_TENANT
                and linked_row["export_ver"] < serve_ver
                and row["export_ver"] < bundle["stale_cutoff"]
            ):
                stale_rows += 1

        mean, std = tenant_stats[row["tenant_id"]]
        normed = _nf_blend(row["value"], mean, std)
        expected = _nf_blend(row["value"], mean, std)
        if abs(normed - expected) > 0.05:
            indirect_units += 1

    for batch in groups.values():
        tenants = {r["tenant_id"] for r in batch}
        if len(tenants) <= 1:
            continue
        for i, a in enumerate(batch):
            for b in batch[i + 1 :]:
                if a["tenant_id"] != b["tenant_id"] and a["entity_id"] == b["entity_id"]:
                    cache_bleed += 1

    purity = 1.0 if total_reads == 0 else clean_reads / total_reads
    if total_reads == 0 and cross_hits == 0 and indirect_units == 0:
        purity = 1.0

    return {
        "scenario_tag": bundle["scenario_label"],
        "cross_tenant_hits": cross_hits,
        "stale_export_rows": stale_rows,
        "cache_bleed_count": cache_bleed,
        "duplicate_entity_collisions": dup_collisions,
        "indirect_leak_units": indirect_units,
        "isolation_purity": round(purity, 3),
        "lineage_edges": lineage,
    }


def _rebuild() -> None:
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd=APP_ROOT, check=True, timeout=120)


def _drive(stem: str) -> dict:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    if REPORT.exists():
        REPORT.unlink()
    subprocess.run(
        ["/app/bin/leakaudit"],
        cwd=APP_ROOT,
        env={**os.environ, "tb_leak_pack": stem},
        check=True,
        timeout=DRIVE_TIMEOUT,
    )
    payload = json.loads(REPORT.read_text(encoding="utf-8"))
    assert payload.get("status") == "ok"
    assert payload.get("tenant_count") == TENANT_COUNT
    assert payload.get("target_tenant") == TARGET_TENANT
    assert "scenario_runs" in payload and len(payload["scenario_runs"]) == 1
    row = payload["scenario_runs"][0]
    assert row.get("scenario_tag") == _stem_tag(stem)
    return row


def _assert_matches_ref(stem: str, row: dict) -> None:
    ref = _ref_row(stem)
    for key, value in ref.items():
        assert row[key] == value, f"{stem} {key}: got {row[key]!r}, ref {value!r}"


def _assert_scenario_keys(stem: str, row: dict, keys: list[str]) -> None:
    ref = _ref_row(stem)
    for key in keys:
        assert row[key] == ref[key], f"{stem} {key}: got {row[key]!r}, ref {ref[key]!r}"


def test_report_schema_and_target_tenant() -> None:
    """Audit report names t-aurora-17 among 50 tenants with a digest."""
    subprocess.run(
        ["/app/bin/leakaudit"],
        cwd=APP_ROOT,
        env={**os.environ, "tb_leak_pack": "pack_default"},
        check=True,
        timeout=DRIVE_TIMEOUT,
    )
    payload = json.loads(REPORT.read_text(encoding="utf-8"))
    assert payload["status"] == "ok"
    assert payload["tenant_count"] == TENANT_COUNT
    assert payload["target_tenant"] == TARGET_TENANT
    assert isinstance(payload["report_digest"], str) and len(payload["report_digest"]) > 0
    assert payload["repair_ready"] is True
    row = payload["scenario_runs"][0]
    assert row["cross_tenant_hits"] == 0
    assert row["indirect_leak_units"] == 0
    assert row["isolation_purity"] >= 0.95


def test_cache_cross_read_isolation() -> None:
    """Shared entity ids across tenants must not cross-read cached values."""
    row = _drive("pack_cache_bleed")
    _assert_scenario_keys(
        "pack_cache_bleed",
        row,
        ["cross_tenant_hits", "isolation_purity", "scenario_tag"],
    )
    assert row["cross_tenant_hits"] == 0
    assert row["isolation_purity"] >= 0.95


def test_stale_export_slice() -> None:
    """Tenant-scoped export resolution flags stale rows below cutoff."""
    row = _drive("pack_stale_export")
    _assert_scenario_keys(
        "pack_stale_export",
        row,
        ["stale_export_rows", "cross_tenant_hits", "scenario_tag"],
    )
    assert row["cross_tenant_hits"] == 0


def test_dup_entity_collision_audit() -> None:
    """Duplicate entity identifiers across tenants are counted but do not leak values."""
    row = _drive("pack_dup_entity")
    _assert_scenario_keys(
        "pack_dup_entity",
        row,
        ["duplicate_entity_collisions", "cross_tenant_hits", "scenario_tag"],
    )
    assert row["cross_tenant_hits"] == 0


def test_indirect_norm_blend() -> None:
    """Normalization uses tenant-local stats rather than shared moments."""
    _assert_matches_ref("pack_indirect", _drive("pack_indirect"))


def test_clean_isolation_baseline() -> None:
    """Distinct tenants with unique entity ids stay fully isolated."""
    _assert_matches_ref("pack_clean", _drive("pack_clean"))


def test_shard_mix_bleed() -> None:
    """Partition routing keeps foreign tenant rows out of cache replay."""
    row = _drive("pack_shard_mix")
    _assert_scenario_keys(
        "pack_shard_mix",
        row,
        ["cache_bleed_count", "cross_tenant_hits", "scenario_tag"],
    )
    assert row["cross_tenant_hits"] == 0


def test_lineage_rebuild() -> None:
    """Lineage edges rebuild without cross-tenant contamination."""
    _assert_matches_ref("pack_lineage", _drive("pack_lineage"))


def test_deterministic_replay_digest() -> None:
    """Identical pack replay yields byte-identical audit output."""
    env = {**os.environ, "tb_leak_pack": "pack_default"}
    REPORT.unlink(missing_ok=True)
    subprocess.run(["/app/bin/leakaudit"], cwd=APP_ROOT, env=env, check=True, timeout=DRIVE_TIMEOUT)
    first = REPORT.read_bytes()
    subprocess.run(["/app/bin/leakaudit"], cwd=APP_ROOT, env=env, check=True, timeout=DRIVE_TIMEOUT)
    second = REPORT.read_bytes()
    assert first == second
    payload = json.loads(first.decode("utf-8"))
    assert payload["report_digest"]


def test_ablation_cache_key_regression() -> None:
    """Reverting cache key composition reintroduces cross-tenant hits."""
    good = (APP / "vault" / "m3_key.go").read_text(encoding="utf-8")
    try:
        shutil.copy(FIXTURES / "z_m3_key.go", APP / "vault" / "m3_key.go")
        _rebuild()
        row = _drive("pack_cache_bleed")
        assert row["cross_tenant_hits"] >= 1
    finally:
        (APP / "vault" / "m3_key.go").write_text(good, encoding="utf-8")
        _rebuild()


def test_ablation_normfold_regression() -> None:
    """Reverting normfold blending changes replay metrics away from the reference."""
    ref = _ref_row("pack_indirect")
    good = (APP / "normfold" / "src" / "lib.rs").read_text(encoding="utf-8")
    try:
        shutil.copy(FIXTURES / "z_r1.rs", APP / "normfold" / "src" / "lib.rs")
        _rebuild()
        row = _drive("pack_indirect")
        assert row["indirect_leak_units"] > ref["indirect_leak_units"] or row != ref
    finally:
        (APP / "normfold" / "src" / "lib.rs").write_text(good, encoding="utf-8")
        _rebuild()
