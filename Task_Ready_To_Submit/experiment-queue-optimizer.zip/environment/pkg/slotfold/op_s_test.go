package slotfold

import "testing"

func TestOpSShortfall(t *testing.T) {
	tax := OpS(map[string]uint32{"a": 0, "b": 10}, 10, 20, 2)
	if tax != 1 {
		t.Fatal("expected share shortfall tax")
	}
}
