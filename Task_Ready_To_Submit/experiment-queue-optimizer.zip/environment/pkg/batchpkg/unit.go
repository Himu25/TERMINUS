package batchpkg

import "strings"

type RankKey struct {
	JobID string
	Score uint64
}

func TieBreak(a, b RankKey) int {
	return strings.Compare(a.JobID, b.JobID)
}
