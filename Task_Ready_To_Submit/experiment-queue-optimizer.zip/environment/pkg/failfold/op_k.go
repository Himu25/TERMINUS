package failfold

func OpK(units uint32) uint32 {
	return units * 2
}
