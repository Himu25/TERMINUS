package failfold

func OpF(priorFails uint32, units uint32) uint32 {
	return units
}
