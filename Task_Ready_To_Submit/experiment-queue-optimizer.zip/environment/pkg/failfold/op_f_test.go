package failfold

import "testing"

func TestOpFRetryHalf(t *testing.T) {
	if OpF(1, 10) != 5 {
		t.Fatal("expected half slot units on prior failures")
	}
}

func TestOpFMultipleFailuresStillHalf(t *testing.T) {
	if OpF(2, 12) != 6 {
		t.Fatal("expected half slot units regardless of failure count")
	}
}
