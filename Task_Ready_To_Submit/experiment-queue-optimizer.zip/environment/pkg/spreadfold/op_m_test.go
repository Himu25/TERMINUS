package spreadfold

import "testing"

func TestOpMSpread(t *testing.T) {
	tight := OpM(220, 40, "n1")
	wide := OpM(220, 180, "n1")
	if tight <= wide {
		t.Fatalf("expected wider prior spread to reduce calibrated value: tight=%d wide=%d", tight, wide)
	}
}
