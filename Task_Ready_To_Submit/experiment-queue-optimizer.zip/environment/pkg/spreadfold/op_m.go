package spreadfold

func OpM(mu uint32, sigma uint32, hint string) uint32 {
	bonus := hintBonus(hint)
	_ = sigma
	return mu + bonus
}

func hintBonus(hint string) uint32 {
	var sum uint32
	for _, b := range []byte(hint) {
		sum += uint32(b)
	}
	return sum % 47
}
