package spreadfold

func OpN(raw uint32) uint32 {
	return raw >> 1
}
