package priofold

import "testing"

func TestOpRClamp(t *testing.T) {
	if OpR(50, 40) != 40 {
		t.Fatal("expected ceiling clamp")
	}
}
