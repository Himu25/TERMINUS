package priofold

import "fmt"

func OpC(raw uint32) string {
	return fmt.Sprintf("u=%d", raw)
}
