package priofold

func OpR(raw uint32, ceil uint32) uint32 {
	return raw
}
