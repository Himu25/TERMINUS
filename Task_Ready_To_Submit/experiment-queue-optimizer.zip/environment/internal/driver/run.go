package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"

	"lab.local/eq_optimizer/internal/config"
	"lab.local/eq_optimizer/internal/engine"
)

type Report struct {
	SchemaVersion string   `json:"schema_version"`
	PoolID        string   `json:"pool_id"`
	PickedJobs    uint32   `json:"picked_jobs"`
	HeldJobs      uint32   `json:"held_jobs"`
	RetryWaste    uint32   `json:"retry_waste"`
	InfoGain      uint32   `json:"info_gain"`
	WaitTax       uint32   `json:"wait_tax"`
	ClaimClamps   uint32   `json:"claim_clamps"`
	PickedTeams   []string `json:"picked_teams"`
	PlanDigest    string   `json:"plan_digest"`
}

func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	w, err := config.LoadWorkload(dir)
	if err != nil {
		return Report{}, err
	}
	return buildReport(w)
}

func buildReport(w config.Workload) (Report, error) {
	out := engine.Plan(w)
	digest := sha256.Sum256([]byte(fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%d",
		w.PoolID,
		out.PickedJobs,
		out.HeldJobs,
		out.RetryWaste,
		out.InfoGain,
		out.WaitTax,
		out.ClaimClamps,
	)))
	return Report{
		SchemaVersion: "1",
		PoolID:        w.PoolID,
		PickedJobs:    out.PickedJobs,
		HeldJobs:      out.HeldJobs,
		RetryWaste:    out.RetryWaste,
		InfoGain:      out.InfoGain,
		WaitTax:       out.WaitTax,
		ClaimClamps:   out.ClaimClamps,
		PickedTeams:   out.PickedTeams,
		PlanDigest:    hex.EncodeToString(digest[:]),
	}, nil
}

func EmitReport(path string, rep Report) error {
	if err := os.MkdirAll("/app/output", 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, append(raw, '\n'), 0o644)
}
