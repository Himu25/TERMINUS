package rank

import (
	"testing"

	"lab.local/eq_optimizer/internal/config"
)

func TestEntryPtsUsesSpread(t *testing.T) {
	tight := EntryPts(config.Entry{PriorMu: 220, PriorSigma: 40, HintBlob: "n1"})
	wide := EntryPts(config.Entry{PriorMu: 220, PriorSigma: 180, HintBlob: "n1"})
	if tight <= wide {
		t.Fatalf("expected wider prior spread to reduce calibrated value: tight=%d wide=%d", tight, wide)
	}
}

func TestEntryPtsIncludesHint(t *testing.T) {
	withHint := EntryPts(config.Entry{PriorMu: 100, PriorSigma: 10, HintBlob: "ab"})
	blank := EntryPts(config.Entry{PriorMu: 100, PriorSigma: 10, HintBlob: ""})
	if withHint == blank {
		t.Fatal("expected hint payload to affect calibrated value")
	}
}
