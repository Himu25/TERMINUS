package rank

import "lab.local/eq_optimizer/pkg/failfold"

func EntryCost(failures uint32, units uint32) uint32 {
	return failfold.OpF(failures, units)
}
