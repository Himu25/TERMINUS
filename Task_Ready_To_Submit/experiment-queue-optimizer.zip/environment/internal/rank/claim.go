package rank

import "lab.local/eq_optimizer/pkg/priofold"

func EntryClaim(raw uint32, ceil uint32) uint32 {
	return priofold.OpR(raw, ceil)
}
