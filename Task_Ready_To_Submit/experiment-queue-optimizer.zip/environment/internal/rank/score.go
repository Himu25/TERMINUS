package rank

import (
	"lab.local/eq_optimizer/internal/config"
	"lab.local/eq_optimizer/pkg/spreadfold"
)

func EntryPts(e config.Entry) uint32 {
	return spreadfold.OpN(e.PriorMu)
}
