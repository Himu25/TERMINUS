package pack

import (
	"testing"

	"lab.local/eq_optimizer/internal/config"
)

func TestSeqItemsTieBreakAscending(t *testing.T) {
	items := []Item{
		{Entry: config.Entry{JobID: "job_z"}, Rank: 10},
		{Entry: config.Entry{JobID: "job_a"}, Rank: 10},
	}
	SeqItems(items)
	if items[0].Entry.JobID != "job_a" {
		t.Fatalf("expected lexicographically smaller job_id first on rank tie: got %s", items[0].Entry.JobID)
	}
}
