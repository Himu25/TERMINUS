package pack

import (
	"lab.local/eq_optimizer/internal/config"
	"lab.local/eq_optimizer/internal/rank"
	"lab.local/eq_optimizer/pkg/batchpkg"
)

type Item struct {
	Entry  config.Entry
	Score  uint32
	Claim  uint32
	Cost   uint32
	Clamped bool
	Rank   uint64
}

func BuildItems(w config.Workload) ([]Item, uint32) {
	items := make([]Item, 0, len(w.Entries))
	var clampCount uint32
	for _, e := range w.Entries {
		sc := rank.EntryPts(e)
		cl := rank.EntryClaim(e.Claim, w.ClaimCeil)
		if e.Claim > w.ClaimCeil {
			clampCount++
		}
		cost := rank.EntryCost(e.Failures, e.SlotUnits)
		rank := uint64(sc) * uint64(cl)
		if cost > 0 {
			rank /= uint64(cost)
		}
		items = append(items, Item{
			Entry:   e,
			Score:   sc,
			Claim:   cl,
			Cost:    cost,
			Clamped: e.Claim > w.ClaimCeil,
			Rank:    rank,
		})
	}
	return items, clampCount
}

func SeqItems(items []Item) {
	for i := 0; i < len(items); i++ {
		for j := i + 1; j < len(items); j++ {
			a, b := items[i], items[j]
			if b.Rank > a.Rank || (b.Rank == a.Rank && batchpkg.TieBreak(
				batchpkg.RankKey{JobID: a.Entry.JobID, Score: a.Rank},
				batchpkg.RankKey{JobID: b.Entry.JobID, Score: b.Rank},
			) < 0) {
				items[i], items[j] = items[j], items[i]
			}
		}
	}
}
