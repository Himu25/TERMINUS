package engine

import (
	"sort"

	"lab.local/eq_optimizer/internal/config"
	"lab.local/eq_optimizer/internal/pack"
	"lab.local/eq_optimizer/pkg/slotfold"
)

type Outcome struct {
	PickedJobs   uint32
	HeldJobs     uint32
	RetryWaste   uint32
	InfoGain     uint32
	WaitTax      uint32
	ClaimClamps  uint32
	PickedTeams  []string
}

func Plan(w config.Workload) Outcome {
	items, clampCount := pack.BuildItems(w)
	pack.SeqItems(items)

	teamSet := map[string]bool{}
	for _, e := range w.Entries {
		teamSet[e.TeamID] = true
	}

	var used uint32
	var picked uint32
	var held uint32
	var gain uint32
	var waste uint32
	teamSlots := map[string]uint32{}
	pickedTeamSet := map[string]bool{}

	for _, it := range items {
		if used+it.Cost > w.SlotCap {
			held++
			continue
		}
		used += it.Cost
		picked++
		gain += it.Score
		pickedTeamSet[it.Entry.TeamID] = true
		teamSlots[it.Entry.TeamID] += it.Cost
		if it.Entry.Failures > 0 && it.Entry.SlotUnits > it.Cost {
			waste += it.Entry.SlotUnits - it.Cost
		}
	}

	allTeams := map[string]uint32{}
	for t := range teamSet {
		allTeams[t] = teamSlots[t]
	}
	tax := slotfold.OpS(allTeams, used, w.TeamFloorPct, len(teamSet))

	pickedTeams := make([]string, 0, len(pickedTeamSet))
	for t := range pickedTeamSet {
		pickedTeams = append(pickedTeams, t)
	}
	sort.Strings(pickedTeams)

	return Outcome{
		PickedJobs:  picked,
		HeldJobs:    held,
		RetryWaste:  waste,
		InfoGain:    gain,
		WaitTax:     tax,
		ClaimClamps: clampCount,
		PickedTeams: pickedTeams,
	}
}
