package config

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
)

type Entry struct {
	JobID       string `json:"job_id"`
	TeamID      string `json:"team_id"`
	Claim       uint32 `json:"claim"`
	PriorMu     uint32 `json:"prior_mu"`
	PriorSigma  uint32 `json:"prior_sigma"`
	Failures    uint32 `json:"failures"`
	SlotUnits   uint32 `json:"slot_units"`
	HintBlob    string `json:"hint_blob"`
}

type Workload struct {
	PoolID       string  `json:"pool_id"`
	SlotCap      uint32  `json:"slot_cap"`
	TeamFloorPct uint32  `json:"team_floor_pct"`
	ClaimCeil    uint32  `json:"claim_ceil"`
	Entries      []Entry `json:"entries"`
}

func ActivePaths(appRoot string) (string, error) {
	dir := filepath.Join(appRoot, "data", "active")
	st, err := os.Stat(dir)
	if err != nil {
		return "", err
	}
	if !st.IsDir() {
		return "", fmt.Errorf("active path is not a directory")
	}
	return dir, nil
}

func LoadWorkload(dir string) (Workload, error) {
	raw, err := os.ReadFile(filepath.Join(dir, "workload_plan.json"))
	if err != nil {
		return Workload{}, err
	}
	var w Workload
	if err := json.Unmarshal(raw, &w); err != nil {
		return Workload{}, err
	}
	return w, nil
}
