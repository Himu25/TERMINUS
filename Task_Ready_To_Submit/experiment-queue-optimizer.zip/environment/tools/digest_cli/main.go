package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
)

func main() {
	if len(os.Args) != 8 {
		fmt.Fprintln(os.Stderr, "usage: digest_cli pool picked held waste gain tax clamps")
		os.Exit(2)
	}
	payload := fmt.Sprintf(
		"%s|%s|%s|%s|%s|%s|%s",
		os.Args[1], os.Args[2], os.Args[3], os.Args[4], os.Args[5], os.Args[6], os.Args[7],
	)
	sum := sha256.Sum256([]byte(payload))
	fmt.Println(hex.EncodeToString(sum[:]))
}
