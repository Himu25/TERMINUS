# eq optimizer workspace

Offline dispatch allocator for shared research compute windows. Active bundle lives under data/active.
