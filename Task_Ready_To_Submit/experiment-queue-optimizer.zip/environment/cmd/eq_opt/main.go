// Plan JSON for /app/output/schedule_plan.json:
//
// schema_version — string, always "1"
// pool_id — string, echoes active workload plan name
// picked_jobs — uint32, entries selected within the slot cap
// held_jobs — uint32, entries deferred for lack of capacity
// retry_waste — uint32, slot units over-charged on selected entries with prior failure counts
// info_gain — uint32, sum of spreadfold-calibrated scores for selected entries
// wait_tax — uint32, aggregate shortfall when a team's selected share sits below the plan floor
// claim_clamps — uint32, entries whose declared urgency exceeded the plan ceiling before ranking
// picked_teams — string array of team_id values for selected entries, sorted ascending
// plan_digest — lowercase hex SHA-256 of pool_id|picked_jobs|held_jobs|retry_waste|info_gain|wait_tax|claim_clamps
//
// Root object contains only these keys.
package main

import (
	"log"
	"os"

	"lab.local/eq_optimizer/internal/driver"
)

func main() {
	if os.Getenv("TB_EQ_FIXTURE") != "1" {
		log.Fatal("TB_EQ_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/schedule_plan.json", rep); err != nil {
		log.Fatal(err)
	}
}
