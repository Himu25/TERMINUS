entry records are inlined in workload_plan.json for the active bundle
