Regression replay bundles for local stem checks. Copy a stem into /app/data/active before running /app/bin/eq_opt with TB_EQ_FIXTURE=1.
