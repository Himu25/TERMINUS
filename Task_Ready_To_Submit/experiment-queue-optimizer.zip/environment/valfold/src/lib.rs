#[no_mangle]
pub extern "C" fn vf_gain_u32(mu: u32, sigma: u32, ptr: *const u8, len: usize) -> u32 {
    let mut hint: u32 = 0;
    if !ptr.is_null() && len > 0 {
        let slice = unsafe { std::slice::from_raw_parts(ptr, len) };
        for &b in slice {
            hint = hint.wrapping_add(b as u32);
        }
        hint %= 47;
    }
    let denom = 1000u64 + sigma as u64;
    if denom == 0 {
        return mu.wrapping_add(hint);
    }
    let scaled = (mu as u64).saturating_mul(1000) / denom;
    scaled as u32 + hint
}
