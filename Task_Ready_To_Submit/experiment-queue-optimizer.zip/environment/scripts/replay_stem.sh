#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "usage: replay_stem.sh <stem_name>" >&2
  exit 2
fi

stem="$1"
src="/app/data/regression/${stem}"
if [[ ! -d "${src}" ]]; then
  echo "missing stem: ${src}" >&2
  exit 1
fi

rm -rf /app/data/active
cp -a "${src}" /app/data/active
TB_EQ_FIXTURE=1 /app/bin/eq_opt
