module lab.local/eq_optimizer

go 1.22
