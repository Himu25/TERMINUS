#!/bin/bash
set -euo pipefail

export PATH="/usr/local/go/bin:${PATH}"
export CGO_ENABLED=0

mkdir -p /app/bin
cd /app
GOFLAGS=-mod=mod go build -trimpath -buildvcs=false -o /app/bin/eq_opt ./cmd/eq_opt
