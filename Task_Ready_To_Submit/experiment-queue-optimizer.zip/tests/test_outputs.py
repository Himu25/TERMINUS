"""Verifier for experiment queue optimizer schedule plans."""

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = Path("/tests") / "fixtures"
OUT = APP / "output" / "schedule_plan.json"
BIN = "/app/bin/eq_opt"
DIGEST_CLI = "/app/tools/digest_cli"
GO_BIN = "go"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "0",
        "PATH": "/usr/local/go/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(
        [
            GO_BIN,
            "build",
            "-trimpath",
            "-buildvcs=false",
            "-o",
            BIN,
            "./cmd/eq_opt",
        ],
        cwd="/app",
        env=env,
        check=True,
    )


def _hint_bonus(hint: str) -> int:
    return sum(hint.encode()) % 47


def _score_entry(mu: int, sigma: int, hint: str) -> int:
    return (mu * 1000) // (1000 + sigma) + _hint_bonus(hint)


def _op_r(raw: int, ceil: int) -> int:
    return min(raw, ceil)


def _op_f(failures: int, units: int) -> int:
    if failures > 0:
        return (units + 1) // 2
    return units


def _op_s(team_slots: dict[str, int], used: int, floor_pct: int, team_count: int) -> int:
    if used == 0 or team_count == 0:
        return 0
    min_share = (floor_pct * used) // (100 * team_count)
    tax = 0
    for slots in team_slots.values():
        if slots < min_share:
            tax += min_share - slots
    return tax


def _digest_hex(
    pool_id: str,
    picked: int,
    held: int,
    waste: int,
    gain: int,
    tax: int,
    clamps: int,
) -> str:
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            DIGEST_CLI,
            pool_id,
            str(picked),
            str(held),
            str(waste),
            str(gain),
            str(tax),
            str(clamps),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


COUNTER_KEYS = (
    "picked_jobs",
    "held_jobs",
    "retry_waste",
    "info_gain",
    "wait_tax",
    "claim_clamps",
)


def _plan_report(
    plan: dict,
    *,
    spread: bool,
    retry: bool,
    floor: bool,
    claim: bool,
) -> dict:
    entries = plan["entries"]
    team_set = {e["team_id"] for e in entries}
    clamp_count = sum(1 for e in entries if e["claim"] > plan["claim_ceil"])

    items: list[dict] = []
    for e in entries:
        if spread:
            score = _score_entry(e["prior_mu"], e["prior_sigma"], e["hint_blob"])
        else:
            score = e["prior_mu"] + _hint_bonus(e["hint_blob"])
        if claim:
            claim_val = _op_r(e["claim"], plan["claim_ceil"])
        else:
            claim_val = e["claim"]
        if retry:
            cost = _op_f(e["failures"], e["slot_units"])
        else:
            cost = e["slot_units"]
        rank = (score * claim_val) // cost if cost else 0
        items.append({"entry": e, "pts": score, "claim": claim_val, "cost": cost, "rank": rank})

    items.sort(key=lambda it: (-it["rank"], it["entry"]["job_id"]))

    used = 0
    picked = 0
    held = 0
    gain = 0
    waste = 0
    team_slots: dict[str, int] = {}
    picked_teams: set[str] = set()

    for it in items:
        e = it["entry"]
        if used + it["cost"] > plan["slot_cap"]:
            held += 1
            continue
        used += it["cost"]
        picked += 1
        gain += it["pts"]
        picked_teams.add(e["team_id"])
        team_slots[e["team_id"]] = team_slots.get(e["team_id"], 0) + it["cost"]
        if e["failures"] > 0 and e["slot_units"] > it["cost"]:
            waste += e["slot_units"] - it["cost"]

    all_teams = {t: team_slots.get(t, 0) for t in team_set}
    if floor:
        tax = _op_s(all_teams, used, plan["team_floor_pct"], len(team_set))
    else:
        tax = 0

    digest = _digest_hex(plan["pool_id"], picked, held, waste, gain, tax, clamp_count)
    return {
        "schema_version": "1",
        "pool_id": plan["pool_id"],
        "picked_jobs": picked,
        "held_jobs": held,
        "retry_waste": waste,
        "info_gain": gain,
        "wait_tax": tax,
        "claim_clamps": clamp_count,
        "plan_digest": digest,
        "picked_teams": sorted(picked_teams),
    }


def _expected(plan: dict) -> dict:
    return _plan_report(plan, spread=True, retry=True, floor=True, claim=True)


def _broken_expected(plan: dict) -> dict:
    return _plan_report(plan, spread=False, retry=False, floor=False, claim=False)


def _assert_counters_match(got: dict, expected: dict) -> None:
    for key in COUNTER_KEYS:
        assert got[key] == expected[key]


def _digest_matches_report(report: dict) -> bool:
    digest = _digest_hex(
        report["pool_id"],
        report["picked_jobs"],
        report["held_jobs"],
        report["retry_waste"],
        report["info_gain"],
        report["wait_tax"],
        report["claim_clamps"],
    )
    return report["plan_digest"] == digest


def _load_plan(pack_dir: Path) -> dict:
    return json.loads((pack_dir / "workload_plan.json").read_text())


def _run_driver() -> dict:
    env = {**os.environ, "TB_EQ_FIXTURE": "1"}
    subprocess.run([BIN], cwd="/app", env=env, check=True)
    return json.loads(OUT.read_text())


def _swap_active(pack_name: str) -> None:
    src = FIXTURES / pack_name
    backup = APP / "data" / "_active_backup"
    if backup.exists():
        shutil.rmtree(backup)
    shutil.move(str(ACTIVE), str(backup))
    shutil.copytree(src, ACTIVE)


def _restore_active() -> None:
    backup = APP / "data" / "_active_backup"
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    if backup.exists():
        shutil.move(str(backup), str(ACTIVE))


class TestSchedulePlan:
    def test_active_plan_matches_contract(self) -> None:
        """Active workload bundle emits expected schedule counters."""
        plan = _load_plan(ACTIVE)
        expected = _expected(plan)
        got = _run_driver()
        assert got["schema_version"] == expected["schema_version"]
        assert got["pool_id"] == expected["pool_id"]
        _assert_counters_match(got, expected)
        assert _digest_matches_report(got)

    def test_plan_digest_is_deterministic(self) -> None:
        """Two consecutive replays produce identical plan_digest."""
        first = _run_driver()
        second = _run_driver()
        assert first["plan_digest"] == second["plan_digest"]
        assert first == second

    def test_info_gain_uses_spread_calibration(self) -> None:
        """info_gain reflects prior spread calibration on high-sigma entries."""
        plan = _load_plan(ACTIVE)
        expected = _expected(plan)
        broken = _broken_expected(plan)
        got = _run_driver()
        assert got["info_gain"] > 0
        assert got["info_gain"] == expected["info_gain"]
        assert got["info_gain"] != broken["info_gain"]

    def test_retry_waste_halves_failed_slots(self) -> None:
        """retry_waste counts slot units over-charged on prior failures."""
        plan = _load_plan(ACTIVE)
        expected = _expected(plan)
        got = _run_driver()
        assert got["retry_waste"] == expected["retry_waste"]
        multi_fail = next(e for e in plan["entries"] if e["failures"] > 1)
        charged = _op_f(multi_fail["failures"], multi_fail["slot_units"])
        assert charged == (multi_fail["slot_units"] + 1) // 2

    def test_every_team_represented_in_picks(self) -> None:
        """Picked entries include every team present in the workload."""
        plan = _load_plan(ACTIVE)
        all_teams = {e["team_id"] for e in plan["entries"]}
        expected = _expected(plan)
        got = _run_driver()
        _assert_counters_match(got, expected)
        assert set(got["picked_teams"]) == all_teams

    def test_wait_tax_when_team_starved(self) -> None:
        """wait_tax rises when a team share sits below the plan floor."""
        plan = _load_plan(ACTIVE)
        expected = _expected(plan)
        got = _run_driver()
        assert got["wait_tax"] == expected["wait_tax"]

    def test_claim_clamps_inflated_urgency(self) -> None:
        """claim_clamps counts entries whose urgency exceeded the ceiling."""
        plan = _load_plan(ACTIVE)
        expected = _expected(plan)
        got = _run_driver()
        assert got["claim_clamps"] == expected["claim_clamps"]
        assert got["claim_clamps"] >= 1

    def test_go_unit_tests_pass(self) -> None:
        """Go unit tests under /app pass after repair."""
        env = {
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "0",
            "PATH": "/usr/local/go/bin:" + os.environ.get("PATH", ""),
        }
        subprocess.run([GO_BIN, "test", "./..."], cwd="/app", env=env, check=True)

    def test_case_narrow_replays_clean(self) -> None:
        """case_narrow regression stem replays to an equivalent plan."""
        _swap_active("case_narrow")
        try:
            plan = _load_plan(ACTIVE)
            expected = _expected(plan)
            got = _run_driver()
            assert got["schema_version"] == expected["schema_version"]
            assert got["pool_id"] == expected["pool_id"]
            _assert_counters_match(got, expected)
            all_teams = {e["team_id"] for e in plan["entries"]}
            assert set(got["picked_teams"]) == all_teams
            assert _digest_matches_report(got)
        finally:
            _restore_active()

    def test_case_broad_replays_clean(self) -> None:
        """case_broad regression stem replays to an equivalent plan."""
        _swap_active("case_broad")
        try:
            plan = _load_plan(ACTIVE)
            expected = _expected(plan)
            got = _run_driver()
            assert got["schema_version"] == expected["schema_version"]
            assert got["pool_id"] == expected["pool_id"]
            _assert_counters_match(got, expected)
            all_teams = {e["team_id"] for e in plan["entries"]}
            assert set(got["picked_teams"]) == all_teams
            assert _digest_matches_report(got)
        finally:
            _restore_active()

    def test_held_jobs_fill_remainder(self) -> None:
        """held_jobs counts entries deferred once the slot cap is exhausted."""
        plan = _load_plan(ACTIVE)
        expected = _expected(plan)
        got = _run_driver()
        assert got["held_jobs"] == expected["held_jobs"]
        assert got["picked_jobs"] + got["held_jobs"] == len(plan["entries"])

    def test_schema_version_and_pool_id(self) -> None:
        """Report carries schema_version and active pool_id from the plan."""
        plan = _load_plan(ACTIVE)
        expected = _expected(plan)
        got = _run_driver()
        assert got["pool_id"] == plan["pool_id"]
        assert got["schema_version"] == expected["schema_version"]
