#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/pkg/priofold/op_r.go <<'EOF'
package priofold

func OpR(raw uint32, ceil uint32) uint32 {
	if ceil == 0 {
		return raw
	}
	if raw <= ceil {
		return raw
	}
	return ceil
}
EOF

cat > /app/pkg/failfold/op_f.go <<'EOF'
package failfold

func OpF(priorFails uint32, units uint32) uint32 {
	if units == 0 {
		return 0
	}
	if priorFails == 0 {
		return units
	}
	adjusted := (units + 1) / 2
	if adjusted == 0 {
		return 1
	}
	return adjusted
}
EOF

cat > /app/pkg/slotfold/op_s.go <<'EOF'
package slotfold

func OpS(teamSlots map[string]uint32, pickedTotal uint32, floorPct uint32, teamCount int) uint32 {
	if pickedTotal == 0 || teamCount == 0 {
		return 0
	}
	if floorPct == 0 {
		return 0
	}
	minShare := (floorPct * pickedTotal) / (100 * uint32(teamCount))
	if minShare == 0 {
		return 0
	}
	var tax uint32
	for _, slots := range teamSlots {
		if slots >= minShare {
			continue
		}
		tax += minShare - slots
	}
	return tax
}
EOF

cat > /app/pkg/spreadfold/op_m.go <<'EOF'
package spreadfold

func OpM(mu uint32, sigma uint32, hint string) uint32 {
	bonus := hintBonus(hint)
	denom := uint64(1000) + uint64(sigma)
	if denom == 0 {
		return mu + bonus
	}
	scaled := uint64(mu) * 1000 / denom
	return uint32(scaled) + bonus
}

func hintBonus(hint string) uint32 {
	var sum uint32
	for _, b := range []byte(hint) {
		sum += uint32(b)
	}
	return sum % 47
}
EOF

cat > /app/internal/rank/score.go <<'EOF'
package rank

import (
	"lab.local/eq_optimizer/internal/config"
	"lab.local/eq_optimizer/pkg/spreadfold"
)

func EntryPts(e config.Entry) uint32 {
	return spreadfold.OpM(e.PriorMu, e.PriorSigma, e.HintBlob)
}
EOF

python3 - <<'PY'
from pathlib import Path
path = Path("/app/internal/pack/greedy.go")
text = path.read_text()
old = """		if b.Rank > a.Rank || (b.Rank == a.Rank && batchpkg.TieBreak(
				batchpkg.RankKey{JobID: a.Entry.JobID, Score: a.Rank},
				batchpkg.RankKey{JobID: b.Entry.JobID, Score: b.Rank},
			) < 0) {"""
new = """		if b.Rank > a.Rank || (b.Rank == a.Rank && batchpkg.TieBreak(
				batchpkg.RankKey{JobID: b.Entry.JobID, Score: b.Rank},
				batchpkg.RankKey{JobID: a.Entry.JobID, Score: a.Rank},
			) < 0) {"""
if old not in text:
    raise SystemExit("greedy.go tie-break pattern missing")
path.write_text(text.replace(old, new, 1))
PY

bash /app/scripts/build.sh

rm -f /app/output/schedule_plan.json
mkdir -p /app/output
TB_EQ_FIXTURE=1 /app/bin/eq_opt
test -s /app/output/schedule_plan.json

GOFLAGS=-mod=mod go test ./...
