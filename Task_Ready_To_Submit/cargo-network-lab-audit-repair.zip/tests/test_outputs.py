"""Verifier for cargo network lab audit repair report."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = APP / "data" / "replay"
OUT = APP / "output" / "netlab_audit_report.json"
ROLE_TABLE = APP / "config" / "role_table.json"
HOSTS_DIR = APP / "config" / "hosts"
STORAGE_NET = APP / "net/systemd/30-storage.network"
TRUNK_NET = APP / "net/systemd/20-seg0.network"
_HOST_FIELD = re.compile(r"^(?P<key>\w+)\s*=\s*(?P<val>.+)$")


def _parse_host_manifest(path: Path) -> dict[str, str]:
    data: dict[str, str] = {}
    for line in path.read_text().splitlines():
        match = _HOST_FIELD.match(line.strip())
        if match:
            data[match.group("key")] = match.group("val").strip().strip('"')
    return data


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        "CARGO_TARGET_DIR": "/tmp/cargo-target",
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _role_table() -> dict:
    return json.loads(ROLE_TABLE.read_text())


def _mirrors(table: dict) -> list[dict]:
    return table["mirrors"]


def _home_vlan(uid: str) -> int:
    for path in HOSTS_DIR.glob("*.toml"):
        manifest = _parse_host_manifest(path)
        if manifest.get("uid") == uid:
            return int(manifest["home_vlan"])
    return 0


def _target_vlan(topo: dict, target: str) -> int:
    for host in topo.get("hosts", []):
        if host["name"] == target:
            return int(host["vlan"])
    return 0


def _target_zone(topo: dict, target: str) -> str:
    for host in topo.get("hosts", []):
        if host["name"] == target:
            return str(host["zone"])
    return ""


def _op_k(hop_count: int, tier_ceiling: int) -> bool:
    return hop_count <= tier_ceiling


def _op_u(uid: str, manifest_tier: int, table: dict) -> int:
    tiers = table["uid_tiers"]
    if uid in tiers:
        return int(tiers[uid])
    return manifest_tier


def _op_r(hop_count: int, home_vlan: int, target_vlan: int) -> int:
    if home_vlan != target_vlan:
        return hop_count + 1
    return hop_count


def _op_w(role_tier: int, target_zone: str) -> bool:
    if target_zone == "storage" and role_tier > 1:
        return False
    return True


def _op_m(tier: str, mgmt_vlan: int, mirrors: list[dict]) -> str:
    eligible = [m for m in mirrors if m["tier"] == tier and m["vlan"] == mgmt_vlan]
    if not eligible:
        return ""
    eligible.sort(key=lambda m: m["priority"])
    return eligible[0]["mirror_id"]


def _op_s(port: int, zone: str, exposed: bool) -> bool:
    if zone == "storage" and port == 22:
        return False
    return exposed


def _manifest_tier(uid: str) -> int:
    for path in HOSTS_DIR.glob("*.toml"):
        manifest = _parse_host_manifest(path)
        if manifest.get("uid") == uid:
            return int(manifest["role_tier"])
    return 0


def _load_topology(pack_dir: Path) -> dict:
    return json.loads((pack_dir / "topology.json").read_text())


def _load_scenario(pack_dir: Path) -> dict:
    return json.loads((pack_dir / "scenario.json").read_text())


def _role_tier(uid: str, table: dict) -> int:
    return int(table["uid_tiers"][uid])


def _tier_ceiling(role_tier: int) -> int:
    return {1: 4, 2: 2}.get(role_tier, 0)


def _graph_storage_vlan(topo: dict) -> int:
    for subnet in topo.get("subnets", []):
        if subnet.get("zone") == "storage":
            return int(subnet["vlan_id"])
    return 0


def _dropin_vlan(path: Path) -> int:
    for line in path.read_text().splitlines():
        trimmed = line.strip()
        if trimmed.startswith("VLAN="):
            return int(trimmed.split("=", 1)[1])
    return 0


def _storage_vlan_ok(topo: dict) -> bool:
    graph_vlan = _graph_storage_vlan(topo)
    return _dropin_vlan(STORAGE_NET) == graph_vlan


def _trunk_native_ok(table: dict) -> bool:
    return _dropin_vlan(TRUNK_NET) == int(table["native_segment_vlan"])


def _digest_hex(parts: list[str | int | bool]) -> str:
    payload = "|".join(str(x) for x in parts)
    got = subprocess.run(
        ["sha256sum"],
        input=payload,
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.split()[0]


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = FIXTURES / pack_name
    scenario = _load_scenario(pack_dir)
    topo = _load_topology(pack_dir)
    table = _role_table()
    tier_ceilings = {int(k): v for k, v in table["tier_ceilings"].items()}
    mgmt_vlan = table["mgmt_vlan"]
    mirrors = _mirrors(table)

    subnet_rows = len(topo["hosts"])
    ssh_pass = 0
    ssh_fail = 0
    uid_tier_ok = 0
    storage_tier_violations = 0
    ssh_paths = topo.get("ssh_paths", [])
    for path in ssh_paths:
        uid = path["uid"]
        manifest_tier = _manifest_tier(uid)
        resolved = _op_u(uid, manifest_tier, table)
        if resolved == _role_tier(uid, table):
            uid_tier_ok += 1
        home = _home_vlan(uid)
        target = path["target"]
        target_vlan = _target_vlan(topo, target)
        target_zone = _target_zone(topo, target)
        effective = _op_r(int(path["hops"]), home, target_vlan)
        ceiling = tier_ceilings[resolved]
        zone_ok = _op_w(resolved, target_zone)
        granted = zone_ok and _op_k(effective, ceiling)
        if granted and target_zone == "storage" and resolved > 1:
            storage_tier_violations += 1
        if granted:
            ssh_pass += 1
        else:
            ssh_fail += 1

    mirror_ok = 0
    for tier in ("prod", "staging"):
        chosen = _op_m(tier, mgmt_vlan[tier], mirrors)
        for mirror in mirrors:
            if mirror["tier"] == tier and mirror["mirror_id"] == chosen:
                if mirror["vlan"] == mgmt_vlan[tier]:
                    mirror_ok += 1

    service_leaks = 0
    for svc in topo.get("services", []):
        if _op_s(svc["port"], svc["zone"], svc["exposed"]):
            if svc["zone"] == "storage" and svc["port"] == 22:
                service_leaks += 1

    trunk_ok = _trunk_native_ok(table)
    storage_ok = _storage_vlan_ok(topo)
    path_count = len(ssh_paths)
    assertion_pass = (
        (1 if ssh_fail == 0 else 0)
        + (1 if mirror_ok >= 2 else 0)
        + (1 if service_leaks == 0 else 0)
        + (1 if trunk_ok else 0)
        + (1 if storage_ok else 0)
        + (1 if uid_tier_ok == path_count and path_count > 0 else 0)
        + (1 if storage_tier_violations == 0 else 0)
    )
    digest_hex = _digest_hex(
        [
            scenario["run_id"],
            subnet_rows,
            ssh_pass,
            ssh_fail,
            mirror_ok,
            service_leaks,
            uid_tier_ok,
            1 if storage_ok else 0,
            storage_tier_violations,
            assertion_pass,
        ]
    )
    return {
        "schema_version": "1",
        "run_id": scenario["run_id"],
        "subject_uid": scenario["subject_uid"],
        "subnet_rows": subnet_rows,
        "ssh_pass_count": ssh_pass,
        "ssh_fail_count": ssh_fail,
        "mirror_primary_ok": mirror_ok,
        "service_leak_count": service_leaks,
        "trunk_native_ok": trunk_ok,
        "storage_vlan_ok": storage_ok,
        "uid_tier_ok_count": uid_tier_ok,
        "storage_tier_violation_count": storage_tier_violations,
        "assertion_pass": assertion_pass,
        "assertion_total": 7,
        "digest_hex": digest_hex,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {
        **os.environ,
        "TB_NETLAB_FIXTURE": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["/app/bin/netlab_audit_run"], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_alpha_report_matches_replay() -> None:
    """Alpha pack should replay with aggregated subnets and clean assertions."""
    _swap("net_alpha")
    exp = _expected_from_fixture("net_alpha")
    got = _run_tool()
    assert got == exp


def test_alpha_subnet_prefix_collapsed() -> None:
    """Alpha should export three subnet rows with graph prefix lengths applied."""
    _swap("net_alpha")
    exp = _expected_from_fixture("net_alpha")
    got = _run_tool()
    assert got["subnet_rows"] == exp["subnet_rows"]
    assert got["ssh_pass_count"] == exp["ssh_pass_count"]
    assert got["ssh_fail_count"] == exp["ssh_fail_count"]


def test_beta_ssh_hop_budget_enforced() -> None:
    """Beta replay should deny SSH grants that exceed the tier hop budget."""
    _swap("net_beta")
    exp = _expected_from_fixture("net_beta")
    got = _run_tool()
    assert got["ssh_fail_count"] == exp["ssh_fail_count"]
    assert got["ssh_pass_count"] == exp["ssh_pass_count"]


def test_gamma_storage_port_not_exposed() -> None:
    """Gamma should report zero outward storage SSH leaks."""
    _swap("net_gamma")
    exp = _expected_from_fixture("net_gamma")
    got = _run_tool()
    assert got["service_leak_count"] == exp["service_leak_count"]


def test_gamma_mirror_primary_on_mgmt_vlan() -> None:
    """Gamma replay should select mirror primaries on each tier management VLAN."""
    _swap("net_gamma")
    exp = _expected_from_fixture("net_gamma")
    got = _run_tool()
    assert got["mirror_primary_ok"] == exp["mirror_primary_ok"]


def test_delta_tier_one_ssh_within_budget() -> None:
    """Delta replay should grant tier-1 operator SSH within the hop budget."""
    _swap("net_delta")
    exp = _expected_from_fixture("net_delta")
    got = _run_tool()
    assert got["ssh_pass_count"] == exp["ssh_pass_count"]
    assert got["ssh_fail_count"] == exp["ssh_fail_count"]


def test_delta_trunk_native_vlan() -> None:
    """Delta replay should set trunk_native_ok when the lab trunk drop-in matches policy."""
    _swap("net_delta")
    exp = _expected_from_fixture("net_delta")
    got = _run_tool()
    assert got["trunk_native_ok"] == exp["trunk_native_ok"]


def test_epsilon_guest_cross_segment_denied() -> None:
    """Epsilon replay should deny guest cross-segment SSH after tier and hop evaluation."""
    _swap("net_epsilon")
    exp = _expected_from_fixture("net_epsilon")
    got = _run_tool()
    assert got["ssh_fail_count"] == exp["ssh_fail_count"]
    assert got["ssh_pass_count"] == exp["ssh_pass_count"]
    assert got["uid_tier_ok_count"] == exp["uid_tier_ok_count"]


def test_epsilon_uid_tier_resolution() -> None:
    """Epsilon replay should resolve uid tiers consistently across all SSH paths."""
    _swap("net_epsilon")
    exp = _expected_from_fixture("net_epsilon")
    got = _run_tool()
    assert got["uid_tier_ok_count"] == exp["uid_tier_ok_count"]
    assert exp["uid_tier_ok_count"] == 2


def test_epsilon_storage_tier_cap() -> None:
    """Epsilon replay should report zero storage-zone tier violations."""
    _swap("net_epsilon")
    exp = _expected_from_fixture("net_epsilon")
    got = _run_tool()
    assert got["storage_tier_violation_count"] == exp["storage_tier_violation_count"]
    assert exp["storage_tier_violation_count"] == 0


def test_zeta_storage_segment_vlan() -> None:
    """Zeta replay should set storage_vlan_ok when the storage drop-in matches the graph."""
    _swap("net_zeta")
    exp = _expected_from_fixture("net_zeta")
    got = _run_tool()
    assert got["storage_vlan_ok"] == exp["storage_vlan_ok"]
    assert exp["storage_vlan_ok"] is True


def test_zeta_ops_ssh_same_segment() -> None:
    """Zeta replay should grant same-segment operator SSH within the tier budget."""
    _swap("net_zeta")
    exp = _expected_from_fixture("net_zeta")
    got = _run_tool()
    assert got["ssh_pass_count"] == exp["ssh_pass_count"]
    assert got["ssh_fail_count"] == exp["ssh_fail_count"]


def test_theta_tier_one_storage_ssh() -> None:
    """Theta replay should grant operator storage SSH when within the tier budget."""
    _swap("net_theta")
    exp = _expected_from_fixture("net_theta")
    got = _run_tool()
    assert got["ssh_pass_count"] == exp["ssh_pass_count"]
    assert got["ssh_fail_count"] == exp["ssh_fail_count"]
    assert exp["ssh_pass_count"] == 1


def test_theta_cross_segment_hop_penalty() -> None:
    """Theta replay should apply cross-segment hop adjustment before SSH grant evaluation."""
    _swap("net_theta")
    exp = _expected_from_fixture("net_theta")
    got = _run_tool()
    assert got["storage_tier_violation_count"] == 0
    assert got == exp


def test_schema_and_digest_present() -> None:
    """Report must validate schema fields and carry digest_hex."""
    _swap("net_alpha")
    exp = _expected_from_fixture("net_alpha")
    got = _run_tool()
    assert got["digest_hex"] == exp["digest_hex"]
    assert len(got["digest_hex"]) == 64
    assert got["assertion_total"] == 7


def test_assertion_total_seven_gates() -> None:
    """All seven handbook assertion gates must be counted in assertion_total."""
    _swap("net_gamma")
    got = _run_tool()
    assert got["assertion_total"] == 7
