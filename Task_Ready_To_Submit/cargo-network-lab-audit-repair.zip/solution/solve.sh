#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/bin:${PATH}"
cd /app

cat > /app/z7x/src/lane/op_v.rs <<'EOF'
/// Collapse a host address to the graph-declared subnet prefix length.
pub fn op_v(host_octets: [u8; 4], graph_prefix: u8) -> String {
    if graph_prefix >= 32 {
        return format!(
            "{}.{}.{}.{}/32",
            host_octets[0], host_octets[1], host_octets[2], host_octets[3]
        );
    }
    let shift = 32 - graph_prefix;
    let mask: u32 = if graph_prefix == 0 {
        0
    } else {
        !((1u32 << shift) - 1)
    };
    let addr = u32::from_be_bytes(host_octets);
    let net = addr & mask;
    let b = net.to_be_bytes();
    format!(
        "{}.{}.{}.{}/{}",
        b[0], b[1], b[2], b[3], graph_prefix
    )
}
EOF

cat > /app/z9x/src/gates/op_k.rs <<'EOF'
pub fn op_k(hop_count: u32, tier_ceiling: u32) -> bool {
    hop_count <= tier_ceiling
}
EOF

cat > /app/z9x/src/gates/op_g.rs <<'EOF'
/// Map tier label to management-plane VLAN from role_table values.
pub fn op_g(prod_val: u16, staging_val: u16, tier: &str) -> u16 {
    match tier {
        "prod" => prod_val,
        "staging" => staging_val,
        _ => 0,
    }
}
EOF

cat > /app/z9x/src/gates/op_p.rs <<'EOF'
use std::cmp::Ordering;

/// Tie-break equal-priority mirror rows for primary selection.
pub fn op_p(left_id: &str, right_id: &str) -> Ordering {
    left_id.cmp(right_id)
}
EOF

cat > /app/z9x/src/gates/op_m.rs <<'EOF'
#[path = "op_p.rs"]
mod op_p;

use op_p::op_p;

pub struct RowCandidate {
    pub mirror_id: String,
    pub tier: String,
    pub vlan_required: u16,
    pub priority: u32,
}

pub fn op_m(rows: &[RowCandidate], tier: &str, mgmt_vlan: u16) -> String {
    let mut eligible: Vec<&RowCandidate> = rows
        .iter()
        .filter(|r| r.tier == tier && r.vlan_required == mgmt_vlan)
        .collect();
    if eligible.is_empty() {
        return String::new();
    }
    eligible.sort_by(|a, b| match a.priority.cmp(&b.priority) {
        std::cmp::Ordering::Equal => op_p(&a.mirror_id, &b.mirror_id),
        other => other,
    });
    eligible[0].mirror_id.clone()
}
EOF

cat > /app/z9x/src/gates/op_n.rs <<'EOF'
/// Outward exposure for storage-zone services before SSH leak counting.
pub fn op_n(port: u16, zone: &str, exposed_flag: bool) -> bool {
    if zone == "storage" && port == 514 {
        return false;
    }
    exposed_flag
}
EOF

cat > /app/z9x/src/gates/op_s.rs <<'EOF'
pub fn op_s(port: u16, zone: &str, exposed_flag: bool) -> bool {
    if zone == "storage" && port == 22 {
        return false;
    }
    exposed_flag
}
EOF

cat > /app/z9x/src/gates/op_r.rs <<'EOF'
/// Adjust hop count when source and target VLANs differ.
pub fn op_r(hop_count: u32, home_vlan: u16, target_vlan: u16) -> u32 {
    if home_vlan != target_vlan {
        return hop_count + 1;
    }
    hop_count
}
EOF

cat > /app/z9x/src/gates/op_u.rs <<'EOF'
/// Resolve effective role tier for SSH budget evaluation.
pub fn op_u(_uid: &str, manifest_tier: u8, table_tier: u8) -> u8 {
    let _ = manifest_tier;
    table_tier
}
EOF

cat > /app/z9x/src/gates/op_w.rs <<'EOF'
/// Zone-tier SSH eligibility before hop budget evaluation.
pub fn op_w(role_tier: u8, target_zone: &str) -> bool {
    !(target_zone == "storage" && role_tier > 1)
}
EOF

cat > /app/net/systemd/20-seg0.network <<'EOF'
[Match]
Name=lab-trunk

[Network]
VLAN=40
Address=10.40.12.1/24
EOF

cat > /app/net/systemd/30-storage.network <<'EOF'
[Match]
Name=storage0

[Network]
Address=10.30.5.1/24
VLAN=30
EOF

bash /app/scripts/build.sh
