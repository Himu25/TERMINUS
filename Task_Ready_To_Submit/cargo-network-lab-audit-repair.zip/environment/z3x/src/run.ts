import { readFileSync } from "node:fs";

const outPath = process.env.NETLAB_OUT ?? "/app/output/netlab_audit_report.json";
const raw = JSON.parse(readFileSync(outPath, "utf8")) as Record<string, unknown>;
const required = [
  "schema_version",
  "run_id",
  "subject_uid",
  "subnet_rows",
  "ssh_pass_count",
  "ssh_fail_count",
  "mirror_primary_ok",
  "service_leak_count",
  "trunk_native_ok",
  "storage_vlan_ok",
  "uid_tier_ok_count",
  "storage_tier_violation_count",
  "assertion_pass",
  "assertion_total",
  "digest_hex",
];
for (const key of required) {
  if (!(key in raw)) {
    throw new Error(`missing report field ${key}`);
  }
}
if (typeof raw.assertion_pass === "number" && typeof raw.assertion_total === "number") {
  if ((raw.assertion_pass as number) > (raw.assertion_total as number)) {
    throw new Error("assertion_pass exceeds assertion_total");
  }
}
