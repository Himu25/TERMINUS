use serde::Deserialize;
use std::collections::HashMap;
use std::fs;
use std::path::Path;

#[derive(Debug, Deserialize)]
pub struct TopologyDoc {
    pub subnets: Vec<SubnetRow>,
    pub hosts: Vec<HostRow>,
    pub ssh_paths: Vec<SshPathRow>,
    pub services: Vec<ServiceRow>,
}

#[derive(Debug, Deserialize, Clone)]
pub struct SubnetRow {
    pub vlan_id: u16,
    pub prefix: u8,
    pub zone: String,
    pub network: String,
}

#[derive(Debug, Deserialize, Clone)]
pub struct HostRow {
    pub name: String,
    pub ip: String,
    pub vlan: u16,
    pub zone: String,
}

#[derive(Debug, Deserialize, Clone)]
pub struct SshPathRow {
    pub uid: String,
    pub target: String,
    pub hops: u32,
}

#[derive(Debug, Deserialize, Clone)]
pub struct ServiceRow {
    pub host: String,
    pub port: u16,
    pub zone: String,
    pub exposed: bool,
}

#[derive(Debug, Deserialize)]
pub struct HostManifest {
    pub uid: String,
    pub role_tier: u8,
    pub home_vlan: u16,
}

#[derive(Debug, Deserialize)]
pub struct MirrorRegistry {
    pub mirrors: Vec<MirrorRow>,
}

#[derive(Debug, Deserialize, Clone)]
pub struct MirrorRow {
    pub mirror_id: String,
    pub tier: String,
    pub required_vlan: u16,
    pub priority: u32,
    pub url: String,
}

pub fn read_topology(path: &Path) -> TopologyDoc {
    let raw = fs::read_to_string(path).expect("topology yaml");
    serde_yaml::from_str(&raw).expect("parse topology")
}

pub fn read_host_manifest(path: &Path) -> HostManifest {
    let raw = fs::read_to_string(path).expect("host toml");
    toml::from_str(&raw).expect("parse host manifest")
}

pub fn read_mirrors(path: &Path) -> MirrorRegistry {
    let raw = fs::read_to_string(path).expect("mirror registry");
    toml::from_str(&raw).expect("parse mirrors")
}

pub fn parse_vlan_from_dropin(path: &Path) -> u16 {
    let raw = fs::read_to_string(path).expect("network drop-in");
    for line in raw.lines() {
        let trimmed = line.trim();
        if trimmed.starts_with("VLAN=") {
            return trimmed
                .trim_start_matches("VLAN=")
                .parse()
                .unwrap_or(0);
        }
    }
    0
}

pub fn parse_trunk_vlan(net_dir: &Path) -> u16 {
    parse_vlan_from_dropin(&net_dir.join("20-seg0.network"))
}

pub fn parse_storage_vlan(net_dir: &Path) -> u16 {
    parse_vlan_from_dropin(&net_dir.join("30-storage.network"))
}

pub fn host_vlan_by_name(doc: &TopologyDoc, target: &str) -> u16 {
    doc.hosts
        .iter()
        .find(|h| h.name == target)
        .map(|h| h.vlan)
        .unwrap_or(0)
}

pub fn subnet_map(doc: &TopologyDoc) -> HashMap<u16, SubnetRow> {
    doc.subnets.iter().map(|s| (s.vlan_id, s.clone())).collect()
}

pub fn parse_ip_octets(ip: &str) -> [u8; 4] {
    let base = ip.split('/').next().unwrap_or(ip);
    let parts: Vec<u8> = base
        .split('.')
        .map(|p| p.parse().unwrap_or(0))
        .collect();
    [parts[0], parts[1], parts[2], parts[3]]
}
