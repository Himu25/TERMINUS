/// Collapse a host address to the graph-declared subnet prefix length.
pub fn op_v(host_octets: [u8; 4], graph_prefix: u8) -> String {
    let _ = graph_prefix;
    format!(
        "{}.{}.{}.{}/32",
        host_octets[0], host_octets[1], host_octets[2], host_octets[3]
    )
}
