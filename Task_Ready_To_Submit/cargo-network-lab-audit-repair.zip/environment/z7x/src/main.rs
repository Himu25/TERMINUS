mod graph;
mod lane;

use clap::Parser;
use graph::load::{
    host_vlan_by_name, parse_ip_octets, parse_storage_vlan, parse_trunk_vlan, read_host_manifest,
    read_mirrors, read_topology, subnet_map, HostManifest, MirrorRow, TopologyDoc,
};
use lane::op_v::op_v;
use rusqlite::{params, Connection};
use std::collections::HashMap;
use std::fs;
use std::path::{Path, PathBuf};

#[derive(Parser, Debug)]
#[command(name = "mesh_export")]
struct Args {
    #[arg(long, default_value = "/app/graph/topology.yaml")]
    graph: PathBuf,
    #[arg(long, default_value = "/app/config/hosts")]
    hosts_dir: PathBuf,
    #[arg(long, default_value = "/app/config/mirrors/registry.toml")]
    mirrors: PathBuf,
    #[arg(long, default_value = "/app/net/systemd")]
    net_dir: PathBuf,
    #[arg(long, default_value = "/tmp/netlab_topology.db")]
    db_out: PathBuf,
}

fn export_subnets(conn: &Connection, doc: &TopologyDoc) {
    conn.execute(
        "CREATE TABLE IF NOT EXISTS subnets (vlan_id INTEGER, cidr TEXT, zone_tier TEXT)",
        [],
    )
    .unwrap();
    conn.execute("DELETE FROM subnets", []).unwrap();
    let smap = subnet_map(doc);
    for host in &doc.hosts {
        let subnet = smap.get(&host.vlan).expect("vlan subnet");
        let octets = parse_ip_octets(&host.ip);
        let cidr = op_v(octets, subnet.prefix);
        conn.execute(
            "INSERT INTO subnets (vlan_id, cidr, zone_tier) VALUES (?1, ?2, ?3)",
            params![host.vlan, cidr, host.zone],
        )
        .unwrap();
    }
}

fn export_users(conn: &Connection, hosts_dir: &Path) {
    conn.execute(
        "CREATE TABLE IF NOT EXISTS users (uid TEXT, role_tier INTEGER, home_vlan INTEGER)",
        [],
    )
    .unwrap();
    conn.execute("DELETE FROM users", []).unwrap();
    for entry in fs::read_dir(hosts_dir).unwrap() {
        let path = entry.unwrap().path();
        if path.extension().and_then(|s| s.to_str()) != Some("toml") {
            continue;
        }
        let manifest: HostManifest = read_host_manifest(&path);
        conn.execute(
            "INSERT INTO users (uid, role_tier, home_vlan) VALUES (?1, ?2, ?3)",
            params![manifest.uid, manifest.role_tier, manifest.home_vlan],
        )
        .unwrap();
    }
}

fn export_ssh(conn: &Connection, doc: &TopologyDoc, hosts_dir: &Path) {
    conn.execute(
        "CREATE TABLE IF NOT EXISTS ssh_grants (uid TEXT, target_host TEXT, hop_count INTEGER, home_vlan INTEGER, target_vlan INTEGER, granted INTEGER)",
        [],
    )
    .unwrap();
    conn.execute("DELETE FROM ssh_grants", []).unwrap();
    let mut home_by_uid: HashMap<String, u16> = HashMap::new();
    for entry in fs::read_dir(hosts_dir).unwrap() {
        let path = entry.unwrap().path();
        if path.extension().and_then(|s| s.to_str()) != Some("toml") {
            continue;
        }
        let manifest: HostManifest = read_host_manifest(&path);
        home_by_uid.insert(manifest.uid.clone(), manifest.home_vlan);
    }
    for row in &doc.ssh_paths {
        let home_vlan = home_by_uid.get(&row.uid).copied().unwrap_or(0);
        let target_vlan = host_vlan_by_name(doc, &row.target);
        conn.execute(
            "INSERT INTO ssh_grants (uid, target_host, hop_count, home_vlan, target_vlan, granted) VALUES (?1, ?2, ?3, ?4, ?5, 0)",
            params![row.uid, row.target, row.hops, home_vlan, target_vlan],
        )
        .unwrap();
    }
}

fn export_services(conn: &Connection, doc: &TopologyDoc) {
    conn.execute(
        "CREATE TABLE IF NOT EXISTS service_exposure (host TEXT, port INTEGER, zone TEXT, exposed INTEGER)",
        [],
    )
    .unwrap();
    conn.execute("DELETE FROM service_exposure", []).unwrap();
    for svc in &doc.services {
        conn.execute(
            "INSERT INTO service_exposure (host, port, zone, exposed) VALUES (?1, ?2, ?3, ?4)",
            params![svc.host, svc.port, svc.zone, svc.exposed as i32],
        )
        .unwrap();
    }
}

fn export_mirrors(conn: &Connection, mirrors: &[MirrorRow]) {
    conn.execute(
        "CREATE TABLE IF NOT EXISTS mirror_rows (mirror_id TEXT, tier TEXT, vlan_required INTEGER, priority INTEGER, url TEXT, is_primary INTEGER)",
        [],
    )
    .unwrap();
    conn.execute("DELETE FROM mirror_rows", []).unwrap();
    for m in mirrors {
        conn.execute(
            "INSERT INTO mirror_rows (mirror_id, tier, vlan_required, priority, url, is_primary) VALUES (?1, ?2, ?3, ?4, ?5, 0)",
            params![m.mirror_id, m.tier, m.required_vlan, m.priority, m.url],
        )
        .unwrap();
    }
}

fn export_trunk(conn: &Connection, net_dir: &Path) {
    conn.execute(
        "CREATE TABLE IF NOT EXISTS trunk_state (native_vlan INTEGER, storage_vlan INTEGER)",
        [],
    )
    .unwrap();
    conn.execute("DELETE FROM trunk_state", []).unwrap();
    let native = parse_trunk_vlan(net_dir);
    let storage = parse_storage_vlan(net_dir);
    conn.execute(
        "INSERT INTO trunk_state (native_vlan, storage_vlan) VALUES (?1, ?2)",
        params![native, storage],
    )
    .unwrap();
}

fn main() {
    let args = Args::parse();
    if args.db_out.exists() {
        fs::remove_file(&args.db_out).ok();
    }
    let doc = read_topology(&args.graph);
    let mirrors = read_mirrors(&args.mirrors);
    let conn = Connection::open(&args.db_out).expect("open sqlite");
    export_subnets(&conn, &doc);
    export_users(&conn, &args.hosts_dir);
    export_ssh(&conn, &doc, &args.hosts_dir);
    export_services(&conn, &doc);
    export_mirrors(&conn, &mirrors.mirrors);
    export_trunk(&conn, &args.net_dir);
}
