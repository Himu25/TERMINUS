#!/usr/bin/env bash
set -euo pipefail
export PATH="/usr/local/cargo/bin:/usr/bin:${PATH}"
cd /app

mkdir -p /app/bin /app/output /tmp/cargo-target
export CARGO_TARGET_DIR=/tmp/cargo-target

cargo build --release --locked --manifest-path /app/Cargo.toml -p z7x -p z9x
install -m 0755 /tmp/cargo-target/release/z7x /app/bin/z7x
install -m 0755 /tmp/cargo-target/release/z9x /app/bin/z9x

cd /app/z3x
npm run build

cat > /app/bin/netlab_audit_run <<'WRAPPER'
#!/usr/bin/env bash
set -euo pipefail
export PATH="/usr/local/cargo/bin:/usr/bin:${PATH}"
APP_ROOT="${APP_ROOT:-/app}"
DB_PATH="${NETLAB_DB:-/tmp/netlab_topology.db}"
OUT_PATH="${NETLAB_OUT:-/app/output/netlab_audit_report.json}"
SCENARIO="$APP_ROOT/data/active/scenario.json"
rm -f "$DB_PATH"
/app/bin/z7x \
  --graph "$APP_ROOT/data/active/topology.yaml" \
  --hosts-dir "$APP_ROOT/config/hosts" \
  --mirrors "$APP_ROOT/config/mirrors/registry.toml" \
  --net-dir "$APP_ROOT/net/systemd" \
  --db-out "$DB_PATH"
/app/bin/z9x --db "$DB_PATH" --scenario "$SCENARIO" --out "$OUT_PATH"
NETLAB_OUT="$OUT_PATH" node /app/z3x/dist/run.js
WRAPPER
chmod +x /app/bin/netlab_audit_run
