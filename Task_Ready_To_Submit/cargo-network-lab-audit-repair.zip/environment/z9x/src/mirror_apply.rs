#[path = "gates/op_m.rs"]
mod op_m;
use op_m::{op_m, RowCandidate};
use crate::mirror_vlan::mgmt_vlan;
use rusqlite::{params, Connection};

pub fn apply_mirrors(conn: &Connection) -> u32 {
    let mut mirror_stmt = conn
        .prepare("SELECT mirror_id, tier, vlan_required, priority FROM mirror_rows")
        .expect("mirrors");
    let mirror_rows: Vec<RowCandidate> = mirror_stmt
        .query_map([], |row| {
            Ok(RowCandidate {
                mirror_id: row.get(0)?,
                tier: row.get(1)?,
                vlan_required: row.get(2)?,
                priority: row.get(3)?,
            })
        })
        .expect("mirror rows")
        .filter_map(Result::ok)
        .collect();

    let mut mirror_ok = 0u32;
    for tier in ["prod", "staging"] {
        let chosen = op_m(&mirror_rows, tier, mgmt_vlan(tier));
        for row in &mirror_rows {
            if row.tier != tier {
                continue;
            }
            let is_primary = row.mirror_id == chosen;
            conn.execute(
                "UPDATE mirror_rows SET is_primary = ?1 WHERE mirror_id = ?2",
                params![if is_primary { 1 } else { 0 }, row.mirror_id],
            )
            .expect("update mirror");
            if is_primary && row.vlan_required == mgmt_vlan(tier) {
                mirror_ok += 1;
            }
        }
    }
    mirror_ok
}
