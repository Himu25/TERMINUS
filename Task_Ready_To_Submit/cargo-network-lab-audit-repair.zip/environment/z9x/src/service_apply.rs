#[path = "gates/op_s.rs"]
mod op_s;
use op_s::op_s;
use rusqlite::Connection;

pub fn count_service_leaks(conn: &Connection) -> u32 {
    let mut svc_stmt = conn
        .prepare("SELECT host, port, zone, exposed FROM service_exposure")
        .expect("services");
    let mut service_leaks = 0u32;
    let svc_rows = svc_stmt
        .query_map([], |row| {
            Ok((
                row.get::<_, String>(0)?,
                row.get::<_, u16>(1)?,
                row.get::<_, String>(2)?,
                row.get::<_, i32>(3)? == 1,
            ))
        })
        .expect("svc rows")
        .filter_map(Result::ok)
        .collect::<Vec<_>>();

    for (_host, port, zone, exposed) in svc_rows {
        if op_s(port, &zone, exposed) && zone == "storage" && port == 22 {
            service_leaks += 1;
        }
    }
    service_leaks
}
