#[path = "gates/op_u.rs"]
mod op_u;

use op_u::op_u;

pub fn resolved_tier(uid: &str, manifest_tier: u8, table_tier: u8) -> u8 {
    op_u(uid, manifest_tier, table_tier)
}
