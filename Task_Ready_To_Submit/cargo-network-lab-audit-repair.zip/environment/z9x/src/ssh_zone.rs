#[path = "gates/op_w.rs"]
mod op_w;

use op_w::op_w;

pub fn zone_allowed(role_tier: u8, target_zone: &str) -> bool {
    op_w(role_tier, target_zone)
}
