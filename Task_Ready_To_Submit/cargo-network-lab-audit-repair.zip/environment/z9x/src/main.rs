use clap::Parser;
use mirror_apply::apply_mirrors;
use rusqlite::Connection;
use service_apply::count_service_leaks;
use sha2::{Digest, Sha256};
use ssh_apply::apply_ssh;
use std::fs;
use std::path::PathBuf;

mod mirror_apply;
mod mirror_vlan;
mod service_apply;
mod ssh_apply;
mod ssh_budget;
mod ssh_hop;
mod ssh_tier;
mod ssh_zone;

#[derive(Parser, Debug)]
#[command(name = "z9x")]
struct Args {
    #[arg(long, default_value = "/tmp/netlab_topology.db")]
    db: PathBuf,
    #[arg(long, default_value = "/app/data/active/scenario.json")]
    scenario: PathBuf,
    #[arg(long, default_value = "/app/output/netlab_audit_report.json")]
    out: PathBuf,
}

#[derive(serde::Serialize)]
struct Report {
    schema_version: String,
    run_id: String,
    subject_uid: String,
    subnet_rows: u32,
    ssh_pass_count: u32,
    ssh_fail_count: u32,
    mirror_primary_ok: u32,
    service_leak_count: u32,
    trunk_native_ok: bool,
    storage_vlan_ok: bool,
    uid_tier_ok_count: u32,
    storage_tier_violation_count: u32,
    assertion_pass: u32,
    assertion_total: u32,
    digest_hex: String,
}

fn digest_hex(parts: &[String]) -> String {
    let payload = parts.join("|");
    let mut hasher = Sha256::new();
    hasher.update(payload.as_bytes());
    format!("{:x}", hasher.finalize())
}

fn graph_storage_vlan(conn: &Connection) -> u16 {
    conn.query_row(
        "SELECT vlan_id FROM subnets WHERE zone_tier = 'storage' LIMIT 1",
        [],
        |row| row.get::<_, u16>(0),
    )
    .unwrap_or(0)
}

fn main() {
    let args = Args::parse();
    let scenario_raw = fs::read_to_string(&args.scenario).expect("scenario json");
    let scenario: serde_json::Value = serde_json::from_str(&scenario_raw).expect("parse scenario");
    let run_id = scenario["run_id"].as_str().unwrap_or("").to_string();
    let subject_uid = scenario["subject_uid"].as_str().unwrap_or("").to_string();

    let conn = Connection::open(&args.db).expect("open db");
    let subnet_rows: u32 = conn
        .query_row("SELECT COUNT(*) FROM subnets", [], |r| r.get(0))
        .unwrap_or(0);

    let (ssh_pass, ssh_fail, uid_tier_ok, storage_tier_violations) = apply_ssh(&conn);
    let mirror_ok = apply_mirrors(&conn);
    let service_leaks = count_service_leaks(&conn);

    let ssh_path_count: u32 = conn
        .query_row("SELECT COUNT(*) FROM ssh_grants", [], |r| r.get(0))
        .unwrap_or(0);

    let trunk_native_ok: bool = conn
        .query_row("SELECT native_vlan FROM trunk_state", [], |r| r.get::<_, u16>(0))
        .map(|v| v == 40)
        .unwrap_or(false);

    let storage_dropin_vlan: u16 = conn
        .query_row("SELECT storage_vlan FROM trunk_state", [], |r| r.get(0))
        .unwrap_or(0);
    let storage_vlan_ok = storage_dropin_vlan == graph_storage_vlan(&conn);

    let assertion_pass = (if ssh_fail == 0 { 1 } else { 0 })
        + (if mirror_ok >= 2 { 1 } else { 0 })
        + (if service_leaks == 0 { 1 } else { 0 })
        + (if trunk_native_ok { 1 } else { 0 })
        + (if storage_vlan_ok { 1 } else { 0 })
        + (if uid_tier_ok == ssh_path_count && ssh_path_count > 0 {
            1
        } else {
            0
        })
        + (if storage_tier_violations == 0 { 1 } else { 0 });

    let digest = digest_hex(&[
        run_id.clone(),
        subnet_rows.to_string(),
        ssh_pass.to_string(),
        ssh_fail.to_string(),
        mirror_ok.to_string(),
        service_leaks.to_string(),
        uid_tier_ok.to_string(),
        if storage_vlan_ok { "1".into() } else { "0".into() },
        storage_tier_violations.to_string(),
        assertion_pass.to_string(),
    ]);

    let report = Report {
        schema_version: "1".into(),
        run_id,
        subject_uid,
        subnet_rows,
        ssh_pass_count: ssh_pass,
        ssh_fail_count: ssh_fail,
        mirror_primary_ok: mirror_ok,
        service_leak_count: service_leaks,
        trunk_native_ok,
        storage_vlan_ok,
        uid_tier_ok_count: uid_tier_ok,
        storage_tier_violation_count: storage_tier_violations,
        assertion_pass,
        assertion_total: 7,
        digest_hex: digest,
    };

    if let Some(parent) = args.out.parent() {
        fs::create_dir_all(parent).ok();
    }
    fs::write(
        &args.out,
        serde_json::to_string_pretty(&report).unwrap() + "\n",
    )
    .expect("write out");
}
