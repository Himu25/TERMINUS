#[path = "gates/op_r.rs"]
mod op_r;

use op_r::op_r;

pub fn effective_hops(hop_count: u32, home_vlan: u16, target_vlan: u16) -> u32 {
    op_r(hop_count, home_vlan, target_vlan)
}
