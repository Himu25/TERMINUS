#[path = "gates/op_g.rs"]
mod op_g;

use op_g::op_g;
use std::fs;

pub fn mgmt_vlan(tier: &str) -> u16 {
    let raw = fs::read_to_string("/app/config/role_table.json").expect("role table");
    let parsed: serde_json::Value = serde_json::from_str(&raw).expect("parse role table");
    let map = &parsed["mgmt_vlan"];
    let prod = map["prod"].as_u64().unwrap_or(0) as u16;
    let staging = map["staging"].as_u64().unwrap_or(0) as u16;
    op_g(prod, staging, tier)
}
