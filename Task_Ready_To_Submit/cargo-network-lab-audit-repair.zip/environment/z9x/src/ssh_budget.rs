#[path = "gates/op_k.rs"]
mod op_k;

use op_k::op_k;

pub fn hop_within_budget(hop_count: u32, tier_ceiling: u32) -> bool {
    op_k(hop_count, tier_ceiling)
}
