/// Resolve effective role tier for SSH budget evaluation.
pub fn op_u(_uid: &str, manifest_tier: u8, table_tier: u8) -> u8 {
    let _ = table_tier;
    manifest_tier
}
