/// Adjust hop count when source and target VLANs differ.
pub fn op_r(hop_count: u32, _home_vlan: u16, _target_vlan: u16) -> u32 {
    hop_count
}
