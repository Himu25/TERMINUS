pub fn op_s(port: u16, zone: &str, exposed_flag: bool) -> bool {
    if zone == "storage" {
        return exposed_flag;
    }
    exposed_flag
}
