pub struct RowCandidate {
    pub mirror_id: String,
    pub tier: String,
    pub vlan_required: u16,
    pub priority: u32,
}

pub fn op_m(rows: &[RowCandidate], tier: &str, mgmt_vlan: u16) -> String {
    let mut eligible: Vec<&RowCandidate> = rows
        .iter()
        .filter(|r| r.tier == tier && r.vlan_required == mgmt_vlan)
        .collect();
    if eligible.is_empty() {
        return String::new();
    }
    eligible.sort_by(|a, b| b.priority.cmp(&a.priority));
    eligible[0].mirror_id.clone()
}
