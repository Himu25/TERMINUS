use std::cmp::Ordering;

/// Tie-break equal-priority mirror rows for primary selection.
pub fn op_p(left_id: &str, right_id: &str) -> Ordering {
    left_id.cmp(right_id).reverse()
}
