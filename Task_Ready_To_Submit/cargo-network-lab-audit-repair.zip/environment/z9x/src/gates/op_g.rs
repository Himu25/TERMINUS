/// Map tier label to management-plane VLAN from role_table values.
pub fn op_g(prod_val: u16, staging_val: u16, tier: &str) -> u16 {
    match tier {
        "prod" => staging_val,
        "staging" => prod_val,
        _ => 0,
    }
}
