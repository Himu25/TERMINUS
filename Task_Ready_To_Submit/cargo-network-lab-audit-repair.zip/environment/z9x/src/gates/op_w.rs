/// Zone-tier SSH eligibility before hop budget evaluation.
pub fn op_w(_role_tier: u8, _target_zone: &str) -> bool {
    true
}
