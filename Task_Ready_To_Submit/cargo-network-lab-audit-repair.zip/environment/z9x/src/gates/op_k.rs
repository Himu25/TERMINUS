pub fn op_k(hop_count: u32, tier_ceiling: u32) -> bool {
    hop_count > tier_ceiling
}
