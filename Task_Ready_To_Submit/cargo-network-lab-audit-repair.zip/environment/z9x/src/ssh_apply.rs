use crate::ssh_budget::hop_within_budget;
use crate::ssh_hop::effective_hops;
use crate::ssh_tier::resolved_tier;
use crate::ssh_zone::zone_allowed;
use rusqlite::{params, Connection};
use std::collections::HashMap;
use std::fs;

pub fn tier_ceiling(role_tier: u8) -> u32 {
    match role_tier {
        1 => 4,
        2 => 2,
        _ => 0,
    }
}

fn uid_tiers() -> HashMap<String, u8> {
    let raw = fs::read_to_string("/app/config/role_table.json").expect("role table");
    let parsed: serde_json::Value = serde_json::from_str(&raw).expect("parse role table");
    parsed["uid_tiers"]
        .as_object()
        .expect("uid_tiers map")
        .iter()
        .map(|(uid, tier)| (uid.clone(), tier.as_u64().unwrap_or(0) as u8))
        .collect()
}

fn zone_for_vlan(conn: &Connection, vlan: u16) -> String {
    conn.query_row(
        "SELECT zone_tier FROM subnets WHERE vlan_id = ?1 LIMIT 1",
        params![vlan],
        |row| row.get(0),
    )
    .unwrap_or_default()
}

pub fn apply_ssh(conn: &Connection) -> (u32, u32, u32, u32) {
    let table_tiers = uid_tiers();
    let mut stmt = conn
        .prepare("SELECT uid, role_tier FROM users")
        .expect("users");
    let manifest_tiers: HashMap<String, u8> = stmt
        .query_map([], |row| Ok((row.get::<_, String>(0)?, row.get::<_, u8>(1)?)))
        .expect("users rows")
        .filter_map(Result::ok)
        .collect();

    let mut ssh_pass = 0u32;
    let mut ssh_fail = 0u32;
    let mut uid_tier_ok = 0u32;
    let mut storage_tier_violations = 0u32;
    let mut ssh_stmt = conn
        .prepare("SELECT uid, target_host, hop_count, home_vlan, target_vlan FROM ssh_grants")
        .expect("ssh");
    let ssh_rows = ssh_stmt
        .query_map([], |row| {
            Ok((
                row.get::<_, String>(0)?,
                row.get::<_, String>(1)?,
                row.get::<_, u32>(2)?,
                row.get::<_, u16>(3)?,
                row.get::<_, u16>(4)?,
            ))
        })
        .expect("ssh rows")
        .filter_map(Result::ok)
        .collect::<Vec<_>>();

    for (uid, target, hops, home_vlan, target_vlan) in ssh_rows {
        let manifest_tier = manifest_tiers.get(&uid).copied().unwrap_or(0);
        let table_tier = table_tiers.get(&uid).copied().unwrap_or(manifest_tier);
        let resolved = resolved_tier(&uid, manifest_tier, table_tier);
        if resolved == table_tier {
            uid_tier_ok += 1;
        }
        let target_zone = zone_for_vlan(conn, target_vlan);
        let zone_ok = zone_allowed(resolved, &target_zone);
        let effective = effective_hops(hops, home_vlan, target_vlan);
        let ok = zone_ok && hop_within_budget(effective, tier_ceiling(resolved));
        if ok && target_zone == "storage" && resolved > 1 {
            storage_tier_violations += 1;
        }
        conn.execute(
            "UPDATE ssh_grants SET granted = ?1 WHERE uid = ?2 AND target_host = ?3",
            params![if ok { 1 } else { 0 }, uid, target],
        )
        .expect("update ssh");
        if ok {
            ssh_pass += 1;
        } else {
            ssh_fail += 1;
        }
    }
    (ssh_pass, ssh_fail, uid_tier_ok, storage_tier_violations)
}
