# Operations Handbook — Chapter 12

Document ID: NRL-HB-12-rev4



## 12.1 Scope

This chapter documents routine maintenance for the research netlab fabric. Operators must cross-reference the topology graph under /app/graph and host manifests under /app/config/hosts before applying changes. All audit assertions in the TypeScript harness derive from handbook tables; grep-friendly summaries are intentionally omitted.

### 12.1 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-12-001. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 12.2 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-12-002. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 12.3 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-12-003. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 12.4 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-12-004. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 12.5 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-12-005. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 12.6 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-12-006. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 12.7 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-12-007. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 12.8 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-12-008. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 12.9 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-12-009. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 12.10 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-12-010. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 12.11 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-12-011. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 12.12 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-12-012. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 12.13 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-12-013. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 12.14 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-12-014. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 12.15 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-12-015. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 12.16 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-12-016. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 12.17 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-12-017. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 12.18 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-12-018. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

