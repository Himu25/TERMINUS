# Operations Handbook — Chapter 16

Document ID: NRL-HB-16-rev4


## 16.5 Cross-segment hop accounting

When a user's home_vlan differs from the target host vlan on an SSH path, add one to hop_count
before comparing against the tier ceiling from chapter 9.


## 16.1 Scope

This chapter documents routine maintenance for the research netlab fabric. Operators must cross-reference the topology graph under /app/graph and host manifests under /app/config/hosts before applying changes. All audit assertions in the TypeScript harness derive from handbook tables; grep-friendly summaries are intentionally omitted.

### 16.1 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-16-001. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 16.2 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-16-002. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 16.3 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-16-003. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 16.4 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-16-004. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 16.5 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-16-005. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 16.6 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-16-006. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 16.7 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-16-007. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 16.8 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-16-008. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 16.9 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-16-009. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 16.10 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-16-010. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 16.11 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-16-011. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 16.12 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-16-012. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 16.13 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-16-013. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 16.14 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-16-014. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 16.15 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-16-015. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 16.16 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-16-016. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 16.17 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-16-017. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 16.18 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-16-018. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

