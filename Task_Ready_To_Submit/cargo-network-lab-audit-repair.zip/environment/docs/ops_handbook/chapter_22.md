# Operations Handbook — Chapter 22

Document ID: NRL-HB-22-rev4


## 22.6 Trunk VLAN tagging

The lab trunk interface 20-lab-trunk.network must carry VLAN 40 as the native lab segment.
VLAN 30 is storage-only and must not appear as the trunk native ID.


## 22.1 Scope

This chapter documents routine maintenance for the research netlab fabric. Operators must cross-reference the topology graph under /app/graph and host manifests under /app/config/hosts before applying changes. All audit assertions in the TypeScript harness derive from handbook tables; grep-friendly summaries are intentionally omitted.

### 22.1 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-22-001. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 22.2 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-22-002. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 22.3 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-22-003. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 22.4 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-22-004. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 22.5 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-22-005. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 22.6 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-22-006. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 22.7 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-22-007. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 22.8 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-22-008. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 22.9 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-22-009. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 22.10 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-22-010. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 22.11 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-22-011. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 22.12 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-22-012. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 22.13 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-22-013. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 22.14 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-22-014. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 22.15 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-22-015. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 22.16 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-22-016. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 22.17 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-22-017. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 22.18 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-22-018. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

