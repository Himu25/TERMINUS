# Operations Handbook — Chapter 14

Document ID: NRL-HB-14-rev4

## 14.1 Package mirror placement

Each mirror tier declares a required_vlan. The primary mirror for a tier must be the registry
row with the lowest priority index among rows whose required_vlan matches the tier's management
plane (vlan100 for tier prod, vlan110 for tier staging).

## 14.1 Scope

This chapter documents routine maintenance for the research netlab fabric. Operators must cross-reference the topology graph under /app/graph and host manifests under /app/config/hosts before applying changes. All audit assertions in the TypeScript harness derive from handbook tables; grep-friendly summaries are intentionally omitted.

### 14.1 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-14-001. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 14.2 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-14-002. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 14.3 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-14-003. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 14.4 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-14-004. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 14.5 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-14-005. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 14.6 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-14-006. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 14.7 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-14-007. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 14.8 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-14-008. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 14.9 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-14-009. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 14.10 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-14-010. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 14.11 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-14-011. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 14.12 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-14-012. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 14.13 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-14-013. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 14.14 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-14-014. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 14.15 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-14-015. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 14.16 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-14-016. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 14.17 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-14-017. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 14.18 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-14-018. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.
