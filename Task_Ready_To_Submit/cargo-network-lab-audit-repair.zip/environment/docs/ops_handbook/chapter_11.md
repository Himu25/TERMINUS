# Operations Handbook — Chapter 11

Document ID: NRL-HB-11-rev4


## 11.4 UID tier authority

Host manifest role_tier fields are advisory only. SSH hop budgets must resolve the effective
role tier from /app/config/role_table.json uid_tiers whenever an entry exists for the uid.


## 11.1 Scope

This chapter documents routine maintenance for the research netlab fabric. Operators must cross-reference the topology graph under /app/graph and host manifests under /app/config/hosts before applying changes. All audit assertions in the TypeScript harness derive from handbook tables; grep-friendly summaries are intentionally omitted.

### 11.1 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-11-001. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 11.2 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-11-002. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 11.3 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-11-003. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 11.4 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-11-004. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 11.5 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-11-005. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 11.6 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-11-006. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 11.7 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-11-007. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 11.8 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-11-008. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 11.9 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-11-009. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 11.10 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-11-010. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 11.11 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-11-011. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 11.12 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-11-012. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 11.13 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-11-013. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 11.14 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-11-014. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 11.15 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-11-015. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 11.16 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-11-016. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 11.17 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-11-017. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

### 11.18 Runbook fragment

During quarterly review, verify that systemd-networkd drop-ins under /app/net/systemd match the declared graph edges. Mirror registry edits require change ticket NRL-11-018. Escalation contacts rotate weekly; see roster appendix. Backup window starts 02:00 UTC. Do not restart mesh_export during active replay.

