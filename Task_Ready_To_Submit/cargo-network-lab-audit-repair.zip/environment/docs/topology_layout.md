Replay packs live under `/app/data/replay/<pack>/` with `scenario.json` and `topology.yaml`. Copy a pack into `/app/data/active/` before invoking the audit driver. Indexed packs for grading are listed in `/app/docs/replay_index.txt`.

The ops handbook under `/app/docs/ops_handbook/` is the authoritative source for VLAN aggregation, SSH hop budgets, mirror placement, storage port exposure, and trunk native VLAN rules. Policy tables are not duplicated in this file.

Active scenario metadata is always read from `/app/data/active/scenario.json`.
