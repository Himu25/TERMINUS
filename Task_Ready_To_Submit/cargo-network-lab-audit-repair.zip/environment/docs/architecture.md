Research netlab fold pipeline and rank lane share one SQLite snapshot per replay.

z7x reads the active topology graph, host manifests, mirror registry, and systemd-networkd drop-ins, then writes subnet, user, ssh_grants, service_exposure, mirror_rows, and trunk_state tables. ssh_grants rows carry home_vlan and target_vlan for cross-segment evaluation.

z9x applies handbook-derived gates to those tables and emits netlab_audit_report.json. z3x is a TypeScript schema checker over the finished report.

Report field semantics:

- schema_version — contract version string
- run_id, subject_uid — copied from the active scenario.json
- subnet_rows — subnet rows exported into SQLite
- ssh_pass_count, ssh_fail_count — SSH grant tallies after gate evaluation
- mirror_primary_ok — count of tier primaries selected on the correct management VLAN
- service_leak_count — outward storage SSH exposure tally
- trunk_native_ok, storage_vlan_ok — systemd drop-in alignment flags against graph state
- uid_tier_ok_count — SSH paths whose resolved tier matches role_table.json
- storage_tier_violation_count — storage-zone SSH grants that violate tier policy
- assertion_pass, assertion_total — handbook assertion gate score (seven gates)
- digest_hex — sha256 digest over pipe-separated tally fields (layout in ops handbook chapter 28)

Tier ceilings, uid tiers, mirror registry rows, and management VLAN ids are listed in /app/config/role_table.json. SSH semantics, mirror selection, VLAN aggregation, trunk native VLAN, storage drop-in rules, and assertion definitions are documented only in /app/docs/ops_handbook/.

Build via /app/scripts/build.sh. Driver binary: /app/bin/netlab_audit_run. Set TB_NETLAB_FIXTURE=1 when replaying fixtures.
