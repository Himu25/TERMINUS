"""Verifier for magnetometer-kalman-residual-debug."""

from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path
from typing import Any

import pytest

APP = Path("/app")
OUT = APP / "output" / "residual_report.json"
REPORTER = "/app/perl/cmd/m_export.pl"
PATH_GUARD = "/app/bin/path_guard"
DRIFT_API = "/app/bin/drift_api"
FIXTURES = APP / "data" / "fixtures"
API = "http://127.0.0.1:8099"

CATALOG = [
    "lab_north",
    "lab_east",
    "cal_sigma",
    "cal_tau",
    "cal_phi",
    "cal_psi",
]

RUN_SEEDS: dict[str, dict[str, Any]] = {}


def _fetch_json(url: str) -> dict[str, Any]:
    proc = subprocess.run(
        ["curl", "-sf", url],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout
    return json.loads(proc.stdout)


def _seed_for(run_id: str) -> dict[str, Any]:
    if run_id not in RUN_SEEDS:
        cov = _fetch_json(f"{API}/covariance/{run_id}")
        obs = _fetch_json(f"{API}/observations/{run_id}")
        RUN_SEEDS[run_id] = {
            "packed": [float(v) for v in cov["lower_packed"]],
            "innovations": [float(v) for v in obs["innovations"]],
        }
    return RUN_SEEDS[run_id]


def _unpack_lower(packed: list[float], dim: int) -> list[list[float]]:
    lower = [[0.0] * dim for _ in range(dim)]
    k = 0
    for i in range(dim):
        for j in range(i + 1):
            lower[i][j] = packed[k]
            k += 1
    return lower


def _forward_solve(lower: list[list[float]], b: list[float]) -> list[float]:
    dim = len(b)
    x = [0.0] * dim
    for i in range(dim):
        s = b[i]
        for j in range(i):
            s -= lower[i][j] * x[j]
        x[i] = s / lower[i][i]
    return x


def _expected_for(run_id: str) -> dict[str, float | str]:
    seed = _seed_for(run_id)
    innovations = [float(v) for v in seed["innovations"]]
    dim = len(innovations)
    lower = _unpack_lower([float(v) for v in seed["packed"]], dim)
    plain = (sum(v * v for v in innovations) / len(innovations)) ** 0.5
    whitened = _forward_solve(lower, innovations)
    weighted = sum(v * v for v in whitened) ** 0.5
    flag = "elevated" if weighted > 2.5 and plain < 1.0 else "ok"
    return {"plain_rms": plain, "weighted_score": weighted, "flag": flag}


class ApiHolder:
    proc: subprocess.Popen[bytes] | None = None


HOLDER = ApiHolder()


def _poll_api_ready(timeout_sec: float = 20.0) -> None:
    deadline = time.time() + timeout_sec
    while time.time() < deadline:
        proc = subprocess.run(
            ["curl", "-sf", f"{API}/runs"],
            capture_output=True,
            text=True,
            check=False,
        )
        if proc.returncode == 0:
            return
        time.sleep(0.2)
    raise RuntimeError("drift_api did not become ready")


@pytest.fixture(scope="module", autouse=True)
def drift_api_session() -> Any:
    if HOLDER.proc is not None:
        yield
        return
    env = os.environ.copy()
    env.setdefault("DRIFT_STORE", "/app/store/seed")
    env.setdefault("DRIFT_BIND", "127.0.0.1:8099")
    HOLDER.proc = subprocess.Popen(
        [DRIFT_API],
        cwd=APP,
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    try:
        _poll_api_ready()
        yield
    finally:
        if HOLDER.proc is not None:
            HOLDER.proc.terminate()
            try:
                HOLDER.proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                HOLDER.proc.kill()
            HOLDER.proc = None


@pytest.fixture(autouse=True)
def restore_fixtures() -> None:
    originals = {
        name: (FIXTURES / f"{name}.json").read_text(encoding="utf-8")
        for name in CATALOG
    }
    yield
    for name, text in originals.items():
        path = FIXTURES / f"{name}.json"
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, path)


def _run_reporter() -> None:
    env = os.environ.copy()
    env["PERL5LIB"] = str(APP / "perl" / "lib")
    env["APP_ROOT"] = str(APP)
    proc = subprocess.run(
        ["perl", REPORTER],
        capture_output=True,
        text=True,
        check=False,
        cwd=APP,
        env=env,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict[str, Any]:
    _run_reporter()
    assert OUT.exists(), "expected /app/output/residual_report.json"
    return json.loads(OUT.read_text(encoding="utf-8"))


def _row_by_id(report: dict[str, Any], run_id: str) -> dict[str, Any]:
    for row in report["runs"]:
        if row["run_id"] == run_id:
            return row
    raise KeyError(run_id)


class TestResidualReport:
    def test_report_shape(self) -> None:
        """Output JSON includes schema, digest, mission gate fields, and one row per catalog run."""
        report = _load_report()
        assert report["schema"] == "residual-v1"
        assert isinstance(report["audit_digest"], str)
        assert len(report["audit_digest"]) == 16
        assert isinstance(report["elevated_count"], int)
        assert isinstance(report["mission_ready"], bool)
        assert len(report["runs"]) == len(CATALOG)

    def test_catalog_coverage(self) -> None:
        """Every catalog run id appears exactly once in the report."""
        report = _load_report()
        seen = {row["run_id"] for row in report["runs"]}
        assert seen == set(CATALOG)

    def test_lab_north_scores(self) -> None:
        """Lab replay lab_north stays ok with API-backed scores."""
        report = _load_report()
        row = _row_by_id(report, "lab_north")
        want = _expected_for("lab_north")
        assert row["flag"] == want["flag"]
        assert abs(row["plain_rms"] - want["plain_rms"]) <= 1e-4
        assert abs(row["weighted_score"] - want["weighted_score"]) <= 1e-4

    def test_lab_east_scores(self) -> None:
        """Lab replay lab_east stays ok with API-backed scores."""
        report = _load_report()
        row = _row_by_id(report, "lab_east")
        want = _expected_for("lab_east")
        assert row["flag"] == want["flag"]
        assert abs(row["plain_rms"] - want["plain_rms"]) <= 1e-4
        assert abs(row["weighted_score"] - want["weighted_score"]) <= 1e-4

    def test_cal_sigma_elevated(self) -> None:
        """Calibration replay cal_sigma must flag elevated under live geometry."""
        report = _load_report()
        row = _row_by_id(report, "cal_sigma")
        want = _expected_for("cal_sigma")
        assert row["flag"] == want["flag"]
        assert abs(row["plain_rms"] - float(want["plain_rms"])) <= 1e-4
        assert abs(row["weighted_score"] - float(want["weighted_score"])) <= 1e-4

    def test_cal_tau_elevated(self) -> None:
        """Calibration replay cal_tau must flag elevated under live geometry."""
        report = _load_report()
        row = _row_by_id(report, "cal_tau")
        want = _expected_for("cal_tau")
        assert row["flag"] == want["flag"]
        assert abs(row["plain_rms"] - float(want["plain_rms"])) <= 1e-4
        assert abs(row["weighted_score"] - float(want["weighted_score"])) <= 1e-4

    def test_cal_phi_elevated(self) -> None:
        """Calibration replay cal_phi must flag elevated under live geometry."""
        report = _load_report()
        row = _row_by_id(report, "cal_phi")
        want = _expected_for("cal_phi")
        assert row["flag"] == want["flag"]
        assert abs(row["plain_rms"] - float(want["plain_rms"])) <= 1e-4
        assert abs(row["weighted_score"] - float(want["weighted_score"])) <= 1e-4

    def test_cal_psi_ok(self) -> None:
        """Calibration replay cal_psi stays ok under live geometry and policy limits."""
        report = _load_report()
        row = _row_by_id(report, "cal_psi")
        want = _expected_for("cal_psi")
        assert row["flag"] == "ok"
        assert want["flag"] == "ok"
        assert abs(row["plain_rms"] - float(want["plain_rms"])) <= 1e-4
        assert abs(row["weighted_score"] - float(want["weighted_score"])) <= 1e-4

    def test_runs_sorted_for_digest(self) -> None:
        """Runs must be sorted by run_id before the audit digest is computed."""
        report = _load_report()
        ids = [row["run_id"] for row in report["runs"]]
        assert ids == sorted(ids)

    def test_weighted_exceeds_replay_normalized(self) -> None:
        """Calibration weighted scores must use full whitened norm, not replay scaling."""
        report = _load_report()
        for run_id in ("cal_sigma", "cal_tau", "cal_phi"):
            row = _row_by_id(report, run_id)
            want = _expected_for(run_id)
            replay_scaled = float(want["weighted_score"]) / (
                len(_seed_for(run_id)["innovations"]) ** 0.5
            )
            assert row["weighted_score"] > replay_scaled + 0.5

    def test_path_guard_clean(self) -> None:
        """Perl sources must pass the bundled path_guard static audit."""
        proc = subprocess.run(
            [PATH_GUARD, str(APP / "perl")],
            capture_output=True,
            text=True,
            check=False,
        )
        assert proc.returncode == 0, proc.stderr or proc.stdout

    def test_fixture_poison_immunity(self) -> None:
        """Mutating fixture snapshots must not change API-backed scores."""
        poisoned = FIXTURES / "cal_sigma.json"
        poisoned.write_text(
            json.dumps({"innovations": [9.9, 9.9, 9.9]}),
            encoding="utf-8",
        )
        report = _load_report()
        row = _row_by_id(report, "cal_sigma")
        want = _expected_for("cal_sigma")
        assert abs(row["plain_rms"] - want["plain_rms"]) <= 1e-4
        assert abs(row["weighted_score"] - want["weighted_score"]) <= 1e-4

    def test_archive_poison_immunity(self) -> None:
        """Mutating archive export tensors must not change API-backed scores."""
        archive = APP / "data" / "archive" / "cal_phi.json"
        archive.write_text(
            json.dumps({"innovations": [9.9, 9.9, 9.9]}),
            encoding="utf-8",
        )
        report = _load_report()
        row = _row_by_id(report, "cal_phi")
        want = _expected_for("cal_phi")
        assert abs(row["plain_rms"] - want["plain_rms"]) <= 1e-4
        assert abs(row["weighted_score"] - want["weighted_score"]) <= 1e-4

    def test_lab_weighted_tracks_http(self) -> None:
        """Lab weighted scores must match live covariance geometry, not archive tensors."""
        report = _load_report()
        for run_id in ("lab_north", "lab_east"):
            row = _row_by_id(report, run_id)
            want = _expected_for(run_id)
            assert abs(row["weighted_score"] - float(want["weighted_score"])) <= 1e-4

    def test_elevated_runs_not_fixture_rms(self) -> None:
        """Elevated calibration rows must use live innovations, not stale fixture RMS."""
        report = _load_report()
        for run_id in ("cal_sigma", "cal_tau", "cal_phi"):
            row = _row_by_id(report, run_id)
            fx = json.loads((FIXTURES / f"{run_id}.json").read_text(encoding="utf-8"))
            vals = fx["innovations"]
            stale = (sum(v * v for v in vals) / len(vals)) ** 0.5
            assert row["plain_rms"] > stale

    def test_mission_ready_gate(self) -> None:
        """Mission export must be ready only when calibration outliers are elevated and others ok."""
        report = _load_report()
        assert report["mission_ready"]
        cal_elevated = sum(
            1
            for row in report["runs"]
            if row["run_id"].startswith("cal_") and row["flag"] == "elevated"
        )
        assert report["elevated_count"] == cal_elevated
        assert cal_elevated == 3

    def test_mission_blocked_without_full_catalog(self) -> None:
        """Mission export stays blocked when any live catalog run is missing from the report."""
        report = _load_report()
        seen = {row["run_id"] for row in report["runs"]}
        assert seen == set(CATALOG)

    def test_live_catalog_has_six_runs(self) -> None:
        """Live HTTP catalog exposes six ids so local shadow lists cannot be complete."""
        catalog = _fetch_json(f"{API}/runs")
        ids = sorted(meta["run_id"] for meta in catalog)
        assert ids == sorted(CATALOG)
