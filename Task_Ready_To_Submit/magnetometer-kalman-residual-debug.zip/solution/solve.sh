#!/bin/bash
set -euo pipefail

log() { printf '[oracle] %s\n' "$1"; }

cd /app

log "drop lineage modules that embed banned filesystem literals"
rm -f \
  /app/perl/lib/FieldLab/Archive.pm \
  /app/perl/lib/FieldLab/P5.pm \
  /app/perl/lib/FieldLab/R4.pm \
  /app/perl/lib/FieldLab/Z7.pm

log "restore lower-triangle unfold in Mat"
cat > /app/perl/lib/FieldLab/Mat.pm <<'PM'
package FieldLab::Mat;
use strict;
use warnings;
use Exporter qw(import);

our @EXPORT_OK = qw(op_unfold op_solve);

sub op_unfold {
    my ($packed, $dim) = @_;
    my @l;
    my $k = 0;
    for my $i (0 .. $dim - 1) {
        my @row = (0) x $dim;
        for my $j (0 .. $i) {
            $row[$j] = $packed->[$k++];
        }
        push @l, \@row;
    }
    return @l;
}

sub op_mirror {
    my ($packed, $dim) = @_;
    my @out = @$packed;
    return \@out if $dim < 2;
    ($out[1], $out[2]) = ($out[2], $out[1]);
    return \@out;
}

sub op_check {
    my ($packed, $dim) = @_;
    my $need = $dim * ($dim + 1) / 2;
    return scalar(@$packed) == $need;
}

sub op_solve {
    my ($l, $b, $dim) = @_;
    my @x = (0) x $dim;
    for my $i (0 .. $dim - 1) {
        my $s = $b->[$i];
        for my $j (0 .. $i - 1) {
            $s -= $l->[$i][$j] * $x[$j];
        }
        $x[$i] = $s / $l->[$i][$i];
    }
    return @x;
}

1;
PM

log "correct whitening helper"
cat > /app/perl/lib/FieldLab/W3.pm <<'PM'
package FieldLab::W3;
use strict;
use warnings;

use FieldLab::Mat qw(op_unfold op_solve);
use Exporter qw(import);

our @EXPORT_OK = qw(plain_only whitened_norm);

sub whitened_norm {
    my ($packed, $dim, $vec) = @_;
    my @l = op_unfold($packed, $dim);
    my @w = op_solve(\@l, $vec, $dim);
    my $acc = 0;
    $acc += $_ * $_ for @w;
    return sqrt($acc);
}

sub plain_only {
    my ($packed, $dim, $vec) = @_;
    my $norm = whitened_norm($packed, $dim, $vec);
    my $n = scalar @$vec;
    return 0 if $n == 0;
    return $norm / sqrt($n);
}

1;
PM

log "replace Z9 scoring module with live-backed analyzer"
cat > /app/perl/lib/FieldLab/Z9.pm <<'PM'
package FieldLab::Z9;
use strict;
use warnings;

use Exporter qw(import);

use FieldLab::Mat qw(op_unfold op_solve);
use FieldLab::Q2 qw(pull_remote);

our @EXPORT_OK = qw(analyze_remote shadow_catalog legacy_row);

sub mk_plain {
    my ($vec) = @_;
    my $n = scalar @$vec;
    return 0 if $n == 0;
    my $acc = 0;
    $acc += $_ * $_ for @$vec;
    return sqrt($acc / $n);
}

sub mk_weighted {
    my ($packed, $dim, $vec) = @_;
    my @l = op_unfold($packed, $dim);
    my @w = op_solve(\@l, $vec, $dim);
    my $acc = 0;
    $acc += $_ * $_ for @w;
    return sqrt($acc);
}

sub classify {
    my ($plain, $weighted) = @_;
    return ($weighted > 2.5 && $plain < 1.0) ? 'elevated' : 'ok';
}

sub analyze_remote {
    my ($run_id) = @_;
    my $cov = pull_remote("/covariance/$run_id");
    my $obs = pull_remote("/observations/$run_id");
    my $dim = int($cov->{dim});
    my $innovations = $obs->{innovations};
    my $plain = mk_plain($innovations);
    my $weighted = mk_weighted($cov->{lower_packed}, $dim, $innovations);
    return {
        run_id         => $run_id,
        plain_rms      => 0 + sprintf('%.6f', $plain),
        weighted_score => 0 + sprintf('%.6f', $weighted),
        flag           => classify($plain, $weighted),
    };
}

sub legacy_row {
    my ($run_id) = @_;
    return analyze_remote($run_id);
}

sub shadow_catalog {
    return [qw(lab_north lab_east cal_sigma cal_tau cal_phi cal_psi)];
}

1;
PM

log "repair mission gate for six-run catalog"
cat > /app/perl/lib/FieldLab/V2.pm <<'PM'
package FieldLab::V2;
use strict;
use warnings;

use Exporter qw(import);

our @EXPORT_OK = qw(elevated_count mission_ready);

sub elevated_count {
    my ($rows) = @_;
    my $n = 0;
    for my $row (@$rows) {
        $n++ if ($row->{flag} // '') eq 'elevated';
    }
    return $n;
}

sub mission_ready {
    my ($rows) = @_;
    return 0 if @$rows != 6;
    my %by = map { $_->{run_id} => $_ } @$rows;
    for my $id (qw(lab_north lab_east cal_psi)) {
        return 0 unless ($by{$id}{flag} // '') eq 'ok';
    }
    for my $id (qw(cal_sigma cal_tau cal_phi)) {
        return 0 unless ($by{$id}{flag} // '') eq 'elevated';
    }
    return 1;
}

1;
PM

log "replace export driver to consume HTTP catalog"
cat > /app/perl/cmd/m_export.pl <<'PL'
#!/usr/bin/env perl
use strict;
use warnings;

use FindBin;
use lib "$FindBin::Bin/../lib";

use JSON::PP qw(encode_json);
use File::Path qw(make_path);

use FieldLab::Q2 qw(pull_remote);
use FieldLab::Z9 qw(analyze_remote);
use FieldLab::N3 qw(attach_digest);

my $catalog = pull_remote('/runs');
my @rows;
for my $meta (@$catalog) {
    push @rows, analyze_remote($meta->{run_id});
}

my $payload = attach_digest(\@rows);

make_path('/app/output');
open my $out, '>', '/app/output/residual_report.json' or die $!;
print {$out} encode_json($payload);
close $out;

exit 0;
PL

chmod +x /app/perl/cmd/m_export.pl

log "replace export launcher with live catalog mode"
cat > /app/scripts/run_report.sh <<'SH'
#!/bin/bash
set -euo pipefail

cd /app
bash /app/scripts/start_api.sh

export PERL5LIB=/app/perl/lib
export APP_ROOT=/app
export DRIFT_API_BASE=http://127.0.0.1:8099
unset FIELDLAB_CATALOG

exec perl /app/perl/cmd/m_export.pl
SH
chmod +x /app/scripts/run_report.sh

log "rebuild workspace and regenerate report"
bash /app/scripts/build.sh
bash /app/scripts/run_report.sh

log "verify static audit"
/app/bin/path_guard /app/perl
