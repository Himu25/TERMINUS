#!/bin/bash
set -euo pipefail

cd /app
cargo build --release --workspace
install -d -m 0777 /app/bin /app/output /app/store
install -m 0755 target/release/drift_api /app/bin/drift_api
install -m 0755 target/release/path_guard /app/bin/path_guard
