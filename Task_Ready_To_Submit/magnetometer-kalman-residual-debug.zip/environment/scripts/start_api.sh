#!/bin/bash
set -euo pipefail

export DRIFT_STORE="${DRIFT_STORE:-/app/store/seed}"
export DRIFT_BIND="${DRIFT_BIND:-127.0.0.1:8099}"

if ! pgrep -f '/app/bin/drift_api' >/dev/null 2>&1; then
  nohup /app/bin/drift_api >/app/output/drift_api.log 2>&1 &
  sleep 1
fi
