#!/bin/bash
set -euo pipefail

cd /app
bash /app/scripts/start_api.sh

export PERL5LIB=/app/perl/lib
export APP_ROOT=/app
export FIELDLAB_CATALOG=shadow

exec perl /app/perl/cmd/m_export.pl
