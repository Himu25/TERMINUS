# API surface

Base URL: `http://127.0.0.1:8099`

## `/runs`

Returns sorted metadata rows. Each row includes `run_id`, `dim`, and `kind`.

## `/covariance/{run_id}`

Returns the lower-triangular factor stored row-major for the run dimension. For `dim = 3`, `lower_packed` has six floats representing:

```
L00
L10 L11
L20 L21 L22
```

Rebuild the square factor by placing each packed value at `(row, col)` with `col <= row` and zeroing the upper triangle.

## `/observations/{run_id}`

Returns the innovation vector as `innovations`, a float array whose length equals `dim`.

## Reporter notes

Clients may issue HTTP GET requests with any library; reporter code may use `LWP::UserAgent`. Sample requests live under `/app/sample_requests/`.

Whitened scoring applies the unpacked lower factor to the innovation vector and returns the Euclidean norm of the solved vector — the full whitened norm, not a replay-scaled or per-dimension shortcut.
