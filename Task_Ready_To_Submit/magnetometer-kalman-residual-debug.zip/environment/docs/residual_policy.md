# Residual export policy

Batch exports attach `mission_ready` and `elevated_count` derived from per-row flags. Flag thresholds and lineage prefixes are declared in `config/residual_policy.toml`. The release gate implementation lives in `perl/lib/FieldLab/V2.pm`.

Lineage routers under `perl/lib/FieldLab/` choose among remote pulls, fixture snapshots, and archived export tensors.
