# Architecture

## HTTP service

`drift_api` listens on `127.0.0.1:8099` and reads `/app/store/seed`. On first boot it seeds five replay rows from `pk-core` catalog data.

Routes:

- `GET /runs` — array of `{run_id, dim, kind}`
- `GET /covariance/{run_id}` — `{run_id, dim, lower_packed}`
- `GET /observations/{run_id}` — `{run_id, dim, innovations}`

## Perl reporter

`perl/cmd/m_export.pl` is the release export driver; `perl/cmd/x7_batch.pl` is an alternate batch path that reads policy or disk catalogs. Scoring helpers split across Mat, Replay, lineage routers, sidecar merge helpers, and remote fetch wrappers.

## Static audit

`/app/bin/path_guard` scans `.pm` and `.pl` files under the reporter tree for banned filesystem references such as the sled seed directory, bundled snapshot directories, or export tensor trees, including split path construction.

## Workspace layout

- `drift-svc/` — axum server
- `path-guard/` — source audit binary
- `pk-core/` — shared catalog types
- `perl/` — reporter and scoring helpers
- `config/` — service and policy knobs
