# Operator notes

## Boot sequence

1. `bash /app/scripts/build.sh` — compiles `drift_api` and `path_guard` into `/app/bin/`.
2. `bash /app/scripts/start_api.sh` — backgrounds the sled-backed service on `127.0.0.1:8099`.
3. Export `APP_ROOT=/app`, `PERL5LIB=/app/perl/lib`, and optionally `DRIFT_API_BASE=http://127.0.0.1:8099`.
4. `perl /app/perl/cmd/m_export.pl` — writes `/app/output/residual_report.json`.

## HTTP probes

Worked examples for the three route families live under `/app/sample_requests/` (`runs.http`, `covariance.http`, `observations.http`). Use them to compare live tensors against the batch export.

## Static audit

`/app/bin/path_guard` walks `.pm` and `.pl` files and rejects sources that embed filesystem literals for snapshot trees, export tensor trees, or the sled seed store.
