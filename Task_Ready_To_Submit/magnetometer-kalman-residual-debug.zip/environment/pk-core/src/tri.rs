pub fn unfold_lower(packed: &[f64], dim: usize) -> Vec<Vec<f64>> {
    let mut l = vec![vec![0.0; dim]; dim];
    let mut k = 0usize;
    for i in 0..dim {
        for j in 0..=i {
            l[i][j] = packed[k];
            k += 1;
        }
    }
    l
}
