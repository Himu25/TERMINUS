use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct RunMeta {
    pub run_id: String,
    pub dim: u32,
    pub kind: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct CovarianceBody {
    pub run_id: String,
    pub dim: u32,
    pub lower_packed: Vec<f64>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ObservationBody {
    pub run_id: String,
    pub dim: u32,
    pub innovations: Vec<f64>,
}

pub fn catalog() -> Vec<(RunMeta, CovarianceBody, ObservationBody)> {
    vec![
        row(
            "lab_north",
            "lab",
            [1.0, 0.0, 1.0, 0.0, 0.0, 1.0],
            [0.4, -0.2, 0.1],
        ),
        row(
            "lab_east",
            "lab",
            [
                1.414_214,
                0.0,
                1.414_214,
                0.0,
                0.0,
                1.414_214,
            ],
            [0.5, 0.5, -0.5],
        ),
        row(
            "cal_sigma",
            "calibration",
            [1.0, 0.88, 0.474_974, 0.88, 0.222_328, 0.419_726],
            [0.9, -0.45, -0.45],
        ),
        row(
            "cal_tau",
            "calibration",
            [1.0, 0.92, 0.391_918, 0.92, 0.187_794, 0.343_996],
            [0.7, -0.35, -0.35],
        ),
        row(
            "cal_phi",
            "calibration",
            [1.0, 0.90, 0.435_890, 0.90, 0.180_000, 0.360_000],
            [0.82, -0.41, -0.41],
        ),
        row(
            "cal_psi",
            "calibration",
            [1.0, 0.85, 0.450_000, 0.85, 0.200_000, 0.380_000],
            [0.3, -0.15, -0.15],
        ),
    ]
}

fn row(
    run_id: &str,
    kind: &str,
    lower: [f64; 6],
    innovations: [f64; 3],
) -> (RunMeta, CovarianceBody, ObservationBody) {
    let meta = RunMeta {
        run_id: run_id.to_string(),
        dim: 3,
        kind: kind.to_string(),
    };
    let cov = CovarianceBody {
        run_id: run_id.to_string(),
        dim: 3,
        lower_packed: lower.to_vec(),
    };
    let obs = ObservationBody {
        run_id: run_id.to_string(),
        dim: 3,
        innovations: innovations.to_vec(),
    };
    (meta, cov, obs)
}

pub fn packed_len(dim: u32) -> usize {
    (dim * (dim + 1) / 2) as usize
}
