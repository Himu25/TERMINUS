#!/bin/bash
set -euo pipefail
cd /app
bash scripts/build.sh
bash scripts/start_api.sh
curl -sf http://127.0.0.1:8099/runs >/dev/null
