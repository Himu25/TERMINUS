use regex::Regex;
use std::{env, fs, path::Path, process::exit};

fn main() {
    let root = env::args()
        .nth(1)
        .unwrap_or_else(|| "/app/perl".to_string());
    let banned = [
        "/app/store/seed",
        "/app/data/fixtures",
        "/app/data/archive",
        "data/fixtures",
        "data/archive",
        "store/seed",
        "fixtures",
        "archive",
        "seed",
    ];
    let mut violations = Vec::new();
    walk(Path::new(&root), &banned, &mut violations);
    if violations.is_empty() {
        return;
    }
    for line in violations {
        eprintln!("path_guard: {line}");
    }
    exit(1);
}

fn walk(dir: &Path, banned: &[&str], out: &mut Vec<String>) {
    let Ok(entries) = fs::read_dir(dir) else {
        return;
    };
    let re = Regex::new(r#"(['"])(/app/[^'"]+|[^'"]*fixtures[^'"]*)['"]"#).unwrap();
    for entry in entries.flatten() {
        let path = entry.path();
        if path.is_dir() {
            walk(&path, banned, out);
            continue;
        }
        if path.extension().and_then(|s| s.to_str()) != Some("pm")
            && path.extension().and_then(|s| s.to_str()) != Some("pl")
        {
            continue;
        }
        let Ok(text) = fs::read_to_string(&path) else {
            continue;
        };
        for (lineno, line) in text.lines().enumerate() {
            if line_references_banned_path(line) {
                out.push(format!(
                    "{}:{} references banned fixture or seed path",
                    path.display(),
                    lineno + 1
                ));
            }
        }
        for cap in re.captures_iter(&text) {
            let token = cap.get(2).map(|m| m.as_str()).unwrap_or("");
            if banned.iter().any(|needle| token.contains(needle)) {
                out.push(format!("{} references banned path {token}", path.display()));
            }
        }
    }
}

fn line_references_banned_path(line: &str) -> bool {
    let trimmed = line.trim();
    if trimmed.starts_with('#') {
        return false;
    }
    let lower = line.to_lowercase();
    let whole_path = [
        "/app/data/fixtures",
        "data/fixtures",
        "/app/data/archive",
        "data/archive",
        "/app/store/seed",
        "store/seed",
    ];
    if whole_path.iter().any(|needle| lower.contains(needle)) {
        return true;
    }
    (lower.contains("catfile") && lower.contains("fixtures"))
        || (lower.contains("catfile") && lower.contains("archive"))
}
