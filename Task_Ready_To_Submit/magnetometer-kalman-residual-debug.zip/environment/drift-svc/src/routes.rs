use axum::{
    extract::{Path, State},
    http::StatusCode,
    response::IntoResponse,
    Json,
};
use pk_core::{CovarianceBody, ObservationBody, RunMeta};
use sled::Db;
use std::sync::Arc;

#[derive(Clone)]
pub struct AppState {
    pub db: Arc<Db>,
}

pub async fn list_runs(State(state): State<AppState>) -> impl IntoResponse {
    match crate::seed::list_runs(&state.db) {
        Ok(rows) => Json(rows).into_response(),
        Err(err) => (StatusCode::INTERNAL_SERVER_ERROR, err.to_string()).into_response(),
    }
}

pub async fn fetch_cov(
    State(state): State<AppState>,
    Path(run_id): Path<String>,
) -> impl IntoResponse {
    match crate::seed::load_cov(&state.db, &run_id) {
        Ok(Some(body)) => Json(body).into_response(),
        Ok(None) => (StatusCode::NOT_FOUND, "missing run").into_response(),
        Err(err) => (StatusCode::INTERNAL_SERVER_ERROR, err.to_string()).into_response(),
    }
}

pub async fn fetch_obs(
    State(state): State<AppState>,
    Path(run_id): Path<String>,
) -> impl IntoResponse {
    match crate::seed::load_obs(&state.db, &run_id) {
        Ok(Some(body)) => Json(body).into_response(),
        Ok(None) => (StatusCode::NOT_FOUND, "missing run").into_response(),
        Err(err) => (StatusCode::INTERNAL_SERVER_ERROR, err.to_string()).into_response(),
    }
}

pub type RunsResponse = Json<Vec<RunMeta>>;
pub type CovResponse = Json<CovarianceBody>;
pub type ObsResponse = Json<ObservationBody>;
