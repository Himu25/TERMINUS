use pk_core::{catalog, CovarianceBody, ObservationBody, RunMeta};
use sled::Db;

pub fn populate(db: &Db) -> sled::Result<()> {
    for (meta, cov, obs) in catalog() {
        db.insert(format!("run:{}", meta.run_id), serde_json::to_vec(&meta).unwrap())?;
        db.insert(
            format!("cov:{}", cov.run_id),
            serde_json::to_vec(&cov).unwrap(),
        )?;
        db.insert(
            format!("obs:{}", obs.run_id),
            serde_json::to_vec(&obs).unwrap(),
        )?;
    }
    db.insert("boot:ready", b"1")?;
    db.flush()?;
    Ok(())
}

pub fn list_runs(db: &Db) -> sled::Result<Vec<RunMeta>> {
    let mut out: Vec<RunMeta> = Vec::new();
    for item in db.scan_prefix("run:") {
        let (_, raw) = item?;
        out.push(serde_json::from_slice(&raw).unwrap());
    }
    out.sort_by(|a, b| a.run_id.cmp(&b.run_id));
    Ok(out)
}

pub fn load_cov(db: &Db, run_id: &str) -> sled::Result<Option<CovarianceBody>> {
    Ok(db
        .get(format!("cov:{run_id}"))?
        .map(|raw| serde_json::from_slice(&raw).unwrap()))
}

pub fn load_obs(db: &Db, run_id: &str) -> sled::Result<Option<ObservationBody>> {
    Ok(db
        .get(format!("obs:{run_id}"))?
        .map(|raw| serde_json::from_slice(&raw).unwrap()))
}
