mod routes;
mod seed;

use axum::{routing::get, Router};
use routes::AppState;
use std::{env, net::SocketAddr, sync::Arc};
use tower_http::trace::TraceLayer;

#[tokio::main]
async fn main() {
    let store_path = env::var("DRIFT_STORE").unwrap_or_else(|_| "/app/store/seed".to_string());
    let bind = env::var("DRIFT_BIND").unwrap_or_else(|_| "127.0.0.1:8099".to_string());

    let db = sled::open(&store_path).expect("open sled store");
    if db.get("boot:ready".as_bytes()).ok().flatten().is_none() {
        seed::populate(&db).expect("seed sled store");
    }

    let state = AppState { db: Arc::new(db) };
    let app = Router::new()
        .route("/runs", get(routes::list_runs))
        .route("/covariance/:run_id", get(routes::fetch_cov))
        .route("/observations/:run_id", get(routes::fetch_obs))
        .layer(TraceLayer::new_for_http())
        .with_state(state);

    let addr: SocketAddr = bind.parse().expect("bind address");
    let listener = tokio::net::TcpListener::bind(addr)
        .await
        .expect("listen");
    axum::serve(listener, app).await.expect("serve");
}
