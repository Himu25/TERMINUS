package FieldLab::W3;
use strict;
use warnings;

use FieldLab::Mat qw(op_unfold op_solve);
use Exporter qw(import);

our @EXPORT_OK = qw(plain_only);

sub plain_only {
    my ($packed, $dim, $vec) = @_;
    my @l = op_unfold($packed, $dim);
    my @w = op_solve(\@l, $vec, $dim);
    my $acc = 0;
    $acc += $_ * $_ for @w;
    return sqrt($acc / @$vec);
}

1;
