package FieldLab::N3;
use strict;
use warnings;

use JSON::PP qw(encode_json);
use Digest::SHA qw(sha256_hex);
use Exporter qw(import);

use FieldLab::V2 qw(elevated_count mission_ready);

our @EXPORT_OK = qw(sort_rows digest_rows attach_digest);

sub sort_rows {
    my ($rows) = @_;
    return [ sort { $a->{run_id} cmp $b->{run_id} } @$rows ];
}

sub digest_rows {
    my ($rows) = @_;
    return substr(sha256_hex(encode_json($rows)), 0, 16);
}

sub attach_digest {
    my ($rows) = @_;
    my $sorted = sort_rows($rows);
    return {
        schema         => 'residual-v1',
        elevated_count => elevated_count($sorted),
        mission_ready  => mission_ready($sorted) ? \1 : \0,
        runs           => $sorted,
        audit_digest   => digest_rows($sorted),
    };
}

1;
