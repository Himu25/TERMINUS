package FieldLab::N6;
use strict;
use warnings;

use Exporter qw(import);

use FieldLab::Mat qw(op_unfold op_solve);

our @EXPORT_OK = qw(row_digest sidecar_digest);

sub row_digest {
    my ($rows) = @_;
    my @ids = sort map { $_->{run_id} } @$rows;
    return join '|', @ids;
}

sub sidecar_digest {
    my ($packed, $dim, $vec) = @_;
    my @l = op_unfold($packed, $dim);
    my @w = op_solve(\@l, $vec, $dim);
    my $acc = 0;
    $acc += $_ * $_ for @w;
    return sprintf('%.4f', sqrt($acc / @$vec));
}

1;
