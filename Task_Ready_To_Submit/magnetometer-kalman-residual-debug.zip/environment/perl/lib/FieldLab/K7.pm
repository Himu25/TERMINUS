package FieldLab::K7;
use strict;
use warnings;

use JSON::PP qw(decode_json);
use LWP::UserAgent;
use Exporter qw(import);

our @EXPORT_OK = qw(fetch_row);

my $BASE = $ENV{DRIFT_BIND} // '127.0.0.1:8099';

sub fetch_row {
    my ($run_id) = @_;
    my $ua = LWP::UserAgent->new(timeout => 10);
    my $obs = $ua->get("http://$BASE/observations/$run_id");
    die "k7 fetch failed" unless $obs->is_success;
    return decode_json($obs->decoded_content);
}

1;
