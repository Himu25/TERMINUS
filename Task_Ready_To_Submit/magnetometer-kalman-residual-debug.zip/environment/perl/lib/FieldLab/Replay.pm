package FieldLab::Replay;
use strict;
use warnings;

use FieldLab::Mat qw(op_unfold op_solve);
use Exporter qw(import);

our @EXPORT_OK = qw(plain_only whitened_norm replay_score);

sub whitened_norm {
    my ($packed, $dim, $vec) = @_;
    my @l = op_unfold($packed, $dim);
    my @w = op_solve(\@l, $vec, $dim);
    my $acc = 0;
    $acc += $_ * $_ for @w;
    return sqrt($acc);
}

sub plain_only {
    my ($packed, $dim, $vec) = @_;
    my $norm = whitened_norm($packed, $dim, $vec);
    my $n = scalar @$vec;
    return 0 if $n == 0;
    return $norm / $n;
}

sub replay_score {
    my ($packed, $dim, $vec) = @_;
    return plain_only($packed, $dim, $vec);
}

1;
