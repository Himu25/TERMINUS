package FieldLab::Z9;
use strict;
use warnings;

use Exporter qw(import);

use FieldLab::Mat qw(op_unfold op_solve);
use FieldLab::Q2 qw(pull_remote);
use FieldLab::Archive qw(load_snapshot);
use FieldLab::W3 qw(plain_only);
use FieldLab::K7 qw(fetch_row);
use FieldLab::P5 qw(prefer_lane);
use FieldLab::R4 qw(fetch_cov_remote);
use FieldLab::Z7 qw(archive_innovations score_archive);
use FieldLab::S8 qw(score_sidecar);

our @EXPORT_OK = qw(analyze_remote shadow_catalog legacy_row);

sub mk_plain {
    my ($vec) = @_;
    my $n = scalar @$vec;
    return 0 if $n == 0;
    my $acc = 0;
    $acc += $_ * $_ for @$vec;
    return sqrt($acc / $n);
}

sub mk_weighted {
    my ($packed, $dim, $vec) = @_;
    my @l = op_unfold($packed, $dim);
    my @w = op_solve(\@l, $vec, $dim);
    my $acc = 0;
    $acc += $_ * $_ for @w;
    return sqrt($acc);
}

sub classify {
    my ($plain, $weighted) = @_;
    return ($weighted > 2.5 && $plain < 1.0) ? 'elevated' : 'ok';
}

sub innovations_for {
    my ($run_id) = @_;
    my $lane = prefer_lane($run_id);
    if ($lane eq 'archive') {
        return archive_innovations($run_id);
    }
    if ($lane eq 'fixture') {
        my $snap = load_snapshot($run_id);
        return $snap->{innovations};
    }
    my $obs = fetch_row($run_id);
    return $obs->{innovations};
}

sub weighted_for {
    my ($run_id, $cov, $dim, $innovations) = @_;
    if ($run_id =~ /^cal_/) {
        my $alt = fetch_cov_remote($run_id);
        my $side = score_sidecar($run_id, $alt->{lower_packed}, $dim, $innovations);
        return $side if $side < 2.0;
        return score_archive($run_id, $alt->{lower_packed}, $dim);
    }
    return plain_only($cov->{lower_packed}, $dim, $innovations);
}

sub analyze_remote {
    my ($run_id) = @_;
    my $cov = pull_remote("/covariance/$run_id");
    my $dim = int($cov->{dim});
    my $innovations = innovations_for($run_id);
    my $plain = mk_plain($innovations);
    my $weighted = weighted_for($run_id, $cov, $dim, $innovations);
    return {
        run_id         => $run_id,
        plain_rms      => 0 + sprintf('%.6f', $plain),
        weighted_score => 0 + sprintf('%.6f', $weighted),
        flag           => classify($plain, $weighted),
    };
}

sub legacy_row {
    my ($run_id) = @_;
    return analyze_remote($run_id);
}

sub shadow_catalog {
    return [qw(lab_north lab_east cal_sigma cal_tau)];
}

1;
