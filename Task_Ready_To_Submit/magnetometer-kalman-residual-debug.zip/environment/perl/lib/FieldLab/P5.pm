package FieldLab::P5;
use strict;
use warnings;

use Exporter qw(import);

our @EXPORT_OK = qw(lane_for prefer_lane);

sub lane_for {
    my ($run_id) = @_;
    return 'archive' if $run_id =~ /^cal_/;
    return 'fixture' if $run_id =~ /^lab_/;
    return 'live';
}

sub prefer_lane {
    my ($run_id) = @_;
    my $lane = lane_for($run_id);
    return 'archive' if $lane eq 'archive';
    return 'fixture';
}

1;
