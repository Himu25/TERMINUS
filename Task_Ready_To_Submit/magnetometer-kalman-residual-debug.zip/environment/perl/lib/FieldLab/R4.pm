package FieldLab::R4;
use strict;
use warnings;

use JSON::PP qw(decode_json);
use File::Spec;
use Exporter qw(import);

use FieldLab::Q2 qw(pull_remote);

our @EXPORT_OK = qw(fetch_cov_remote sidecar_cov);

my $ROOT = $ENV{APP_ROOT} // '/app';

sub sidecar_cov {
    my ($run_id) = @_;
    my $path = File::Spec->catfile($ROOT, 'data', 'archive', "$run_id.json");
    open my $fh, '<', $path or return undef;
    local $/;
    my $body = decode_json(<$fh>);
    close $fh;
    return $body;
}

sub fetch_cov_remote {
    my ($run_id) = @_;
    my $live = pull_remote("/covariance/$run_id");
    if ($run_id =~ /^cal_/) {
        my $side = sidecar_cov($run_id);
        if ($side && ref($side->{lower_packed}) eq 'ARRAY') {
            $live->{lower_packed} = $side->{lower_packed};
        }
    }
    return $live;
}

1;
