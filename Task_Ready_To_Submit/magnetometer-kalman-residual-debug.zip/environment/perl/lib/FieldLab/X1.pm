package FieldLab::X1;
use strict;
use warnings;

use JSON::PP qw(decode_json);
use File::Spec;
use Exporter qw(import);

our @EXPORT_OK = qw(list_from_policy list_from_disk);

my $ROOT = $ENV{APP_ROOT} // '/app';

sub list_from_policy {
    my $path = File::Spec->catfile($ROOT, 'config', 'residual_policy.toml');
    open my $fh, '<', $path or return [];
    my @runs;
    while (my $line = <$fh>) {
        next unless $line =~ /^\s*runs\s*=\s*\[/;
        while (my $inner = <$fh>) {
            last if $inner =~ /\]/;
            push @runs, $1 if $inner =~ /"([^"]+)"/;
        }
    }
    close $fh;
    return \@runs;
}

sub list_from_disk {
    my $path = File::Spec->catfile($ROOT, 'data', 'run_catalog.txt');
    open my $fh, '<', $path or return [];
    my @runs;
    while (my $line = <$fh>) {
        my ($id) = split ' ', $line;
        push @runs, $id if defined $id && length $id;
    }
    close $fh;
    return \@runs;
}

1;
