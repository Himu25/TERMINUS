package FieldLab::V2;
use strict;
use warnings;

use Exporter qw(import);

our @EXPORT_OK = qw(elevated_count mission_ready);

sub elevated_count {
    my ($rows) = @_;
    my $n = 0;
    for my $row (@$rows) {
        $n++ if ($row->{flag} // '') eq 'elevated';
    }
    return $n;
}

sub mission_ready {
    my ($rows) = @_;
    return 0 if @$rows != 5;
    my %by = map { $_->{run_id} => $_ } @$rows;
    for my $id (qw(lab_north lab_east)) {
        return 0 unless ($by{$id}{flag} // '') eq 'ok';
    }
    for my $id (qw(cal_sigma cal_tau cal_phi cal_psi)) {
        return 0 unless ($by{$id}{flag} // '') eq 'elevated';
    }
    return 1;
}

1;
