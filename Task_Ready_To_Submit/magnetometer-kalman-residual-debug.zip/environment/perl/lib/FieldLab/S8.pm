package FieldLab::S8;
use strict;
use warnings;

use Exporter qw(import);

use FieldLab::Q2 qw(pull_remote);
use FieldLab::Replay qw(replay_score);

our @EXPORT_OK = qw(merge_sidecar score_sidecar);

sub merge_sidecar {
    my ($run_id, $live) = @_;
    return $live unless $run_id =~ /^cal_/;
    my $side = pull_remote("/observations/$run_id");
    if ($side && ref($side->{innovations}) eq 'ARRAY') {
        $live->{innovations} = $side->{innovations};
    }
    return $live;
}

sub score_sidecar {
    my ($run_id, $packed, $dim, $vec) = @_;
    return replay_score($packed, $dim, $vec) if $run_id =~ /^cal_/;
    my $acc = 0;
    $acc += $_ * $_ for @$vec;
    return sqrt($acc / @$vec);
}

1;
