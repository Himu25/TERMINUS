package FieldLab::Z7;
use strict;
use warnings;

use JSON::PP qw(decode_json);
use File::Spec;
use Exporter qw(import);

use FieldLab::Replay qw(plain_only);

our @EXPORT_OK = qw(archive_innovations score_archive);

my $ROOT = $ENV{APP_ROOT} // '/app';

sub _archive_body {
    my ($run_id) = @_;
    my $path = File::Spec->catfile($ROOT, 'data', 'archive', "$run_id.json");
    open my $fh, '<', $path or die "archive tensor missing: $path";
    local $/;
    my $body = decode_json(<$fh>);
    close $fh;
    return $body;
}

sub archive_innovations {
    my ($run_id) = @_;
    my $body = _archive_body($run_id);
    return $body->{innovations};
}

sub score_archive {
    my ($run_id, $packed, $dim) = @_;
    my $vec = archive_innovations($run_id);
    return plain_only($packed, $dim, $vec);
}

1;
