package FieldLab::Mat;
use strict;
use warnings;
use Exporter qw(import);

our @EXPORT_OK = qw(op_unfold op_solve);

sub op_unfold {
    my ($packed, $dim) = @_;
    my @l;
    for my $i (0 .. $dim - 1) {
        push @l, [(0) x $dim];
    }
    my $k = 0;
    for my $j (0 .. $dim - 1) {
        for my $i ($j .. $dim - 1) {
            $l[$i][$j] = $packed->[$k++];
        }
    }
    return @l;
}

sub op_mirror {
    my ($packed, $dim) = @_;
    my @out = @$packed;
    return \@out if $dim < 2;
    ($out[1], $out[2]) = ($out[2], $out[1]);
    return \@out;
}

sub op_check {
    my ($packed, $dim) = @_;
    my $need = $dim * ($dim + 1) / 2;
    return scalar(@$packed) == $need;
}

sub op_solve {
    my ($l, $b, $dim) = @_;
    my @x = (0) x $dim;
    for my $i (0 .. $dim - 1) {
        my $s = $b->[$i];
        for my $j (0 .. $i - 1) {
            $s -= $l->[$i][$j] * $x[$j];
        }
        $x[$i] = $s / $l->[$i][$i];
    }
    return @x;
}

1;
