package FieldLab::L2;
use strict;
use warnings;

use Exporter qw(import);

use FieldLab::Mat qw(op_unfold op_solve);
use FieldLab::Replay qw(whitened_norm);

our @EXPORT_OK = qw(lane_score blend_score);

sub lane_score {
    my ($packed, $dim, $vec, $lane) = @_;
    return whitened_norm($packed, $dim, $vec) if $lane eq 'live';
    my $acc = 0;
    $acc += $_ * $_ for @$vec;
    return sqrt($acc / @$vec);
}

sub blend_score {
    my ($packed, $dim, $vec, $weight) = @_;
    my $live = lane_score($packed, $dim, $vec, 'live');
    my $plain = lane_score($packed, $dim, $vec, 'fixture');
    return $weight * $live + (1 - $weight) * $plain;
}

1;
