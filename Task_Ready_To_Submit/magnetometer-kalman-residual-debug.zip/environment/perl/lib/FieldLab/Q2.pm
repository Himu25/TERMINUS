package FieldLab::Q2;
use strict;
use warnings;

use JSON::PP qw(decode_json);
use LWP::UserAgent;
use Exporter qw(import);

our @EXPORT_OK = qw(pull_remote);

my $BASE = $ENV{DRIFT_API_BASE} // 'http://127.0.0.1:8099';

sub pull_remote {
    my ($path) = @_;
    my $ua = LWP::UserAgent->new(timeout => 10);
    my $resp = $ua->get("$BASE$path");
    die "remote fetch failed for $path: " . $resp->status_line unless $resp->is_success;
    return decode_json($resp->decoded_content);
}

1;
