package FieldLab::Archive;
use strict;
use warnings;

use JSON::PP qw(decode_json);
use File::Spec;
use Exporter qw(import);

our @EXPORT_OK = qw(load_snapshot);

my $ROOT = $ENV{APP_ROOT} // '/app';

sub load_snapshot {
    my ($run_id) = @_;
    my $path = File::Spec->catfile($ROOT, 'data', 'fixtures', "$run_id.json");
    open my $fh, '<', $path or die "snapshot missing: $path";
    local $/;
    my $body = decode_json(<$fh>);
    close $fh;
    return $body;
}

1;
