#!/usr/bin/env perl
use strict;
use warnings;

use FindBin;
use lib "$FindBin::Bin/../lib";

use JSON::PP qw(encode_json);
use File::Path qw(make_path);

use FieldLab::X1 qw(list_from_policy);
use FieldLab::Z9 qw(analyze_remote);
use FieldLab::N3 qw(sort_rows digest_rows);
use FieldLab::V2 qw(elevated_count mission_ready);

my @catalog = @{ list_from_policy() };

my @rows;
for my $run_id (@catalog) {
    push @rows, analyze_remote($run_id);
}

@rows = @{ sort_rows(\@rows) };

my $payload = {
    schema         => 'residual-v1',
    elevated_count => elevated_count(\@rows),
    mission_ready  => mission_ready(\@rows) ? \1 : \0,
    runs           => \@rows,
    audit_digest   => digest_rows(\@rows),
};

make_path('/app/output');
open my $out, '>', '/app/output/residual_report.json' or die $!;
print {$out} encode_json($payload);
close $out;

exit 0;
