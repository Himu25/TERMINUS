#!/usr/bin/env perl
use strict;
use warnings;

use FindBin;
use lib "$FindBin::Bin/../lib";

use JSON::PP qw(encode_json);
use File::Path qw(make_path);

use FieldLab::Z9 qw(analyze_remote shadow_catalog);
use FieldLab::X1 qw(list_from_policy list_from_disk);
use FieldLab::N3 qw(sort_rows digest_rows);

my $mode = $ENV{FIELDLAB_CATALOG} // 'shadow';
my @catalog = do {
    if ($mode eq 'policy') {
        @{ list_from_policy() };
    }
    elsif ($mode eq 'disk') {
        @{ list_from_disk() };
    }
    else {
        @{ shadow_catalog() };
    }
};

my @rows;
for my $run_id (@catalog) {
    push @rows, analyze_remote($run_id);
}

@rows = @{ sort_rows(\@rows) };

my $payload = {
    schema         => 'residual-v1',
    elevated_count => 0,
    mission_ready  => \0,
    runs           => \@rows,
    audit_digest   => digest_rows(\@rows),
};

make_path('/app/output');
open my $out, '>', '/app/output/residual_report.json' or die $!;
print {$out} encode_json($payload);
close $out;

exit 0;
