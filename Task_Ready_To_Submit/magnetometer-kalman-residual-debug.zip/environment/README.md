# Magnetometer drift replay lab

The Cargo workspace hosts `drift_api`, a sled-backed HTTP service, and `path_guard`, a static source audit for Perl reporters. Perl tooling under `perl/` emits residual summaries for calibration replays.

Build everything with `scripts/build.sh`. Start the API with `scripts/start_api.sh`. Run the batch driver with `scripts/run_report.sh` after exporting `PERL5LIB=/app/perl/lib`. Remote pulls honor `DRIFT_API_BASE` from `config/service.toml`. The reporter reads `APP_ROOT` from the environment (default `/app`). Static audit: `/app/bin/path_guard /app/perl` must exit zero on a clean reporter tree.

Output lands in `/app/output/residual_report.json`.
