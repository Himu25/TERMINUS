#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/relief.toml
require_file /app/data/region_manifest.jsonl
require_file /app/data/corridor_conditions.csv
require_file /app/data/field_reports.csv
mkdir -p /app/bin /app/output

log "apply patched sources"
cp "${ROOT_DIR}/oracle/p2_order.go" /app/q9/p2_order.go
cp "${ROOT_DIR}/oracle/d4_hold.go" /app/k2/d4_hold.go
cp "${ROOT_DIR}/oracle/b7_slot.go" /app/h4/b7_slot.go
cp "${ROOT_DIR}/oracle/w5_roll.go" /app/z1/w5_roll.go
cp "${ROOT_DIR}/oracle/lib.rs" /app/n8/src/lib.rs

log "rebuild dispatcher"
bash /app/scripts/build.sh
rm -rf /app/n8/target /app/output/go-build

log "refresh default region bundle"
/app/bin/regionpack /app/data/region_manifest.jsonl /app/data/regions_default.jsonl

log "emit default dispatch report"
/app/tools/run_convoy

log "post-run validation against relief.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/relief.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k in ("min_coverage_rate", "max_surplus_ratio", "min_humanitarian_value"):
        cfg[k] = float(v)
    elif k.startswith("max_") or k.startswith("min_") or k == "fleet_capacity_tons":
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/convoy_report.json").read_text())
assert report["status"] == "ok", report
assert report["coverage_rate"] >= cfg["min_coverage_rate"]
assert report["surplus_ratio"] <= cfg["max_surplus_ratio"]
assert report["route_violations"] <= cfg["max_route_violations"]
assert report["priority_inversions"] <= cfg["max_priority_inversions"]
assert report["convoy_buffer_tons"] >= cfg["min_convoy_buffer_tons"]
assert report["humanitarian_value"] >= cfg["min_humanitarian_value"]
for row in report["regions"]:
    if row["region_id"].startswith("r_dep_") and row["served"]:
        assert row["route_ready"], row
    if row["region_id"].startswith("r_convoy_"):
        assert row["served"], row
print("ok", report["coverage_rate"], report["surplus_ratio"], report["humanitarian_value"])
PY

log "oracle complete"
