package q9

import (
	"sort"

	"rcd.relief/pkg/types"
)

// RxOrder ranks pending regions for relief convoy dispatch.
func RxOrder(cases []types.RegionCase) []types.RegionCase {
	out := make([]types.RegionCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		a, b := out[i], out[j]
		if a.ReportRevision != b.ReportRevision {
			return a.ReportRevision > b.ReportRevision
		}
		if a.Urgency != b.Urgency {
			return a.Urgency > b.Urgency
		}
		if a.NeedScore != b.NeedScore {
			return a.NeedScore > b.NeedScore
		}
		return a.RegionID < b.RegionID
	})
	return out
}
