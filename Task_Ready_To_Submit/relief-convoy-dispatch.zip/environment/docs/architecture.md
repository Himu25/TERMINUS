Relief convoy dispatch ties together a Go driver, Rust route meter, and bash runners under /app.
The driver reads region manifests, corridor passability tables, and field reports.
When est_tons is zero, the meter resolves billable tons from field report telemetry.
