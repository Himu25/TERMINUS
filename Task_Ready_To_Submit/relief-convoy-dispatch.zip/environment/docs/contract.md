# Convoy report contract

## Top-level fields

- status: ok when guardrails pass, otherwise fail
- fleet_capacity_tons: daily pool from relief.toml
- tons_shipped: billable tons consumed by served regions
- tons_surplus: reservation surplus summed across regions
- regions_total: input JSONL row count
- regions_served: regions marked served
- coverage_rate: regions_served divided by regions_total
- surplus_ratio: tons_surplus divided by tons_shipped
- route_violations: regions dispatched before route dependencies finished
- priority_inversions: served regions whose rank score fell below a prior finish
- convoy_buffer_tons: convoy headroom tons absorbed during waves
- humanitarian_value: weighted need score total for served regions
- report_digest: SHA-256 lowercase hex of the digest pre-image (see report_digest section)
- regions: per-region rows

## Region row fields

- region_id, cluster, urgency
- tons_reserved, tons_delivered, surplus_tons
- served, route_ready, dispatch_rank, convoy_wave, humanitarian_value

## Dispatch order

Pending regions are sorted before allocation using, in order:

1. report_revision descending (late field reports outrank stale rows)
2. urgency descending
3. need_score descending
4. region_id ascending (stable tie-break)

## dispatch_rank

1-based position in the scheduler processing order after the sort above. Lower dispatch_rank means the region was scheduled earlier.

## Priority inversions

For each served region, form rank score = report_revision * 10 + urgency. priority_inversions counts how often a served region's rank score is greater than the rank score of an earlier-served region.

## Corridor passability

corridor_conditions.csv supplies dry_scale, wet_scale, and wet_after per corridor_id. The Rust meter spans each region from depart_slot for a duration in slot units taken from act_tons when positive, otherwise est_tons (minimum 1). When depart_slot plus duration is at or before wet_after, dry_scale applies; when depart_slot is at or after wet_after, wet_scale applies; when the span crosses wet_after, compute integer scales in this order (floor division at each step, no floating-point rounding):

1. pre_slots = max(0, wet_after − depart_slot)
2. post_slots = duration − pre_slots
3. scale = (pre_slots × dry_scale + post_slots × wet_scale) // duration
4. billable = raw × scale // 100

Use the same raw tonnage as duration (act_tons when positive, otherwise est_tons). Clamp scale to at least 1 before step 4. Without a matching field report, corridor scaling shapes tons_reserved and can cap tons_delivered; eu-west scales below us-east for the same raw act_tons when the corridor tables diverge.

## Drift and ton accounting

- tons_reserved: reservation size from est_tons when est_tons is positive; when est_tons is zero and field_reports.csv supplies a row, tons_reserved is the field-report act_tons verbatim (equal to tons_delivered, surplus_tons zero); when est_tons is zero without a field report, reservation equals corridor billable tons from the integer blend above
- tons_delivered: field-report act_tons verbatim when field_reports.csv supplies a value (this overrides corridor scaling); otherwise corridor-scaled actual unload capped by tons_reserved when region act_tons is positive, or blended billable actual when act_tons is zero
- surplus_tons: tons_reserved minus tons_delivered (zero when reserved is not greater than delivered)
- Conflicting-report drift rows keep the estimate reservation even when actual unload is lower, so surplus_tons reflects reserved minus delivered
- Zero-estimate rows with a field overlay therefore carry tons_reserved and tons_delivered both equal to field-report act_tons verbatim; do not corridor-scale the reservation for these rows

## report_digest

Pre-image is one JSON object containing every top-level report field with report_digest set to the empty string. Top-level keys appear in this order: status, fleet_capacity_tons, tons_shipped, tons_surplus, regions_total, regions_served, coverage_rate, surplus_ratio, route_violations, priority_inversions, convoy_buffer_tons, humanitarian_value, report_digest, regions. Each regions entry lists keys in this order: region_id, cluster, urgency, tons_reserved, tons_delivered, served, route_ready, dispatch_rank, surplus_tons, convoy_wave, humanitarian_value; array order follows dispatch_rank ascending.

Serialize the pre-image as compact JSON: no insignificant whitespace, HTML escaping off, no trailing newline. Hash the UTF-8 bytes with SHA-256 and write the lowercase hex digest to report_digest. The written convoy_report.json file may use indented JSON; only this compact pre-image participates in the digest.
