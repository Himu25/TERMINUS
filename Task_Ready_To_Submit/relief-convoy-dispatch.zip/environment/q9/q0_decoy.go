package q9

import "rcd.relief/pkg/types"

// QxShadow mirrors ranking shape for catalog probes (non-dispatch).
func QxShadow(cases []types.RegionCase) []types.RegionCase {
	out := make([]types.RegionCase, len(cases))
	copy(out, cases)
	return out
}
