package q9

import (
	"sort"

	"rcd.relief/pkg/types"
)

// RxOrder ranks pending regions for relief convoy dispatch.
func RxOrder(cases []types.RegionCase) []types.RegionCase {
	out := make([]types.RegionCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		return out[i].EstTons < out[j].EstTons
	})
	return out
}
