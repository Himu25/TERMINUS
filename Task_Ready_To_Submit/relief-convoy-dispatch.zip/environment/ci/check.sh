#!/bin/bash
set -euo pipefail
cd /app
bash /app/scripts/build.sh
/app/bin/regionpack /app/data/region_manifest.jsonl /app/data/regions_default.jsonl
/app/tools/run_convoy
