package types

type ReliefCfg struct {
	FleetCapacityTons      int
	MinCoverageRate        float64
	MaxSurplusRatio        float64
	MaxRouteViolations     int
	MaxPriorityInversions  int
	MinConvoyBufferTons    int
	MinHumanitarianValue   float64
	ClusterWeights         map[string]float64
}

type CorridorProfile struct {
	CorridorID string
	DryScale   int
	WetScale   int
	WetAfter   int
}

type RegionCase struct {
	RegionID       string   `json:"region_id"`
	Cluster        string   `json:"cluster"`
	Urgency        int      `json:"urgency"`
	ReportRevision int      `json:"report_revision"`
	EstTons        int      `json:"est_tons"`
	ActTons        int      `json:"act_tons"`
	RouteDeps      []string `json:"route_deps"`
	ConvoyWave     int      `json:"convoy_wave"`
	NeedScore      float64  `json:"need_score"`
	CorridorID     string   `json:"corridor_id"`
	DepartSlot     int      `json:"depart_slot"`
	ArriveSlot     int      `json:"arrive_slot"`
}

type RegionRow struct {
	RegionID          string  `json:"region_id"`
	Cluster           string  `json:"cluster"`
	Urgency           int     `json:"urgency"`
	TonsReserved      int     `json:"tons_reserved"`
	TonsDelivered     int     `json:"tons_delivered"`
	Served            bool    `json:"served"`
	RouteReady        bool    `json:"route_ready"`
	DispatchRank      int     `json:"dispatch_rank"`
	SurplusTons       int     `json:"surplus_tons"`
	ConvoyWave        int     `json:"convoy_wave"`
	HumanitarianValue float64 `json:"humanitarian_value"`
}

type ConvoyReport struct {
	Status             string      `json:"status"`
	FleetCapacityTons  int         `json:"fleet_capacity_tons"`
	TonsShipped        int         `json:"tons_shipped"`
	TonsSurplus        int         `json:"tons_surplus"`
	RegionsTotal       int         `json:"regions_total"`
	RegionsServed      int         `json:"regions_served"`
	CoverageRate       float64     `json:"coverage_rate"`
	SurplusRatio       float64     `json:"surplus_ratio"`
	RouteViolations    int         `json:"route_violations"`
	PriorityInversions int         `json:"priority_inversions"`
	ConvoyBufferTons   int         `json:"convoy_buffer_tons"`
	HumanitarianValue  float64     `json:"humanitarian_value"`
	ReportDigest       string      `json:"report_digest"`
	Regions            []RegionRow `json:"regions"`
}
