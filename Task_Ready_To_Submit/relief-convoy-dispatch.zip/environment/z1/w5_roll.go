package z1

// VxRoll totals surplus tons for one convoy wave.
func VxRoll(reserved, used int) int {
	_ = reserved
	_ = used
	return 0
}
