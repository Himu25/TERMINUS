package summ

import "rcd.relief/pkg/types"

// SxFold folds region rows for telemetry export (non-scheduling).
func SxFold(rows []types.RegionRow) int {
	total := 0
	for _, row := range rows {
		total += row.TonsDelivered
	}
	return total
}
