package drv

import (
	"rcd.relief/n8"
	"rcd.relief/pkg/types"
	"rcd.relief/z1"
)

func meterBillable(jc types.RegionCase, fieldReportVal int, rp types.CorridorProfile) int {
	dryScale := rp.DryScale
	wetScale := rp.WetScale
	wetAfter := rp.WetAfter
	if fieldReportVal > 0 {
		dryScale, wetScale, wetAfter = 100, 100, 0
	}
	roll := n8.MeterSpan(
		jc.EstTons, jc.ActTons, fieldReportVal,
		dryScale, wetScale, wetAfter, jc.DepartSlot,
	)
	if roll.Billable > 0 {
		return roll.Billable
	}
	return jc.EstTons
}

func regionSurplus(reserved, used int) int {
	return z1.VxRoll(reserved, used)
}
