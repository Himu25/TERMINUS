package drv

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"

	"rcd.relief/k2"
	"rcd.relief/pkg/types"
	"rcd.relief/q9"
	"rcd.relief/summ"
	"rcd.relief/u3"
)

func LoadCfg(path string) (types.ReliefCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.ReliefCfg{}, err
	}
	cfg := types.ReliefCfg{
		FleetCapacityTons:     12000,
		MinCoverageRate:     0.75,
		MaxSurplusRatio:         0.35,
		MaxRouteViolations:      0,
		MaxPriorityInversions: 1,
		MinConvoyBufferTons:      3,
		MinHumanitarianValue:     2.0,
		ClusterWeights:           map[string]float64{"cluster_alpha": 1.0, "cluster_beta": 1.0, "cluster_gamma": 1.0},
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "fleet_capacity_tons":
			fmt.Sscanf(val, "%d", &cfg.FleetCapacityTons)
		case "min_coverage_rate":
			fmt.Sscanf(val, "%f", &cfg.MinCoverageRate)
		case "max_surplus_ratio":
			fmt.Sscanf(val, "%f", &cfg.MaxSurplusRatio)
		case "max_route_violations":
			fmt.Sscanf(val, "%d", &cfg.MaxRouteViolations)
		case "max_priority_inversions":
			fmt.Sscanf(val, "%d", &cfg.MaxPriorityInversions)
		case "min_convoy_buffer_tons":
			fmt.Sscanf(val, "%d", &cfg.MinConvoyBufferTons)
		case "min_humanitarian_value":
			fmt.Sscanf(val, "%f", &cfg.MinHumanitarianValue)
		case "cluster_weight_alpha":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClusterWeights["cluster_alpha"] = w
		case "cluster_weight_beta":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClusterWeights["cluster_beta"] = w
		case "cluster_weight_gamma":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClusterWeights["cluster_gamma"] = w
		}
	}
	return cfg, nil
}

func LoadCorridors(path string) (map[string]types.CorridorProfile, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]types.CorridorProfile)
	for i, row := range rows {
		if i == 0 || len(row) < 4 {
			continue
		}
		var peak, renew, after int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &peak)
		fmt.Sscanf(strings.TrimSpace(row[2]), "%d", &renew)
		fmt.Sscanf(strings.TrimSpace(row[3]), "%d", &after)
		id := strings.TrimSpace(row[0])
		out[id] = types.CorridorProfile{
			CorridorID: id,
			DryScale:  peak,
			WetScale: renew,
			WetAfter: after,
		}
	}
	return out, nil
}

func LoadRegionCases(path string) ([]types.RegionCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.RegionCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var jc types.RegionCase
		if err := json.Unmarshal([]byte(line), &jc); err != nil {
			return nil, err
		}
		if jc.CorridorID == "" {
			jc.CorridorID = "us-east"
		}
		out = append(out, jc)
	}
	return out, sc.Err()
}

func LoadFieldReports(path string) (map[string]int, error) {
	f, err := os.Open(path)
	if err != nil {
		return map[string]int{}, nil
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]int)
	for i, row := range rows {
		if i == 0 || len(row) < 2 {
			continue
		}
		var actTons int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &actTons)
		out[strings.TrimSpace(row[0])] = actTons
	}
	return out, nil
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

func corridorFor(jc types.RegionCase, corridors map[string]types.CorridorProfile) types.CorridorProfile {
	if rp, ok := corridors[jc.CorridorID]; ok {
		return rp
	}
	return types.CorridorProfile{CorridorID: jc.CorridorID, DryScale: 100, WetScale: 100, WetAfter: 0}
}

func Run(cfg types.ReliefCfg, cases []types.RegionCase, fieldReports map[string]int, corridors map[string]types.CorridorProfile) (types.ConvoyReport, error) {
	ordered := q9.RxOrder(cases)
	report := types.ConvoyReport{
		Status:            "ok",
		FleetCapacityTons: cfg.FleetCapacityTons,
		RegionsTotal:         len(ordered),
	}
	done := make(map[string]bool)
	budgetLeft := cfg.FleetCapacityTons
	var spent, totalWaste, completed, depViol, inversions, renewTotal int
	var valueTotal float64
	prevRank := -1
	report.Regions = make([]types.RegionRow, 0, len(ordered))

	for idx, jc := range ordered {
		actualReady := true
		for _, depID := range jc.RouteDeps {
			if !done[depID] {
				actualReady = false
				break
			}
		}
		depReady := k2.DxGate(jc.RouteDeps, done)
		if len(jc.RouteDeps) > 0 && !actualReady && depReady {
			depViol++
		}
		fieldReportVal := 0
		if act, ok := fieldReports[jc.RegionID]; ok && act > 0 {
			fieldReportVal = act
			jc.ActTons = act
		}
		rp := corridorFor(jc, corridors)
		billable := meterBillable(jc, fieldReportVal, rp)
		reserveNeed := u3.AxNeed(jc.EstTons, billable)
		reserved, ok := u3.BxReserve(budgetLeft, reserveNeed)
		headroom := budgetLeft - reserved
		if jc.ConvoyWave > 0 {
			renewTotal += waveConvoyTotal(jc.ConvoyWave, jc.EstTons, headroom)
		}
		used := 0
		finished := false
		if ok && depReady {
			used = jc.ActTons
			if used <= 0 {
				used = billable
			}
			if used > reserved {
				used = reserved
			}
			budgetLeft -= reserved
			spent += used
			finished = true
			completed++
			done[jc.RegionID] = true
			valueTotal += u3.VxValue(jc.NeedScore, used)
		}
		wasteAmt := regionSurplus(reserved, used)
		totalWaste += wasteAmt
		rankScore := jc.ReportRevision*10 + jc.Urgency
		if finished {
			if prevRank >= 0 && rankScore > prevRank {
				inversions++
			}
			prevRank = rankScore
		}
		row := types.RegionRow{
			RegionID:          jc.RegionID,
			Cluster:           jc.Cluster,
			Urgency:       jc.Urgency,
			TonsReserved:  reserved,
			TonsDelivered:      used,
			Served:      finished,
			RouteReady:       depReady,
			DispatchRank:   idx + 1,
			SurplusTons:     wasteAmt,
			ConvoyWave:      jc.ConvoyWave,
			HumanitarianValue: round4(u3.VxValue(jc.NeedScore, used)),
		}
		report.Regions = append(report.Regions, row)
	}

	report.TonsShipped = spent
	report.TonsSurplus = totalWaste
	report.RegionsServed = completed
	if report.RegionsTotal > 0 {
		report.CoverageRate = round4(float64(completed) / float64(report.RegionsTotal))
	}
	if spent > 0 {
		report.SurplusRatio = round4(float64(totalWaste) / float64(spent))
	}
	report.RouteViolations = depViol
	report.PriorityInversions = inversions
	report.ConvoyBufferTons = renewTotal
	report.HumanitarianValue = round4(valueTotal)
	hasConvoy := false
	for _, jc := range ordered {
		if jc.ConvoyWave > 0 {
			hasConvoy = true
			break
		}
	}
	if !meetsFloors(cfg, report, hasConvoy) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func meetsFloors(cfg types.ReliefCfg, report types.ConvoyReport, hasConvoy bool) bool {
	if report.CoverageRate < cfg.MinCoverageRate {
		return false
	}
	if report.SurplusRatio > cfg.MaxSurplusRatio {
		return false
	}
	if report.RouteViolations > cfg.MaxRouteViolations {
		return false
	}
	if report.PriorityInversions > cfg.MaxPriorityInversions {
		return false
	}
	if report.ConvoyBufferTons < cfg.MinConvoyBufferTons {
		if hasConvoy {
			return false
		}
	}
	if report.HumanitarianValue < cfg.MinHumanitarianValue {
		return false
	}
	for _, row := range report.Regions {
		if strings.HasPrefix(row.RegionID, "r_dep_") && !row.RouteReady && row.Served {
			return false
		}
		if strings.HasPrefix(row.RegionID, "r_convoy_") && row.ConvoyWave > 0 && !row.Served {
			return false
		}
		if strings.HasPrefix(row.RegionID, "r_report_") && row.SurplusTons == 0 && row.TonsReserved > row.TonsDelivered+50 {
			return false
		}
		if strings.HasPrefix(row.RegionID, "r_corridor_") && row.Served && row.TonsDelivered > row.TonsReserved+200 {
			return false
		}
	}
	_ = summ.SxFold(report.Regions)
	return true
}

type digestPayload struct {
	Status              string         `json:"status"`
	FleetCapacityTons   int            `json:"fleet_capacity_tons"`
	TonsShipped          int            `json:"tons_shipped"`
	TonsSurplus          int            `json:"tons_surplus"`
	RegionsTotal           int            `json:"regions_total"`
	RegionsServed       int            `json:"regions_served"`
	CoverageRate      float64        `json:"coverage_rate"`
	SurplusRatio          float64        `json:"surplus_ratio"`
	RouteViolations       int            `json:"route_violations"`
	PriorityInversions  int            `json:"priority_inversions"`
	ConvoyBufferTons    int            `json:"convoy_buffer_tons"`
	HumanitarianValue   float64        `json:"humanitarian_value"`
	ReportDigest        string         `json:"report_digest"`
	Regions             []types.RegionRow `json:"regions"`
}

func digestBody(report types.ConvoyReport) string {
	payload := digestPayload{
		Status:              report.Status,
		FleetCapacityTons:   report.FleetCapacityTons,
		TonsShipped:         report.TonsShipped,
		TonsSurplus:         report.TonsSurplus,
		RegionsTotal:        report.RegionsTotal,
		RegionsServed:       report.RegionsServed,
		CoverageRate:        report.CoverageRate,
		SurplusRatio:        report.SurplusRatio,
		RouteViolations:     report.RouteViolations,
		PriorityInversions:  report.PriorityInversions,
		ConvoyBufferTons:    report.ConvoyBufferTons,
		HumanitarianValue:   report.HumanitarianValue,
		ReportDigest:        "",
		Regions:             report.Regions,
	}
	raw, err := marshalDigestJSON(payload)
	if err != nil {
		return ""
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func marshalDigestJSON(payload digestPayload) ([]byte, error) {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return nil, err
	}
	b := buf.Bytes()
	if n := len(b); n > 0 && b[n-1] == '\n' {
		b = b[:n-1]
	}
	return b, nil
}

func WriteReport(path string, report types.ConvoyReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func p95(values []int) int {
	if len(values) == 0 {
		return 0
	}
	cp := append([]int(nil), values...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}
