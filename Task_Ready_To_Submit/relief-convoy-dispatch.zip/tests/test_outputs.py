"""Validate /app/output/convoy_report.json against relief.toml guardrails."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "convoy_report.json"
REGIONS = APP / "data" / "regions_default.jsonl"
CFG = APP / "config" / "relief.toml"
FIELD_REPORTS = APP / "data" / "field_reports.csv"
CASES = Path(__file__).resolve().parent / "data"

_DEFAULT_REGIONS_TEXT = REGIONS.read_text(encoding="utf-8") if REGIONS.is_file() else ""

REPORT_KEYS = frozenset(
    {
        "status",
        "fleet_capacity_tons",
        "tons_shipped",
        "tons_surplus",
        "regions_total",
        "regions_served",
        "coverage_rate",
        "surplus_ratio",
        "route_violations",
        "priority_inversions",
        "convoy_buffer_tons",
        "humanitarian_value",
        "report_digest",
        "regions",
    }
)
RUN_TIMEOUT_SEC = 120

ROW_KEYS = frozenset(
    {
        "region_id",
        "cluster",
        "urgency",
        "tons_reserved",
        "tons_delivered",
        "surplus_tons",
        "served",
        "route_ready",
        "dispatch_rank",
        "convoy_wave",
        "humanitarian_value",
    }
)

# Key order matches digestPayload / RegionRow struct field order in reliefdisp.
DIGEST_REPORT_KEY_ORDER = (
    "status",
    "fleet_capacity_tons",
    "tons_shipped",
    "tons_surplus",
    "regions_total",
    "regions_served",
    "coverage_rate",
    "surplus_ratio",
    "route_violations",
    "priority_inversions",
    "convoy_buffer_tons",
    "humanitarian_value",
    "report_digest",
    "regions",
)
DIGEST_REGION_KEY_ORDER = (
    "region_id",
    "cluster",
    "urgency",
    "tons_reserved",
    "tons_delivered",
    "served",
    "route_ready",
    "dispatch_rank",
    "surplus_tons",
    "convoy_wave",
    "humanitarian_value",
)

def _corridor_raw_act(regions_text: str) -> int:
    return _region_map_from_text(regions_text)["r_corridor_us"]["act_tons"]


CORRIDOR_CONDITIONS = APP / "data" / "corridor_conditions.csv"


def _load_corridor_profiles() -> dict[str, dict[str, int]]:
    profiles: dict[str, dict[str, int]] = {}
    if not CORRIDOR_CONDITIONS.is_file():
        return profiles
    lines = CORRIDOR_CONDITIONS.read_text(encoding="utf-8").splitlines()
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        corridor_id, dry_scale, wet_scale, wet_after = (
            part.strip() for part in line.split(",", 3)
        )
        profiles[corridor_id] = {
            "dry_scale": int(dry_scale),
            "wet_scale": int(wet_scale),
            "wet_after": int(wet_after),
        }
    return profiles


def _corridor_blend_scale(
    depart_slot: int, duration: int, dry_scale: int, wet_scale: int, wet_after: int
) -> int:
    start = max(0, depart_slot)
    duration = max(1, duration)
    dry_scale = max(1, dry_scale)
    wet_scale = max(1, wet_scale)
    wet_after = max(0, wet_after)
    end = start + duration
    if end <= wet_after:
        return dry_scale
    if start >= wet_after:
        return wet_scale
    pre = max(0, wet_after - start)
    post = duration - pre
    return max(1, (pre * dry_scale + post * wet_scale) // duration)


def _expected_corridor_billable(spec: dict, corridors: dict[str, dict[str, int]]) -> int:
    act = int(spec.get("act_tons") or 0)
    est = int(spec.get("est_tons") or 0)
    duration = act if act > 0 else max(est, 1)
    profile = corridors.get(spec.get("corridor_id", "us-east"), {})
    dry_scale = profile.get("dry_scale", 100)
    wet_scale = profile.get("wet_scale", 100)
    wet_after = profile.get("wet_after", 0)
    depart_slot = int(spec.get("depart_slot") or 0)
    scale = _corridor_blend_scale(
        depart_slot, duration, dry_scale, wet_scale, wet_after
    )
    raw = act if act > 0 else est
    return max(1, raw * scale // 100)


def _expected_corridor_delivery(spec: dict, corridors: dict[str, dict[str, int]]) -> int:
    billable = _expected_corridor_billable(spec, corridors)
    act = int(spec.get("act_tons") or 0)
    if act > 0:
        return min(act, billable)
    return billable


def _assert_corridor_blend(report: dict, regions_text: str, *, require_status: bool) -> None:
    """Corridor rows must use duration-weighted dry/wet blending, not dry_scale alone."""
    corridors = _load_corridor_profiles()
    inputs = _region_map_from_text(regions_text)
    raw = _corridor_raw_act(regions_text)
    us_spec = inputs["r_corridor_us"]
    eu_spec = inputs["r_corridor_eu"]
    us = next(r for r in report["regions"] if r["region_id"] == "r_corridor_us")
    eu = next(r for r in report["regions"] if r["region_id"] == "r_corridor_eu")
    us_expected = _expected_corridor_delivery(us_spec, corridors)
    eu_expected = _expected_corridor_delivery(eu_spec, corridors)
    assert us["served"] and eu["served"]
    assert us_expected < raw
    assert eu_expected < us_expected
    assert us["tons_reserved"] == us_expected, (us, us_expected)
    assert eu["tons_reserved"] == eu_expected, (eu, eu_expected)
    assert us["tons_delivered"] == us_expected, (us, us_expected)
    assert eu["tons_delivered"] == eu_expected, (eu, eu_expected)
    assert eu["tons_reserved"] < us["tons_reserved"], (us, eu)
    assert eu["tons_delivered"] < us["tons_delivered"], (us, eu)
    if require_status:
        assert report["status"] == "ok"


def _load_field_reports() -> dict[str, int]:
    field_reports: dict[str, int] = {}
    if not FIELD_REPORTS.is_file():
        return field_reports
    lines = FIELD_REPORTS.read_text(encoding="utf-8").splitlines()
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        region_id, act_tons = (part.strip() for part in line.split(",", 1))
        field_reports[region_id] = int(act_tons)
    return field_reports


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "fleet_capacity_tons": 12000,
        "min_coverage_rate": 0.75,
        "max_surplus_ratio": 0.35,
        "max_route_violations": 0,
        "max_priority_inversions": 1,
        "min_convoy_buffer_tons": 3,
        "min_humanitarian_value": 2.0,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in ("min_coverage_rate", "max_surplus_ratio", "min_humanitarian_value"):
            cfg[key] = float(val)
        elif key in (
            "fleet_capacity_tons",
            "max_route_violations",
            "max_priority_inversions",
            "min_convoy_buffer_tons",
        ):
            cfg[key] = int(float(val))
    return cfg


def _region_rows_from_text(text: str) -> list[dict]:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def _region_ids_from_text(text: str) -> list[str]:
    return [row["region_id"] for row in _region_rows_from_text(text)]


def _region_map_from_text(text: str) -> dict[str, dict]:
    return {row["region_id"]: row for row in _region_rows_from_text(text)}


def _assert_regions_match_input(report: dict, regions_text: str) -> None:
    expected_ids = _region_ids_from_text(regions_text)
    report_ids = [row["region_id"] for row in report["regions"]]
    assert report["regions_total"] == len(expected_ids)
    assert len(report_ids) == len(expected_ids)
    assert set(report_ids) == set(expected_ids)


@pytest.fixture(autouse=True)
def restore_default_regions() -> None:
    yield
    if _DEFAULT_REGIONS_TEXT:
        _atomic_write_text(REGIONS, _DEFAULT_REGIONS_TEXT)
    stale_tmp = REGIONS.with_suffix(REGIONS.suffix + ".tmp")
    if stale_tmp.is_file():
        stale_tmp.unlink()


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    try:
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, path)
    finally:
        if tmp.is_file():
            tmp.unlink()


def _swap_fixture(stem: str) -> str:
    src = CASES / f"{stem}.jsonl"
    text = src.read_text(encoding="utf-8")
    _atomic_write_text(REGIONS, text)
    return text


def _digest_payload(report: dict) -> dict:
    regions = [
        {key: row[key] for key in DIGEST_REGION_KEY_ORDER}
        for row in report["regions"]
    ]
    payload = {key: report[key] for key in DIGEST_REPORT_KEY_ORDER if key != "regions"}
    payload["report_digest"] = ""
    payload["regions"] = regions
    return payload


def _expected_digest(report: dict) -> str:
    payload = _digest_payload(report)
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
        timeout=RUN_TIMEOUT_SEC,
    )
    return proc.stdout.split()[0]


def _invoke_default() -> None:
    proc = subprocess.run(
        ["/app/tools/run_convoy"],
        capture_output=True,
        text=True,
        check=False,
        timeout=RUN_TIMEOUT_SEC,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "convoy_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    _invoke_default()


def test_report_top_level_keys_exact() -> None:
    """Report must expose only the documented top-level keys."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS


def test_region_row_schema() -> None:
    """Each region row must match the documented per-region schema."""
    report = _load_report()
    assert report["regions"]
    for row in report["regions"]:
        assert set(row.keys()) == ROW_KEYS
        assert isinstance(row["region_id"], str) and row["region_id"]
        assert isinstance(row["cluster"], str) and row["cluster"]
        assert isinstance(row["urgency"], int)
        assert row["tons_reserved"] >= 0
        assert row["tons_delivered"] >= 0
        assert row["surplus_tons"] >= 0
        assert isinstance(row["served"], bool)
        assert isinstance(row["route_ready"], bool)
        assert row["dispatch_rank"] >= 1
        assert row["convoy_wave"] >= 0
        assert row["humanitarian_value"] >= 0.0


def test_passing_run_contract() -> None:
    """Default bundle must finish ok and meet relief.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["fleet_capacity_tons"] == cfg["fleet_capacity_tons"]
    _assert_regions_match_input(report, _DEFAULT_REGIONS_TEXT)
    assert report["coverage_rate"] >= cfg["min_coverage_rate"]
    assert report["surplus_ratio"] <= cfg["max_surplus_ratio"]
    assert report["route_violations"] <= cfg["max_route_violations"]
    assert report["priority_inversions"] <= cfg["max_priority_inversions"]
    assert report["convoy_buffer_tons"] >= cfg["min_convoy_buffer_tons"]
    assert report["humanitarian_value"] >= cfg["min_humanitarian_value"]


def test_regions_total_matches_input_rows() -> None:
    """Report region IDs must cover every input JSONL row with no drops or extras."""
    report = _load_report()
    _assert_regions_match_input(report, _DEFAULT_REGIONS_TEXT)


def test_report_digest_matches_payload() -> None:
    """report_digest must hash contract key order and compact UTF-8 JSON."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_deterministic_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_dep_rows_finish_in_order() -> None:
    """Dependency chain rows must complete only after prerequisites."""
    report = _load_report()
    ranks = {row["region_id"]: row["dispatch_rank"] for row in report["regions"]}
    assert ranks["r_dep_root"] < ranks["r_dep_leaf"] < ranks["r_dep_chain"]
    for row in report["regions"]:
        if row["region_id"].startswith("r_dep_") and row["served"]:
            assert row["route_ready"] is True, row


def test_prio_hot_ranks_before_cold() -> None:
    """Late priority revision rows must finish before stale low-revision peers."""
    report = _load_report()
    hot = next(r for r in report["regions"] if r["region_id"] == "r_prio_hot")
    cold = next(r for r in report["regions"] if r["region_id"] == "r_prio_cold")
    assert hot["served"] is True
    assert cold["served"] is True
    assert hot["dispatch_rank"] < cold["dispatch_rank"], (hot, cold)


def test_drift_accounting_semantics() -> None:
    """Drift rows reserve estimates, bill actuals, and record reserved minus used."""
    report = _load_report()
    inputs = _region_map_from_text(_DEFAULT_REGIONS_TEXT)
    field_reports = _load_field_reports()
    for row in report["regions"]:
        if not row["region_id"].startswith("r_report_") or not row["served"]:
            continue
        spec = inputs[row["region_id"]]
        expected_used = field_reports.get(row["region_id"], spec["act_tons"])
        assert row["tons_reserved"] == spec["est_tons"]
        assert row["tons_delivered"] == expected_used
        assert row["surplus_tons"] == max(0, row["tons_reserved"] - row["tons_delivered"])


def test_drift_rows_record_waste() -> None:
    """Drift-prone rows with inflated reservations must record surplus_tons."""
    report = _load_report()
    drift_rows = [r for r in report["regions"] if r["region_id"].startswith("r_report_")]
    assert drift_rows
    assert any(r["surplus_tons"] > 0 for r in drift_rows if r["served"])


def test_burst_rows_complete() -> None:
    """Convoy-wave rows with the r_convoy_ prefix must complete under the default bundle."""
    report = _load_report()
    burst_rows = [r for r in report["regions"] if r["region_id"].startswith("r_convoy_")]
    assert burst_rows
    assert all(r["served"] for r in burst_rows), burst_rows


def test_region_rows_respect_intensity() -> None:
    """Regional rows must bill through blended intensity, not raw estimates alone."""
    _invoke_default()
    report = _load_report()
    _assert_corridor_blend(report, _DEFAULT_REGIONS_TEXT, require_status=False)


def test_renew_late_row_completes() -> None:
    """Delayed convoy-wave row r_convoy_renew_late must complete under the default bundle."""
    report = _load_report()
    renew = next(r for r in report["regions"] if r["region_id"] == "r_convoy_renew_late")
    assert renew["served"] is True
    assert renew["convoy_wave"] > 0


def test_scenario_dep_chain() -> None:
    """Dependency-chain scenario must schedule deps before dependents."""
    regions_text = _swap_fixture("dep_chain")
    _invoke_default()
    report = _load_report()
    _assert_regions_match_input(report, regions_text)
    assert report["route_violations"] == 0
    assert report["status"] == "ok"
    ranks = {row["region_id"]: row["dispatch_rank"] for row in report["regions"]}
    assert ranks["r_dep_root"] < ranks["r_dep_leaf"] < ranks["r_dep_chain"]


def test_scenario_urgency_flip() -> None:
    """Urgency-flip scenario must schedule late revisions ahead of stale peers."""
    cfg = _parse_cfg()
    regions_text = _swap_fixture("urgency_flip")
    _invoke_default()
    report = _load_report()
    _assert_regions_match_input(report, regions_text)
    hot = next(r for r in report["regions"] if r["region_id"] == "r_prio_hot")
    cold = next(r for r in report["regions"] if r["region_id"] == "r_prio_cold")
    assert hot["dispatch_rank"] < cold["dispatch_rank"]
    assert report["priority_inversions"] <= cfg["max_priority_inversions"]
    assert report["status"] == "ok"


def test_scenario_est_drift() -> None:
    """Estimate-drift scenario must keep surplus_ratio under max_surplus_ratio."""
    cfg = _parse_cfg()
    regions_text = _swap_fixture("est_drift")
    _invoke_default()
    report = _load_report()
    _assert_regions_match_input(report, regions_text)
    inputs = _region_map_from_text(regions_text)
    for row in report["regions"]:
        if not row["region_id"].startswith("r_report_") or not row["served"]:
            continue
        spec = inputs[row["region_id"]]
        assert row["tons_reserved"] == spec["est_tons"]
        assert row["surplus_tons"] == max(0, row["tons_reserved"] - row["tons_delivered"])
        assert row["surplus_tons"] > 0
    assert report["surplus_ratio"] <= cfg["max_surplus_ratio"]
    assert report["status"] == "ok"


def test_scenario_burst_cluster() -> None:
    """Convoy-cluster scenario must absorb enough convoy buffer headroom."""
    cfg = _parse_cfg()
    regions_text = _swap_fixture("burst_cluster")
    _invoke_default()
    report = _load_report()
    _assert_regions_match_input(report, regions_text)
    burst_rows = [r for r in report["regions"] if r["region_id"].startswith("r_convoy_")]
    assert burst_rows
    assert all(r["served"] for r in burst_rows)
    assert report["convoy_buffer_tons"] >= cfg["min_convoy_buffer_tons"]
    assert report["status"] == "ok"


def test_scenario_value_mix() -> None:
    """Need-score mix scenario must meet humanitarian_value floor."""
    cfg = _parse_cfg()
    regions_text = _swap_fixture("value_mix")
    _invoke_default()
    report = _load_report()
    _assert_regions_match_input(report, regions_text)
    assert report["humanitarian_value"] >= cfg["min_humanitarian_value"]


def test_scenario_field_meter() -> None:
    """Zero-estimate field-report row reserves and delivers field act_tons verbatim."""
    regions_text = _swap_fixture("field_meter")
    _invoke_default()
    report = _load_report()
    _assert_regions_match_input(report, regions_text)
    field_reports = _load_field_reports()
    expected_used = field_reports["r_field_meter"]
    row = next(r for r in report["regions"] if r["region_id"] == "r_field_meter")
    assert row["served"] is True
    assert row["tons_delivered"] == expected_used
    assert row["tons_reserved"] == expected_used
    assert row["surplus_tons"] == 0


def test_scenario_region_mix() -> None:
    """Regional variability scenario must bill eu-west below us-east for similar work."""
    regions_text = _swap_fixture("region_mix")
    _invoke_default()
    report = _load_report()
    _assert_regions_match_input(report, regions_text)
    _assert_corridor_blend(report, regions_text, require_status=False)


def test_scenario_renew_delay() -> None:
    """Delayed convoy-wave scenario must complete r_convoy_renew_late with convoy buffer absorption."""
    cfg = _parse_cfg()
    regions_text = _swap_fixture("renew_delay")
    _invoke_default()
    report = _load_report()
    _assert_regions_match_input(report, regions_text)
    renew = next(r for r in report["regions"] if r["region_id"] == "r_convoy_renew_late")
    assert renew["served"] is True
    assert report["convoy_buffer_tons"] >= cfg["min_convoy_buffer_tons"]
    assert report["status"] == "ok"
