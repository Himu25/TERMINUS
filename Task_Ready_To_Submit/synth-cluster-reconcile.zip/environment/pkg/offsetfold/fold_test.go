package offsetfold

import "testing"

func TestFoldUnitSkewNetsHoldBand(t *testing.T) {
	const skew int64 = 30
	const hold int64 = 5
	got := FoldUnitSkew(skew, hold)
	want := skew - hold
	if got != want {
		t.Fatalf("FoldUnitSkew(%d,%d)=%d want %d (skew minus hold)", skew, hold, got, want)
	}
}

func TestFoldUnitSkewIgnoresZeroHold(t *testing.T) {
	const skew int64 = 12
	if got := FoldUnitSkew(skew, 0); got != skew {
		t.Fatalf("FoldUnitSkew(%d,0)=%d want %d", skew, got, skew)
	}
}
