package offsetfold

import "lab.local/synth_cluster_reconcile/lanegate"

// FoldUnitSkew applies optional radio hold smear to the recorded clock skew baseline.
func FoldUnitSkew(skewMS int64, radioHoldMS int64) int64 {
	return lanegate.ApplySmear(skewMS, radioHoldMS)
}
