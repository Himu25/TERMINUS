package version

// ToolingTag is stamped into build metadata.
const ToolingTag = "synth-reconcile-0.9"
