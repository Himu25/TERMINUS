package unit

// Profile holds per-unit clock and partition marks.
// ClockSkewMS is subtracted from segment emitted_ms when comparing rows for ordering.
type Profile struct {
	UnitID    string `json:"worker_id"`
	ClockSkewMS    int64  `json:"clock_skew_ms"`
	RadioHoldMS int64  `json:"lane_hold_ms"`
	StaleMark uint32 `json:"freeze_mark"`
}
