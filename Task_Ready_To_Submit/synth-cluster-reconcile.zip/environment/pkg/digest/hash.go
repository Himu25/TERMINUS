package digest

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
)

// ReportHex matches the pipe-separated digest in cmd/gen_reconcile.
func ReportHex(
	clusterID string,
	masterEpoch, batchSeq, dedupeCount, gapCount, workersActive uint32,
	skewBand string,
	templateClean bool,
) string {
	ck := "true"
	if !templateClean {
		ck = "false"
	}
	raw := fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%s|%s",
		clusterID, masterEpoch, batchSeq, dedupeCount, gapCount, workersActive, skewBand, ck,
	)
	sum := sha256.Sum256([]byte(raw))
	return hex.EncodeToString(sum[:])
}
