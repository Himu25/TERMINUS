Operator tools live outside the heal driver; use /app/bin/gen_reconcile for pack replay.
Verifier helpers include /tmp/gen_reconcile_verify_bin and /app/tools/gen_digest for digest recomputation.
