#pragma once

long long lg_apply_smear(long long base_ms, long long hold_ms);
