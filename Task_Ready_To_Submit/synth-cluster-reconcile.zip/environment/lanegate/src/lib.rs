/// LgApplySmear folds a radio hold band into a unit clock skew baseline (milliseconds).
#[no_mangle]
pub extern "C" fn lg_apply_smear(base_ms: i64, hold_ms: i64) -> i64 {
    if hold_ms == 0 {
        return base_ms;
    }
    base_ms + hold_ms
}
