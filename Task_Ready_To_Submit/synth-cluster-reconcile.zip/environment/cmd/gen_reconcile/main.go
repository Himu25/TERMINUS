// Report JSON for /app/output/gen_report.json:
//
// schema_version — string, must be "1"
// cluster_id — string, echoes active pack name
// master_epoch — highest epoch in the consistent chain
// batch_seq — highest contiguous sequence included in the chain
// dedupe_count — checksum fixes applied during heal
// gap_count — sweep positions without replica agreement
// workers_active — count of units contributing to accepted rows
// skew_band — string, "tight" or "wide"
// template_clean — boolean (not 0/1 strings)
// digest_hex — lowercase hex SHA-256 of cluster_id|master_epoch|batch_seq|dedupe_count|gap_count|workers_active|skew_band|template_clean
//
// Root object contains only these keys.
package main

import (
	"log"
	"os"

	"lab.local/synth_cluster_reconcile/internal/driver"
)

func main() {
	if os.Getenv("TB_GEN_FIXTURE") != "1" {
		log.Fatal("TB_GEN_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/gen_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
