module lab.local/synth_cluster_reconcile

go 1.22
