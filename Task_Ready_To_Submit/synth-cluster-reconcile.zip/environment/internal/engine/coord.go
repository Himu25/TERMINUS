package engine

import (
	"lab.local/synth_cluster_reconcile/internal/freeze"
	"lab.local/synth_cluster_reconcile/internal/merge"
	"lab.local/synth_cluster_reconcile/pkg/frame"
	"lab.local/synth_cluster_reconcile/pkg/unit"
)

// Replay executes one pack through freeze and merge stages.
func Replay(
	packID string,
	qSize int,
	sepEpoch uint32,
	linkTight int64,
	profiles []unit.Profile,
	allRows map[uint32][]frame.Row,
	offsets map[string]int64,
) merge.Outcome {
	wm := freeze.Watermark(profiles)
	above := make(map[uint32][]frame.Row)
	for seq, rows := range allRows {
		if seq > uint32(wm) {
			above[seq] = rows
		}
	}
	out := merge.FusePack(uint32(wm), qSize, sepEpoch, linkTight, offsets, above, allRows)
	_ = packID
	return out
}
