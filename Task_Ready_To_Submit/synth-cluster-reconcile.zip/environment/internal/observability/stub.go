package observability

// Stub counter sink for future metrics wiring.
func Stub() {}
