package skew

import (
	"lab.local/synth_cluster_reconcile/pkg/timenorm"
	"lab.local/synth_cluster_reconcile/pkg/frame"
)

// PickEarlier returns the row with smaller drift-adjusted wall time.
func PickEarlier(a, b frame.Row, offA, offB int64) frame.Row {
	if timenorm.OpT(a.WallMS, offA) <= timenorm.OpT(b.WallMS, offB) {
		return a
	}
	return b
}

// AdjustEmit returns drift-adjusted wall time for one row.
func AdjustEmit(row frame.Row, offset int64) int64 {
	return timenorm.OpT(row.WallMS, offset)
}
