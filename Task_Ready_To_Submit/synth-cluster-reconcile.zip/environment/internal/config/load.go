package config

import (
	"encoding/json"
	"os"
	"path/filepath"

	"lab.local/synth_cluster_reconcile/pkg/frame"
	"lab.local/synth_cluster_reconcile/pkg/offsetfold"
	"lab.local/synth_cluster_reconcile/pkg/unit"
)

// Pack describes one heal scenario root.
type Pack struct {
	ClusterID       string   `json:"cluster_id"`
	QSize        int      `json:"q_size"`
	SepEpoch   uint32   `json:"sep_epoch"`
	LinkTightMS int64    `json:"link_tight_ms"`
	Units        []string `json:"workers"`
}

// ActivePaths resolves the bundled active pack directory.
func ActivePaths(root string) (string, error) {
	return filepath.Join(root, "data", "active"), nil
}

// LoadPack reads cluster_pack.json and unit trees.
func LoadPack(dir string) (Pack, []unit.Profile, map[uint32][]frame.Row, map[string]int64, error) {
	raw, err := os.ReadFile(filepath.Join(dir, "cluster_pack.json"))
	if err != nil {
		return Pack{}, nil, nil, nil, err
	}
	var doc Pack
	if err := json.Unmarshal(raw, &doc); err != nil {
		return Pack{}, nil, nil, nil, err
	}
	profiles := make([]unit.Profile, 0, len(doc.Units))
	offsets := make(map[string]int64, len(doc.Units))
	rows := make(map[uint32][]frame.Row)
	for _, mid := range doc.Units {
		metaPath := filepath.Join(dir, "workers", mid, "meta.json")
		metaRaw, err := os.ReadFile(metaPath)
		if err != nil {
			return Pack{}, nil, nil, nil, err
		}
		var prof unit.Profile
		if err := json.Unmarshal(metaRaw, &prof); err != nil {
			return Pack{}, nil, nil, nil, err
		}
		profiles = append(profiles, prof)
		offsets[mid] = offsetfold.FoldUnitSkew(prof.ClockSkewMS, prof.RadioHoldMS)
		seg := filepath.Join(dir, "workers", mid, "seg_001.jsonl")
		data, err := os.ReadFile(seg)
		if err != nil {
			if os.IsNotExist(err) {
				continue
			}
			return Pack{}, nil, nil, nil, err
		}
		for _, line := range splitLines(string(data)) {
			if line == "" {
				continue
			}
			var row frame.Row
			if err := json.Unmarshal([]byte(line), &row); err != nil {
				continue
			}
			row.Site = mid
			rows[row.Seq] = append(rows[row.Seq], row)
		}
	}
	return doc, profiles, rows, offsets, nil
}

func splitLines(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			out = append(out, s[start:i])
			start = i + 1
		}
	}
	if start < len(s) {
		out = append(out, s[start:])
	}
	return out
}
