package driver

import (
	"encoding/json"
	"os"
)

// Report is the outward JSON envelope.
type Report struct {
	SchemaVersion string `json:"schema_version"`
	ClusterID        string `json:"cluster_id"`
	MasterEpoch     uint32 `json:"master_epoch"`
	BatchSeq     uint32 `json:"batch_seq"`
	DedupeCount   uint32 `json:"dedupe_count"`
	GapCount     uint32 `json:"gap_count"`
	WorkersActive   uint32 `json:"workers_active"`
	SkewBand     string `json:"skew_band"`
	TemplateClean    bool   `json:"template_clean"`
	DigestHex     string `json:"digest_hex"`
}

// EmitReport writes the heal output document.
func EmitReport(path string, rep Report) error {
	raw, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}
