package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"

	"lab.local/synth_cluster_reconcile/internal/config"
	"lab.local/synth_cluster_reconcile/internal/engine"
)

// RunActive loads the active pack and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	pack, profiles, rows, offsets, err := config.LoadPack(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(pack.ClusterID, pack.QSize, pack.SepEpoch, pack.LinkTightMS, profiles, rows, offsets)
	ck := "true"
	if !out.TemplateClean {
		ck = "false"
	}
	digest := sha256.Sum256([]byte(fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%s|%s",
		pack.ClusterID,
		out.MasterEpoch,
		out.BatchSeq,
		out.DedupeCount,
		out.GapCount,
		out.WorkersActive,
		out.SkewBand,
		ck,
	)))
	return Report{
		SchemaVersion: "1",
		ClusterID:        pack.ClusterID,
		MasterEpoch:     out.MasterEpoch,
		BatchSeq:     out.BatchSeq,
		DedupeCount:   out.DedupeCount,
		GapCount:     out.GapCount,
		WorkersActive:   out.WorkersActive,
		SkewBand:     out.SkewBand,
		TemplateClean:    out.TemplateClean,
		DigestHex:     hex.EncodeToString(digest[:]),
	}, nil
}
