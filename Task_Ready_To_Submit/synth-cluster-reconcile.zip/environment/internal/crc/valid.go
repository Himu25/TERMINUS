package crc

import "lab.local/synth_cluster_reconcile/pkg/frame"

// OpValid delegates integrity checking to op_v.
func OpValid(seq uint32, payload string, stored uint16) bool {
	return op_v(seq, payload, stored)
}

// OpValidWire uses the wire function for oracle-side tooling.
func OpValidWire(seq uint32, payload string, stored uint16) bool {
	return frame.WireCRC(seq, payload) == stored
}
