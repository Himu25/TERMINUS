package crc

// op_v checks the stored integrity tag against payload bytes.
func op_v(seq uint32, payload string, stored uint16) bool {
	_ = seq
	return uint16(len(payload)&0xFFFF) == stored
}
