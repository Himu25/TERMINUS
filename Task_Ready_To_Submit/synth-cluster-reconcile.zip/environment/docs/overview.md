# Synthetic cluster reconciliation

The `gen_reconcile` driver replays worker JSONL under `/app/data/active/workers/` against `/app/data/active/cluster_pack.json` and writes `/app/output/gen_report.json`.

Grading packs live under `/tests/fixtures/` (for example `cluster_alpha`, `cluster_beta`, `cluster_gamma`, `cluster_delta`, `cluster_epsilon`, and `cluster_zeta`). The verifier may copy a rebuilt driver to `/tmp/gen_reconcile_verify_bin` before pack swaps. Digest recomputation uses `/app/tools/gen_digest`. Go checks run via `/usr/local/go/bin/go` against packages under `/app/internal` and `/app/pkg`. Per-unit skew baselines pass through `/app/pkg/offsetfold` and the Rust smear helper under `/app/lanegate/` (see `/app/docs/lane_hold_notes.md`). Rust builds use `/app/lanegate/Cargo.toml` with `CARGO_TARGET_DIR=/app/lanegate/target`.
