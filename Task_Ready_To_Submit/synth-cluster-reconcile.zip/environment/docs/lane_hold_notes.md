# Lane hold notes

Workers record `clock_skew_ms` from their onboard clock source. During lane hold windows,
`lane_hold_ms` is folded into the effective skew baseline when the pack loader builds offset maps.
Hold band milliseconds are netted against the raw skew reading so held units sit closer to the
cluster timing mesh than the uncorrected clock delta alone would imply.
