# Cluster layout

Five workers (`n1`–`n5`) append synthetic record rows under `/app/data/active/workers/`.
Each worker carries `clock_skew_ms`, optional `lane_hold_ms`, and a `freeze_mark` watermark in `meta.json`.
Hold-window semantics for offset maps are in `/app/docs/lane_hold_notes.md`.

Segment files use JSONL with `seq`, `epoch`, `emitted_ms`, `payload`, and `crc` fields.
