# Upgrade fragment (incomplete)

2024-03: beacon checksum widened to xor sequence into sixteen-bit field.

2024-07: GPS tie ordering now references drift-adjusted timestamps from unit meta profiles.

2024-11: radio hold windows affect folded clock skew baselines when packs load.
