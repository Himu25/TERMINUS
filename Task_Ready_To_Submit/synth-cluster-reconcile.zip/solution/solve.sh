#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/pkg/replicount/op_q.go <<'EOF'
package replicount

func quorumMet(count int, need int) bool {
	if need <= 0 {
		return false
	}
	if count < 0 {
		return false
	}
	return count >= need
}

// OpQ decides whether enough replicas reported the same payload group.
func OpQ(replicaCount int, need int) bool {
	return quorumMet(replicaCount, need)
}
EOF

cat > /app/internal/crc/op_v.go <<'EOF'
package crc

import "lab.local/synth_cluster_reconcile/pkg/frame"

func wireMatch(seq uint32, payload string, stored uint16) bool {
	want := frame.WireCRC(seq, payload)
	return want == stored
}

// op_v checks the stored integrity tag against payload bytes.
func op_v(seq uint32, payload string, stored uint16) bool {
	if payload == "" {
		return stored == 0 && seq == 0
	}
	return wireMatch(seq, payload, stored)
}
EOF

cat > /app/pkg/timenorm/op_t.go <<'EOF'
package timenorm

func normalizeWall(wall int64, offset int64) int64 {
	return wall - offset
}

// OpT adjusts wall time for drift comparisons.
func OpT(wall int64, offset int64) int64 {
	return normalizeWall(wall, offset)
}
EOF

cat > /app/pkg/markfold/op_w.go <<'EOF'
package markfold

func minMark(marks []int64) int64 {
	if len(marks) == 0 {
		return 0
	}
	best := marks[0]
	for _, m := range marks[1:] {
		if m < best {
			best = m
		}
	}
	return best
}

// OpW folds member marks into one replay watermark.
func OpW(marks []int64) int64 {
	return minMark(marks)
}
EOF

cat > /app/lanegate/src/lib.rs <<'EOF'
use std::os::raw::c_longlong;

/// LgApplySmear folds a radio hold band into a unit clock skew baseline (milliseconds).
#[no_mangle]
pub extern "C" fn lg_apply_smear(base_ms: c_longlong, hold_ms: c_longlong) -> c_longlong {
    if hold_ms == 0 {
        return base_ms;
    }
    base_ms - hold_ms
}
EOF

bash /app/scripts/build.sh

rm -f /app/output/gen_report.json
mkdir -p /app/output
TB_GEN_FIXTURE=1 /app/bin/gen_reconcile
test -s /app/output/gen_report.json

GOFLAGS=-mod=mod go test ./...
