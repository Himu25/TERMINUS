#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/bin:/app/bin:${PATH}"
cd /app

cat > /app/drv/src/slot_a/fetch_a.rs <<'EOF'
use super::op_s;
use serde::{Deserialize, Serialize};
use std::process::Command;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SlotRow {
    pub room_id: String,
    pub tier: i32,
    pub manual_page: String,
    pub hint_token: String,
    pub chain_rank: i32,
    pub prior_token: Option<String>,
    pub solution_guard: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub chain_id: Option<String>,
}

/// FetchA loads authoritative room facts for a single room id.
pub fn fetch_a(room_id: &str) -> Option<SlotRow> {
    let store = op_s::op_s();
    let escaped = room_id.replace('\'', "''");
    let sql = format!(
        "SELECT r.room_id, r.tier, r.manual_page, r.hint_token, r.chain_rank, r.prior_token, r.solution_guard, c.chain_id \
         FROM rooms r JOIN room_chains c ON r.room_id = c.room_id WHERE r.room_id = '{escaped}'"
    );
    let out = Command::new("duckdb")
        .args(["-csv", &store, &sql])
        .output()
        .ok()?;
    if !out.status.success() {
        return None;
    }
    let text = String::from_utf8_lossy(&out.stdout);
    let mut lines = text.lines();
    lines.next()?;
    let row = lines.next()?;
    let parts: Vec<&str> = row.split(',').collect();
    if parts.len() < 8 {
        return None;
    }
    let prior = if parts[5].is_empty() {
        None
    } else {
        Some(parts[5].to_string())
    };
    Some(SlotRow {
        room_id: parts[0].to_string(),
        tier: parts[1].parse().ok()?,
        manual_page: parts[2].to_string(),
        hint_token: parts[3].to_string(),
        chain_rank: parts[4].parse().ok()?,
        prior_token: prior,
        solution_guard: parts[6].to_string(),
        chain_id: Some(parts[7].to_string()),
    })
}
EOF

cat > /app/drv/src/linkstep/lane_c.rs <<'EOF'
use crate::slot_a::SlotRow;

/// LaneC stamps each row with the chain lane id read from the catalog.
pub fn lane_c(rows: &mut [SlotRow]) {
    for row in rows.iter_mut() {
        if row.chain_id.is_none() {
            row.chain_id = Some("chain_primary".into());
        }
    }
}
EOF

cat > /app/drv/src/linkstep/sort_b.rs <<'EOF'
use crate::slot_a::SlotRow;

/// SortB orders room facts before hint evaluation.
pub fn sort_b(mut rows: Vec<SlotRow>) -> Vec<SlotRow> {
    rows.sort_by(|a, b| a.chain_rank.cmp(&b.chain_rank).then(a.room_id.cmp(&b.room_id)));
    rows
}
EOF

python3 - <<'PY'
from pathlib import Path

path = Path("/app/drv/src/driver/run.rs")
text = path.read_text()
old = """        let granted = decision.grant && decision.chain_ok && decision.safety_ok;
        if decision.grant {
            granted_tokens.push(decision.hint_token.clone());
        }
        if granted {
            hints_granted += 1;
        }"""
new = """        let granted = decision.grant && decision.chain_ok && decision.safety_ok;
        if granted {
            hints_granted += 1;
            granted_tokens.push(decision.hint_token.clone());
        }"""
if old not in text:
    raise SystemExit("run.rs grant ledger pattern not found")
path.write_text(text.replace(old, new, 1))
PY

cat > /app/opa_r/gate_a.rego <<'EOF'
package gate_a

default gate_ok = false

gate_ok {
    input.room.prior_token == null
}

gate_ok {
    input.room.prior_token == input.granted_tokens[_]
}
EOF

cat > /app/opa_r/gate_c.rego <<'EOF'
package gate_c

default lane_ok = false

lane_ok {
    input.room.prior_token == null
}

lane_ok {
    input.room.prior_token == input.granted_tokens[_]
    input.prior_chain == input.room.chain_id
}
EOF

cat > /app/opa_r/guard_b.rego <<'EOF'
package guard_b

default guard_ok = false

guard_ok {
    not contains(input.room.hint_token, "SOLUTION:")
    input.room.hint_token != input.room.solution_guard
}
EOF

cat > /app/opa_r/unlock_m.rego <<'EOF'
package hint

import data.gate_a.gate_ok
import data.gate_c.lane_ok
import data.guard_b.guard_ok

default decision = {
    "grant": false,
    "manual_page": "",
    "hint_token": "",
    "chain_ok": false,
    "safety_ok": false,
}

decision = {
    "grant": grant,
    "manual_page": input.room.manual_page,
    "hint_token": input.room.hint_token,
    "chain_ok": chain_ok,
    "safety_ok": guard_ok,
} {
    chain_ok := gate_ok
    chain_ok
    lane_ok
    grant := chain_ok
    grant
    guard_ok
}
EOF

bash /app/scripts/build.sh

rm -f /app/output/hint_unlock_report.json
mkdir -p /app/output
TB_HINT_FIXTURE=1 /app/bin/referee_run
test -s /app/output/hint_unlock_report.json

opa test /app/opa_r -v
