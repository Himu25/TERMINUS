# Archivist Lens referee

The normative report contract is `/app/schemas/hint_unlock_report.schema.json`. Top-level fields are string `schema_version` (`hint-v2`), string `run_id`, integer `rooms_total`, `hints_granted`, `chain_ok_count`, `safety_ok_count`, and `catalog_hits`, string `digest_hex`, and array `rooms`. Each `rooms` item carries string `room_id`, `manual_page`, and `hint_token` plus boolean `granted`, `chain_ok`, and `safety_ok`.

The release build entrypoint is `/app/scripts/build.sh`. The referee binary `/app/bin/referee_run` replays failed cargo-puzzle rooms from session JSON. With `TB_HINT_FIXTURE=1` it reads `/app/data/active/session.json`; otherwise the first CLI argument is the session path. Every run writes `/app/output/hint_unlock_report.json`. Regression harnesses may copy the rebuilt binary to `/tmp/referee_run_verify_bin` before replay checks.

Room facts live in `/app/store/rooms.duckdb` with lane membership in `room_chains`. Warm exports under `/app/data/fixtures` mirror historical snapshots and can disagree with the catalog on chain rank, lane id, and prerequisite tokens. Manual pages under `/app/manuals` describe operator-facing unlock semantics.

Unlock evaluation uses OPA bundles in `/app/opa_r` (`gate_a.rego`, `gate_c.rego`, `guard_b.rego`, `unlock_m.rego`). Policy input carries the room row, granted token ledger, and the lane id of the prerequisite token when present.

Report digest is lowercase hex SHA-256 over `run_id|hints_granted|chain_ok_count|safety_ok_count|catalog_hits` via `/app/bin/digest_cli`.
