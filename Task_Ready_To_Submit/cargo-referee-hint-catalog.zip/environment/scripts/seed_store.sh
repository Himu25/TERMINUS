#!/bin/bash
set -euo pipefail

mkdir -p /app/store
duckdb /app/store/rooms.duckdb <<'SQL'
CREATE TABLE rooms (
    room_id TEXT PRIMARY KEY,
    tier INTEGER NOT NULL,
    manual_page TEXT NOT NULL,
    hint_token TEXT NOT NULL,
    chain_rank INTEGER NOT NULL,
    prior_token TEXT,
    solution_guard TEXT NOT NULL
);

INSERT INTO rooms VALUES
    ('rm_alpha', 1, 'page_alpha', 'token_a1', 1, NULL, 'SOLUTION:alpha_crane'),
    ('rm_beta', 2, 'page_beta', 'token_b2', 2, 'token_a1', 'SOLUTION:beta_lift'),
    ('rm_gamma', 3, 'page_gamma', 'token_g3', 3, 'token_b2', 'SOLUTION:gamma_stack'),
    ('rm_delta', 1, 'page_alpha', 'token_d4', 1, NULL, 'SOLUTION:delta_fork'),
    ('rm_epsilon', 2, 'page_beta', 'token_e5', 2, 'token_d4', 'SOLUTION:epsilon_pallet');

CREATE TABLE hint_chains (
    chain_id TEXT PRIMARY KEY,
    head_room TEXT NOT NULL,
    tail_room TEXT NOT NULL
);

INSERT INTO hint_chains VALUES
    ('chain_primary', 'rm_alpha', 'rm_gamma'),
    ('chain_shadow', 'rm_delta', 'rm_epsilon');

CREATE TABLE room_chains (
    room_id TEXT PRIMARY KEY,
    chain_id TEXT NOT NULL
);

INSERT INTO room_chains VALUES
    ('rm_alpha', 'chain_primary'),
    ('rm_beta', 'chain_primary'),
    ('rm_gamma', 'chain_primary'),
    ('rm_delta', 'chain_shadow'),
    ('rm_epsilon', 'chain_shadow');
SQL
