#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/bin:${PATH}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/tmp/cargo-target}"

mkdir -p /app/bin /app/output
cd /app/drv
cargo build --release --locked
cp /tmp/cargo-target/release/referee_run /app/bin/referee_run
cd /app/tools/digest_cli
cargo build --release --locked
cp /tmp/cargo-target/release/digest_cli /app/bin/digest_cli
