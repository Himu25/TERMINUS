use crate::slot_a::SlotRow;
use serde::{Deserialize, Serialize};
use std::io::Write;
use std::process::{Command, Stdio};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PolicyDecision {
    pub grant: bool,
    pub manual_page: String,
    pub hint_token: String,
    pub chain_ok: bool,
    pub safety_ok: bool,
}

pub fn op_p(room: &SlotRow, granted: &[String], prior_chain: Option<&str>) -> PolicyDecision {
    let input = serde_json::json!({
        "room": room,
        "granted_tokens": granted,
        "prior_chain": prior_chain,
    });
    let mut child = Command::new("/usr/local/bin/opa")
        .args([
            "eval",
            "-d",
            "/app/opa_r",
            "-i",
            "/dev/stdin",
            "data.hint.decision",
            "--format",
            "raw",
        ])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
        .expect("opa eval");
    if let Some(mut stdin) = child.stdin.take() {
        let _ = stdin.write_all(input.to_string().as_bytes());
    }
    let out = child.wait_with_output().expect("opa output");
    let body = String::from_utf8_lossy(&out.stdout);
    serde_json::from_str(body.trim()).unwrap_or(PolicyDecision {
        grant: false,
        manual_page: room.manual_page.clone(),
        hint_token: room.hint_token.clone(),
        chain_ok: false,
        safety_ok: false,
    })
}
