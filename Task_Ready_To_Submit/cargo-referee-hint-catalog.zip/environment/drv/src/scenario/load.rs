use serde::{Deserialize, Serialize};
use std::path::Path;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Session {
    pub run_id: String,
    pub failed_rooms: Vec<String>,
}

pub fn load_session(path: &Path) -> Session {
    let raw = std::fs::read_to_string(path).expect("session json");
    serde_json::from_str(&raw).expect("session parse")
}
