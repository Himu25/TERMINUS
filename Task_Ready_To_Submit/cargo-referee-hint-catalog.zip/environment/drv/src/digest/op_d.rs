use std::process::Command;

pub fn op_d(
    run_id: &str,
    hints_granted: i32,
    chain_ok: i32,
    safety_ok: i32,
    catalog_hits: i32,
) -> String {
    let out = Command::new("/app/bin/digest_cli")
        .args([
            run_id,
            &hints_granted.to_string(),
            &chain_ok.to_string(),
            &safety_ok.to_string(),
            &catalog_hits.to_string(),
        ])
        .output()
        .expect("digest_cli");
    String::from_utf8_lossy(&out.stdout).trim().to_string()
}
