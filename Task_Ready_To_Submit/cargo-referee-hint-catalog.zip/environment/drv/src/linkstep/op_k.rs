/// OpK returns a stable sort key for unrelated replay lanes.
pub fn op_k(tier: i32, chain_rank: i32) -> i64 {
    (tier as i64) * 1000 + chain_rank as i64
}
