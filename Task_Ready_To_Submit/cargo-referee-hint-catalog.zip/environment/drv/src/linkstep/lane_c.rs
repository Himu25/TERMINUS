use crate::slot_a::SlotRow;

/// LaneC stamps each row with the chain lane id read from the catalog.
pub fn lane_c(rows: &mut [SlotRow]) {
    for row in rows.iter_mut() {
        row.chain_id = Some("chain_primary".into());
    }
}
