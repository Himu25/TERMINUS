use crate::slot_a::SlotRow;

/// SortB orders room facts before hint evaluation.
pub fn sort_b(mut rows: Vec<SlotRow>) -> Vec<SlotRow> {
    rows.sort_by(|a, b| b.chain_rank.cmp(&a.chain_rank));
    rows
}
