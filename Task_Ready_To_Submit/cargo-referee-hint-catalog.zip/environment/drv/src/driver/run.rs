use crate::digest::op_d;
use crate::linkstep::{lane_c, sort_b};
use crate::policy::op_p;
use crate::scenario::load_session;
use crate::slot_a::{SlotRow, fetch_a};
use serde::{Deserialize, Serialize};
use std::path::Path;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoomRow {
    pub room_id: String,
    pub manual_page: String,
    pub hint_token: String,
    pub granted: bool,
    pub chain_ok: bool,
    pub safety_ok: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Report {
    pub schema_version: String,
    pub run_id: String,
    pub rooms_total: i32,
    pub hints_granted: i32,
    pub chain_ok_count: i32,
    pub safety_ok_count: i32,
    pub catalog_hits: i32,
    pub digest_hex: String,
    pub rooms: Vec<RoomRow>,
}

fn prior_chain(fact: &SlotRow, facts: &[SlotRow]) -> Option<String> {
    let prior = fact.prior_token.as_ref()?;
    facts
        .iter()
        .find(|row| row.hint_token == *prior)
        .and_then(|row| row.chain_id.clone())
}

pub fn run_session(session_path: &Path) -> Report {
    let session = load_session(session_path);
    let mut facts: Vec<SlotRow> = Vec::new();
    let mut catalog_hits = 0;
    for room_id in &session.failed_rooms {
        if let Some(fact) = fetch_a(room_id) {
            catalog_hits += 1;
            facts.push(fact);
        }
    }
    lane_c(&mut facts);
    facts = sort_b(facts);

    let mut granted_tokens: Vec<String> = Vec::new();
    let mut rows: Vec<RoomRow> = Vec::new();
    let mut hints_granted = 0;
    let mut chain_ok_count = 0;
    let mut safety_ok_count = 0;

    for fact in &facts {
        let prior_chain = prior_chain(fact, &facts);
        let decision = op_p(fact, &granted_tokens, prior_chain.as_deref());
        if decision.chain_ok {
            chain_ok_count += 1;
        }
        if decision.safety_ok {
            safety_ok_count += 1;
        }
        let granted = decision.grant && decision.chain_ok && decision.safety_ok;
        if decision.grant {
            granted_tokens.push(decision.hint_token.clone());
        }
        if granted {
            hints_granted += 1;
        }
        rows.push(RoomRow {
            room_id: fact.room_id.clone(),
            manual_page: decision.manual_page,
            hint_token: decision.hint_token,
            granted,
            chain_ok: decision.chain_ok,
            safety_ok: decision.safety_ok,
        });
    }

    let digest_hex = op_d(
        &session.run_id,
        hints_granted,
        chain_ok_count,
        safety_ok_count,
        catalog_hits,
    );

    Report {
        schema_version: "hint-v2".into(),
        run_id: session.run_id,
        rooms_total: rows.len() as i32,
        hints_granted,
        chain_ok_count,
        safety_ok_count,
        catalog_hits,
        digest_hex,
        rooms: rows,
    }
}
