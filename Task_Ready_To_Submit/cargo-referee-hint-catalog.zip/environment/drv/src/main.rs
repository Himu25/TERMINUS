mod slot_a;
mod digest;
mod driver;
mod linkstep;
mod policy;
mod scenario;

use std::env;
use std::path::PathBuf;

fn main() {
    let fixture = env::var("TB_HINT_FIXTURE").unwrap_or_default();
    let session_path = if fixture == "1" {
        PathBuf::from("/app/data/active/session.json")
    } else {
        PathBuf::from(
            env::args()
                .nth(1)
                .unwrap_or_else(|| "/app/data/active/session.json".to_string()),
        )
    };
    let report = driver::run_session(&session_path);
    let out = PathBuf::from("/app/output/hint_unlock_report.json");
    std::fs::create_dir_all(out.parent().unwrap()).ok();
    std::fs::write(&out, serde_json::to_string_pretty(&report).unwrap()).unwrap();
}
