use super::cache_b;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SlotRow {
    pub room_id: String,
    pub tier: i32,
    pub manual_page: String,
    pub hint_token: String,
    pub chain_rank: i32,
    pub prior_token: Option<String>,
    pub solution_guard: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub chain_id: Option<String>,
}

/// FetchA loads authoritative room facts for a single room id.
pub fn fetch_a(room_id: &str) -> Option<SlotRow> {
    cache_b::cache_b(room_id)
}
