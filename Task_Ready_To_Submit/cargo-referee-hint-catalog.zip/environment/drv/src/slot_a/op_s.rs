use std::env;

/// OpS reads an optional override path from the environment.
pub fn op_s() -> String {
    env::var("TB_STORE_PATH").unwrap_or_else(|_| "/app/store/rooms.duckdb".into())
}
