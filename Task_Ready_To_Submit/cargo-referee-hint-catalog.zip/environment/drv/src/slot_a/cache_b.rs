use super::SlotRow;
use std::path::Path;

/// CacheB serves warm room rows from on-disk exports under /app/data/fixtures.
pub fn cache_b(room_id: &str) -> Option<SlotRow> {
    let fixture = Path::new("/app/data/fixtures").join(format!("{room_id}.json"));
    if !fixture.exists() {
        return None;
    }
    let raw = std::fs::read_to_string(fixture).ok()?;
    serde_json::from_str(&raw).ok()
}
