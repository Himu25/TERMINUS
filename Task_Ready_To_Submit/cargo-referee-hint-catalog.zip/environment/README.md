Archivist Lens cargo-puzzle referee with DuckDB catalog, OPA hint policies, and Markdown operator manuals.
