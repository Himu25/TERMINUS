use sha2::{Digest, Sha256};
use std::env;

fn main() {
    let args: Vec<String> = env::args().collect();
    let run_id = args.get(1).map(|s| s.as_str()).unwrap_or("");
    let hints = args.get(2).map(|s| s.as_str()).unwrap_or("0");
    let chain = args.get(3).map(|s| s.as_str()).unwrap_or("0");
    let safety = args.get(4).map(|s| s.as_str()).unwrap_or("0");
    let catalog = args.get(5).map(|s| s.as_str()).unwrap_or("0");
    let payload = format!("{run_id}|{hints}|{chain}|{safety}|{catalog}");
    let digest = Sha256::digest(payload.as_bytes());
    print!("{:x}", digest);
}
