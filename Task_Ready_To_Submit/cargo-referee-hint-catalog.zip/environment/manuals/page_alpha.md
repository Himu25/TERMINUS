# Alpha crane manual

Tier-one cargo rooms expose alpha crane vocabulary. First hint token in a chain is always tier-one.
