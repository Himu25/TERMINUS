# Gamma stack manual

Tier-three rooms close the primary chain after beta lift token is granted.
