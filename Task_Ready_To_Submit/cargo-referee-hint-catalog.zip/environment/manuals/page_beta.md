# Beta lift manual

Tier-two rooms require the alpha-chain head token before beta lift hints unlock.
