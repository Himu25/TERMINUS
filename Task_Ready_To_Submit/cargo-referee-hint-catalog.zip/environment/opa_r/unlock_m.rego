package hint

import data.gate_a.gate_ok
import data.gate_c.lane_ok
import data.guard_b.guard_ok

default decision = {
    "grant": false,
    "manual_page": "",
    "hint_token": "",
    "chain_ok": false,
    "safety_ok": false,
}

decision = {
    "grant": grant,
    "manual_page": input.room.manual_page,
    "hint_token": input.room.hint_token,
    "chain_ok": gate_ok,
    "safety_ok": guard_ok,
} {
    grant := gate_ok
    grant
    guard_ok
}
