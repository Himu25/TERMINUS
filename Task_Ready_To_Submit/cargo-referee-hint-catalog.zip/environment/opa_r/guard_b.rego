package guard_b

default guard_ok = true

guard_ok {
    input.room.hint_token != ""
}
