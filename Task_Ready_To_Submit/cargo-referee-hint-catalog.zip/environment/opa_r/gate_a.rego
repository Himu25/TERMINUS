package gate_a

default gate_ok = false

gate_ok {
    input.room.room_id != ""
}
