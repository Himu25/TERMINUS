package gate_c

default lane_ok = true

lane_ok {
    input.room.room_id != ""
}
