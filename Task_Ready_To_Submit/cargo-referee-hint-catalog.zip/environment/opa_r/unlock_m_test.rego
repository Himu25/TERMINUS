package hint_test

import data.hint.decision

test_decision_fields_present {
    d := decision with input as {
        "room": {
            "room_id": "rm_alpha",
            "tier": 1,
            "manual_page": "page_alpha",
            "hint_token": "token_a1",
            "chain_rank": 1,
            "prior_token": null,
            "solution_guard": "SOLUTION:alpha_crane",
            "chain_id": "chain_primary",
        },
        "granted_tokens": [],
        "prior_chain": null,
    }
    d.grant == true
    d.chain_ok == true
    d.safety_ok == true
}

test_mid_chain_without_ledger {
    d := decision with input as {
        "room": {
            "room_id": "rm_beta",
            "tier": 2,
            "manual_page": "page_beta",
            "hint_token": "token_b2",
            "chain_rank": 2,
            "prior_token": "token_a1",
            "solution_guard": "SOLUTION:beta_lift",
            "chain_id": "chain_primary",
        },
        "granted_tokens": [],
        "prior_chain": "chain_primary",
    }
    d.grant == false
}

test_solution_literal_rejected {
    d := decision with input as {
        "room": {
            "room_id": "rm_alpha",
            "tier": 1,
            "manual_page": "page_alpha",
            "hint_token": "SOLUTION:alpha_crane",
            "chain_rank": 1,
            "prior_token": null,
            "solution_guard": "SOLUTION:alpha_crane",
            "chain_id": "chain_primary",
        },
        "granted_tokens": [],
        "prior_chain": null,
    }
    d.safety_ok == false
}

test_shadow_tail_needs_lane_head {
    d := decision with input as {
        "room": {
            "room_id": "rm_epsilon",
            "tier": 2,
            "manual_page": "page_beta",
            "hint_token": "token_e5",
            "chain_rank": 2,
            "prior_token": "token_d4",
            "solution_guard": "SOLUTION:epsilon_pallet",
            "chain_id": "chain_shadow",
        },
        "granted_tokens": ["token_a1"],
        "prior_chain": "chain_shadow",
    }
    d.grant == false
}
