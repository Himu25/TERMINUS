CREATE TABLE rooms (
    room_id TEXT PRIMARY KEY,
    tier INTEGER NOT NULL,
    manual_page TEXT NOT NULL,
    hint_token TEXT NOT NULL,
    chain_rank INTEGER NOT NULL,
    prior_token TEXT,
    solution_guard TEXT NOT NULL
);

CREATE TABLE hint_chains (
    chain_id TEXT PRIMARY KEY,
    head_room TEXT NOT NULL,
    tail_room TEXT NOT NULL
);
