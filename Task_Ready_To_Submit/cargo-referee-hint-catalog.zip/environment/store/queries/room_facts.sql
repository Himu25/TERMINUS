SELECT room_id, tier, manual_page, hint_token, chain_rank, prior_token, solution_guard
FROM rooms
WHERE room_id = ?
ORDER BY chain_rank ASC;
