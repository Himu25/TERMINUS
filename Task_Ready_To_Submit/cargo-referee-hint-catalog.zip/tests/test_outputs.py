"""Verifier for cargo referee hint unlock report."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "hint_unlock_report.json"
VERIFY_BIN = Path("/tmp/referee_run_verify_bin")

ACTIVE_SESSION = APP / "data" / "active" / "session.json"
REPLAY_ALPHA_SESSION = APP / "data" / "replay" / "rm_alpha" / "session.json"
REPLAY_BETA_SESSION = APP / "data" / "replay" / "rm_beta" / "session.json"
REPLAY_GAMMA_SESSION = APP / "data" / "replay" / "rm_gamma" / "session.json"
REPLAY_DELTA_SESSION = APP / "data" / "replay" / "rm_delta" / "session.json"
REPLAY_EPSILON_SESSION = APP / "data" / "replay" / "rm_epsilon" / "session.json"
REPLAY_INDEX = APP / "docs" / "replay_index.txt"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {**os.environ, "CARGO_TARGET_DIR": "/tmp/cargo-target"}
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)
    subprocess.run(["cp", "/app/bin/referee_run", str(VERIFY_BIN)], check=True)


def _digest_hex(run_id: str, hints: int, chain: int, safety: int, catalog: int) -> str:
    proc = subprocess.run(
        [
            str(APP / "bin" / "digest_cli"),
            run_id,
            str(hints),
            str(chain),
            str(safety),
            str(catalog),
        ],
        capture_output=True,
        text=True,
        check=True,
    )
    return proc.stdout.strip()


def _ordered_room_ids(room_ids: list[str]) -> list[str]:
    quoted = ", ".join(f"'{room_id}'" for room_id in room_ids)
    sql = (
        "SELECT room_id FROM rooms WHERE room_id IN ("
        f"{quoted}) ORDER BY chain_rank ASC, room_id ASC"
    )
    proc = subprocess.run(
        ["duckdb", "-csv", "/app/store/rooms.duckdb", sql],
        capture_output=True,
        text=True,
        check=True,
    )
    lines = [line.strip() for line in proc.stdout.splitlines() if line.strip()]
    return lines[1:]


def _load_session(path: Path) -> dict:
    return json.loads(path.read_text())


def _run_session(app_session_path: Path) -> dict:
    subprocess.run([str(VERIFY_BIN), str(app_session_path)], cwd="/app", check=True)
    return json.loads(OUT.read_text())


def test_opa_policy_suite_passes() -> None:
    """Static OPA analysis tests must pass."""
    proc = subprocess.run(
        ["opa", "test", "/app/opa_r", "-v"],
        capture_output=True,
        text=True,
    )
    assert proc.returncode == 0, proc.stdout + proc.stderr


def test_active_report_shape() -> None:
    """Active replay emits the documented report fields."""
    session = _load_session(ACTIVE_SESSION)
    report = _run_session(ACTIVE_SESSION)
    for key in (
        "schema_version",
        "run_id",
        "rooms_total",
        "hints_granted",
        "chain_ok_count",
        "safety_ok_count",
        "catalog_hits",
        "digest_hex",
        "rooms",
    ):
        assert key in report
    assert report["run_id"] == session["run_id"]
    assert report["schema_version"] == "hint-v2"


def test_active_room_row_shape() -> None:
    """Each rooms row exposes the documented per-room report fields."""
    report = _run_session(ACTIVE_SESSION)
    for row in report["rooms"]:
        for key in (
            "room_id",
            "manual_page",
            "hint_token",
            "granted",
            "chain_ok",
            "safety_ok",
        ):
            assert key in row


def test_active_grant_totals() -> None:
    """Primary session grants every chained room once store and bundles are correct."""
    session = _load_session(ACTIVE_SESSION)
    expected = len(session["failed_rooms"])
    report = _run_session(ACTIVE_SESSION)
    assert report["rooms_total"] == expected
    assert report["hints_granted"] == expected
    assert report["chain_ok_count"] == expected
    assert report["safety_ok_count"] == expected
    assert report["catalog_hits"] == expected


def test_active_room_sequence() -> None:
    """Rooms evaluate in store chain_rank order with stable room_id tie-break."""
    session = _load_session(ACTIVE_SESSION)
    expected = _ordered_room_ids(session["failed_rooms"])
    report = _run_session(ACTIVE_SESSION)
    ids = [row["room_id"] for row in report["rooms"]]
    assert ids == expected


def test_active_grant_consistency() -> None:
    """Granted rows align with chain and safety gates for every room."""
    report = _run_session(ACTIVE_SESSION)
    for row in report["rooms"]:
        assert row["granted"] == (row["chain_ok"] and row["safety_ok"])
    assert sum(1 for row in report["rooms"] if row["granted"]) == report["hints_granted"]


def test_active_digest_hex() -> None:
    """Report digest matches the documented fold."""
    session = _load_session(ACTIVE_SESSION)
    report = _run_session(ACTIVE_SESSION)
    n = len(session["failed_rooms"])
    expected = _digest_hex(session["run_id"], n, n, n, n)
    assert report["digest_hex"] == expected


def test_replay_gamma_chain_tail() -> None:
    """Gamma replay grants the tier-three tail after beta prerequisite."""
    session = _load_session(REPLAY_GAMMA_SESSION)
    report = _run_session(REPLAY_GAMMA_SESSION)
    assert report["hints_granted"] == len(session["failed_rooms"])
    tail = report["rooms"][-1]
    assert tail["room_id"] == session["failed_rooms"][-1]
    assert tail["granted"] == (tail["chain_ok"] and tail["safety_ok"])


def test_replay_delta_shadow_chain() -> None:
    """Shadow lane replay orders delta before epsilon per catalog chain_rank."""
    session = _load_session(REPLAY_DELTA_SESSION)
    expected = _ordered_room_ids(session["failed_rooms"])
    report = _run_session(REPLAY_DELTA_SESSION)
    assert report["hints_granted"] == len(session["failed_rooms"])
    assert [row["room_id"] for row in report["rooms"]] == expected
    assert all(row["granted"] == (row["chain_ok"] and row["safety_ok"]) for row in report["rooms"])


def test_replay_alpha_single_head() -> None:
    """Single-room replay grants only the head token."""
    session = _load_session(REPLAY_ALPHA_SESSION)
    report = _run_session(REPLAY_ALPHA_SESSION)
    assert report["hints_granted"] == len(session["failed_rooms"])
    row = report["rooms"][0]
    assert row["granted"] == (row["chain_ok"] and row["safety_ok"])


def test_replay_beta_pair_count() -> None:
    """Two-room primary chain replay grants alpha then beta."""
    session = _load_session(REPLAY_BETA_SESSION)
    expected = _ordered_room_ids(session["failed_rooms"])
    report = _run_session(REPLAY_BETA_SESSION)
    assert report["hints_granted"] == len(session["failed_rooms"])
    assert [row["room_id"] for row in report["rooms"]] == expected


def test_store_row_count() -> None:
    """Store hits reflect DuckDB rows, not missing fixture files."""
    session = _load_session(ACTIVE_SESSION)
    report = _run_session(ACTIVE_SESSION)
    assert report["catalog_hits"] == len(session["failed_rooms"])


def test_replay_epsilon_indexed_chain() -> None:
    """Indexed epsilon replay grants delta head then epsilon tail."""
    session = _load_session(REPLAY_EPSILON_SESSION)
    expected = _ordered_room_ids(session["failed_rooms"])
    report = _run_session(REPLAY_EPSILON_SESSION)
    assert report["hints_granted"] == len(session["failed_rooms"])
    assert [row["room_id"] for row in report["rooms"]] == expected
    assert all(row["granted"] == (row["chain_ok"] and row["safety_ok"]) for row in report["rooms"])


def test_shadow_lane_tail_requires_lane_head() -> None:
    """Shadow-lane epsilon grants only after delta head token is in the ledger."""
    report = _run_session(REPLAY_EPSILON_SESSION)
    by_id = {row["room_id"]: row for row in report["rooms"]}
    assert by_id["rm_delta"]["granted"] is True
    tail = by_id["rm_epsilon"]
    assert tail["granted"] == (tail["chain_ok"] and tail["safety_ok"])


def test_primary_lane_token_does_not_unlock_shadow_tail() -> None:
    """Primary-lane ledger tokens must not satisfy shadow-lane prerequisites alone."""
    session = _load_session(ACTIVE_SESSION)
    report = _run_session(ACTIVE_SESSION)
    by_id = {row["room_id"]: row for row in report["rooms"]}
    assert by_id["rm_alpha"]["granted"] is True
    epsilon = by_id["rm_epsilon"]
    assert epsilon["room_id"] == session["failed_rooms"][-1]
    assert epsilon["granted"] == (epsilon["chain_ok"] and epsilon["safety_ok"])


def test_replay_index_lists_all_sessions() -> None:
    """Every replay path in replay_index.txt is present and replayable."""
    paths = [Path(line.strip()) for line in REPLAY_INDEX.read_text().splitlines() if line.strip()]
    assert paths, "replay_index.txt must list at least one session path"
    for path in paths:
        assert path.is_file(), f"missing indexed replay session: {path}"
        session = _load_session(path)
        report = _run_session(path)
        assert report["hints_granted"] == len(session["failed_rooms"])
