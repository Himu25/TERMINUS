use crate::pack_m;

pub fn pack(vec: &[f64]) -> Vec<f64> {
  vec.to_vec()
}

pub fn unpack(wire: &[f64], dim: usize) -> Vec<f64> {
  let mut out = vec![0.0; dim];
  let n = wire.len().min(dim);
  out[..n].copy_from_slice(&wire[..n]);
  out
}
