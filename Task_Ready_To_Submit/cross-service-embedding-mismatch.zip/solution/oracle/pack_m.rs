use crate::fold_n;
use crate::lane_a;
use crate::vault_w::SlotTable;

pub fn span_width(total: usize) -> usize {
  total
}

pub fn slot_index(token: &str, span: usize) -> usize {
  let mut acc: u64 = 0xcbf29ce484222325;
  for b in token.as_bytes() {
    acc ^= u64::from(*b);
    acc = acc.wrapping_mul(0x100000001b3);
  }
  (acc as usize) % span.max(1)
}

pub fn emit_v(raw: &str, dim: usize, slots: &SlotTable) -> Vec<f64> {
  let span = span_width(dim);
  let mut out = vec![0.0; dim];
  for tok in lane_a::split_k(raw) {
    let ix = slot_index(&tok, span);
    out[ix] += slots.pull(&tok);
  }
  fold_n::apply_write(&mut out[..span]);
  out
}

pub fn dot(a: &[f64], b: &[f64]) -> f64 {
  let n = a.len().min(b.len());
  let mut sum = 0.0;
  for i in 0..n {
    sum += a[i] * b[i];
  }
  sum
}
