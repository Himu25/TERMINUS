use crate::codec_q;
use serde::Deserialize;
use std::fs;

#[derive(Debug, Deserialize)]
struct Contract {
  wire_layout: String,
}

fn contract_layout() -> String {
  let raw = fs::read_to_string("/app/registry/deploy_contract.json").unwrap_or_default();
  serde_json::from_str::<Contract>(&raw)
    .map(|c| c.wire_layout)
    .unwrap_or_else(|_| "le64".to_string())
}

pub fn ingress(wire: &[f64], dim: usize) -> Vec<f64> {
  let bytes = codec_q::encode(wire);
  codec_q::decode(&bytes, dim)
}

pub fn layout_ok() -> u32 {
  if contract_layout() == codec_q::layout_tag() {
    1
  } else {
    0
  }
}
