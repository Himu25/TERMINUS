use serde::Deserialize;
use std::collections::HashMap;
use std::fs;

#[derive(Debug, Deserialize)]
struct Contract {
  prep_rev: u32,
  prep_active: String,
  model_rev: u32,
  model_active: String,
  vector_dim: usize,
}

#[derive(Debug, Deserialize)]
struct SlotFile {
  rev: u32,
  slots: HashMap<String, f64>,
}

pub struct SlotTable {
  pub loaded_rev: u32,
  pub manifest_rev: u32,
  map: HashMap<String, f64>,
  default_gain: f64,
}

fn read_contract() -> Result<Contract, String> {
  let raw = fs::read_to_string("/app/registry/deploy_contract.json").map_err(|e| e.to_string())?;
  serde_json::from_str(&raw).map_err(|e| e.to_string())
}

fn load_from(path: &str, manifest_rev: u32) -> Result<SlotTable, String> {
  let body = fs::read_to_string(path).map_err(|e| e.to_string())?;
  let parsed: SlotFile = serde_json::from_str(&body).map_err(|e| e.to_string())?;
  Ok(SlotTable {
    loaded_rev: parsed.rev,
    manifest_rev,
    map: parsed.slots,
    default_gain: 1.0,
  })
}

impl SlotTable {
  pub fn load_write() -> Result<Self, String> {
    let contract = read_contract()?;
    let path = format!("/app/registry/{}", contract.model_active);
    load_from(&path, contract.model_rev)
  }

  pub fn load_read() -> Result<Self, String> {
    let contract = read_contract()?;
    let path = format!("/app/registry/{}", contract.model_active);
    load_from(&path, contract.model_rev)
  }

  pub fn pull(&self, token: &str) -> f64 {
    self.map.get(token).copied().unwrap_or(self.default_gain)
  }

  pub fn manifest_dim(&self) -> usize {
    read_contract().map(|c| c.vector_dim).unwrap_or(64)
  }

  pub fn prep_rev_manifest(&self) -> u32 {
    read_contract().map(|c| c.prep_rev).unwrap_or(0)
  }

  pub fn prep_active_manifest(&self) -> String {
    read_contract()
      .map(|c| c.prep_active)
      .unwrap_or_else(|_| "vocab_r5.txt".to_string())
  }
}
