use serde::Deserialize;
use std::collections::HashMap;
use std::fs;

#[derive(Debug, Deserialize)]
struct Contract {
  alias_rev: u32,
  alias_active: String,
}

fn load_table(path: &str) -> HashMap<String, String> {
  let mut out = HashMap::new();
  let Ok(body) = fs::read_to_string(path) else {
    return out;
  };
  for line in body.lines() {
    let line = line.trim();
    if line.is_empty() || line.starts_with('#') {
      continue;
    }
    let mut parts = line.split_whitespace();
    let Some(src) = parts.next() else {
      continue;
    };
    let Some(dst) = parts.next() else {
      continue;
    };
    out.insert(src.to_string(), dst.to_string());
  }
  out
}

fn contract() -> Contract {
  let raw = fs::read_to_string("/app/registry/deploy_contract.json").unwrap_or_default();
  serde_json::from_str(&raw).unwrap_or(Contract {
    alias_rev: 5,
    alias_active: "alias_v5.txt".to_string(),
  })
}

fn active_table() -> HashMap<String, String> {
  let c = contract();
  load_table(&format!("/app/registry/{}", c.alias_active))
}

fn map_tokens(tokens: &[String], table: &HashMap<String, String>) -> Vec<String> {
  tokens
    .iter()
    .map(|t| table.get(t).cloned().unwrap_or_else(|| t.clone()))
    .collect()
}

pub fn map_write(tokens: &[String]) -> Vec<String> {
  map_tokens(tokens, &active_table())
}

pub fn map_read(tokens: &[String]) -> Vec<String> {
  map_tokens(tokens, &active_table())
}

pub fn rev_write() -> u32 {
  contract().alias_rev
}

pub fn rev_read() -> u32 {
  contract().alias_rev
}

pub fn rev_manifest() -> u32 {
  contract().alias_rev
}

pub fn rewrite_write(raw: &str) -> String {
  map_write(&vec![raw.to_string()]).join(" ")
}

pub fn rewrite_read(raw: &str) -> String {
  map_read(&vec![raw.to_string()]).join(" ")
}
