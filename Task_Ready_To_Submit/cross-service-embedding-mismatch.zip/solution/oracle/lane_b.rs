use std::collections::HashSet;
use std::fs;
use std::sync::OnceLock;

static STOPS: OnceLock<HashSet<String>> = OnceLock::new();

fn stop_set() -> &'static HashSet<String> {
  STOPS.get_or_init(|| {
    let mut out = HashSet::new();
    if let Ok(raw) = fs::read_to_string("/app/config/stopwords.txt") {
      for tok in raw.split_whitespace() {
        out.insert(tok.to_ascii_lowercase());
      }
    }
    out
  })
}

fn lex_path() -> String {
  #[derive(serde::Deserialize)]
  struct Contract {
    prep_active: String,
  }
  let raw = fs::read_to_string("/app/registry/deploy_contract.json").unwrap_or_default();
  if let Ok(c) = serde_json::from_str::<Contract>(&raw) {
    return format!("/app/registry/{}", c.prep_active);
  }
  "/app/registry/vocab_r5.txt".to_string()
}

fn load_merges() -> Vec<String> {
  let Ok(body) = fs::read_to_string(lex_path()) else {
    return Vec::new();
  };
  body.lines()
    .map(str::trim)
    .filter(|line| !line.is_empty() && !line.starts_with('#'))
    .map(str::to_string)
    .collect()
}

fn split_legacy(raw: &str) -> Vec<String> {
  raw.to_ascii_lowercase()
    .split_whitespace()
    .map(str::to_string)
    .collect()
}

fn split_current(raw: &str) -> Vec<String> {
  let mut tokens = Vec::new();
  let mut cur = String::new();
  let flush = |cur: &mut String, tokens: &mut Vec<String>| {
    if !cur.is_empty() {
      tokens.push(cur.clone());
      cur.clear();
    }
  };
  for ch in raw.to_ascii_lowercase().chars() {
    if ch.is_ascii_alphanumeric() || ch == '-' || ch == '.' {
      cur.push(ch);
    } else {
      flush(&mut cur, &mut tokens);
    }
  }
  flush(&mut cur, &mut tokens);
  let stops = stop_set();
  tokens
    .into_iter()
    .filter(|t| !stops.contains(t))
    .collect()
}

pub fn split_k(raw: &str) -> Vec<String> {
  let merges = load_merges();
  if merges.is_empty() {
    return crate::table_u5::map_read(&split_legacy(raw));
  }
  let mut tokens = split_current(raw);
  for pair in merges {
    let parts: Vec<&str> = pair.split_whitespace().collect();
    if parts.len() == 2 {
      let needle = format!("{} {}", parts[0], parts[1]);
      let glued = format!("{}{}", parts[0], parts[1]);
      tokens = tokens
        .into_iter()
        .flat_map(|t| {
          if t == needle {
            vec![glued.clone()]
          } else {
            vec![t]
          }
        })
        .collect();
    }
  }
  crate::table_u5::map_read(&tokens)
}

pub fn table_rev() -> u32 {
  5
}
