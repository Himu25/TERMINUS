#!/bin/bash
set -euo pipefail

log() { printf '[oracle] %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

log "preflight: cross-service parity workspace"
require_file /app/Cargo.toml
require_file /app/config/parity.toml
require_file /app/registry/deploy_contract.json
require_file /app/data/corpus_default.json
require_file /app/data/query_specs.jsonl
for f in lane_a lane_b pack_m fold_n vault_w scan_h buf_n codec_q gate_v8 table_u5; do
  require_file "${ROOT_DIR}/oracle/${f}.rs"
done
mkdir -p /app/bin /app/output

log "survey: deploy contract and parity floors"
python3 - <<'PY'
import json
from pathlib import Path
contract = json.loads(Path("/app/registry/deploy_contract.json").read_text())
print("prep_rev", contract.get("prep_rev"))
print("model_rev", contract.get("model_rev"))
print("alias_rev", contract.get("alias_rev"))
print("wire_layout", contract.get("wire_layout"))
for line in Path("/app/config/parity.toml").read_text().splitlines():
    if "floor" in line or "min_" in line:
        print(line.strip())
PY

log "align ingest-side prep table with contract"
cp "${ROOT_DIR}/oracle/lane_a.rs" /app/ingest_k7/lane_a/mod.rs

log "align search-side prep table with contract"
cp "${ROOT_DIR}/oracle/lane_b.rs" /app/query_m4/lane_b/mod.rs

log "restore full-width ingest materialization"
cp "${ROOT_DIR}/oracle/pack_m.rs" /app/ingest_k7/pack_m/mod.rs

log "restore search scoring over full wire vectors"
cp "${ROOT_DIR}/oracle/scan_h.rs" /app/query_m4/scan_h/mod.rs

log "align post-process stages on both service paths"
cp "${ROOT_DIR}/oracle/fold_n.rs" /app/fold_n/mod.rs

log "load matching weight bundle on writer and reader"
cp "${ROOT_DIR}/oracle/vault_w.rs" /app/vault_w/mod.rs

log "stop truncating vectors on the cross-service wire"
cp "${ROOT_DIR}/oracle/buf_n.rs" /app/brdg/buf_n/mod.rs

log "repair le64 byte bank roundtrip on the gateway hop"
cp "${ROOT_DIR}/oracle/codec_q.rs" /app/brdg/codec_q/mod.rs

log "restore gateway ingress without layout drift"
cp "${ROOT_DIR}/oracle/gate_v8.rs" /app/hop_p2/gate_v8/mod.rs

log "sync legacy alias tables across writer and reader"
cp "${ROOT_DIR}/oracle/table_u5.rs" /app/shrd/table_u5/mod.rs

log "rebuild parity bench binaries"
export CARGO_TARGET_DIR=/app/output/cargo-target
cd /app
cargo build --release --manifest-path /app/Cargo.toml
install -m 0755 /app/output/cargo-target/release/goldgen /app/bin/goldgen
install -m 0755 /app/output/cargo-target/release/parity_bench /app/bin/parity_bench

log "regenerate default query gold labels"
/app/bin/goldgen \
  /app/data/corpus_default.json \
  /app/data/query_specs.jsonl \
  /app/data/queries_default.jsonl

log "write default parity bench report"
/app/bin/parity_bench \
  /app/data/queries_default.jsonl \
  /app/output/cross_parity_bench.json

log "post-run validation against parity.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg = {}
for line in Path("/app/config/parity.toml").read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    key, val = line.split("=", 1)
    key, val = key.strip(), val.strip()
    if key.endswith("_floor") or key.startswith("min_"):
        cfg[key] = float(val)
    elif key == "billing_pack_min_gold_hits":
        cfg[key] = int(float(val))

report = json.loads(Path("/app/output/cross_parity_bench.json").read_text())
contract = json.loads(Path("/app/registry/deploy_contract.json").read_text())
assert report["status"] == "ok", report
assert report["active_write_dim"] == report["vector_dim"], report
assert report["active_read_dim"] == report["vector_dim"], report
assert report["cross_cosine_parity_rate"] >= cfg["min_cross_cosine"], report
assert report["wire_byte_parity_rate"] >= cfg["min_wire_byte_parity"], report
assert report["alias_preserve_rate"] >= cfg["min_alias_preserve"], report
assert report["gateway_layout_ok"] == 1, report
assert report["prep_rev_writer"] == contract["prep_rev"], report
assert report["prep_rev_reader"] == contract["prep_rev"], report
assert report["alias_rev_writer"] == contract["alias_rev"], report
assert report["alias_rev_reader"] == contract["alias_rev"], report
assert report["model_rev_writer"] == contract["model_rev"], report
assert report["model_rev_reader"] == contract["model_rev"], report
assert report["mean_recall_at_10"] >= cfg["recall_floor"], report
assert report["mean_ndcg_at_10"] >= cfg["ndcg_floor"], report
billing = next(q for q in report["queries"] if q["query_id"] == "q_billing_refund")
assert billing["recall_at_10"] >= cfg["billing_pack_recall_floor"], billing
assert billing["gold_hits"] >= cfg["billing_pack_min_gold_hits"], billing
print(
    "ok",
    report["cross_cosine_parity_rate"],
    report["wire_byte_parity_rate"],
    report["alias_preserve_rate"],
    report["mean_recall_at_10"],
)
PY

log "oracle complete"
