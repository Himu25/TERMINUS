"""Validate cross_parity_bench.json after cross-service embedding repair."""

from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "cross_parity_bench.json"
CFG = APP / "config" / "parity.toml"
CONTRACT = APP / "registry" / "deploy_contract.json"
FIXTURES = Path(__file__).resolve().parent / "fixtures"
VERIFIER_CARGO_TARGET = Path("/app/output/verifier-cargo-target")
CARGO_BUILD_TIMEOUT_SEC = 540

REPORT_KEYS = frozenset(
    {
        "status",
        "corpus_vectors",
        "vector_dim",
        "active_write_dim",
        "active_read_dim",
        "queries_total",
        "cross_cosine_parity_rate",
        "wire_byte_parity_rate",
        "alias_preserve_rate",
        "prep_rev_writer",
        "prep_rev_reader",
        "prep_rev_manifest",
        "alias_rev_writer",
        "alias_rev_reader",
        "alias_rev_manifest",
        "model_rev_writer",
        "model_rev_reader",
        "model_rev_manifest",
        "gateway_layout_ok",
        "mean_recall_at_10",
        "mean_ndcg_at_10",
        "report_digest",
        "queries",
    }
)
QUERY_KEYS = frozenset(
    {"query_id", "recall_at_10", "ndcg_at_10", "gold_hits", "wire_dim_kept", "layout_ok"}
)

ENFORCED_FLOORS: dict[str, float | int] = {
    "recall_floor": 0.75,
    "ndcg_floor": 0.75,
    "min_cross_cosine": 0.95,
    "min_wire_byte_parity": 0.95,
    "min_alias_preserve": 0.90,
    "min_prep_match": 0.95,
    "min_model_match": 0.95,
    "tight_security_recall_floor": 0.5,
    "billing_pack_recall_floor": 0.6667,
    "billing_pack_min_gold_hits": 2,
    "legacy_alias_recall_floor": 0.5,
    "realm_ops_recall_floor": 0.55,
}


def _effective_floor(cfg: dict[str, float | int], key: str) -> float | int:
    return max(cfg[key], ENFORCED_FLOORS[key])


def _pass_status() -> str:
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line.startswith("pass_status"):
            return line.split("=", 1)[1].strip()
    return "ok"


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = dict(ENFORCED_FLOORS)
    cfg["vector_dim"] = 64
    cfg["top_k"] = 10
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in (
            "recall_floor",
            "ndcg_floor",
            "min_cross_cosine",
            "min_wire_byte_parity",
            "min_alias_preserve",
            "min_prep_match",
            "min_model_match",
            "tight_security_recall_floor",
            "billing_pack_recall_floor",
            "legacy_alias_recall_floor",
            "realm_ops_recall_floor",
        ):
            cfg[key] = float(val)
        elif key == "billing_pack_min_gold_hits":
            cfg[key] = int(float(val))
        elif key in ("vector_dim", "top_k"):
            cfg[key] = int(float(val))
    return cfg


def _contract() -> dict:
    return json.loads(CONTRACT.read_text(encoding="utf-8"))


def _digest_payload(report: dict) -> dict:
    return {
        "status": report["status"],
        "corpus_vectors": report["corpus_vectors"],
        "vector_dim": report["vector_dim"],
        "active_write_dim": report["active_write_dim"],
        "active_read_dim": report["active_read_dim"],
        "queries_total": report["queries_total"],
        "cross_cosine_parity_rate": report["cross_cosine_parity_rate"],
        "wire_byte_parity_rate": report["wire_byte_parity_rate"],
        "alias_preserve_rate": report["alias_preserve_rate"],
        "prep_rev_writer": report["prep_rev_writer"],
        "prep_rev_reader": report["prep_rev_reader"],
        "prep_rev_manifest": report["prep_rev_manifest"],
        "alias_rev_writer": report["alias_rev_writer"],
        "alias_rev_reader": report["alias_rev_reader"],
        "alias_rev_manifest": report["alias_rev_manifest"],
        "model_rev_writer": report["model_rev_writer"],
        "model_rev_reader": report["model_rev_reader"],
        "model_rev_manifest": report["model_rev_manifest"],
        "gateway_layout_ok": report["gateway_layout_ok"],
        "mean_recall_at_10": report["mean_recall_at_10"],
        "mean_ndcg_at_10": report["mean_ndcg_at_10"],
        "report_digest": "",
        "queries": report["queries"],
    }


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _rebuild_parity_bench(env: dict[str, str] | None = None) -> None:
    build_env = dict(env or os.environ.copy())
    build_env["CARGO_TARGET_DIR"] = str(VERIFIER_CARGO_TARGET)
    subprocess.run(
        ["cargo", "build", "--release", "--manifest-path", str(APP / "Cargo.toml")],
        cwd=APP,
        env=build_env,
        check=True,
        capture_output=True,
        text=True,
        timeout=CARGO_BUILD_TIMEOUT_SEC,
    )
    release = VERIFIER_CARGO_TARGET / "release"
    subprocess.run(
        ["install", "-m", "0755", str(release / "parity_bench"), "/app/bin/parity_bench"],
        check=True,
        capture_output=True,
        text=True,
    )
    subprocess.run(
        ["install", "-m", "0755", str(release / "goldgen"), "/app/bin/goldgen"],
        check=True,
        capture_output=True,
        text=True,
    )


def _goldgen(corpus_path: Path, specs_path: Path, out_path: Path) -> None:
    subprocess.run(
        [
            "/app/bin/goldgen",
            corpus_path.as_posix(),
            specs_path.as_posix(),
            out_path.as_posix(),
        ],
        check=True,
        capture_output=True,
        text=True,
    )


def _assert_query_row(row: dict) -> None:
    assert set(row) == QUERY_KEYS
    assert isinstance(row["query_id"], str) and row["query_id"]
    for key in ("recall_at_10", "ndcg_at_10"):
        assert isinstance(row[key], (int, float))
        assert 0.0 <= float(row[key]) <= 1.0
    assert isinstance(row["gold_hits"], int)
    assert isinstance(row["wire_dim_kept"], int)
    assert isinstance(row["layout_ok"], int)
    assert row["gold_hits"] >= 0
    assert row["wire_dim_kept"] >= 0
    assert row["layout_ok"] in (0, 1)


def _assert_report_schema(data: dict) -> None:
    assert set(data) == REPORT_KEYS
    assert isinstance(data["status"], str) and data["status"] in {_pass_status(), "fail"}
    for int_key in (
        "corpus_vectors",
        "vector_dim",
        "active_write_dim",
        "active_read_dim",
        "queries_total",
        "prep_rev_writer",
        "prep_rev_reader",
        "prep_rev_manifest",
        "alias_rev_writer",
        "alias_rev_reader",
        "alias_rev_manifest",
        "model_rev_writer",
        "model_rev_reader",
        "model_rev_manifest",
        "gateway_layout_ok",
    ):
        assert isinstance(data[int_key], int), int_key
        assert data[int_key] >= 0, int_key
    for float_key in (
        "cross_cosine_parity_rate",
        "wire_byte_parity_rate",
        "alias_preserve_rate",
        "mean_recall_at_10",
        "mean_ndcg_at_10",
    ):
        assert isinstance(data[float_key], (int, float)), float_key
        assert float(data[float_key]) >= 0.0, float_key
    digest = data["report_digest"]
    assert isinstance(digest, str) and len(digest) == 64
    assert digest == digest.lower()
    assert re.fullmatch(r"[0-9a-f]{64}", digest)
    assert isinstance(data["queries"], list)
    for row in data["queries"]:
        _assert_query_row(row)


def _load_report(path: Path = OUT) -> dict:
    assert path.is_file(), f"missing report at {path}"
    data = json.loads(path.read_text(encoding="utf-8"))
    _assert_report_schema(data)
    return data


def _run_bench(
    query_path: Path,
    out_path: Path = OUT,
    corpus_path: Path | None = None,
    *,
    rebuild: bool = False,
) -> None:
    env = os.environ.copy()
    if corpus_path is not None:
        env["TB_CORPUS_PATH"] = str(corpus_path)
    else:
        env.pop("TB_CORPUS_PATH", None)
    if out_path.exists():
        out_path.unlink()
    if rebuild:
        _rebuild_parity_bench(env)
    subprocess.run(
        [
            "/app/bin/parity_bench",
            query_path.as_posix(),
            out_path.as_posix(),
        ],
        cwd=APP,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )


def _query_row(report: dict, query_id: str) -> dict:
    return next(q for q in report["queries"] if q["query_id"] == query_id)


def _jsonl_lines(path: Path) -> int:
    return sum(1 for line in path.read_text(encoding="utf-8").splitlines() if line.strip())



@pytest.fixture(scope="session", autouse=True)
def _default_bench_run() -> None:
    _rebuild_parity_bench()
    _goldgen(
        APP / "data" / "corpus_default.json",
        APP / "data" / "query_specs.jsonl",
        APP / "data" / "queries_default.jsonl",
    )
    _run_bench(APP / "data" / "queries_default.jsonl")


def test_default_pass_status() -> None:
    """Default bench report status matches pass_status in parity.toml."""
    bench = APP / "bin" / "parity_bench"
    assert bench.is_file() and os.access(bench, os.X_OK)
    report = _load_report()
    assert report["status"] == _pass_status()


def test_corpus_vectors_populated() -> None:
    """Report indexes the full default corpus."""
    report = _load_report()
    assert report["corpus_vectors"] > 0


def test_report_schema_and_digest() -> None:
    """Default bench report matches architecture schema and digest contract."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_active_dims_match_vector_dim() -> None:
    """Healthy services use the full configured vector width on both paths."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["vector_dim"] == cfg["vector_dim"]
    assert report["active_write_dim"] == report["vector_dim"]
    assert report["active_read_dim"] == report["vector_dim"]


def test_parity_guardrails_not_neutered() -> None:
    """parity.toml quality floors remain at shipped thresholds."""
    cfg = _parse_cfg()
    for key, minimum in ENFORCED_FLOORS.items():
        assert cfg[key] >= minimum, f"{key} lowered below shipped floor"


def test_cross_cosine_parity_floor() -> None:
    """Stored wire vectors match reader-side re-encodes."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["cross_cosine_parity_rate"] >= _effective_floor(cfg, "min_cross_cosine")


def test_wire_byte_parity_floor() -> None:
    """Gateway byte-bank roundtrips preserve wire vectors."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["wire_byte_parity_rate"] >= _effective_floor(cfg, "min_wire_byte_parity")


def test_alias_preserve_floor() -> None:
    """Writer and reader prep lanes agree on alias-heavy probe text."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["alias_preserve_rate"] >= _effective_floor(cfg, "min_alias_preserve")


def test_gateway_layout_ok() -> None:
    """Gateway byte layout matches deploy contract wire_layout."""
    report = _load_report()
    assert report["gateway_layout_ok"] == 1
    for row in report["queries"]:
        assert row["layout_ok"] == 1


def test_prep_revision_aligned() -> None:
    """Writer and reader prep revisions match deploy contract."""
    report = _load_report()
    contract = _contract()
    assert report["prep_rev_writer"] == contract["prep_rev"]
    assert report["prep_rev_reader"] == contract["prep_rev"]
    assert report["prep_rev_manifest"] == contract["prep_rev"]


def test_alias_revision_aligned() -> None:
    """Writer and reader alias revisions match deploy contract."""
    report = _load_report()
    contract = _contract()
    assert report["alias_rev_writer"] == contract["alias_rev"]
    assert report["alias_rev_reader"] == contract["alias_rev"]
    assert report["alias_rev_manifest"] == contract["alias_rev"]


def test_model_revision_aligned() -> None:
    """Writer and reader load the contract weight bundle revision."""
    report = _load_report()
    contract = _contract()
    assert report["model_rev_writer"] == contract["model_rev"]
    assert report["model_rev_reader"] == contract["model_rev"]
    assert report["model_rev_manifest"] == contract["model_rev"]


def test_mean_recall_and_ndcg_floors() -> None:
    """Aggregate retrieval metrics meet parity.toml floors."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["mean_recall_at_10"] >= _effective_floor(cfg, "recall_floor")
    assert report["mean_ndcg_at_10"] >= _effective_floor(cfg, "ndcg_floor")


def test_queries_total_matches_jsonl() -> None:
    """Report query count matches non-empty default JSONL lines."""
    report = _load_report()
    expected = _jsonl_lines(APP / "data" / "queries_default.jsonl")
    assert report["queries_total"] == expected
    assert len(report["queries"]) == expected


def test_billing_refund_recall() -> None:
    """q_billing_refund retrieves billing-domain gold neighbors."""
    cfg = _parse_cfg()
    report = _load_report()
    row = _query_row(report, "q_billing_refund")
    assert row["recall_at_10"] >= _effective_floor(cfg, "billing_pack_recall_floor")
    assert row["gold_hits"] >= _effective_floor(cfg, "billing_pack_min_gold_hits")


def test_cross_billing_ops_recall() -> None:
    """q_cross_billing_ops keeps cross-realm billing recall."""
    cfg = _parse_cfg()
    report = _load_report()
    row = _query_row(report, "q_cross_billing_ops")
    assert row["recall_at_10"] >= _effective_floor(cfg, "billing_pack_recall_floor")


def test_deterministic_default_run() -> None:
    """Identical default inputs yield byte-identical bench output."""
    first = OUT.read_bytes()
    _run_bench(APP / "data" / "queries_default.jsonl", OUT, rebuild=True)
    second = OUT.read_bytes()
    assert first == second


def test_half_migrated_pack() -> None:
    """pack_half_migrated satisfies tight_security floor for q_tight_security."""
    pack = FIXTURES / "pack_half_migrated"
    specs = pack / "query_specs.jsonl"
    queries = pack / "queries.jsonl"
    _goldgen(APP / "data" / "corpus_default.json", specs, queries)
    out = APP / "output" / "bench_pack_half.json"
    _run_bench(queries, out, APP / "data" / "corpus_default.json")
    report = _load_report(out)
    row = _query_row(report, "q_tight_security")
    assert row["recall_at_10"] >= ENFORCED_FLOORS["tight_security_recall_floor"]


def test_skew_query_pack() -> None:
    """pack_skew_queries benches clean on default corpus."""
    pack = FIXTURES / "pack_skew_queries"
    specs = pack / "query_specs.jsonl"
    queries = pack / "queries.jsonl"
    _goldgen(APP / "data" / "corpus_default.json", specs, queries)
    out = APP / "output" / "bench_pack_skew.json"
    _run_bench(queries, out, APP / "data" / "corpus_default.json")
    report = _load_report(out)
    assert report["mean_recall_at_10"] >= ENFORCED_FLOORS["recall_floor"]


def test_unicode_prep_pack() -> None:
    """pack_unicode_prep regen gold and meets cross cosine floor."""
    pack = FIXTURES / "pack_unicode_prep"
    specs = pack / "query_specs.jsonl"
    queries = pack / "queries.jsonl"
    _goldgen(APP / "data" / "corpus_default.json", specs, queries)
    out = APP / "output" / "bench_pack_unicode.json"
    _run_bench(queries, out, APP / "data" / "corpus_default.json")
    report = _load_report(out)
    cfg = _parse_cfg()
    assert report["cross_cosine_parity_rate"] >= _effective_floor(cfg, "min_cross_cosine")


def test_legacy_alias_pack() -> None:
    """pack_legacy_alias meets legacy alias recall floor for q_legacy_wifi."""
    pack = FIXTURES / "pack_legacy_alias"
    specs = pack / "query_specs.jsonl"
    queries = pack / "queries.jsonl"
    _goldgen(APP / "data" / "corpus_default.json", specs, queries)
    out = APP / "output" / "bench_pack_legacy.json"
    _run_bench(queries, out, APP / "data" / "corpus_default.json")
    report = _load_report(out)
    cfg = _parse_cfg()
    row = _query_row(report, "q_legacy_wifi")
    assert row["recall_at_10"] >= _effective_floor(cfg, "legacy_alias_recall_floor")
    assert report["alias_preserve_rate"] >= _effective_floor(cfg, "min_alias_preserve")


def test_realm_ops_pack() -> None:
    """pack_realm_ops meets realm_ops recall floor for q_realm_ops_billing."""
    pack = FIXTURES / "pack_realm_ops"
    specs = pack / "query_specs.jsonl"
    queries = pack / "queries.jsonl"
    _goldgen(APP / "data" / "corpus_default.json", specs, queries)
    out = APP / "output" / "bench_pack_realm.json"
    _run_bench(queries, out, APP / "data" / "corpus_default.json")
    report = _load_report(out)
    cfg = _parse_cfg()
    row = _query_row(report, "q_realm_ops_billing")
    assert row["recall_at_10"] >= _effective_floor(cfg, "realm_ops_recall_floor")
    assert report["mean_recall_at_10"] >= ENFORCED_FLOORS["recall_floor"]


def test_broken_bank_ablation_fails_byte_parity() -> None:
    """Endian-mismatched byte bank cannot clear wire_byte_parity floor."""
    bank_src = APP / "brdg" / "codec_q" / "mod.rs"
    backup = bank_src.read_text(encoding="utf-8")
    out = APP / "output" / "ablation_bank.json"
    cfg = _parse_cfg()
    try:
        bank_src.write_text((FIXTURES / "broken_codec_q.rs").read_text(encoding="utf-8"), encoding="utf-8")
        _run_bench(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        assert report["wire_byte_parity_rate"] < cfg["min_wire_byte_parity"] or report["status"] == "fail"
    finally:
        bank_src.write_text(backup, encoding="utf-8")
        _rebuild_parity_bench()
        _run_bench(APP / "data" / "queries_default.jsonl")


def test_broken_route_ablation_fails_layout() -> None:
    """Gateway ingress drift forces layout_ok to zero on the default pack."""
    route_src = APP / "hop_p2" / "gate_v8" / "mod.rs"
    backup = route_src.read_text(encoding="utf-8")
    out = APP / "output" / "ablation_route.json"
    try:
        route_src.write_text((FIXTURES / "broken_gate_v8.rs").read_text(encoding="utf-8"), encoding="utf-8")
        _run_bench(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        assert report["gateway_layout_ok"] == 0 or report["status"] == "fail"
    finally:
        route_src.write_text(backup, encoding="utf-8")
        _rebuild_parity_bench()
        _run_bench(APP / "data" / "queries_default.jsonl")


def test_broken_alias_ablation_fails_preserve() -> None:
    """Stale reader alias table drops alias_preserve below the floor."""
    alias_src = APP / "shrd" / "table_u5" / "mod.rs"
    backup = alias_src.read_text(encoding="utf-8")
    out = APP / "output" / "ablation_alias.json"
    cfg = _parse_cfg()
    try:
        alias_src.write_text((FIXTURES / "broken_table_u5.rs").read_text(encoding="utf-8"), encoding="utf-8")
        _run_bench(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        assert report["alias_preserve_rate"] < cfg["min_alias_preserve"] or report["status"] == "fail"
    finally:
        alias_src.write_text(backup, encoding="utf-8")
        _rebuild_parity_bench()
        _run_bench(APP / "data" / "queries_default.jsonl")
