use std::collections::HashMap;
use std::fs;

fn load_table(path: &str) -> HashMap<String, String> {
  let mut out = HashMap::new();
  let Ok(body) = fs::read_to_string(path) else {
    return out;
  };
  for line in body.lines() {
    let line = line.trim();
    if line.is_empty() || line.starts_with('#') {
      continue;
    }
    let mut parts = line.split_whitespace();
    let Some(src) = parts.next() else { continue; };
    let Some(dst) = parts.next() else { continue; };
    out.insert(src.to_string(), dst.to_string());
  }
  out
}

pub fn map_write(tokens: &[String]) -> Vec<String> {
  tokens.to_vec()
}

pub fn map_read(tokens: &[String]) -> Vec<String> {
  let table = load_table("/app/registry/alias_v2.txt");
  tokens
    .iter()
    .map(|t| table.get(t).cloned().unwrap_or_else(|| t.clone()))
    .collect()
}

pub fn rev_write() -> u32 {
  5
}

pub fn rev_read() -> u32 {
  2
}

pub fn rev_manifest() -> u32 {
  5
}

pub fn rewrite_write(raw: &str) -> String {
  raw.to_string()
}

pub fn rewrite_read(raw: &str) -> String {
  raw.to_string()
}
