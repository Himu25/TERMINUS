#!/usr/bin/env bash
set -euo pipefail
/app/bin/goldgen \
  /app/data/corpus_default.json \
  /app/data/query_specs.jsonl \
  /app/data/queries_default.jsonl
/app/bin/parity_bench \
  /app/data/queries_default.jsonl \
  /app/output/cross_parity_bench.json
