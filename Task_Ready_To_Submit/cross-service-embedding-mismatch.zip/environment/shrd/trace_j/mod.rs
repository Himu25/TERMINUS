pub fn digest_hint(raw: &str) -> u64 {
  let mut acc: u64 = 0xcbf29ce484222325;
  for b in raw.as_bytes() {
    acc ^= u64::from(*b);
    acc = acc.wrapping_mul(0x100000001b3);
  }
  acc
}
