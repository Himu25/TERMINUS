use std::collections::HashSet;
use std::fs;
use std::sync::OnceLock;

static STOPS: OnceLock<HashSet<String>> = OnceLock::new();

fn stop_set() -> &'static HashSet<String> {
  STOPS.get_or_init(|| {
    let mut out = HashSet::new();
    if let Ok(raw) = fs::read_to_string("/app/config/stopwords.txt") {
      for tok in raw.split_whitespace() {
        out.insert(tok.to_ascii_lowercase());
      }
    }
    out
  })
}

fn lex_path() -> &'static str {
  "/app/registry/vocab_r3.txt"
}

fn load_merges() -> Vec<String> {
  let Ok(body) = fs::read_to_string(lex_path()) else {
    return Vec::new();
  };
  body.lines()
    .map(str::trim)
    .filter(|line| !line.is_empty() && !line.starts_with('#'))
    .map(str::to_string)
    .collect()
}

pub fn split_k(raw: &str) -> Vec<String> {
  let _ = load_merges();
  let _ = stop_set();
  raw.split_whitespace().map(str::to_string).collect()
}

pub fn table_rev() -> u32 {
  3
}
