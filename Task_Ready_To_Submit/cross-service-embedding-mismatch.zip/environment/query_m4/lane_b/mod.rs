use std::collections::HashSet;
use std::fs;
use std::sync::OnceLock;

static STOPS: OnceLock<HashSet<String>> = OnceLock::new();

fn stop_set() -> &'static HashSet<String> {
  STOPS.get_or_init(|| {
    let mut out = HashSet::new();
    if let Ok(raw) = fs::read_to_string("/app/config/stopwords.txt") {
      for tok in raw.split_whitespace() {
        out.insert(tok.to_ascii_lowercase());
      }
    }
    out
  })
}

fn split_legacy(raw: &str) -> Vec<String> {
  raw.to_ascii_lowercase()
    .split_whitespace()
    .map(str::to_string)
    .collect()
}

/// Split text on the query-side prep lane.
pub fn split_k(raw: &str) -> Vec<String> {
  let _ = stop_set();
  crate::table_u5::map_read(&split_legacy(raw))
}

pub fn table_rev() -> u32 {
  5
}
