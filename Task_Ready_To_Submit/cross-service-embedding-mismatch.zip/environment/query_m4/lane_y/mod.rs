use std::collections::HashMap;
use std::fs;

fn load_table() -> HashMap<String, String> {
  let mut out = HashMap::new();
  if let Ok(body) = fs::read_to_string("/app/registry/alias_v2.txt") {
    for line in body.lines() {
      let line = line.trim();
      if line.is_empty() || line.starts_with('#') {
        continue;
      }
      let mut parts = line.split_whitespace();
      let Some(src) = parts.next() else {
        continue;
      };
      let Some(dst) = parts.next() else {
        continue;
      };
      out.insert(src.to_string(), dst.to_string());
    }
  }
  out
}

pub fn split_k(raw: &str) -> Vec<String> {
  let table = load_table();
  raw
    .split(',')
    .map(|s| s.trim().to_string())
    .map(|t| table.get(&t).cloned().unwrap_or(t))
    .collect()
}

pub fn table_rev() -> u32 {
  2
}
