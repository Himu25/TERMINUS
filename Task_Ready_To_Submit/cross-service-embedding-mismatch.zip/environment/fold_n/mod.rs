fn l2_unit(slice: &mut [f64]) {
  let mut sum = 0.0;
  for v in slice.iter() {
    sum += v * v;
  }
  if sum == 0.0 {
    return;
  }
  let inv = 1.0 / sum.sqrt();
  for v in slice.iter_mut() {
    *v *= inv;
  }
}

/// Post-process vectors on the ingest materialization path.
pub fn apply_write(slice: &mut [f64]) {
  l2_unit(slice);
}

/// Post-process vectors on the online query path.
pub fn apply_read(slice: &mut [f64]) {
  let _ = slice;
}
