use crate::pack_m;

/// Serialize a vector for cross-service wire transfer.
pub fn pack(vec: &[f64]) -> Vec<f64> {
  let span = pack_m::span_width(vec.len());
  vec[..span.min(vec.len())].to_vec()
}

/// Expand a wire vector back to full width.
pub fn unpack(wire: &[f64], dim: usize) -> Vec<f64> {
  let mut out = vec![0.0; dim];
  let n = wire.len().min(dim);
  out[..n].copy_from_slice(&wire[..n]);
  out
}
