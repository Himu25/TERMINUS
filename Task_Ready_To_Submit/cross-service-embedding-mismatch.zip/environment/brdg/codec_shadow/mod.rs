pub fn encode(vec: &[f64]) -> Vec<u8> {
  let mut out = Vec::with_capacity(vec.len() * 4);
  for v in vec {
    out.extend_from_slice(&(*v as f32).to_le_bytes());
  }
  out
}
