pub fn layout_tag() -> &'static str {
  "be64"
}

pub fn encode(vec: &[f64]) -> Vec<u8> {
  let mut out = Vec::with_capacity(vec.len() * 8);
  for v in vec {
    out.extend_from_slice(&v.to_be_bytes());
  }
  out
}

pub fn decode(bytes: &[u8], dim: usize) -> Vec<f64> {
  let mut out = vec![0.0; dim];
  let count = (bytes.len() / 8).min(dim);
  for i in 0..count {
    let off = i * 8;
    if off + 8 > bytes.len() {
      break;
    }
    let chunk: [u8; 8] = bytes[off..off + 8].try_into().unwrap_or([0; 8]);
    out[i] = f64::from_le_bytes(chunk);
  }
  out
}
