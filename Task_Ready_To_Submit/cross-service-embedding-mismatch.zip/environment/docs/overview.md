Ingest writer and search reader are separate binaries sharing deploy_contract.json.
