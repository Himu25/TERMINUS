# Cross-service parity bench

The ingest writer, gateway relay, and search reader under `/app` each run their own prep, byte-bank, post-process normalization, weight tables, and vector materialization paths. Stored index vectors, reader-side re-encodes, gateway byte roundtrips, and realm-scoped retrieval can disagree when any stage drifts from `/app/registry/deploy_contract.json`.

## Report schema

`/app/output/cross_parity_bench.json` is JSON with:

- `status` — `ok` when all parity.toml floors pass, otherwise `fail`
- `corpus_vectors` — indexed document count
- `vector_dim` — contract width from parity.toml
- `active_write_dim` — width the ingest path keeps after wire packing
- `active_read_dim` — width the search path uses during scoring
- `queries_total` — non-empty query rows processed
- `cross_cosine_parity_rate` — fraction of corpus rows whose stored vector matches reader re-encode cosine ≥ 0.99
- `wire_byte_parity_rate` — fraction of wire vectors whose le64 bank roundtrip matches cosine ≥ 0.99
- `alias_preserve_rate` — fraction of alias-probe texts where writer and reader prep lanes emit identical token streams
- `prep_rev_writer`, `prep_rev_reader`, `prep_rev_manifest` — prep table revisions observed vs deploy_contract.json
- `alias_rev_writer`, `alias_rev_reader`, `alias_rev_manifest` — alias table revisions observed vs deploy_contract.json
- `model_rev_writer`, `model_rev_reader`, `model_rev_manifest` — weight bundle revisions observed vs deploy_contract.json
- `gateway_layout_ok` — 1 when gateway byte layout matches deploy_contract.json `wire_layout`, else 0
- `mean_recall_at_10`, `mean_ndcg_at_10` — retrieval aggregates
- `report_digest` — 64 lowercase hex chars over compact JSON of all other fields with report_digest cleared
- `queries` — array of rows with `query_id`, `recall_at_10`, `ndcg_at_10`, `gold_hits`, `wire_dim_kept`, and `layout_ok`

Digest uses serde_json compact serialization of the stub object above.

## Build layout

Release binaries install to `/app/bin`. Cargo builds use `CARGO_TARGET_DIR` under `/app/output/cargo-target`. External verifier rebuilds may use `/app/output/verifier-cargo-target/release` without clobbering agent artifacts.

## Fixture packs

Regression packs listed in `/app/docs/fixture_queries.txt` live under verifier fixture trees named `pack_half_migrated`, `pack_skew_queries`, `pack_unicode_prep`, `pack_legacy_alias`, and `pack_realm_ops`. Pack replay writes scratch reports such as `/app/output/bench_pack_half.json`, `/app/output/bench_pack_skew.json`, `/app/output/bench_pack_unicode.json`, `/app/output/bench_pack_legacy.json`, and `/app/output/bench_pack_realm.json`. Ablation replays may write `/app/output/ablation_bank.json`, `/app/output/ablation_route.json`, or `/app/output/ablation_alias.json`. External verifier rebuilds use `/app/output/verifier-cargo-target/release`.

## Floors

Shipped thresholds live in `/app/config/parity.toml`. The verifier enforces them even if the file is edited.
