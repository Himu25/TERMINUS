use crate::codec_q;

pub fn ingress(wire: &[f64], dim: usize) -> Vec<f64> {
  let bytes = codec_q::encode(wire);
  let mut out = codec_q::decode(&bytes, dim);
  if out.len() >= 2 {
    let head = out.remove(0);
    let tail = out.pop().unwrap_or(head);
    out.insert(0, tail);
    out.push(head);
  }
  out
}

pub fn layout_ok() -> u32 {
  0
}
