pub fn note_hop(_doc_id: &str) -> u32 {
  1
}
