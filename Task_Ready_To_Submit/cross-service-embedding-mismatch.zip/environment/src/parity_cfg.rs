use serde::Deserialize;
use std::fs;

#[derive(Debug, Clone, Deserialize)]
pub struct QueryRow {
  pub query_id: String,
  pub query: String,
  #[serde(default)]
  pub gold: Vec<String>,
}

#[derive(Debug, Clone)]
pub struct ParityCfg {
  pub pass_status: String,
  pub vector_dim: usize,
  pub top_k: usize,
  pub recall_floor: f64,
  pub ndcg_floor: f64,
  pub min_cross_cosine: f64,
  pub min_prep_match: f64,
  pub min_model_match: f64,
  pub min_wire_byte_parity: f64,
  pub min_alias_preserve: f64,
  pub corpus_path: String,
  pub billing_pack_recall_floor: f64,
  pub billing_pack_min_gold_hits: u32,
  pub tight_security_recall_floor: f64,
  pub legacy_alias_recall_floor: f64,
}

impl ParityCfg {
  pub fn load(path: &str) -> Result<Self, String> {
    let raw = fs::read_to_string(path).map_err(|e| e.to_string())?;
    let mut cfg = ParityCfg {
      pass_status: "ok".to_string(),
      vector_dim: 64,
      top_k: 10,
      recall_floor: 0.75,
      ndcg_floor: 0.75,
      min_cross_cosine: 0.95,
      min_prep_match: 0.95,
      min_model_match: 0.95,
      min_wire_byte_parity: 0.95,
      min_alias_preserve: 0.90,
      corpus_path: "/app/data/corpus_default.json".to_string(),
      billing_pack_recall_floor: 0.6667,
      billing_pack_min_gold_hits: 2,
      tight_security_recall_floor: 0.5,
      legacy_alias_recall_floor: 0.5,
    };
    for line in raw.lines() {
      let line = line.trim();
      if line.is_empty() || line.starts_with('#') {
        continue;
      }
      let Some((key, val)) = line.split_once('=') else {
        continue;
      };
      let key = key.trim();
      let val = val.trim();
      match key {
        "pass_status" => cfg.pass_status = val.to_string(),
        "vector_dim" | "top_k" | "billing_pack_min_gold_hits" => {
          let n: usize = val.parse::<usize>().map_err(|e| e.to_string())?;
          match key {
            "vector_dim" => cfg.vector_dim = n,
            "top_k" => cfg.top_k = n,
            _ => cfg.billing_pack_min_gold_hits = n as u32,
          }
        }
        "corpus_path" => cfg.corpus_path = val.to_string(),
        _ => {
          let f: f64 = val.parse::<f64>().map_err(|e| e.to_string())?;
          match key {
            "recall_floor" => cfg.recall_floor = f,
            "ndcg_floor" => cfg.ndcg_floor = f,
            "min_cross_cosine" => cfg.min_cross_cosine = f,
            "min_prep_match" => cfg.min_prep_match = f,
            "min_model_match" => cfg.min_model_match = f,
            "min_wire_byte_parity" => cfg.min_wire_byte_parity = f,
            "min_alias_preserve" => cfg.min_alias_preserve = f,
            "billing_pack_recall_floor" => cfg.billing_pack_recall_floor = f,
            "tight_security_recall_floor" => cfg.tight_security_recall_floor = f,
            "legacy_alias_recall_floor" => cfg.legacy_alias_recall_floor = f,
            _ => {}
          }
        }
      }
    }
    Ok(cfg)
  }
}
