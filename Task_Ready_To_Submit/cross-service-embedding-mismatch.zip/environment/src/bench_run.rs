use crate::table_u5;
use crate::codec_q;
use crate::corpus;
use crate::lane_a;
use crate::lane_b;
use crate::pack_m;
use crate::parity_cfg::{ParityCfg, QueryRow};
use crate::gate_v8;
use crate::scan_h::{self, IndexedDoc};
use crate::vault_w::SlotTable;
use crate::buf_n;
use serde::Serialize;
use sha2::{Digest, Sha256};
use std::path::Path;

#[derive(Debug, Clone, Serialize)]
pub struct QueryStat {
  pub query_id: String,
  pub recall_at_10: f64,
  pub ndcg_at_10: f64,
  pub gold_hits: u32,
  pub wire_dim_kept: u32,
  pub layout_ok: u32,
}

#[derive(Debug, Serialize)]
pub struct ParityReport {
  pub status: String,
  pub corpus_vectors: usize,
  pub vector_dim: usize,
  pub active_write_dim: usize,
  pub active_read_dim: usize,
  pub queries_total: usize,
  pub cross_cosine_parity_rate: f64,
  pub wire_byte_parity_rate: f64,
  pub alias_preserve_rate: f64,
  pub prep_rev_writer: u32,
  pub prep_rev_reader: u32,
  pub prep_rev_manifest: u32,
  pub alias_rev_writer: u32,
  pub alias_rev_reader: u32,
  pub alias_rev_manifest: u32,
  pub model_rev_writer: u32,
  pub model_rev_reader: u32,
  pub model_rev_manifest: u32,
  pub gateway_layout_ok: u32,
  pub mean_recall_at_10: f64,
  pub mean_ndcg_at_10: f64,
  pub report_digest: String,
  pub queries: Vec<QueryStat>,
}

fn round4(v: f64) -> f64 {
  (v * 10000.0).round() / 10000.0
}

fn cosine(a: &[f64], b: &[f64]) -> f64 {
  let n = a.len().min(b.len());
  if n == 0 {
    return 0.0;
  }
  let mut dot = 0.0;
  let mut na = 0.0;
  let mut nb = 0.0;
  for i in 0..n {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  if na == 0.0 || nb == 0.0 {
    return 0.0;
  }
  dot / (na.sqrt() * nb.sqrt())
}

fn cross_cosine_parity(
  texts: &[String],
  stored: &[Vec<f64>],
  read_slots: &SlotTable,
  dim: usize,
) -> f64 {
  if texts.is_empty() {
    return 0.0;
  }
  let mut ok = 0usize;
  for (text, vec) in texts.iter().zip(stored.iter()) {
    let reader_reencode = scan_h::encode_q(text, dim, read_slots);
    if cosine(vec, &reader_reencode) >= 0.99 {
      ok += 1;
    }
  }
  round4(ok as f64 / texts.len() as f64)
}

fn wire_byte_parity(wires: &[Vec<f64>], dim: usize) -> f64 {
  if wires.is_empty() {
    return 0.0;
  }
  let mut ok = 0usize;
  for wire in wires {
    let bytes = codec_q::encode(wire);
    let back = codec_q::decode(&bytes, dim);
    if cosine(wire, &back) >= 0.99 {
      ok += 1;
    }
  }
  round4(ok as f64 / wires.len() as f64)
}

fn alias_preserve(texts: &[String]) -> f64 {
  if texts.is_empty() {
    return 0.0;
  }
  let mut ok = 0usize;
  for text in texts {
    if lane_a::split_k(text) == lane_b::split_k(text) {
      ok += 1;
    }
  }
  round4(ok as f64 / texts.len() as f64)
}

fn alias_probe_texts(rows: &[corpus::DocRow]) -> Vec<String> {
  let mut out = Vec::new();
  for row in rows {
    if row.text.contains('-') || row.text.contains("wi-fi") || row.text.contains("e-mail") {
      out.push(row.text.clone());
    }
  }
  if out.is_empty() {
    out.push("billing wi-fi e-mail charge back policy".to_string());
  }
  out.truncate(32);
  out
}

fn prep_match_rate() -> f64 {
  if lane_a::table_rev() == lane_b::table_rev() {
    1.0
  } else {
    0.0
  }
}

fn model_match_rate(write_slots: &SlotTable, read_slots: &SlotTable) -> f64 {
  if write_slots.loaded_rev == read_slots.loaded_rev
    && write_slots.loaded_rev == write_slots.manifest_rev
  {
    1.0
  } else {
    round4(0.5)
  }
}

fn digest_payload(report: &ParityReport) -> String {
  let stub = ParityReport {
    status: report.status.clone(),
    corpus_vectors: report.corpus_vectors,
    vector_dim: report.vector_dim,
    active_write_dim: report.active_write_dim,
    active_read_dim: report.active_read_dim,
    queries_total: report.queries_total,
    cross_cosine_parity_rate: report.cross_cosine_parity_rate,
    wire_byte_parity_rate: report.wire_byte_parity_rate,
    alias_preserve_rate: report.alias_preserve_rate,
    prep_rev_writer: report.prep_rev_writer,
    prep_rev_reader: report.prep_rev_reader,
    prep_rev_manifest: report.prep_rev_manifest,
    alias_rev_writer: report.alias_rev_writer,
    alias_rev_reader: report.alias_rev_reader,
    alias_rev_manifest: report.alias_rev_manifest,
    model_rev_writer: report.model_rev_writer,
    model_rev_reader: report.model_rev_reader,
    model_rev_manifest: report.model_rev_manifest,
    gateway_layout_ok: report.gateway_layout_ok,
    mean_recall_at_10: report.mean_recall_at_10,
    mean_ndcg_at_10: report.mean_ndcg_at_10,
    report_digest: String::new(),
    queries: report.queries.clone(),
  };
  serde_json::to_string(&stub).unwrap_or_default()
}

pub fn load_queries(path: &Path) -> Result<Vec<QueryRow>, String> {
  let raw = std::fs::read_to_string(path).map_err(|e| e.to_string())?;
  let mut out = Vec::new();
  for line in raw.lines() {
    let line = line.trim();
    if line.is_empty() {
      continue;
    }
    out.push(serde_json::from_str(line).map_err(|e| e.to_string())?);
  }
  Ok(out)
}

pub fn run(cfg: &ParityCfg, cases: &[QueryRow]) -> Result<ParityReport, String> {
  let corpus_path = std::env::var("TB_CORPUS_PATH").unwrap_or_else(|_| cfg.corpus_path.clone());
  let rows = corpus::load(&corpus_path)?;
  let write_slots = SlotTable::load_write()?;
  let read_slots = SlotTable::load_read()?;
  let dim = cfg.vector_dim;

  let mut texts = Vec::new();
  let mut stored_vecs = Vec::new();
  let mut wire_vecs = Vec::new();
  let mut indexed = Vec::new();

  for row in &rows {
    let raw_vec = pack_m::emit_v(&row.text, dim, &write_slots);
    let wire = buf_n::pack(&raw_vec);
    let stored = gate_v8::ingress(&wire, dim);
    texts.push(row.text.clone());
    wire_vecs.push(wire);
    stored_vecs.push(stored.clone());
    indexed.push(IndexedDoc {
      id: row.id.clone(),
      realm: row.realm.clone(),
      vec: stored,
    });
  }

  let cross = cross_cosine_parity(&texts, &stored_vecs, &read_slots, dim);
  let wire_parity = wire_byte_parity(&wire_vecs, dim);
  let alias_rate = alias_preserve(&alias_probe_texts(&rows));

  let mut query_stats = Vec::new();
  let mut recall_sum = 0.0;
  let mut ndcg_sum = 0.0;
  for case in cases {
    let qvec = scan_h::encode_q(&case.query, dim, &read_slots);
    let realm = scan_h::realm_hint(&case.query);
    let ranked = scan_h::top_k(&qvec, &indexed, cfg.top_k, realm.as_deref());
    let recall = scan_h::recall_at_k(&case.gold, &ranked, cfg.top_k);
    let ndcg = scan_h::ndcg_at_k(&case.gold, &ranked, cfg.top_k);
    let hits = scan_h::gold_hits(&case.gold, &ranked, cfg.top_k);
    recall_sum += recall;
    ndcg_sum += ndcg;
    query_stats.push(QueryStat {
      query_id: case.query_id.clone(),
      recall_at_10: round4(recall),
      ndcg_at_10: round4(ndcg),
      gold_hits: hits,
      wire_dim_kept: pack_m::span_width(dim) as u32,
      layout_ok: gate_v8::layout_ok(),
    });
  }

  let nq = cases.len().max(1);
  let write_span = pack_m::span_width(dim);
  let read_span = pack_m::span_width(dim);

  let mut report = ParityReport {
    status: cfg.pass_status.clone(),
    corpus_vectors: rows.len(),
    vector_dim: dim,
    active_write_dim: write_span,
    active_read_dim: read_span,
    queries_total: cases.len(),
    cross_cosine_parity_rate: cross,
    wire_byte_parity_rate: wire_parity,
    alias_preserve_rate: alias_rate,
    prep_rev_writer: lane_a::table_rev(),
    prep_rev_reader: lane_b::table_rev(),
    prep_rev_manifest: write_slots.prep_rev_manifest(),
    alias_rev_writer: table_u5::rev_write(),
    alias_rev_reader: table_u5::rev_read(),
    alias_rev_manifest: table_u5::rev_manifest(),
    model_rev_writer: write_slots.loaded_rev,
    model_rev_reader: read_slots.loaded_rev,
    model_rev_manifest: write_slots.manifest_rev,
    gateway_layout_ok: gate_v8::layout_ok(),
    mean_recall_at_10: round4(recall_sum / nq as f64),
    mean_ndcg_at_10: round4(ndcg_sum / nq as f64),
    report_digest: String::new(),
    queries: query_stats,
  };

  if report.mean_recall_at_10 < cfg.recall_floor
    || report.mean_ndcg_at_10 < cfg.ndcg_floor
    || report.cross_cosine_parity_rate < cfg.min_cross_cosine
    || report.wire_byte_parity_rate < cfg.min_wire_byte_parity
    || report.alias_preserve_rate < cfg.min_alias_preserve
    || prep_match_rate() < cfg.min_prep_match
    || model_match_rate(&write_slots, &read_slots) < cfg.min_model_match
    || report.active_write_dim != dim
    || report.active_read_dim != dim
    || report.gateway_layout_ok != 1
    || report.prep_rev_writer != report.prep_rev_manifest
    || report.prep_rev_reader != report.prep_rev_manifest
    || report.alias_rev_writer != report.alias_rev_manifest
    || report.alias_rev_reader != report.alias_rev_manifest
  {
    report.status = "fail".to_string();
  }

  let payload = digest_payload(&report);
  let mut hasher = Sha256::new();
  hasher.update(payload.as_bytes());
  report.report_digest = format!("{:x}", hasher.finalize());
  Ok(report)
}
