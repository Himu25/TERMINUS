use cross_parity::bench_run;
use cross_parity::corpus;
use cross_parity::pack_m;
use cross_parity::parity_cfg::QueryRow;
use cross_parity::gate_v8;
use cross_parity::scan_h::{self, IndexedDoc};
use cross_parity::vault_w::SlotTable;
use cross_parity::buf_n;
use std::path::PathBuf;

#[derive(serde::Serialize)]
struct OutRow {
  query_id: String,
  query: String,
  gold: Vec<String>,
}

fn main() -> Result<(), String> {
  let args: Vec<String> = std::env::args().skip(1).collect();
  if args.len() < 3 {
    eprintln!("usage: goldgen <corpus.json> <specs.jsonl> <out.jsonl>");
    std::process::exit(2);
  }
  let dim = 64;
  let top_k = 10;
  let docs = corpus::load(PathBuf::from(&args[0]).to_str().unwrap())?;
  let specs: Vec<QueryRow> = bench_run::load_queries(PathBuf::from(&args[1]).as_path())?;
  let write_slots = SlotTable::load_write()?;
  let read_slots = SlotTable::load_read()?;

  let mut indexed = Vec::new();
  for doc in &docs {
    let raw_vec = pack_m::emit_v(&doc.text, dim, &write_slots);
    let wire = buf_n::pack(&raw_vec);
    let stored = gate_v8::ingress(&wire, dim);
    indexed.push(IndexedDoc {
      id: doc.id.clone(),
      realm: doc.realm.clone(),
      vec: stored,
    });
  }

  let mut out_lines = Vec::new();
  for spec in specs {
    let realm = scan_h::realm_hint(&spec.query);
    let qv = scan_h::encode_q(&spec.query, dim, &read_slots);
    let ranked = scan_h::top_k(&qv, &indexed, top_k, realm.as_deref());
    let gold: Vec<String> = ranked.into_iter().take(3).collect();
    let row = OutRow {
      query_id: spec.query_id,
      query: spec.query,
      gold,
    };
    out_lines.push(serde_json::to_string(&row).map_err(|e| e.to_string())?);
  }
  std::fs::write(&args[2], out_lines.join("\n") + "\n").map_err(|e| e.to_string())?;
  Ok(())
}
