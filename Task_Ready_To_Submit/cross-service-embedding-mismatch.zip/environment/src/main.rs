use cross_parity::bench_run;
use cross_parity::parity_cfg::ParityCfg;
use std::env;
use std::path::PathBuf;

fn main() {
  let args: Vec<String> = env::args().collect();
  if args.len() != 3 {
    eprintln!("usage: parity_bench <queries.jsonl> <output.json>");
    std::process::exit(2);
  }
  let cfg = ParityCfg::load("/app/config/parity.toml").expect("load parity config");
  let cases = bench_run::load_queries(&PathBuf::from(&args[1])).expect("load queries");
  let report = bench_run::run(&cfg, &cases).expect("run bench");
  let out = serde_json::to_string_pretty(&report).expect("serialize report");
  std::fs::write(&args[2], out).expect("write report");
}
