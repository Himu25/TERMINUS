use serde::Deserialize;
use std::fs;

#[derive(Debug, Clone, Deserialize)]
pub struct DocRow {
  pub id: String,
  pub label: String,
  pub text: String,
  pub realm: String,
}

#[derive(Debug, Deserialize)]
struct CorpusFile {
  vectors: Vec<DocRow>,
}

pub fn load(path: &str) -> Result<Vec<DocRow>, String> {
  let raw = fs::read_to_string(path).map_err(|e| e.to_string())?;
  let parsed: CorpusFile = serde_json::from_str(&raw).map_err(|e| e.to_string())?;
  Ok(parsed.vectors)
}
