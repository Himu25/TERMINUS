# Replica layout

Five replicas (`n1`–`n5`) append record rows under `/app/data/active/replicas/`.
Each replica carries `clock_skew_ms`, optional `radio_hold_ms`, and a `freeze_mark` watermark in `meta.json`.
Replay folds those per-replica marks into one watermark by taking the minimum `freeze_mark` across the pack.
Hold-window semantics for offset maps are in `/app/docs/lane_hold_notes.md`.

Segment files use JSONL with `seq`, `epoch`, `emitted_ms`, `payload`, and `crc` fields.
