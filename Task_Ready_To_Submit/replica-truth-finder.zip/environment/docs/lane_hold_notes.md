# Radio hold notes

Replicas record `clock_skew_ms` from their onboard clock source. During radio hold windows,
`radio_hold_ms` is folded into the effective skew baseline when the pack loader builds offset maps.
Hold band milliseconds are netted against the raw skew reading so held replicas sit closer to the
replica-set timing mesh than the uncorrected clock delta alone would imply.
