# Replica truth finder

The `truth_find` driver replays replica segment JSONL under `/app/data/active/replicas/` against `/app/data/active/replica_pack.json` and writes `/app/output/truth_report.json`.

Active packs declare quorum size, partition epoch, link-tight skew band, and replica membership. Each replica contributes `meta.json` (clock skew, optional radio hold band, freeze mark) plus one or more JSONL segment files keyed by sequence number. Freeze watermark folding uses the minimum `freeze_mark` across all replicas in the pack.

Skew baselines are folded through `/app/pkg/offsetfold` and the Rust hold helper under `/app/holdgate/` before merge tie-breaks (see `/app/docs/lane_hold_notes.md`). Build the driver with `/app/scripts/build.sh`; digest tooling lives at `/app/tools/truth_digest`.

Replay counters in `truth_report.json` follow strict scopes. The sweep visits only sequence numbers that appear in segment rows above the folded freeze watermark; integers with no rows in that span are not evaluated and do not add to `gap_count`. At each visited position, `gap_count` increments only where no (epoch, payload) group gathers quorum with enough integrity-valid replicas to advance the chain. `repair_count` increments only for integrity tag mismatches among rows in the winning group at each accepted position; rows from losing groups and positions recorded as gaps do not contribute.
