# Pack archive notes

Historical replica packs are retained for offline regression. Each pack includes `replica_pack.json` plus per-replica `meta.json` and segment JSONL trees.

Operators stage one pack under `/app/data/active/` before invoking `truth_find`. Pack headers declare quorum size, partition epoch, link-tight skew band, and replica membership; segment rows carry sequence, epoch, emitted time, payload, and integrity tags.

Rebuild the driver with `/app/scripts/build.sh` when changing replay logic. Digest recomputation for report fields uses `/app/tools/truth_digest`.
