package version

// ToolingTag is stamped into build metadata.
const ToolingTag = "replica-truth-0.9"
