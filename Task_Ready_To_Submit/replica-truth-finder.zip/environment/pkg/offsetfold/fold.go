package offsetfold

import "lab.local/replica_truth_finder/holdgate"

// FoldUnitSkew applies optional radio hold smear to the recorded clock skew baseline.
func FoldUnitSkew(skewMS int64, radioHoldMS int64) int64 {
	return holdgate.ApplyHold(skewMS, radioHoldMS)
}
