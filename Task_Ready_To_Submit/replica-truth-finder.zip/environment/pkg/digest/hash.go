package digest

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
)

// ReportHex matches the pipe-separated digest in cmd/truth_find.
func ReportHex(
	setID string,
	masterEpoch, batchSeq, repairCount, gapCount, replicasActive uint32,
	skewBand string,
	partitionClean bool,
) string {
	ck := "true"
	if !partitionClean {
		ck = "false"
	}
	raw := fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%s|%s",
		setID, masterEpoch, batchSeq, repairCount, gapCount, replicasActive, skewBand, ck,
	)
	sum := sha256.Sum256([]byte(raw))
	return hex.EncodeToString(sum[:])
}
