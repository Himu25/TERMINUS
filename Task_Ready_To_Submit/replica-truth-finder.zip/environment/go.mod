module lab.local/replica_truth_finder

go 1.22
