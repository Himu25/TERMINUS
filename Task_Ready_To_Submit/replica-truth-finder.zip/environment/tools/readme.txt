Operator tools live outside the heal driver; use /app/bin/truth_find for pack replay.
Digest recomputation for report fields uses /app/tools/truth_digest.
