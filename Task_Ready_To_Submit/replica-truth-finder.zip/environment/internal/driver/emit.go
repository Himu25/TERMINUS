package driver

import (
	"encoding/json"
	"os"
)

// Report is the outward JSON envelope.
type Report struct {
	SchemaVersion string `json:"schema_version"`
	SetID        string `json:"set_id"`
	MasterEpoch     uint32 `json:"master_epoch"`
	BatchSeq     uint32 `json:"batch_seq"`
	RepairCount   uint32 `json:"repair_count"`
	GapCount     uint32 `json:"gap_count"`
	ReplicasActive   uint32 `json:"replicas_active"`
	SkewBand     string `json:"skew_band"`
	PartitionClean    bool   `json:"partition_clean"`
	DigestHex     string `json:"digest_hex"`
}

// EmitReport writes the heal output document.
func EmitReport(path string, rep Report) error {
	raw, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}
