package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"

	"lab.local/replica_truth_finder/internal/config"
	"lab.local/replica_truth_finder/internal/engine"
)

// RunActive loads the active pack and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	pack, profiles, rows, offsets, err := config.LoadPack(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(pack.SetID, pack.QSize, pack.SepEpoch, pack.LinkTightMS, profiles, rows, offsets)
	ck := "true"
	if !out.PartitionClean {
		ck = "false"
	}
	digest := sha256.Sum256([]byte(fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%s|%s",
		pack.SetID,
		out.MasterEpoch,
		out.BatchSeq,
		out.RepairCount,
		out.GapCount,
		out.ReplicasActive,
		out.SkewBand,
		ck,
	)))
	return Report{
		SchemaVersion: "1",
		SetID:        pack.SetID,
		MasterEpoch:     out.MasterEpoch,
		BatchSeq:     out.BatchSeq,
		RepairCount:   out.RepairCount,
		GapCount:     out.GapCount,
		ReplicasActive:   out.ReplicasActive,
		SkewBand:     out.SkewBand,
		PartitionClean:    out.PartitionClean,
		DigestHex:     hex.EncodeToString(digest[:]),
	}, nil
}
