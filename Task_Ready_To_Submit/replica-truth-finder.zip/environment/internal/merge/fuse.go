package merge

import (
	"lab.local/replica_truth_finder/internal/crc"
	"lab.local/replica_truth_finder/pkg/replicount"
	"lab.local/replica_truth_finder/internal/skew"
	"lab.local/replica_truth_finder/pkg/frame"
)

// Outcome is the folded heal counters for one pack replay.
type Outcome struct {
	MasterEpoch    uint32
	BatchSeq    uint32
	RepairCount  uint32
	GapCount    uint32
	ReplicasActive  uint32
	SkewBand    string
	PartitionClean   bool
}

// FusePack rebuilds consistent sequence state above a watermark.
func FusePack(
	watermark uint32,
	qSize int,
	sepEpoch uint32,
	linkTight int64,
	offsets map[string]int64,
	bySeq map[uint32][]frame.Row,
	allRows map[uint32][]frame.Row,
) Outcome {
	var spreadMin, spreadMax int64
	for _, off := range offsets {
		if spreadMin == 0 && spreadMax == 0 {
			spreadMin, spreadMax = off, off
			continue
		}
		if off < spreadMin {
			spreadMin = off
		}
		if off > spreadMax {
			spreadMax = off
		}
	}
	drift := "tight"
	if spreadMax-spreadMin > linkTight {
		drift = "wide"
	}

	accepted := map[uint32]uint32{}
	repair := uint32(0)
	loss := uint32(0)
	live := map[string]struct{}{}
	sepClean := true

	seqs := make([]uint32, 0, len(bySeq))
	for s := range bySeq {
		seqs = append(seqs, s)
	}
	for _, s := range op_rUint(seqs) {
		rows := bySeq[s]
		buckets := map[[2]string][]frame.Row{}
		for _, row := range rows {
			key := [2]string{itoaU(row.Epoch), row.Payload}
			buckets[key] = append(buckets[key], row)
		}
		var pickedKey [2]string
		var pickedRows []frame.Row
		var bestAdj int64
		found := false
		for key, items := range buckets {
			memSet := map[string]struct{}{}
			for _, it := range items {
				memSet[it.Site] = struct{}{}
			}
			if !replicount.OpQ(len(memSet), qSize) {
				continue
			}
			valid := make([]frame.Row, 0, len(items))
			for _, it := range items {
				if crc.OpValid(it.Seq, it.Payload, it.CRC) {
					valid = append(valid, it)
				}
			}
			if len(valid) < qSize {
				continue
			}
			adj := skew.AdjustEmit(valid[0], offsets[valid[0].Site])
			for _, it := range valid[1:] {
				a := skew.AdjustEmit(it, offsets[it.Site])
				if a < adj {
					adj = a
				}
			}
			if !found || adj < bestAdj {
				found = true
				bestAdj = adj
				pickedKey = key
				pickedRows = valid
			}
		}
		if !found {
			loss++
			continue
		}
		// Integrity repairs for this sequence: only replicas in the winning bucket.
		for _, it := range buckets[pickedKey] {
			if !crc.OpValid(it.Seq, it.Payload, it.CRC) {
				repair++
			}
		}
		epoch := parseU(pickedKey[0])
		if epoch > sepEpoch {
			mem := map[string]struct{}{}
			for _, it := range pickedRows {
				mem[it.Site] = struct{}{}
			}
			if len(mem) < qSize {
				sepClean = false
			}
		}
		for _, it := range pickedRows {
			live[it.Site] = struct{}{}
		}
		accepted[s] = epoch
	}

	global := uint32(0)
	for s := uint32(1); ; s++ {
		if s <= watermark {
			global = s
			continue
		}
		if _, ok := accepted[s]; ok {
			global = s
			continue
		}
		break
	}

	meshEp := uint32(0)
	for s, ep := range accepted {
		if s <= global && ep > meshEp {
			meshEp = ep
		}
	}
	for _, rows := range allRows {
		for _, row := range rows {
			if row.Seq > global {
				continue
			}
			if ep, ok := accepted[row.Seq]; ok {
				if row.Epoch == ep && crc.OpValid(row.Seq, row.Payload, row.CRC) && row.Epoch > meshEp {
					meshEp = row.Epoch
				}
			} else if row.Seq <= watermark && row.Epoch > meshEp {
				meshEp = row.Epoch
			}
		}
	}

	return Outcome{
		MasterEpoch:   meshEp,
		BatchSeq:   global,
		RepairCount: repair,
		GapCount:   loss,
		ReplicasActive: uint32(len(live)),
		SkewBand:   drift,
		PartitionClean:  sepClean,
	}
}

func op_rUint(seqs []uint32) []uint32 {
	out := append([]uint32(nil), seqs...)
	for i := 0; i < len(out); i++ {
		for j := i + 1; j < len(out); j++ {
			if out[j] < out[i] {
				out[i], out[j] = out[j], out[i]
			}
		}
	}
	return out
}

func itoaU(v uint32) string {
	if v == 0 {
		return "0"
	}
	var buf [12]byte
	i := len(buf)
	n := v
	for n > 0 {
		i--
		buf[i] = byte('0' + n%10)
		n /= 10
	}
	return string(buf[i:])
}

func parseU(s string) uint32 {
	var n uint32
	for _, c := range s {
		if c < '0' || c > '9' {
			continue
		}
		n = n*10 + uint32(c-'0')
	}
	return n
}
