package freeze

import (
	"lab.local/replica_truth_finder/pkg/markfold"
	"lab.local/replica_truth_finder/pkg/unit"
)

// Watermark collects partition marks from profiles.
func Watermark(profiles []unit.Profile) int64 {
	marks := make([]int64, 0, len(profiles))
	for _, p := range profiles {
		marks = append(marks, int64(p.StaleMark))
	}
	return markfold.OpW(marks)
}
