package engine

import (
	"lab.local/replica_truth_finder/internal/freeze"
	"lab.local/replica_truth_finder/internal/merge"
	"lab.local/replica_truth_finder/pkg/frame"
	"lab.local/replica_truth_finder/pkg/unit"
)

// Replay executes one pack through freeze and merge stages.
func Replay(
	packID string,
	qSize int,
	sepEpoch uint32,
	linkTight int64,
	profiles []unit.Profile,
	allRows map[uint32][]frame.Row,
	offsets map[string]int64,
) merge.Outcome {
	wm := freeze.Watermark(profiles)
	above := make(map[uint32][]frame.Row)
	for seq, rows := range allRows {
		if seq > uint32(wm) {
			above[seq] = rows
		}
	}
	out := merge.FusePack(uint32(wm), qSize, sepEpoch, linkTight, offsets, above, allRows)
	_ = packID
	return out
}
