package crc

import "lab.local/replica_truth_finder/pkg/frame"

// OpValid delegates integrity checking to op_v.
func OpValid(seq uint32, payload string, stored uint16) bool {
	return op_v(seq, payload, stored)
}

// OpValidWire checks integrity tags using the wire CRC function.
func OpValidWire(seq uint32, payload string, stored uint16) bool {
	return frame.WireCRC(seq, payload) == stored
}
