// Report JSON for /app/output/truth_report.json:
//
// schema_version — string, must be "1"
// set_id — string, echoes active pack name
// master_epoch — highest epoch in the consistent chain
// batch_seq — highest contiguous sequence included in the chain
// repair_count — integrity tag mismatches in the winning (epoch, payload) group per accepted sequence
// gap_count — row-backed sequence positions above the freeze watermark with no quorum-backed winning group (absent integers in the span are not gaps)
// replicas_active — count of units contributing to accepted rows
// skew_band — string, "tight" or "wide"
// partition_clean — boolean (not 0/1 strings)
// digest_hex — lowercase hex SHA-256 of set_id|master_epoch|batch_seq|repair_count|gap_count|replicas_active|skew_band|partition_clean
//
// Root object contains only these keys.
package main

import (
	"log"
	"os"

	"lab.local/replica_truth_finder/internal/driver"
)

func main() {
	if os.Getenv("TB_TRUTH_FIXTURE") != "1" {
		log.Fatal("TB_TRUTH_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/truth_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
