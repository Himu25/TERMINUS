#pragma once

long long hg_apply_hold(long long base_ms, long long hold_ms);
