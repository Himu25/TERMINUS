package holdgate

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libholdgate.a -ldl -lm
#include "hold_fold.h"
*/
import "C"

// ApplyHold combines unit clock skew with an optional radio hold band.
func ApplyHold(baseMS int64, holdMS int64) int64 {
	return int64(C.hg_apply_hold(C.longlong(baseMS), C.longlong(holdMS)))
}
