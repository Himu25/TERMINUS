"""Verifier for replica truth finder reconciliation report."""

import json
import os
import shutil
import subprocess

import pytest
from collections import defaultdict
from pathlib import Path

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = Path("/tests") / "fixtures"
OUT = APP / "output" / "truth_report.json"
GO_BIN = "/usr/local/go/bin/go"
VERIFY_BIN = "/tmp/truth_find_verify_bin"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)
    subprocess.run(["cp", "/app/bin/truth_find", VERIFY_BIN], check=True)


def _digest_hex(
    set_id: str,
    master_epoch: int,
    batch_seq: int,
    repair: int,
    loss: int,
    replicas_active: int,
    drift: str,
    partition_clean: bool,
) -> str:
    ck = "true" if partition_clean else "false"
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/truth_digest",
            set_id,
            str(master_epoch),
            str(batch_seq),
            str(repair),
            str(loss),
            str(replicas_active),
            drift,
            ck,
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _crc16(seq: int, payload: str) -> int:
    s = sum(payload.encode()) & 0xFFFFFFFF
    return (s ^ seq) & 0xFFFF


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = FIXTURES / pack_name
    pack = json.loads((pack_dir / "replica_pack.json").read_text())
    q = pack["q_size"]
    sep_epoch = pack["sep_epoch"]
    drift_tight = pack["link_tight_ms"]
    offsets: dict[str, int] = {}
    freezes: list[int] = []
    rows: list[dict] = []
    for mid in pack["replicas"]:
        meta = json.loads((pack_dir / "replicas" / mid / "meta.json").read_text())
        hold = int(meta.get("radio_hold_ms", 0))
        offsets[mid] = int(meta["clock_skew_ms"]) - hold
        freezes.append(meta["freeze_mark"])
        seg = pack_dir / "replicas" / mid / "seg_001.jsonl"
        if not seg.exists():
            continue
        for line in seg.read_text().splitlines():
            if not line.strip():
                continue
            entry = json.loads(line)
            entry["site"] = mid
            rows.append(entry)
    wm = min(freezes) if freezes else 0
    by_seq: dict[int, list] = defaultdict(list)
    all_rows: dict[int, list] = defaultdict(list)
    for entry in rows:
        all_rows[entry["seq"]].append(entry)
        if entry["seq"] > wm:
            by_seq[entry["seq"]].append(entry)
    accepted: dict[int, int] = {}
    repair = 0
    loss = 0
    live: set[str] = set()
    partition_clean = True
    for seq in sorted(by_seq):
        buckets: dict[tuple, list] = defaultdict(list)
        for entry in by_seq[seq]:
            buckets[(entry["epoch"], entry["payload"])].append(entry)
        picked = None
        best_adj = None
        for key, items in buckets.items():
            if len({it["site"] for it in items}) < q:
                continue
            valid = [it for it in items if _crc16(it["seq"], it["payload"]) == it["crc"]]
            if len(valid) < q:
                continue
            adj = min(it["emitted_ms"] - offsets[it["site"]] for it in valid)
            if picked is None or adj < best_adj:
                picked, best_adj = key, adj
        if picked is None:
            loss += 1
            continue
        items = buckets[picked]
        repair += sum(1 for it in items if _crc16(it["seq"], it["payload"]) != it["crc"])
        epoch = picked[0]
        valid = [it for it in items if _crc16(it["seq"], it["payload"]) == it["crc"]]
        if epoch > sep_epoch and len({it["site"] for it in valid}) < q:
            partition_clean = False
        for it in valid:
            live.add(it["site"])
        accepted[seq] = epoch
    batch_seq = 0
    s = 1
    while True:
        if s <= wm or s in accepted:
            batch_seq = s
            s += 1
        else:
            break
    master_epoch = 0
    for seq, seq_rows in all_rows.items():
        if seq > batch_seq:
            continue
        for entry in seq_rows:
            if seq in accepted and entry["epoch"] == accepted[seq]:
                if _crc16(entry["seq"], entry["payload"]) == entry["crc"] and entry["epoch"] > master_epoch:
                    master_epoch = entry["epoch"]
            elif seq <= wm and entry["epoch"] > master_epoch:
                master_epoch = entry["epoch"]
    spread = max(offsets.values()) - min(offsets.values())
    drift = "tight" if spread <= drift_tight else "wide"
    digest = _digest_hex(
        pack["set_id"], master_epoch, batch_seq, repair, loss, len(live), drift, partition_clean
    )
    return {
        "schema_version": "1",
        "set_id": pack["set_id"],
        "master_epoch": master_epoch,
        "batch_seq": batch_seq,
        "repair_count": repair,
        "gap_count": loss,
        "replicas_active": len(live),
        "skew_band": drift,
        "partition_clean": partition_clean,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_TRUTH_FIXTURE": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_alpha_report_matches_quorum_replay() -> None:
    """set_alpha pack should reach tight link band with full five-replica chain."""
    _swap("set_alpha")
    exp = _expected_from_fixture("set_alpha")
    got = _run_tool()
    assert got == exp


def test_beta_report_matches_quorum_replay() -> None:
    """set_beta pack applies radio hold fold when adjusting replica skew for replay."""
    _swap("set_beta")
    exp = _expected_from_fixture("set_beta")
    got = _run_tool()
    assert got == exp


def test_gamma_loss_after_lone_epoch() -> None:
    """set_gamma stops the chain when only one replica carries a high epoch row."""
    _swap("set_gamma")
    exp = _expected_from_fixture("set_gamma")
    got = _run_tool()
    assert got["gap_count"] == exp["gap_count"]
    assert got["batch_seq"] == exp["batch_seq"]


def test_delta_high_gap_count() -> None:
    """set_delta orphan high sweep should not extend the global chain."""
    _swap("set_delta")
    exp = _expected_from_fixture("set_delta")
    got = _run_tool()
    assert got["gap_count"] == exp["gap_count"]
    assert got["batch_seq"] == exp["batch_seq"]


def test_epsilon_repair_count_nonzero() -> None:
    """set_epsilon should count one checksum reconcile on the winning claim group."""
    _swap("set_epsilon")
    exp = _expected_from_fixture("set_epsilon")
    got = _run_tool()
    assert got["repair_count"] == exp["repair_count"]
    assert got["batch_seq"] == exp["batch_seq"]


def test_alpha_batch_seq_watermark() -> None:
    """set_alpha freeze watermark must use the minimum mark, not the maximum."""
    _swap("set_alpha")
    exp = _expected_from_fixture("set_alpha")
    got = _run_tool()
    assert got["batch_seq"] == exp["batch_seq"]


def test_go_subsystem_tests_pass() -> None:
    """Go unit tests under /app must pass after the repair."""
    subprocess.run(
        [GO_BIN, "test", "./..."],
        cwd="/app",
        env={**os.environ, "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1", "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", "")},
        check=True,
    )
