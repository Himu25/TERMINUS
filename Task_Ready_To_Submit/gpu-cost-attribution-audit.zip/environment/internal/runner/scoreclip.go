package runner

import (
	"costbench/hitwire"
	"costbench/ridge_d7"
)

func runSeal(rows []hitwire.HitRow, posted string, anchor *int) ridge_d7.Rollup {
	return ridge_d7.FoldSpan(rows, posted, anchor)
}
