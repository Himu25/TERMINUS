package runner

import (
	"costbench/flux_p2"
	"costbench/hitwire"
)

func runClip(rows []hitwire.HitRow) ([]hitwire.HitRow, int) {
	return flux_p2.ClipSpan(rows)
}
