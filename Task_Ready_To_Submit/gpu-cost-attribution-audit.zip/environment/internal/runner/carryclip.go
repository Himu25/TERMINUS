package runner

import (
	"costbench/keel_m8"
	"costbench/hitwire"
)

func runShift(rows []hitwire.HitRow, pair string) []hitwire.HitRow {
	return keel_m8.ShiftSpan(rows, pair)
}
