package runner

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"

	"costbench/hitwire"
)

// PipelineRun is the JSON shape for one scenario emission.
type PipelineRun struct {
	ScenarioTag string `json:"scenario_tag"`
	WorkloadUnits int    `json:"workload_units"`
	PoolUnits int    `json:"pool_units"`
	AttributionGap    int    `json:"attribution_gap"`
	DupLogs int    `json:"dup_logs"`
	OrphanIntervals int    `json:"orphan_intervals"`
}

type pipelinePayload struct {
	PipelineRuns []PipelineRun `json:"pipeline_runs"`
}

// Run loads one bundle using tb_pack, writes /app/output/cost_attribution.json.
func Run() error {
	stem := os.Getenv("tb_pack")
	if stem == "" {
		return errors.New("tb_pack must name a stem under /app/cases")
	}
	emit := "/app/output/cost_attribution.json"
	raw, err := os.ReadFile(filepath.Join("/app", "cases", stem+".json"))
	if err != nil {
		return err
	}
	var bundle hitwire.Bundle
	if err := json.Unmarshal(raw, &bundle); err != nil {
		return err
	}
	trimmed, noise := runClip(bundle.Tape)
	carried := runShift(trimmed, bundle.PairStaleWire)
	view := runSeal(carried, bundle.LiveLaneToken, bundle.RankAnchorHint)
	run := PipelineRun{
		ScenarioTag: bundle.ScenarioLabel,
		WorkloadUnits: view.WorkloadUnits,
		PoolUnits: view.PoolUnits,
		AttributionGap:    view.AttributionGap,
		DupLogs: noise,
		OrphanIntervals: view.OrphanIntervals,
	}
	out := pipelinePayload{PipelineRuns: []PipelineRun{run}}
	if err := os.MkdirAll(filepath.Dir(emit), 0o755); err != nil {
		return err
	}
	buf, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		return err
	}
	tmp := emit + ".tmp"
	if err := os.WriteFile(tmp, buf, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, emit)
}

// MainExit is a thin wrapper for cmd.
func MainExit() int {
	if err := Run(); err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		return 1
	}
	return 0
}
