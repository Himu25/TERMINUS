module costbench

go 1.22
