package flux_p2

import (
	"costbench/hitwire"
)

func tagFrom(r hitwire.HitRow) string {
	return r.Ink
}

// ClipSpan removes replayed duplicates while preserving first-seen order.
func ClipSpan(rows []hitwire.HitRow) ([]hitwire.HitRow, int) {
	seen := map[string]bool{}
	out := make([]hitwire.HitRow, 0, len(rows))
	noise := 0
	for idx := range rows {
		r := rows[idx]
		key := tagFrom(r)
		if seen[key] {
			noise++
			continue
		}
		seen[key] = true
		out = append(out, r)
	}
	return out, noise
}
