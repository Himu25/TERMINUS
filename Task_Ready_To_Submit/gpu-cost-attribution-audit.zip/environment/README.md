# GPU cost attribution audit

Offline telemetry reconciler for attributing shared-pool GPU spend to ML workloads. Mixed Rust/Go pipeline under `/app` narrows duplicate pod fingerprints, applies workload-local completion markers, and rolls up billable vs pool overhead units.

Build with `/app/scripts/build.sh`. Run scenarios via `tb_pack=<stem> /app/bin/costattr`.
