package hitwire

// HitRow is one sampled GPU telemetry interval from scheduler or pool logs.
type HitRow struct {
	Wire     string `json:"wire_tag"`
	Ink      string `json:"ink"`
	Grain    int    `json:"grain"`
	Face     string `json:"face"`
	Band     string `json:"band"`
	Sentinel bool   `json:"sentinel"`
}

// Bundle is one deterministic scenario under /app/cases.
type Bundle struct {
	ScenarioLabel    string    `json:"scenario_label"`
	LiveLaneToken  string    `json:"live_pack_token"`
	RankAnchorHint *int      `json:"rank_anchor_hint"`
	PairStaleWire string    `json:"pair_stale_wire"`
	Tape             []HitRow `json:"hits"`
}
