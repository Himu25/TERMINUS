Local smoke: `go build -o /tmp/costattr ./cmd/costattr && tb_pack=pack_alpha /tmp/costattr`
