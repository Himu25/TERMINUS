# Architecture sketch

- `cmd/costattr` CLI entry (reads `tb_pack` for the cases stem)
- `flux_p2` telemetry dedupe / narrowing
- `keel_m8` completion-marker walk
- `ridge_d7` billable vs pool rollup via cgo
- `internal/runner` wires stages without centralizing every fix symbol
