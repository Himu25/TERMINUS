package ridge_d7

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libridge_fold.a -ldl -lm
#include "ridge_fold.h"
#include <stdlib.h>
*/
import "C"

import (
	"unsafe"

	"costbench/hitwire"
)

// Rollup is one attributed row for JSON emission.
type Rollup struct {
	WorkloadUnits int
	PoolUnits int
	AttributionGap    int
	OrphanIntervals int
}

// FoldSpan folds mirror and posted booking views after carry.
func FoldSpan(rows []hitwire.HitRow, posted string, anchor *int) Rollup {
	if len(rows) == 0 {
		return rollupFrom(C.vf_meter_span(nil, 0, cStr(posted), cAnchor(anchor)))
	}
	cRows := make([]C.vf_row, len(rows))
	keepers := make([]*C.char, 0, len(rows)*4+1)
	defer freeAll(keepers)

	for idx := range rows {
		r := rows[idx]
		w := C.CString(r.Wire)
		i := C.CString(r.Ink)
		f := C.CString(r.Face)
		b := C.CString(r.Band)
		keepers = append(keepers, w, i, f, b)
		cRows[idx] = C.vf_row{
			wire:     w,
			ink:      i,
			grain:    C.int(r.Grain),
			face:     f,
			band:     b,
			sentinel: C.bool(r.Sentinel),
		}
	}
	p := cStr(posted)
	keepers = append(keepers, p)
	ct := C.vf_meter_span(
		(*C.vf_row)(unsafe.Pointer(&cRows[0])),
		C.size_t(len(cRows)),
		p,
		cAnchor(anchor),
	)
	return rollupFrom(ct)
}

func cStr(s string) *C.char {
	return C.CString(s)
}

func cAnchor(anchor *int) *C.int {
	if anchor == nil {
		return nil
	}
	v := C.int(*anchor)
	return &v
}

func freeAll(ptrs []*C.char) {
	for _, p := range ptrs {
		C.free(unsafe.Pointer(p))
	}
}

func rollupFrom(ct C.vf_tally) Rollup {
	return Rollup{
		WorkloadUnits:   int(ct.primary_score),
		PoolUnits:       int(ct.diversity_score),
		AttributionGap:  int(ct.score_delta),
		OrphanIntervals: int(ct.stale_skips),
	}
}
