#!/bin/bash
set -euo pipefail

# Mixed Rust/Go link step: CGO_ENABLED=1 binds the Go binary to libridge_fold.a.
export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1

mkdir -p /app/bin
cd /app/ridge_d7
cargo build --release --locked
cd /app
GOFLAGS=-mod=mod go build -o /app/bin/costattr ./cmd/costattr
