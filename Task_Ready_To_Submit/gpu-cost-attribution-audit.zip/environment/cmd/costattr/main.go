package main

import (
	"os"

	"costbench/internal/runner"
)

func main() {
	os.Exit(runner.MainExit())
}
