"""Verifier for GPU workload cost attribution audits."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

APP = Path("/app")
REPORT = APP / "output" / "cost_attribution.json"


def _stem_tag(stem: str) -> str:
    bundle = json.loads((APP / "cases" / f"{stem}.json").read_text(encoding="utf-8"))
    return str(bundle["scenario_label"])


def _drive(stem: str) -> dict:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    if REPORT.exists():
        REPORT.unlink()
    subprocess.run(
        ["/app/bin/costattr"],
        cwd=str(APP),
        env={**os.environ, "tb_pack": stem},
        check=True,
    )
    payload = json.loads(REPORT.read_text(encoding="utf-8"))
    assert "pipeline_runs" in payload and len(payload["pipeline_runs"]) == 1
    row = payload["pipeline_runs"][0]
    assert row.get("scenario_tag") == _stem_tag(stem)
    return row


def _assert_row(
    row: dict,
    *,
    workload_units: int,
    pool_units: int,
    attribution_gap: int,
    dup_logs: int,
    orphan_intervals: int,
) -> None:
    assert row["workload_units"] == workload_units
    assert row["pool_units"] == pool_units
    assert row["attribution_gap"] == attribution_gap
    assert row["dup_logs"] == dup_logs
    assert row["orphan_intervals"] == orphan_intervals


def test_pack_alpha_shared_pod_fingerprint_across_workloads() -> None:
    """Same pod fingerprint on different wire_tag workloads must not collapse distinct HIT rows."""
    row = _drive("pack_alpha")
    _assert_row(row, workload_units=161, pool_units=161, attribution_gap=0, dup_logs=1, orphan_intervals=0)


def test_pack_beta_completion_marker_scope() -> None:
    """A completion sentinel on one workload must not freeze unrelated workloads still expecting ALT lines."""
    row = _drive("pack_beta")
    _assert_row(row, workload_units=70, pool_units=70, attribution_gap=0, dup_logs=0, orphan_intervals=0)


def test_pack_gamma_shadow_pool_excluded() -> None:
    """Billable totals must ignore HIT rows on held or shadow pool lanes outside live_pack_token."""
    row = _drive("pack_gamma")
    _assert_row(row, workload_units=10, pool_units=10, attribution_gap=0, dup_logs=0, orphan_intervals=0)


def test_pack_delta_replay_and_completion_halt() -> None:
    """Duplicate telemetry replay plus per-workload ALT freeze after a completion sentinel."""
    row = _drive("pack_delta")
    _assert_row(row, workload_units=35, pool_units=35, attribution_gap=0, dup_logs=1, orphan_intervals=0)


def test_pack_peak_composite() -> None:
    """Composite pack mixes duplicate suppression, completion scope, and late ALT overhead lines."""
    row = _drive("pack_peak")
    _assert_row(row, workload_units=16, pool_units=16, attribution_gap=0, dup_logs=1, orphan_intervals=0)


def test_pack_ozone_finance_override_hint() -> None:
    """rank_anchor_hint replaces summed ALT totals for pool_units when finance overrides land."""
    row = _drive("pack_ozone")
    _assert_row(row, workload_units=100, pool_units=90, attribution_gap=10, dup_logs=0, orphan_intervals=0)


def test_pack_canyon_cross_workload_pod_collision() -> None:
    """Shared pod ink on distinct wire_tag workloads must survive narrowing with trailing replays."""
    row = _drive("pack_canyon")
    _assert_row(row, workload_units=100, pool_units=75, attribution_gap=25, dup_logs=2, orphan_intervals=0)


def test_pack_echo_completion_orphan_hits() -> None:
    """Per-workload completion halt drops late ALT mirrors while live-lane HIT rows stay booked."""
    row = _drive("pack_echo")
    _assert_row(row, workload_units=55, pool_units=30, attribution_gap=25, dup_logs=0, orphan_intervals=2)


def test_pack_frost_negative_override_clamp() -> None:
    """Shadow-pool bulk and a negative rank_anchor_hint must not inflate billable workload_units."""
    row = _drive("pack_frost")
    _assert_row(row, workload_units=30, pool_units=0, attribution_gap=30, dup_logs=0, orphan_intervals=0)


def test_pack_rift_negative_alt_sum_clamp() -> None:
    """Without rank_anchor_hint, a negative summed ALT total floors pool_units at zero."""
    row = _drive("pack_rift")
    _assert_row(row, workload_units=80, pool_units=0, attribution_gap=80, dup_logs=0, orphan_intervals=0)


def test_pack_haze_dual_completion_late_alts() -> None:
    """Independent completion sentinels on two workloads must not freeze a third still pairing."""
    row = _drive("pack_haze")
    _assert_row(row, workload_units=119, pool_units=119, attribution_gap=0, dup_logs=0, orphan_intervals=0)


def test_pack_iron_replay_completion_shadow_orphan() -> None:
    """Replay collapse, per-workload halt, shadow exclusion, and orphan_interval tally interact."""
    row = _drive("pack_iron")
    _assert_row(row, workload_units=27, pool_units=20, attribution_gap=7, dup_logs=1, orphan_intervals=1)


def test_pack_jade_triple_replay_same_workload() -> None:
    """Three identical telemetry rows on one wire_tag must count as two dup_logs events."""
    row = _drive("pack_jade")
    _assert_row(row, workload_units=7, pool_units=7, attribution_gap=0, dup_logs=2, orphan_intervals=0)


def test_pack_kite_completion_unrelated_workload_alt() -> None:
    """Halting one wire_tag must not block ALT or HIT lines on a different workload."""
    row = _drive("pack_kite")
    _assert_row(row, workload_units=125, pool_units=125, attribution_gap=0, dup_logs=0, orphan_intervals=0)


def test_pack_loom_interleaved_dup_completion() -> None:
    """Interleaved workloads with shared pod ink and a mid-feed completion marker preserve pairing."""
    row = _drive("pack_loom")
    _assert_row(row, workload_units=18, pool_units=18, attribution_gap=0, dup_logs=1, orphan_intervals=0)


def test_pack_mist_override_shadow_replay() -> None:
    """Finance override, shadow-pool HITs, and duplicate replay must not double-count billable totals."""
    row = _drive("pack_mist")
    _assert_row(row, workload_units=100, pool_units=75, attribution_gap=25, dup_logs=1, orphan_intervals=0)


def test_pack_nova_full_stack_stress() -> None:
    """Cross-workload dedupe, completion scope, shadow exclusion, and pool sum divergence together."""
    row = _drive("pack_nova")
    _assert_row(row, workload_units=48, pool_units=70, attribution_gap=-22, dup_logs=1, orphan_intervals=0)
