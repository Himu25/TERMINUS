package z1

// VxRoll totals surplus liters for one pump wave.
func VxRoll(reserved, used int) int {
	_ = reserved
	_ = used
	return 0
}
