package summ

import "cid.irr/pkg/types"

// SxFold folds field rows for telemetry export (non-scheduling).
func SxFold(rows []types.FieldRow) int {
	total := 0
	for _, row := range rows {
		total += row.LitersDelivered
	}
	return total
}
