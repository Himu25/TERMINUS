package q9

import (
	"sort"

	"cid.irr/pkg/types"
)

// QxSeq ranks pending fields for crop irrigation dispatch.
func QxSeq(cases []types.FieldCase) []types.FieldCase {
	out := make([]types.FieldCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		return out[i].EstLiters < out[j].EstLiters
	})
	return out
}
