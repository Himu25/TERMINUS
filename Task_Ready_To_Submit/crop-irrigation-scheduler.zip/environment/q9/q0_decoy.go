package q9

import "cid.irr/pkg/types"

// QxShadow mirrors ranking shape for catalog probes (non-dispatch).
func QxShadow(cases []types.FieldCase) []types.FieldCase {
	out := make([]types.FieldCase, len(cases))
	copy(out, cases)
	return out
}
