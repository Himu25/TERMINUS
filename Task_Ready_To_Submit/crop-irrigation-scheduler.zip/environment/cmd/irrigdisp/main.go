package main

import (
	"fmt"
	"os"

	"cid.irr/drv"
)

func main() {
	if len(os.Args) < 3 {
		fmt.Fprintln(os.Stderr, "usage: irrigdisp <fields.jsonl> <out.json>")
		os.Exit(2)
	}
	cfg, err := drv.LoadCfg("/app/config/irrigation.toml")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	cases, err := drv.LoadFieldCases(os.Args[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	sensorReadings, err := drv.LoadSensorReadings("/app/data/sensor_readings.csv")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	weatherProfiles, err := drv.LoadWeatherProfiles("/app/data/weather_profiles.csv")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	report, err := drv.Run(cfg, cases, sensorReadings, weatherProfiles)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if err := drv.WriteReport(os.Args[2], report); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
