package types

type IrrigCfg struct {
	ReservoirCapLiters   int
	MinCoverageRate      float64
	MaxSurplusRatio      float64
	MaxPipeViolations    int
	MaxScheduleInverts   int
	MinReserveBufferLit  int
	MinCropYieldScore    float64
	BandWeights          map[string]float64
}

type WeatherProfile struct {
	WeatherZone string
	DryFactor   int
	WetFactor   int
	WetAfter    int
}

type FieldCase struct {
	FieldID            string   `json:"field_id"`
	SoilBand           string   `json:"soil_band"`
	StressLevel        int      `json:"stress_level"`
	ForecastRevision   int      `json:"forecast_revision"`
	EstLiters          int      `json:"est_liters"`
	ActLiters          int      `json:"act_liters"`
	ZoneDeps           []string `json:"zone_deps"`
	PumpWave           int      `json:"pump_wave"`
	MoistureScore      float64  `json:"moisture_score"`
	WeatherZone        string   `json:"weather_zone"`
	StartSlot          int      `json:"start_slot"`
	EndSlot            int      `json:"end_slot"`
}

type FieldRow struct {
	FieldID         string  `json:"field_id"`
	SoilBand        string  `json:"soil_band"`
	StressLevel     int     `json:"stress_level"`
	LitersReserved  int     `json:"liters_reserved"`
	LitersDelivered int     `json:"liters_delivered"`
	Served          bool    `json:"served"`
	ZoneReady       bool    `json:"zone_ready"`
	ScheduleRank    int     `json:"schedule_rank"`
	SurplusLiters   int     `json:"surplus_liters"`
	PumpWave        int     `json:"pump_wave"`
	CropYieldScore  float64 `json:"crop_yield_score"`
}

type IrrigReport struct {
	Status                  string     `json:"status"`
	ReservoirCapacityLiters int        `json:"reservoir_capacity_liters"`
	LitersApplied           int        `json:"liters_applied"`
	LitersSurplus           int        `json:"liters_surplus"`
	FieldsTotal             int        `json:"fields_total"`
	FieldsServed            int        `json:"fields_served"`
	CoverageRate            float64    `json:"coverage_rate"`
	SurplusRatio            float64    `json:"surplus_ratio"`
	PipeViolations          int        `json:"pipe_violations"`
	ScheduleInversions      int        `json:"schedule_inversions"`
	ReserveBufferLiters     int        `json:"reserve_buffer_liters"`
	CropYieldScore          float64    `json:"crop_yield_score"`
	ReportDigest            string     `json:"report_digest"`
	Fields                  []FieldRow `json:"fields"`
}
