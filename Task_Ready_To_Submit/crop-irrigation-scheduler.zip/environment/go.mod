module cid.irr

go 1.22
