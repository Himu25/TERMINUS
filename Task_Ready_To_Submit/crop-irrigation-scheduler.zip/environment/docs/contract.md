# Irrigation report contract

## Top-level fields

- status: ok when guardrails pass, otherwise fail
- reservoir_capacity_liters: daily pool from irrigation.toml
- liters_applied: billable liters consumed by served fields
- liters_surplus: reservation surplus summed across fields
- fields_total: input JSONL row count
- fields_served: fields marked served
- coverage_rate: fields_served divided by fields_total
- surplus_ratio: liters_surplus divided by liters_applied
- pipe_violations: fields dispatched before zone dependencies finished
- schedule_inversions: served fields whose rank score fell below a prior finish
- reserve_buffer_liters: pump headroom liters absorbed during waves
- crop_yield_score: weighted moisture score total for served fields
- report_digest: sha256 hex of compact JSON with report_digest empty
- fields: per-field rows

## Field row fields

- field_id, soil_band, stress_level
- liters_reserved, liters_delivered, surplus_liters
- served, zone_ready, schedule_rank, pump_wave, crop_yield_score

## Dispatch order

Pending fields are sorted before allocation using, in order:

1. forecast_revision descending (late sensor readings outrank stale rows)
2. stress_level descending
3. moisture_score descending
4. field_id ascending (stable tie-break)

## schedule_rank

1-based position in the scheduler processing order after the sort above. Lower schedule_rank means the field was scheduled earlier.

## Schedule inversions

For each served field, form rank score = forecast_revision * 10 + stress_level. schedule_inversions counts how often a served field's rank score is greater than the rank score of an earlier-served field.

## Weather profile

weather_profiles.csv supplies dry_scale, wet_scale, and wet_after per weather_zone. The Rust meter blends dry and wet scales across each field's start_slot and duration before converting estimates and actuals into billable liters.

## Drift and volume accounting

- liters_reserved: reservation size from est_liters when est_liters is positive; when est_liters is zero, reservation follows billable liters from the sensor meter
- liters_delivered: sensor act_liters when sensor_readings.csv supplies a value, otherwise act_liters from the field row
- surplus_liters: liters_reserved minus liters_delivered (zero when reserved is not greater than delivered)
- Conflicting-sensor drift rows keep the estimate reservation even when actual delivery is lower, so surplus_liters reflects reserved minus delivered

Digest JSON uses the same keys as the written report with report_digest set to empty string before hashing.
