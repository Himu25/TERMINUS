Crop irrigation dispatch ties together a Go driver, Rust weather meter, and bash runners under /app.
The driver reads field manifests, weather profile tables, and sensor readings.
When est_liters is zero, the meter resolves billable liters from sensor telemetry.
