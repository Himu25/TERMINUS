#!/bin/bash
set -euo pipefail
cd /app
bash /app/scripts/build.sh
/app/bin/fieldpack /app/data/field_manifest.jsonl /app/data/fields_default.jsonl
/app/tools/run_irrigate
