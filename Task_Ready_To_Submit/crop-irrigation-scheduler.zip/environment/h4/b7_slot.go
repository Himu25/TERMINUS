package h4

// UxAbsorb counts reserve buffer liters absorbed from spare headroom.
func UxAbsorb(burstNeed, headroom int) int {
	_ = burstNeed
	_ = headroom
	return 0
}
