package drv

import "cid.irr/h4"

func wavePumpTotal(pumpWave, estLiters, headroom int) int {
	if pumpWave <= 0 {
		return 0
	}
	return h4.UxAbsorb(estLiters/4, headroom)
}
