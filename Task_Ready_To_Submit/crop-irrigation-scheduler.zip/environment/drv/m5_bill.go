package drv

import (
	"cid.irr/n8"
	"cid.irr/pkg/types"
	"cid.irr/z1"
)

func spanBillable(jc types.FieldCase, sensorVal int, rp types.WeatherProfile) int {
	dryScale := rp.DryFactor
	wetScale := rp.WetFactor
	wetAfter := rp.WetAfter
	if sensorVal > 0 {
		dryScale, wetScale, wetAfter = 100, 100, 0
	}
	roll := n8.MeterSpan(
		jc.EstLiters, jc.ActLiters, sensorVal,
		dryScale, wetScale, wetAfter, jc.StartSlot,
	)
	if roll.Billable > 0 {
		return roll.Billable
	}
	return jc.EstLiters
}

func fieldSurplus(reserved, used int) int {
	return z1.VxRoll(reserved, used)
}
