package drv

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"

	"cid.irr/k2"
	"cid.irr/pkg/types"
	"cid.irr/q9"
	"cid.irr/summ"
	"cid.irr/u3"
)

func LoadCfg(path string) (types.IrrigCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.IrrigCfg{}, err
	}
	cfg := types.IrrigCfg{
		ReservoirCapLiters:     12000,
		MinCoverageRate:     0.75,
		MaxSurplusRatio:         0.35,
		MaxPipeViolations:      0,
		MaxScheduleInverts: 1,
		MinReserveBufferLit:      3,
		MinCropYieldScore:     2.0,
		BandWeights:           map[string]float64{"band_alpha": 1.0, "band_beta": 1.0, "band_gamma": 1.0},
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "reservoir_capacity_liters":
			fmt.Sscanf(val, "%d", &cfg.ReservoirCapLiters)
		case "min_coverage_rate":
			fmt.Sscanf(val, "%f", &cfg.MinCoverageRate)
		case "max_surplus_ratio":
			fmt.Sscanf(val, "%f", &cfg.MaxSurplusRatio)
		case "max_pipe_violations":
			fmt.Sscanf(val, "%d", &cfg.MaxPipeViolations)
		case "max_schedule_inversions":
			fmt.Sscanf(val, "%d", &cfg.MaxScheduleInverts)
		case "min_reserve_buffer_liters":
			fmt.Sscanf(val, "%d", &cfg.MinReserveBufferLit)
		case "min_crop_yield_score":
			fmt.Sscanf(val, "%f", &cfg.MinCropYieldScore)
		case "band_weight_alpha":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.BandWeights["band_alpha"] = w
		case "band_weight_beta":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.BandWeights["band_beta"] = w
		case "band_weight_gamma":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.BandWeights["band_gamma"] = w
		}
	}
	return cfg, nil
}

func LoadWeatherProfiles(path string) (map[string]types.WeatherProfile, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]types.WeatherProfile)
	for i, row := range rows {
		if i == 0 || len(row) < 4 {
			continue
		}
		var peak, renew, after int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &peak)
		fmt.Sscanf(strings.TrimSpace(row[2]), "%d", &renew)
		fmt.Sscanf(strings.TrimSpace(row[3]), "%d", &after)
		id := strings.TrimSpace(row[0])
		out[id] = types.WeatherProfile{
			WeatherZone: id,
			DryFactor:  peak,
			WetFactor: renew,
			WetAfter: after,
		}
	}
	return out, nil
}

func LoadFieldCases(path string) ([]types.FieldCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.FieldCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var jc types.FieldCase
		if err := json.Unmarshal([]byte(line), &jc); err != nil {
			return nil, err
		}
		if jc.WeatherZone == "" {
			jc.WeatherZone = "north-basin"
		}
		out = append(out, jc)
	}
	return out, sc.Err()
}

func LoadSensorReadings(path string) (map[string]int, error) {
	f, err := os.Open(path)
	if err != nil {
		return map[string]int{}, nil
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]int)
	for i, row := range rows {
		if i == 0 || len(row) < 2 {
			continue
		}
		var actTons int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &actTons)
		out[strings.TrimSpace(row[0])] = actTons
	}
	return out, nil
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

func weatherFor(jc types.FieldCase, weatherProfiles map[string]types.WeatherProfile) types.WeatherProfile {
	if rp, ok := weatherProfiles[jc.WeatherZone]; ok {
		return rp
	}
	return types.WeatherProfile{WeatherZone: jc.WeatherZone, DryFactor: 100, WetFactor: 100, WetAfter: 0}
}

func Run(cfg types.IrrigCfg, cases []types.FieldCase, sensorReadings map[string]int, weatherProfiles map[string]types.WeatherProfile) (types.IrrigReport, error) {
	ordered := q9.QxSeq(cases)
	report := types.IrrigReport{
		Status:                  "ok",
		ReservoirCapacityLiters: cfg.ReservoirCapLiters,
		FieldsTotal:             len(ordered),
	}
	done := make(map[string]bool)
	budgetLeft := cfg.ReservoirCapLiters
	var spent, totalWaste, completed, depViol, inversions, renewTotal int
	var valueTotal float64
	prevRank := -1
	report.Fields = make([]types.FieldRow, 0, len(ordered))

	for idx, jc := range ordered {
		actualReady := true
		for _, depID := range jc.ZoneDeps {
			if !done[depID] {
				actualReady = false
				break
			}
		}
		depReady := k2.PxHold(jc.ZoneDeps, done)
		if len(jc.ZoneDeps) > 0 && !actualReady && depReady {
			depViol++
		}
		sensorVal := 0
		if act, ok := sensorReadings[jc.FieldID]; ok && act > 0 {
			sensorVal = act
			jc.ActLiters = act
		}
		rp := weatherFor(jc, weatherProfiles)
		billable := spanBillable(jc, sensorVal, rp)
		reserveNeed := u3.AxNeed(jc.EstLiters, billable)
		reserved, ok := u3.BxReserve(budgetLeft, reserveNeed)
		headroom := budgetLeft - reserved
		if jc.PumpWave > 0 {
			renewTotal += wavePumpTotal(jc.PumpWave, jc.EstLiters, headroom)
		}
		used := 0
		finished := false
		if ok && depReady {
			used = jc.ActLiters
			if used <= 0 {
				used = billable
			}
			if used > reserved {
				used = reserved
			}
			budgetLeft -= reserved
			spent += used
			finished = true
			completed++
			done[jc.FieldID] = true
			valueTotal += u3.VxValue(jc.MoistureScore, used)
		}
		wasteAmt := fieldSurplus(reserved, used)
		totalWaste += wasteAmt
		rankScore := jc.ForecastRevision*10 + jc.StressLevel
		if finished {
			if prevRank >= 0 && rankScore > prevRank {
				inversions++
			}
			prevRank = rankScore
		}
		row := types.FieldRow{
			FieldID:         jc.FieldID,
			SoilBand:        jc.SoilBand,
			StressLevel:       jc.StressLevel,
			LitersReserved:  reserved,
			LitersDelivered:      used,
			Served:      finished,
			ZoneReady:       depReady,
			ScheduleRank:   idx + 1,
			SurplusLiters:     wasteAmt,
			PumpWave:      jc.PumpWave,
			CropYieldScore: round4(u3.VxValue(jc.MoistureScore, used)),
		}
		report.Fields = append(report.Fields, row)
	}

	report.LitersApplied = spent
	report.LitersSurplus = totalWaste
	report.FieldsServed = completed
	if report.FieldsTotal > 0 {
		report.CoverageRate = round4(float64(completed) / float64(report.FieldsTotal))
	}
	if spent > 0 {
		report.SurplusRatio = round4(float64(totalWaste) / float64(spent))
	}
	report.PipeViolations = depViol
	report.ScheduleInversions = inversions
	report.ReserveBufferLiters = renewTotal
	report.CropYieldScore = round4(valueTotal)
	hasPumpWave := false
	for _, jc := range ordered {
		if jc.PumpWave > 0 {
			hasPumpWave = true
			break
		}
	}
	if !meetsFloors(cfg, report, hasPumpWave) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func meetsFloors(cfg types.IrrigCfg, report types.IrrigReport, hasPumpWave bool) bool {
	if report.CoverageRate < cfg.MinCoverageRate {
		return false
	}
	if report.SurplusRatio > cfg.MaxSurplusRatio {
		return false
	}
	if report.PipeViolations > cfg.MaxPipeViolations {
		return false
	}
	if report.ScheduleInversions > cfg.MaxScheduleInverts {
		return false
	}
	if report.ReserveBufferLiters < cfg.MinReserveBufferLit {
		if hasPumpWave {
			return false
		}
	}
	if report.CropYieldScore < cfg.MinCropYieldScore {
		return false
	}
	for _, row := range report.Fields {
		if strings.HasPrefix(row.FieldID, "f_dep_") && !row.ZoneReady && row.Served {
			return false
		}
		if strings.HasPrefix(row.FieldID, "f_reserve_") && row.PumpWave > 0 && !row.Served {
			return false
		}
		if strings.HasPrefix(row.FieldID, "f_sensor_") && row.SurplusLiters == 0 && row.LitersReserved > row.LitersDelivered+50 {
			return false
		}
		if strings.HasPrefix(row.FieldID, "f_weather_") && row.Served && row.LitersDelivered > row.LitersReserved+200 {
			return false
		}
	}
	_ = summ.SxFold(report.Fields)
	return true
}

type digestPayload struct {
	Status              string         `json:"status"`
	ReservoirCapacityLiters   int            `json:"reservoir_capacity_liters"`
	LitersApplied          int            `json:"liters_applied"`
	LitersSurplus          int            `json:"liters_surplus"`
	FieldsTotal           int            `json:"fields_total"`
	FieldsServed       int            `json:"fields_served"`
	CoverageRate      float64        `json:"coverage_rate"`
	SurplusRatio          float64        `json:"surplus_ratio"`
	PipeViolations       int            `json:"pipe_violations"`
	ScheduleInversions  int            `json:"schedule_inversions"`
	ReserveBufferLiters    int            `json:"reserve_buffer_liters"`
	CropYieldScore   float64        `json:"crop_yield_score"`
	ReportDigest        string         `json:"report_digest"`
	Fields             []types.FieldRow `json:"fields"`
}

func digestBody(report types.IrrigReport) string {
	payload := digestPayload{
		Status:              report.Status,
		ReservoirCapacityLiters: report.ReservoirCapacityLiters,
		LitersApplied:         report.LitersApplied,
		LitersSurplus:         report.LitersSurplus,
		FieldsTotal:        report.FieldsTotal,
		FieldsServed:       report.FieldsServed,
		CoverageRate:        report.CoverageRate,
		SurplusRatio:        report.SurplusRatio,
		PipeViolations:     report.PipeViolations,
		ScheduleInversions:  report.ScheduleInversions,
		ReserveBufferLiters:    report.ReserveBufferLiters,
		CropYieldScore:   report.CropYieldScore,
		ReportDigest:        "",
		Fields:             report.Fields,
	}
	raw, err := marshalDigestJSON(payload)
	if err != nil {
		return ""
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func marshalDigestJSON(payload digestPayload) ([]byte, error) {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return nil, err
	}
	b := buf.Bytes()
	if n := len(b); n > 0 && b[n-1] == '\n' {
		b = b[:n-1]
	}
	return b, nil
}

func WriteReport(path string, report types.IrrigReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func p95(values []int) int {
	if len(values) == 0 {
		return 0
	}
	cp := append([]int(nil), values...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}
