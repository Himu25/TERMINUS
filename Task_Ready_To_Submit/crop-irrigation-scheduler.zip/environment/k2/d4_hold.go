package k2

// PxHold reports whether dependency prerequisites are satisfied.
func PxHold(depOn []string, done map[string]bool) bool {
	_ = depOn
	_ = done
	return true
}
