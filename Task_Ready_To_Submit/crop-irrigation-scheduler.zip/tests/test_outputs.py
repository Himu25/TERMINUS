"""Validate /app/output/irrigation_report.json against irrigation.toml guardrails."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "irrigation_report.json"
FIELDS = APP / "data" / "fields_default.jsonl"
CFG = APP / "config" / "irrigation.toml"
FIELD_REPORTS = APP / "data" / "sensor_readings.csv"
CASES = Path(__file__).resolve().parent / "data"

_DEFAULT_FIELDS_TEXT = FIELDS.read_text(encoding="utf-8") if FIELDS.is_file() else ""

REPORT_KEYS = frozenset(
    {
        "status",
        "reservoir_capacity_liters",
        "liters_applied",
        "liters_surplus",
        "fields_total",
        "fields_served",
        "coverage_rate",
        "surplus_ratio",
        "pipe_violations",
        "schedule_inversions",
        "reserve_buffer_liters",
        "crop_yield_score",
        "report_digest",
        "fields",
    }
)
ROW_KEYS = frozenset(
    {
        "field_id",
        "soil_band",
        "stress_level",
        "liters_reserved",
        "liters_delivered",
        "surplus_liters",
        "served",
        "zone_ready",
        "schedule_rank",
        "pump_wave",
        "crop_yield_score",
    }
)


def _load_field_reports() -> dict[str, int]:
    field_reports: dict[str, int] = {}
    if not FIELD_REPORTS.is_file():
        return field_reports
    lines = FIELD_REPORTS.read_text(encoding="utf-8").splitlines()
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        field_id, act_liters = (part.strip() for part in line.split(",", 1))
        field_reports[field_id] = int(act_liters)
    return field_reports


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "reservoir_capacity_liters": 12000,
        "min_coverage_rate": 0.75,
        "max_surplus_ratio": 0.35,
        "max_pipe_violations": 0,
        "max_schedule_inversions": 1,
        "min_reserve_buffer_liters": 3,
        "min_crop_yield_score": 2.0,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in ("min_coverage_rate", "max_surplus_ratio", "min_crop_yield_score"):
            cfg[key] = float(val)
        elif key in (
            "reservoir_capacity_liters",
            "max_pipe_violations",
            "max_schedule_inversions",
            "min_reserve_buffer_liters",
        ):
            cfg[key] = int(float(val))
    return cfg


def _field_rows_from_text(text: str) -> list[dict]:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def _field_ids_from_text(text: str) -> list[str]:
    return [row["field_id"] for row in _field_rows_from_text(text)]


def _field_map_from_text(text: str) -> dict[str, dict]:
    return {row["field_id"]: row for row in _field_rows_from_text(text)}


def _assert_fields_match_input(report: dict, fields_text: str) -> None:
    expected_ids = _field_ids_from_text(fields_text)
    report_ids = [row["field_id"] for row in report["fields"]]
    assert report["fields_total"] == len(expected_ids)
    assert len(report_ids) == len(expected_ids)
    assert set(report_ids) == set(expected_ids)


@pytest.fixture(autouse=True)
def restore_default_fields() -> None:
    yield
    if _DEFAULT_FIELDS_TEXT:
        _atomic_write_text(FIELDS, _DEFAULT_FIELDS_TEXT)


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _swap_fixture(stem: str) -> str:
    src = CASES / f"{stem}.jsonl"
    text = src.read_text(encoding="utf-8")
    _atomic_write_text(FIELDS, text)
    return text


def _expected_digest(report: dict) -> str:
    payload = dict(report)
    payload["report_digest"] = ""
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _invoke_default() -> None:
    proc = subprocess.run(
        ["/app/tools/run_irrigate"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "irrigation_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    _invoke_default()


def test_report_top_level_keys_exact() -> None:
    """Report must expose only the documented top-level keys."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS


def test_field_row_schema() -> None:
    """Each field row must match the documented per-field schema."""
    report = _load_report()
    assert report["fields"]
    for row in report["fields"]:
        assert set(row.keys()) == ROW_KEYS
        assert isinstance(row["field_id"], str) and row["field_id"]
        assert isinstance(row["soil_band"], str) and row["soil_band"]
        assert isinstance(row["stress_level"], int)
        assert row["liters_reserved"] >= 0
        assert row["liters_delivered"] >= 0
        assert row["surplus_liters"] >= 0
        assert isinstance(row["served"], bool)
        assert isinstance(row["zone_ready"], bool)
        assert row["schedule_rank"] >= 1
        assert row["pump_wave"] >= 0
        assert row["crop_yield_score"] >= 0.0


def test_passing_run_contract() -> None:
    """Default bundle must finish ok and meet irrigation.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["reservoir_capacity_liters"] == cfg["reservoir_capacity_liters"]
    _assert_fields_match_input(report, _DEFAULT_FIELDS_TEXT)
    assert report["coverage_rate"] >= cfg["min_coverage_rate"]
    assert report["surplus_ratio"] <= cfg["max_surplus_ratio"]
    assert report["pipe_violations"] <= cfg["max_pipe_violations"]
    assert report["schedule_inversions"] <= cfg["max_schedule_inversions"]
    assert report["reserve_buffer_liters"] >= cfg["min_reserve_buffer_liters"]
    assert report["crop_yield_score"] >= cfg["min_crop_yield_score"]


def test_fields_total_matches_input_rows() -> None:
    """Report field IDs must cover every input JSONL row with no drops or extras."""
    report = _load_report()
    _assert_fields_match_input(report, _DEFAULT_FIELDS_TEXT)


def test_report_digest_matches_payload() -> None:
    """report_digest must hash the compact pre-digest JSON payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_deterministic_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_dep_rows_finish_in_order() -> None:
    """Dependency chain rows must complete only after prerequisites."""
    report = _load_report()
    ranks = {row["field_id"]: row["schedule_rank"] for row in report["fields"]}
    assert ranks["f_dep_root"] < ranks["f_dep_leaf"] < ranks["f_dep_chain"]
    for row in report["fields"]:
        if row["field_id"].startswith("f_dep_") and row["served"]:
            assert row["zone_ready"] is True, row


def test_prio_hot_ranks_before_cold() -> None:
    """Late priority revision rows must finish before stale low-revision peers."""
    report = _load_report()
    hot = next(r for r in report["fields"] if r["field_id"] == "f_prio_hot")
    cold = next(r for r in report["fields"] if r["field_id"] == "f_prio_cold")
    assert hot["served"] is True
    assert cold["served"] is True
    assert hot["schedule_rank"] < cold["schedule_rank"], (hot, cold)


def test_drift_accounting_semantics() -> None:
    """Drift rows reserve estimates, bill actuals, and record reserved minus used."""
    report = _load_report()
    inputs = _field_map_from_text(_DEFAULT_FIELDS_TEXT)
    field_reports = _load_field_reports()
    for row in report["fields"]:
        if not row["field_id"].startswith("f_sensor_") or not row["served"]:
            continue
        spec = inputs[row["field_id"]]
        expected_used = field_reports.get(row["field_id"], spec["act_liters"])
        assert row["liters_reserved"] == spec["est_liters"]
        assert row["liters_delivered"] == expected_used
        assert row["surplus_liters"] == max(0, row["liters_reserved"] - row["liters_delivered"])


def test_drift_rows_record_waste() -> None:
    """Drift-prone rows with inflated reservations must record surplus_liters."""
    report = _load_report()
    drift_rows = [r for r in report["fields"] if r["field_id"].startswith("f_sensor_")]
    assert drift_rows
    assert any(r["surplus_liters"] > 0 for r in drift_rows if r["served"])


def test_burst_rows_complete() -> None:
    """Pump-wave rows with the f_reserve_ prefix must complete under the default bundle."""
    report = _load_report()
    burst_rows = [r for r in report["fields"] if r["field_id"].startswith("f_reserve_")]
    assert burst_rows
    assert all(r["served"] for r in burst_rows), burst_rows


def test_field_rows_respect_intensity() -> None:
    """Weather-zone rows must bill through blended intensity, not raw estimates alone."""
    report = _load_report()
    us = next(r for r in report["fields"] if r["field_id"] == "f_weather_north")
    eu = next(r for r in report["fields"] if r["field_id"] == "f_weather_south")
    assert us["served"] and eu["served"]
    assert eu["liters_reserved"] < us["liters_reserved"]
    assert eu["liters_delivered"] < us["liters_delivered"]


def test_renew_late_row_completes() -> None:
    """Delayed pump-wave row f_renew_late must complete under the default bundle."""
    report = _load_report()
    renew = next(r for r in report["fields"] if r["field_id"] == "f_renew_late")
    assert renew["served"] is True
    assert renew["pump_wave"] > 0


def test_scenario_dep_chain() -> None:
    """Dependency-chain scenario must schedule deps before dependents."""
    fields_text = _swap_fixture("dep_chain")
    _invoke_default()
    report = _load_report()
    _assert_fields_match_input(report, fields_text)
    assert report["pipe_violations"] == 0
    assert report["status"] == "ok"
    ranks = {row["field_id"]: row["schedule_rank"] for row in report["fields"]}
    assert ranks["f_dep_root"] < ranks["f_dep_leaf"] < ranks["f_dep_chain"]


def test_scenario_urgency_flip() -> None:
    """Stress-flip scenario must schedule late revisions ahead of stale peers."""
    cfg = _parse_cfg()
    fields_text = _swap_fixture("urgency_flip")
    _invoke_default()
    report = _load_report()
    _assert_fields_match_input(report, fields_text)
    hot = next(r for r in report["fields"] if r["field_id"] == "f_prio_hot")
    cold = next(r for r in report["fields"] if r["field_id"] == "f_prio_cold")
    assert hot["schedule_rank"] < cold["schedule_rank"]
    assert report["schedule_inversions"] <= cfg["max_schedule_inversions"]
    assert report["status"] == "ok"


def test_scenario_est_drift() -> None:
    """Estimate-drift scenario must keep surplus_ratio under max_surplus_ratio."""
    cfg = _parse_cfg()
    fields_text = _swap_fixture("est_drift")
    _invoke_default()
    report = _load_report()
    _assert_fields_match_input(report, fields_text)
    inputs = _field_map_from_text(fields_text)
    for row in report["fields"]:
        if not row["field_id"].startswith("f_sensor_") or not row["served"]:
            continue
        spec = inputs[row["field_id"]]
        assert row["liters_reserved"] == spec["est_liters"]
        assert row["surplus_liters"] == max(0, row["liters_reserved"] - row["liters_delivered"])
        assert row["surplus_liters"] > 0
    assert report["surplus_ratio"] <= cfg["max_surplus_ratio"]
    assert report["status"] == "ok"


def test_scenario_burst_cluster() -> None:
    """Pump-cluster scenario must absorb enough pump buffer headroom."""
    cfg = _parse_cfg()
    fields_text = _swap_fixture("burst_cluster")
    _invoke_default()
    report = _load_report()
    _assert_fields_match_input(report, fields_text)
    burst_rows = [r for r in report["fields"] if r["field_id"].startswith("f_reserve_")]
    assert burst_rows
    assert all(r["served"] for r in burst_rows)
    assert report["reserve_buffer_liters"] >= cfg["min_reserve_buffer_liters"]
    assert report["status"] == "ok"


def test_scenario_value_mix() -> None:
    """Need-score mix scenario must meet crop_yield_score floor."""
    cfg = _parse_cfg()
    fields_text = _swap_fixture("value_mix")
    _invoke_default()
    report = _load_report()
    _assert_fields_match_input(report, fields_text)
    assert report["crop_yield_score"] >= cfg["min_crop_yield_score"]


def test_scenario_field_meter() -> None:
    """Zero-estimate field-report row must bill act_liters through the meter."""
    fields_text = _swap_fixture("field_meter")
    _invoke_default()
    report = _load_report()
    _assert_fields_match_input(report, fields_text)
    field_reports = _load_field_reports()
    expected_used = field_reports["f_soil_meter"]
    row = next(r for r in report["fields"] if r["field_id"] == "f_soil_meter")
    assert row["served"] is True
    assert row["liters_delivered"] == expected_used
    assert row["liters_reserved"] >= row["liters_delivered"]
    assert row["surplus_liters"] == max(0, row["liters_reserved"] - row["liters_delivered"])


def test_scenario_field_mix() -> None:
    """Weather-zone variability scenario must bill south-ridge below north-basin for similar work."""
    fields_text = _swap_fixture("weather_mix")
    _invoke_default()
    report = _load_report()
    _assert_fields_match_input(report, fields_text)
    us = next(r for r in report["fields"] if r["field_id"] == "f_weather_north")
    eu = next(r for r in report["fields"] if r["field_id"] == "f_weather_south")
    assert us["served"] and eu["served"]
    assert eu["liters_reserved"] < us["liters_reserved"]


def test_scenario_renew_delay() -> None:
    """Delayed pump-wave scenario must complete f_renew_late with pump buffer absorption."""
    cfg = _parse_cfg()
    fields_text = _swap_fixture("renew_delay")
    _invoke_default()
    report = _load_report()
    _assert_fields_match_input(report, fields_text)
    renew = next(r for r in report["fields"] if r["field_id"] == "f_renew_late")
    assert renew["served"] is True
    assert report["reserve_buffer_liters"] >= cfg["min_reserve_buffer_liters"]
    assert report["status"] == "ok"
