#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/irrigation.toml
require_file /app/data/field_manifest.jsonl
require_file /app/data/weather_profiles.csv
require_file /app/data/sensor_readings.csv
mkdir -p /app/bin /app/output

log "apply patched sources"
cp "${ROOT_DIR}/oracle/p2_order.go" /app/q9/p2_order.go
cp "${ROOT_DIR}/oracle/d4_hold.go" /app/k2/d4_hold.go
cp "${ROOT_DIR}/oracle/b7_slot.go" /app/h4/b7_slot.go
cp "${ROOT_DIR}/oracle/w5_roll.go" /app/z1/w5_roll.go
cp "${ROOT_DIR}/oracle/lib.rs" /app/n8/src/lib.rs

log "rebuild dispatcher"
bash /app/scripts/build.sh

log "refresh default field bundle"
/app/bin/fieldpack /app/data/field_manifest.jsonl /app/data/fields_default.jsonl

log "emit default dispatch report"
/app/tools/run_irrigate

log "post-run validation against irrigation.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/irrigation.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k in ("min_coverage_rate", "max_surplus_ratio", "min_crop_yield_score"):
        cfg[k] = float(v)
    elif k.startswith("max_") or k.startswith("min_") or k == "reservoir_capacity_liters":
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/irrigation_report.json").read_text())
assert report["status"] == "ok", report
assert report["coverage_rate"] >= cfg["min_coverage_rate"]
assert report["surplus_ratio"] <= cfg["max_surplus_ratio"]
assert report["pipe_violations"] <= cfg["max_pipe_violations"]
assert report["schedule_inversions"] <= cfg["max_schedule_inversions"]
assert report["reserve_buffer_liters"] >= cfg["min_reserve_buffer_liters"]
assert report["crop_yield_score"] >= cfg["min_crop_yield_score"]
for row in report["fields"]:
    if row["field_id"].startswith("f_dep_") and row["served"]:
        assert row["zone_ready"], row
    if row["field_id"].startswith("f_reserve_"):
        assert row["served"], row
print("ok", report["coverage_rate"], report["surplus_ratio"], report["crop_yield_score"])
PY

log "oracle complete"
