package z1

// VxRoll totals surplus liters for one pump wave.
func VxRoll(reserved, used int) int {
	if reserved <= used {
		return 0
	}
	return reserved - used
}
