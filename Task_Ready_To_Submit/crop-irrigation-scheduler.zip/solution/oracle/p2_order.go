package q9

import (
	"sort"

	"cid.irr/pkg/types"
)

// QxSeq ranks pending fields for crop irrigation dispatch.
func QxSeq(cases []types.FieldCase) []types.FieldCase {
	out := make([]types.FieldCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		a, b := out[i], out[j]
		if a.ForecastRevision != b.ForecastRevision {
			return a.ForecastRevision > b.ForecastRevision
		}
		if a.StressLevel != b.StressLevel {
			return a.StressLevel > b.StressLevel
		}
		if a.MoistureScore != b.MoistureScore {
			return a.MoistureScore > b.MoistureScore
		}
		return a.FieldID < b.FieldID
	})
	return out
}
