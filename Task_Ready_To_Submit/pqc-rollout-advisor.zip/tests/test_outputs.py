"""Verifier for /app/output/migration_matrix.json."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
REPORT = APP / "output" / "migration_matrix.json"
SCENARIOS = APP / "fixtures" / "scenarios"
STEADY = APP / "data" / "steady"
FIXTURE_INDEX = APP / "docs" / "fixture_index.txt"


def _env() -> dict[str, str]:
    return os.environ.copy()


def rebuild_binaries() -> None:
    crate = APP / "crates" / "k7core"
    subprocess.run(
        ["cargo", "build", "--release", "--bin", "wkctl"],
        cwd=str(crate),
        check=True,
        env=_env(),
    )
    subprocess.run(
        ["go", "build", "-o", "/app/bin/advisor", "./cmd/advisor"],
        cwd=str(APP),
        check=True,
        env=_env(),
    )
    (APP / "bin").mkdir(parents=True, exist_ok=True)
    shutil.copy2(crate / "target" / "release" / "wkctl", APP / "bin" / "wkctl")


def run_matrix() -> None:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        [
            "/app/bin/advisor",
            "-scenarios",
            str(SCENARIOS),
            "-inventory",
            str(APP / "inventory"),
            "-out",
            str(REPORT),
        ],
        cwd=str(APP),
        check=True,
        env=_env(),
    )


def _steady(name: str) -> dict:
    return json.loads((STEADY / f"{name}.json").read_text())


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    rebuild_binaries()


@pytest.fixture()
def report() -> dict:
    run_matrix()
    return json.loads(REPORT.read_text())


def _scenario(report: dict, name: str) -> dict:
    for row in report["scenarios"]:
        if row["name"] == name:
            return row
    raise AssertionError(f"missing scenario {name!r}")


def _fixture_names() -> list[str]:
    return [
        line.strip()
        for line in FIXTURE_INDEX.read_text().splitlines()
        if line.strip()
    ]


def test_report_schema(report: dict) -> None:
    """migration_matrix.json matches the published contract."""
    assert isinstance(report, dict)
    rows = report["scenarios"]
    assert isinstance(rows, list)
    assert len(rows) == len(_fixture_names())
    names = sorted(r["name"] for r in rows)
    assert names == sorted(_fixture_names())
    for row in rows:
        assert set(row.keys()) >= {
            "name",
            "finish_reason",
            "inventory_hits",
            "wire_ok",
            "token_ok",
            "hsm_excluded",
            "hybrid_ok",
            "perf_ratio",
            "migration_digest_hex",
        }
        assert row["finish_reason"] in {"complete", "reject"}
        digest = row["migration_digest_hex"]
        assert isinstance(digest, str) and len(digest) == 64
        int(digest, 16)


def test_fixture_index_coverage(report: dict) -> None:
    """Every fixture listed in fixture_index.txt appears in the migration matrix."""
    indexed = set(_fixture_names())
    reported = {row["name"] for row in report["scenarios"]}
    assert reported == indexed


def test_all_complete(report: dict) -> None:
    """Every bundled scenario completes migration replay."""
    for name in _fixture_names():
        assert _scenario(report, name)["finish_reason"] == "complete"


def test_wire_slot_fixed_width(report: dict) -> None:
    """Fixed-width wire slot services accept normalized signatures."""
    exp = _steady("wire_slot")
    row = _scenario(report, "wire_slot")
    assert row["wire_ok"] is exp["wire_ok"]
    assert row["inventory_hits"] == exp["inventory_hits"]


def test_token_stamp_ceiling(report: dict) -> None:
    """Timestamped token bundles stay within the service ceiling."""
    exp = _steady("token_stamp")
    row = _scenario(report, "token_stamp")
    assert row["token_ok"] is exp["token_ok"]
    assert row["hybrid_ok"] is exp["hybrid_ok"]


def test_hsm_lane_excluded(report: dict) -> None:
    """Immutable hardware signing lanes are excluded from next-gen rollout."""
    exp = _steady("hsm_lane")
    row = _scenario(report, "hsm_lane")
    assert row["hsm_excluded"] is exp["hsm_excluded"]
    assert row["finish_reason"] == exp["finish_reason"]


def test_hybrid_gate_dual_verify(report: dict) -> None:
    """Dual-verify clients accept compact transition artifacts."""
    exp = _steady("hybrid_gate")
    row = _scenario(report, "hybrid_gate")
    assert row["hybrid_ok"] is exp["hybrid_ok"]
    assert row["token_ok"] is exp["token_ok"]


def test_perf_budget_ratio(report: dict) -> None:
    """Budgeted signing paths stay within the allowed slowdown ratio."""
    exp = _steady("perf_budget")
    row = _scenario(report, "perf_budget")
    assert row["perf_ratio"] == exp["perf_ratio"]
    assert row["perf_ratio"] <= 2.0


def test_migration_digest_shared(report: dict) -> None:
    """Each scenario row carries the same matrix integrity digest."""
    digests = {row["migration_digest_hex"] for row in report["scenarios"]}
    assert len(digests) == 1


def test_steady_rows_align(report: dict) -> None:
    """Steady reference rows agree with replayed counters."""
    for name in _fixture_names():
        steady = _steady(name)
        row = _scenario(report, name)
        assert row["finish_reason"] == steady["finish_reason"]
        assert row["inventory_hits"] == steady["inventory_hits"]
        assert row["wire_ok"] == steady["wire_ok"]
        assert row["token_ok"] == steady["token_ok"]
        assert row["hsm_excluded"] == steady["hsm_excluded"]
        assert row["hybrid_ok"] == steady["hybrid_ok"]
        assert row["perf_ratio"] == steady["perf_ratio"]


def test_rebuild_from_source(report: dict) -> None:
    """Fresh go and rust rebuilds reproduce the same migration matrix."""
    rebuild_binaries()
    run_matrix()
    again = json.loads(REPORT.read_text())
    assert again["scenarios"] == report["scenarios"]
