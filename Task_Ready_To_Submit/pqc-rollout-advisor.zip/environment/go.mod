module pqcrollout

go 1.22
