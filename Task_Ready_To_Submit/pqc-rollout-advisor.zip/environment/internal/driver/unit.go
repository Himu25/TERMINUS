package driver

import (
	"sort"
)

func SortRowsByName(names []string) []string {
	out := append([]string(nil), names...)
	sort.Strings(out)
	return out
}
