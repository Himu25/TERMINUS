package driver

import (
	"os"
	"path/filepath"
	"strings"

	"pqcrollout/pkg/api"
)

func scanT(inventoryDir, serviceName string) int {
	path := filepath.Join(inventoryDir, "services", serviceName+".yaml")
	raw, err := os.ReadFile(path)
	if err != nil {
		return 0
	}
	text := string(raw)
	if strings.Contains(text, "KEY_BITS:") {
		return 1
	}
	return 0
}

func phaseR(sc *api.Scenario) bool {
	if !sc.HsmLocked {
		return true
	}
	return false
}
