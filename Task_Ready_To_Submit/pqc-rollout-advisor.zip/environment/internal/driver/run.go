package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"

	"pqcrollout/pkg/api"
)

func RunMatrix(scenariosDir, inventoryDir, outPath string) error {
	entries, err := os.ReadDir(scenariosDir)
	if err != nil {
		return err
	}
	var rows []api.ScenarioRow
	var digestParts []string
	for _, ent := range entries {
		if ent.IsDir() || !strings.HasSuffix(ent.Name(), ".json") {
			continue
		}
		raw, err := os.ReadFile(filepath.Join(scenariosDir, ent.Name()))
		if err != nil {
			return err
		}
		var sc api.Scenario
		if err := json.Unmarshal(raw, &sc); err != nil {
			return err
		}
		row, err := replayScenario(&sc, inventoryDir)
		if err != nil {
			return err
		}
		rows = append(rows, row)
		digestParts = append(digestParts, fmt.Sprintf("%s:%s:%t:%t:%t:%.3f",
			row.Name, row.FinishReason, row.WireOk, row.TokenOk, row.HybridOk, row.PerfRatio))
	}
	digest := sha256.Sum256([]byte(strings.Join(digestParts, "|")))
	for i := range rows {
		rows[i].MigrationDigest = hex.EncodeToString(digest[:])
	}
	report := api.MatrixReport{Scenarios: rows}
	payload, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(outPath), 0o755); err != nil {
		return err
	}
	return os.WriteFile(outPath, payload, 0o644)
}

func replayScenario(sc *api.Scenario, inventoryDir string) (api.ScenarioRow, error) {
	row := api.ScenarioRow{Name: sc.Name}
	row.InventoryHits = scanT(inventoryDir, sc.Name)
	payload := []byte("fixture-" + sc.Name)

	sig, err := execSigctl("blend", sc.WireMode, payload)
	if err != nil {
		return row, err
	}
	if sc.WireMode == "fixed256" {
		row.WireOk = len(sig) == 256
	} else {
		row.WireOk = len(sig) > 0
	}

	token, err := execSigctl("pack", "", payload)
	if err != nil {
		return row, err
	}
	row.TokenOk = true
	if sc.TokenLimit > 0 {
		row.TokenOk = len(token) <= sc.TokenLimit
	}

	row.HsmExcluded = phaseR(sc)

	legacy, err := execSigctl("legacy", "", payload)
	if err != nil {
		return row, err
	}
	hybrid, err := execSigctl("pack", "", payload)
	if err != nil {
		return row, err
	}
	row.HybridOk = verifyHybrid(legacy, hybrid, sc)

	baseline := float64(sc.PerfBaseline)
	if baseline <= 0 {
		baseline = 100
	}
	ops, err := execMeter(payload, sc.HybridRequired)
	if err != nil {
		return row, err
	}
	row.PerfRatio = float64(ops) / baseline

	row.FinishReason = finishReason(row, sc)
	return row, nil
}

func finishReason(row api.ScenarioRow, sc *api.Scenario) string {
	if sc.HsmLocked && !row.HsmExcluded {
		return "reject"
	}
	if sc.WireMode == "fixed256" && !row.WireOk {
		return "reject"
	}
	if sc.TokenLimit > 0 && !row.TokenOk {
		return "reject"
	}
	if sc.HybridRequired && !row.HybridOk {
		return "reject"
	}
	if sc.PerfGate && row.PerfRatio > 2.0 {
		return "reject"
	}
	return "complete"
}

func verifyHybrid(legacy, hybrid []byte, sc *api.Scenario) bool {
	if sc.LegacyOnly {
		return len(hybrid) == len(legacy)
	}
	if len(hybrid) == 0 {
		return false
	}
	if sc.HybridRequired {
		if len(hybrid) > 0 && hybrid[0] == 0x01 && len(hybrid) >= 33 {
			return len(hybrid) <= sc.TokenLimit && bytesHasPrefix(hybrid[1:33], legacy[:32])
		}
		return len(hybrid) <= sc.TokenLimit && bytesHasPrefix(hybrid, legacy[:32])
	}
	return true
}

func bytesHasPrefix(hay, needle []byte) bool {
	if len(hay) < len(needle) {
		return false
	}
	for i := range needle {
		if hay[i] != needle[i] {
			return false
		}
	}
	return true
}

func execSigctl(subcmd, arg string, payload []byte) ([]byte, error) {
	args := []string{subcmd}
	if arg != "" {
		args = append(args, arg)
	}
	cmd := exec.Command("/app/bin/wkctl", args...)
	cmd.Stdin = strings.NewReader(string(payload))
	return cmd.Output()
}

func execMeter(payload []byte, hybrid bool) (int, error) {
	flag := "0"
	if hybrid {
		flag = "1"
	}
	cmd := exec.Command("/app/bin/wkctl", "meter", flag)
	cmd.Stdin = strings.NewReader(string(payload))
	out, err := cmd.Output()
	if err != nil {
		return 0, err
	}
	var n int
	_, err = fmt.Sscanf(strings.TrimSpace(string(out)), "%d", &n)
	return n, err
}
