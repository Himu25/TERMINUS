#!/usr/bin/env bash
set -euo pipefail
export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
cd /app
mkdir -p /app/output
/app/bin/advisor \
  -scenarios /app/fixtures/scenarios \
  -inventory /app/inventory \
  -out /app/output/migration_matrix.json
