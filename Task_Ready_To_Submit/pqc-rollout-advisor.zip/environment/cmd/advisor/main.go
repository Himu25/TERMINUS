package main

import (
	"flag"
	"fmt"
	"os"

	"pqcrollout/internal/driver"
)

func main() {
	scenarios := flag.String("scenarios", "/app/fixtures/scenarios", "scenario bundle dir")
	inventory := flag.String("inventory", "/app/inventory", "inventory root")
	out := flag.String("out", "/app/output/migration_matrix.json", "report path")
	flag.Parse()
	if err := driver.RunMatrix(*scenarios, *inventory, *out); err != nil {
		fmt.Fprintf(os.Stderr, "advisor: %v\n", err)
		os.Exit(1)
	}
}
