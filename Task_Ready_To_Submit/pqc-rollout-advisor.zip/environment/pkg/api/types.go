package api

type Scenario struct {
	Name           string `json:"name"`
	WireMode       string `json:"wire_mode"`
	TokenLimit     int    `json:"token_limit"`
	HsmLocked      bool   `json:"hsm_locked"`
	HybridRequired bool   `json:"hybrid_required"`
	LegacyOnly     bool   `json:"legacy_only"`
	PerfBaseline   int    `json:"perf_baseline"`
	PerfGate       bool   `json:"perf_gate"`
}

type ScenarioRow struct {
	Name            string  `json:"name"`
	FinishReason    string  `json:"finish_reason"`
	InventoryHits   int     `json:"inventory_hits"`
	WireOk          bool    `json:"wire_ok"`
	TokenOk         bool    `json:"token_ok"`
	HsmExcluded     bool    `json:"hsm_excluded"`
	HybridOk        bool    `json:"hybrid_ok"`
	PerfRatio       float64 `json:"perf_ratio"`
	MigrationDigest string  `json:"migration_digest_hex"`
}

type MatrixReport struct {
	Scenarios []ScenarioRow `json:"scenarios"`
}
