#!/usr/bin/env bash
set -euo pipefail
export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
test -x /app/bin/advisor
test -x /app/bin/wkctl
/app/bin/wkctl legacy <<< "probe" | wc -c | grep -q 256
