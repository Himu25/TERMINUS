use crate::{legacy_stamp, next_stamp};

pub fn pack_h(payload: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    out.extend_from_slice(&legacy_stamp(payload));
    out.extend_from_slice(&next_stamp(payload));
    out
}
