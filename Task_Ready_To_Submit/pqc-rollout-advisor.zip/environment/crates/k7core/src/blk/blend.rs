use crate::next_stamp;

pub fn blend_v(payload: &[u8], wire_mode: &str) -> Vec<u8> {
    let raw = next_stamp(payload);
    if wire_mode == "fixed256" {
        return raw;
    }
    raw
}
