use crate::legacy_stamp;

pub fn merge_v(payload: &[u8], _mode: &str) -> Vec<u8> {
    legacy_stamp(payload).to_vec()
}
