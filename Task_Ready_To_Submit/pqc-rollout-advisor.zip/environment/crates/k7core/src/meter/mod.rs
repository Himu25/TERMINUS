pub fn op_count(payload: &[u8], hybrid: bool) -> u32 {
    let tag = if payload.is_empty() {
        0
    } else {
        payload[0] as u32
    };
    let mut acc = 100 + (tag % 17);
    if hybrid {
        acc = acc.wrapping_add(120);
    }
    acc
}
