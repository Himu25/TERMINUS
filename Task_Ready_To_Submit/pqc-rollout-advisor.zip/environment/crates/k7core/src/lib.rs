pub mod blk;
pub mod meter;

use sha2::{Digest, Sha256};

pub fn legacy_stamp(payload: &[u8]) -> [u8; 256] {
    let mut out = [0u8; 256];
    let digest = Sha256::digest(payload);
    out[..32].copy_from_slice(&digest);
    out[32..64].copy_from_slice(b"LEGACY-RSA-CLASS-STAMP-V1-------");
    for i in 64..256 {
        out[i] = digest[i % 32];
    }
    out
}

pub fn next_stamp(payload: &[u8]) -> Vec<u8> {
    let digest = Sha256::digest(payload);
    let tail = Sha256::digest(&digest);
    let mut out = Vec::with_capacity(712);
    out.extend_from_slice(b"NEXT-VAR-LEN-STAMP");
    out.extend_from_slice(&digest);
    out.extend_from_slice(&tail);
    while out.len() < 690 {
        out.push((out.len() % 251) as u8);
    }
    out
}

pub fn matrix_digest(rows: &[String]) -> String {
    let joined = rows.join("|");
    hex::encode(Sha256::digest(joined.as_bytes()))
}
