use k7core::blk::{blend_v, pack_h};
use k7core::legacy_stamp;
use k7core::meter::op_count;
use std::env;
use std::io::{self, Read};

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() < 2 {
        eprintln!("usage: wkctl <blend|pack|legacy|meter> ...");
        std::process::exit(2);
    }
    let cmd = args[1].as_str();
    match cmd {
        "blend" => {
            let mode = args.get(2).map(String::as_str).unwrap_or("free");
            let payload = read_stdin();
            let out = blend_v(&payload, mode);
            io::Write::write_all(&mut std::io::stdout(), &out).unwrap();
        }
        "pack" => {
            let payload = read_stdin();
            let out = pack_h(&payload);
            io::Write::write_all(&mut std::io::stdout(), &out).unwrap();
        }
        "legacy" => {
            let payload = read_stdin();
            let out = legacy_stamp(&payload);
            io::Write::write_all(&mut std::io::stdout(), &out).unwrap();
        }
        "meter" => {
            let hybrid = args.get(2).map(|s| s == "1").unwrap_or(false);
            let payload = read_stdin();
            let n = op_count(&payload, hybrid);
            println!("{n}");
        }
        _ => {
            eprintln!("unknown command");
            std::process::exit(2);
        }
    }
}

fn read_stdin() -> Vec<u8> {
    let mut buf = Vec::new();
    io::stdin().read_to_end(&mut buf).unwrap();
    buf
}
