package coord

import "pragidx.lab/lane"

func LxPick(lanes []lane.Lane, dead []int) []lane.Lane {
	deadSet := make(map[int]struct{}, len(dead))
	for _, d := range dead {
		deadSet[d] = struct{}{}
	}
	out := make([]lane.Lane, 0, len(lanes))
	for _, ln := range lanes {
		if _, off := deadSet[ln.ShardID]; off {
			continue
		}
		out = append(out, ln)
	}
	return out
}
