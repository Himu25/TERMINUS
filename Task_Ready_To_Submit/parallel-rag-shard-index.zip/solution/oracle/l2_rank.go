package lane

import (
	"sort"

	"pragidx.lab/codec"
	"pragidx.lab/embed"
	"pragidx.lab/pkg/types"
)

func scorePair(query []float64, row codec.Row) float64 {
	vec := row.Open()
	return embed.Dot(query, vec)
}

func PxScan(query []float64, lane Lane, topK int) []types.PartialHit {
	type scored struct {
		id    string
		score float64
	}
	pairs := make([]scored, 0, len(lane.Rows))
	for _, row := range lane.Rows {
		pairs = append(pairs, scored{id: row.ID, score: scorePair(query, row)})
	}
	sort.Slice(pairs, func(i, j int) bool {
		if pairs[i].score == pairs[j].score {
			return pairs[i].id < pairs[j].id
		}
		return pairs[i].score > pairs[j].score
	})
	if topK <= 0 || topK > len(pairs) {
		topK = len(pairs)
	}
	out := make([]types.PartialHit, 0, topK)
	for i := 0; i < topK; i++ {
		out = append(out, types.PartialHit{
			DocID: pairs[i].id,
			Score: pairs[i].score,
			Shard: lane.ShardID,
		})
	}
	return out
}

func KxSpan(lane Lane, dim int) int {
	return len(lane.Rows) * dim
}
