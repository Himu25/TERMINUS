use serde::{Deserialize, Serialize};
use std::cmp::Ordering;
use std::collections::HashMap;
use std::io::{self, Read, Write};

#[derive(Debug, Clone, Serialize, Deserialize)]
struct PartialHit {
    doc_id: String,
    score: f64,
}

#[derive(Debug, Deserialize)]
struct FoldInput {
    partials: Vec<Vec<PartialHit>>,
    top_k: usize,
}

#[derive(Debug, Serialize)]
struct FoldOutput {
    merged: Vec<PartialHit>,
    sync_units: i64,
}

fn dedup_fold(input: &FoldInput) -> FoldOutput {
    let mut best: HashMap<String, PartialHit> = HashMap::new();
    for block in &input.partials {
        for hit in block {
            match best.get(&hit.doc_id) {
                Some(cur) if cur.score >= hit.score => {}
                _ => {
                    best.insert(hit.doc_id.clone(), hit.clone());
                }
            }
        }
    }
    let mut merged: Vec<PartialHit> = best.into_values().collect();
    merged.sort_by(|a, b| {
        match b.score.partial_cmp(&a.score) {
            Some(Ordering::Equal) | None => a.doc_id.cmp(&b.doc_id),
            Some(other) => other,
        }
    });
    let top_k = if input.top_k == 0 || input.top_k > merged.len() {
        merged.len()
    } else {
        input.top_k
    };
    merged.truncate(top_k);
    let sync_units = if input.partials.is_empty() {
        0
    } else {
        (input.top_k as i64) * ((input.partials.len() as i64) + 1)
    };
    FoldOutput { merged, sync_units }
}

fn main() {
    let mut raw = String::new();
    io::stdin().read_to_string(&mut raw).expect("read stdin");
    let input: FoldInput = serde_json::from_str(&raw).expect("parse fold input");
    let out = dedup_fold(&input);
    let encoded = serde_json::to_string(&out).expect("encode fold output");
    io::stdout().write_all(encoded.as_bytes()).expect("write stdout");
}
