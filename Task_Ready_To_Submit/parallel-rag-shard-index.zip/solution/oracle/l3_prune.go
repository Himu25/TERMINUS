package lane

import "pragidx.lab/pkg/types"

func TxPrune(partials [][]types.PartialHit, topK int) [][]types.PartialHit {
	return partials
}
