#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight: parallel RAG shard index workspace"
require_file /app/go.mod
require_file /app/config/index.toml
require_file /app/config/stopwords.txt
require_file /app/data/corpus_default.json
require_file /app/data/build_specs.jsonl
require_file /app/x7fold/Cargo.toml
mkdir -p /app/bin /app/output

log "survey: guardrails and subsystem layout"
grep -nE 'recall|worker_units|failover|billing|stopword|shard' \
  /app/config/index.toml /app/metrics/guardrails.txt /app/policies/index_policy.txt 2>/dev/null | head -n 20 || true
wc -l /app/coord/c1_fan.go /app/lane/l2_rank.go /app/x7fold/src/main.rs /app/node/n9_cost.go /app/codec/c0_pack.go

log "restore little-endian packed row decode and row signatures"
cp "${ROOT_DIR}/oracle/c0_pack.go" /app/codec/c0_pack.go

log "restore stable document-to-shard routing"
cp "${ROOT_DIR}/oracle/s1_store.go" /app/lane/s1_store.go

log "install multi-shard fan-out picker"
cp "${ROOT_DIR}/oracle/c1_fan.go" /app/coord/c1_fan.go

log "install per-shard partial ranker"
cp "${ROOT_DIR}/oracle/l2_rank.go" /app/lane/l2_rank.go

log "restore full partial lists before global merge"
cp "${ROOT_DIR}/oracle/l3_prune.go" /app/lane/l3_prune.go

log "install global merge stage (Go fallback path)"
cp "${ROOT_DIR}/oracle/c2_mux.go" /app/coord/c2_mux.go

log "install synthetic probe unit tally"
cp "${ROOT_DIR}/oracle/n9_cost.go" /app/node/n9_cost.go

log "enable partial posting checksum gate before merge"
cp "${ROOT_DIR}/oracle/w4_integr.go" /app/lane/w4_integr.go

log "install worker load-balance scoring"
cp "${ROOT_DIR}/oracle/s5_even.go" /app/coord/s5_even.go

log "install Rust shard fold with dedup and descending merge"
cp "${ROOT_DIR}/oracle/x7_fold.rs" /app/x7fold/src/main.rs

log "align gold regeneration with bench query preparation"
sed -i 's/embed\.VecFromText(spec\.Query, cfg\.VectorDim)/embed.VecFromText(embed.QxPrep(spec.Query), cfg.VectorDim)/' /app/cmd/refgen/main.go

log "rebuild Go and Rust index binaries"
bash /app/tools/build_all

log "regenerate query gold ids with repaired distributed search path"
/app/bin/refgen /app/data/corpus_default.json /app/data/build_specs.jsonl /app/data/builds_default.jsonl

log "run default index bench report"
chmod +x /app/tools/run_bench
/app/tools/run_bench /app/data/builds_default.jsonl /app/output/index_bench.json

log "post-run validation against index.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/index.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k.endswith("_floor") or k.startswith("billing_"):
        cfg[k] = float(v)
    elif k.startswith("max_"):
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/index_bench.json").read_text())
assert report["status"] == "ok", report
assert report["mean_cosine_fidelity"] >= cfg["fidelity_floor"]
assert report["mean_balance_score"] >= cfg["balance_floor"]
assert report["mean_reject_rate"] <= cfg["max_mean_reject_rate"]
assert report["p95_batch_units"] <= cfg["max_p95_batch_units"]
bill = next(q for q in report["batches"] if q["batch_id"] == "b_billing_refund")
assert bill["intact_chunks"] >= int(cfg["billing_pack_min_intact"])
assert bill["cosine_fidelity"] >= cfg["billing_pack_min_fidelity"]
fail = [q for q in report["batches"] if q["batch_id"].startswith("b_failover")]
for row in fail:
    assert row["cosine_fidelity"] >= cfg["failover_fidelity_floor"], row
print("ok", report["mean_cosine_fidelity"], report["p95_batch_units"], len(fail))
PY

log "oracle complete"
