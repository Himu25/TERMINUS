package bench

import (
	"pragidx.lab/lane"
	"pragidx.lab/node"
)

func ProbeUnits(lanes []lane.Lane, dim int, dead []int) int {
	return node.NxTally(lanes, dim, dead)
}
