package bench

// FoldTopK delegates global partial-index merge to the Rust x7_fold helper.
