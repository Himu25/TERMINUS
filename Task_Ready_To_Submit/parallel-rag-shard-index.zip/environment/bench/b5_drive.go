package bench

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"

	"pragidx.lab/codec"
	"pragidx.lab/coord"
	"pragidx.lab/corpus"
	"pragidx.lab/embed"
	"pragidx.lab/lane"
	"pragidx.lab/pkg/types"
)

func LoadCfg(path string) (types.ClusterCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.ClusterCfg{}, err
	}
	cfg := types.ClusterCfg{CorpusPath: corpus.DefaultCorpusPath}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "vector_dim":
			fmt.Sscanf(val, "%d", &cfg.VectorDim)
		case "worker_count":
			fmt.Sscanf(val, "%d", &cfg.WorkerCount)
		case "top_k":
			fmt.Sscanf(val, "%d", &cfg.TopK)
		case "fidelity_floor":
			fmt.Sscanf(val, "%f", &cfg.RecallFloor)
		case "compress_ratio_floor":
			fmt.Sscanf(val, "%f", &cfg.NdcgFloor)
		case "max_mean_worker_units":
			fmt.Sscanf(val, "%d", &cfg.MaxMeanWorkerUnits)
		case "max_mean_sync_units":
			fmt.Sscanf(val, "%d", &cfg.MaxMeanSyncUnits)
		case "max_p95_batch_units":
			fmt.Sscanf(val, "%d", &cfg.MaxP95BatchUnits)
		case "failover_fidelity_floor":
			fmt.Sscanf(val, "%f", &cfg.FailoverRecallFloor)
		case "tight_pack_fidelity_floor":
			fmt.Sscanf(val, "%f", &cfg.TightSecurityRecall)
		case "balance_floor":
			fmt.Sscanf(val, "%f", &cfg.BalanceFloor)
		case "max_mean_reject_rate":
			fmt.Sscanf(val, "%f", &cfg.MaxMeanRejectRate)
		case "corpus_path":
			cfg.CorpusPath = val
		}
	}
	return cfg, nil
}

func LoadBatches(path string) ([]types.BatchCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.BatchCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var qc types.BatchCase
		if err := json.Unmarshal([]byte(line), &qc); err != nil {
			return nil, err
		}
		out = append(out, qc)
	}
	return out, sc.Err()
}

func BuildLanes(docs []types.Doc, cfg types.ClusterCfg) []lane.Lane {
	lanes := lane.MkLanes(cfg.WorkerCount)
	for _, doc := range docs {
		vec := embed.VecFromText(doc.Text, cfg.VectorDim)
		sid := lane.ShMap(doc.ID, cfg.WorkerCount)
		lanes[sid].Rows = append(lanes[sid].Rows, codec.VkStore(doc.ID, vec))
	}
	return lanes
}

func Run(cfg types.ClusterCfg, cases []types.BatchCase) (types.BenchReport, error) {
	if override := os.Getenv("TB_CORPUS_PATH"); override != "" {
		cfg.CorpusPath = override
	}
	docs, err := corpus.Load(cfg.CorpusPath)
	if err != nil {
		return types.BenchReport{}, err
	}
	lanes := BuildLanes(docs, cfg)
	report := types.BenchReport{
		Status:        "ok",
		CorpusVectors: len(docs),
		VectorDim:     cfg.VectorDim,
		WorkerCount:    cfg.WorkerCount,
		BatchesTotal:  len(cases),
	}
	var sumRecall, sumNdcg, sumShard, sumMerge, sumBalance, sumReject float64
	queryUnits := make([]int, 0, len(cases))
	report.Batches = make([]types.BatchRow, 0, len(cases))
	for _, qc := range cases {
		qv := embed.VecFromText(embed.QxPrep(qc.Query), cfg.VectorDim)
		partials := FanoutPartials(qv, lanes, qc.DeadWorkers, cfg.TopK)
		partials, rejects := lane.WxGate(partials, lanes)
		merged, mergeU := FoldTopK(partials, cfg.TopK)
		shardU := ProbeUnits(lanes, cfg.VectorDim, qc.DeadWorkers)
		queryU := shardU + mergeU
		topIDs := make([]string, 0, len(merged))
		for _, hit := range merged {
			topIDs = append(topIDs, hit.DocID)
		}
		recall, ndcg, hits := rankScores(qc.GoldIDs, topIDs, cfg.TopK)
		perWorker := PerWorkerUnits(partials, lanes, cfg.VectorDim, qc.DeadWorkers)
		balance := coord.BxScore(perWorker)
		rejectRate := 0.0
		if len(partials) > 0 {
			rejectRate = float64(rejects) / float64(rejects+countHits(partials))
		}
		row := types.BatchRow{
			BatchID:        qc.BatchID,
			CosineFidelity: round4(recall),
			CompressRatio:  round4(ndcg),
			IntactChunks:   hits,
			WorkerUnits:    shardU,
			SyncUnits:      mergeU,
			BatchUnits:     queryU,
			WorkersActive:  len(partials),
			RejectsBad:     rejects,
			BalanceScore:   balance,
			ChunkIDs:       topIDs,
		}
		report.Batches = append(report.Batches, row)
		sumRecall += recall
		sumNdcg += ndcg
		sumShard += float64(shardU)
		sumMerge += float64(mergeU)
		sumBalance += balance
		sumReject += rejectRate
		queryUnits = append(queryUnits, queryU)
	}
	n := float64(len(cases))
	if n > 0 {
		report.MeanCosineFidelity = round4(sumRecall / n)
		report.MeanCompressRatio = round4(sumNdcg / n)
		report.MeanWorkerUnits = round4(sumShard / n)
		report.MeanSyncUnits = round4(sumMerge / n)
		report.MeanBalanceScore = round4(sumBalance / n)
		report.MeanRejectRate = round4(sumReject / n)
	}
	report.P95BatchUnits = p95(queryUnits)
	if !meetsFloors(cfg, report) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func meetsFloors(cfg types.ClusterCfg, report types.BenchReport) bool {
	if report.MeanCosineFidelity < cfg.RecallFloor {
		return false
	}
	if report.MeanCompressRatio < cfg.NdcgFloor {
		return false
	}
	if int(report.MeanWorkerUnits) > cfg.MaxMeanWorkerUnits {
		return false
	}
	if int(report.MeanSyncUnits) > cfg.MaxMeanSyncUnits {
		return false
	}
	if report.P95BatchUnits > cfg.MaxP95BatchUnits {
		return false
	}
	if report.MeanBalanceScore < cfg.BalanceFloor {
		return false
	}
	if report.MeanRejectRate > cfg.MaxMeanRejectRate {
		return false
	}
	return true
}

func countHits(partials [][]types.PartialHit) int {
	n := 0
	for _, block := range partials {
		n += len(block)
	}
	return n
}

func rankScores(gold, got []string, k int) (recall float64, ndcg float64, hits int) {
	if len(gold) == 0 {
		return 0, 0, 0
	}
	goldSet := make(map[string]struct{}, len(gold))
	for _, id := range gold {
		goldSet[id] = struct{}{}
	}
	if k <= 0 {
		k = len(got)
	}
	if k > len(got) {
		k = len(got)
	}
	rel := make([]float64, 0, k)
	for i := 0; i < k; i++ {
		if _, ok := goldSet[got[i]]; ok {
			hits++
			rel = append(rel, 1.0)
		} else {
			rel = append(rel, 0.0)
		}
	}
	recall = float64(hits) / float64(len(gold))
	var dcg, idcg float64
	for i, r := range rel {
		if r > 0 {
			dcg += r / math.Log2(float64(i+2))
		}
	}
	sort.Strings(gold)
	ideal := make([]float64, 0, len(gold))
	for i := 0; i < len(gold) && i < k; i++ {
		ideal = append(ideal, 1.0)
	}
	for i, r := range ideal {
		if r > 0 {
			idcg += r / math.Log2(float64(i+2))
		}
	}
	if idcg > 0 {
		ndcg = dcg / idcg
	}
	return recall, ndcg, hits
}

func p95(values []int) int {
	if len(values) == 0 {
		return 0
	}
	cp := append([]int(nil), values...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

type digestPayload struct {
	Status         string           `json:"status"`
	CorpusVectors  int              `json:"corpus_vectors"`
	VectorDim      int              `json:"vector_dim"`
	WorkerCount     int              `json:"worker_count"`
	BatchesTotal   int              `json:"batches_total"`
	MeanCosineFidelity float64          `json:"mean_cosine_fidelity"`
	MeanCompressRatio   float64          `json:"mean_compress_ratio"`
	MeanWorkerUnits float64          `json:"mean_worker_units"`
	MeanSyncUnits float64          `json:"mean_sync_units"`
	P95BatchUnits     int              `json:"p95_batch_units"`
	MeanBalanceScore  float64          `json:"mean_balance_score"`
	MeanRejectRate    float64          `json:"mean_reject_rate"`
	ReportDigest      string           `json:"report_digest"`
	Batches           []types.BatchRow `json:"batches"`
}

func digestBody(report types.BenchReport) string {
	payload := digestPayload{
		Status:         report.Status,
		CorpusVectors:  report.CorpusVectors,
		VectorDim:      report.VectorDim,
		WorkerCount:     report.WorkerCount,
		BatchesTotal:   report.BatchesTotal,
		MeanCosineFidelity: report.MeanCosineFidelity,
		MeanCompressRatio:   report.MeanCompressRatio,
		MeanWorkerUnits: report.MeanWorkerUnits,
		MeanSyncUnits: report.MeanSyncUnits,
		P95BatchUnits:     report.P95BatchUnits,
		MeanBalanceScore:  report.MeanBalanceScore,
		MeanRejectRate:    report.MeanRejectRate,
		ReportDigest:      "",
		Batches:           report.Batches,
	}
	raw, err := marshalDigestJSON(payload)
	if err != nil {
		return ""
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func marshalDigestJSON(payload digestPayload) ([]byte, error) {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return nil, err
	}
	b := buf.Bytes()
	if n := len(b); n > 0 && b[n-1] == '\n' {
		b = b[:n-1]
	}
	return b, nil
}

func WriteReport(path string, report types.BenchReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}
