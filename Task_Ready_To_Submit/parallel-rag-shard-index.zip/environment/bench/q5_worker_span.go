package bench

import (
	"pragidx.lab/lane"
	"pragidx.lab/pkg/types"
)

func PerWorkerUnits(partials [][]types.PartialHit, lanes []lane.Lane, dim int, dead []int) []int {
	deadSet := make(map[int]struct{}, len(dead))
	for _, d := range dead {
		deadSet[d] = struct{}{}
	}
	units := make([]int, len(lanes))
	for i, ln := range lanes {
		if _, off := deadSet[ln.ShardID]; off {
			continue
		}
		units[i] = lane.KxSpan(ln, dim)
	}
	for _, block := range partials {
		for _, hit := range block {
			if hit.Shard >= 0 && hit.Shard < len(units) {
				units[hit.Shard] += dim
			}
		}
	}
	return units
}
