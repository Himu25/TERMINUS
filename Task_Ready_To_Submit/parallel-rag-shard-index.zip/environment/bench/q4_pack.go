package bench

import (
	"pragidx.lab/lane"
	"pragidx.lab/pkg/types"
)

func PackRatio(partials [][]types.PartialHit, lanes []lane.Lane, dim int) float64 {
	if dim <= 0 {
		dim = 32
	}
	lookup := make(map[string]int)
	for _, ln := range lanes {
		for _, row := range ln.Rows {
			lookup[row.ID] = len(row.Raw) + len(row.ID)
		}
	}
	packed, full := 0, 0
	seen := make(map[string]struct{})
	for _, block := range partials {
		for _, hit := range block {
			if _, ok := seen[hit.DocID]; ok {
				continue
			}
			seen[hit.DocID] = struct{}{}
			if span, ok := lookup[hit.DocID]; ok {
				packed += span
			}
			full += dim * 8
		}
	}
	if full == 0 {
		return 0
	}
	return float64(packed) / float64(full)
}
