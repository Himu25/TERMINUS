package bench

import (
	"bytes"
	"encoding/json"
	"os/exec"

	"pragidx.lab/pkg/types"
)

type rustFoldInput struct {
	Partials [][]rustPartial `json:"partials"`
	TopK     int             `json:"top_k"`
}

type rustPartial struct {
	DocID string  `json:"doc_id"`
	Score float64 `json:"score"`
}

type rustFoldOutput struct {
	Merged    []rustPartial `json:"merged"`
	SyncUnits int64         `json:"sync_units"`
}

func FoldTopK(partials [][]types.PartialHit, topK int) ([]types.PartialHit, int) {
	payload := rustFoldInput{TopK: topK, Partials: make([][]rustPartial, 0, len(partials))}
	for _, block := range partials {
		chunk := make([]rustPartial, 0, len(block))
		for _, hit := range block {
			chunk = append(chunk, rustPartial{DocID: hit.DocID, Score: hit.Score})
		}
		payload.Partials = append(payload.Partials, chunk)
	}
	raw, err := json.Marshal(payload)
	if err != nil {
		return nil, 0
	}
	cmd := exec.Command("/app/bin/x7_fold")
	cmd.Stdin = bytes.NewReader(raw)
	var stdout bytes.Buffer
	cmd.Stdout = &stdout
	if err := cmd.Run(); err != nil {
		return nil, 0
	}
	var out rustFoldOutput
	if err := json.Unmarshal(stdout.Bytes(), &out); err != nil {
		return nil, 0
	}
	merged := make([]types.PartialHit, 0, len(out.Merged))
	for _, hit := range out.Merged {
		merged = append(merged, types.PartialHit{DocID: hit.DocID, Score: hit.Score})
	}
	return merged, int(out.SyncUnits)
}
