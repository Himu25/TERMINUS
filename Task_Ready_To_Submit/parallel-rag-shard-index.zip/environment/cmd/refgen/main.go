package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"sort"

	"pragidx.lab/bench"
	"pragidx.lab/corpus"
	"pragidx.lab/embed"
	"pragidx.lab/pkg/types"
	"pragidx.lab/lane"
)

func main() {
	if len(os.Args) < 4 {
		fmt.Fprintln(os.Stderr, "usage: refgen <corpus.json> <specs.jsonl> <out.jsonl>")
		os.Exit(2)
	}
	cfg, err := bench.LoadCfg("/app/config/index.toml")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	docs, err := corpus.Load(os.Args[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	type scored struct {
		id    string
		score float64
	}
	specs, err := os.Open(os.Args[2])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer specs.Close()
	out, err := os.Create(os.Args[3])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer out.Close()
	w := bufio.NewWriter(out)
	defer w.Flush()
	sc := bufio.NewScanner(specs)
	for sc.Scan() {
		line := sc.Text()
		if line == "" {
			continue
		}
		var spec struct {
			BatchID    string `json:"batch_id"`
			Query      string `json:"query"`
			DeadWorkers []int  `json:"dead_workers"`
		}
		if err := json.Unmarshal([]byte(line), &spec); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		qv := embed.VecFromText(spec.Query, cfg.VectorDim)
		dead := make(map[int]struct{}, len(spec.DeadWorkers))
		for _, d := range spec.DeadWorkers {
			dead[d] = struct{}{}
		}
		pairs := make([]scored, 0, len(docs))
		for _, doc := range docs {
			sid := lane.ShMap(doc.ID, cfg.WorkerCount)
			if _, off := dead[sid]; off {
				continue
			}
			vec := embed.VecFromText(doc.Text, cfg.VectorDim)
			pairs = append(pairs, scored{id: doc.ID, score: embed.Dot(qv, vec)})
		}
		sort.Slice(pairs, func(i, j int) bool {
			return pairs[i].score > pairs[j].score
		})
		k := cfg.TopK
		if k > len(pairs) {
			k = len(pairs)
		}
		gold := make([]string, 0, k)
		for i := 0; i < k; i++ {
			gold = append(gold, pairs[i].id)
		}
		row := types.BatchCase{
			BatchID:    spec.BatchID,
			Query:      spec.Query,
			GoldIDs:    gold,
			DeadWorkers: spec.DeadWorkers,
		}
		raw, _ := json.Marshal(row)
		w.Write(raw)
		w.WriteByte('\n')
	}
	if err := sc.Err(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
