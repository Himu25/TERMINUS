package lane

import "pragidx.lab/pkg/types"

func PxShadow(_ []float64, ln Lane, topK int) []types.PartialHit {
	out := make([]types.PartialHit, 0, topK)
	for i, row := range ln.Rows {
		if i >= topK {
			break
		}
		out = append(out, types.PartialHit{DocID: row.ID, Score: float64(i), Shard: ln.ShardID})
	}
	return out
}
