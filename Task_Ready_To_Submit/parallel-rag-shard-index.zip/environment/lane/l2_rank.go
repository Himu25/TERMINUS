package lane

import (
	"sort"

	"pragidx.lab/embed"
	"pragidx.lab/pkg/types"
)

func PxScan(query []float64, lane Lane, topK int) []types.PartialHit {
	type scored struct {
		id    string
		score float64
	}
	pairs := make([]scored, 0, len(lane.Rows))
	half := len(query) / 2
	if half <= 0 {
		half = len(query)
	}
	qSlice := query[:half]
	for _, row := range lane.Rows {
		vec := row.Open()
		if len(vec) > half {
			vec = vec[:half]
		}
		pairs = append(pairs, scored{id: row.ID, score: embed.Dot(qSlice, vec)})
	}
	sort.Slice(pairs, func(i, j int) bool {
		return pairs[i].score < pairs[j].score
	})
	if topK <= 0 || topK > len(pairs) {
		topK = len(pairs)
	}
	out := make([]types.PartialHit, 0, topK)
	for i := 0; i < topK; i++ {
		out = append(out, types.PartialHit{
			DocID: pairs[i].id,
			Score: pairs[i].score,
			Shard: lane.ShardID,
		})
	}
	return out
}

func KxSpan(lane Lane, dim int) int {
	return len(lane.Rows) * dim
}
