package lane

import "pragidx.lab/pkg/types"

func WxShadow(partials [][]types.PartialHit, _ []Lane) [][]types.PartialHit {
	return partials
}
