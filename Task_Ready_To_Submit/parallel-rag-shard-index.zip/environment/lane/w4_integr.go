package lane

import "pragidx.lab/pkg/types"

func WxGate(partials [][]types.PartialHit, _ []Lane) ([][]types.PartialHit, int) {
	return partials, 0
}
