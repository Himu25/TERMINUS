package coord

import (
	"sort"

	"pragidx.lab/lane"
	"pragidx.lab/pkg/types"
)

func MxFold(partials [][]types.PartialHit, topK int) []types.PartialHit {
	flat := make([]types.PartialHit, 0)
	for _, block := range partials {
		flat = append(flat, block...)
	}
	sort.Slice(flat, func(i, j int) bool {
		return flat[i].Score < flat[j].Score
	})
	if topK <= 0 || topK > len(flat) {
		topK = len(flat)
	}
	return flat[:topK]
}

func R4Weight(partials [][]types.PartialHit, topK int) int {
	n := 0
	for _, block := range partials {
		n += len(block)
	}
	return n * topK
}

func JxFold(partials [][]types.PartialHit, topK int) ([]types.PartialHit, int) {
	weight := R4Weight(partials, topK)
	pruned := lane.TxPrune(partials, topK)
	merged := MxFold(pruned, topK)
	return merged, weight
}
