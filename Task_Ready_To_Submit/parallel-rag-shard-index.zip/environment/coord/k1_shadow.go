package coord

import "pragidx.lab/lane"

func LxShadow(lanes []lane.Lane, dead []int) []lane.Lane {
	if len(lanes) == 0 {
		return nil
	}
	return lanes[:1]
}
