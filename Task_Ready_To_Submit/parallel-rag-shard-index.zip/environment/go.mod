module pragidx.lab

go 1.22
