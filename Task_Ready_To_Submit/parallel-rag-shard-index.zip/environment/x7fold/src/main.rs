use serde::{Deserialize, Serialize};
use std::cmp::Ordering;
use std::io::{self, Read, Write};

#[derive(Debug, Clone, Serialize, Deserialize)]
struct PartialHit {
    doc_id: String,
    score: f64,
}

#[derive(Debug, Deserialize)]
struct FoldInput {
    partials: Vec<Vec<PartialHit>>,
    top_k: usize,
}

#[derive(Debug, Serialize)]
struct FoldOutput {
    merged: Vec<PartialHit>,
    sync_units: i64,
}

fn broken_fold(input: &FoldInput) -> FoldOutput {
    let mut flat: Vec<PartialHit> = Vec::new();
    for block in &input.partials {
        flat.extend(block.clone());
    }
    flat.sort_by(|a, b| {
        a.score
            .partial_cmp(&b.score)
            .unwrap_or(Ordering::Equal)
    });
    let top_k = if input.top_k == 0 || input.top_k > flat.len() {
        flat.len()
    } else {
        input.top_k
    };
    let merged = flat.into_iter().take(top_k).collect::<Vec<_>>();
    let sync_units = (merged.len() as i64) * (input.top_k as i64);
    FoldOutput { merged, sync_units }
}

fn main() {
    let mut raw = String::new();
    io::stdin().read_to_string(&mut raw).expect("read stdin");
    let input: FoldInput = serde_json::from_str(&raw).expect("parse fold input");
    let out = broken_fold(&input);
    let encoded = serde_json::to_string(&out).expect("encode fold output");
    io::stdout().write_all(encoded.as_bytes()).expect("write stdout");
}
