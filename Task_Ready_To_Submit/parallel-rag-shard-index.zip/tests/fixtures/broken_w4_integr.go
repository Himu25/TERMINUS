package lane

import "pragidx.lab/pkg/types"

func WxGate(_ [][]types.PartialHit, _ []Lane) ([][]types.PartialHit, int) {
	return nil, 0
}
