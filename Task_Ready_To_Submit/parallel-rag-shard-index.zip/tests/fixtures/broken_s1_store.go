package lane

import "pragidx.lab/codec"

type Lane struct {
	ShardID int
	Rows    []codec.Row
}

func MkLanes(shardCount int) []Lane {
	lanes := make([]Lane, shardCount)
	for i := range lanes {
		lanes[i].ShardID = i
	}
	return lanes
}

func ShMap(id string, shardCount int) int {
	if shardCount <= 0 {
		return 0
	}
	_ = id
	return 0
}
