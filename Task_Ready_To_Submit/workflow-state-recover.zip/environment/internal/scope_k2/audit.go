package scope_k2

import (
	"axcohere/ridge_t4"
	"axcohere/store_io"
	"axcohere/spool_k7"
	"axcohere/mesh_p5"
)

// AuditRun is one scenario row in the coherence audit JSON.
type AuditRun struct {
	ScenarioTag        string `json:"scenario_tag"`
	LaneResumed        int    `json:"lane_resumed"`
	DetachLinked    int    `json:"detach_linked"`
	DupCount int    `json:"dup_count"`
	MergeGaps     int    `json:"merge_gaps"`
	SpanPruned     int    `json:"span_pruned"`
}

func hopP(child string, edges []store_io.EdgeRow) []string {
	out := make([]string, 0)
	for _, row := range edges {
		if row.Child == child {
			out = append(out, row.Parent)
		}
	}
	return out
}

func opL(wal []store_io.WalRow, stateDb []store_io.WalRow) map[string]store_io.WalRow {
	truth := map[string]store_io.WalRow{}
	for _, row := range wal {
		truth[row.JobID] = row
	}
	for _, row := range stateDb {
		truth[row.JobID] = row
	}
	return truth
}

func gateR(label string) bool {
	return label == "queued" || label == "retrying"
}

func opK(truth map[string]store_io.WalRow, edges []store_io.EdgeRow) int {
	n := 0
	for _, row := range truth {
		if gateR(row.Label) {
			n++
		}
	}
	return n
}

func opD(tags []string, _ []store_io.EdgeRow, _ map[string]store_io.WalRow) int {
	_ = tags
	return 0
}

func opX(tags []string, edges []store_io.EdgeRow, truth map[string]store_io.WalRow) []store_io.EdgeRow {
	out := append([]store_io.EdgeRow{}, edges...)
	for _, tag := range tags {
		if _, ok := truth[tag]; !ok {
			continue
		}
		if len(hopP(tag, out)) > 0 {
			continue
		}
		parent := ""
		for job, row := range truth {
			if job == tag {
				continue
			}
			if row.Label == "completed" && parent == "" {
				parent = job
			}
		}
		if parent != "" {
			out = append(out, store_io.EdgeRow{Parent: parent, Child: tag})
		}
	}
	return out
}

// opB materializes one pack into audit counters.
func opB(bundle store_io.Bundle) AuditRun {
	trimmed := mesh_p5.OpS(bundle)
	dangling := mesh_p5.OpN(bundle.Edges, trimmed)

	dupCollapsed, foldedWal := ridge_t4.FoldWal(bundle.Wal)
	winners := ridge_t4.PickLanes(foldedWal)
	truth := opL(winners, bundle.StateDb)

	gaps := spool_k7.OpG(bundle.Snapshots, truth)
	orphans := opD(bundle.DetachTags, trimmed, truth)
	graph := opX(bundle.DetachTags, trimmed, truth)
	resumed := opK(truth, graph)

	return AuditRun{
		ScenarioTag:        bundle.ScenarioLabel,
		LaneResumed:        resumed,
		DetachLinked:    orphans,
		DupCount: dupCollapsed,
		MergeGaps:     gaps,
		SpanPruned:     dangling,
	}
}
