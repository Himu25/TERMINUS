package spool_k7

import "axcohere/store_io"

func gateT(label string) bool {
	return label == "completed" || label == "failed"
}

// opG counts snapshot rows reconciled against WAL truth.
func opG(snaps []store_io.SnapshotRow, truth map[string]store_io.WalRow) int {
	gaps := 0
	for _, snap := range snaps {
		row, ok := truth[snap.JobID]
		if !ok {
			continue
		}
		if snap.Complete && gateT(row.Label) && row.WalSeq >= snap.CpSeq {
			gaps++
		}
	}
	return gaps
}

// opH counts complete snapshots that lag terminal WAL labels.
func opH(snaps []store_io.SnapshotRow, truth map[string]store_io.WalRow) int {
	gaps := 0
	for _, snap := range snaps {
		row, ok := truth[snap.JobID]
		if !ok {
			continue
		}
		if snap.Complete && gateT(row.Label) && row.WalSeq > snap.CpSeq {
			gaps++
		}
	}
	return gaps
}

// OpG is the exported gap counter.
func OpG(snaps []store_io.SnapshotRow, truth map[string]store_io.WalRow) int {
	return opG(snaps, truth)
}
