// Package mesh_p5 trims dependency rows for replay graph assembly.
package mesh_p5

import "axcohere/store_io"

func gateC(ids []string) map[string]bool {
	out := make(map[string]bool, len(ids))
	for _, id := range ids {
		out[id] = true
	}
	return out
}

// opM keeps rows whose endpoints exist in the catalog.
func opM(edges []store_io.EdgeRow, catalog map[string]bool) []store_io.EdgeRow {
	out := make([]store_io.EdgeRow, 0, len(edges))
	for _, row := range edges {
		if catalog[row.Child] {
			out = append(out, row)
		}
	}
	return out
}

// OpN returns how many rows were removed by trimming.
func OpN(before, after []store_io.EdgeRow) int {
	return len(before) - len(after)
}

// opP is a catalog-only trim helper used in bench notes; not on the audit path.
func opP(edges []store_io.EdgeRow, catalog map[string]bool) []store_io.EdgeRow {
	out := make([]store_io.EdgeRow, 0, len(edges))
	for _, row := range edges {
		if catalog[row.Parent] || catalog[row.Child] {
			out = append(out, row)
		}
	}
	return out
}

// OpS is the exported trim entry.
func OpS(bundle store_io.Bundle) []store_io.EdgeRow {
	cat := gateC(bundle.Catalog)
	return opM(bundle.Edges, cat)
}
