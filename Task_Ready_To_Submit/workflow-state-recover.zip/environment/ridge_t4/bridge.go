package ridge_t4

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libridge_t4.a -ldl -lm
#include "row.h"
#include <stdlib.h>
*/
import "C"

import (
	"axcohere/store_io"
	"unsafe"
)

// FoldWal folds duplicate WAL rows and returns collapsed count plus kept rows.
func FoldWal(rows []store_io.WalRow) (int, []store_io.WalRow) {
	if len(rows) == 0 {
		return 0, nil
	}
	wire := make([]C.WalWire, len(rows))
	for i, row := range rows {
		copyWire(&wire[i], row)
	}
	res := C.rt_fold_rows((*C.WalWire)(unsafe.Pointer(&wire[0])), C.int(len(wire)))
	out := make([]C.WalWire, len(rows))
	n := int(C.rt_materialize(
		(*C.WalWire)(unsafe.Pointer(&wire[0])),
		C.int(len(wire)),
		(*C.WalWire)(unsafe.Pointer(&out[0])),
		C.int(len(out)),
	))
	kept := make([]store_io.WalRow, 0, n)
	for i := 0; i < n; i++ {
		kept = append(kept, readWire(out[i]))
	}
	return int(res.collapsed), kept
}

// PickLanes selects the latest WAL row per job after collapse.
func PickLanes(rows []store_io.WalRow) []store_io.WalRow {
	if len(rows) == 0 {
		return nil
	}
	_, folded := FoldWal(rows)
	if len(folded) == 0 {
		return nil
	}
	wire := make([]C.WalWire, len(rows))
	for i, row := range folded {
		copyWire(&wire[i], row)
	}
	out := make([]C.WalWire, len(wire))
	n := int(C.rt_pick_winners(
		(*C.WalWire)(unsafe.Pointer(&wire[0])),
		C.int(len(rows)),
		(*C.WalWire)(unsafe.Pointer(&out[0])),
		C.int(len(out)),
	))
	winners := make([]store_io.WalRow, 0, n)
	for i := 0; i < n; i++ {
		winners = append(winners, readWire(out[i]))
	}
	return winners
}

func copyWire(dst *C.WalWire, row store_io.WalRow) {
	job := []byte(row.JobID)
	lbl := []byte(row.Label)
	for i := 0; i < len(job) && i < 63; i++ {
		dst.job_id[i] = C.char(job[i])
	}
	for i := 0; i < len(lbl) && i < 31; i++ {
		dst.label[i] = C.char(lbl[i])
	}
	dst.wal_seq = C.int(row.WalSeq)
	dst.epoch = C.int(row.Epoch)
}

func readWire(src C.WalWire) store_io.WalRow {
	job := cBytesToString(src.job_id[:])
	lbl := cBytesToString(src.label[:])
	return store_io.WalRow{
		JobID:  job,
		WalSeq: int(src.wal_seq),
		Epoch:  int(src.epoch),
		Label:  lbl,
	}
}

func cBytesToString(buf []C.char) string {
	out := make([]byte, 0, len(buf))
	for _, b := range buf {
		if b == 0 {
			break
		}
		out = append(out, byte(b))
	}
	return string(out)
}
