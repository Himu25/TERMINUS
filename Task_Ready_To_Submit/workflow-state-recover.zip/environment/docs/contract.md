# Audit contract

`coherence_audit.json` carries `scenario_runs` with `lane_resumed`, `detach_linked`, `dup_count`, `merge_gaps`, and `span_pruned`.
