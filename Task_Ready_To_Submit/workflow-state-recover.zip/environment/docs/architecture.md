# Replay layout

Components: `scope_k2` driver, `mesh_p5` span trim, `spool_k7` snapshot merge, `ridge_t4` WAL fold (Rust), `store_io` bundles.
