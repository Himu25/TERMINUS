"""Verifier for workflow coherence audit emission."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
BIN = APP / "bin" / "cohereplay"
BUILD_SH = APP / "scripts" / "build.sh"
RIDGE = APP / "ridge_t4"
REPORT = APP / "output" / "coherence_audit.json"
GO_CACHE = APP / "output" / "go-build"

BUILD_TIMEOUT_SEC = 600
RUN_TIMEOUT_SEC = 120


def _subproc_env() -> dict[str, str]:
    env = os.environ.copy()
    env["PATH"] = "/usr/local/cargo/bin:/usr/local/go/bin:" + env.get("PATH", "")
    env.setdefault("CGO_ENABLED", "1")
    env.setdefault("GOCACHE", str(GO_CACHE))
    env.setdefault("GOTMPDIR", "/tmp")
    return env


def _is_elf_executable(path: Path) -> bool:
    if not path.is_file() or not os.access(path, os.X_OK):
        return False
    with path.open("rb") as handle:
        header = handle.read(4)
    return len(header) == 4 and header[0] == 0x7F and header[1:4] == b"ELF"


def _scrub_build_artifacts() -> None:
    if BIN.is_file():
        BIN.unlink()
    if (RIDGE / "target").is_dir():
        shutil.rmtree(RIDGE / "target")
    if GO_CACHE.is_dir():
        shutil.rmtree(GO_CACHE)
    GO_CACHE.mkdir(parents=True, exist_ok=True)


def _rebuild_from_clean_source() -> None:
    """Rebuild cohereplay from the current /app sources with no cached artifacts."""
    _scrub_build_artifacts()
    subprocess.run(
        ["bash", "/app/scripts/build.sh"],
        cwd=str(APP),
        check=True,
        timeout=BUILD_TIMEOUT_SEC,
        env=_subproc_env(),
    )
    assert BIN.is_file(), "build.sh must produce /app/bin/cohereplay"
    assert os.access(BIN, os.X_OK), "cohereplay must be executable"
    assert _is_elf_executable(BIN), "cohereplay must be a compiled ELF binary"


@pytest.fixture(scope="session", autouse=True)
def _session_clean_rebuild() -> None:
    _rebuild_from_clean_source()


def _stem_tag(stem: str) -> str:
    bundle = json.loads((APP / "cases" / f"{stem}.json").read_text(encoding="utf-8"))
    return str(bundle["scenario_label"])


def _drive(stem: str) -> dict:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    if REPORT.exists():
        REPORT.unlink()
    subprocess.run(
        ["/app/bin/cohereplay"],
        cwd=str(APP),
        env={**_subproc_env(), "tb_pack": stem},
        check=True,
        timeout=RUN_TIMEOUT_SEC,
    )
    payload = json.loads(REPORT.read_text(encoding="utf-8"))
    assert "scenario_runs" in payload and len(payload["scenario_runs"]) == 1
    row = payload["scenario_runs"][0]
    assert row.get("scenario_tag") == _stem_tag(stem)
    return row


def _assert_row(
    row: dict,
    *,
    lane_resumed: int,
    detach_linked: int,
    dup_count: int,
    merge_gaps: int,
    span_pruned: int,
) -> None:
    assert row["lane_resumed"] == lane_resumed
    assert row["detach_linked"] == detach_linked
    assert row["dup_count"] == dup_count
    assert row["merge_gaps"] == merge_gaps
    assert row["span_pruned"] == span_pruned


def test_build_script_present_and_executable() -> None:
    """Documented build helper must exist for rebuilding cohereplay."""
    assert BUILD_SH.is_file()
    assert os.access(BUILD_SH, os.X_OK)


def test_cohereplay_is_elf_binary() -> None:
    """cohereplay must be an executable ELF binary at the documented path."""
    assert _is_elf_executable(BIN)


def test_cohereplay_matches_fresh_source_build() -> None:
    """Installed cohereplay must match a clean rebuild of the current source tree."""
    installed = BIN.read_bytes()
    _rebuild_from_clean_source()
    fresh = BIN.read_bytes()
    assert installed == fresh


def test_pack_alpha() -> None:
    """Linear chain must not resume past the first blocked queued unit."""
    row = _drive("pack_alpha")
    _assert_row(row, lane_resumed=1, detach_linked=0, dup_count=0, merge_gaps=0, span_pruned=0)


def test_pack_dup() -> None:
    """Duplicate WAL rows must collapse before truth resolution."""
    row = _drive("pack_dup")
    _assert_row(row, lane_resumed=1, detach_linked=0, dup_count=1, merge_gaps=0, span_pruned=0)


def test_pack_gap() -> None:
    """Incomplete snapshots must align when WAL shows a terminal lane."""
    row = _drive("pack_gap")
    _assert_row(row, lane_resumed=0, detach_linked=0, dup_count=0, merge_gaps=1, span_pruned=0)


def test_pack_dangle() -> None:
    """Edges aimed at missing catalog ids must be pruned."""
    row = _drive("pack_dangle")
    _assert_row(row, lane_resumed=1, detach_linked=0, dup_count=0, merge_gaps=0, span_pruned=1)


def test_pack_detach() -> None:
    """Disconnected units must be relinked and counted."""
    row = _drive("pack_detach")
    _assert_row(row, lane_resumed=1, detach_linked=1, dup_count=0, merge_gaps=0, span_pruned=0)


def test_pack_retry() -> None:
    """Retrying lanes resume when parents are complete and gaps align."""
    row = _drive("pack_retry")
    _assert_row(row, lane_resumed=1, detach_linked=0, dup_count=0, merge_gaps=1, span_pruned=0)


def test_pack_fail() -> None:
    """Failed lanes must not count as resumed even when state store disagrees."""
    row = _drive("pack_fail")
    _assert_row(row, lane_resumed=0, detach_linked=0, dup_count=0, merge_gaps=0, span_pruned=0)


def test_pack_echo() -> None:
    """Identical duplicate WAL rows must still collapse to one row."""
    row = _drive("pack_echo")
    _assert_row(row, lane_resumed=1, detach_linked=0, dup_count=1, merge_gaps=0, span_pruned=0)


def test_pack_mixed() -> None:
    """Duplicate fold, merge gap, span prune, and detach relink interact."""
    row = _drive("pack_mixed")
    _assert_row(row, lane_resumed=2, detach_linked=1, dup_count=1, merge_gaps=1, span_pruned=1)


def test_pack_peak() -> None:
    """Larger pack combines duplicate fold, span prune, gap, and parent-gated resume."""
    row = _drive("pack_peak")
    _assert_row(row, lane_resumed=1, detach_linked=0, dup_count=1, merge_gaps=1, span_pruned=1)


def test_pack_branch() -> None:
    """Detach relink must prefer the strongest completed parent candidate."""
    row = _drive("pack_branch")
    _assert_row(row, lane_resumed=1, detach_linked=1, dup_count=0, merge_gaps=0, span_pruned=0)


def test_pack_stale() -> None:
    """Stale store fragments must not override terminal WAL labels for resume."""
    row = _drive("pack_stale")
    _assert_row(row, lane_resumed=0, detach_linked=0, dup_count=0, merge_gaps=0, span_pruned=0)
