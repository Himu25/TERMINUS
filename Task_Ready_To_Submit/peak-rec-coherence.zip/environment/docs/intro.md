Offline replay harness for the recommendation slice. Telemetry under `/app/telemetry` is sampled and may omit GPU queue depth.
