# Feed surge lab

The cord span witness replays `/app/data/traffic.json` against `/app/data/seed_users.json` and `/app/data/catalog.json` using props from `/app/config/feed.props`. Coordination modules live under `/app/src` (`ridge`, `reel`, `moor`, `spar`, `keel`, `dock`, `flux`). Redis cord URL comes from `TB_FEED_CORD`.

Reel scores catalog rows against query vectors. Dock materializes catalog slices after boot. Moor fuses distance with cohort affinity. Spar turns traffic rows into tick plans. Keel holds cord slot IO. Ridge wires the replay loop and audit envelope. Flux queues ingest rows when traffic carries them.
