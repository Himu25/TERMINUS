# Feed surge architecture

Replay walks `/app/data/traffic.json` in order. Boot warms the in-memory catalog table and seeds cord-backed feature vector slots (`{alpha}:fv:{item}`) plus recommendation cord slots (`{alpha}:{cohort}:{k}`).

Modules:
- `ridge/d7_loop` orchestrates the plan from `spar/k2_tick`
- `reel/r7_vec` scores candidates; `moor/n4_wgt` blends cohort affinity
- `dock/d9_load` materializes catalog rows; `dock/d2_overlay` applies Redis feature vectors onto rows before scoring
- `keel/m8_cord` stores ranked id lists per cord key; `keel/m9_feat` stores per-item vectors
- `flux/p1_ingest` queues ingest events; `flux/p2_dedup` provides dedup helpers used when wired
- `policy/prism` loads `feed.props`

Ingest rows update item vectors. Refresh rows evict cord slots that mention the item. Feature slots and catalog rows must stay aligned for ranking to match the lab ideal order.
