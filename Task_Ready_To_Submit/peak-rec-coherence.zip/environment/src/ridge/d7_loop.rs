use std::collections::HashMap;
use std::fs;
use std::path::Path;

use redis::Commands;
use serde::{Deserialize, Serialize};

use crate::dock::d2_overlay::overlay_feat_cache_copy;
use crate::dock::d9_load::{load_slice, warm_slice, CatalogRow};
use crate::flux::p1_ingest::{IngestEvent, IngestQueue};
use crate::keel::m8_cord::{
    cord_label, drop_item_slots, flush_alpha, read_slot, write_slot, SlotDoc,
};
use crate::keel::m9_feat::{flush_feats, write_feat};
use crate::moor::n4_wgt::fuse_scores;
use crate::policy::prism::{load_props, Prism};
use crate::reel::r7_vec::rank_items;
use crate::spar::k2_tick::{burst_schedule, PlanEntry, TrafficStep};

#[derive(Debug, Clone, Deserialize)]
pub struct UserDoc {
    pub cohort: String,
    pub vec: Vec<f64>,
}

#[derive(Debug, Serialize)]
pub struct SurgeAudit {
    pub throughput_band: String,
    pub quality_score: u32,
    pub latency_band: String,
    pub rank_stability: String,
    pub cold_misses: u32,
    pub batch_gain: u32,
    pub mix_digest: String,
}

pub struct SurgeCtx {
    pub cord_url: String,
    pub catalog_path: String,
    pub props_path: String,
    pub users_path: String,
    pub traffic_path: String,
    pub cache_ttl: u64,
}

struct SurgeState {
    cold_misses: u32,
    batch_units: u32,
    rank_ranks: Vec<u32>,
    label_trace: Vec<String>,
}

pub fn run_surge(ctx: &SurgeCtx) -> Result<SurgeAudit, redis::RedisError> {
    let prism = load_props(&ctx.props_path);
    let client = redis::Client::open(ctx.cord_url.as_str())?;
    let mut conn = client.get_connection()?;
    flush_alpha(&mut conn, &prism);
    flush_feats(&mut conn, &prism);

    let users_raw = fs::read_to_string(&ctx.users_path).expect("users");
    let users: HashMap<String, UserDoc> =
        serde_json::from_str(&users_raw).expect("users json");
    let traffic_raw = fs::read_to_string(&ctx.traffic_path).expect("traffic");
    let steps: Vec<TrafficStep> =
        serde_json::from_str(&traffic_raw).expect("traffic json");

    let mut local: HashMap<String, CatalogRow> = HashMap::new();
    let mut ingest = IngestQueue::new();
    let mut st = SurgeState {
        cold_misses: 0,
        batch_units: 0,
        rank_ranks: Vec::new(),
        label_trace: Vec::new(),
    };

    for s in &steps {
        if matches!(s, TrafficStep::Boot) {
            let catalog_items = load_slice(&ctx.catalog_path, &local);
            local = warm_slice(&catalog_items);
            for row in local.values() {
                write_feat(&mut conn, &prism, &row.id, &row.vec, ctx.cache_ttl)?;
            }
        }
    }

    let plan = burst_schedule(&steps);
    for entry in plan {
        ingest.tick_delay(&mut local);
        match entry {
            PlanEntry::Ingest { item, seq, vec } => {
                ingest.enqueue(IngestEvent { item, seq, vec });
            }
            PlanEntry::Refresh { item } => {
                let dropped = drop_item_slots(&mut conn, &prism, &item);
                if dropped > 0 {
                    st.cold_misses += 1;
                }
            }
            PlanEntry::Tick { members } => {
                if members.len() > 1 {
                    st.batch_units += 1;
                }
                for member in &members {
                    serve_query(
                        &mut conn,
                        &prism,
                        &ctx.catalog_path,
                        &local,
                        &users,
                        member,
                        &mut st,
                        ctx.cache_ttl,
                    )?;
                }
            }
        }
    }

    let quality_score = quality_from_ranks(&st.rank_ranks);
    let throughput_band = throughput_band(st.batch_units, st.cold_misses, quality_score);
    let latency_band = latency_band(st.cold_misses, st.batch_units);
    let rank_stability = if quality_score < 2000 {
        "drifted".to_string()
    } else {
        "steady".to_string()
    };
    let mix_digest = mix_digest(&st.label_trace, prism.mix);

    Ok(SurgeAudit {
        throughput_band,
        quality_score,
        latency_band,
        rank_stability,
        cold_misses: st.cold_misses,
        batch_gain: st.batch_units,
        mix_digest,
    })
}

fn serve_query(
    conn: &mut redis::Connection,
    prism: &Prism,
    catalog_path: &str,
    local: &HashMap<String, CatalogRow>,
    users: &HashMap<String, UserDoc>,
    member: &crate::spar::k2_tick::TickMember,
    st: &mut SurgeState,
    cache_ttl: u64,
) -> Result<(), redis::RedisError> {
    let user = users.get(&member.u).expect("user");
    let key = cord_label(prism, &member.u, member.k);
    let ids = if let Some(cached) = read_slot(conn, &key) {
        cached.ids
    } else {
        st.cold_misses += 1;
        let mut catalog_items = load_slice(catalog_path, local);
        catalog_items = overlay_feat_cache_copy(conn, prism, &catalog_items);
        let scanned = rank_items(&catalog_items, &user.vec);
        let mut mixed: Vec<(String, f64)> = Vec::new();
        for row in &scanned {
            let score = fuse_scores(row.raw, row, &user.cohort, prism);
            mixed.push((row.id.clone(), score));
        }
        mixed.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap());
        let ids: Vec<String> = mixed
            .into_iter()
            .take(member.k as usize)
            .map(|(id, _)| id)
            .collect();
        write_slot(conn, &key, &SlotDoc { ids: ids.clone() }, cache_ttl)?;
        ids
    };

    let mut catalog_items = load_slice(catalog_path, local);
    catalog_items = overlay_feat_cache_copy(conn, prism, &catalog_items);
    let want = ideal_top_ids(user, &catalog_items, member.k);
    for w in &want {
        let pos = ids
            .iter()
            .position(|x| x == w)
            .map(|p| p + 1)
            .unwrap_or(member.k as usize + 1);
        st.rank_ranks.push(pos as u32);
    }
    st.label_trace.push(ids.join(","));
    Ok(())
}

fn l2norm(vec: &[f64]) -> Vec<f64> {
    let s: f64 = vec.iter().map(|x| x * x).sum();
    let n = s.sqrt().max(1e-12);
    vec.iter().map(|x| x / n).collect()
}

fn dot(a: &[f64], b: &[f64]) -> f64 {
    a.iter().zip(b.iter()).map(|(x, y)| x * y).sum()
}

fn ideal_top_ids(user: &UserDoc, items: &[CatalogRow], k: u32) -> Vec<String> {
    let q = l2norm(&user.vec);
    let mut scored: Vec<(String, f64)> = items
        .iter()
        .map(|it| {
            let score = dot(&q, &l2norm(&it.vec)) * 0.85
                + if it.cohort == user.cohort { 0.15 } else { 0.0 };
            (it.id.clone(), score)
        })
        .collect();
    scored.sort_by(|a, b| {
        b.1.partial_cmp(&a.1)
            .unwrap()
            .then_with(|| a.0.cmp(&b.0))
    });
    scored.into_iter().take(k as usize).map(|(id, _)| id).collect()
}

fn quality_from_ranks(ranks: &[u32]) -> u32 {
    ranks
        .iter()
        .map(|r| if *r > 0 { 1000 / *r } else { 0 })
        .sum()
}

fn throughput_band(batch_units: u32, cold_misses: u32, quality_score: u32) -> String {
    if batch_units >= 2 && cold_misses <= 3 && quality_score >= 2800 {
        "green".into()
    } else if batch_units >= 1 || cold_misses <= 5 {
        "amber".into()
    } else {
        "red".into()
    }
}

fn latency_band(cold_misses: u32, batch_units: u32) -> String {
    if cold_misses <= 3 && batch_units >= 1 {
        "snappy".into()
    } else if cold_misses <= 6 {
        "sluggish".into()
    } else {
        "stalled".into()
    }
}

fn mix_digest(labels: &[String], mix: u32) -> String {
    let mut t = mix;
    for s in labels {
        for unit in s.bytes() {
            t = t.wrapping_add(u32::from(unit));
        }
    }
    format!("{:08x}", t & 0xffff_ffff)
}

pub fn write_audit(path: &Path, audit: &SurgeAudit) -> std::io::Result<()> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }
    let body = serde_json::to_string_pretty(audit).expect("audit json");
    fs::write(path, body)
}
