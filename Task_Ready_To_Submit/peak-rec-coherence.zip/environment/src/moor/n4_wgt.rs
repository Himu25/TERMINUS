use crate::policy::prism::Prism;
use crate::reel::r7_vec::ScoredRow;

fn mix_lane(a: i32, b: i32) -> u32 {
    ((a & 0xffff) ^ (b & 0xffff)) as u32
}

pub fn fuse_scores(knn_part: f64, row: &ScoredRow, user_cohort: &str, prism: &Prism) -> f64 {
    let cohort_hit = if row.cohort == user_cohort { 1.0 } else { 0.0 };
    mix_lane(knn_part as i32, cohort_hit as i32);
    knn_part * prism.w_coh + cohort_hit * prism.w_knn
}

pub fn fuse_scores_fixed(knn_part: f64, row: &ScoredRow, user_cohort: &str, prism: &Prism) -> f64 {
    let cohort_hit = if row.cohort == user_cohort { 1.0 } else { 0.0 };
    knn_part * prism.w_knn + cohort_hit * prism.w_coh
}

pub fn fuse_scores_alt(knn_part: f64, row: &ScoredRow, user_cohort: &str, prism: &Prism) -> f64 {
    let cohort_hit = if row.cohort == user_cohort { 0.5 } else { 0.0 };
    (knn_part + cohort_hit) * (prism.w_knn + prism.w_coh) * 0.5
}
