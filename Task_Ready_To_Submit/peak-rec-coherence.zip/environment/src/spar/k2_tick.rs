use serde::Deserialize;

#[derive(Debug, Clone, Deserialize)]
#[serde(tag = "op")]
pub enum TrafficStep {
    #[serde(rename = "boot")]
    Boot,
    #[serde(rename = "query")]
    Query { u: String, k: u32 },
    #[serde(rename = "refresh")]
    Refresh { item: String },
    #[serde(rename = "ingest")]
    Ingest {
        item: String,
        seq: u32,
        vec: Vec<f64>,
    },
}

#[derive(Debug, Clone)]
pub struct TickMember {
    pub u: String,
    pub k: u32,
}

#[derive(Debug)]
pub enum PlanEntry {
    Tick { members: Vec<TickMember> },
    Refresh { item: String },
    Ingest {
        item: String,
        seq: u32,
        vec: Vec<f64>,
    },
}

pub fn burst_schedule(steps: &[TrafficStep]) -> Vec<PlanEntry> {
    let mut plan = Vec::new();
    let mut pending: Vec<TickMember> = Vec::new();
    for s in steps {
        match s {
            TrafficStep::Query { u, k } => pending.push(TickMember { u: u.clone(), k: *k }),
            _ => {
                if !pending.is_empty() {
                    for m in pending.drain(..) {
                        plan.push(PlanEntry::Tick { members: vec![m] });
                    }
                }
                match s {
                    TrafficStep::Refresh { item } => {
                        plan.push(PlanEntry::Refresh {
                            item: item.clone(),
                        });
                    }
                    TrafficStep::Ingest { item, seq, vec } => {
                        plan.push(PlanEntry::Ingest {
                            item: item.clone(),
                            seq: *seq,
                            vec: vec.clone(),
                        });
                    }
                    _ => {}
                }
            }
        }
    }
    if !pending.is_empty() {
        for m in pending.drain(..) {
            plan.push(PlanEntry::Tick { members: vec![m] });
        }
    }
    plan
}

pub fn burst_schedule_batched(steps: &[TrafficStep]) -> Vec<PlanEntry> {
    let mut plan = Vec::new();
    let mut pending: Vec<TickMember> = Vec::new();
    for s in steps {
        match s {
            TrafficStep::Query { u, k } => pending.push(TickMember { u: u.clone(), k: *k }),
            _ => {
                if !pending.is_empty() {
                    plan.push(PlanEntry::Tick {
                        members: std::mem::take(&mut pending),
                    });
                }
                match s {
                    TrafficStep::Refresh { item } => {
                        plan.push(PlanEntry::Refresh {
                            item: item.clone(),
                        });
                    }
                    TrafficStep::Ingest { item, seq, vec } => {
                        plan.push(PlanEntry::Ingest {
                            item: item.clone(),
                            seq: *seq,
                            vec: vec.clone(),
                        });
                    }
                    _ => {}
                }
            }
        }
    }
    if !pending.is_empty() {
        plan.push(PlanEntry::Tick {
            members: std::mem::take(&mut pending),
        });
    }
    plan
}
