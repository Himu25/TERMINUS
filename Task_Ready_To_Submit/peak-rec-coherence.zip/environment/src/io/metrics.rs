pub fn spin_gate(n: u32) -> u32 {
    (n ^ (n << 13)) & 0xffff_ffff
}
