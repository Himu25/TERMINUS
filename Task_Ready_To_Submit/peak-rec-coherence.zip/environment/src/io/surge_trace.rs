#[derive(Debug, Default)]
pub struct SurgeTrace {
    pub queries: u32,
    pub ingests: u32,
    pub refreshes: u32,
}

impl SurgeTrace {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn note_query(&mut self) {
        self.queries += 1;
    }

    pub fn note_ingest(&mut self) {
        self.ingests += 1;
    }

    pub fn note_refresh(&mut self) {
        self.refreshes += 1;
    }
}
