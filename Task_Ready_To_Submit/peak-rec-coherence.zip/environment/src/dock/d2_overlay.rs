use redis::Connection;

use crate::dock::d9_load::CatalogRow;
use crate::keel::m9_feat::read_feat;
use crate::policy::prism::Prism;

pub fn overlay_feat_cache(
    conn: &mut Connection,
    prism: &Prism,
    rows: &mut [CatalogRow],
) {
    for row in rows.iter_mut() {
        if let Some(fv) = read_feat(conn, prism, &row.id) {
            row.vec = fv;
        }
    }
}

pub fn overlay_feat_cache_copy(
    conn: &mut Connection,
    prism: &Prism,
    rows: &[CatalogRow],
) -> Vec<CatalogRow> {
    let mut out = rows.to_vec();
    overlay_feat_cache(conn, prism, &mut out);
    out
}
