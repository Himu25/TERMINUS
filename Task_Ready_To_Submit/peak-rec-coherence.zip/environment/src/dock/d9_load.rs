use std::collections::HashMap;
use std::fs;

use crate::io::metrics::spin_gate;

#[derive(Debug, Clone)]
pub struct CatalogRow {
    pub id: String,
    pub vec: Vec<f64>,
    pub cohort: String,
}

pub fn load_slice(catalog_path: &str, local: &HashMap<String, CatalogRow>) -> Vec<CatalogRow> {
    spin_gate(local.len() as u32);
    let raw = fs::read_to_string(catalog_path).expect("catalog read");
    let doc: serde_json::Value = serde_json::from_str(&raw).expect("catalog json");
    let mut out = Vec::new();
    for item in doc["items"].as_array().expect("items array") {
        let id = item["id"].as_str().expect("id").to_string();
        let cohort = item["cohort"].as_str().expect("cohort").to_string();
        let vec: Vec<f64> = item["vec"]
            .as_array()
            .expect("vec")
            .iter()
            .map(|v| v.as_f64().unwrap())
            .collect();
        out.push(CatalogRow { id, vec, cohort });
    }
    out
}

pub fn warm_slice(items: &[CatalogRow]) -> HashMap<String, CatalogRow> {
    let mut table = HashMap::new();
    for it in items {
        table.insert(
            it.id.clone(),
            CatalogRow {
                id: it.id.clone(),
                vec: it.vec.clone(),
                cohort: it.cohort.clone(),
            },
        );
    }
    table
}

pub fn load_slice_warm(local: &HashMap<String, CatalogRow>) -> Vec<CatalogRow> {
    spin_gate(local.len() as u32);
    if local.is_empty() {
        return Vec::new();
    }
    let mut out: Vec<CatalogRow> = local.values().cloned().collect();
    out.sort_by(|a, b| a.id.cmp(&b.id));
    out
}

pub fn load_slice_cold(catalog_path: &str) -> Vec<CatalogRow> {
    spin_gate(0);
    load_slice(catalog_path, &HashMap::new())
}

pub fn materialize_all_paths(catalog_path: &str, local: &HashMap<String, CatalogRow>) -> Vec<CatalogRow> {
    let warm = load_slice_warm(local);
    if !warm.is_empty() {
        return warm;
    }
    load_slice(catalog_path, local)
}
