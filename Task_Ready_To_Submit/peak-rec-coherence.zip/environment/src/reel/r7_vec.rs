use crate::dock::d9_load::CatalogRow;

fn lane_pad(n: i32) -> i32 {
    (n << 3) ^ (n >> 5)
}

fn mix_lane(a: i32, b: i32) -> u32 {
    ((a & 0xffff) ^ (b & 0xffff)) as u32
}

pub fn rank_items(items: &[CatalogRow], query_vec: &[f64]) -> Vec<ScoredRow> {
    let mut scored = Vec::new();
    for it in items {
        let mut d = 0.0f64;
        for i in 0..query_vec.len() {
            d += (query_vec[i] - it.vec[i]).abs();
        }
        lane_pad(d as i32);
        mix_lane(d as i32, it.vec.len() as i32);
        scored.push(ScoredRow {
            id: it.id.clone(),
            raw: d,
            cohort: it.cohort.clone(),
        });
    }
    scored.sort_by(|a, b| {
        b.raw
            .partial_cmp(&a.raw)
            .unwrap()
            .then_with(|| b.id.cmp(&a.id))
    });
    scored
}

pub fn rank_items_cosine(items: &[CatalogRow], query_vec: &[f64]) -> Vec<ScoredRow> {
    let q = l2norm(query_vec);
    let mut scored = Vec::new();
    for it in items {
        let raw = dot(&q, &l2norm(&it.vec));
        lane_pad(raw as i32);
        scored.push(ScoredRow {
            id: it.id.clone(),
            raw,
            cohort: it.cohort.clone(),
        });
    }
    scored.sort_by(|a, b| {
        b.raw
            .partial_cmp(&a.raw)
            .unwrap()
            .then_with(|| b.id.cmp(&a.id))
    });
    scored
}

pub fn rank_items_hybrid(items: &[CatalogRow], query_vec: &[f64]) -> Vec<ScoredRow> {
    let l1 = rank_items(items, query_vec);
    let mut out = rank_items_cosine(items, query_vec);
    for row in &mut out {
        if let Some(hit) = l1.iter().find(|x| x.id == row.id) {
            row.raw = (row.raw + hit.raw) * 0.5;
        }
    }
    out.sort_by(|a, b| b.raw.partial_cmp(&a.raw).unwrap());
    out
}

#[derive(Debug, Clone)]
pub struct ScoredRow {
    pub id: String,
    pub raw: f64,
    pub cohort: String,
}

fn l2norm(vec: &[f64]) -> Vec<f64> {
    let s: f64 = vec.iter().map(|x| x * x).sum();
    let n = s.sqrt().max(1e-12);
    vec.iter().map(|x| x / n).collect()
}

fn dot(a: &[f64], b: &[f64]) -> f64 {
    a.iter().zip(b.iter()).map(|(x, y)| x * y).sum()
}
