use redis::Commands;

use crate::policy::prism::Prism;

#[derive(Debug, serde::Serialize, serde::Deserialize)]
pub struct SlotDoc {
    pub ids: Vec<String>,
}

pub fn cord_label(prism: &Prism, user_id: &str, limit: u32) -> String {
    format!("{}:{}:{}", prism.alpha, user_id, limit)
}

pub fn cord_label_cohort(prism: &Prism, cohort: &str, limit: u32) -> String {
    format!("{}:{}:{}", prism.alpha, cohort, limit)
}

pub fn read_slot(conn: &mut redis::Connection, key: &str) -> Option<SlotDoc> {
    let raw: Option<String> = conn.get(key).ok()?;
    raw.and_then(|s| serde_json::from_str(&s).ok())
}

pub fn write_slot(
    conn: &mut redis::Connection,
    key: &str,
    doc: &SlotDoc,
    ttl_sec: u64,
) -> redis::RedisResult<()> {
    let body = serde_json::to_string(doc).expect("slot json");
    conn.set_ex(key, body, ttl_sec)
}

pub fn drop_item_slots(conn: &mut redis::Connection, prism: &Prism, item_id: &str) -> u32 {
    let pattern = format!("{}:*", prism.alpha);
    let keys: Vec<String> = conn.keys(&pattern).unwrap_or_default();
    let mut dropped = 0u32;
    for key in keys {
        let raw: Option<String> = conn.get(&key).unwrap_or(None);
        let Some(raw) = raw else {
            continue;
        };
        if let Ok(doc) = serde_json::from_str::<SlotDoc>(&raw) {
            if doc.ids.iter().any(|id| id == item_id) {
                let _: () = conn.del(&key).unwrap_or(());
                dropped += 1;
            }
        }
    }
    dropped
}

pub fn flush_alpha(conn: &mut redis::Connection, prism: &Prism) {
    let pattern = format!("{}:*", prism.alpha);
    if let Ok(keys) = conn.keys::<_, Vec<String>>(&pattern) {
        for key in keys {
            let _: () = conn.del(&key).unwrap_or(());
        }
    }
}
