use redis::Commands;

use crate::policy::prism::Prism;

pub fn feat_key(prism: &Prism, item_id: &str) -> String {
    format!("{}:fv:{}", prism.alpha, item_id)
}

pub fn read_feat(conn: &mut redis::Connection, prism: &Prism, item_id: &str) -> Option<Vec<f64>> {
    let key = feat_key(prism, item_id);
    let raw: Option<String> = conn.get(&key).ok()?;
    raw.and_then(|s| serde_json::from_str(&s).ok())
}

pub fn write_feat(
    conn: &mut redis::Connection,
    prism: &Prism,
    item_id: &str,
    vec: &[f64],
    ttl_sec: u64,
) -> redis::RedisResult<()> {
    let key = feat_key(prism, item_id);
    let body = serde_json::to_string(vec).expect("feat json");
    conn.set_ex(key, body, ttl_sec)
}

pub fn drop_item_feats(conn: &mut redis::Connection, prism: &Prism, item_id: &str) -> u32 {
    let key = feat_key(prism, item_id);
    let deleted: u32 = conn.del(&key).unwrap_or(0);
    if deleted > 0 {
        1
    } else {
        0
    }
}

pub fn flush_feats(conn: &mut redis::Connection, prism: &Prism) {
    let pattern = format!("{}:fv:*", prism.alpha);
    if let Ok(keys) = conn.keys::<_, Vec<String>>(&pattern) {
        for key in keys {
            let _: () = conn.del(&key).unwrap_or(());
        }
    }
}
