use std::fs;

#[derive(Debug, Clone)]
pub struct Prism {
    pub alpha: String,
    pub mix: u32,
    pub w_knn: f64,
    pub w_coh: f64,
}

pub fn load_props(path: &str) -> Prism {
    let mut alpha = "rc".to_string();
    let mut mix = 0u32;
    let mut w_knn = 0.85;
    let mut w_coh = 0.15;
    for line in fs::read_to_string(path).unwrap_or_default().lines() {
        let t = line.trim();
        if t.starts_with('#') || !t.contains('=') {
            continue;
        }
        let (k, v) = t.split_once('=').unwrap();
        match k.trim() {
            "ALPHA" => alpha = v.trim().to_string(),
            "MIX" => mix = v.trim().parse().unwrap_or(0),
            "W_KNN" => w_knn = v.trim().parse().unwrap_or(0.85),
            "W_COH" => w_coh = v.trim().parse().unwrap_or(0.15),
            _ => {}
        }
    }
    Prism {
        alpha,
        mix,
        w_knn,
        w_coh,
    }
}
