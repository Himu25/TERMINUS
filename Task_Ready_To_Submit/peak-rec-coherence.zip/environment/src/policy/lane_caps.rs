pub fn clamp_k(k: u32) -> u32 {
    if k == 0 {
        1
    } else if k > 6 {
        6
    } else {
        k
    }
}
