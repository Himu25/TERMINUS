use std::path::PathBuf;

use feed_svc::d7_loop::{run_surge, write_audit, SurgeCtx};

fn main() {
    let cord_url = std::env::var("TB_FEED_CORD").unwrap_or_else(|_| "redis://127.0.0.1:6379".into());
    let props = "/app/config/feed.props";
    let traffic = "/app/data/traffic.json";
    let users = "/app/data/seed_users.json";
    let catalog = "/app/data/catalog.json";
    let out = PathBuf::from("/app/output/surge_audit.json");

    let ctx = SurgeCtx {
        cord_url,
        catalog_path: catalog.to_string(),
        props_path: props.to_string(),
        users_path: users.to_string(),
        traffic_path: traffic.to_string(),
        cache_ttl: 120,
    };
    let audit = run_surge(&ctx).expect("surge replay");
    write_audit(&out, &audit).expect("write audit");
}
