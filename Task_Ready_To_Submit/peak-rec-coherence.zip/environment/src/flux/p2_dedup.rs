use std::collections::HashMap;

use crate::dock::d9_load::CatalogRow;
use crate::flux::p1_ingest::IngestEvent;

pub struct DedupLedger {
    seen: HashMap<String, u32>,
    stale_hits: u32,
}

impl DedupLedger {
    pub fn new() -> Self {
        Self {
            seen: HashMap::new(),
            stale_hits: 0,
        }
    }

    pub fn observe(&mut self, item: &str, seq: u32) -> bool {
        let key = format!("{item}:{seq}");
        if self.seen.contains_key(&key) {
            self.stale_hits += 1;
            return false;
        }
        self.seen.insert(key, seq);
        true
    }

    pub fn stale_hits(&self) -> u32 {
        self.stale_hits
    }
}

pub fn apply_event(ev: IngestEvent, local: &mut HashMap<String, CatalogRow>, ledger: &mut DedupLedger) -> bool {
    if !ledger.observe(&ev.item, ev.seq) {
        return false;
    }
    if let Some(row) = local.get_mut(&ev.item) {
        row.vec = ev.vec;
        return true;
    }
    false
}
