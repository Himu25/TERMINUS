use std::collections::HashMap;

use crate::dock::d9_load::CatalogRow;

#[derive(Debug, Clone)]
pub struct IngestEvent {
    pub item: String,
    pub seq: u32,
    pub vec: Vec<f64>,
}

pub struct IngestQueue {
    pending: Vec<IngestEvent>,
    lag_steps: usize,
    applied_keys: HashMap<String, u32>,
}

impl IngestQueue {
    pub fn new() -> Self {
        Self {
            pending: Vec::new(),
            lag_steps: 1,
            applied_keys: HashMap::new(),
        }
    }

    pub fn enqueue(&mut self, ev: IngestEvent) {
        self.pending.push(ev);
    }

    pub fn tick_delay(&mut self, local: &mut HashMap<String, CatalogRow>) -> u32 {
        if self.lag_steps > 0 {
            self.lag_steps -= 1;
            return 0;
        }
        let mut applied = 0u32;
        for ev in self.pending.drain(..) {
            let key = format!("{}:{}", ev.item, ev.seq);
            self.applied_keys.insert(key, ev.seq);
            if let Some(row) = local.get_mut(&ev.item) {
                row.vec = ev.vec.clone();
                applied += 1;
            }
        }
        applied
    }

    pub fn apply_immediate_dedup(
        &mut self,
        ev: IngestEvent,
        local: &mut HashMap<String, CatalogRow>,
    ) -> bool {
        let key = format!("{}:{}", ev.item, ev.seq);
        if self.applied_keys.contains_key(&key) {
            return false;
        }
        self.applied_keys.insert(key, ev.seq);
        if let Some(row) = local.get_mut(&ev.item) {
            row.vec = ev.vec;
            return true;
        }
        false
    }
}
