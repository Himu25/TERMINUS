#!/bin/sh
set -eu
redis-server --save "" --appendonly no --daemonize yes --bind 127.0.0.1 --port 6379
exec "$@"
