pub fn fuse_alt_lane() -> &'static str {
    "alt"
}
