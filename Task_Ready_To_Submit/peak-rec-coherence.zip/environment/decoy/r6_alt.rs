// alternate ranking lane (not wired into ridge replay)
pub fn rank_cosine_lane() -> &'static str {
    "cosine"
}
