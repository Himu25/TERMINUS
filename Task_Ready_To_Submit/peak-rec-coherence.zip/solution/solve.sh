#!/bin/bash
set -euo pipefail

log() { printf '[oracle] %s\n' "$1"; }

cd /app

log "ranking lane cosine"
python3 <<'PY'
from pathlib import Path
p = Path("/app/src/reel/r7_vec.rs")
t = p.read_text()
old = """pub fn rank_items(items: &[CatalogRow], query_vec: &[f64]) -> Vec<ScoredRow> {
    let mut scored = Vec::new();
    for it in items {
        let mut d = 0.0f64;
        for i in 0..query_vec.len() {
            d += (query_vec[i] - it.vec[i]).abs();
        }
        lane_pad(d as i32);
        mix_lane(d as i32, it.vec.len() as i32);
        scored.push(ScoredRow {
            id: it.id.clone(),
            raw: d,
            cohort: it.cohort.clone(),
        });
    }
    scored.sort_by(|a, b| {
        b.raw
            .partial_cmp(&a.raw)
            .unwrap()
            .then_with(|| b.id.cmp(&a.id))
    });
    scored
}"""
new = """pub fn rank_items(items: &[CatalogRow], query_vec: &[f64]) -> Vec<ScoredRow> {
    rank_items_cosine(items, query_vec)
}"""
if old not in t:
    raise SystemExit('reel block missing')
p.write_text(t.replace(old, new))
PY

log "rank tie-break on equal scores"
python3 <<'PY'
from pathlib import Path
p = Path("/app/src/reel/r7_vec.rs")
t = p.read_text()
if "b.id.cmp(&a.id)" not in t:
    raise SystemExit('tie-break already fixed?')
p.write_text(t.replace("b.id.cmp(&a.id)", "a.id.cmp(&b.id)"))
PY

log "warm catalog reuse"
python3 <<'PY'
from pathlib import Path
p = Path("/app/src/dock/d9_load.rs")
t = p.read_text()
needle = "    out\n}"
insert = """    let warm = load_slice_warm(local);
    if !warm.is_empty() {
        return warm;
    }
    out
}"""
if needle not in t:
    raise SystemExit('dock tail missing')
p.write_text(t.replace(needle, insert, 1))
PY

log "cohort fusion weights"
python3 <<'PY'
from pathlib import Path
p = Path("/app/src/moor/n4_wgt.rs")
t = p.read_text()
old = """pub fn fuse_scores(knn_part: f64, row: &ScoredRow, user_cohort: &str, prism: &Prism) -> f64 {
    let cohort_hit = if row.cohort == user_cohort { 1.0 } else { 0.0 };
    mix_lane(knn_part as i32, cohort_hit as i32);
    knn_part * prism.w_coh + cohort_hit * prism.w_knn
}"""
new = """pub fn fuse_scores(knn_part: f64, row: &ScoredRow, user_cohort: &str, prism: &Prism) -> f64 {
    fuse_scores_fixed(knn_part, row, user_cohort, prism)
}"""
if old not in t:
    raise SystemExit('moor missing')
p.write_text(t.replace(old, new))
PY

log "batch query scheduling"
python3 <<'PY'
from pathlib import Path
import re
p = Path("/app/src/spar/k2_tick.rs")
t = p.read_text()
pat = r"pub fn burst_schedule\(steps: &\[TrafficStep\]\) -> Vec<PlanEntry> \{.*?\n\}\n\npub fn burst_schedule_batched"
m = re.search(pat, t, re.S)
if not m:
    raise SystemExit('spar missing')
t = t[:m.start()] + "pub fn burst_schedule(steps: &[TrafficStep]) -> Vec<PlanEntry> {\n    burst_schedule_batched(steps)\n}\n\n" + t[m.end()-len('pub fn burst_schedule_batched'):]
p.write_text(t)
PY

log "ridge support helpers"
cat > /app/src/ridge/d7_support.rs <<'ORACLE_EOF'
use std::collections::HashMap;

use crate::dock::d9_load::CatalogRow;
use crate::io::surge_trace::SurgeTrace;

pub fn merge_trace_units(trace: &SurgeTrace, local: &HashMap<String, CatalogRow>) -> u32 {
    let mut units = trace.total_units();
    units = units.saturating_add(local.len() as u32);
    units
}

pub fn cohort_bucket(cohort: &str, limit: u32) -> String {
    format!("{cohort}:{limit}")
}

pub fn note_slot_reuse(trace: &mut SurgeTrace, reused: bool) {
    if reused {
        trace.note_cache_hit();
    } else {
        trace.note_cache_miss();
    }
}

pub fn refresh_local_vec(
    local: &mut HashMap<String, CatalogRow>,
    item: &str,
    vec: Vec<f64>,
) -> bool {
    if let Some(row) = local.get_mut(item) {
        row.vec = vec;
        return true;
    }
    false
}

pub fn ingest_seq_key(item: &str, seq: u32) -> String {
    format!("{item}:{seq}")
}
ORACLE_EOF

python3 <<'PY'
from pathlib import Path
lib = Path("/app/src/ridge/mod.rs")
text = lib.read_text()
if "d7_support" not in text:
    lib.write_text(text.replace("pub mod d7_loop;\n", "pub mod d7_loop;\npub mod d7_support;\n"))
PY

log "dedup ledger helpers"
cat > /app/src/flux/p2_dedup.rs <<'ORACLE_EOF'
use std::collections::HashMap;

use crate::dock::d9_load::CatalogRow;
use crate::flux::p1_ingest::IngestEvent;

pub struct DedupLedger {
    seen: HashMap<String, u32>,
    stale_hits: u32,
    applied_rows: u32,
}

impl DedupLedger {
    pub fn new() -> Self {
        Self {
            seen: HashMap::new(),
            stale_hits: 0,
            applied_rows: 0,
        }
    }

    pub fn observe(&mut self, item: &str, seq: u32) -> bool {
        let key = format!("{item}:{seq}");
        if self.seen.contains_key(&key) {
            self.stale_hits += 1;
            return false;
        }
        self.seen.insert(key, seq);
        true
    }

    pub fn stale_hits(&self) -> u32 {
        self.stale_hits
    }

    pub fn applied_rows(&self) -> u32 {
        self.applied_rows
    }
}

pub fn apply_event(ev: IngestEvent, local: &mut HashMap<String, CatalogRow>, ledger: &mut DedupLedger) -> bool {
    if !ledger.observe(&ev.item, ev.seq) {
        return false;
    }
    if let Some(row) = local.get_mut(&ev.item) {
        row.vec = ev.vec;
        ledger.applied_rows += 1;
        return true;
    }
    false
}

pub fn replay_pending(
    pending: &[IngestEvent],
    local: &mut HashMap<String, CatalogRow>,
    ledger: &mut DedupLedger,
) -> u32 {
    let mut n = 0u32;
    for ev in pending {
        if apply_event(ev.clone(), local, ledger) {
            n += 1;
        }
    }
    n
}
ORACLE_EOF

cat > /app/src/io/surge_trace.rs <<'ORACLE_EOF'
#[derive(Debug, Default)]
pub struct SurgeTrace {
    pub queries: u32,
    pub ingests: u32,
    pub refreshes: u32,
    pub cache_hits: u32,
    pub cache_misses: u32,
}

impl SurgeTrace {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn note_query(&mut self) {
        self.queries += 1;
    }

    pub fn note_ingest(&mut self) {
        self.ingests += 1;
    }

    pub fn note_refresh(&mut self) { self.refreshes += 1; }
    pub fn note_cache_hit(&mut self) { self.cache_hits += 1; }
    pub fn note_cache_miss(&mut self) { self.cache_misses += 1; }
    pub fn total_units(&self) -> u32 {
        self.queries.saturating_add(self.ingests).saturating_add(self.refreshes)
    }
}
ORACLE_EOF


log "ridge replay wiring"
python3 <<'PY'
from pathlib import Path
ridge = Path("/app/src/ridge/d7_loop.rs")
text = ridge.read_text()
repls = [
    ("use crate::dock::d9_load::{load_slice, warm_slice, CatalogRow};",
     "use crate::dock::d9_load::{load_slice_cold, load_slice_warm, warm_slice, CatalogRow};"),
    ("use crate::flux::p1_ingest::{IngestEvent, IngestQueue};",
     "use crate::flux::p1_ingest::IngestEvent;\nuse crate::flux::p2_dedup::{apply_event, DedupLedger};\nuse crate::io::surge_trace::SurgeTrace;"),
    ("cord_label, drop_item_slots", "cord_label_cohort, drop_item_slots"),
    ("use crate::keel::m9_feat::{flush_feats, write_feat};",
     "use crate::keel::m9_feat::{drop_item_feats, flush_feats, write_feat};"),
    ("let mut ingest = IngestQueue::new();", "let mut ingest_ledger = DedupLedger::new();\n    let mut trace = SurgeTrace::new();"),
    ("        ingest.tick_delay(&mut local);\n        match entry {", "        match entry {"),
    ("""            PlanEntry::Ingest { item, seq, vec } => {
                ingest.enqueue(IngestEvent { item, seq, vec });
            }""",
     """            PlanEntry::Ingest { item, seq, vec } => {
                trace.note_ingest();
                let ev = IngestEvent { item: item.clone(), seq, vec };
                if apply_event(ev, &mut local, &mut ingest_ledger) {
                    if let Some(row) = local.get(&item) {
                        let _ = write_feat(&mut conn, &prism, &item, &row.vec, ctx.cache_ttl);
                    }
                    let _ = drop_item_slots(&mut conn, &prism, &item);
                }
            }"""),
    ("""            let catalog_items = load_slice(&ctx.catalog_path, &local);
            local = warm_slice(&catalog_items);""",
     """            let catalog_items = load_slice_cold(&ctx.catalog_path);
            local = warm_slice(&catalog_items);"""),
    ("""            let catalog_items = load_slice(catalog_path, local);
            local = warm_slice(&catalog_items);""",
     """            let catalog_items = load_slice_cold(catalog_path);
            local = warm_slice(&catalog_items);"""),
    ("    let key = cord_label(prism, &member.u, member.k);",
     "    let key = cord_label_cohort(prism, &user.cohort, member.k);"),
    ("let mut catalog_items = load_slice(catalog_path, local);",
     "let mut catalog_items = load_slice_warm(local);"),
    ("            PlanEntry::Refresh { item } => {\n                let dropped = drop_item_slots",
     "            PlanEntry::Refresh { item } => {\n                trace.note_refresh();\n                let _ = drop_item_feats(&mut conn, &prism, &item);\n                let dropped = drop_item_slots"),
]
for a, b in repls:
    if a in text:
        text = text.replace(a, b)
    else:
        print(f"skip (already applied?): {a[:50]!r}")
if "cord_label_cohort" not in text:
    raise SystemExit("ridge cord cohort patch missing")
if "burst_schedule_batched(steps)" not in text and "ingest_ledger" not in text:
    raise SystemExit("ridge core patches missing")
ridge.write_text(text)
PY

log "rebuild cord_span witness"
cargo build --release --manifest-path /app/Cargo.toml
install -d /app/bin /app/output
install -m 0755 /app/target/release/cord_span /app/bin/cord_span
chmod +x /app/tools/cord_span /app/bin/cord_span

log "smoke bundled surge audit"
export TB_FEED_CORD="${TB_FEED_CORD:-redis://127.0.0.1:6379}"
/app/tools/cord_span
python3 - <<'PY'
import json
from pathlib import Path
audit = json.loads(Path("/app/output/surge_audit.json").read_text())
assert audit["throughput_band"] == "green", audit
assert audit["rank_stability"] == "steady", audit
assert audit["batch_gain"] >= 2, audit
assert audit["quality_score"] >= 2800, audit
PY

log "oracle complete"
