#!/bin/bash
set -euo pipefail
cd /app
export TB_FEED_CORD="${TB_FEED_CORD:-redis://127.0.0.1:6379}"
exec /app/tools/cord_span
