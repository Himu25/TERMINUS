"""Verifier for peak-rec-coherence surge_audit contract."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import pytest

APP = Path("/app")
OUT = APP / "output" / "surge_audit.json"
TRAFFIC = APP / "data" / "traffic.json"
USERS = APP / "data" / "seed_users.json"
FIXTURES = Path(__file__).resolve().parent / "fixtures"
INVOKER = Path("/tests/invoke_runner.sh")

BUNDLED_TRAFFIC = TRAFFIC.read_text(encoding="utf-8")
BUNDLED_USERS = USERS.read_text(encoding="utf-8")


@pytest.fixture(autouse=True)
def restore_lab_bundle() -> None:
    yield
    _atomic_write_text(TRAFFIC, BUNDLED_TRAFFIC)
    _atomic_write_text(USERS, BUNDLED_USERS)


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _run_probe() -> dict[str, Any]:
    import subprocess

    proc = subprocess.run(
        [str(INVOKER)],
        capture_output=True,
        text=True,
        check=False,
        cwd="/app",
        env={
            **os.environ,
            "TB_FEED_CORD": os.environ.get("TB_FEED_CORD", "redis://127.0.0.1:6379"),
        },
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout
    assert OUT.exists(), "expected surge audit at /app/output/surge_audit.json"
    return json.loads(OUT.read_text(encoding="utf-8"))


def _swap_fixture(stem: str) -> None:
    churn = json.loads((FIXTURES / f"{stem}.json").read_text(encoding="utf-8"))
    users = json.loads((FIXTURES / f"{stem}_users.json").read_text(encoding="utf-8"))
    _atomic_write_text(TRAFFIC, json.dumps(churn, indent=2) + "\n")
    _atomic_write_text(USERS, json.dumps(users, indent=2) + "\n")


def _load_audit_expectation(stem: str) -> dict[str, Any]:
    path = FIXTURES / f"{stem}_audit.json"
    return json.loads(path.read_text(encoding="utf-8"))


def _assert_audit_exact(got: dict[str, Any], want: dict[str, Any]) -> None:
    g = json.loads(json.dumps(got))
    w = json.loads(json.dumps(want))
    for key in (
        "quality_score",
        "cold_misses",
        "batch_gain",
    ):
        g[key] = int(g[key])
        w[key] = int(w[key])
    assert g == w


def _latency_allowed(want_lat: str) -> tuple[str, ...]:
    if want_lat == "snappy":
        return ("snappy", "sluggish")
    if want_lat == "sluggish":
        return ("sluggish", "stalled")
    return ("stalled", "sluggish")


def _assert_audit_scenario_target(got: dict[str, Any], want: dict[str, Any]) -> None:
    assert got["throughput_band"] == want["throughput_band"]
    assert got["rank_stability"] == want["rank_stability"]
    assert got["latency_band"] in _latency_allowed(want["latency_band"])
    q_want = int(want["quality_score"])
    assert int(got["quality_score"]) >= (q_want * 75) // 100
    assert abs(int(got["cold_misses"]) - int(want["cold_misses"])) <= 5
    assert int(got["batch_gain"]) >= 1
    assert len(got["mix_digest"]) == 8
    assert got["mix_digest"][:4] == want["mix_digest"][:4]


def _assert_refresh_storm_target(got: dict[str, Any], want: dict[str, Any]) -> None:
    assert got["throughput_band"] in ("amber", "red")
    assert got["rank_stability"] == want["rank_stability"]
    assert got["latency_band"] in _latency_allowed(want["latency_band"])
    q_want = int(want["quality_score"])
    assert int(got["quality_score"]) >= (q_want * 75) // 100
    assert abs(int(got["cold_misses"]) - int(want["cold_misses"])) <= 6
    assert int(got["batch_gain"]) >= 1
    assert len(got["mix_digest"]) == 8
    assert got["mix_digest"][:4] == want["mix_digest"][:4]


def _assert_cross_burst_ping_target(got: dict[str, Any], want: dict[str, Any]) -> None:
    assert got["throughput_band"] in ("green", "amber", "red")
    assert got["rank_stability"] == want["rank_stability"]
    assert got["latency_band"] in _latency_allowed(want["latency_band"])
    q_want = int(want["quality_score"])
    assert int(got["quality_score"]) >= (q_want * 60) // 100
    assert abs(int(got["cold_misses"]) - int(want["cold_misses"])) <= 6
    assert int(got["batch_gain"]) >= 1
    assert len(got["mix_digest"]) == 8
    assert got["mix_digest"][:4] == want["mix_digest"][:4]


HARD_EXACT_STEMS = [
    "scenario_limit_ladder",
    "scenario_near_tie_blend",
]

HARD_BAND_STEMS = [
    "scenario_interleaved_refresh",
    "scenario_seven_mark_spiral",
    "scenario_dual_limit_matrix",
    "scenario_cohort_isolation",
    "scenario_heavy_cold_warm",
    "scenario_mixed_refresh_tail",
]

AUDIT_KEYS = frozenset(
    {
        "throughput_band",
        "quality_score",
        "latency_band",
        "rank_stability",
        "cold_misses",
        "batch_gain",
        "mix_digest",
    }
)


def test_surge_audit_output_exists() -> None:
    """Bundled replay must emit /app/output/surge_audit.json."""
    _run_probe()
    assert OUT.is_file()


def test_surge_audit_schema_keys_only() -> None:
    """Audit JSON must expose only the seven documented surge audit fields."""
    data = _run_probe()
    assert set(data.keys()) == AUDIT_KEYS


def test_bundled_throughput_green() -> None:
    """throughput_band settles to green on the bundled surge replay."""
    data = _run_probe()
    assert data["throughput_band"] == "green"


def test_bundled_latency_snappy() -> None:
    """latency_band reads snappy when cold paths and batching are healthy."""
    data = _run_probe()
    assert data["latency_band"] == "snappy"


def test_bundled_rank_stability_steady() -> None:
    """rank_stability is steady when ranking matches the lab ideal order."""
    data = _run_probe()
    assert data["rank_stability"] == "steady"


def test_bundled_quality_floor() -> None:
    """quality_score meets the bundled floor from the probe witness."""
    data = _run_probe()
    assert data["quality_score"] >= 2800


def test_bundled_batch_gain() -> None:
    """batch_gain reflects coalesced query ticks between refresh rows."""
    data = _run_probe()
    assert data["batch_gain"] >= 2


def test_bundled_mix_digest_shape() -> None:
    """mix_digest is eight lowercase hex digits from the MIX walk."""
    data = _run_probe()
    assert len(data["mix_digest"]) == 8
    assert all(c in "0123456789abcdef" for c in data["mix_digest"])


@pytest.mark.parametrize(
    "stem",
    [
        "scenario_warm_repeat",
        "scenario_cohort_flip",
        "scenario_refresh_tail",
        "scenario_triple_burst",
        "scenario_sparse_catalog",
        "scenario_dual_cohort",
    ],
)
def test_fixture_scenarios(stem: str) -> None:
    """Indexed churn bundles meet fixture floors in steady_tokens.txt after substitution."""
    _swap_fixture(stem)
    data = _run_probe()
    assert data["throughput_band"] in ("green", "amber")
    assert data["latency_band"] in ("snappy", "sluggish")
    assert data["rank_stability"] == "steady"
    assert data["quality_score"] >= 2000
    assert data["batch_gain"] >= 1
    assert len(data["mix_digest"]) == 8


@pytest.mark.parametrize("stem", HARD_EXACT_STEMS)
def test_hard_scenario_exact_contract(stem: str) -> None:
    """Hard stems require a byte-stable surge_audit matching the lab oracle replay."""
    _swap_fixture(stem)
    got = _run_probe()
    want = _load_audit_expectation(stem)
    _assert_audit_exact(got, want)


def test_refresh_storm_target_bands() -> None:
    """scenario_refresh_storm follows refresh_storm_* slack in steady_tokens.txt."""
    stem = "scenario_refresh_storm"
    _swap_fixture(stem)
    got = _run_probe()
    want = _load_audit_expectation(stem)
    _assert_refresh_storm_target(got, want)


def test_cross_burst_ping_target_bands() -> None:
    """scenario_cross_burst_ping follows cross_burst_* slack in steady_tokens.txt."""
    stem = "scenario_cross_burst_ping"
    _swap_fixture(stem)
    got = _run_probe()
    want = _load_audit_expectation(stem)
    _assert_cross_burst_ping_target(got, want)


@pytest.mark.parametrize("stem", HARD_BAND_STEMS)
def test_hard_scenario_target_bands(stem: str) -> None:
    """Indexed hard stems must hit oracle replay bands with bounded numeric slack."""
    _swap_fixture(stem)
    got = _run_probe()
    want = _load_audit_expectation(stem)
    _assert_audit_scenario_target(got, want)
