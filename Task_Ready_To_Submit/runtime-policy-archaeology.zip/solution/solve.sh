#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/pkg/closegate/op_t.go <<'EOF'
package closegate

func depthOpen(currentDepth int, maxDepth int) bool {
	if maxDepth <= 0 {
		return false
	}
	return currentDepth < maxDepth
}

// GateT decides whether graph expansion may continue past the current depth.
func GateT(currentDepth int, maxDepth int) bool {
	return depthOpen(currentDepth, maxDepth)
}
EOF

cat > /app/internal/catalog/op_s.go <<'EOF'
package catalog

// OpS decides whether a registry edge row is fresh enough to merge.
func OpS(asOf int, cutoff int) bool {
	return asOf >= cutoff
}
EOF

cat > /app/pkg/lanehint/op_h.go <<'EOF'
package lanehint

// OpH decides whether a shadow-policy overlay edge is incorporated into the working graph.
func OpH(lane string, present bool) bool {
	_ = lane
	return present
}
EOF

cat > /app/pkg/priority/op_k.go <<'EOF'
package priority

// OpK scores authorization urgency from alert volume and hop distance from the subject principal.
func OpK(alertCount int, hopDistance int) int {
	return alertCount*100 - hopDistance*10
}
EOF

cat > /app/spanfold/src/lib.rs <<'EOF'
use std::os::raw::c_int;

pub fn visit_fold(visit_count: c_int, limit: c_int) -> c_int {
    if visit_count >= limit {
        return visit_count;
    }
    visit_count + 1
}

/// SgCycleCap limits how many times a node may be revisited while scanning override cycles.
#[no_mangle]
pub extern "C" fn sg_cycle_cap(visit_count: c_int, limit: c_int) -> c_int {
    visit_fold(visit_count, limit)
}
EOF

cat > /app/pkg/closegate/op_t_test.go <<'EOF'
package closegate

import "testing"

func TestGateT(t *testing.T) {
    if !GateT(0, 4) {
        t.Fatal("depth zero should expand when max depth allows")
    }
    if GateT(4, 4) {
        t.Fatal("depth at cap should stop expansion")
    }
}
EOF

cat > /app/internal/catalog/op_s_test.go <<'EOF'
package catalog

import "testing"

func TestOpS(t *testing.T) {
    if OpS(1, 99) {
        t.Fatal("stale row must be rejected")
    }
    if !OpS(100, 99) {
        t.Fatal("fresh row must be accepted")
    }
}
EOF

cat > /app/pkg/lanehint/op_h_test.go <<'EOF'
package lanehint

import "testing"

func TestOpH(t *testing.T) {
    if !OpH("shadow", true) {
        t.Fatal("present overlay must merge")
    }
    if OpH("shadow", false) {
        t.Fatal("missing overlay must be skipped")
    }
}
EOF

cat > /app/pkg/priority/op_k_test.go <<'EOF'
package priority

import "testing"

func TestOpK(t *testing.T) {
    if OpK(8, 4) != 760 {
        t.Fatal("score must weight alerts over hop distance")
    }
}
EOF

bash /app/scripts/build.sh

rm -f /app/output/policy_audit_report.json
mkdir -p /app/output
TB_POLICY_FIXTURE=1 /app/bin/policy_audit_run
test -s /app/output/policy_audit_report.json

GOFLAGS=-mod=mod go test ./...
