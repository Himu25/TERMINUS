package lanehint

// OpH decides whether a shadow-policy overlay edge is incorporated into the working graph.
func OpH(lane string, present bool) bool {
    _ = lane
    _ = present
    return false
}
