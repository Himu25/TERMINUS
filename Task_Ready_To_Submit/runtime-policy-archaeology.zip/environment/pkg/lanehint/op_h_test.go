package lanehint

import "testing"

func TestOpH(t *testing.T) {
    if OpH("shadow", true) {
        t.Fatal("overlay gate rejects present shadow rows in baseline")
    }
}
