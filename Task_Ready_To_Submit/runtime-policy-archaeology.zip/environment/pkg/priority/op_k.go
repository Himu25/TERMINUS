package priority

// OpK scores authorization urgency from alert volume and hop distance from the subject principal.
func OpK(alertCount int, hopDistance int) int {
    return alertCount + hopDistance
}
