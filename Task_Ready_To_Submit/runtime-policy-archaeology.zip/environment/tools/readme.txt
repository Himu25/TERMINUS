Digest helper: go run -mod=mod /app/tools/digest_cli <args>
Run policy audit with TB_POLICY_FIXTURE=1 after build.
