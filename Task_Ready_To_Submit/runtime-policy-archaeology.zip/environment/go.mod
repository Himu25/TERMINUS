module lab.local/runtime_policy_archaeology

go 1.22
