package engine

import (
    "lab.local/runtime_policy_archaeology/internal/config"
    "lab.local/runtime_policy_archaeology/internal/cycletab"
    "lab.local/runtime_policy_archaeology/internal/edgefuse"
    "lab.local/runtime_policy_archaeology/internal/reach"
    "lab.local/runtime_policy_archaeology/internal/score"
    "lab.local/runtime_policy_archaeology/pkg/alert"
    "lab.local/runtime_policy_archaeology/pkg/graph"
)

type queueRow struct {
    Service       string `json:"service"`
    PriorityScore int    `json:"priority_score"`
    HopDistance   int    `json:"hop_distance"`
}

// Outcome is the folded counters for one pack replay.
type Outcome struct {
    RootService     string
    AffectedCount   int
    TransitiveDepth int
    ShadowMerged    int
    StaleDropped    int
    CycleNodes      int
    Queue           []queueRow
}

// Replay executes one incident pack through the policy audit pipeline.
func Replay(inc config.Incident, reg config.RegistryFile, runtime []graph.Edge, hints []config.SidecarHint, alerts []alert.Row) Outcome {
    merged := edgefuse.Merge(inc, reg, runtime, hints)
    walked := reach.Expand(inc.RootService, merged.Edges, inc.MaxDepth)
    ranked := score.Queue(walked.Affected, walked.Hops, alerts)
    cycles := cycletab.Count(merged.Edges, inc.CycleLimit)

    queue := make([]queueRow, len(ranked))
    for i, row := range ranked {
        queue[i] = queueRow{
            Service:       row.Service,
            PriorityScore: row.PriorityScore,
            HopDistance:   row.HopDistance,
        }
    }

    return Outcome{
        RootService:     inc.RootService,
        AffectedCount:   len(walked.Affected),
        TransitiveDepth: walked.MaxHop,
        ShadowMerged:    merged.ShadowMerged,
        StaleDropped:    merged.StaleDropped,
        CycleNodes:      cycles,
        Queue:           queue,
    }
}
