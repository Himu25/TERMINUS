package score

import (
    "sort"

    "lab.local/runtime_policy_archaeology/pkg/alert"
    "lab.local/runtime_policy_archaeology/pkg/priority"
)

type row struct {
    Service       string `json:"service"`
    PriorityScore int    `json:"priority_score"`
    HopDistance   int    `json:"hop_distance"`
}

// Queue builds the authorization decision ordering for granted principals.
func Queue(affected []string, hops map[string]int, alerts []alert.Row) []row {
    alertMap := map[string]int{}
    for _, item := range alerts {
        alertMap[item.Service] = item.Count
    }
    out := make([]row, 0, len(affected))
    for _, svc := range affected {
        hop := hops[svc]
        out = append(out, row{
            Service:       svc,
            PriorityScore: priority.OpK(alertMap[svc], hop),
            HopDistance:   hop,
        })
    }
    sort.Slice(out, func(i, j int) bool {
        if out[i].PriorityScore == out[j].PriorityScore {
            return out[i].Service < out[j].Service
        }
        return out[i].PriorityScore > out[j].PriorityScore
    })
    return out
}
