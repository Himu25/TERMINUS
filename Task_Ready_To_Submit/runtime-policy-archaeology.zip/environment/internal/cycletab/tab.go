package cycletab

import (
    "sort"

    "lab.local/runtime_policy_archaeology/pkg/graph"
    "lab.local/runtime_policy_archaeology/spanfold"
)

// Count tallies cyclic membership under the configured cap.
func Count(edges []graph.Edge, limit int) int {
    adj := make(map[string][]string)
    nodes := map[string]struct{}{}
    for _, e := range edges {
        adj[e.Provider] = append(adj[e.Provider], e.Consumer)
        nodes[e.Provider] = struct{}{}
        nodes[e.Consumer] = struct{}{}
    }
    cyclic := map[string]struct{}{}
    for start := range nodes {
        stack := []string{start}
        onPath := map[string]int{start: 0}

        var walk func(int)
        walk = func(pos int) {
            cur := stack[pos]
            for _, nxt := range adj[cur] {
                if idx, ok := onPath[nxt]; ok {
                    for i := idx; i <= pos; i++ {
                        cyclic[stack[i]] = struct{}{}
                    }
                    continue
                }
                onPath[nxt] = pos + 1
                stack = append(stack, nxt)
                walk(pos + 1)
                stack = stack[:len(stack)-1]
                delete(onPath, nxt)
            }
        }
        walk(0)
    }
    if len(cyclic) == 0 {
        return 0
    }
    acc := 0
    count := 0
    for range sortedKeys(cyclic) {
        acc = spanfold.CycleCap(acc, limit)
        if acc <= limit {
            count++
        }
    }
    return count
}

func sortedKeys(in map[string]struct{}) []string {
    keys := make([]string, 0, len(in))
    for k := range in {
        keys = append(keys, k)
    }
    sort.Strings(keys)
    return keys
}
