package config

import (
    "encoding/json"
    "fmt"
    "os"
    "path/filepath"
)

// Incident holds replay knobs for one pack.
type Incident struct {
    RunID           string `json:"run_id"`
    RootService     string `json:"subject_principal"`
    RegistryCutoff  int    `json:"registry_cutoff"`
    MaxDepth        int    `json:"max_depth"`
    CycleLimit      int    `json:"cycle_limit"`
}

// RegistryEdge is one catalog row with freshness metadata.
type RegistryEdge struct {
    Provider string `json:"provider"`
    Consumer string `json:"consumer"`
    AsOf     int    `json:"as_of"`
}

// RegistryFile is the on-disk catalog snapshot.
type RegistryFile struct {
    Edges []RegistryEdge `json:"edges"`
}

// SidecarHint is an overlay-only consumer link.
type SidecarHint struct {
    Provider string `json:"provider"`
    Consumer string `json:"consumer"`
    Lane     string `json:"lane"`
}

// LoadIncident reads incident.json from a pack directory.
func LoadIncident(packDir string) (Incident, error) {
    raw, err := os.ReadFile(filepath.Join(packDir, "incident.json"))
    if err != nil {
        return Incident{}, err
    }
    var inc Incident
    if err := json.Unmarshal(raw, &inc); err != nil {
        return Incident{}, err
    }
    if inc.RunID == "" || inc.RootService == "" {
        return Incident{}, fmt.Errorf("incident missing run_id or subject_principal")
    }
    if inc.MaxDepth <= 0 {
        inc.MaxDepth = 8
    }
    if inc.CycleLimit <= 0 {
        inc.CycleLimit = 2
    }
    return inc, nil
}

// LoadRegistry reads registry.json from a pack directory.
func LoadRegistry(packDir string) (RegistryFile, error) {
    raw, err := os.ReadFile(filepath.Join(packDir, "registry.json"))
    if err != nil {
        return RegistryFile{}, err
    }
    var reg RegistryFile
    if err := json.Unmarshal(raw, &reg); err != nil {
        return RegistryFile{}, err
    }
    return reg, nil
}
