// Report JSON for /app/output/policy_audit_report.json:
//
// schema_version — string, must be "1"
// run_id — string, echoes active pack name
// subject_principal — principal under audit named in incident.json
// granted_count — resources reachable through the effective policy chain
// chain_depth — maximum delegation hop from the subject among granted resources
// shadow_applied — shadow-policy edges incorporated into the working graph
// obsolete_dropped — catalog rows rejected below registry_cutoff (legacy engine)
// override_conflicts — principals flagged while scanning override cycles under cycle_limit
// decision_queue — array sorted by priority_score descending then service ascending;
//   each row carries service, priority_score, hop_distance
// digest_hex — lowercase hex SHA-256 of run_id|granted_count|chain_depth|shadow_applied|obsolete_dropped|override_conflicts|first_queue_service
//
// Root object contains only these keys.
//
// Replay merges registry rows passing freshness cutoff, runtime_edges.jsonl, and
// shadow_policies.jsonl when the overlay lane is present. Edges aim provider to consumer.
// Breadth-first expansion from subject_principal continues while depth stays below max_depth.
// Authorization priority_score is alertCount times one hundred minus hopDistance times ten.
// Override conflict tally revisits nodes through the spanfold cap helper using cycle_limit.
package main

import (
    "log"
    "os"

    "lab.local/runtime_policy_archaeology/internal/driver"
)

func main() {
    if os.Getenv("TB_POLICY_FIXTURE") != "1" {
        log.Fatal("TB_POLICY_FIXTURE unset or not 1")
    }
    rep, err := driver.RunActive("/app")
    if err != nil {
        log.Fatal(err)
    }
    if err := driver.EmitReport("/app/output/policy_audit_report.json", rep); err != nil {
        log.Fatal(err)
    }
}
