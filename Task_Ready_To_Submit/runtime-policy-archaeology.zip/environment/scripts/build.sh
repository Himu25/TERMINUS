#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1

mkdir -p /app/bin
cd /app/spanfold
cargo build --release --locked
cd /app
GOFLAGS=-mod=mod go build -trimpath -buildvcs=false -o /app/bin/policy_audit_run ./cmd/policy_audit_run
