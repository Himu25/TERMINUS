# replay layout

Each pack under `/app/data/replay/<name>/` carries:

- `incident.json` — run_id, subject_principal, registry_cutoff, max_depth, cycle_limit
- `registry.json` — catalog edges with as_of freshness
- `runtime_edges.jsonl` — observed provider-to-consumer rows
- `shadow_policies.jsonl` — overlay-only consumers (may be empty)
- `alerts.jsonl` — paging counts keyed by service name

Active replay uses `/app/data/active/` (copy of one pack). Driver reads only those filenames.

Build via `/app/scripts/build.sh`. Audit binary lands at `/app/bin/policy_audit_run`.
