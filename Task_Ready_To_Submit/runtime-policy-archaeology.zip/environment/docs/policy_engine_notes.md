# policy engine notes

Three evaluation layers feed the audit replay:

1. **Catalog** (`registry.json`) — versioned delegation rows with `as_of` freshness. Rows below `registry_cutoff` belong to the retired engine and must not widen the grant graph.
2. **Runtime grants** (`runtime_edges.jsonl`) — live provider-to-consumer edges observed at request time.
3. **Shadow policies** (`shadow_policies.jsonl`) — parallel rules that apply only when the shadow lane is present on the pack.

Override cycles are tallied through the spanfold cap helper using `cycle_limit` from `incident.json`. The authorization queue ranks downstream principals using paging counts from `alerts.jsonl`.
