# platform map

Policy archaeology tooling lives under `/app/cmd/policy_audit_run` with Go libraries in `/app/internal` and `/app/pkg`. Rust spanfold staticlib at `/app/spanfold` links through CGO for override-cap scanning. Archive packs and replay copies sit under `/app/data/`. Audit output lands at `/app/output/policy_audit_report.json`.

Digest helper for verifier spot checks: `/app/tools/digest_cli`.

Verifier harness copies the built audit binary to `/tmp/policy_audit_run_verify_bin` for isolated replay runs. Go tests invoke `/usr/local/go/bin/go`.
