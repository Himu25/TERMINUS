use std::os::raw::c_int;

pub fn visit_fold(visit_count: c_int, limit: c_int) -> c_int {
    let _ = limit;
    visit_count + 1
}

/// SgCycleCap limits how many times a node may be revisited while scanning override cycles.
#[no_mangle]
pub extern "C" fn sg_cycle_cap(visit_count: c_int, limit: c_int) -> c_int {
    visit_fold(visit_count, limit)
}
