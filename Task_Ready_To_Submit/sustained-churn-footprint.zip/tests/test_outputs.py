"""Verifier for sustained churn footprint task."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import zipfile
from pathlib import Path

APP = Path("/app")
OUT = Path("/app/output/stability.json")
NAMEPLATE = Path("/app/palette/load_profile.properties")
STEADY_PROFILE = Path("/app/workshop/ops/steady-profile.properties")
JAR_BUILD = Path("/app/m2/target/driver-r0.jar")
JAR_BIN = Path("/app/bin/driver-r0.jar")

_SESSION: tuple[dict, dict, str] | None = None


def _publish_jar_from_build() -> None:
    """Verifier must exercise the freshly packaged shaded jar, not a stale /app/bin copy."""
    if not JAR_BUILD.is_file():
        msg = f"missing shaded jar after mvn package: {JAR_BUILD}"
        raise AssertionError(msg)
    JAR_BIN.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(JAR_BUILD, JAR_BIN)


def _session() -> tuple[dict, dict, str]:
    """One full build plus two harness runs (paired-run contract for retained_slots)."""
    global _SESSION
    if _SESSION is not None:
        return _SESSION
    subprocess.run(
        ["mvn", "-q", "-f", "/app/pom.xml", "package"],
        check=True,
        cwd=str(APP),
        capture_output=True,
        text=True,
    )
    _publish_jar_from_build()
    subprocess.run(
        ["bash", "/app/bin/spin_once"],
        check=True,
        cwd=str(APP),
        capture_output=True,
        text=True,
    )
    first_row = json.loads(OUT.read_text())
    subprocess.run(
        ["bash", "/app/bin/spin_once"],
        check=True,
        cwd=str(APP),
        capture_output=True,
        text=True,
    )
    second_row = json.loads(OUT.read_text())
    raw_line = OUT.read_text()
    _SESSION = (first_row, second_row, raw_line)
    return _SESSION


def _read_properties(path: Path) -> dict[str, str]:
    props: dict[str, str] = {}
    text = path.read_text(encoding="utf-8")
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        key, sep, val = line.partition("=")
        if not sep:
            continue
        props[key.strip()] = val.strip()
    return props


def _read_nameplate() -> dict[str, str]:
    return _read_properties(NAMEPLATE)


def _steady_profile() -> dict[str, str]:
    assert STEADY_PROFILE.is_file(), f"missing steady profile: {STEADY_PROFILE}"
    return _read_properties(STEADY_PROFILE)


def _jar_entries(jar: Path) -> list[str]:
    with zipfile.ZipFile(jar) as archive:
        return archive.namelist()


def _jar_simple_names(jar: Path = JAR_BUILD) -> set[str]:
    prefix = "io" + "/" + "arc" + "/"
    return {
        ln[len(prefix) : -len(".class")]
        for ln in _jar_entries(jar)
        if ln.startswith(prefix) and ln.endswith(".class")
    }


def _spin_once_proc() -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["bash", "/app/bin/spin_once"],
        check=True,
        cwd=str(APP),
        capture_output=True,
        text=True,
    )


def _assert_nameplate_echo_layers_drives_echo_span(
    *,
    cycles: int,
    echo_layers: int,
    expected_echo_span: int,
) -> None:
    """Prove the driver parses live palette knobs, not hard-coded echo_span."""
    original = NAMEPLATE.read_text(encoding="utf-8")
    try:
        NAMEPLATE.write_text(
            f"cycles={cycles}\necho_layers={echo_layers}\n",
            encoding="utf-8",
        )
        _spin_once_proc()
        row = json.loads(OUT.read_text(encoding="utf-8"))
        assert row["echo_span"] == expected_echo_span
        assert row["cycles_completed"] == cycles
    finally:
        NAMEPLATE.write_text(original, encoding="utf-8")


def _assert_flat_scalars(value: object, trail: str) -> None:
    if isinstance(value, dict):
        for key, nested in value.items():
            _assert_flat_scalars(nested, f"{trail}.{key}")
        return
    if isinstance(value, list):
        for idx, nested in enumerate(value):
            _assert_flat_scalars(nested, f"{trail}[{idx}]")
        return
    assert not isinstance(value, (dict, list)), f"nested container at {trail}"


def _manifest_main_class(jar: Path) -> str:
    manifest_entry = "META" + "-INF" + "/" + "MANIFEST.MF"
    with zipfile.ZipFile(jar) as archive:
        text = archive.read(manifest_entry).decode("utf-8", errors="replace")
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    folded: list[str] = []
    for raw in text.split("\n"):
        line = raw.rstrip()
        if line.startswith(" ") and folded:
            folded[-1] += line[1:].strip()
        elif line:
            folded.append(line)
    for entry in folded:
        if entry.lower().startswith("main-class:"):
            return entry.split(":", 1)[1].strip()
    return ""


def _driver_fqcn_from_overview() -> str:
    overview = Path("/app/workshop/docs/overview.md").read_text(encoding="utf-8")
    match = re.search(r"io/arc/([A-Za-z0-9_]+)\.class", overview)
    if match is None:
        msg = "overview must name a driver entry class path under io/arc/"
        raise AssertionError(msg)
    return "io.arc." + match.group(1)


def test_stability_artifact_emitted() -> None:
    """Loader must emit the stability artifact under /app/output/."""
    _session()
    assert OUT.is_file()


def test_stability_json_key_surface_exact() -> None:
    """JSON must use exactly the documented snake_case surface."""
    _first, second_row, _raw = _session()
    allowed = {
        "closure_state",
        "replay_integrity",
        "foreign_joins_cleared",
        "echo_span",
        "retained_slots",
        "cycles_completed",
    }
    assert set(second_row.keys()) == allowed


def test_stability_json_single_line_compact() -> None:
    """Driver writes a compact single-line JSON object."""
    _first, _second, raw_line = _session()
    body = raw_line.rstrip("\n")
    assert "\n" not in body


def test_steady_state_string_metrics() -> None:
    """Green pass must emit the steady string tokens documented in overview.md."""
    _first, second_row, _raw = _session()
    assert second_row["closure_state"] == "sealed"
    assert second_row["replay_integrity"] == "aligned"
    assert second_row["foreign_joins_cleared"] == "yes"


def test_echo_span_follows_live_nameplate_echo_layers() -> None:
    """echo_span must follow twice the on-disk echo_layers (nameplate vs JSON must agree)."""
    props = _read_nameplate()
    echo_layers = int(props["echo_layers"])
    _first, second_row, _raw = _session()
    assert second_row["echo_span"] == echo_layers * 2
    steady = _steady_profile()
    cycles = int(steady["cycles"])
    _assert_nameplate_echo_layers_drives_echo_span(
        cycles=cycles, echo_layers=5, expected_echo_span=10
    )


def test_cycles_completed_matches_nameplate_cycles() -> None:
    """cycles_completed mirrors the nameplate cycle knob."""
    props = _read_nameplate()
    cycles = int(props["cycles"])
    _first, second_row, _raw = _session()
    assert second_row["cycles_completed"] == cycles


def test_retained_slots_drained_to_zero() -> None:
    """Steady pass drains pool and echo-tracker so retained_slots hits zero."""
    _first, second_row, _raw = _session()
    assert int(second_row["retained_slots"]) == 0


def test_spin_once_launcher_invokes_shaded_jar() -> None:
    """Reject solutions that replace /app/bin/spin_once with a static JSON writer."""
    _session()
    launcher = Path("/app/bin/spin_once")
    assert launcher.is_file()
    text = launcher.read_text(encoding="utf-8")
    assert "#!/bin/sh" in text
    assert "mkdir -p /app/output" in text
    assert "exec java -jar /app/bin/driver-r0.jar" in text


def test_shaded_jar_contains_overview_entry_class() -> None:
    """Confirm the published artifact is a Java jar with the harness entry class."""
    _session()
    assert "io/arc/EntryPulse.class" in _jar_entries(JAR_BUILD)


def test_nameplate_matches_steady_profile() -> None:
    """Palette must match workshop steady profile; echo_layers must not be stale."""
    steady = _steady_profile()
    props = _read_nameplate()
    assert props.get("cycles") == steady.get("cycles")
    assert props.get("echo_layers") == steady.get("echo_layers")
    assert int(steady["cycles"]) > 0
    assert int(steady["echo_layers"]) > 0


def test_back_to_back_loader_rows_identical() -> None:
    """Two successful loader invocations must be deterministic on the emitted contract."""
    first_row, second_row, _raw = _session()
    assert first_row == second_row


def test_numeric_metrics_are_json_integers() -> None:
    """Integer metrics must not be quoted strings in the stability line."""
    _first, second_row, _raw = _session()
    assert isinstance(second_row["echo_span"], int)
    assert isinstance(second_row["retained_slots"], int)
    assert isinstance(second_row["cycles_completed"], int)


def test_manifest_main_class_matches_overview() -> None:
    """Manifest entry must match the overview driver path rule in instruction.md."""
    _session()
    assert _manifest_main_class(JAR_BUILD) == _driver_fqcn_from_overview()


def test_shaded_jar_bundles_required_io_arc_types() -> None:
    """Fat jar must retain lane, pool, vault, ledger, and helper types from overview."""
    _session()
    names = _jar_simple_names()
    required = {
        "EntryPulse",
        "ShuttleLane",
        "RelayUnit",
        "FrameKernel",
        "HopIndex",
        "SliceVault",
        "VisitorLedger",
        "MarginTable",
        "CohortMixer",
        "TokenStrip",
        "TallySink",
        "EchoTracker",
    }
    missing = required - names
    assert not missing, f"missing shaded types: {sorted(missing)}"
    assert len(names) >= 10


def test_stability_line_has_no_trailing_payload() -> None:
    """Overwrite contract: single JSON object line with no trailing noise."""
    _first, _second, raw_line = _session()
    body = raw_line.rstrip("\n")
    assert body.startswith("{") and body.endswith("}")
    assert not re.search(r"}\s*[^\s]", body)


def test_stability_json_values_are_flat_scalars() -> None:
    """Stability document must be a flat scalar map after json.loads."""
    _first, second_row, _raw = _session()
    for _key, val in second_row.items():
        assert not isinstance(val, (dict, list))
    tree = json.loads(OUT.read_text(encoding="utf-8"))
    _assert_flat_scalars(tree, "root")


def test_shade_output_matches_published_jar_bytes() -> None:
    """Build tree shade jar must match the published /app/bin copy byte-for-byte."""
    _session()
    built = JAR_BUILD.read_bytes()
    published = JAR_BIN.read_bytes()
    assert built == published
    assert len(built) > 0


def test_loader_exits_without_retention_abort() -> None:
    """In-process dual-wave guard must not abort before writing stability.json."""
    _session()
    proc = _spin_once_proc()
    assert proc.returncode == 0
    assert "retention grew between replay waves" not in (proc.stderr or "")
    assert OUT.is_file()


def test_each_spin_once_overwrites_single_json_line() -> None:
    """Each successful loader run replaces the artifact; never append a second JSON line."""
    _session()
    for _ in range(3):
        _spin_once_proc()
    raw = OUT.read_text(encoding="utf-8")
    lines = [ln for ln in raw.splitlines() if ln.strip()]
    assert len(lines) == 1
    parsed = json.loads(lines[0])
    assert parsed["retained_slots"] == 0


def test_nameplate_path_env_resolves_palette_file() -> None:
    """NAMEPLATE_PATH from the image must resolve to the operator pacing file."""
    steady = _steady_profile()
    bound = os.environ.get("NAMEPLATE_PATH", "").strip()
    assert bound == str(NAMEPLATE)
    assert NAMEPLATE.is_file()
    props = _read_nameplate()
    assert props["cycles"] == steady["cycles"]
    assert props["echo_layers"] == steady["echo_layers"]


def test_steady_numeric_triplet_matches_nameplate() -> None:
    """retained_slots zero; echo_span and cycles_completed track live nameplate knobs."""
    props = _read_nameplate()
    _first, second_row, _raw = _session()
    assert int(second_row["retained_slots"]) == 0
    assert second_row["cycles_completed"] == int(props["cycles"])
    assert second_row["echo_span"] == int(props["echo_layers"]) * 2


def test_spin_once_writes_stability_after_fresh_build() -> None:
    """Harness launcher must drive the shaded jar and emit a steady stability line."""
    _session()
    if OUT.exists():
        OUT.unlink()
    proc = _spin_once_proc()
    assert proc.returncode == 0
    assert OUT.is_file()
    row = json.loads(OUT.read_text(encoding="utf-8"))
    assert row["retained_slots"] == 0
    assert row["closure_state"] == "sealed"
