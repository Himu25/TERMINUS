#!/bin/bash
set -euo pipefail

# Terminal-Bench Canary: solver-side fix script

log_line() {
  printf '[oracle] %s\n' "$1"
}

require_file() {
  local p="$1"
  if [[ ! -f "$p" ]]; then
    log_line "missing expected file: $p"
    exit 1
  fi
}

rewrite_hop_index() {
  log_line "rewriting hop index at /app/m2/src/main/java/io/arc/HopIndex.java"
  require_file "/app/m2/src/main/java/io/arc/HopIndex.java"
  cat > /app/m2/src/main/java/io/arc/HopIndex.java <<'JAVA'
package io.arc;

public final class HopIndex {

    private HopIndex() {}

    public static String tag(int hop, int seq) {
        return "h" + hop + "-s" + seq;
    }

    public static void resetObserved() {
        /* steady path does not count hop tags toward retention */
    }
}
JAVA
  log_line "hop index rewrite bytes $(wc -c < /app/m2/src/main/java/io/arc/HopIndex.java)"
}

rewrite_token_strip() {
  log_line "rewriting token strip at /app/m2/src/main/java/io/arc/TokenStrip.java"
  require_file "/app/m2/src/main/java/io/arc/TokenStrip.java"
  cat > /app/m2/src/main/java/io/arc/TokenStrip.java <<'JAVA'
package io.arc;

public final class TokenStrip {

    private TokenStrip() {}

    public static String stripNoise(String in) {
        return in.replaceAll("[^a-zA-Z0-9_-]", "");
    }

    public static void resetAdopted() {
        /* steady path does not retain adopted tokens */
    }
}
JAVA
  log_line "token strip rewrite bytes $(wc -c < /app/m2/src/main/java/io/arc/TokenStrip.java)"
}

rewrite_relay() {
  log_line "rewriting bind pool at /app/m2/src/main/java/io/arc/RelayUnit.java"
  require_file "/app/m2/src/main/java/io/arc/RelayUnit.java"
  cat > /app/m2/src/main/java/io/arc/RelayUnit.java <<'JAVA'
package io.arc;

import java.util.concurrent.ConcurrentHashMap;

public final class RelayUnit {

    private static final ConcurrentHashMap<String, byte[]> HOLD = new ConcurrentHashMap<>();

    private RelayUnit() {}

    public static void bind(String k, byte[] raw) {
        HOLD.put(k, raw);
    }

    public static void drop(String k) {
        HOLD.remove(k);
    }

    public static int activeCount() {
        return HOLD.size();
    }

    public static void purgeArchive() {
        /* no archive side map on steady path */
    }
}
JAVA
  log_line "relay pool rewrite bytes $(wc -c < /app/m2/src/main/java/io/arc/RelayUnit.java)"
}

rewrite_frame() {
  log_line "rewriting frame kernel at /app/m2/src/main/java/io/arc/FrameKernel.java"
  require_file "/app/m2/src/main/java/io/arc/FrameKernel.java"
  cat > /app/m2/src/main/java/io/arc/FrameKernel.java <<'JAVA'
package io.arc;

public final class FrameKernel {

    private FrameKernel() {}

    public static int touch(byte[] raw) {
        int acc = 0;
        for (int i = 0; i < raw.length; i++) {
            acc += raw[i] & 0xff;
        }
        return acc & 0xffff;
    }

    public static void releasePins() {
        /* steady path does not retain frame payloads */
    }
}
JAVA
  log_line "frame kernel rewrite bytes $(wc -c < /app/m2/src/main/java/io/arc/FrameKernel.java)"
}

rewrite_shuttle() {
  log_line "rewriting shuttle lane completion at /app/m2/src/main/java/io/arc/ShuttleLane.java"
  require_file "/app/m2/src/main/java/io/arc/ShuttleLane.java"
  cat > /app/m2/src/main/java/io/arc/ShuttleLane.java <<'JAVA'
package io.arc;

public final class ShuttleLane {

    private final VisitorLedger ledger = new VisitorLedger();

    public void passThrough(String k, byte[] raw) {
        ledger.signal();
        RelayUnit.bind(k, raw);
        FrameKernel.touch(raw);
        RelayUnit.drop(k);
        ledger.ack();
    }

    public VisitorLedger ledger() {
        return ledger;
    }
}
JAVA
  log_line "shuttle rewrite bytes $(wc -c < /app/m2/src/main/java/io/arc/ShuttleLane.java)"
}

rewrite_nameplate() {
  log_line "rewriting load nameplate at /app/palette/load_profile.properties"
  require_file "/app/palette/load_profile.properties"
  cat > /app/palette/load_profile.properties <<'PROP'
cycles=80
echo_layers=4
PROP
  log_line "nameplate now lists $(grep -c '=' /app/palette/load_profile.properties || true) non-empty assignments"
}

rewrite_driver() {
  log_line "rewriting entry pulse at /app/m2/src/main/java/io/arc/EntryPulse.java"
  require_file "/app/m2/src/main/java/io/arc/EntryPulse.java"
  cat > /app/m2/src/main/java/io/arc/EntryPulse.java <<'JAVA'
package io.arc;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

/** Writes the stability JSON document for the harness. */
public final class EntryPulse {

    public static final String EXPORT_CLOSURE_STEADY = "sealed";
    public static final String EXPORT_CLOSURE_HOT = "open";
    public static final String EXPORT_REPLAY_ALIGNED = "aligned";
    public static final String EXPORT_REPLAY_SKEWED = "skewed";
    public static final String EXPORT_FOREIGN_YES = "yes";
    public static final String EXPORT_FOREIGN_NO = "no";
    public static final int REGRESSION_ECHO_SPAN = 8;
    public static final int REGRESSION_CYCLES = 80;

    private EntryPulse() {}

    public static void main(String[] args) throws IOException {
        Path nameplate = Path.of(System.getenv().getOrDefault("NAMEPLATE_PATH", "/app/palette/load_profile.properties"));
        Properties props = readNameplate(nameplate);
        assertNameplateKeys(props);
        int cycles = readIntProp(props, "cycles", "40");
        int echoLayers = readIntProp(props, "echo_layers", "1");
        assertPositiveCycles(cycles);
        assertEchoLayersBounded(echoLayers, REGRESSION_ECHO_SPAN * 4);
        ShuttleLane lane1 = new ShuttleLane();
        z7QkStiltMux(lane1, 0, cycles, echoLayers);
        waveDrain();
        int retainedAfterFirstWave = RelayUnit.activeCount();

        ShuttleLane lane2 = new ShuttleLane();
        z7QkStiltMux(lane2, 1, cycles, echoLayers);
        waveDrain();
        int retainedAfterSecondWave = RelayUnit.activeCount();

        if (retainedAfterSecondWave > retainedAfterFirstWave) {
            throw new IllegalStateException("retention grew between replay waves in the same JVM");
        }

        if (lane1.ledger().openedCount() != cycles || lane2.ledger().openedCount() != cycles) {
            throw new IllegalStateException("replay waves did not run full cycle volume");
        }
        if (!lane1.ledger().balanced() || !lane2.ledger().balanced()) {
            throw new IllegalStateException("visitor ledger not balanced across replay waves");
        }

        int echoSpan = echoLayers * 2;
        boolean poolEmpty = RelayUnit.activeCount() == 0;
        boolean ledgerOk = lane2.ledger().balanced();
        String foreign = poolEmpty ? EXPORT_FOREIGN_YES : EXPORT_FOREIGN_NO;
        String replay = ledgerOk ? EXPORT_REPLAY_ALIGNED : EXPORT_REPLAY_SKEWED;
        String closure = poolEmpty && ledgerOk ? EXPORT_CLOSURE_STEADY : EXPORT_CLOSURE_HOT;
        int retained = RelayUnit.activeCount();
        Map<String, Object> doc = assembleDoc(closure, replay, foreign, echoSpan, retained, cycles);
        Path out = Path.of("/app/output/stability.json");
        emitJson(out, doc);
    }

    private static Properties readNameplate(Path p) throws IOException {
        Properties props = new Properties();
        try (var in = Files.newInputStream(p)) {
            props.load(in);
        }
        return props;
    }

    private static int readIntProp(Properties props, String key, String defVal) {
        return Integer.parseInt(props.getProperty(key, defVal).trim());
    }

    private static void assertNameplateKeys(Properties props) {
        if (!props.containsKey("cycles") || !props.containsKey("echo_layers")) {
            throw new IllegalStateException("palette profile missing required knobs for relay pacing");
        }
    }

    private static void assertPositiveCycles(int cycles) {
        if (cycles < 1) {
            throw new IllegalArgumentException("cycles below minimum for a replay scenario");
        }
        if (cycles > REGRESSION_CYCLES + 256) {
            throw new IllegalArgumentException("cycles above guardrail for operator stress sweep");
        }
    }

    private static void assertEchoLayersBounded(int echoLayers, int maxLayers) {
        if (echoLayers < 1) {
            throw new IllegalArgumentException("echo_layers below minimum depth");
        }
        if (echoLayers > maxLayers) {
            throw new IllegalArgumentException("echo_layers beyond configured round-trip fan-out limit");
        }
    }

    private static void waveDrain() {
        FrameKernel.releasePins();
        HopIndex.resetObserved();
        TokenStrip.resetAdopted();
        RelayUnit.purgeArchive();
        CohortMixer.releaseWave();
        TallySink.flush();
    }

    private static void z7QkStiltMux(ShuttleLane lane, int hop, int cycles, int echoLayers) {
        for (int i = 0; i < cycles; i++) {
            String k = HopIndex.tag(hop, i);
            byte[] raw = SliceVault.sliceOf(64, i + echoLayers * 31);
            lane.passThrough(k, raw);
        }
    }

    private static Map<String, Object> assembleDoc(
            String closure, String replay, String foreign, int echoSpan, int retained, int cycles) {
        Map<String, Object> doc = new LinkedHashMap<>();
        doc.put("closure_state", closure);
        doc.put("replay_integrity", replay);
        doc.put("foreign_joins_cleared", foreign);
        doc.put("echo_span", echoSpan);
        doc.put("retained_slots", retained);
        doc.put("cycles_completed", cycles);
        return doc;
    }

    private static void emitJson(Path out, Map<String, Object> doc) throws IOException {
        Files.createDirectories(out.getParent());
        Files.writeString(out, encodeMap(doc), StandardCharsets.UTF_8);
    }

    private static String encodeMap(Map<String, Object> doc) {
        StringBuilder sb = new StringBuilder();
        sb.append('{');
        boolean first = true;
        for (Map.Entry<String, Object> e : doc.entrySet()) {
            if (!first) {
                sb.append(',');
            }
            first = false;
            sb.append('"').append(e.getKey()).append("\":");
            Object v = e.getValue();
            if (v instanceof Integer) {
                sb.append(v);
            } else {
                sb.append('"').append(quoteText((String) v)).append('"');
            }
        }
        sb.append('}');
        return sb.toString();
    }

    private static String quoteText(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
JAVA
  log_line "driver rewrite bytes $(wc -c < /app/m2/src/main/java/io/arc/EntryPulse.java)"
}

remove_shadow_queue() {
  local shadow_path="/app/m2/src/main/java/io/arc/ShadowQueue.java"
  if [[ -f "$shadow_path" ]]; then
    log_line "removing auxiliary retention helper at $shadow_path"
    rm -f "$shadow_path"
  else
    log_line "aux retention file already absent"
  fi
}

rebuild_bundle() {
  log_line "running mvn package from /app/pom.xml with tests skipped for speed"
  mvn -q -f /app/pom.xml -DskipTests package
  require_file "/app/m2/target/driver-r0.jar"
  local sz
  sz="$(wc -c < /app/m2/target/driver-r0.jar)"
  log_line "shade jar size ${sz} bytes"
  install -m 0644 /app/m2/target/driver-r0.jar /app/bin/driver-r0.jar
  log_line "published shaded jar to /app/bin/driver-r0.jar"
}

smoke_load() {
  log_line "running /app/bin/spin_once for a deterministic smoke pass"
  mkdir -p /app/output
  bash /app/bin/spin_once
  require_file "/app/output/stability.json"
  log_line "stability artifact present after smoke"
}

verify_graph_roots() {
  log_line "checking required module roots before edits"
  local roots=(
    "/app/pom.xml"
    "/app/m2/pom.xml"
    "/app/m2/pom.xml"
    "/app/m2/src/main/java/io/arc/EntryPulse.java"
    "/app/m2/src/main/java/io/arc/ShuttleLane.java"
    "/app/palette/load_profile.properties"
    "/app/bin/spin_once"
  )
  local p
  for p in "${roots[@]}"; do
    if [[ ! -e "$p" ]]; then
      log_line "missing graph vertex: $p"
      exit 1
    fi
    if [[ -d "$p" ]]; then
      log_line "expected file but found directory: $p"
      exit 1
    fi
  done
  log_line "module graph roots present (${#roots[@]} paths)"
}

verify_shaded_manifest() {
  log_line "verifying shaded jar manifest and entry class"
  require_file "/app/m2/target/driver-r0.jar"
  local sz
  sz="$(wc -c < /app/m2/target/driver-r0.jar)"
  if [[ "$sz" -lt 1024 ]]; then
    log_line "shaded jar unexpectedly small: ${sz} bytes"
    exit 1
  fi
  local mc
  mc="$(unzip -p /app/m2/target/driver-r0.jar META-INF/MANIFEST.MF 2>/dev/null | tr -d '\r' | grep '^Main-Class:' || true)"
  if [[ -z "$mc" ]]; then
    log_line "missing Main-Class in shaded manifest"
    exit 1
  fi
  if ! jar tf /app/m2/target/driver-r0.jar | grep -q '^io/arc/EntryPulse.class$'; then
    log_line "missing EntryPulse class inside shaded jar"
    exit 1
  fi
  log_line "shaded manifest ok; jar bytes ${sz}"
}

log_line "starting sustained churn footprint oracle"
require_file "/app/pom.xml"
require_file "/app/bin/spin_once"
verify_graph_roots
rewrite_hop_index
rewrite_token_strip
rewrite_relay
rewrite_frame
rewrite_shuttle
rewrite_nameplate
rewrite_driver
remove_shadow_queue
rebuild_bundle
verify_shaded_manifest
smoke_load
log_line "oracle sustained churn footprint refresh finished"
