# Ingest sidecar

This workspace hosts the ingest sidecar sources plus the load nameplate.
Runtime wiring lives under `/app` in the container with the multi-module build at the repo root.

After `mvn package`, the shaded fat jar is `/app/m2/target/driver-r0.jar`; published images copy it to `/app/bin/driver-r0.jar` next to `spin_once`. The archive lists `io/arc/EntryPulse.class` as the driver entry type and also ships `io/arc/ShuttleLane.class` and `io/arc/RelayUnit.class` for the visitor lane and bind pool wiring.

Each loader JVM pass replays two back-to-back waves with different hop ids so the relay pool sees disjoint bind keys across waves; retention that only clears on process exit cannot satisfy the in-process guard.

The operator pacing profile under `/app/palette/load_profile.properties` must expose `cycles` and `echo_layers` keys the driver reads at startup. Reconcile those knobs against `/app/workshop/ops/steady-profile.properties` before declaring green.

## Stability JSON field names

The loader writes `/app/output/stability.json` with keys `closure_state`, `replay_integrity`, `foreign_joins_cleared`, `echo_span`, `retained_slots`, and `cycles_completed`.

## Steady-state contract

On a green build after footprint work completes, `closure_state` is `sealed`, `replay_integrity` is `aligned`, and `foreign_joins_cleared` is `yes`. The `retained_slots` integer must reach zero. The `cycles_completed` integer must match the nameplate `cycles` value. The `echo_span` integer must follow the echo depth the driver derives from nameplate `echo_layers` (see the driver export path for the exact relationship).

The dual-wave in-process guard compares aggregate hold depth across every store the driver folds into its combined retention tally before metrics are written. Steady export requires each contributor to drain within the same JVM pass; tracing which subsystems still hold bytes after a wave is part of the repair work.
