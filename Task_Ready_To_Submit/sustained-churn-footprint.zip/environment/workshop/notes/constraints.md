Operational constraints for the ingest sidecar:

- JVM service runs under the container workdir `/app`.
- Synthetic drivers are packaged as shell entrypoints beside the shaded runner jar.
- The reactor POM for local builds is `/app/pom.xml`.
- The nameplate defaults through `NAMEPLATE_PATH` in the image; see the Dockerfile for the default path.
- Steady green export expects the palette pacing file to match `/app/workshop/ops/steady-profile.properties`.
