# Operator triage

RSS-only dashboards miss per-generation churn. Pair heap dumps with the harness JSON under `/app/output/stability.json` when escalating.
