Cross-wave retention compares aggregated hold totals at each wave boundary. Steady runs require every contributor to that aggregate to return to zero before export.

The driver folds relay pool occupancy, archive side-map depth, shadow queue depth, frame diagnostic pins, hop tag observations, and token adoptions into the same hold total used for the wave guard and the `retained_slots` export.
