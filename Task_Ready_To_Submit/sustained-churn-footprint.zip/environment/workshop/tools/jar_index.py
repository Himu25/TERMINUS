"""Workshop helper for listing shaded jar entries without invoking the jar CLI."""

from __future__ import annotations

import zipfile
from pathlib import Path


def list_entries(jar_path: Path) -> list[str]:
    with zipfile.ZipFile(jar_path) as archive:
        return archive.namelist()
