package io.arc;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Writes the stability JSON document for the harness.
 */
public final class EntryPulse {

    public static final String EXPORT_CLOSURE_STEADY = "sealed";
    public static final String EXPORT_CLOSURE_HOT = "open";
    public static final String EXPORT_REPLAY_ALIGNED = "aligned";
    public static final String EXPORT_REPLAY_SKEWED = "skewed";
    public static final String EXPORT_FOREIGN_YES = "yes";
    public static final String EXPORT_FOREIGN_NO = "no";
    public static final int REGRESSION_ECHO_SPAN = 8;
    public static final int REGRESSION_CYCLES = 80;

    private EntryPulse() {}

    public static void main(String[] args) throws IOException {
        Path nameplate = Path.of(System.getenv().getOrDefault("NAMEPLATE_PATH", "/app/palette/load_profile.properties"));
        Properties props = new Properties();
        try (var in = Files.newInputStream(nameplate)) {
            props.load(in);
        }
        int cycles = Integer.parseInt(props.getProperty("cycles", "40").trim());
        int echoLayers = Integer.parseInt(props.getProperty("echo_layers", "1").trim());

        ShuttleLane lane1 = new ShuttleLane();
        z7QkStiltMux(lane1, 0, cycles, echoLayers);
        int retainedAfterFirstWave = q4HoldTotal();

        ShuttleLane lane2 = new ShuttleLane();
        z7QkStiltMux(lane2, 1, cycles, echoLayers);
        int retainedAfterSecondWave = q4HoldTotal();

        if (retainedAfterSecondWave > retainedAfterFirstWave) {
            throw new IllegalStateException("retention grew between replay waves in the same JVM");
        }

        if (lane1.ledger().openedCount() != cycles || lane2.ledger().openedCount() != cycles) {
            throw new IllegalStateException("replay waves did not run full cycle volume");
        }
        if (!lane1.ledger().balanced() || !lane2.ledger().balanced()) {
            throw new IllegalStateException("visitor ledger not balanced across replay waves");
        }

        int echoSpan = echoLayers * 2;
        boolean poolEmpty = RelayUnit.activeCount() == 0;
        boolean ledgerOk = lane2.ledger().balanced();
        boolean shadowEmpty = ShadowQueue.depth() == 0;
        String foreign = poolEmpty ? EXPORT_FOREIGN_YES : EXPORT_FOREIGN_NO;
        String replay = ledgerOk ? EXPORT_REPLAY_ALIGNED : EXPORT_REPLAY_SKEWED;
        String closure = poolEmpty && ledgerOk && shadowEmpty ? EXPORT_CLOSURE_STEADY : EXPORT_CLOSURE_HOT;
        int retained = q4HoldTotal();

        Map<String, Object> doc = new LinkedHashMap<>();
        doc.put("closure_state", closure);
        doc.put("replay_integrity", replay);
        doc.put("foreign_joins_cleared", foreign);
        doc.put("echo_span", echoSpan);
        doc.put("retained_slots", retained);
        doc.put("cycles_completed", cycles);

        Path out = Path.of("/app/output/stability.json");
        Files.createDirectories(out.getParent());
        String json = encodeMap(doc);
        Files.writeString(out, json, StandardCharsets.UTF_8);
    }

    private static int q4HoldTotal() {
        return RelayUnit.activeCount()
                + RelayUnit.z9ArcDepth()
                + ShadowQueue.depth()
                + FrameKernel.w2PinDepth()
                + HopIndex.observeDepth()
                + TokenStrip.adoptedDepth()
                + CohortMixer.cohortDepth()
                + TallySink.pendingDepth();
    }

    private static void z7QkStiltMux(ShuttleLane lane, int hop, int cycles, int echoLayers) {
        for (int i = 0; i < cycles; i++) {
            EchoTracker.notePass();
            String k = HopIndex.tag(hop, i);
            byte[] raw = SliceVault.sliceOf(64, i + echoLayers * 31);
            lane.passThrough(k, raw);
            ShadowQueue.remember(i, raw);
            CohortMixer.noteHop(hop, k);
            TallySink.stage(i + hop * 100_000, raw);
        }
    }

    private static String encodeMap(Map<String, Object> doc) {
        StringBuilder sb = new StringBuilder();
        sb.append('{');
        boolean first = true;
        for (Map.Entry<String, Object> e : doc.entrySet()) {
            if (!first) {
                sb.append(',');
            }
            first = false;
            sb.append('"').append(e.getKey()).append("\":");
            Object v = e.getValue();
            if (v instanceof Integer) {
                sb.append(v);
            } else {
                sb.append('"').append(quoteText((String) v)).append('"');
            }
        }
        sb.append('}');
        return sb.toString();
    }

    private static String quoteText(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
