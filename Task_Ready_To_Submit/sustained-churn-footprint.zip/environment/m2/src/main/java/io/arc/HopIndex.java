package io.arc;

import java.util.HashSet;
import java.util.Set;

public final class HopIndex {

    private static final Set<String> OBSERVED = new HashSet<>();

    private HopIndex() {}

    public static String tag(int hop, int seq) {
        String k = "h" + hop + "-s" + seq;
        OBSERVED.add(k);
        return k;
    }

    public static int observeDepth() {
        return OBSERVED.size();
    }
}
