package io.arc;

public final class SliceVault {

    private SliceVault() {}

    public static byte[] sliceOf(int len, int seed) {
        byte[] out = new byte[len];
        int x = seed & 0xffff;
        for (int i = 0; i < len; i++) {
            x = (x * 1103515245 + 12345) & 0x7fffffff;
            out[i] = (byte) (x & 0xff);
        }
        return out;
    }
}
