package io.arc;

import java.util.concurrent.ConcurrentHashMap;

public final class RelayUnit {

    private static final ConcurrentHashMap<String, byte[]> HOLD = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<String, byte[]> ARCHIVE = new ConcurrentHashMap<>();

    private RelayUnit() {}

    public static void bind(String k, byte[] raw) {
        HOLD.put(k, raw);
        ARCHIVE.put(k, raw);
    }

    public static void drop(String k) {
        HOLD.remove(k);
    }

    public static int activeCount() {
        return HOLD.size();
    }

    public static int z9ArcDepth() {
        return ARCHIVE.size();
    }
}
