package io.arc;

public final class ShuttleLane {

    private final VisitorLedger ledger = new VisitorLedger();

    public void passThrough(String k, byte[] raw) {
        ledger.signal();
        TokenStrip.adopt(k);
        RelayUnit.bind(k, raw);
        FrameKernel.touch(raw);
    }

    public VisitorLedger ledger() {
        return ledger;
    }
}
