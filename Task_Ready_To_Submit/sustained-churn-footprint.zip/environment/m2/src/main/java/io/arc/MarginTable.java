package io.arc;

public final class MarginTable {

    private MarginTable() {}

    public static int widen(int v, int margin) {
        return v + margin * 17;
    }
}
