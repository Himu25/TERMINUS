package io.arc;

import java.util.ArrayList;
import java.util.List;

public final class TallySink {

    private static final List<int[]> STAGED = new ArrayList<>();

    private TallySink() {}

    public static int absorb(int[] vals) {
        int t = 0;
        for (int v : vals) {
            t += v;
        }
        return t;
    }

    public static void stage(int cycle, byte[] raw) {
        STAGED.add(new int[] {cycle, raw.length});
    }

    public static int pendingDepth() {
        return STAGED.size();
    }

    public static void flush() {
        STAGED.clear();
    }
}
