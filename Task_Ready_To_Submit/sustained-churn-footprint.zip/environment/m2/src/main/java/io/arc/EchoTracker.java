package io.arc;

public final class EchoTracker {

    private static int passes;

    private EchoTracker() {}

    public static void notePass() {
        passes++;
    }

    public static int passesSeen() {
        return passes;
    }

    public static void reset() {
        passes = 0;
    }
}
