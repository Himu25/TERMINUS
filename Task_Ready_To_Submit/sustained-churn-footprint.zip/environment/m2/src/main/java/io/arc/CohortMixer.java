package io.arc;

import java.util.HashMap;
import java.util.Map;

public final class CohortMixer {

    private static final Map<String, Integer> COHORT = new HashMap<>();

    private CohortMixer() {}

    public static int fold(int a, int b) {
        return (a ^ b) & 0xffff;
    }

    public static void noteHop(int hop, String key) {
        COHORT.put(hop + ":" + key, 1);
    }

    public static int cohortDepth() {
        return COHORT.size();
    }

    public static void releaseWave() {
        COHORT.clear();
    }
}
