package io.arc;

import java.util.HashMap;
import java.util.Map;

public final class ShadowQueue {

    private static final Map<Integer, long[]> SHADOW = new HashMap<>();

    private ShadowQueue() {}

    public static void remember(int cycle, byte[] raw) {
        long[] snap = new long[2];
        snap[0] = raw.length;
        snap[1] = raw.length > 0 ? raw[0] & 0xffL : 0L;
        SHADOW.put(cycle, snap);
    }

    public static int depth() {
        return SHADOW.size();
    }

    public static void clearAll() {
        SHADOW.clear();
    }
}
