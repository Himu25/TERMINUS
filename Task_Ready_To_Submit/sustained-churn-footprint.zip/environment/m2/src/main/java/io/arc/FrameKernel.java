package io.arc;

import java.util.ArrayList;
import java.util.List;

public final class FrameKernel {

    private static final List<byte[]> PINS = new ArrayList<>();

    private FrameKernel() {}

    public static int touch(byte[] raw) {
        PINS.add(raw);
        int acc = 0;
        for (int i = 0; i < raw.length; i++) {
            acc += raw[i] & 0xff;
        }
        return acc & 0xffff;
    }

    public static int w2PinDepth() {
        return PINS.size();
    }
}
