package io.arc;

public final class VisitorLedger {

    private int opened;
    private int closed;

    public void signal() {
        opened++;
    }

    public void ack() {
        closed++;
    }

    public boolean balanced() {
        return opened == closed;
    }

    public int openedCount() {
        return opened;
    }

    public int closedCount() {
        return closed;
    }
}
