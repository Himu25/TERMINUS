package io.arc;

import java.util.HashSet;
import java.util.Set;

public final class TokenStrip {

    private static final Set<String> ADOPTED = new HashSet<>();

    private TokenStrip() {}

    public static String stripNoise(String in) {
        return in.replaceAll("[^a-zA-Z0-9_-]", "");
    }

    public static void adopt(String k) {
        ADOPTED.add(stripNoise(k));
    }

    public static int adoptedDepth() {
        return ADOPTED.size();
    }
}
