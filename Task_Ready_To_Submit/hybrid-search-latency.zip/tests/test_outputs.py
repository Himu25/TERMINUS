"""Validate hybrid_bench_report.json outcomes for the hybrid search latency repair task.

Checks cover report schema, hybrid.toml guardrails, digest stability,
independent ranking metrics from gold labels, fixture packs, and ablations
that prove batching, tile memo reuse, lane spread, scratch caps, filter pruning,
and invalidation churn controls are required.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "hybrid_bench_report.json"
CFG = APP / "config" / "hybrid.toml"
RUNNER = APP / "tools" / "run_replay"
FIXTURES = Path(__file__).resolve().parent / "fixtures"
VERIFIER_CARGO_TARGET = Path("/tmp/tbench-verifier-cargo-target")
CARGO_BUILD_TIMEOUT_SEC = 540

REPORT_KEYS = frozenset(
    {
        "status",
        "corpus_vectors",
        "vector_dim",
        "shard_count",
        "queries_total",
        "mean_recall_at_10",
        "mean_ndcg_at_10",
        "mean_leg_a_units",
        "mean_leg_b_units",
        "mean_merge_units",
        "mean_filter_prune_hits",
        "tile_reuse_hits",
        "inval_churn_events",
        "mean_batch_efficiency",
        "p95_query_units",
        "peak_scratch_bytes",
        "starved_lanes",
        "report_digest",
        "queries",
    }
)
_INV_LOG2_RANK = (
    1.0,
    0.6309297535714575,
    0.5,
    0.4306765580733931,
    0.3868528072345416,
    0.3562071871080222,
    0.3333333333333333,
    0.3154648767857288,
    0.3010299956639812,
    0.2890648263178879,
    0.2789429456511299,
    0.2702381544273197,
    0.2626495350371936,
    0.2559580248098155,
    0.25,
    0.244650542118226,
)

QUERY_KEYS = frozenset(
    {
        "query_id",
        "recall_at_10",
        "ndcg_at_10",
        "gold_hits",
        "leg_a_units",
        "leg_b_units",
        "merge_units",
        "query_units",
        "filter_prune_hits",
        "top_ids",
        "batch_size",
        "tile_hit",
    }
)


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "vector_dim": 32,
        "shard_count": 4,
        "top_k": 10,
        "batch_window": 8,
        "recall_floor": 0.82,
        "ndcg_floor": 0.72,
        "max_mean_leg_a_units": 1600,
        "max_mean_leg_b_units": 4200,
        "max_mean_merge_units": 70,
        "max_p95_query_units": 4800,
        "min_batch_efficiency": 0.62,
        "max_peak_scratch_bytes": 512,
        "max_starved_lanes": 1,
        "max_starved_lanes_skew": 1,
        "min_tile_reuse_hits": 1,
        "max_inval_churn_events": 4,
        "max_inval_churn_storm": 6,
        "min_filter_prune_hits": 12,
        "failover_recall_floor": 0.65,
        "tight_security_recall_floor": 0.5,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in (
            "recall_floor",
            "ndcg_floor",
            "failover_recall_floor",
            "tight_security_recall_floor",
            "min_batch_efficiency",
        ):
            cfg[key] = float(val)
        elif key in (
            "vector_dim",
            "shard_count",
            "top_k",
            "batch_window",
            "max_mean_leg_a_units",
            "max_mean_leg_b_units",
            "max_mean_merge_units",
            "max_p95_query_units",
            "max_peak_scratch_bytes",
            "max_starved_lanes",
            "max_starved_lanes_skew",
            "min_tile_reuse_hits",
            "max_inval_churn_events",
            "max_inval_churn_storm",
            "min_filter_prune_hits",
        ):
            cfg[key] = int(float(val))
    return cfg


def _round4(value: float) -> float:
    return round(value * 10000 + 0.5) / 10000


def _rank_scores(gold: list[str], got: list[str], k: int) -> tuple[float, float, int]:
    """Mirror bench.rankScores from gold_ids and emitted top_ids."""
    if not gold:
        return 0.0, 0.0, 0
    gold_set = set(gold)
    if k <= 0:
        k = len(got)
    k = min(k, len(got))
    hits = 0
    rel: list[float] = []
    for i in range(k):
        if got[i] in gold_set:
            hits += 1
            rel.append(1.0)
        else:
            rel.append(0.0)
    recall = hits / len(gold)
    dcg = sum(r * _INV_LOG2_RANK[i] for i, r in enumerate(rel) if r > 0)
    ideal_len = min(len(gold), k)
    idcg = sum(_INV_LOG2_RANK[i] for i in range(ideal_len))
    ndcg = dcg / idcg if idcg > 0 else 0.0
    return _round4(recall), _round4(ndcg), hits


def _load_query_gold(path: Path) -> dict[str, list[str]]:
    gold_by_id: dict[str, list[str]] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        gold_by_id[row["query_id"]] = row.get("gold_ids") or []
    return gold_by_id


def _assert_row_metrics_match_gold(
    row: dict,
    gold_ids: list[str],
    top_k: int,
) -> None:
    exp_recall, exp_ndcg, exp_hits = _rank_scores(gold_ids, row["top_ids"], top_k)
    assert row["recall_at_10"] == pytest.approx(exp_recall, abs=2e-4)
    assert row["ndcg_at_10"] == pytest.approx(exp_ndcg, abs=2e-4)
    assert row["gold_hits"] == exp_hits
    if exp_recall > 0:
        assert any(doc_id in gold_ids for doc_id in row["top_ids"])


def _assert_report_ranking_metrics(report: dict, queries_path: Path) -> None:
    cfg = _parse_cfg()
    gold_by_id = _load_query_gold(queries_path)
    for row in report["queries"]:
        gold_ids = gold_by_id[row["query_id"]]
        _assert_row_metrics_match_gold(row, gold_ids, int(cfg["top_k"]))


def _writable_pack_queries(pack_name: str) -> Path:
    path = APP / "output" / f"queries_{pack_name}.jsonl"
    assert str(path).startswith("/app/output/")
    return path


def _run_fixture_pack(pack: Path, pack_name: str) -> tuple[Path, dict]:
    out = APP / "output" / f"pack_{pack_name}.json"
    queries = _writable_pack_queries(pack_name)
    _goldgen(pack / "corpus.json", pack / "query_specs.jsonl", queries)
    _run_replay(queries, out, pack / "corpus.json")
    return queries, _load_report(out)


def _expected_means(rows: list[dict]) -> tuple[float, float, float, float, float, float]:
    if not rows:
        return 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
    total = len(rows)
    recall = sum(row["recall_at_10"] for row in rows) / total
    ndcg = sum(row["ndcg_at_10"] for row in rows) / total
    leg_a = sum(row["leg_a_units"] for row in rows) / total
    leg_b = sum(row["leg_b_units"] for row in rows) / total
    merge_u = sum(row["merge_units"] for row in rows) / total
    prune = sum(row["filter_prune_hits"] for row in rows) / total
    return (
        _round4(recall),
        _round4(ndcg),
        _round4(leg_a),
        _round4(leg_b),
        _round4(merge_u),
        _round4(prune),
    )


def _digest_payload(report: dict) -> dict:
    return {
        "status": report["status"],
        "corpus_vectors": report["corpus_vectors"],
        "vector_dim": report["vector_dim"],
        "shard_count": report["shard_count"],
        "queries_total": report["queries_total"],
        "mean_recall_at_10": report["mean_recall_at_10"],
        "mean_ndcg_at_10": report["mean_ndcg_at_10"],
        "mean_leg_a_units": report["mean_leg_a_units"],
        "mean_leg_b_units": report["mean_leg_b_units"],
        "mean_merge_units": report["mean_merge_units"],
        "mean_filter_prune_hits": report["mean_filter_prune_hits"],
        "tile_reuse_hits": report["tile_reuse_hits"],
        "inval_churn_events": report["inval_churn_events"],
        "mean_batch_efficiency": report["mean_batch_efficiency"],
        "p95_query_units": report["p95_query_units"],
        "peak_scratch_bytes": report["peak_scratch_bytes"],
        "starved_lanes": report["starved_lanes"],
        "report_digest": "",
        "queries": report["queries"],
    }


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _p95_index(n: int) -> int:
    if n == 0:
        return 0
    return min(n - 1, max(0, int(n * 0.95 + 0.999999) - 1))


def _assert_query_row(row: dict) -> None:
    assert set(row) == QUERY_KEYS
    assert isinstance(row["query_id"], str) and row["query_id"]
    assert isinstance(row["recall_at_10"], (int, float))
    assert isinstance(row["ndcg_at_10"], (int, float))
    assert isinstance(row["gold_hits"], int)
    assert isinstance(row["leg_a_units"], int)
    assert isinstance(row["leg_b_units"], int)
    assert isinstance(row["merge_units"], int)
    assert isinstance(row["query_units"], int)
    assert isinstance(row["filter_prune_hits"], int)
    assert isinstance(row["top_ids"], list)
    assert isinstance(row["batch_size"], int)
    assert isinstance(row["tile_hit"], bool)
    assert 0.0 <= float(row["recall_at_10"]) <= 1.0
    assert 0.0 <= float(row["ndcg_at_10"]) <= 1.0
    assert row["gold_hits"] >= 0
    assert row["leg_a_units"] >= 0
    assert row["leg_b_units"] >= 0
    assert row["merge_units"] >= 0
    assert row["filter_prune_hits"] >= 0
    assert row["query_units"] >= row["leg_a_units"] + row["leg_b_units"] + row["merge_units"]
    assert row["batch_size"] >= 1
    for doc_id in row["top_ids"]:
        assert isinstance(doc_id, str) and doc_id
    if row["tile_hit"]:
        assert row["merge_units"] == 0
        assert row["leg_a_units"] == 0


def _assert_report_schema(data: dict) -> None:
    assert set(data) == REPORT_KEYS
    assert isinstance(data["status"], str) and data["status"] in {"ok", "fail"}
    for int_key in (
        "corpus_vectors",
        "vector_dim",
        "shard_count",
        "queries_total",
        "tile_reuse_hits",
        "inval_churn_events",
        "p95_query_units",
        "peak_scratch_bytes",
        "starved_lanes",
    ):
        assert isinstance(data[int_key], int), int_key
        assert data[int_key] >= 0, int_key
    for float_key in (
        "mean_recall_at_10",
        "mean_ndcg_at_10",
        "mean_leg_a_units",
        "mean_leg_b_units",
        "mean_merge_units",
        "mean_filter_prune_hits",
        "mean_batch_efficiency",
    ):
        assert isinstance(data[float_key], (int, float)), float_key
        assert float(data[float_key]) >= 0.0, float_key
    digest = data["report_digest"]
    assert isinstance(digest, str) and len(digest) == 64
    assert digest == digest.lower()
    assert re.fullmatch(r"[0-9a-f]{64}", digest)
    assert isinstance(data["queries"], list)
    for row in data["queries"]:
        _assert_query_row(row)


def _load_report(path: Path = OUT) -> dict:
    assert path.is_file(), f"missing report at {path}"
    data = json.loads(path.read_text(encoding="utf-8"))
    _assert_report_schema(data)
    return data


def _rebuild_hybrid_bench(env: dict[str, str] | None = None) -> None:
    build_env = dict(env or os.environ.copy())
    build_env["CARGO_TARGET_DIR"] = str(VERIFIER_CARGO_TARGET)
    subprocess.run(
        ["cargo", "build", "--release", "--manifest-path", str(APP / "Cargo.toml")],
        cwd=APP,
        env=build_env,
        check=True,
        capture_output=True,
        text=True,
        timeout=CARGO_BUILD_TIMEOUT_SEC,
    )
    release = VERIFIER_CARGO_TARGET / "release"
    subprocess.run(
        ["install", "-m", "0755", str(release / "hybrid_bench"), "/app/bin/hybrid_bench"],
        check=True,
        capture_output=True,
        text=True,
    )
    subprocess.run(
        ["install", "-m", "0755", str(release / "goldgen"), "/app/bin/goldgen"],
        check=True,
        capture_output=True,
        text=True,
    )


def _goldgen(corpus_path: Path, specs_path: Path, out_path: Path) -> None:
    subprocess.run(
        [
            "/app/bin/goldgen",
            corpus_path.as_posix(),
            specs_path.as_posix(),
            out_path.as_posix(),
        ],
        check=True,
        capture_output=True,
        text=True,
    )


def _run_replay(
    query_path: Path,
    out_path: Path = OUT,
    corpus_path: Path | None = None,
    *,
    rebuild: bool = False,
) -> None:
    env = os.environ.copy()
    if corpus_path is not None:
        env["TB_CORPUS_PATH"] = str(corpus_path)
    else:
        env.pop("TB_CORPUS_PATH", None)
    if out_path.exists():
        out_path.unlink()
    if rebuild:
        _rebuild_hybrid_bench(env)
    subprocess.run(
        [
            "/app/bin/hybrid_bench",
            query_path.as_posix(),
            out_path.as_posix(),
        ],
        cwd=APP,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )


def _assert_ok_default(report: dict) -> None:
    cfg = _parse_cfg()
    assert report["status"] == "ok"
    assert report["mean_recall_at_10"] >= cfg["recall_floor"]
    assert report["mean_ndcg_at_10"] >= cfg["ndcg_floor"]
    assert report["mean_leg_a_units"] <= cfg["max_mean_leg_a_units"]
    assert report["mean_leg_b_units"] <= cfg["max_mean_leg_b_units"]
    assert report["mean_merge_units"] <= cfg["max_mean_merge_units"]
    assert report["p95_query_units"] <= cfg["max_p95_query_units"]
    assert report["mean_batch_efficiency"] >= cfg["min_batch_efficiency"]
    assert report["peak_scratch_bytes"] <= cfg["max_peak_scratch_bytes"]
    assert report["starved_lanes"] <= cfg["max_starved_lanes"]
    assert report["tile_reuse_hits"] >= cfg["min_tile_reuse_hits"]
    assert report["inval_churn_events"] <= cfg["max_inval_churn_events"]
    assert report["mean_filter_prune_hits"] >= cfg["min_filter_prune_hits"]


@pytest.fixture(scope="session", autouse=True)
def _default_bench_run() -> None:
    _rebuild_hybrid_bench()
    _goldgen(
        APP / "data" / "corpus_default.json",
        APP / "data" / "query_specs.jsonl",
        APP / "data" / "queries_default.jsonl",
    )
    _run_replay(APP / "data" / "queries_default.jsonl")


def test_runner_exists() -> None:
    """Documented replay driver is present and executable."""
    assert RUNNER.is_file() and os.access(RUNNER, os.X_OK)


def test_hybrid_bench_report_output_exists() -> None:
    """Primary deliverable hybrid_bench_report.json is written under /app/output."""
    assert OUT.is_file(), f"missing report at {OUT}"


def test_report_schema_keys() -> None:
    """hybrid_bench_report.json exposes the contract field set only."""
    report = _load_report()
    _assert_ok_default(report)
    assert report["queries_total"] == len(report["queries"])


def test_per_query_row_keys() -> None:
    """Each queries[] row uses the documented sub-schema and valid metric ranges."""
    report = _load_report()
    _assert_ok_default(report)
    for row in report["queries"]:
        _assert_query_row(row)


def test_default_ranking_metrics_match_gold_labels() -> None:
    """Per-row recall, ndcg, and gold_hits are recomputed from gold_ids and top_ids."""
    report = _load_report()
    _assert_ok_default(report)
    _assert_report_ranking_metrics(report, APP / "data" / "queries_default.jsonl")


def test_status_ok_and_hybrid_floors() -> None:
    """Default pack has status ok and meets recall floor in hybrid.toml."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["status"] == "ok"
    assert report["mean_recall_at_10"] >= cfg["recall_floor"]


def test_mean_ndcg_meets_floor() -> None:
    """mean_ndcg_at_10 must meet ndcg_floor in hybrid.toml."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["mean_ndcg_at_10"] >= cfg["ndcg_floor"]


def test_mean_leg_a_units_within_cap() -> None:
    """mean_leg_a_units stays under max_mean_leg_a_units on the default pack."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["mean_leg_a_units"] <= cfg["max_mean_leg_a_units"]


def test_mean_leg_b_units_within_cap() -> None:
    """mean_leg_b_units stays under max_mean_leg_b_units on the default pack."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["status"] == "ok"
    assert report["mean_leg_b_units"] <= cfg["max_mean_leg_b_units"]


def test_mean_merge_units_within_cap() -> None:
    """mean_merge_units stays under max_mean_merge_units on the default pack."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["status"] == "ok"
    assert report["mean_merge_units"] <= cfg["max_mean_merge_units"]
    non_tile = [r for r in report["queries"] if not r["tile_hit"]]
    assert non_tile, "expected at least one non-tile row"
    assert sum(r["merge_units"] for r in non_tile) / len(non_tile) <= cfg["max_mean_merge_units"]


def test_batch_efficiency_meets_floor() -> None:
    """mean_batch_efficiency must meet min_batch_efficiency in hybrid.toml."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["status"] == "ok"
    assert report["mean_batch_efficiency"] >= cfg["min_batch_efficiency"]


def test_batch_sizes_respect_window() -> None:
    """Per-query batch_size must not exceed batch_window from hybrid.toml."""
    report = _load_report()
    cfg = _parse_cfg()
    window = int(cfg["batch_window"])
    assert window >= 1
    sizes = [row["batch_size"] for row in report["queries"]]
    assert sizes, "expected at least one query row"
    assert max(sizes) <= window
    assert max(sizes) >= min(window // 2, len(sizes))


def test_peak_scratch_within_cap() -> None:
    """peak_scratch_bytes stays under max_peak_scratch_bytes."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["peak_scratch_bytes"] <= cfg["max_peak_scratch_bytes"]


def test_p95_query_units_within_cap() -> None:
    """Tail query units stay under max_p95_query_units."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["p95_query_units"] <= cfg["max_p95_query_units"]


def test_starved_lanes_within_cap_on_default_pack() -> None:
    """Default replay schedules every shard lane at least once within cap."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["starved_lanes"] <= cfg["max_starved_lanes"]


def test_tile_reuse_hits_meets_floor() -> None:
    """tile_reuse_hits must meet min_tile_reuse_hits in hybrid.toml."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["tile_reuse_hits"] >= cfg["min_tile_reuse_hits"]


def test_inval_churn_events_within_cap() -> None:
    """inval_churn_events stays under max_inval_churn_events."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["inval_churn_events"] <= cfg["max_inval_churn_events"]


def test_mean_filter_prune_hits_meets_floor() -> None:
    """mean_filter_prune_hits must meet min_filter_prune_hits in hybrid.toml."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["mean_filter_prune_hits"] >= cfg["min_filter_prune_hits"]


def test_hot_query_tile_hits_present() -> None:
    """Repeated hot query ids in the default pack should record tile_hit rows."""
    report = _load_report()
    hits = [r for r in report["queries"] if r["tile_hit"]]
    assert len(hits) >= 1


def test_summary_means_recomputed_from_query_rows() -> None:
    """Mean recall, ndcg, unit, and prune fields must match per-query rows."""
    report = _load_report()
    want_recall, want_ndcg, want_leg_a, want_leg_b, want_merge, want_prune = _expected_means(
        report["queries"]
    )
    assert report["mean_recall_at_10"] == pytest.approx(want_recall, abs=2e-4)
    assert report["mean_ndcg_at_10"] == pytest.approx(want_ndcg, abs=2e-4)
    assert report["mean_leg_a_units"] == pytest.approx(want_leg_a, abs=2e-4)
    assert report["mean_leg_b_units"] == pytest.approx(want_leg_b, abs=2e-4)
    assert report["mean_merge_units"] == pytest.approx(want_merge, abs=2e-4)
    assert report["mean_filter_prune_hits"] == pytest.approx(want_prune, abs=2e-4)


def test_p95_query_units_matches_rows() -> None:
    """p95_query_units is the 95th percentile of per-query query_units."""
    report = _load_report()
    units = sorted(row["query_units"] for row in report["queries"])
    assert report["p95_query_units"] == units[_p95_index(len(units))]


def test_report_digest_format() -> None:
    """report_digest is 64-char lowercase hex."""
    digest = _load_report()["report_digest"]
    assert len(digest) == 64
    assert digest == digest.lower()
    assert re.fullmatch(r"[0-9a-f]{64}", digest)


def test_report_digest_matches_body() -> None:
    """report_digest is SHA-256 of the compact pre-digest payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_repeat_run_byte_identical() -> None:
    """Back-to-back default runs emit identical report bytes."""
    _assert_ok_default(_load_report())
    first = OUT.read_bytes()
    _run_replay(APP / "data" / "queries_default.jsonl")
    second = OUT.read_bytes()
    assert first == second


def test_queries_total_matches_pack_line_count() -> None:
    """queries_total equals non-empty lines in the default query JSONL."""
    report = _load_report()
    expected = sum(
        1
        for line in (APP / "data" / "queries_default.jsonl")
        .read_text(encoding="utf-8")
        .splitlines()
        if line.strip()
    )
    assert report["queries_total"] == expected
    assert len(report["queries"]) == expected


def test_corpus_vectors_matches_manifest() -> None:
    """corpus_vectors and vector_dim track the shard manifest."""
    report = _load_report()
    manifest = json.loads((APP / "registry" / "shard_manifest.json").read_text(encoding="utf-8"))
    assert report["corpus_vectors"] == manifest["count"]
    assert report["vector_dim"] == manifest["dim"]
    assert report["shard_count"] == manifest["shards"]


def test_q_search_ann_ndcg_floor() -> None:
    """q_search_ann ndcg must be positive once ranking is repaired."""
    report = _load_report()
    cfg = _parse_cfg()
    gold_by_id = _load_query_gold(APP / "data" / "queries_default.jsonl")
    row = next(r for r in report["queries"] if r["query_id"] == "q_search_ann")
    exp_recall, exp_ndcg, _ = _rank_scores(
        gold_by_id["q_search_ann"], row["top_ids"], int(cfg["top_k"])
    )
    assert row["ndcg_at_10"] == pytest.approx(exp_ndcg, abs=2e-4)
    assert exp_ndcg >= cfg["ndcg_floor"] / (2 * cfg["top_k"])


def test_failover_queries_reduce_leg_b_units() -> None:
    """Failover rows skip dead lanes and clear the failover recall floor."""
    report = _load_report()
    cfg = _parse_cfg()
    queries_path = APP / "data" / "queries_default.jsonl"
    gold_by_id = _load_query_gold(queries_path)
    specs = {
        json.loads(line)["query_id"]: json.loads(line).get("dead_shards", [])
        for line in (APP / "data" / "query_specs.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    }
    for row in report["queries"]:
        if not row["query_id"].startswith("q_failover"):
            continue
        exp_recall, _, _ = _rank_scores(
            gold_by_id[row["query_id"]], row["top_ids"], int(cfg["top_k"])
        )
        assert row["recall_at_10"] == pytest.approx(exp_recall, abs=2e-4)
        assert exp_recall >= cfg["failover_recall_floor"]
        assert row["leg_b_units"] < cfg["max_mean_leg_b_units"]
        dead = specs[row["query_id"]]
        live = int(cfg["shard_count"]) - len(dead)
        assert live >= 1


def test_fixture_pack_failover_recall() -> None:
    """Failover fixture pack clears per-row failover recall floor."""
    cfg = _parse_cfg()
    queries, report = _run_fixture_pack(FIXTURES / "pack_failover", "failover")
    _assert_report_ranking_metrics(report, queries)
    for row in report["queries"]:
        exp_recall, _, _ = _rank_scores(
            _load_query_gold(queries)[row["query_id"]],
            row["top_ids"],
            int(cfg["top_k"]),
        )
        assert exp_recall >= cfg["failover_recall_floor"]


def test_fixture_pack_skew_starvation_cap() -> None:
    """Hot-skew pack keeps starved_lanes within max_starved_lanes_skew."""
    cfg = _parse_cfg()
    queries, report = _run_fixture_pack(FIXTURES / "pack_skew_queries", "skew")
    _assert_report_ranking_metrics(report, queries)
    assert report["status"] == "ok"
    assert report["starved_lanes"] <= cfg["max_starved_lanes_skew"]
    assert report["mean_recall_at_10"] >= cfg["recall_floor"]


def test_fixture_pack_burst_replay() -> None:
    """Burst pack replays with status ok, tile hits, and merge/p95 guardrails."""
    cfg = _parse_cfg()
    queries, report = _run_fixture_pack(FIXTURES / "pack_burst", "burst")
    _assert_report_ranking_metrics(report, queries)
    assert report["status"] == "ok"
    assert report["mean_merge_units"] <= cfg["max_mean_merge_units"]
    assert report["p95_query_units"] <= cfg["max_p95_query_units"]
    assert report["mean_batch_efficiency"] >= cfg["min_batch_efficiency"]
    hits = [r for r in report["queries"] if r["tile_hit"]]
    assert len(hits) >= 3


def test_per_query_merge_units_match_shard_fanout() -> None:
    """Non-tile rows bill top_k per live partial stream plus one coordinator fold pass."""
    report = _load_report()
    cfg = _parse_cfg()
    top_k = int(cfg["top_k"])
    specs = {
        json.loads(line)["query_id"]: json.loads(line).get("dead_shards", [])
        for line in (APP / "data" / "query_specs.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    }
    for row in report["queries"]:
        if row["tile_hit"]:
            continue
        dead = specs.get(row["query_id"], [])
        live = int(cfg["shard_count"]) - len(dead)
        assert live >= 1
        expected_merge = top_k * (live + 1)
        assert row["merge_units"] == expected_merge


def test_tile_hit_rows_skip_merge_and_leg_a_units() -> None:
    """Tile memo hits reuse prior results with merge_units and leg_a_units at zero."""
    report = _load_report()
    hits = [row for row in report["queries"] if row["tile_hit"]]
    assert hits, "expected at least one tile_hit row on the default pack"
    for row in hits:
        assert row["merge_units"] == 0
        assert row["leg_a_units"] == 0


def test_fixture_pack_tight_recall_security_row() -> None:
    """Tight recall pack clears security-query recall floor."""
    cfg = _parse_cfg()
    queries, report = _run_fixture_pack(FIXTURES / "pack_tight_recall", "tight")
    _assert_report_ranking_metrics(report, queries)
    gold_by_id = _load_query_gold(queries)
    sec = next(r for r in report["queries"] if r["query_id"] == "q_tight_security")
    exp_recall, _, _ = _rank_scores(
        gold_by_id["q_tight_security"], sec["top_ids"], int(cfg["top_k"])
    )
    assert sec["recall_at_10"] == pytest.approx(exp_recall, abs=2e-4)
    assert exp_recall >= cfg["tight_security_recall_floor"]
    assert report["mean_recall_at_10"] >= cfg["recall_floor"]


def test_broken_batch_ablation_fails_efficiency() -> None:
    """Single-query batches cannot clear mean_batch_efficiency on the default pack."""
    batch_src = APP / "codec" / "mod.rs"
    backup = batch_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "broken_qk_fold.rs").read_text(encoding="utf-8")
    out = APP / "output" / "ablation_batch.json"
    cfg = _parse_cfg()
    try:
        batch_src.write_text(broken, encoding="utf-8")
        _run_replay(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        assert report["mean_batch_efficiency"] < cfg["min_batch_efficiency"] or report["status"] == "fail"
    finally:
        batch_src.write_text(backup, encoding="utf-8")
        _rebuild_hybrid_bench()
        _run_replay(APP / "data" / "queries_default.jsonl")


def test_broken_memo_ablation_loses_tile_hits() -> None:
    """Disabled tile memo reuse drops hot-query tile_hit rows on the default pack."""
    memo_src = APP / "rowq" / "mod.rs"
    backup = memo_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "broken_r3_memo.rs").read_text(encoding="utf-8")
    out = APP / "output" / "ablation_memo.json"
    try:
        memo_src.write_text(broken, encoding="utf-8")
        _run_replay(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        assert not any(r["tile_hit"] for r in report["queries"])
    finally:
        memo_src.write_text(backup, encoding="utf-8")
        _rebuild_hybrid_bench()
        _run_replay(APP / "data" / "queries_default.jsonl")


def test_broken_lane_ablation_starves_skew_pack() -> None:
    """Pinned worker lane placement starves shards on the hot-skew fixture pack."""
    slot_src = APP / "node" / "mod.rs"
    backup = slot_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "broken_n7_slot.rs").read_text(encoding="utf-8")
    out = APP / "output" / "ablation_lane.json"
    cfg = _parse_cfg()
    pack = FIXTURES / "pack_skew_queries"
    queries = _writable_pack_queries("ablation_skew")
    try:
        slot_src.write_text(broken, encoding="utf-8")
        _goldgen(pack / "corpus.json", pack / "query_specs.jsonl", queries)
        _run_replay(queries, out, pack / "corpus.json", rebuild=True)
        report = _load_report(out)
        assert report["starved_lanes"] > cfg["max_starved_lanes_skew"] or report["status"] == "fail"
    finally:
        slot_src.write_text(backup, encoding="utf-8")
        _rebuild_hybrid_bench()
        _run_replay(APP / "data" / "queries_default.jsonl")


def test_broken_merge_ablation_inflates_mean() -> None:
    """Doubled coordinator surcharge cannot clear max_mean_merge_units on the default pack."""
    merge_src = APP / "coord" / "mod.rs"
    backup = merge_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "broken_r4_fold.rs").read_text(encoding="utf-8")
    out = APP / "output" / "ablation_merge.json"
    cfg = _parse_cfg()
    try:
        merge_src.write_text(broken, encoding="utf-8")
        _run_replay(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        assert report["mean_merge_units"] > cfg["max_mean_merge_units"] or report["status"] == "fail"
    finally:
        merge_src.write_text(backup, encoding="utf-8")
        _rebuild_hybrid_bench()
        _run_replay(APP / "data" / "queries_default.jsonl")


def test_broken_sparse_ablation_inflates_leg_a() -> None:
    """Full-corpus sparse tally cannot clear max_mean_leg_a_units on the default pack."""
    sparse_src = APP / "sparse" / "mod.rs"
    backup = sparse_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "broken_sx_tally.rs").read_text(encoding="utf-8")
    out = APP / "output" / "ablation_sparse.json"
    cfg = _parse_cfg()
    try:
        sparse_src.write_text(broken, encoding="utf-8")
        _run_replay(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        assert report["mean_leg_a_units"] > cfg["max_mean_leg_a_units"] or report["status"] == "fail"
    finally:
        sparse_src.write_text(backup, encoding="utf-8")
        _rebuild_hybrid_bench()
        _run_replay(APP / "data" / "queries_default.jsonl")


def test_broken_filter_ablation_zero_prune_hits() -> None:
    """Disabled metadata tag pruning drops filter_prune_hits below the floor."""
    filter_src = APP / "filter" / "mod.rs"
    backup = filter_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "broken_f5_prune.rs").read_text(encoding="utf-8")
    out = APP / "output" / "ablation_filter.json"
    cfg = _parse_cfg()
    try:
        filter_src.write_text(broken, encoding="utf-8")
        _run_replay(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        assert (
            report["mean_filter_prune_hits"] < cfg["min_filter_prune_hits"]
            or report["status"] == "fail"
        )
    finally:
        filter_src.write_text(backup, encoding="utf-8")
        _rebuild_hybrid_bench()
        _run_replay(APP / "data" / "queries_default.jsonl")


def test_broken_cache_ablation_storm_reduces_tile_reuse() -> None:
    """Aggressive tick purge on the invalidation-storm pack cuts tile reuse below the good band."""
    cache_src = APP / "cache" / "mod.rs"
    backup = cache_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "broken_t4_purge.rs").read_text(encoding="utf-8")
    out = APP / "output" / "ablation_cache.json"
    pack = FIXTURES / "pack_inval_storm"
    queries = _writable_pack_queries("ablation_storm")
    try:
        cache_src.write_text(broken, encoding="utf-8")
        _goldgen(pack / "corpus.json", pack / "query_specs.jsonl", queries)
        _run_replay(queries, out, pack / "corpus.json", rebuild=True)
        report = _load_report(out)
        assert report["tile_reuse_hits"] < 30 or report["status"] == "fail"
    finally:
        cache_src.write_text(backup, encoding="utf-8")
        _rebuild_hybrid_bench()
        _run_replay(APP / "data" / "queries_default.jsonl")


def test_broken_rerank_ablation_inflates_merge() -> None:
    """Doubled rerank surcharge cannot clear max_mean_merge_units on the default pack."""
    rerank_src = APP / "rerank" / "mod.rs"
    backup = rerank_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "broken_hy_surcharge.rs").read_text(encoding="utf-8")
    out = APP / "output" / "ablation_rerank.json"
    cfg = _parse_cfg()
    try:
        rerank_src.write_text(broken, encoding="utf-8")
        _run_replay(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        assert report["mean_merge_units"] > cfg["max_mean_merge_units"] or report["status"] == "fail"
    finally:
        rerank_src.write_text(backup, encoding="utf-8")
        _rebuild_hybrid_bench()
        _run_replay(APP / "data" / "queries_default.jsonl")


def test_fixture_pack_inval_storm_churn_and_tile_reuse() -> None:
    """Invalidation-storm pack keeps churn within cap while preserving hot tile hits."""
    cfg = _parse_cfg()
    queries, report = _run_fixture_pack(FIXTURES / "pack_inval_storm", "inval_storm")
    _assert_report_ranking_metrics(report, queries)
    assert report["status"] == "ok"
    assert report["inval_churn_events"] <= cfg["max_inval_churn_storm"]
    assert report["tile_reuse_hits"] >= 3
    assert report["mean_recall_at_10"] >= cfg["recall_floor"]


def test_sparse_leg_a_coupled_to_filter_prune() -> None:
    """Queries with tag hints should keep leg_a_units below the sparse leg cap."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["mean_leg_a_units"] <= cfg["max_mean_leg_a_units"]
    assert report["mean_filter_prune_hits"] >= cfg["min_filter_prune_hits"]


def test_broken_scratch_ablation_exceeds_peak() -> None:
    """Oversized per-query scratch buffers exceed max_peak_scratch_bytes."""
    scratch_src = APP / "bench" / "mod.rs"
    backup = scratch_src.read_text(encoding="utf-8")
    broken_scratch = (FIXTURES / "broken_m3_bump.rs").read_text(encoding="utf-8")
    out = APP / "output" / "ablation_scratch.json"
    cfg = _parse_cfg()
    try:
        scratch_src.write_text(broken_scratch, encoding="utf-8")
        _run_replay(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        assert (
            report["peak_scratch_bytes"] > cfg["max_peak_scratch_bytes"]
            or report["status"] == "fail"
        )
    finally:
        scratch_src.write_text(backup, encoding="utf-8")
        _rebuild_hybrid_bench()
        _run_replay(APP / "data" / "queries_default.jsonl")
