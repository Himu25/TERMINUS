use crate::types::PartialHit;

pub fn hy_surcharge(partials: &[Vec<PartialHit>], top_k: usize) -> u32 {
    if partials.is_empty() {
        return 0;
    }
    (top_k as u32) * (partials.len() as u32) * 2
}

pub fn hy_blend_score(sparse: f64, dense: f64) -> f64 {
    sparse * 0.35 + dense * 0.65
}
