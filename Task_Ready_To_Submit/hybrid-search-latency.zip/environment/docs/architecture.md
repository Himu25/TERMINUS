# Architecture notes

Corpus JSON is embedded, partitioned across shard lanes by doc id hash, scheduled in batches through the query dispatcher, probed per live lane on two retrieval legs, then merged globally.

`/app/output/hybrid_bench_report.json` top-level keys: status, corpus_vectors, vector_dim, shard_count, queries_total, mean_recall_at_10, mean_ndcg_at_10, mean_leg_a_units, mean_leg_b_units, mean_merge_units, mean_filter_prune_hits, tile_reuse_hits, inval_churn_events, mean_batch_efficiency, p95_query_units, peak_scratch_bytes, starved_lanes, report_digest, queries.

Each queries row: query_id, recall_at_10, ndcg_at_10, gold_hits, leg_a_units, leg_b_units, merge_units, query_units, filter_prune_hits, top_ids, batch_size, tile_hit. Ranking metrics are between zero and one; gold_hits is non-negative. Unit fields are synthetic cost tallies, not wall-clock timings. query_units equals leg_a_units plus leg_b_units plus merge_units plus scheduler overhead. mean_batch_efficiency compares realized batch sizes against batch_window from hybrid.toml. starved_lanes counts shard lanes that received zero scheduled queries during the replay. peak_scratch_bytes is the high-water mark of scratch allocations for the run.

Digest covers every report field except the live digest value. Build compact JSON with `separators=(',', ':')` and UTF-8, hashing with SHA-256 lowercase hex. Top-level key order: status, corpus_vectors, vector_dim, shard_count, queries_total, mean_recall_at_10, mean_ndcg_at_10, mean_leg_a_units, mean_leg_b_units, mean_merge_units, mean_filter_prune_hits, tile_reuse_hits, inval_churn_events, mean_batch_efficiency, p95_query_units, peak_scratch_bytes, starved_lanes, report_digest (empty string), queries. Each queries[] row key order: query_id, recall_at_10, ndcg_at_10, gold_hits, leg_a_units, leg_b_units, merge_units, query_units, filter_prune_hits, top_ids, batch_size, tile_hit. Verifier mean recomputation allows four-decimal drift (2e-4).

Quality gates compare means against floors and ceilings in hybrid.toml. When every hybrid.toml guardrail passes, status is the string ok; otherwise status is fail. Failover packs list dead_shards per query; only live lanes may be queried. The hot-skew pack must keep `starved_lanes` at or below `max_starved_lanes_skew`. The tight-recall pack security row must meet `tight_security_recall_floor`. The invalidation-storm pack must keep `inval_churn_events` at or below `max_inval_churn_storm` while preserving tile reuse on repeated hot query ids.

Per-field unit semantics and merge fold pass worked examples are in `/app/docs/unit_ledger.md`.

## Regression scope

Latency regressions span batch coalescing and coalesce tax (`/app/codec/mod.rs`), sparse leg token tally (`/app/sparse/mod.rs`), tile memo reuse (`/app/rowq/mod.rs`), lane placement against shard targets (`/app/node/mod.rs`), coordinator merge weight and rerank surcharge (`/app/coord/mod.rs`, `/app/rerank/mod.rs`), metadata tag pruning (`/app/filter/mod.rs`), invalidation tick hooks (`/app/cache/mod.rs`), and scratch high-water plus per-batch reset (`/app/bench/mod.rs`). Repairs must correct those canonical implementations in place. Bridge or wrapper modules that route around them while leaving the originals broken will not pass ablation checks.

Verifier fixture benches write generated query JSONL under `/app/output/queries_<pack>.jsonl` (never under `/tests`) and may write `/app/output/pack_failover.json`, `/app/output/pack_skew.json`, `/app/output/pack_tight.json`, `/app/output/pack_burst.json`, `/app/output/pack_inval_storm.json`, `/app/output/ablation_batch.json`, `/app/output/ablation_memo.json`, `/app/output/ablation_lane.json`, `/app/output/ablation_merge.json`, `/app/output/ablation_sparse.json`, `/app/output/ablation_filter.json`, `/app/output/ablation_cache.json`, `/app/output/ablation_rerank.json`, `/app/output/ablation_scratch.json`. Ablation sources live under the verifier fixture tree (`fixtures/broken_qk_fold.rs`, `fixtures/broken_sx_tally.rs`, `fixtures/broken_r3_memo.rs`, `fixtures/broken_n7_slot.rs`, `fixtures/broken_r4_fold.rs`, `fixtures/broken_f5_prune.rs`, `fixtures/broken_t4_purge.rs`, `fixtures/broken_hy_surcharge.rs`, `fixtures/broken_m3_bump.rs`, `fixtures/broken_m3_reset.rs`). Verifier rebuilds set `CARGO_TARGET_DIR` to `/tmp/tbench-verifier-cargo-target` and install from that target's `release` directory.

## Module map

| Path | Role |
|------|------|
| `/app/codec/mod.rs` | Row packing, batch fold, partial fan-out picker |
| `/app/sparse/mod.rs` | Sparse leg token tally for leg_a_units |
| `/app/rowq/mod.rs` | Tile memo peek/save |
| `/app/node/mod.rs` | Worker lane axis and placement tax |
| `/app/coord/mod.rs` | Global merge unit tally |
| `/app/rerank/mod.rs` | Hybrid rerank surcharge on coordinator fold |
| `/app/filter/mod.rs` | Metadata tag hint pruning |
| `/app/cache/mod.rs` | Invalidation tick gate |
| `/app/bench/mod.rs` | Scratch arena and replay bridges |

Decoy bridge stubs under `/app/bench/h4_sparse_bridge.rs`, `/app/bench/h5_rerank_bridge.rs`, `/app/lane/k3_rerank_stub.rs`, and `/app/sparse/sx_shadow.rs` are not on the hot replay path.
