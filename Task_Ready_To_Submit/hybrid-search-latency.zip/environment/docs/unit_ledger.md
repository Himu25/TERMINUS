# Unit ledger

Synthetic unit fields in `/app/output/hybrid_bench_report.json` are deterministic cost tallies used by guardrails in `/app/config/hybrid.toml`. They are not wall-clock timings.

## Leg A units

`leg_a_units` counts sparse token-overlap work for the first retrieval leg across live shard lanes via `/app/sparse/mod.rs`. When metadata tag hints narrow the candidate set, only matching documents should contribute. Failover query specs list `dead_shards`; those lanes are skipped.

## Leg B units

`leg_b_units` counts vector probe work for the second retrieval leg across live shard lanes.

## Merge units

Non-tile rows bill merge comparator work during partial fan-out and the coordinator fold:

- one `top_k`-width pass per live shard partial stream
- one additional `top_k`-width coordinator fold pass after partials are merged

Coordinator weight is tallied in `/app/coord/mod.rs` with rerank surcharge from `/app/rerank/mod.rs`. For `top_k` from `/app/config/hybrid.toml` and `live` live shard lanes, non-tile `merge_units` is `top_k * (live + 1)`. Tile-hit rows reuse prior results and record `merge_units = 0`.

## Filter prune hits

`filter_prune_hits` counts documents skipped when a metadata tag hint from the query text narrows the candidate set before either leg runs.

## Tile reuse

`tile_hit` on a query row marks a memo reuse. `tile_reuse_hits` is the run total of tile hits.

## Invalidation churn

`inval_churn_events` counts batch tick hooks that purge memo tiles without a matching reuse opportunity. Lower is better; guardrails cap this field on default and storm fixture packs separately.

## Query units

`query_units` adds leg A, leg B, merge, and scheduler overhead from batch coalescing tax and worker lane placement tax. Tile hits copy prior `query_units` and skip merge work.

## Scratch bytes

`peak_scratch_bytes` tracks the high-water mark of scratch arena allocations across the replay. Per-batch tick hooks reset transient scratch counters while preserving the run peak.
