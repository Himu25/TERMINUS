# Runbook

1. Regenerate gold labels when query specs drift: `/app/bin/goldgen <corpus> <specs.jsonl> <out.jsonl>`.
2. Replay queries: `/app/tools/run_replay <queries.jsonl> <report.json>`.
3. Compare report status and guardrail fields against `/app/config/hybrid.toml`.

Regression packs are listed in `/app/docs/fixture_queries.txt`. Write generated query JSONL under `/app/output`.
