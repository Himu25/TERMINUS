pub fn h4_sparse_bridge_tax(batch: usize) -> u32 {
    if batch <= 1 {
        95
    } else {
        25
    }
}

pub fn h4_sparse_bridge_span(rows: usize, dim: usize) -> usize {
    rows.saturating_mul(dim) / 4
}
