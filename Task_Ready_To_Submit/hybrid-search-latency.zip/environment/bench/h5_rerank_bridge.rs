pub fn h5_rerank_bridge_units(top_k: usize, streams: usize) -> u32 {
    (top_k as u32).saturating_mul(streams as u32)
}

pub fn h5_rerank_bridge_fold(partials: usize) -> u32 {
    partials as u32 * 8
}
