use std::sync::atomic::{AtomicU32, Ordering};

static INVALIDATION_EVENTS: AtomicU32 = AtomicU32::new(0);

pub fn t4_note_inval() {
    INVALIDATION_EVENTS.fetch_add(1, Ordering::Relaxed);
}

pub fn t4_read_inval() -> u32 {
    INVALIDATION_EVENTS.load(Ordering::Relaxed)
}

pub fn t4_zero_inval() {
    INVALIDATION_EVENTS.store(0, Ordering::Relaxed);
}

pub fn t4_should_purge(_batch_tick: u32) -> bool {
    true
}
