pub fn k3_rerank_stub_units(top_k: usize) -> u32 {
    top_k as u32 * 3
}

pub fn k3_rerank_stub_blend(sparse: f64, dense: f64) -> f64 {
    sparse + dense
}
