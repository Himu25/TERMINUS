use crate::codec::Row;
use std::collections::hash_map::DefaultHasher;
use std::hash::{Hash, Hasher};

#[derive(Clone)]
pub struct Lane {
    pub shard_id: usize,
    pub rows: Vec<Row>,
}

pub fn empty_lanes(shard_count: usize) -> Vec<Lane> {
    (0..shard_count)
        .map(|i| Lane {
            shard_id: i,
            rows: Vec::new(),
        })
        .collect()
}

pub fn route_doc(id: &str, shard_count: usize) -> usize {
    if shard_count == 0 {
        return 0;
    }
    let mut hasher = DefaultHasher::new();
    id.hash(&mut hasher);
    (hasher.finish() as usize) % shard_count
}

pub fn kx_span(lane: &Lane, dim: usize) -> usize {
    lane.rows.len() * dim
}

pub fn px_scan(query: &[f64], lane: &Lane, top_k: usize) -> Vec<crate::types::PartialHit> {
    let mut pairs: Vec<(String, f64)> = lane
        .rows
        .iter()
        .map(|row| (row.id.clone(), crate::embed::dot(query, &row.open())))
        .collect();
    pairs.sort_by(|a, b| {
        b.1.partial_cmp(&a.1)
            .unwrap_or(std::cmp::Ordering::Equal)
            .then_with(|| a.0.cmp(&b.0))
    });
    let k = if top_k == 0 || top_k > pairs.len() {
        pairs.len()
    } else {
        top_k
    };
    pairs
        .into_iter()
        .take(k)
        .map(|(id, score)| crate::types::PartialHit {
            doc_id: id,
            score,
            shard: lane.shard_id,
        })
        .collect()
}

pub fn leg_a_tally(lanes: &[Lane], dead: &[usize], docs: &[crate::types::Doc]) -> u32 {
    let live: Vec<usize> = lanes
        .iter()
        .filter(|ln| !dead.contains(&ln.shard_id))
        .map(|ln| ln.shard_id)
        .collect();
    docs.iter()
        .filter(|d| live.contains(&route_doc(&d.id, lanes.len())))
        .map(|d| d.text.split_whitespace().count() as u32)
        .sum()
}
