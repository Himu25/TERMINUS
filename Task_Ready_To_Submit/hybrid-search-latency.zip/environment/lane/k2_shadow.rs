pub fn k2_span(rows: usize, dim: usize) -> usize {
    rows.saturating_mul(dim) / 2
}

pub fn k2_tax(batch: usize) -> u32 {
    if batch <= 1 {
        90
    } else {
        30
    }
}
