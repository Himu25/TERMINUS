use crate::types::PartialHit;

#[derive(Clone)]
pub struct Row {
    pub id: String,
    pub vec: Vec<f64>,
    pub raw: Vec<u8>,
}

pub fn pack_vec(id: &str, vec: &[f64]) -> Row {
    let mut raw = vec![0u8; 8 * vec.len()];
    for (i, v) in vec.iter().enumerate() {
        raw[i * 8..(i + 1) * 8].copy_from_slice(&v.to_le_bytes());
    }
    Row {
        id: id.to_string(),
        vec: vec.to_vec(),
        raw,
    }
}

impl Row {
    pub fn open(&self) -> Vec<f64> {
        if !self.vec.is_empty() {
            return self.vec.clone();
        }
        let mut out = Vec::with_capacity(self.raw.len() / 8);
        for chunk in self.raw.chunks_exact(8) {
            out.push(f64::from_le_bytes(chunk.try_into().unwrap()));
        }
        out
    }
}

pub fn qk_fold(pending: i32, window: i32) -> i32 {
    if pending <= 0 {
        return 0;
    }
    if pending < 2 {
        return pending;
    }
    2
}

pub fn qk_tax(batch_size: i32) -> i32 {
    if batch_size <= 1 {
        220
    } else {
        120
    }
}

pub fn mx_fold(partials: &[Vec<PartialHit>], top_k: usize) -> Vec<PartialHit> {
    use std::collections::HashMap;
    let mut best: HashMap<String, PartialHit> = HashMap::new();
    for block in partials {
        for hit in block {
            let replace = best
                .get(&hit.doc_id)
                .map(|cur| hit.score > cur.score)
                .unwrap_or(true);
            if replace {
                best.insert(hit.doc_id.clone(), hit.clone());
            }
        }
    }
    let mut flat: Vec<PartialHit> = best.into_values().collect();
    flat.sort_by(|a, b| {
        b.score
            .partial_cmp(&a.score)
            .unwrap_or(std::cmp::Ordering::Equal)
            .then_with(|| a.doc_id.cmp(&b.doc_id))
    });
    let k = if top_k == 0 || top_k > flat.len() {
        flat.len()
    } else {
        top_k
    };
    flat.truncate(k);
    flat
}

pub fn r4_coord_surcharge(top_k: usize) -> u32 {
    top_k as u32
}

pub fn lx_pick<'a>(lanes: &'a [crate::lane::Lane], dead: &[usize]) -> Vec<&'a crate::lane::Lane> {
    lanes
        .iter()
        .filter(|ln| !dead.contains(&ln.shard_id))
        .collect()
}
