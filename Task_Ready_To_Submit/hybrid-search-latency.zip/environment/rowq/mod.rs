use std::collections::HashMap;
use std::sync::{Mutex, OnceLock};

struct MemoEntry {
    top_ids: Vec<String>,
    units: u32,
}

fn memo_table() -> &'static Mutex<HashMap<String, MemoEntry>> {
    static MEMO: OnceLock<Mutex<HashMap<String, MemoEntry>>> = OnceLock::new();
    MEMO.get_or_init(|| Mutex::new(HashMap::new()))
}

pub fn r3_peek(query_id: &str) -> (Option<Vec<String>>, u32, bool) {
    let _ = query_id;
    (None, 0, false)
}

pub fn r3_save(query_id: &str, top_ids: &[String], units: u32) {
    let _ = (query_id, top_ids, units);
}

pub fn r3_zero() {
    if let Ok(mut table) = memo_table().lock() {
        table.clear();
    }
}
