Helper scripts live under /app/tools. See /app/docs/runbook.md.
