use crate::types::{Corpus, Doc};
use std::path::Path;

pub fn load(path: &Path) -> Result<Vec<Doc>, String> {
    let raw = std::fs::read_to_string(path).map_err(|e| e.to_string())?;
    let corpus: Corpus = serde_json::from_str(&raw).map_err(|e| e.to_string())?;
    Ok(corpus.vectors)
}

pub const DEFAULT_CORPUS_PATH: &str = "/app/data/corpus_default.json";
