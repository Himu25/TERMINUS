use std::collections::hash_map::DefaultHasher;
use std::hash::{Hash, Hasher};

pub fn vec_from_text(text: &str, dim: usize) -> Vec<f64> {
    let dim = if dim == 0 { 32 } else { dim };
    let mut out = vec![0.0; dim];
    let mut hasher = DefaultHasher::new();
    text.hash(&mut hasher);
    let mut seed = hasher.finish();
    for v in out.iter_mut() {
        seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
        *v = ((seed >> 33) as i64 % 1000) as f64 / 500.0 - 1.0;
    }
    let norm: f64 = out.iter().map(|x| x * x).sum::<f64>().sqrt();
    if norm > 0.0 {
        for v in out.iter_mut() {
            *v /= norm;
        }
    }
    out
}

pub fn dot(a: &[f64], b: &[f64]) -> f64 {
    let n = a.len().min(b.len());
    a.iter().take(n).zip(b.iter()).map(|(x, y)| x * y).sum()
}
