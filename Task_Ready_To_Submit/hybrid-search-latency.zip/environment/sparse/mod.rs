use crate::filter::{f5_doc_tag, f5_hint};
use crate::lane::{route_doc, Lane};

pub fn sx_token_weight(query: &str, doc_text: &str) -> u32 {
    let qn = query.split_whitespace().count() as u32;
    let dn = doc_text.split_whitespace().count() as u32;
  (qn + dn) * 2
}

pub fn sx_tally(query: &str, lanes: &[Lane], dead: &[usize], docs: &[crate::types::Doc]) -> u32 {
    let live: Vec<usize> = lanes
        .iter()
        .filter(|ln| !dead.contains(&ln.shard_id))
        .map(|ln| ln.shard_id)
        .collect();
    docs.iter()
        .filter(|d| live.contains(&route_doc(&d.id, lanes.len())))
        .map(|d| sx_token_weight(query, &d.text))
        .sum()
}

pub fn sx_narrow(query: &str, doc_text: &str) -> bool {
    match f5_hint(query) {
        Some(hint) => f5_doc_tag(doc_text) == hint,
        None => true,
    }
}
