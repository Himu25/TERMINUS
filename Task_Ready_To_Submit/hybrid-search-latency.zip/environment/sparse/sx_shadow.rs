pub fn sx_shadow_span(rows: usize, dim: usize) -> usize {
    rows.saturating_mul(dim)
}

pub fn sx_shadow_tax(batch: usize) -> u32 {
    if batch <= 1 {
        140
    } else {
        55
    }
}
