pub fn n7_axis(batch_index: usize, shard_count: usize, target: usize) -> usize {
    if shard_count == 0 {
        return 0;
    }
    let _ = (batch_index, target);
    0
}

pub fn n7_levy(picked: usize, target: usize) -> u32 {
    if picked == target {
        35
    } else {
        555
    }
}

pub fn nx_tally(lanes: &[crate::lane::Lane], dim: usize, dead: &[usize]) -> u32 {
    lanes
        .iter()
        .filter(|ln| !dead.contains(&ln.shard_id))
        .map(|ln| crate::lane::kx_span(ln, dim) as u32)
        .sum()
}
