use crate::bench::{
    coalesce_tax, coalesce_window, fanout_partials, fold_top_k, memo_lookup, memo_save, m3_tick,
    m3_wake, probe_units, scratch_alloc, scratch_peak, worker_pick, worker_tax,
};
use crate::cache;
use crate::codec::pack_vec;
use crate::corpus;
use crate::embed::vec_from_text;
use crate::filter;
use crate::lane::{empty_lanes, route_doc, Lane};
use crate::sparse;
use crate::rowq;
use crate::types::{BenchReport, HybridCfg, QueryCase, QueryRow};
use sha2::{Digest, Sha256};
use std::path::Path;

pub fn load_cfg(path: &str) -> Result<HybridCfg, String> {
    let raw = std::fs::read_to_string(path).map_err(|e| e.to_string())?;
    let mut cfg = HybridCfg {
        vector_dim: 32,
        shard_count: 4,
        top_k: 10,
        batch_window: 8,
        recall_floor: 0.82,
        ndcg_floor: 0.72,
        max_mean_leg_a_units: 1600,
        max_mean_leg_b_units: 4200,
        max_mean_merge_units: 70,
        max_p95_query_units: 4800,
        min_batch_efficiency: 0.62,
        max_peak_scratch_bytes: 512,
        max_starved_lanes: 1,
        max_starved_lanes_skew: 1,
        min_tile_reuse_hits: 1,
        max_inval_churn_events: 4,
        min_filter_prune_hits: 12,
        failover_recall_floor: 0.65,
        tight_security_recall_floor: 0.5,
        corpus_path: corpus::DEFAULT_CORPUS_PATH.to_string(),
    };
    for line in raw.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let Some((key, val)) = line.split_once('=') else {
            continue;
        };
        let key = key.trim();
        let val = val.trim();
        match key {
            "vector_dim" => cfg.vector_dim = val.parse::<usize>().map_err(|e| e.to_string())?,
            "shard_count" => cfg.shard_count = val.parse::<usize>().map_err(|e| e.to_string())?,
            "top_k" => cfg.top_k = val.parse::<usize>().map_err(|e| e.to_string())?,
            "batch_window" => cfg.batch_window = val.parse::<usize>().map_err(|e| e.to_string())?,
            "recall_floor" | "ndcg_floor" | "min_batch_efficiency" | "failover_recall_floor"
            | "tight_security_recall_floor" => {
                let f: f64 = val.parse::<f64>().map_err(|e| e.to_string())?;
                match key {
                    "recall_floor" => cfg.recall_floor = f,
                    "ndcg_floor" => cfg.ndcg_floor = f,
                    "min_batch_efficiency" => cfg.min_batch_efficiency = f,
                    "failover_recall_floor" => cfg.failover_recall_floor = f,
                    "tight_security_recall_floor" => cfg.tight_security_recall_floor = f,
                    _ => {}
                }
            }
            "max_mean_leg_a_units" => {
                cfg.max_mean_leg_a_units = val.parse::<u32>().map_err(|e| e.to_string())?
            }
            "max_mean_leg_b_units" => {
                cfg.max_mean_leg_b_units = val.parse::<u32>().map_err(|e| e.to_string())?
            }
            "max_mean_merge_units" => {
                cfg.max_mean_merge_units = val.parse::<u32>().map_err(|e| e.to_string())?
            }
            "max_p95_query_units" => {
                cfg.max_p95_query_units = val.parse::<u32>().map_err(|e| e.to_string())?
            }
            "max_peak_scratch_bytes" => {
                cfg.max_peak_scratch_bytes = val.parse::<u32>().map_err(|e| e.to_string())?
            }
            "max_starved_lanes" => cfg.max_starved_lanes = val.parse::<u32>().map_err(|e| e.to_string())?,
            "max_starved_lanes_skew" => {
                cfg.max_starved_lanes_skew = val.parse::<u32>().map_err(|e| e.to_string())?
            }
            "min_tile_reuse_hits" => {
                cfg.min_tile_reuse_hits = val.parse::<u32>().map_err(|e| e.to_string())?
            }
            "max_inval_churn_events" => {
                cfg.max_inval_churn_events = val.parse::<u32>().map_err(|e| e.to_string())?
            }
            "min_filter_prune_hits" => {
                cfg.min_filter_prune_hits = val.parse::<u32>().map_err(|e| e.to_string())?
            }
            "corpus_path" => cfg.corpus_path = val.to_string(),
            _ => {}
        }
    }
    Ok(cfg)
}

pub fn load_queries(path: &Path) -> Result<Vec<QueryCase>, String> {
    let raw = std::fs::read_to_string(path).map_err(|e| e.to_string())?;
    let mut out = Vec::new();
    for line in raw.lines() {
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        out.push(serde_json::from_str(line).map_err(|e| e.to_string())?);
    }
    Ok(out)
}

fn build_lanes(docs: &[crate::types::Doc], cfg: &HybridCfg) -> Vec<Lane> {
    let mut lanes = empty_lanes(cfg.shard_count);
    for doc in docs {
        let vec = vec_from_text(&doc.text, cfg.vector_dim);
        let sid = route_doc(&doc.id, cfg.shard_count);
        lanes[sid].rows.push(pack_vec(&doc.id, &vec));
    }
    lanes
}

fn round4(v: f64) -> f64 {
    (v * 10000.0).round() / 10000.0
}

fn rank_scores(gold: &[String], got: &[String], k: usize) -> (f64, f64, u32) {
    if gold.is_empty() {
        return (0.0, 0.0, 0);
    }
    let gold_set: std::collections::HashSet<_> = gold.iter().collect();
    let k = if k == 0 || k > got.len() { got.len() } else { k };
    let mut hits = 0u32;
    let mut rel = Vec::new();
    for id in got.iter().take(k) {
        if gold_set.contains(id) {
            hits += 1;
            rel.push(1.0);
        } else {
            rel.push(0.0);
        }
    }
    let recall = hits as f64 / gold.len() as f64;
    let mut dcg = 0.0;
    for (i, r) in rel.iter().enumerate() {
        if *r > 0.0 {
            dcg += r / (i as f64 + 2.0).log2();
        }
    }
    let ideal_len = gold.len().min(k);
    let idcg: f64 = (0..ideal_len).map(|i| 1.0 / (i as f64 + 2.0).log2()).sum();
    let ndcg = if idcg > 0.0 { dcg / idcg } else { 0.0 };
    (round4(recall), round4(ndcg), hits)
}

fn p95(values: &[u32]) -> u32 {
    if values.is_empty() {
        return 0;
    }
    let mut cp = values.to_vec();
    cp.sort_unstable();
    let idx = ((0.95 * cp.len() as f64).ceil() as usize).saturating_sub(1);
    cp[idx.min(cp.len() - 1)]
}

fn meets_floors(cfg: &HybridCfg, report: &BenchReport) -> bool {
    if report.mean_recall_at_10 < cfg.recall_floor {
        return false;
    }
    if report.mean_ndcg_at_10 < cfg.ndcg_floor {
        return false;
    }
    if report.mean_leg_a_units > cfg.max_mean_leg_a_units as f64 {
        return false;
    }
    if report.mean_leg_b_units > cfg.max_mean_leg_b_units as f64 {
        return false;
    }
    if report.mean_merge_units > cfg.max_mean_merge_units as f64 {
        return false;
    }
    if report.p95_query_units > cfg.max_p95_query_units {
        return false;
    }
    if report.mean_batch_efficiency < cfg.min_batch_efficiency {
        return false;
    }
    if report.peak_scratch_bytes > cfg.max_peak_scratch_bytes {
        return false;
    }
    if report.starved_lanes > cfg.max_starved_lanes {
        return false;
    }
    if report.tile_reuse_hits < cfg.min_tile_reuse_hits {
        return false;
    }
    if report.inval_churn_events > cfg.max_inval_churn_events {
        return false;
    }
    if report.mean_filter_prune_hits < cfg.min_filter_prune_hits as f64 {
        return false;
    }
    true
}

pub fn run(cfg: &HybridCfg, cases: &[QueryCase]) -> Result<BenchReport, String> {
    let corpus_path = std::env::var("TB_CORPUS_PATH").unwrap_or_else(|_| cfg.corpus_path.clone());
    let docs = corpus::load(Path::new(&corpus_path))?;
    let lanes = build_lanes(&docs, cfg);
    rowq::r3_zero();
    cache::t4_zero_inval();
    m3_wake();
    let mut lane_hits = vec![0u32; cfg.shard_count];
    let mut sum_recall = 0.0;
    let mut sum_ndcg = 0.0;
    let mut sum_leg_a = 0.0;
    let mut sum_leg_b = 0.0;
    let mut sum_merge = 0.0;
    let mut sum_prune = 0.0;
    let mut sum_batch = 0.0;
    let mut query_units = Vec::new();
    let mut queries = Vec::new();
    let mut tile_reuse_hits = 0u32;
    let mut idx = 0usize;
    let mut ticks = 0u32;
    while idx < cases.len() {
        let n = coalesce_window(cases.len() - idx, cfg.batch_window);
        if n == 0 {
            break;
        }
        ticks += 1;
        for j in 0..n {
            let qc = &cases[idx + j];
            sum_batch += n as f64;
            let qv = vec_from_text(&qc.query, cfg.vector_dim);
            let _scratch = scratch_alloc(cfg.vector_dim);
            let target = route_doc(&qc.query_id, cfg.shard_count);
            let pick = worker_pick(target, j, cfg.shard_count);
            if pick < lane_hits.len() {
                lane_hits[pick] += 1;
            }
            let (prune_hits, _kept) = filter::f5_prune(&qc.query, &docs);
            sum_prune += prune_hits as f64;
            if let (Some(top), units, true) = {
                let (ids, u, ok) = memo_lookup(&qc.query_id);
                (ids, u, ok)
            } {
                tile_reuse_hits += 1;
                let (recall, ndcg, hits) = rank_scores(&qc.gold_ids, &top, cfg.top_k);
                queries.push(QueryRow {
                    query_id: qc.query_id.clone(),
                    recall_at_10: recall,
                    ndcg_at_10: ndcg,
                    gold_hits: hits,
                    leg_a_units: 0,
                    leg_b_units: units,
                    merge_units: 0,
                    query_units: units,
                    filter_prune_hits: prune_hits,
                    top_ids: top,
                    batch_size: n as u32,
                    tile_hit: true,
                });
                sum_recall += recall;
                sum_ndcg += ndcg;
                sum_leg_b += units as f64;
                query_units.push(units);
                continue;
            }
            let partials = fanout_partials(&qv, &lanes, &qc.dead_shards, cfg.top_k);
            let (merged, merge_u) = fold_top_k(&partials, cfg.top_k);
            let leg_b = probe_units(&lanes, cfg.vector_dim, &qc.dead_shards);
            let leg_a = sparse::sx_tally(&qc.query, &lanes, &qc.dead_shards, &docs);
            let sched_u = coalesce_tax(n) + worker_tax(pick, target);
            let query_u = leg_a + leg_b + merge_u + sched_u;
            let top_ids: Vec<String> = merged.iter().map(|h| h.doc_id.clone()).collect();
            let (recall, ndcg, hits) = rank_scores(&qc.gold_ids, &top_ids, cfg.top_k);
            queries.push(QueryRow {
                query_id: qc.query_id.clone(),
                recall_at_10: recall,
                ndcg_at_10: ndcg,
                gold_hits: hits,
                leg_a_units: leg_a,
                leg_b_units: leg_b,
                merge_units: merge_u,
                query_units: query_u,
                filter_prune_hits: prune_hits,
                top_ids: top_ids.clone(),
                batch_size: n as u32,
                tile_hit: false,
            });
            memo_save(&qc.query_id, &top_ids, query_u);
            sum_recall += recall;
            sum_ndcg += ndcg;
            sum_leg_a += leg_a as f64;
            sum_leg_b += leg_b as f64;
            sum_merge += merge_u as f64;
            query_units.push(query_u);
        }
        idx += n;
        if idx < cases.len() {
            if cache::t4_should_purge(ticks) {
                rowq::r3_zero();
            }
            cache::t4_note_inval();
            m3_tick();
        }
    }
    let starved = lane_hits.iter().filter(|&&c| c == 0).count() as u32;
    let qn = cases.len() as f64;
    let mut report = BenchReport {
        status: "ok".to_string(),
        corpus_vectors: docs.len(),
        vector_dim: cfg.vector_dim,
        shard_count: cfg.shard_count,
        queries_total: cases.len(),
        mean_recall_at_10: 0.0,
        mean_ndcg_at_10: 0.0,
        mean_leg_a_units: 0.0,
        mean_leg_b_units: 0.0,
        mean_merge_units: 0.0,
        mean_filter_prune_hits: 0.0,
        tile_reuse_hits,
        inval_churn_events: cache::t4_read_inval(),
        mean_batch_efficiency: 0.0,
        p95_query_units: p95(&query_units),
        peak_scratch_bytes: scratch_peak(),
        starved_lanes: starved,
        report_digest: String::new(),
        queries,
    };
    if qn > 0.0 {
        report.mean_recall_at_10 = round4(sum_recall / qn);
        report.mean_ndcg_at_10 = round4(sum_ndcg / qn);
        report.mean_leg_a_units = round4(sum_leg_a / qn);
        report.mean_leg_b_units = round4(sum_leg_b / qn);
        report.mean_merge_units = round4(sum_merge / qn);
        report.mean_filter_prune_hits = round4(sum_prune / qn);
    }
    if ticks > 0 && cfg.batch_window > 0 {
        report.mean_batch_efficiency =
            round4(sum_batch / ticks as f64 / cfg.batch_window as f64);
    }
    if !meets_floors(cfg, &report) {
        report.status = "fail".to_string();
    }
    report.report_digest = digest_body(&report);
    Ok(report)
}

#[derive(serde::Serialize)]
struct DigestPayload<'a> {
    status: &'a str,
    corpus_vectors: usize,
    vector_dim: usize,
    shard_count: usize,
    queries_total: usize,
    mean_recall_at_10: f64,
    mean_ndcg_at_10: f64,
    mean_leg_a_units: f64,
    mean_leg_b_units: f64,
    mean_merge_units: f64,
    mean_filter_prune_hits: f64,
    tile_reuse_hits: u32,
    inval_churn_events: u32,
    mean_batch_efficiency: f64,
    p95_query_units: u32,
    peak_scratch_bytes: u32,
    starved_lanes: u32,
    report_digest: &'static str,
    queries: &'a [QueryRow],
}

fn digest_body(report: &BenchReport) -> String {
    let payload = DigestPayload {
        status: &report.status,
        corpus_vectors: report.corpus_vectors,
        vector_dim: report.vector_dim,
        shard_count: report.shard_count,
        queries_total: report.queries_total,
        mean_recall_at_10: report.mean_recall_at_10,
        mean_ndcg_at_10: report.mean_ndcg_at_10,
        mean_leg_a_units: report.mean_leg_a_units,
        mean_leg_b_units: report.mean_leg_b_units,
        mean_merge_units: report.mean_merge_units,
        mean_filter_prune_hits: report.mean_filter_prune_hits,
        tile_reuse_hits: report.tile_reuse_hits,
        inval_churn_events: report.inval_churn_events,
        mean_batch_efficiency: report.mean_batch_efficiency,
        p95_query_units: report.p95_query_units,
        peak_scratch_bytes: report.peak_scratch_bytes,
        starved_lanes: report.starved_lanes,
        report_digest: "",
        queries: &report.queries,
    };
    let raw = serde_json::to_string(&payload).unwrap_or_default();
    format!("{:x}", Sha256::digest(raw.as_bytes()))
}

pub fn write_report(path: &Path, report: &BenchReport) -> Result<(), String> {
    let raw = serde_json::to_string_pretty(report).map_err(|e| e.to_string())?;
    std::fs::write(path, raw).map_err(|e| e.to_string())
}
