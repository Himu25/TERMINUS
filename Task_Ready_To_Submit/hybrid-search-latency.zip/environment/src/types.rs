use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Deserialize)]
pub struct Doc {
    pub id: String,
    pub text: String,
}

#[derive(Debug, Deserialize)]
pub struct Corpus {
    pub vectors: Vec<Doc>,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct QueryCase {
    pub query_id: String,
    pub query: String,
    #[serde(default)]
    pub gold_ids: Vec<String>,
    #[serde(default)]
    pub dead_shards: Vec<usize>,
}

#[derive(Debug, Clone, Serialize)]
pub struct QueryRow {
    pub query_id: String,
    pub recall_at_10: f64,
    pub ndcg_at_10: f64,
    pub gold_hits: u32,
    pub leg_a_units: u32,
    pub leg_b_units: u32,
    pub merge_units: u32,
    pub query_units: u32,
    pub filter_prune_hits: u32,
    pub top_ids: Vec<String>,
    pub batch_size: u32,
    pub tile_hit: bool,
}

#[derive(Debug, Serialize)]
pub struct BenchReport {
    pub status: String,
    pub corpus_vectors: usize,
    pub vector_dim: usize,
    pub shard_count: usize,
    pub queries_total: usize,
    pub mean_recall_at_10: f64,
    pub mean_ndcg_at_10: f64,
    pub mean_leg_a_units: f64,
    pub mean_leg_b_units: f64,
    pub mean_merge_units: f64,
    pub mean_filter_prune_hits: f64,
    pub tile_reuse_hits: u32,
    pub inval_churn_events: u32,
    pub mean_batch_efficiency: f64,
    pub p95_query_units: u32,
    pub peak_scratch_bytes: u32,
    pub starved_lanes: u32,
    pub report_digest: String,
    pub queries: Vec<QueryRow>,
}

#[derive(Debug, Clone)]
pub struct HybridCfg {
    pub vector_dim: usize,
    pub shard_count: usize,
    pub top_k: usize,
    pub batch_window: usize,
    pub recall_floor: f64,
    pub ndcg_floor: f64,
    pub max_mean_leg_a_units: u32,
    pub max_mean_leg_b_units: u32,
    pub max_mean_merge_units: u32,
    pub max_p95_query_units: u32,
    pub min_batch_efficiency: f64,
    pub max_peak_scratch_bytes: u32,
    pub max_starved_lanes: u32,
    pub max_starved_lanes_skew: u32,
    pub min_tile_reuse_hits: u32,
    pub max_inval_churn_events: u32,
    pub min_filter_prune_hits: u32,
    pub failover_recall_floor: f64,
    pub tight_security_recall_floor: f64,
    pub corpus_path: String,
}

#[derive(Debug, Clone)]
pub struct PartialHit {
    pub doc_id: String,
    pub score: f64,
    pub shard: usize,
}
