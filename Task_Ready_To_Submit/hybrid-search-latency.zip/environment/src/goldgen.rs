use hybrid_bench::bench_drive;
use hybrid_bench::embed::{dot, vec_from_text};
use hybrid_bench::lane::route_doc;
use hybrid_bench::types::QueryCase;
use std::io::{BufRead, Write};
use std::path::Path;

fn main() -> Result<(), String> {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 4 {
        return Err("usage: goldgen <corpus.json> <specs.jsonl> <out.jsonl>".to_string());
    }
    let cfg = bench_drive::load_cfg("/app/config/hybrid.toml")?;
    let docs = hybrid_bench::corpus::load(Path::new(&args[1]))?;
    let specs = std::fs::read_to_string(&args[2]).map_err(|e| e.to_string())?;
    let mut out = std::fs::File::create(&args[3]).map_err(|e| e.to_string())?;
    for line in specs.lines() {
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        let spec: serde_json::Value = serde_json::from_str(line).map_err(|e| e.to_string())?;
        let query_id = spec["query_id"].as_str().unwrap_or("").to_string();
        let query = spec["query"].as_str().unwrap_or("").to_string();
        let dead_shards: Vec<usize> = spec["dead_shards"]
            .as_array()
            .map(|arr| {
                arr.iter()
                    .filter_map(|v| v.as_u64().map(|n| n as usize))
                    .collect()
            })
            .unwrap_or_default();
        let qv = vec_from_text(&query, cfg.vector_dim);
        let dead: std::collections::HashSet<usize> = dead_shards.iter().copied().collect();
        let mut pairs: Vec<(String, f64)> = Vec::new();
        for doc in &docs {
            let sid = route_doc(&doc.id, cfg.shard_count);
            if dead.contains(&sid) {
                continue;
            }
            let vec = vec_from_text(&doc.text, cfg.vector_dim);
            pairs.push((doc.id.clone(), dot(&qv, &vec)));
        }
        pairs.sort_by(|a, b| {
            b.1.partial_cmp(&a.1)
                .unwrap_or(std::cmp::Ordering::Equal)
                .then_with(|| a.0.cmp(&b.0))
        });
        let k = cfg.top_k.min(pairs.len());
        let gold: Vec<String> = pairs.into_iter().take(k).map(|(id, _)| id).collect();
        let row = QueryCase {
            query_id,
            query,
            gold_ids: gold,
            dead_shards,
        };
        let raw = serde_json::to_string(&row).map_err(|e| e.to_string())?;
        writeln!(out, "{raw}").map_err(|e| e.to_string())?;
    }
    Ok(())
}
