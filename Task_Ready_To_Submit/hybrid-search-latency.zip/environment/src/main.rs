use hybrid_bench::bench_drive;
use std::path::PathBuf;

fn main() -> Result<(), String> {
    let cfg = bench_drive::load_cfg("/app/config/hybrid.toml")?;
    let query_path = PathBuf::from(
        std::env::args()
            .nth(1)
            .unwrap_or_else(|| "/app/data/queries_default.jsonl".to_string()),
    );
    let out_path = PathBuf::from(
        std::env::args()
            .nth(2)
            .unwrap_or_else(|| "/app/output/hybrid_bench_report.json".to_string()),
    );
    let cases = bench_drive::load_queries(&query_path)?;
    let report = bench_drive::run(&cfg, &cases)?;
    bench_drive::write_report(&out_path, &report)
}
