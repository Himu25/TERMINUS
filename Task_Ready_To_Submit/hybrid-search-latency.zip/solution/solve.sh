#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

require_file() {
  if [[ ! -f "$1" ]]; then
    echo "missing required file: $1" >&2
    exit 1
  fi
}

require_file /app/Cargo.toml
require_file /app/config/hybrid.toml
require_file /app/data/corpus_default.json
require_file /app/data/query_specs.jsonl
mkdir -p /app/bin /app/output

cp "${ROOT_DIR}/oracle/codec_mod.rs" /app/codec/mod.rs
cp "${ROOT_DIR}/oracle/coord_mod.rs" /app/coord/mod.rs
cp "${ROOT_DIR}/oracle/rerank_mod.rs" /app/rerank/mod.rs
cp "${ROOT_DIR}/oracle/sparse_mod.rs" /app/sparse/mod.rs
cp "${ROOT_DIR}/oracle/rowq_mod.rs" /app/rowq/mod.rs
cp "${ROOT_DIR}/oracle/node_mod.rs" /app/node/mod.rs
cp "${ROOT_DIR}/oracle/filter_mod.rs" /app/filter/mod.rs
cp "${ROOT_DIR}/oracle/cache_mod.rs" /app/cache/mod.rs
cp "${ROOT_DIR}/oracle/bench_mod.rs" /app/bench/mod.rs

export CARGO_TARGET_DIR=/app/output/cargo-target
cd /app
cargo build --release --manifest-path /app/Cargo.toml
install -m 0755 /app/output/cargo-target/release/hybrid_bench /app/bin/hybrid_bench
install -m 0755 /app/output/cargo-target/release/goldgen /app/bin/goldgen
chmod +x /app/tools/run_replay

/app/bin/goldgen \
  /app/data/corpus_default.json \
  /app/data/query_specs.jsonl \
  /app/data/queries_default.jsonl

/app/tools/run_replay \
  /app/data/queries_default.jsonl \
  /app/output/hybrid_bench_report.json

python3 - <<'PY'
import json
from pathlib import Path

cfg: dict[str, float | int] = {}
for line in Path("/app/config/hybrid.toml").read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    key, val = (part.strip() for part in line.split("=", 1))
    if key.endswith("_floor") or key.startswith("min_"):
        cfg[key] = float(val)
    elif key.startswith("max_") or key in {"batch_window", "min_tile_reuse_hits", "min_filter_prune_hits"}:
        cfg[key] = int(float(val))

report = json.loads(Path("/app/output/hybrid_bench_report.json").read_text())
assert report["status"] == "ok", report
assert report["mean_recall_at_10"] >= cfg["recall_floor"]
assert report["mean_leg_a_units"] <= cfg["max_mean_leg_a_units"]
assert report["mean_merge_units"] <= cfg["max_mean_merge_units"]
assert report["mean_batch_efficiency"] >= cfg["min_batch_efficiency"]
assert report["p95_query_units"] <= cfg["max_p95_query_units"]
assert report["peak_scratch_bytes"] <= cfg["max_peak_scratch_bytes"]
assert report["starved_lanes"] <= cfg["max_starved_lanes"]
assert report["tile_reuse_hits"] >= cfg["min_tile_reuse_hits"]
assert report["inval_churn_events"] <= cfg["max_inval_churn_events"]
assert report["mean_filter_prune_hits"] >= cfg["min_filter_prune_hits"]
assert any(q.get("tile_hit") for q in report["queries"])
print("oracle ok", report["p95_query_units"], report["tile_reuse_hits"])
PY
