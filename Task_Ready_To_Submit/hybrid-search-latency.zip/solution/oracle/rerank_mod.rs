use crate::types::PartialHit;

pub fn hy_surcharge(_partials: &[Vec<PartialHit>], top_k: usize) -> u32 {
    top_k as u32
}

pub fn hy_blend_score(sparse: f64, dense: f64) -> f64 {
    sparse * 0.35 + dense * 0.65
}
