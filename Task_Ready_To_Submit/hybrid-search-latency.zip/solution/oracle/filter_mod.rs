pub fn f5_hint(query: &str) -> Option<&'static str> {
    let q = query.to_ascii_lowercase();
    if q.contains("billing") {
        Some("billing")
    } else if q.contains("security") || q.contains("credential") {
        Some("security")
    } else if q.contains("search") || q.contains("ann") {
        Some("search")
    } else if q.contains("ops") || q.contains("cohort") || q.contains("skew") || q.contains("partition") {
        Some("ops")
    } else {
        None
    }
}

pub fn f5_doc_tag(text: &str) -> &'static str {
    let t = text.to_ascii_lowercase();
    if t.contains("billing") {
        "billing"
    } else if t.contains("security") || t.contains("credential") {
        "security"
    } else if t.contains("search") || t.contains("ann") {
        "search"
    } else {
        "ops"
    }
}

pub fn f5_prune(query: &str, docs: &[crate::types::Doc]) -> (u32, u32) {
    let Some(hint) = f5_hint(query) else {
        return (0, docs.len() as u32);
    };
    let mut kept = 0u32;
    for doc in docs {
        if f5_doc_tag(&doc.text) == hint {
            kept += 1;
        }
    }
    let pruned = docs.len().saturating_sub(kept as usize) as u32;
    (pruned, kept)
}
