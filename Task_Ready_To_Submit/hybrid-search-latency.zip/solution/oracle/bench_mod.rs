use std::sync::atomic::{AtomicU32, Ordering};
use std::sync::Mutex;

static PEAK_ARENA: AtomicU32 = AtomicU32::new(0);
static PEAK_ARENA_MAX: AtomicU32 = AtomicU32::new(0);
static SHARED_CAP: Mutex<usize> = Mutex::new(0);

pub fn m3_zero() {
    PEAK_ARENA.store(0, Ordering::Relaxed);
    PEAK_ARENA_MAX.store(0, Ordering::Relaxed);
    if let Ok(mut cap) = SHARED_CAP.lock() {
        *cap = 0;
    }
}

pub fn m3_wake() {
    m3_zero();
}

pub fn m3_tick() {
    PEAK_ARENA.store(0, Ordering::Relaxed);
}

pub fn m3_bump(dim: usize) -> Vec<f64> {
    let used = (dim * 8) as u32;
    let mut peak = PEAK_ARENA.load(Ordering::Relaxed);
    while used > peak {
        match PEAK_ARENA.compare_exchange_weak(peak, used, Ordering::Relaxed, Ordering::Relaxed) {
            Ok(_) => break,
            Err(current) => peak = current,
        }
    }
    let mut max_peak = PEAK_ARENA_MAX.load(Ordering::Relaxed);
    while used > max_peak {
        match PEAK_ARENA_MAX.compare_exchange_weak(max_peak, used, Ordering::Relaxed, Ordering::Relaxed)
        {
            Ok(_) => break,
            Err(current) => max_peak = current,
        }
    }
  if let Ok(mut cap) = SHARED_CAP.lock() {
        if *cap < dim {
            *cap = dim;
        }
    }
    vec![0.0; dim]
}

pub fn m3_high() -> u32 {
    PEAK_ARENA_MAX.load(Ordering::Relaxed)
}

pub fn fold_top_k(
    partials: &[Vec<crate::types::PartialHit>],
    top_k: usize,
) -> (Vec<crate::types::PartialHit>, u32) {
    let merged = crate::codec::mx_fold(partials, top_k);
    (merged, crate::coord::r4_weight(partials, top_k))
}

pub fn fanout_partials(
    query: &[f64],
    lanes: &[crate::lane::Lane],
    dead: &[usize],
    top_k: usize,
) -> Vec<Vec<crate::types::PartialHit>> {
    crate::codec::lx_pick(lanes, dead)
        .into_iter()
        .map(|ln| crate::lane::px_scan(query, ln, top_k))
        .collect()
}

pub fn probe_units(lanes: &[crate::lane::Lane], dim: usize, dead: &[usize]) -> u32 {
    crate::node::nx_tally(lanes, dim, dead)
}

pub fn coalesce_window(pending: usize, window: usize) -> usize {
    crate::codec::qk_fold(pending as i32, window as i32) as usize
}

pub fn coalesce_tax(batch_size: usize) -> u32 {
    crate::codec::qk_tax(batch_size as i32) as u32
}

pub fn memo_lookup(query_id: &str) -> (Option<Vec<String>>, u32, bool) {
    let (ids, units, ok) = crate::rowq::r3_peek(query_id);
    (ids, units, ok)
}

pub fn memo_save(query_id: &str, top_ids: &[String], units: u32) {
    crate::rowq::r3_save(query_id, top_ids, units);
}

pub fn scratch_alloc(dim: usize) -> Vec<f64> {
    m3_bump(dim)
}

pub fn scratch_peak() -> u32 {
    m3_high()
}

pub fn worker_pick(target: usize, batch_index: usize, shard_count: usize) -> usize {
    crate::node::n7_axis(batch_index, shard_count, target)
}

pub fn worker_tax(picked: usize, target: usize) -> u32 {
    crate::node::n7_levy(picked, target)
}
