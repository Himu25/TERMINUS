use crate::rerank;
use crate::types::PartialHit;

pub use crate::codec::mx_fold;

pub fn r4_coord_surcharge(top_k: usize) -> u32 {
    top_k as u32
}

pub fn r4_weight(partials: &[Vec<PartialHit>], top_k: usize) -> u32 {
    if partials.is_empty() {
        return 0;
    }
    (top_k as u32) * (partials.len() as u32) + rerank::hy_surcharge(partials, top_k)
}
