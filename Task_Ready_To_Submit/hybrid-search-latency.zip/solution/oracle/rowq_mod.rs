use std::collections::HashMap;
use std::sync::{Mutex, OnceLock};

struct MemoEntry {
    top_ids: Vec<String>,
    units: u32,
}

fn memo_table() -> &'static Mutex<HashMap<String, MemoEntry>> {
    static MEMO: OnceLock<Mutex<HashMap<String, MemoEntry>>> = OnceLock::new();
    MEMO.get_or_init(|| Mutex::new(HashMap::new()))
}

pub fn r3_peek(query_id: &str) -> (Option<Vec<String>>, u32, bool) {
    if let Ok(table) = memo_table().lock() {
        if let Some(ent) = table.get(query_id) {
            return (Some(ent.top_ids.clone()), ent.units, true);
        }
    }
    (None, 0, false)
}

pub fn r3_save(query_id: &str, top_ids: &[String], units: u32) {
    if let Ok(mut table) = memo_table().lock() {
        table.insert(
            query_id.to_string(),
            MemoEntry {
                top_ids: top_ids.to_vec(),
                units,
            },
        );
    }
}

pub fn r3_zero() {
    if let Ok(mut table) = memo_table().lock() {
        table.clear();
    }
}
