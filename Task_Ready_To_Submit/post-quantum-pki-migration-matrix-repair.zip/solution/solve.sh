#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
cd /app

cat > crates/k7core/src/blk/blend.rs <<'EOF'
use crate::next_stamp;

pub fn blend_v(payload: &[u8], wire_mode: &str) -> Vec<u8> {
    let raw = next_stamp(payload);
    if wire_mode == "fixed256" {
        let mut slot = vec![0u8; 256];
        let copy_len = raw.len().min(255);
        slot[..copy_len].copy_from_slice(&raw[..copy_len]);
        slot[255] = (raw.len() & 0xff) as u8;
        return slot;
    }
    raw
}
EOF

cat > crates/k7core/src/blk/pack.rs <<'EOF'
use crate::{legacy_stamp, next_stamp};

const COMPACT_TAG: u8 = 0x01;
const LEGACY_PREFIX: usize = 32;
const DEFAULT_CAP: usize = 384;

pub fn pack_h(payload: &[u8]) -> Vec<u8> {
    let leg = legacy_stamp(payload);
    let nxt = next_stamp(payload);
    let cap = DEFAULT_CAP;
    let mut out = Vec::with_capacity(cap);
    out.push(COMPACT_TAG);
    out.extend_from_slice(&leg[..LEGACY_PREFIX]);
    let room = cap.saturating_sub(1 + LEGACY_PREFIX);
    if nxt.len() <= room {
        out.extend_from_slice(&nxt);
    } else {
        out.extend_from_slice(&nxt[..room]);
    }
    out
}
EOF

cat > crates/k7core/src/meter/mod.rs <<'EOF'
pub fn op_count(payload: &[u8], hybrid: bool) -> u32 {
    let tag = if payload.is_empty() {
        0
    } else {
        payload[0] as u32
    };
    let mut acc = 100 + (tag % 17);
    if hybrid {
        acc = acc.wrapping_add(40);
    }
    acc
}
EOF

cat > internal/driver/plan.go <<'EOF'
package driver

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"

	"pqcrollout/internal/inventory"
	"pqcrollout/pkg/api"
)

func scanT(inventoryDir, serviceName string) int {
	path := inventory.ServiceManifest(inventoryDir, serviceName)
	raw, err := os.ReadFile(path)
	if err != nil {
		return 0
	}
	text := string(raw)
	hits := 0
	if strings.Contains(text, "MODULUS_BITS:") {
		hits++
	}
	if strings.Contains(text, "TRUST_LINEAGE:") {
		hits += countRoots(inventoryDir)
	}
	return hits
}

func countRoots(inventoryDir string) int {
	path := filepath.Join(inventoryDir, "pki", "roots.json")
	raw, err := os.ReadFile(path)
	if err != nil {
		return 0
	}
	var doc struct {
		Roots []struct {
			ModulusBits int `json:"modulus_bits"`
		} `json:"roots"`
	}
	if err := json.Unmarshal(raw, &doc); err != nil {
		return 0
	}
	return len(doc.Roots)
}

func phaseR(sc *api.Scenario) bool {
	if sc.HsmLocked {
		return true
	}
	return true
}
EOF

cat > internal/inventory/resolve.go <<'EOF'
package inventory

import (
	"path/filepath"
)

func ServiceManifest(inventoryDir, serviceName string) string {
	return filepath.Join(inventoryDir, "services", serviceName+".yaml")
}
EOF

cd /app/crates/k7core && cargo build --release --bin wkctl
install -m 0755 /app/crates/k7core/target/release/wkctl /app/bin/wkctl
cd /app && go build -o /app/bin/advisor ./cmd/advisor

bash /app/ci/run_migration_matrix.sh
rm -rf /app/crates/k7core/target
