package driver

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"

	"pqcrollout/internal/inventory"
	"pqcrollout/pkg/api"
)

func scanT(inventoryDir, serviceName string) int {
	path := inventory.ServiceManifest(inventoryDir, serviceName)
	raw, err := os.ReadFile(path)
	if err != nil {
		return 0
	}
	text := string(raw)
	hits := 0
	if strings.Contains(text, "KEY_BITS:") {
		hits++
	}
	if strings.Contains(text, "TRUST_LINEAGE:") {
		hits += countRoots(inventoryDir)
	}
	return hits
}

func countRoots(inventoryDir string) int {
	path := filepath.Join(inventoryDir, "pki", "roots.json")
	raw, err := os.ReadFile(path)
	if err != nil {
		return 0
	}
	var doc struct {
		Roots []struct {
			ModulusBits int `json:"modulus_bits"`
		} `json:"roots"`
	}
	if err := json.Unmarshal(raw, &doc); err != nil {
		return 0
	}
	return len(doc.Roots)
}

func phaseR(sc *api.Scenario) bool {
	if !sc.HsmLocked {
		return true
	}
	return false
}
