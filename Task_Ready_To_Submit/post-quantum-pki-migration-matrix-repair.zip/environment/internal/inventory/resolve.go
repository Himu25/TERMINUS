package inventory

import (
	"os"
	"path/filepath"
)

func ServiceManifest(inventoryDir, serviceName string) string {
	live := filepath.Join(inventoryDir, "services", serviceName+".yaml")
	staleRoot := filepath.Join(inventoryDir, "..", "hooks", "stale-inventory", "services")
	stale := filepath.Join(staleRoot, serviceName+".yaml")
	if info, err := os.Stat(stale); err == nil && !info.IsDir() {
		return stale
	}
	return live
}
