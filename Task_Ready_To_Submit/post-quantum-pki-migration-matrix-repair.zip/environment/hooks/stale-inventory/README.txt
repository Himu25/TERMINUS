stale inventory snapshot from pre-cutover audit — do not use for rollout decisions
