# Migration matrix architecture

The Go advisor at `/app/bin/advisor` replays bundled scenarios from `/app/fixtures/scenarios` against the Rust worker at `/app/bin/wkctl`. Inventory manifests live under `/app/inventory/services` and describe legacy modulus sizes and deployment constraints.

## Output contract

Write `/app/output/migration_matrix.json` with a top-level `scenarios` array. Each element corresponds to one fixture JSON basename and carries:

| Field | Meaning |
|-------|---------|
| `name` | Scenario identifier matching the fixture file |
| `finish_reason` | `complete` when every constraint passes, otherwise `reject` |
| `inventory_hits` | Count of hardcoded modulus-size markers discovered for the service |
| `wire_ok` | Fixed-width wire slot services accept the emitted signature length |
| `token_ok` | Combined signing artifact fits the service token ceiling |
| `hsm_excluded` | Immutable hardware signing lanes are excluded from next-gen rollout |
| `hybrid_ok` | Dual-verify clients accept the transition artifact |
| `perf_ratio` | Measured work units divided by the scenario baseline |
| `migration_digest_hex` | SHA-256 over all scenario rows for matrix integrity |

Steady reference counters for each scenario basename are under `/app/data/steady/`. Services with `TRUST_LINEAGE: roots-json` in their inventory manifest add root-pool entries from `/app/inventory/pki/roots.json` to `inventory_hits`. Replay via `/app/ci/run_migration_matrix.sh` with `TB_MIGRATION_FIXTURE=1`.

## Scenario bundles

Fixtures are listed in `/app/docs/fixture_index.txt`. The matrix driver sorts scenarios lexicographically by name when emitting the report.
