#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '[oracle] %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/index.toml
require_file /app/data/corpus_default.json
require_file /app/data/query_specs.jsonl
mkdir -p /app/bin /app/output

log "repair embedding lane width"
patch -p1 < "${ROOT_DIR}/patches/embeddim.patch"

log "repair vault packing and shard gaps"
patch -p1 < "${ROOT_DIR}/patches/kbox.patch"

log "repair weave edge storage"
patch -p1 < "${ROOT_DIR}/patches/mlink.patch"

log "repair probe ranking"
patch -p1 < "${ROOT_DIR}/patches/qseek.patch"

log "repair realm metadata gate"
patch -p1 < "${ROOT_DIR}/patches/gatefix.patch"

log "repair rerank ordering"
patch -p1 < "${ROOT_DIR}/patches/blendfix.patch"

log "refresh gold labels"
go run ./cmd/goldgen /app/data/corpus_default.json /app/data/query_specs.jsonl /app/data/queries_default.jsonl

log "rebuild benchd and write report"
go build -o /app/bin/benchd ./cmd/benchd
go build -o /app/bin/goldgen ./cmd/goldgen
/app/tools/run_bench /app/data/queries_default.jsonl /app/output/search_bench.json

log "sanity check"
python3 - <<'PY'
import json
p = "/app/output/search_bench.json"
r = json.load(open(p))
assert r["status"] == "ok", r
assert r["active_embed_dim"] == r["vector_dim"], r
assert r["index_integrity"] >= 0.95, r
assert r["mean_rerank_recall_at_10"] >= 0.75, r
assert r["filter_survival_rate"] >= 0.40, r
print("ok", r["index_integrity"], r["mean_rerank_recall_at_10"], r["filter_survival_rate"])
PY

log "oracle complete"
