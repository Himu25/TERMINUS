package gate

import (
	"strings"

	"ssrec.lab/pkg/types"
)

func RealmHint(query string) string {
	for _, tok := range strings.Fields(query) {
		if strings.HasPrefix(tok, "realm:") {
			return strings.TrimPrefix(tok, "realm:")
		}
	}
	return ""
}

func KeepDoc(doc types.CorpusDoc, hint string) bool {
	if hint == "" {
		return true
	}
	return doc.Realm == hint
}

func FilterDocs(docs []types.CorpusDoc, ids []string, hint string) []string {
	if hint == "" {
		return ids
	}
	byID := make(map[string]types.CorpusDoc, len(docs))
	for _, d := range docs {
		byID[d.ID] = d
	}
	out := make([]string, 0, len(ids))
	for _, id := range ids {
		doc, ok := byID[id]
		if !ok {
			continue
		}
		if KeepDoc(doc, hint) {
			out = append(out, id)
		}
	}
	return out
}
