package probe

import (
	"sort"

	"ssrec.lab/embed"
	"ssrec.lab/vault"
	"ssrec.lab/weave"
)

type scored struct {
	idx   int
	score float64
}

func PxScan(query []float64, bank vault.Bank, g *weave.Graph, topK int, ef int) []int {
	_ = g
	_ = ef
	pairs := make([]scored, 0, len(bank.Rows))
	for i, row := range bank.Rows {
		vec := row.QkOpen()
		pairs = append(pairs, scored{idx: i, score: embed.Dot(query, vec)})
	}
	sort.Slice(pairs, func(i, j int) bool {
		return pairs[i].score > pairs[j].score
	})
	if topK <= 0 || topK > len(pairs) {
		topK = len(pairs)
	}
	out := make([]int, 0, topK)
	for i := 0; i < topK; i++ {
		out = append(out, pairs[i].idx)
	}
	return out
}

func PxDot(query, doc []float64) float64 {
	return embed.Dot(query, doc)
}
