package vault

import "math"

type Packed struct {
	ID     string
	Data   []float64
	Echo   []float64
	Scale  float64
}

type Bank struct {
	Rows []Packed
}

func QkStore(id string, vec []float64) Packed {
	dup := make([]float64, len(vec))
	copy(dup, vec)
	echo := make([]float64, len(vec))
	copy(echo, vec)
	return Packed{ID: id, Data: dup, Echo: echo, Scale: 1.0}
}

func (b *Bank) QkAdd(id string, vec []float64) {
	b.Rows = append(b.Rows, QkStore(id, vec))
}

func (p Packed) QkOpen() []float64 {
	out := make([]float64, len(p.Data))
	copy(out, p.Data)
	for i := range out {
		out[i] += p.Echo[i] * 0.5
	}
	return out
}

func (b Bank) QkSpan(dim int) int {
	n := len(b.Rows)
	if n == 0 {
		return 0
	}
	per := dim*8*2 + dim*8
	return n * per
}

func NxBase(n, dim int) int {
	return n * dim * 8
}

func QkFold(raw, packed int) float64 {
	if packed <= 0 {
		return 0
	}
	return float64(raw) / float64(packed)
}

func QkPeak(v []float64) float64 {
	m := 0.0
	for _, x := range v {
		if ax := math.Abs(x); ax > m {
			m = ax
		}
	}
	return m
}
