"""Validate semantic search bench output after pipeline repair.

Checks /app/output/search_bench.json against /app/config/index.toml guardrails,
schema contracts in /app/docs/architecture.md, and regression packs under
/tests/fixtures/. Tests exercise behavior via real benchd runs, not source parsing.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "search_bench.json"
CFG = APP / "config" / "index.toml"
RUNNER = APP / "tools" / "run_bench"
GO = "/usr/local/go/bin/go"
FIXTURES = Path(__file__).resolve().parent / "fixtures"

REPORT_KEYS = frozenset(
    {
        "status",
        "corpus_vectors",
        "vector_dim",
        "active_embed_dim",
        "queries_total",
        "index_bytes",
        "raw_float_bytes",
        "compression_ratio",
        "index_integrity",
        "mean_ann_recall_at_10",
        "mean_rerank_recall_at_10",
        "mean_ndcg_at_10",
        "filter_survival_rate",
        "graph_nodes",
        "graph_edges",
        "report_digest",
        "queries",
    }
)
QUERY_KEYS = frozenset({"query_id", "ann_recall_at_10", "rerank_recall_at_10", "ndcg_at_10", "gold_hits", "filter_kept"})
FOOTPRINT_PACK = FIXTURES / "pack_dense_corpus"
FOOTPRINT_BENCH_OUT = APP / "output" / "bench_pack_dense_footprint.json"
BILLING_REFUND_MIN_RECALL = 2 / 3
BILLING_REFUND_MIN_GOLD_HITS = 2

_BENCHD_READY = False


def _pass_status() -> str:
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line.startswith("pass_status"):
            return line.split("=", 1)[1].strip()
    return "ok"


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "vector_dim": 64,
        "graph_degree": 8,
        "search_ef": 32,
        "top_k": 10,
        "ann_recall_floor": 0.75,
        "rerank_recall_floor": 0.75,
        "ndcg_floor": 0.75,
        "max_index_bytes": 52000,
        "min_compression_ratio": 3.2,
        "min_index_integrity": 0.95,
        "min_filter_survival": 0.40,
        "tight_security_recall_floor": 0.5,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in (
            "ann_recall_floor",
            "rerank_recall_floor",
            "ndcg_floor",
            "min_compression_ratio",
            "min_index_integrity",
            "min_filter_survival",
            "tight_security_recall_floor",
        ):
            cfg[key] = float(val)
        elif key in (
            "vector_dim",
            "graph_degree",
            "search_ef",
            "top_k",
            "max_index_bytes",
        ):
            cfg[key] = int(float(val))
    return cfg


def _round4(value: float) -> float:
    return round(value * 10000 + 0.5) / 10000


def _expected_means(rows: list[dict]) -> tuple[float, float, float]:
    if not rows:
        return 0.0, 0.0, 0.0
    total = len(rows)
    ann = sum(row["ann_recall_at_10"] for row in rows) / total
    rerank = sum(row["rerank_recall_at_10"] for row in rows) / total
    ndcg = sum(row["ndcg_at_10"] for row in rows) / total
    return _round4(ann), _round4(rerank), _round4(ndcg)


def _digest_payload(report: dict) -> dict:
    # Field order must match bench.digestPayload in b5_drive.go for SHA-256 parity.
    return {
        "status": report["status"],
        "corpus_vectors": report["corpus_vectors"],
        "vector_dim": report["vector_dim"],
        "active_embed_dim": report["active_embed_dim"],
        "queries_total": report["queries_total"],
        "index_bytes": report["index_bytes"],
        "raw_float_bytes": report["raw_float_bytes"],
        "compression_ratio": report["compression_ratio"],
        "index_integrity": report["index_integrity"],
        "mean_ann_recall_at_10": report["mean_ann_recall_at_10"],
        "mean_rerank_recall_at_10": report["mean_rerank_recall_at_10"],
        "mean_ndcg_at_10": report["mean_ndcg_at_10"],
        "filter_survival_rate": report["filter_survival_rate"],
        "graph_nodes": report["graph_nodes"],
        "graph_edges": report["graph_edges"],
        "report_digest": "",
        "queries": report["queries"],
    }


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _assert_query_row(row: dict) -> None:
    assert set(row) == QUERY_KEYS
    assert isinstance(row["query_id"], str) and row["query_id"]
    assert isinstance(row["ann_recall_at_10"], (int, float))
    assert isinstance(row["rerank_recall_at_10"], (int, float))
    assert isinstance(row["ndcg_at_10"], (int, float))
    assert isinstance(row["gold_hits"], int)
    assert isinstance(row["filter_kept"], int)
    assert 0.0 <= float(row["ann_recall_at_10"]) <= 1.0
    assert 0.0 <= float(row["rerank_recall_at_10"]) <= 1.0
    assert 0.0 <= float(row["ndcg_at_10"]) <= 1.0
    assert row["gold_hits"] >= 0
    assert row["filter_kept"] >= 0


def _assert_report_schema(data: dict) -> None:
    assert set(data) == REPORT_KEYS
    assert isinstance(data["status"], str) and data["status"] in {_pass_status(), "fail"}
    for int_key in (
        "corpus_vectors",
        "vector_dim",
        "active_embed_dim",
        "queries_total",
        "index_bytes",
        "raw_float_bytes",
        "graph_nodes",
        "graph_edges",
    ):
        assert isinstance(data[int_key], int), int_key
        assert data[int_key] >= 0, int_key
    for float_key in (
        "compression_ratio",
        "index_integrity",
        "mean_ann_recall_at_10",
        "mean_rerank_recall_at_10",
        "mean_ndcg_at_10",
        "filter_survival_rate",
    ):
        assert isinstance(data[float_key], (int, float)), float_key
        assert float(data[float_key]) >= 0.0, float_key
    digest = data["report_digest"]
    assert isinstance(digest, str) and len(digest) == 64
    assert digest == digest.lower()
    assert re.fullmatch(r"[0-9a-f]{64}", digest)
    assert isinstance(data["queries"], list)
    for row in data["queries"]:
        _assert_query_row(row)


def _load_report(path: Path = OUT) -> dict:
    assert path.is_file(), f"missing report at {path}"
    data = json.loads(path.read_text(encoding="utf-8"))
    _assert_report_schema(data)
    return data


def _gold_ids_for(query_id: str, queries_path: Path) -> list[str]:
    for line in queries_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        if row["query_id"] == query_id:
            gold = row["gold_ids"]
            assert isinstance(gold, list) and gold
            return gold
    raise AssertionError(f"query_id {query_id} not found in {queries_path}")


def _pack_queries_path(pack: Path) -> Path:
    return APP / "output" / f"queries_{pack.name}.jsonl"


def _bench_footprint_pack() -> dict:
    pack = FOOTPRINT_PACK
    queries = _pack_queries_path(pack)
    _goldgen(pack / "corpus.json", pack / "query_specs.jsonl", queries)
    _run_bench(queries, FOOTPRINT_BENCH_OUT, pack / "corpus.json")
    return _load_report(FOOTPRINT_BENCH_OUT)


def _assert_ok_default(report: dict) -> None:
    cfg = _parse_cfg()
    assert report["status"] == _pass_status()
    assert report["active_embed_dim"] == report["vector_dim"]
    assert report["mean_ann_recall_at_10"] >= cfg["ann_recall_floor"]
    assert report["mean_rerank_recall_at_10"] >= cfg["rerank_recall_floor"]
    assert report["mean_ndcg_at_10"] >= cfg["ndcg_floor"]
    assert report["index_integrity"] >= cfg["min_index_integrity"]
    assert report["filter_survival_rate"] >= cfg["min_filter_survival"]
    assert report["index_bytes"] <= cfg["max_index_bytes"]
    assert report["compression_ratio"] >= cfg["min_compression_ratio"]


def _rebuild_benchd(env: dict[str, str] | None = None, *, force: bool = False) -> None:
    global _BENCHD_READY
    if _BENCHD_READY and not force:
        return
    subprocess.run(
        [GO, "build", "-o", "/app/bin/benchd", "./cmd/benchd"],
        cwd=APP,
        env=env or os.environ.copy(),
        check=True,
        capture_output=True,
        text=True,
    )
    _BENCHD_READY = True


def _goldgen(corpus_path: Path, specs_path: Path, out_path: Path) -> None:
    subprocess.run(
        [
            "/app/bin/goldgen",
            corpus_path.as_posix(),
            specs_path.as_posix(),
            out_path.as_posix(),
        ],
        check=True,
        capture_output=True,
        text=True,
    )


def _run_bench(
    query_path: Path,
    out_path: Path = OUT,
    corpus_path: Path | None = None,
    *,
    rebuild: bool = False,
) -> None:
    env = os.environ.copy()
    if corpus_path is not None:
        env["TB_CORPUS_PATH"] = str(corpus_path)
    else:
        env.pop("TB_CORPUS_PATH", None)
    if out_path.exists():
        out_path.unlink()
    if rebuild:
        _rebuild_benchd(env, force=True)
    else:
        _rebuild_benchd(env)
    subprocess.run(
        [
            "/app/bin/benchd",
            query_path.as_posix(),
            out_path.as_posix(),
        ],
        cwd=APP,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )


def _run_pack_bench(pack: Path, out: Path) -> dict:
    queries = _pack_queries_path(pack)
    _goldgen(pack / "corpus.json", pack / "query_specs.jsonl", queries)
    _run_bench(queries, out, pack / "corpus.json")
    return _load_report(out)


@pytest.fixture(scope="session", autouse=True)
def _default_bench_run() -> None:
    _rebuild_benchd(force=True)
    _goldgen(
        APP / "data" / "corpus_default.json",
        APP / "data" / "query_specs.jsonl",
        APP / "data" / "queries_default.jsonl",
    )
    _run_bench(APP / "data" / "queries_default.jsonl", rebuild=False)


@pytest.fixture(scope="session")
def footprint_pack_report() -> dict:
    """Dense corpus footprint pack is reused across compression and byte-cap tests."""
    return _bench_footprint_pack()


def test_runner_exists() -> None:
    """Documented bench driver is present and executable."""
    assert RUNNER.is_file() and os.access(RUNNER, os.X_OK)


def test_report_schema_keys() -> None:
    """search_bench.json exposes the contract field set only."""
    report = _load_report()
    _assert_ok_default(report)
    assert report["queries_total"] == len(report["queries"])


def test_per_query_row_keys() -> None:
    """Each queries[] row uses the documented sub-schema and valid metric ranges."""
    report = _load_report()
    _assert_ok_default(report)
    for row in report["queries"]:
        assert set(row) == QUERY_KEYS
        assert 0.0 <= row["ann_recall_at_10"] <= 1.0
        assert 0.0 <= row["rerank_recall_at_10"] <= 1.0
        assert 0.0 <= row["ndcg_at_10"] <= 1.0
        assert row["gold_hits"] >= 0


def test_active_embed_dim_matches_vector_dim() -> None:
    """Embedding lane width must match configured vector_dim after migration repair."""
    report = _load_report()
    _assert_ok_default(report)
    assert report["active_embed_dim"] == report["vector_dim"]


def test_index_integrity_floor() -> None:
    """Vault shard integrity must clear the production floor."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["index_integrity"] >= cfg["min_index_integrity"]


def test_filter_survival_floor() -> None:
    """Metadata gate must retain enough ANN candidates on realm-tagged queries."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["filter_survival_rate"] >= cfg["min_filter_survival"]


def test_status_ok_and_mean_floors() -> None:
    """Default pack clears recall, ndcg, footprint floors with status ok."""
    _assert_ok_default(_load_report())


def test_index_bytes_within_cap(footprint_pack_report: dict) -> None:
    """index_bytes cap is enforced on verifier-only dense corpus, not a hand-written report."""
    report = footprint_pack_report
    cfg = _parse_cfg()
    dense_count = len(
        json.loads((FOOTPRINT_PACK / "corpus.json").read_text(encoding="utf-8"))["vectors"]
    )
    assert report["status"] == _pass_status()
    assert report["corpus_vectors"] >= dense_count
    assert report["index_bytes"] <= cfg["max_index_bytes"]
    assert report["index_bytes"] < report["raw_float_bytes"]
    assert report["raw_float_bytes"] == dense_count * cfg["vector_dim"] * 8


def test_compression_ratio_meets_minimum(footprint_pack_report: dict) -> None:
    """compression_ratio is recomputed from verifier-only dense corpus bench output."""
    report = footprint_pack_report
    cfg = _parse_cfg()
    assert report["status"] == _pass_status()
    assert report["compression_ratio"] >= cfg["min_compression_ratio"]
    assert report["raw_float_bytes"] > report["index_bytes"]
    assert report["compression_ratio"] == pytest.approx(
        report["raw_float_bytes"] / report["index_bytes"],
        rel=0.02,
        abs=0.05,
    )


def test_graph_edge_budget_near_degree_times_nodes() -> None:
    """Graph must not store neighbor payload vectors inline (edge count ~ degree * nodes)."""
    report = _load_report()
    cfg = _parse_cfg()
    nodes = report["graph_nodes"]
    edges = report["graph_edges"]
    assert nodes == report["corpus_vectors"]
    assert edges <= nodes * cfg["graph_degree"] + nodes
    assert edges >= nodes


def test_summary_means_recomputed_from_query_rows() -> None:
    """Mean ann recall, rerank recall, and ndcg must match per-query rows."""
    report = _load_report()
    want_ann, want_rerank, want_ndcg = _expected_means(report["queries"])
    assert report["mean_ann_recall_at_10"] == pytest.approx(want_ann, abs=2e-4)
    assert report["mean_rerank_recall_at_10"] == pytest.approx(want_rerank, abs=2e-4)
    assert report["mean_ndcg_at_10"] == pytest.approx(want_ndcg, abs=2e-4)


def test_report_digest_format() -> None:
    """report_digest is 64-char lowercase hex."""
    digest = _load_report()["report_digest"]
    assert len(digest) == 64
    assert digest == digest.lower()
    assert re.fullmatch(r"[0-9a-f]{64}", digest)


def test_report_digest_matches_body() -> None:
    """report_digest is SHA-256 of the compact pre-digest payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_repeat_run_byte_identical() -> None:
    """Back-to-back default runs emit identical report bytes."""
    _assert_ok_default(_load_report())
    first = OUT.read_bytes()
    _run_bench(APP / "data" / "queries_default.jsonl")
    second = OUT.read_bytes()
    assert first == second


def test_queries_total_matches_pack_line_count() -> None:
    """queries_total equals non-empty lines in the default query JSONL."""
    report = _load_report()
    expected = sum(
        1
        for line in (APP / "data" / "queries_default.jsonl")
        .read_text(encoding="utf-8")
        .splitlines()
        if line.strip()
    )
    assert report["queries_total"] == expected
    assert len(report["queries"]) == expected


def test_corpus_vectors_matches_default_manifest() -> None:
    """corpus_vectors tracks the default shard manifest count."""
    report = _load_report()
    manifest = json.loads((APP / "registry" / "shard_manifest.json").read_text(encoding="utf-8"))
    assert report["corpus_vectors"] == manifest["count"]
    assert report["vector_dim"] == manifest["dim"]


def test_q_billing_refund_recall_floor() -> None:
    """q_billing_refund must recover most gold neighbors and match recall accounting."""
    report = _load_report()
    queries_path = APP / "data" / "queries_default.jsonl"
    gold_ids = _gold_ids_for("q_billing_refund", queries_path)
    row = next(r for r in report["queries"] if r["query_id"] == "q_billing_refund")
    assert row["gold_hits"] >= BILLING_REFUND_MIN_GOLD_HITS
    assert row["rerank_recall_at_10"] >= BILLING_REFUND_MIN_RECALL
    assert row["rerank_recall_at_10"] == pytest.approx(
        row["gold_hits"] / len(gold_ids),
        abs=2e-4,
    )


def test_q_search_ann_ndcg_floor() -> None:
    """q_search_ann ndcg must be positive once ranking is repaired."""
    report = _load_report()
    cfg = _parse_cfg()
    row = next(r for r in report["queries"] if r["query_id"] == "q_search_ann")
    assert row["ndcg_at_10"] >= cfg["ndcg_floor"] / (2 * cfg["top_k"])


def test_q_cross_billing_ops_multi_gold_hits() -> None:
    """Cross-topic query should hit multiple gold ids."""
    report = _load_report()
    cfg = _parse_cfg()
    row = next(r for r in report["queries"] if r["query_id"] == "q_cross_billing_ops")
    assert row["gold_hits"] >= cfg["graph_degree"] // 4


def test_fixture_pack_dense_corpus_footprint() -> None:
    """Dense corpus pack still meets compression ratio with status ok."""
    pack = FIXTURES / "pack_dense_corpus"
    cfg = _parse_cfg()
    report = _run_pack_bench(pack, APP / "output" / "bench_pack_dense.json")
    assert report["status"] == _pass_status()
    assert report["compression_ratio"] >= cfg["min_compression_ratio"]
    dense_count = len(
        json.loads((pack / "corpus.json").read_text(encoding="utf-8"))["vectors"]
    )
    assert report["corpus_vectors"] >= dense_count
    assert report["index_integrity"] >= cfg["min_index_integrity"]


def test_fixture_pack_skew_queries_recall() -> None:
    """Skew query pack clears mean rerank recall floor."""
    pack = FIXTURES / "pack_skew_queries"
    cfg = _parse_cfg()
    report = _run_pack_bench(pack, APP / "output" / "bench_pack_skew.json")
    assert report["mean_rerank_recall_at_10"] >= cfg["rerank_recall_floor"]


def test_fixture_pack_tight_recall_mean_and_security_row() -> None:
    """Tight recall pack clears mean floor and q_tight_security row recall."""
    pack = FIXTURES / "pack_tight_recall"
    cfg = _parse_cfg()
    report = _run_pack_bench(pack, APP / "output" / "bench_pack_tight.json")
    assert report["status"] == _pass_status()
    assert report["mean_rerank_recall_at_10"] >= cfg["rerank_recall_floor"]
    sec = next(r for r in report["queries"] if r["query_id"] == "q_tight_security")
    assert sec["rerank_recall_at_10"] >= cfg["tight_security_recall_floor"]


def test_realm_tagged_queries_keep_candidates() -> None:
    """Realm-tagged default queries must retain ANN candidates through the metadata gate."""
    report = _load_report()
    queries_path = APP / "data" / "queries_default.jsonl"
    query_text_by_id: dict[str, str] = {}
    for line in queries_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        spec = json.loads(line)
        query_text_by_id[spec["query_id"]] = spec["query"]
    for row in report["queries"]:
        query_text = query_text_by_id.get(row["query_id"], "")
        if "realm:" not in query_text:
            continue
        assert row["filter_kept"] >= 1, row["query_id"]


def test_q_dense_tail_recall_on_dense_pack() -> None:
    """Dense corpus pack q_dense_tail must recover most gold neighbors."""
    pack = FIXTURES / "pack_dense_corpus"
    report = _run_pack_bench(pack, APP / "output" / "bench_pack_dense_tail.json")
    queries_path = _pack_queries_path(pack)
    gold_ids = _gold_ids_for("q_dense_tail", queries_path)
    row = next(r for r in report["queries"] if r["query_id"] == "q_dense_tail")
    min_hits = BILLING_REFUND_MIN_GOLD_HITS if len(gold_ids) >= 3 else max(1, len(gold_ids))
    assert row["gold_hits"] >= min_hits
    assert row["rerank_recall_at_10"] >= BILLING_REFUND_MIN_RECALL
    assert row["rerank_recall_at_10"] == pytest.approx(
        row["gold_hits"] / len(gold_ids),
        abs=2e-4,
    )


def test_fixture_pack_skew_mean_ann_recall() -> None:
    """Skew query pack must clear mean ann recall, not only rerank recall."""
    pack = FIXTURES / "pack_skew_queries"
    cfg = _parse_cfg()
    report = _run_pack_bench(pack, APP / "output" / "bench_pack_skew_ann.json")
    assert report["mean_ann_recall_at_10"] >= cfg["ann_recall_floor"]


def test_fixture_pack_dense_digest_matches() -> None:
    """Dense corpus pack report_digest must match its bench body."""
    pack = FIXTURES / "pack_dense_corpus"
    report = _run_pack_bench(pack, APP / "output" / "bench_pack_dense_digest.json")
    assert report["report_digest"] == _expected_digest(report)


def test_fixture_pack_skew_digest_matches() -> None:
    """Skew query pack report_digest must match its bench body."""
    pack = FIXTURES / "pack_skew_queries"
    report = _run_pack_bench(pack, APP / "output" / "bench_pack_skew_digest.json")
    assert report["report_digest"] == _expected_digest(report)


def test_fixture_pack_tight_digest_matches() -> None:
    """Tight recall pack report_digest must match its bench body."""
    pack = FIXTURES / "pack_tight_recall"
    report = _run_pack_bench(pack, APP / "output" / "bench_pack_tight_digest.json")
    assert report["report_digest"] == _expected_digest(report)


def test_q_triple_gate_ndcg_floor() -> None:
    """q_triple_gate ndcg must be positive once ranking is repaired."""
    report = _load_report()
    cfg = _parse_cfg()
    row = next(r for r in report["queries"] if r["query_id"] == "q_triple_gate")
    assert row["ndcg_at_10"] >= cfg["ndcg_floor"] / (2 * cfg["top_k"])


def test_broken_codec_ablation_fails_gates() -> None:
    """Baseline float64 echo codec cannot pass footprint gates."""
    codec_src = APP / "vault" / "k2_cells.go"
    graph_src = APP / "weave" / "h3_build.go"
    backup_codec = codec_src.read_text(encoding="utf-8")
    backup_graph = graph_src.read_text(encoding="utf-8")
    broken_codec = (FIXTURES / "broken_k2_cells.go").read_text(encoding="utf-8")
    broken_graph = (FIXTURES / "broken_h3_build.go").read_text(encoding="utf-8")
    out = APP / "output" / "bench_ablation_codec.json"
    try:
        codec_src.write_text(broken_codec, encoding="utf-8")
        graph_src.write_text(broken_graph, encoding="utf-8")
        _run_bench(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        assert report["status"] == "fail"
    finally:
        codec_src.write_text(backup_codec, encoding="utf-8")
        graph_src.write_text(backup_graph, encoding="utf-8")
        _rebuild_benchd(force=True)
        _run_bench(APP / "data" / "queries_default.jsonl")


def test_broken_rank_ablation_fails_recall() -> None:
    """Ascending half-dimension ranker cannot clear recall floor."""
    search_src = APP / "probe" / "p4_ann.go"
    backup = search_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "broken_p4_ann.go").read_text(encoding="utf-8")
    out = APP / "output" / "bench_ablation_search.json"
    cfg = _parse_cfg()
    try:
        search_src.write_text(broken, encoding="utf-8")
        _run_bench(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        assert report["mean_ann_recall_at_10"] < cfg["ann_recall_floor"] or report["status"] == "fail"
    finally:
        search_src.write_text(backup, encoding="utf-8")
        _rebuild_benchd(force=True)
        _run_bench(APP / "data" / "queries_default.jsonl")
