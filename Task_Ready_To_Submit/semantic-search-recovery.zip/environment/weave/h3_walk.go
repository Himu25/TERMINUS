package weave

// WalkBudget is the default greedy expansion cap for probe routines.
const WalkBudget = 48
