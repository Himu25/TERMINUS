Helper scripts are not wired into benchd. Use tools/run_bench as the supported driver.
Go toolchain: /usr/local/go/bin/go (also on PATH via /usr/bin/go).
Regenerate default gold labels atomically: /app/tools/regen_queries
Restore shipped defaults if queries_default.jsonl was truncated: cp /app/data/queries_default.jsonl.seed /app/data/queries_default.jsonl
