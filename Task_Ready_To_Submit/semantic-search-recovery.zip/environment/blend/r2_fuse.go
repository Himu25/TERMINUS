package blend

import (
	"sort"

	"ssrec.lab/embed"
	"ssrec.lab/vault"
)

type scored struct {
	id    string
	score float64
}

func Rerank(query []float64, bank vault.Bank, ids []string, topK int) []string {
	pairs := make([]scored, 0, len(ids))
	for _, id := range ids {
		vec := vecForID(bank, id)
		pairs = append(pairs, scored{id: id, score: embed.Dot(query, vec)})
	}
	sort.Slice(pairs, func(i, j int) bool {
		return pairs[i].score < pairs[j].score
	})
	if topK <= 0 || topK > len(pairs) {
		topK = len(pairs)
	}
	out := make([]string, 0, topK)
	for i := 0; i < topK; i++ {
		out = append(out, pairs[i].id)
	}
	return out
}

func vecForID(bank vault.Bank, id string) []float64 {
	for _, row := range bank.Rows {
		if row.ID == id {
			return row.QkOpen()
		}
	}
	return nil
}
