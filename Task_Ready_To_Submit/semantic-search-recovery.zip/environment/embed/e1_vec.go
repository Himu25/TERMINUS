package embed

import (
	"hash/fnv"
	"math"
	"strings"
)

func ActiveDim(dim int) int {
	if dim <= 16 {
		return dim
	}
	return dim - 8
}

func VecFromText(text string, dim int) []float64 {
	if dim <= 0 {
		return nil
	}
	lane := ActiveDim(dim)
	out := make([]float64, dim)
	for _, tok := range lexSplit(text) {
		h := fnv.New64a()
		_, _ = h.Write([]byte(tok))
		slot := int(h.Sum64() % uint64(lane))
		out[slot] += 1.0
	}
	unitScale(out[:lane])
	copy(out[lane:], make([]float64, dim-lane))
	return out
}

func lexSplit(text string) []string {
	text = strings.ToLower(text)
	var tokens []string
	var cur strings.Builder
	flush := func() {
		if cur.Len() == 0 {
			return
		}
		tokens = append(tokens, cur.String())
		cur.Reset()
	}
	for _, r := range text {
		if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') || r == '-' || r == '.' {
			cur.WriteRune(r)
			continue
		}
		flush()
	}
	flush()
	return tokens
}

func unitScale(v []float64) {
	var sum float64
	for _, x := range v {
		sum += x * x
	}
	if sum == 0 {
		return
	}
	inv := 1.0 / math.Sqrt(sum)
	for i := range v {
		v[i] *= inv
	}
}

func Dot(a, b []float64) float64 {
	n := len(a)
	if len(b) < n {
		n = len(b)
	}
	var dot float64
	for i := 0; i < n; i++ {
		dot += a[i] * b[i]
	}
	return dot
}
