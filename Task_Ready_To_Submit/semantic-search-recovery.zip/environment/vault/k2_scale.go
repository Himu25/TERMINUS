package vault

// ScaleHint documents the per-vector scale slot used by the compact lane.
// Bench report fields: index_bytes, raw_float_bytes, compression_ratio,
// mean_recall_at_10, mean_ndcg_at_10, graph_nodes, graph_edges, gold_hits.
const ScaleHint = "one float64 scale per vector row"
