module ssrec.lab

go 1.22
