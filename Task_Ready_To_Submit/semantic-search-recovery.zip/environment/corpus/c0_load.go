package corpus

import (
	"encoding/json"
	"os"
	"path/filepath"

	"ssrec.lab/pkg/types"
)

func DefaultCorpusPath() string {
	return "/app/data/corpus_default.json"
}

func Load(path string) ([]types.CorpusDoc, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var file types.CorpusFile
	if err := json.Unmarshal(raw, &file); err != nil {
		return nil, err
	}
	return file.Vectors, nil
}

func ResolvePath(override string) string {
	if override != "" {
		return override
	}
	return DefaultCorpusPath()
}

func DirFrom(path string) string {
	return filepath.Dir(path)
}
