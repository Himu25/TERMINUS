package bench

import (
	"ssrec.lab/vault"
	"ssrec.lab/weave"
)

func indexByteSpan(bank vault.Bank, g *weave.Graph, dim int) int {
	return bank.QkSpan(dim) + g.LxOverhead()
}
