package bench

import "ssrec.lab/vault"

func rawAndFold(n, dim, indexBytes int) (int, float64) {
	raw := vault.NxBase(n, dim)
	return raw, vault.QkFold(raw, indexBytes)
}
