package bench

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"strings"

	"ssrec.lab/blend"
	"ssrec.lab/corpus"
	"ssrec.lab/embed"
	"ssrec.lab/gate"
	"ssrec.lab/pkg/types"
	"ssrec.lab/probe"
	"ssrec.lab/vault"
	"ssrec.lab/weave"
)

func LoadCfg(path string) (types.IndexCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.IndexCfg{}, err
	}
	cfg := types.IndexCfg{CorpusPath: corpus.DefaultCorpusPath()}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "vector_dim":
			fmt.Sscanf(val, "%d", &cfg.VectorDim)
		case "graph_degree":
			fmt.Sscanf(val, "%d", &cfg.GraphDegree)
		case "search_ef":
			fmt.Sscanf(val, "%d", &cfg.SearchEF)
		case "top_k":
			fmt.Sscanf(val, "%d", &cfg.TopK)
		case "ann_recall_floor":
			fmt.Sscanf(val, "%f", &cfg.AnnRecallFloor)
		case "rerank_recall_floor":
			fmt.Sscanf(val, "%f", &cfg.RerankRecallFloor)
		case "ndcg_floor":
			fmt.Sscanf(val, "%f", &cfg.NdcgFloor)
		case "max_index_bytes":
			fmt.Sscanf(val, "%d", &cfg.MaxIndexBytes)
		case "min_compression_ratio":
			fmt.Sscanf(val, "%f", &cfg.MinCompressionRatio)
		case "min_index_integrity":
			fmt.Sscanf(val, "%f", &cfg.MinIndexIntegrity)
		case "min_filter_survival":
			fmt.Sscanf(val, "%f", &cfg.MinFilterSurvival)
		case "corpus_path":
			cfg.CorpusPath = val
		case "tight_security_recall_floor":
			fmt.Sscanf(val, "%f", &cfg.TightSecurityRecallFloor)
		case "pass_status":
			// bench uses literal ok/fail strings; config documents the success token
		}
	}
	return cfg, nil
}

func LoadQueries(path string) ([]types.QueryCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.QueryCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var qc types.QueryCase
		if err := json.Unmarshal([]byte(line), &qc); err != nil {
			return nil, err
		}
		out = append(out, qc)
	}
	return out, sc.Err()
}

func Run(cfg types.IndexCfg, cases []types.QueryCase) (types.SearchReport, error) {
	if override := os.Getenv("TB_CORPUS_PATH"); override != "" {
		cfg.CorpusPath = override
	}
	docs, err := corpus.Load(cfg.CorpusPath)
	if err != nil {
		return types.SearchReport{}, err
	}
	bank := vault.Bank{}
	ids := make([]string, 0, len(docs))
	for _, doc := range docs {
		vec := embed.VecFromText(doc.Text, cfg.VectorDim)
		bank.QkAdd(doc.ID, vec)
		ids = append(ids, doc.ID)
	}
	g := weave.LxWire(bank, cfg.GraphDegree)
	indexBytes := indexByteSpan(bank, g, cfg.VectorDim)
	rawBytes, ratio := rawAndFold(len(docs), cfg.VectorDim, indexBytes)
	integrity := indexIntegrity(bank)
	report := types.SearchReport{
		Status:           "ok",
		CorpusVectors:    len(docs),
		VectorDim:        cfg.VectorDim,
		ActiveEmbedDim:   embed.ActiveDim(cfg.VectorDim),
		QueriesTotal:     len(cases),
		IndexBytes:       indexBytes,
		RawFloatBytes:    rawBytes,
		CompressionRatio: round4(ratio),
		IndexIntegrity:   round4(integrity),
		GraphNodes:       len(g.Nodes),
	}
	report.GraphNodes, report.GraphEdges = g.Tally()
	var sumAnn, sumRerank, sumNdcg, sumFilter float64
	report.Queries = make([]types.QueryRow, 0, len(cases))
	for _, qc := range cases {
		qv := embed.VecFromText(qc.Query, cfg.VectorDim)
		idxs := probe.PxScan(qv, bank, g, cfg.TopK, cfg.SearchEF)
		annIDs := make([]string, 0, len(idxs))
		for _, ix := range idxs {
			if ix >= 0 && ix < len(ids) {
				annIDs = append(annIDs, ids[ix])
			}
		}
		hint := gate.RealmHint(qc.Query)
		filtered := gate.FilterDocs(docs, annIDs, hint)
		reranked := blend.Rerank(qv, bank, filtered, cfg.TopK)
		annRec := recallAtK(annIDs, qc.GoldIDs, cfg.TopK)
		rerankRec := recallAtK(reranked, qc.GoldIDs, cfg.TopK)
		nd := ndcgAtK(reranked, qc.GoldIDs, cfg.TopK)
		hits := goldHits(reranked, qc.GoldIDs)
		kept := len(filtered)
		if len(annIDs) > 0 {
			sumFilter += float64(kept) / float64(len(annIDs))
		}
		report.Queries = append(report.Queries, types.QueryRow{
			QueryID:          qc.QueryID,
			AnnRecallAt10:    round4(annRec),
			RerankRecallAt10: round4(rerankRec),
			NdcgAt10:         round4(nd),
			GoldHits:         hits,
			FilterKept:       kept,
		})
		sumAnn += annRec
		sumRerank += rerankRec
		sumNdcg += nd
	}
	n := float64(len(cases))
	if n > 0 {
		report.MeanAnnRecallAt10 = round4(sumAnn / n)
		report.MeanRerankRecallAt10 = round4(sumRerank / n)
		report.MeanNdcgAt10 = round4(sumNdcg / n)
		report.FilterSurvivalRate = round4(sumFilter / n)
	}
	if report.MeanAnnRecallAt10 < cfg.AnnRecallFloor ||
		report.MeanRerankRecallAt10 < cfg.RerankRecallFloor ||
		report.MeanNdcgAt10 < cfg.NdcgFloor ||
		report.IndexBytes > cfg.MaxIndexBytes ||
		report.CompressionRatio < cfg.MinCompressionRatio ||
		report.IndexIntegrity < cfg.MinIndexIntegrity ||
		report.FilterSurvivalRate < cfg.MinFilterSurvival ||
		report.ActiveEmbedDim != report.VectorDim {
		report.Status = "fail"
	}
	digest, err := digestBody(report)
	if err != nil {
		return types.SearchReport{}, err
	}
	report.ReportDigest = digest
	return report, nil
}

func indexIntegrity(bank vault.Bank) float64 {
	if len(bank.Rows) == 0 {
		return 0
	}
	ok := 0
	for _, row := range bank.Rows {
		vec := row.QkOpen()
		peak := 0.0
		for _, x := range vec {
			if ax := math.Abs(x); ax > peak {
				peak = ax
			}
		}
		if peak > 1e-9 {
			ok++
		}
	}
	return float64(ok) / float64(len(bank.Rows))
}

func WriteReport(path string, report types.SearchReport) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o775); err != nil {
		return err
	}
	body, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	body = append(body, '\n')
	return os.WriteFile(path, body, 0o664)
}

type digestPayload struct {
	Status               string           `json:"status"`
	CorpusVectors        int              `json:"corpus_vectors"`
	VectorDim            int              `json:"vector_dim"`
	ActiveEmbedDim       int              `json:"active_embed_dim"`
	QueriesTotal         int              `json:"queries_total"`
	IndexBytes           int              `json:"index_bytes"`
	RawFloatBytes        int              `json:"raw_float_bytes"`
	CompressionRatio     float64          `json:"compression_ratio"`
	IndexIntegrity       float64          `json:"index_integrity"`
	MeanAnnRecallAt10    float64          `json:"mean_ann_recall_at_10"`
	MeanRerankRecallAt10 float64          `json:"mean_rerank_recall_at_10"`
	MeanNdcgAt10         float64          `json:"mean_ndcg_at_10"`
	FilterSurvivalRate   float64          `json:"filter_survival_rate"`
	GraphNodes           int              `json:"graph_nodes"`
	GraphEdges           int              `json:"graph_edges"`
	ReportDigest         string           `json:"report_digest"`
	Queries              []types.QueryRow `json:"queries"`
}

func digestBody(report types.SearchReport) (string, error) {
	payload := digestPayload{
		Status:               report.Status,
		CorpusVectors:        report.CorpusVectors,
		VectorDim:            report.VectorDim,
		ActiveEmbedDim:       report.ActiveEmbedDim,
		QueriesTotal:         report.QueriesTotal,
		IndexBytes:           report.IndexBytes,
		RawFloatBytes:        report.RawFloatBytes,
		CompressionRatio:     report.CompressionRatio,
		IndexIntegrity:       report.IndexIntegrity,
		MeanAnnRecallAt10:    report.MeanAnnRecallAt10,
		MeanRerankRecallAt10: report.MeanRerankRecallAt10,
		MeanNdcgAt10:         report.MeanNdcgAt10,
		FilterSurvivalRate:   report.FilterSurvivalRate,
		GraphNodes:           report.GraphNodes,
		GraphEdges:           report.GraphEdges,
		ReportDigest:         "",
		Queries:              report.Queries,
	}
	raw, err := json.Marshal(payload)
	if err != nil {
		return "", err
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:]), nil
}

func recallAtK(retrieved, gold []string, k int) float64 {
	if len(gold) == 0 {
		return 0
	}
	if k > len(retrieved) {
		k = len(retrieved)
	}
	gset := make(map[string]struct{}, len(gold))
	for _, g := range gold {
		gset[g] = struct{}{}
	}
	hits := 0
	for i := 0; i < k; i++ {
		if _, ok := gset[retrieved[i]]; ok {
			hits++
		}
	}
	return float64(hits) / float64(len(gold))
}

func ndcgAtK(retrieved, gold []string, k int) float64 {
	if len(gold) == 0 {
		return 0
	}
	if k > len(retrieved) {
		k = len(retrieved)
	}
	gset := make(map[string]struct{}, len(gold))
	for _, g := range gold {
		gset[g] = struct{}{}
	}
	var dcg float64
	for i := 0; i < k; i++ {
		if _, ok := gset[retrieved[i]]; ok {
			dcg += 1.0 / math.Log2(float64(i+2))
		}
	}
	var idcg float64
	for i := 0; i < len(gold) && i < k; i++ {
		idcg += 1.0 / math.Log2(float64(i+2))
	}
	if idcg == 0 {
		return 0
	}
	return dcg / idcg
}

func goldHits(retrieved, gold []string) int {
	gset := make(map[string]struct{}, len(gold))
	for _, g := range gold {
		gset[g] = struct{}{}
	}
	hits := 0
	for _, r := range retrieved {
		if _, ok := gset[r]; ok {
			hits++
		}
	}
	return hits
}

func round4(v float64) float64 {
	return float64(int(v*10000+0.5)) / 10000
}
