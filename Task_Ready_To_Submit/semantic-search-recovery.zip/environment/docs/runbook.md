# Runbook

Rebuild `/app/bin/benchd` after workspace edits, then invoke `/app/tools/run_bench` with the query JSONL path and output path. Use `/usr/local/go/bin/go` when a shell session lacks the Go toolchain on PATH.

Regenerate gold labels with positional paths only (never shell redirects on the JSONL). `/app/tools/regen_queries` writes via a temp file; shipped defaults are at `/app/data/queries_default.jsonl.seed`.

Default inputs:
- `/app/config/index.toml`
- `/app/data/corpus_default.json` (override with `TB_CORPUS_PATH`)
- `/app/data/queries_default.jsonl`

Output: `/app/output/search_bench.json`

Repeat runs on unchanged inputs must be byte-identical.
