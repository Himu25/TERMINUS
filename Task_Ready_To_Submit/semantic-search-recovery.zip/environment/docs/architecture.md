# Architecture notes

The retrieval path is corpus JSON → embed → vault bank → weave graph → probe scan → gate metadata filter → blend rerank.

Footprint accounting sums vault row bytes plus weave edge storage. `raw_float_bytes` is the naive float64 corpus size used as the compression baseline. `index_integrity` is the fraction of vault rows whose opened vector has non-zero peak magnitude.

`/app/output/search_bench.json` top-level keys: status, corpus_vectors, vector_dim, active_embed_dim, queries_total, index_bytes, raw_float_bytes, compression_ratio, index_integrity, mean_ann_recall_at_10, mean_rerank_recall_at_10, mean_ndcg_at_10, filter_survival_rate, graph_nodes, graph_edges, report_digest, queries.

Each queries row: query_id, ann_recall_at_10, rerank_recall_at_10, ndcg_at_10, gold_hits, filter_kept. Ranking metrics are between zero and one. gold_hits counts gold neighbors in the reranked top-k set.

Quality gates compare mean ann and rerank recall, mean ndcg, index footprint, compression ratio, index integrity, filter survival, and active_embed_dim against floors in `index.toml`. Queries carry `realm:` tags that gate filtering must honor.

Digest covers every report field except `report_digest`, serialized as compact JSON with `report_digest` set to an empty string.
