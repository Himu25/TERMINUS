# Semantic search service

Offline retrieval stack under `/app` builds a corpus vault, runs ANN probe scans, applies metadata gates, reranks through blend, and emits `/app/output/search_bench.json` through `benchd` and `/app/tools/run_bench`.

Packages:
- `corpus` loads JSON vector records with realm tags.
- `embed` hashes text into dense unit vectors.
- `vault` stores packed rows for the index bank.
- `weave` links neighbors for greedy expansion.
- `probe` scores ANN candidates.
- `gate` filters candidates on realm metadata.
- `blend` reranks survivors.
- `bench` aggregates recall, ndcg, integrity, and filter metrics.

Thresholds live in `/app/config/index.toml`.
