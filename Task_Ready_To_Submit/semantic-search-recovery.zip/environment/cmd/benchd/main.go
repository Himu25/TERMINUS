package main

import (
	"fmt"
	"os"

	"ssrec.lab/bench"
)

func main() {
	cfgPath := "/app/config/index.toml"
	queryPath := "/app/data/queries_default.jsonl"
	outPath := "/app/output/search_bench.json"
	if len(os.Args) > 1 {
		queryPath = os.Args[1]
	}
	if len(os.Args) > 2 {
		outPath = os.Args[2]
	}
	cfg, err := bench.LoadCfg(cfgPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "config: %v\n", err)
		os.Exit(1)
	}
	cases, err := bench.LoadQueries(queryPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "queries: %v\n", err)
		os.Exit(1)
	}
	report, err := bench.Run(cfg, cases)
	if err != nil {
		fmt.Fprintf(os.Stderr, "run: %v\n", err)
		os.Exit(1)
	}
	if err := bench.WriteReport(outPath, report); err != nil {
		fmt.Fprintf(os.Stderr, "write: %v\n", err)
		os.Exit(1)
	}
}
