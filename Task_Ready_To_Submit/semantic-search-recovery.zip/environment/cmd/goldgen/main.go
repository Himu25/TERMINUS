package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"

	"ssrec.lab/blend"
	"ssrec.lab/corpus"
	"ssrec.lab/embed"
	"ssrec.lab/gate"
	"ssrec.lab/probe"
	"ssrec.lab/vault"
	"ssrec.lab/weave"
)

type specRow struct {
	QueryID string `json:"query_id"`
	Query   string `json:"query"`
}

type outRow struct {
	QueryID string   `json:"query_id"`
	Query   string   `json:"query"`
	GoldIDs []string `json:"gold_ids"`
}

func main() {
	if len(os.Args) < 4 {
		fmt.Fprintf(os.Stderr, "usage: goldgen <corpus.json> <specs.jsonl> <out.jsonl>\n")
		os.Exit(2)
	}
	docs, err := corpus.Load(os.Args[1])
	if err != nil {
		panic(err)
	}
	dim := 64
	degree := 8
	topK := 10
	bank := vault.Bank{}
	ids := make([]string, 0, len(docs))
	for _, doc := range docs {
		vec := embed.VecFromText(doc.Text, dim)
		bank.QkAdd(doc.ID, vec)
		ids = append(ids, doc.ID)
	}
	g := weave.LxWire(bank, degree)
	specs, err := loadSpecs(os.Args[2])
	if err != nil {
		panic(err)
	}
	if len(specs) == 0 {
		panic("no query specs")
	}
	outPath := os.Args[3]
	tmp, err := os.CreateTemp(os.TempDir(), ".goldgen-*.jsonl")
	if err != nil {
		panic(err)
	}
	tmpPath := tmp.Name()
	defer func() {
		_ = tmp.Close()
		_ = os.Remove(tmpPath)
	}()
	for _, spec := range specs {
		qv := embed.VecFromText(spec.Query, dim)
		idxs := probe.PxScan(qv, bank, g, topK, 32)
		annIDs := make([]string, 0, len(idxs))
		for _, ix := range idxs {
			if ix >= 0 && ix < len(ids) {
				annIDs = append(annIDs, ids[ix])
			}
		}
		hint := gate.RealmHint(spec.Query)
		filtered := gate.FilterDocs(docs, annIDs, hint)
		reranked := blend.Rerank(qv, bank, filtered, topK)
		gold := make([]string, 0, 3)
		for i := 0; i < 3 && i < len(reranked); i++ {
			gold = append(gold, reranked[i])
		}
		row := outRow{QueryID: spec.QueryID, Query: spec.Query, GoldIDs: gold}
		raw, _ := json.Marshal(row)
		_, _ = tmp.Write(raw)
		_, _ = tmp.Write([]byte("\n"))
	}
	if err := tmp.Close(); err != nil {
		panic(err)
	}
	if err := commitTempFile(tmpPath, outPath); err != nil {
		panic(err)
	}
}

func commitTempFile(tmpPath, outPath string) error {
	if err := os.Rename(tmpPath, outPath); err == nil {
		return nil
	}
	raw, err := os.ReadFile(tmpPath)
	if err != nil {
		return err
	}
	if err := os.WriteFile(outPath, raw, 0o644); err != nil {
		return err
	}
	return os.Remove(tmpPath)
}

func loadSpecs(path string) ([]specRow, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	rows := make([]specRow, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := sc.Text()
		if line == "" {
			continue
		}
		var row specRow
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return nil, err
		}
		rows = append(rows, row)
	}
	return rows, sc.Err()
}
