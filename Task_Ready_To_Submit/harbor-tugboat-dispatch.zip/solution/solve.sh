#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/harbor.toml
require_file /app/data/vessel_manifest.jsonl
require_file /app/data/weather_forecast.csv
require_file /app/data/boarding_log.csv
mkdir -p /app/bin /app/output

log "apply patched sources"
cp "${ROOT_DIR}/oracle/p2_order.go" /app/q9/p2_order.go
cp "${ROOT_DIR}/oracle/d4_hold.go" /app/k2/d4_hold.go
cp "${ROOT_DIR}/oracle/b7_slot.go" /app/h4/b7_slot.go
cp "${ROOT_DIR}/oracle/w5_roll.go" /app/z1/w5_roll.go
cp "${ROOT_DIR}/oracle/lib.rs" /app/n8/src/lib.rs

log "rebuild dispatcher"
bash /app/scripts/build.sh

log "refresh default vessel bundle"
/app/bin/berthpack /app/data/vessel_manifest.jsonl /app/data/vessels_default.jsonl

log "emit default dispatch report"
/app/tools/run_dispatch

log "post-run validation against harbor.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/harbor.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k in ("min_coverage_rate", "max_slack_ratio", "min_throughput_value"):
        cfg[k] = float(v)
    elif k.startswith("max_") or k.startswith("min_") or k == "tug_pool_hours":
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/dispatch_report.json").read_text())
assert report["status"] == "ok", report
assert report["coverage_rate"] >= cfg["min_coverage_rate"]
assert report["slack_ratio"] <= cfg["max_slack_ratio"]
assert report["berth_violations"] <= cfg["max_berth_violations"]
assert report["wait_inversions"] <= cfg["max_wait_inversions"]
assert report["standby_buffer_hours"] >= cfg["min_standby_buffer_hours"]
assert report["throughput_value"] >= cfg["min_throughput_value"]
for row in report["vessels"]:
    if row["vessel_id"].startswith("v_berth_") and row["served"]:
        assert row["berth_ready"], row
    if row["vessel_id"].startswith("v_shift_"):
        assert row["served"], row
print("ok", report["coverage_rate"], report["slack_ratio"], report["throughput_value"])
PY

log "oracle complete"
