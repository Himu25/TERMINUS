package k2

// DxGate reports whether dependency prerequisites are satisfied.
func DxGate(depOn []string, done map[string]bool) bool {
	if len(depOn) == 0 {
		return true
	}
	for _, depID := range depOn {
		if !done[depID] {
			return false
		}
	}
	return true
}
