package z1

// VxRoll totals slack hours for one shift wave.
func VxRoll(reserved, used int) int {
	if reserved <= used {
		return 0
	}
	return reserved - used
}
