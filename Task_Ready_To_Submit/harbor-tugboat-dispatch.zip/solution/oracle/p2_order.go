package q9

import (
	"sort"

	"htd.harbor/pkg/types"
)

// RxOrder ranks pending vessels for harbor tug dispatch.
func RxOrder(cases []types.VesselCase) []types.VesselCase {
	out := make([]types.VesselCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		a, b := out[i], out[j]
		if a.EtaRevision != b.EtaRevision {
			return a.EtaRevision > b.EtaRevision
		}
		if a.Urgency != b.Urgency {
			return a.Urgency > b.Urgency
		}
		if a.PriorityScore != b.PriorityScore {
			return a.PriorityScore > b.PriorityScore
		}
		return a.VesselID < b.VesselID
	})
	return out
}
