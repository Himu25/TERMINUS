station relay notes for batch credit handoff
