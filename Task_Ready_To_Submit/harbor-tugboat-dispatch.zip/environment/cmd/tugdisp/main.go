package main

import (
	"fmt"
	"os"

	"htd.harbor/drv"
)

func main() {
	if len(os.Args) < 3 {
		fmt.Fprintln(os.Stderr, "usage: tugdisp <vessels.jsonl> <out.json>")
		os.Exit(2)
	}
	cfg, err := drv.LoadCfg("/app/config/harbor.toml")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	cases, err := drv.LoadVesselCases(os.Args[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	fieldReports, err := drv.LoadBoardingLog("/app/data/boarding_log.csv")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	weathers, err := drv.LoadWeatherZones("/app/data/weather_forecast.csv")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	report, err := drv.Run(cfg, cases, fieldReports, weathers)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if err := drv.WriteReport(os.Args[2], report); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
