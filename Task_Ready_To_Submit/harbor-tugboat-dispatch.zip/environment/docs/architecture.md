Harbor tug dispatch ties together a Go driver, Rust weather meter, and bash runners under `/app`.
The driver reads vessel manifests from `/app/data`, weather tables, and boarding logs before emitting the dispatch report.
The Rust crate under `/app/n8` exposes a C ABI consumed by the Go bridge for billable-hour resolution.
Build orchestration lives in `/app/scripts/build.sh`; the default run path is `/app/tools/run_dispatch`.
