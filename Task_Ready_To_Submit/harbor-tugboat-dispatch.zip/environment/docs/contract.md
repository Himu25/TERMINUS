# Dispatch report schema

Reference for `/app/output/dispatch_report.json` field names and coarse semantics. Operational guardrails are in `/app/config/harbor.toml`.

## Top-level fields

- status: ok when every harbor.toml guardrail passes; otherwise a failure token
- tug_pool_hours: daily tug-hour pool from harbor.toml
- hours_assigned: billable hours consumed by served vessels
- hours_slack: reservation surplus summed across vessels
- vessels_total: input JSONL row count
- vessels_served: vessels marked served
- coverage_rate: vessels_served divided by vessels_total
- slack_ratio: hours_slack divided by hours_assigned
- berth_violations: berth dependency ordering faults
- wait_inversions: scheduling-order faults among served vessels
- standby_buffer_hours: dispatch headroom hours absorbed during shift waves
- throughput_value: weighted priority score total for served vessels
- report_digest: sha256 hex of compact JSON with report_digest empty
- vessels: per-vessel rows

## Vessel row fields

- vessel_id, cluster, urgency
- hours_reserved, hours_served, slack_hours
- served, berth_ready, queue_rank, shift_wave, throughput_value

## Notes

- queue_rank is the 1-based position in scheduler processing order; lower means earlier.
- slack_hours reflects reserved minus served when reservation exceeds billed service.
- report_digest hashes the same keys as the written report with report_digest set to an empty string before hashing.
