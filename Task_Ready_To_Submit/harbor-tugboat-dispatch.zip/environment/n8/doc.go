// Package span wraps the Rust credit meter for Go callers.
package n8
