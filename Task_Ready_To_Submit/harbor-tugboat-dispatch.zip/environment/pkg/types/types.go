package types

type HarborCfg struct {
	TugPoolHours      int
	MinCoverageRate        float64
	MaxSlackRatio        float64
	MaxBerthViolations     int
	MaxWaitInversions  int
	MinStandbyBufferHours    int
	MinThroughputValue   float64
	ClusterWeights         map[string]float64
}

type WeatherZone struct {
	WeatherZoneID string
	DryScale   int
	WetScale   int
	WetAfter   int
}

type VesselCase struct {
	VesselID       string   `json:"vessel_id"`
	Cluster        string   `json:"cluster"`
	Urgency        int      `json:"urgency"`
	EtaRevision int      `json:"eta_revision"`
	EstHours        int      `json:"est_hours"`
	ActHours        int      `json:"act_hours"`
	BerthDeps      []string `json:"berth_deps"`
	ShiftWave     int      `json:"shift_wave"`
	PriorityScore      float64  `json:"priority_score"`
	WeatherZoneID     string   `json:"weather_zone"`
	DepartSlot     int      `json:"depart_slot"`
	ArriveSlot     int      `json:"arrive_slot"`
}

type VesselRow struct {
	VesselID          string  `json:"vessel_id"`
	Cluster           string  `json:"cluster"`
	Urgency           int     `json:"urgency"`
	HoursReserved      int     `json:"hours_reserved"`
	HoursServed     int     `json:"hours_served"`
	Served            bool    `json:"served"`
	BerthReady        bool    `json:"berth_ready"`
	QueueRank      int     `json:"queue_rank"`
	SlackHours       int     `json:"slack_hours"`
	ShiftWave        int     `json:"shift_wave"`
	ThroughputValue float64 `json:"throughput_value"`
}

type DispatchReport struct {
	Status             string      `json:"status"`
	TugPoolHours  int         `json:"tug_pool_hours"`
	HoursAssigned        int         `json:"hours_assigned"`
	HoursSlack        int         `json:"hours_slack"`
	VesselsTotal       int         `json:"vessels_total"`
	VesselsServed      int         `json:"vessels_served"`
	CoverageRate       float64     `json:"coverage_rate"`
	SlackRatio       float64     `json:"slack_ratio"`
	BerthViolations    int         `json:"berth_violations"`
	WaitInversions int         `json:"wait_inversions"`
	StandbyBufferHours   int         `json:"standby_buffer_hours"`
	ThroughputValue  float64     `json:"throughput_value"`
	ReportDigest       string      `json:"report_digest"`
	Vessels            []VesselRow `json:"vessels"`
}
