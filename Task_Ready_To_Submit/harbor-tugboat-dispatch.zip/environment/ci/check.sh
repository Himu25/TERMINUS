#!/bin/bash
set -euo pipefail
cd /app
bash /app/scripts/build.sh
/app/bin/berthpack /app/data/vessel_manifest.jsonl /app/data/vessels_default.jsonl
/app/tools/run_dispatch
