package drv

import (
	"htd.harbor/n8"
	"htd.harbor/pkg/types"
	"htd.harbor/z1"
)

func meterBillable(jc types.VesselCase, fieldReportVal int, rp types.WeatherZone) int {
	dryScale := rp.DryScale
	wetScale := rp.WetScale
	wetAfter := rp.WetAfter
	if fieldReportVal > 0 {
		dryScale, wetScale, wetAfter = 100, 100, 0
	}
	roll := n8.MeterSpan(
		jc.EstHours, jc.ActHours, fieldReportVal,
		dryScale, wetScale, wetAfter, jc.DepartSlot,
	)
	if roll.Billable > 0 {
		return roll.Billable
	}
	return jc.EstHours
}

func vesselSurplus(reserved, used int) int {
	return z1.VxRoll(reserved, used)
}
