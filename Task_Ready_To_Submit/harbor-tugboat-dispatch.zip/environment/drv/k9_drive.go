package drv

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"

	"htd.harbor/k2"
	"htd.harbor/pkg/types"
	"htd.harbor/q9"
	"htd.harbor/summ"
	"htd.harbor/u3"
)

func LoadCfg(path string) (types.HarborCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.HarborCfg{}, err
	}
	cfg := types.HarborCfg{
		TugPoolHours:     12000,
		MinCoverageRate:     0.75,
		MaxSlackRatio:         0.35,
		MaxBerthViolations:      0,
		MaxWaitInversions: 1,
		MinStandbyBufferHours:      3,
		MinThroughputValue:     2.0,
		ClusterWeights:           map[string]float64{"cluster_alpha": 1.0, "cluster_beta": 1.0, "cluster_gamma": 1.0},
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "tug_pool_hours":
			fmt.Sscanf(val, "%d", &cfg.TugPoolHours)
		case "min_coverage_rate":
			fmt.Sscanf(val, "%f", &cfg.MinCoverageRate)
		case "max_slack_ratio":
			fmt.Sscanf(val, "%f", &cfg.MaxSlackRatio)
		case "max_berth_violations":
			fmt.Sscanf(val, "%d", &cfg.MaxBerthViolations)
		case "max_wait_inversions":
			fmt.Sscanf(val, "%d", &cfg.MaxWaitInversions)
		case "min_standby_buffer_hours":
			fmt.Sscanf(val, "%d", &cfg.MinStandbyBufferHours)
		case "min_throughput_value":
			fmt.Sscanf(val, "%f", &cfg.MinThroughputValue)
		case "cluster_weight_alpha":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClusterWeights["cluster_alpha"] = w
		case "cluster_weight_beta":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClusterWeights["cluster_beta"] = w
		case "cluster_weight_gamma":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClusterWeights["cluster_gamma"] = w
		}
	}
	return cfg, nil
}

func LoadWeatherZones(path string) (map[string]types.WeatherZone, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]types.WeatherZone)
	for i, row := range rows {
		if i == 0 || len(row) < 4 {
			continue
		}
		var peak, renew, after int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &peak)
		fmt.Sscanf(strings.TrimSpace(row[2]), "%d", &renew)
		fmt.Sscanf(strings.TrimSpace(row[3]), "%d", &after)
		id := strings.TrimSpace(row[0])
		out[id] = types.WeatherZone{
			WeatherZoneID: id,
			DryScale:  peak,
			WetScale: renew,
			WetAfter: after,
		}
	}
	return out, nil
}

func LoadVesselCases(path string) ([]types.VesselCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.VesselCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var jc types.VesselCase
		if err := json.Unmarshal([]byte(line), &jc); err != nil {
			return nil, err
		}
		if jc.WeatherZoneID == "" {
			jc.WeatherZoneID = "us-east"
		}
		out = append(out, jc)
	}
	return out, sc.Err()
}

func LoadBoardingLog(path string) (map[string]int, error) {
	f, err := os.Open(path)
	if err != nil {
		return map[string]int{}, nil
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]int)
	for i, row := range rows {
		if i == 0 || len(row) < 2 {
			continue
		}
		var actTons int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &actTons)
		out[strings.TrimSpace(row[0])] = actTons
	}
	return out, nil
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

func weatherFor(jc types.VesselCase, weathers map[string]types.WeatherZone) types.WeatherZone {
	if rp, ok := weathers[jc.WeatherZoneID]; ok {
		return rp
	}
	return types.WeatherZone{WeatherZoneID: jc.WeatherZoneID, DryScale: 100, WetScale: 100, WetAfter: 0}
}

func Run(cfg types.HarborCfg, cases []types.VesselCase, fieldReports map[string]int, weathers map[string]types.WeatherZone) (types.DispatchReport, error) {
	ordered := q9.RxOrder(cases)
	report := types.DispatchReport{
		Status:            "ok",
		TugPoolHours: cfg.TugPoolHours,
		VesselsTotal:         len(ordered),
	}
	done := make(map[string]bool)
	budgetLeft := cfg.TugPoolHours
	var spent, totalWaste, completed, depViol, inversions, renewTotal int
	var valueTotal float64
	prevRank := -1
	report.Vessels = make([]types.VesselRow, 0, len(ordered))

	for idx, jc := range ordered {
		actualReady := true
		for _, depID := range jc.BerthDeps {
			if !done[depID] {
				actualReady = false
				break
			}
		}
		depReady := k2.DxGate(jc.BerthDeps, done)
		if len(jc.BerthDeps) > 0 && !actualReady && depReady {
			depViol++
		}
		fieldReportVal := 0
		if act, ok := fieldReports[jc.VesselID]; ok && act > 0 {
			fieldReportVal = act
			jc.ActHours = act
		}
		rp := weatherFor(jc, weathers)
		billable := meterBillable(jc, fieldReportVal, rp)
		reserveNeed := u3.AxNeed(jc.EstHours, billable)
		reserved, ok := u3.BxReserve(budgetLeft, reserveNeed)
		headroom := budgetLeft - reserved
		if jc.ShiftWave > 0 {
			renewTotal += waveDispatchTotal(jc.ShiftWave, jc.EstHours, headroom)
		}
		used := 0
		finished := false
		if ok && depReady {
			used = jc.ActHours
			if used <= 0 {
				used = billable
			}
			if used > reserved {
				used = reserved
			}
			budgetLeft -= reserved
			spent += used
			finished = true
			completed++
			done[jc.VesselID] = true
			valueTotal += u3.VxValue(jc.PriorityScore, used)
		}
		wasteAmt := vesselSurplus(reserved, used)
		totalWaste += wasteAmt
		rankScore := jc.EtaRevision*10 + jc.Urgency
		if finished {
			if prevRank >= 0 && rankScore > prevRank {
				inversions++
			}
			prevRank = rankScore
		}
		row := types.VesselRow{
			VesselID:          jc.VesselID,
			Cluster:           jc.Cluster,
			Urgency:       jc.Urgency,
			HoursReserved:  reserved,
			HoursServed:      used,
			Served:      finished,
			BerthReady:       depReady,
			QueueRank:   idx + 1,
			SlackHours:     wasteAmt,
			ShiftWave:      jc.ShiftWave,
			ThroughputValue: round4(u3.VxValue(jc.PriorityScore, used)),
		}
		report.Vessels = append(report.Vessels, row)
	}

	report.HoursAssigned = spent
	report.HoursSlack = totalWaste
	report.VesselsServed = completed
	if report.VesselsTotal > 0 {
		report.CoverageRate = round4(float64(completed) / float64(report.VesselsTotal))
	}
	if spent > 0 {
		report.SlackRatio = round4(float64(totalWaste) / float64(spent))
	}
	report.BerthViolations = depViol
	report.WaitInversions = inversions
	report.StandbyBufferHours = renewTotal
	report.ThroughputValue = round4(valueTotal)
	hasDispatch := false
	for _, jc := range ordered {
		if jc.ShiftWave > 0 {
			hasDispatch = true
			break
		}
	}
	if !meetsFloors(cfg, report, hasDispatch) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func meetsFloors(cfg types.HarborCfg, report types.DispatchReport, hasDispatch bool) bool {
	if report.CoverageRate < cfg.MinCoverageRate {
		return false
	}
	if report.SlackRatio > cfg.MaxSlackRatio {
		return false
	}
	if report.BerthViolations > cfg.MaxBerthViolations {
		return false
	}
	if report.WaitInversions > cfg.MaxWaitInversions {
		return false
	}
	if report.StandbyBufferHours < cfg.MinStandbyBufferHours {
		if hasDispatch {
			return false
		}
	}
	if report.ThroughputValue < cfg.MinThroughputValue {
		return false
	}
	for _, row := range report.Vessels {
		if strings.HasPrefix(row.VesselID, "v_berth_") && !row.BerthReady && row.Served {
			return false
		}
		if strings.HasPrefix(row.VesselID, "v_shift_") && row.ShiftWave > 0 && !row.Served {
			return false
		}
		if strings.HasPrefix(row.VesselID, "v_log_") && row.SlackHours == 0 && row.HoursReserved > row.HoursServed+50 {
			return false
		}
		if strings.HasPrefix(row.VesselID, "v_weather_") && row.Served && row.HoursServed > row.HoursReserved+200 {
			return false
		}
	}
	_ = summ.SxFold(report.Vessels)
	return true
}

type digestPayload struct {
	Status              string         `json:"status"`
	TugPoolHours   int            `json:"tug_pool_hours"`
	HoursAssigned          int            `json:"hours_assigned"`
	HoursSlack          int            `json:"hours_slack"`
	VesselsTotal           int            `json:"vessels_total"`
	VesselsServed       int            `json:"vessels_served"`
	CoverageRate      float64        `json:"coverage_rate"`
	SlackRatio          float64        `json:"slack_ratio"`
	BerthViolations       int            `json:"berth_violations"`
	WaitInversions  int            `json:"wait_inversions"`
	StandbyBufferHours    int            `json:"standby_buffer_hours"`
	ThroughputValue   float64        `json:"throughput_value"`
	ReportDigest        string         `json:"report_digest"`
	Vessels             []types.VesselRow `json:"vessels"`
}

func digestBody(report types.DispatchReport) string {
	payload := digestPayload{
		Status:              report.Status,
		TugPoolHours:   report.TugPoolHours,
		HoursAssigned:         report.HoursAssigned,
		HoursSlack:         report.HoursSlack,
		VesselsTotal:        report.VesselsTotal,
		VesselsServed:       report.VesselsServed,
		CoverageRate:        report.CoverageRate,
		SlackRatio:        report.SlackRatio,
		BerthViolations:     report.BerthViolations,
		WaitInversions:  report.WaitInversions,
		StandbyBufferHours:    report.StandbyBufferHours,
		ThroughputValue:   report.ThroughputValue,
		ReportDigest:        "",
		Vessels:             report.Vessels,
	}
	raw, err := marshalDigestJSON(payload)
	if err != nil {
		return ""
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func marshalDigestJSON(payload digestPayload) ([]byte, error) {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return nil, err
	}
	b := buf.Bytes()
	if n := len(b); n > 0 && b[n-1] == '\n' {
		b = b[:n-1]
	}
	return b, nil
}

func WriteReport(path string, report types.DispatchReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func p95(values []int) int {
	if len(values) == 0 {
		return 0
	}
	cp := append([]int(nil), values...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}
