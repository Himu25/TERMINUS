package drv

import "htd.harbor/h4"

func waveDispatchTotal(dispatchWave, estTons, headroom int) int {
	if dispatchWave <= 0 {
		return 0
	}
	return h4.UxAbsorb(estTons/4, headroom)
}
