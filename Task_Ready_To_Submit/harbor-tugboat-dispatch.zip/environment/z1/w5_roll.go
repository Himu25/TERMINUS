package z1

// VxRoll totals slack hours for one shift wave.
func VxRoll(reserved, used int) int {
	_ = reserved
	_ = used
	return 0
}
