package q9

import "htd.harbor/pkg/types"

// QxShadow mirrors ranking shape for catalog probes (non-dispatch).
func QxShadow(cases []types.VesselCase) []types.VesselCase {
	out := make([]types.VesselCase, len(cases))
	copy(out, cases)
	return out
}
