package q9

import (
	"sort"

	"htd.harbor/pkg/types"
)

// RxOrder ranks pending vessels for harbor tug dispatch.
func RxOrder(cases []types.VesselCase) []types.VesselCase {
	out := make([]types.VesselCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		return out[i].EstHours < out[j].EstHours
	})
	return out
}
