probe harness placeholder for offline credit sampling
