package summ

import "htd.harbor/pkg/types"

// SxFold folds vessel rows for telemetry export (non-scheduling).
func SxFold(rows []types.VesselRow) int {
	total := 0
	for _, row := range rows {
		total += row.HoursServed
	}
	return total
}
