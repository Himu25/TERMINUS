"""Validate /app/output/reindex_bench.json against the public contract and reindex.toml guardrails."""

from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "reindex_bench.json"
CFG = APP / "config" / "reindex.toml"
RUNNER = APP / "tools" / "run_bench"
FIXTURES = Path(__file__).resolve().parent / "fixtures"
PACKS = APP / "data" / "packs"

REPORT_KEYS = frozenset(
    {
        "status",
        "corpus_vectors",
        "vector_dim",
        "shard_count",
        "queries_total",
        "index_epoch",
        "segments_ready",
        "rollback_events",
        "mean_recall_at_10",
        "mean_ndcg_at_10",
        "mean_shard_units",
        "mean_merge_units",
        "mean_batch_efficiency",
        "p95_query_units",
        "peak_scratch_bytes",
        "starved_lanes",
        "report_digest",
        "queries",
    }
)
QUERY_KEYS = frozenset(
    {
        "query_id",
        "recall_at_10",
        "ndcg_at_10",
        "gold_hits",
        "shard_units",
        "merge_units",
        "query_units",
        "shards_queried",
        "top_ids",
        "batch_size",
        "cache_hit",
        "served_epoch",
        "partial_hit",
        "stale_reads",
    }
)


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "vector_dim": 32,
        "shard_count": 4,
        "top_k": 10,
        "batch_window": 8,
        "recall_floor": 0.82,
        "ndcg_floor": 0.72,
        "max_mean_shard_units": 4200,
        "max_mean_merge_units": 180,
        "max_p95_query_units": 4800,
        "min_batch_efficiency": 0.62,
        "max_peak_scratch_bytes": 512,
        "max_starved_lanes": 0,
        "max_starved_lanes_skew": 0,
        "failover_recall_floor": 0.65,
        "tight_security_recall_floor": 0.5,
        "min_segments_ready": 4,
        "max_rollback_events": 1,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in (
            "recall_floor",
            "ndcg_floor",
            "failover_recall_floor",
            "tight_security_recall_floor",
            "min_batch_efficiency",
        ):
            cfg[key] = float(val)
        elif key in (
            "vector_dim",
            "shard_count",
            "top_k",
            "batch_window",
            "max_mean_shard_units",
            "max_mean_merge_units",
            "max_p95_query_units",
            "max_peak_scratch_bytes",
            "max_starved_lanes",
            "max_starved_lanes_skew",
            "min_segments_ready",
            "max_rollback_events",
        ):
            cfg[key] = int(float(val))
    return cfg


def _round4(value: float) -> float:
    return round(value * 10000 + 0.5) / 10000


def _expected_means(rows: list[dict]) -> tuple[float, float, float, float]:
    if not rows:
        return 0.0, 0.0, 0.0, 0.0
    total = len(rows)
    recall = sum(row["recall_at_10"] for row in rows) / total
    ndcg = sum(row["ndcg_at_10"] for row in rows) / total
    shard_u = sum(row["shard_units"] for row in rows) / total
    merge_u = sum(row["merge_units"] for row in rows) / total
    return _round4(recall), _round4(ndcg), _round4(shard_u), _round4(merge_u)


def _digest_payload(report: dict) -> dict:
    return {
        "status": report["status"],
        "corpus_vectors": report["corpus_vectors"],
        "vector_dim": report["vector_dim"],
        "shard_count": report["shard_count"],
        "queries_total": report["queries_total"],
        "index_epoch": report["index_epoch"],
        "segments_ready": report["segments_ready"],
        "rollback_events": report["rollback_events"],
        "mean_recall_at_10": report["mean_recall_at_10"],
        "mean_ndcg_at_10": report["mean_ndcg_at_10"],
        "mean_shard_units": report["mean_shard_units"],
        "mean_merge_units": report["mean_merge_units"],
        "mean_batch_efficiency": report["mean_batch_efficiency"],
        "p95_query_units": report["p95_query_units"],
        "peak_scratch_bytes": report["peak_scratch_bytes"],
        "starved_lanes": report["starved_lanes"],
        "report_digest": "",
        "queries": report["queries"],
    }


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _assert_query_row(row: dict) -> None:
    assert set(row) == QUERY_KEYS
    assert isinstance(row["query_id"], str) and row["query_id"]
    assert isinstance(row["recall_at_10"], (int, float))
    assert isinstance(row["ndcg_at_10"], (int, float))
    assert isinstance(row["gold_hits"], int)
    assert isinstance(row["shard_units"], int)
    assert isinstance(row["merge_units"], int)
    assert isinstance(row["query_units"], int)
    assert isinstance(row["shards_queried"], int)
    assert isinstance(row["top_ids"], list)
    assert isinstance(row["batch_size"], int)
    assert isinstance(row["cache_hit"], bool)
    assert isinstance(row["served_epoch"], int) and row["served_epoch"] >= 1
    assert isinstance(row["partial_hit"], bool)
    assert isinstance(row["stale_reads"], int) and row["stale_reads"] >= 0
    assert 0.0 <= float(row["recall_at_10"]) <= 1.0
    assert 0.0 <= float(row["ndcg_at_10"]) <= 1.0
    assert row["gold_hits"] >= 0
    assert row["shard_units"] >= 0
    assert row["merge_units"] >= 0
    assert row["query_units"] >= row["shard_units"] + row["merge_units"]
    assert row["shards_queried"] >= 0
    assert row["batch_size"] >= 1
    for doc_id in row["top_ids"]:
        assert isinstance(doc_id, str) and doc_id


def _assert_report_schema(data: dict) -> None:
    assert set(data) == REPORT_KEYS
    assert isinstance(data["status"], str) and data["status"] in {"ok", "fail"}
    for int_key in (
        "corpus_vectors",
        "vector_dim",
        "shard_count",
        "queries_total",
        "index_epoch",
        "segments_ready",
        "rollback_events",
        "p95_query_units",
        "peak_scratch_bytes",
        "starved_lanes",
    ):
        assert isinstance(data[int_key], int), int_key
        assert data[int_key] >= 0, int_key
    for float_key in (
        "mean_recall_at_10",
        "mean_ndcg_at_10",
        "mean_shard_units",
        "mean_merge_units",
        "mean_batch_efficiency",
    ):
        assert isinstance(data[float_key], (int, float)), float_key
        assert float(data[float_key]) >= 0.0, float_key
    digest = data["report_digest"]
    assert isinstance(digest, str) and len(digest) == 64
    assert digest == digest.lower()
    assert re.fullmatch(r"[0-9a-f]{64}", digest)
    assert isinstance(data["queries"], list)
    for row in data["queries"]:
        _assert_query_row(row)


def _load_report(path: Path = OUT) -> dict:
    assert path.is_file(), f"missing report at {path}"
    data = json.loads(path.read_text(encoding="utf-8"))
    _assert_report_schema(data)
    return data


def _rebuild_benchd(env: dict[str, str] | None = None) -> None:
    subprocess.run(
        ["go", "build", "-o", "/app/bin/benchd", "./cmd/benchd"],
        cwd=APP,
        env=env or os.environ.copy(),
        check=True,
        capture_output=True,
        text=True,
    )


def _goldgen(corpus_path: Path, specs_path: Path, out_path: Path) -> None:
    subprocess.run(
        [
            "/app/bin/goldgen",
            corpus_path.as_posix(),
            specs_path.as_posix(),
            out_path.as_posix(),
        ],
        check=True,
        capture_output=True,
        text=True,
    )


def _run_bench(
    query_path: Path,
    out_path: Path = OUT,
    corpus_path: Path | None = None,
    *,
    rebuild: bool = False,
) -> None:
    env = os.environ.copy()
    if corpus_path is not None:
        env["TB_CORPUS_PATH"] = str(corpus_path)
    else:
        env.pop("TB_CORPUS_PATH", None)
    if out_path.exists():
        out_path.unlink()
    if rebuild:
        _rebuild_benchd(env)
    subprocess.run(
        [
            "/app/bin/benchd",
            query_path.as_posix(),
            out_path.as_posix(),
        ],
        cwd=APP,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )


def _assert_ok_default(report: dict) -> None:
    cfg = _parse_cfg()
    assert report["status"] == "ok"
    assert report["mean_recall_at_10"] >= cfg["recall_floor"]
    assert report["mean_ndcg_at_10"] >= cfg["ndcg_floor"]
    assert report["mean_shard_units"] <= cfg["max_mean_shard_units"]
    assert report["mean_merge_units"] <= cfg["max_mean_merge_units"]
    assert report["p95_query_units"] <= cfg["max_p95_query_units"]
    assert report["mean_batch_efficiency"] >= cfg["min_batch_efficiency"]
    assert report["peak_scratch_bytes"] <= cfg["max_peak_scratch_bytes"]
    assert report["starved_lanes"] <= cfg["max_starved_lanes"]
    assert report["segments_ready"] >= cfg["min_segments_ready"]
    assert report["rollback_events"] <= cfg["max_rollback_events"]


@pytest.fixture(scope="session", autouse=True)
def _default_bench_run() -> None:
    subprocess.run(
        ["go", "build", "-o", "/app/bin/goldgen", "./cmd/goldgen"],
        cwd=APP,
        check=True,
        capture_output=True,
        text=True,
    )
    _rebuild_benchd()
    _goldgen(
        APP / "data" / "corpus_default.json",
        APP / "data" / "query_specs.jsonl",
        APP / "data" / "queries_default.jsonl",
    )
    _run_bench(APP / "data" / "queries_default.jsonl")


def test_runner_exists() -> None:
    """Documented bench driver is present and executable."""
    assert RUNNER.is_file() and os.access(RUNNER, os.X_OK)


def test_report_schema_keys() -> None:
    """reindex_bench.json exposes the contract field set only."""
    report = _load_report()
    _assert_ok_default(report)
    assert report["queries_total"] == len(report["queries"])


def test_per_query_row_keys() -> None:
    """Each queries[] row uses the documented sub-schema and valid metric ranges."""
    report = _load_report()
    _assert_ok_default(report)
    for row in report["queries"]:
        _assert_query_row(row)


def test_status_ok_and_reindex_floors() -> None:
    """Default pack clears recall, commit efficiency, scratch, and segment caps."""
    _assert_ok_default(_load_report())


def test_batch_efficiency_meets_floor() -> None:
    """mean_batch_efficiency must meet min_batch_efficiency in reindex.toml."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["status"] == "ok"
    assert report["mean_batch_efficiency"] >= cfg["min_batch_efficiency"]


def test_peak_scratch_within_cap() -> None:
    """peak_scratch_bytes stays under max_peak_scratch_bytes."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["peak_scratch_bytes"] <= cfg["max_peak_scratch_bytes"]


def test_p95_query_units_within_cap() -> None:
    """Tail query units stay under max_p95_query_units."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["p95_query_units"] <= cfg["max_p95_query_units"]


def test_starved_lanes_zero_on_default_pack() -> None:
    """Default replay schedules every shard lane at least once."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["starved_lanes"] <= cfg["max_starved_lanes"]


def test_epoch_cache_repeat_hits() -> None:
    """Repeated query ids in the same index generation should record cache_hit rows."""
    report = _load_report()
    by_id: dict[str, list[dict]] = {}
    for row in report["queries"]:
        by_id.setdefault(row["query_id"], []).append(row)
    hits = False
    for rows in by_id.values():
        if len(rows) < 2:
            continue
        epochs = {r["served_epoch"] for r in rows}
        if len(epochs) == 1 and any(r["cache_hit"] for r in rows[1:]):
            hits = True
            break
    assert hits


def test_partial_hit_rows_during_reindex() -> None:
    """Default replay records partial_hit while segments are still committing."""
    report = _load_report()
    partial = [r for r in report["queries"] if r["partial_hit"]]
    assert len(partial) >= 1
    assert all(r["stale_reads"] > 0 for r in partial)


def test_segments_ready_meets_floor() -> None:
    """segments_ready finishes at or above min_segments_ready."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["segments_ready"] >= cfg["min_segments_ready"]


def test_index_epoch_positive() -> None:
    """index_epoch records the serving generation after commit waves."""
    report = _load_report()
    assert report["index_epoch"] >= 1


def test_rollback_events_within_cap_on_default() -> None:
    """Default pack keeps rollback_events at or below max_rollback_events."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["rollback_events"] <= cfg["max_rollback_events"]


def test_ndcg_floor_on_default_pack() -> None:
    """Default pack mean_ndcg_at_10 meets ndcg_floor from reindex.toml."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["mean_ndcg_at_10"] >= cfg["ndcg_floor"]


def test_summary_means_recomputed_from_query_rows() -> None:
    """Mean recall, ndcg, and unit fields must match per-query rows."""
    report = _load_report()
    want_recall, want_ndcg, want_shard, want_merge = _expected_means(report["queries"])
    assert report["mean_recall_at_10"] == pytest.approx(want_recall, abs=2e-4)
    assert report["mean_ndcg_at_10"] == pytest.approx(want_ndcg, abs=2e-4)
    assert report["mean_shard_units"] == pytest.approx(want_shard, abs=2e-4)
    assert report["mean_merge_units"] == pytest.approx(want_merge, abs=2e-4)


def test_p95_query_units_matches_rows() -> None:
    """p95_query_units is the 95th percentile of per-query query_units."""
    report = _load_report()
    units = sorted(row["query_units"] for row in report["queries"])
    idx = max(0, int(len(units) * 0.95 + 0.999999) - 1)
    assert report["p95_query_units"] == units[idx]


def test_report_digest_format() -> None:
    """report_digest is 64-char lowercase hex."""
    digest = _load_report()["report_digest"]
    assert len(digest) == 64
    assert digest == digest.lower()
    assert re.fullmatch(r"[0-9a-f]{64}", digest)


def test_report_digest_matches_body() -> None:
    """report_digest is SHA-256 of the compact pre-digest payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_repeat_run_byte_identical() -> None:
    """Back-to-back default runs emit identical report bytes."""
    _assert_ok_default(_load_report())
    first = OUT.read_bytes()
    _run_bench(APP / "data" / "queries_default.jsonl")
    second = OUT.read_bytes()
    assert first == second


def test_queries_total_matches_pack_line_count() -> None:
    """queries_total equals non-empty lines in the default query JSONL."""
    report = _load_report()
    expected = sum(
        1
        for line in (APP / "data" / "queries_default.jsonl")
        .read_text(encoding="utf-8")
        .splitlines()
        if line.strip()
    )
    assert report["queries_total"] == expected
    assert len(report["queries"]) == expected


def test_corpus_vectors_matches_manifest() -> None:
    """corpus_vectors and vector_dim track the shard manifest."""
    report = _load_report()
    manifest = json.loads((APP / "registry" / "shard_manifest.json").read_text(encoding="utf-8"))
    assert report["corpus_vectors"] == manifest["count"]
    assert report["vector_dim"] == manifest["dim"]
    assert report["shard_count"] == manifest["shards"]


def test_q_search_ann_ndcg_floor() -> None:
    """q_search_ann ndcg must be positive once ranking is repaired."""
    report = _load_report()
    cfg = _parse_cfg()
    row = next(r for r in report["queries"] if r["query_id"] == "q_search_ann")
    assert row["ndcg_at_10"] >= cfg["ndcg_floor"] / (2 * cfg["top_k"])


def test_failover_queries_skip_dead_shards() -> None:
    """Failover rows query only live lanes and clear the failover recall floor."""
    report = _load_report()
    cfg = _parse_cfg()
    specs = {
        json.loads(line)["query_id"]: json.loads(line).get("dead_shards", [])
        for line in (APP / "data" / "query_specs.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    }
    for row in report["queries"]:
        if not row["query_id"].startswith("q_failover"):
            continue
        dead = specs[row["query_id"]]
        assert row["shards_queried"] == cfg["shard_count"] - len(dead)
        assert row["recall_at_10"] >= cfg["failover_recall_floor"]
        assert row["shard_units"] < cfg["max_mean_shard_units"]


def test_fixture_pack_failover_recall() -> None:
    """Failover fixture pack clears per-row failover recall floor."""
    pack = PACKS / "pack_failover"
    out = APP / "output" / "bench_pack_failover.json"
    cfg = _parse_cfg()
    queries = pack / "queries.jsonl"
    _goldgen(pack / "corpus.json", pack / "query_specs.jsonl", queries)
    _run_bench(queries, out, pack / "corpus.json")
    report = _load_report(out)
    for row in report["queries"]:
        assert row["recall_at_10"] >= cfg["failover_recall_floor"]


def test_fixture_pack_skew_starvation_cap() -> None:
    """Hot-skew pack keeps starved_lanes within max_starved_lanes_skew."""
    pack = PACKS / "pack_skew_queries"
    out = APP / "output" / "bench_pack_skew.json"
    cfg = _parse_cfg()
    queries = pack / "queries.jsonl"
    _goldgen(pack / "corpus.json", pack / "query_specs.jsonl", queries)
    _run_bench(queries, out, pack / "corpus.json")
    report = _load_report(out)
    assert report["status"] == "ok"
    assert report["starved_lanes"] <= cfg["max_starved_lanes_skew"]
    assert report["p95_query_units"] <= cfg["max_p95_query_units"]
    assert report["mean_recall_at_10"] >= cfg["recall_floor"]


def test_fixture_pack_tight_recall_security_row() -> None:
    """Tight recall pack clears security-query recall floor."""
    pack = PACKS / "pack_tight_recall"
    out = APP / "output" / "bench_pack_tight.json"
    cfg = _parse_cfg()
    queries = pack / "queries.jsonl"
    _goldgen(pack / "corpus.json", pack / "query_specs.jsonl", queries)
    _run_bench(queries, out, pack / "corpus.json")
    report = _load_report(out)
    sec = next(r for r in report["queries"] if r["query_id"] == "q_tight_security")
    assert sec["recall_at_10"] >= cfg["tight_security_recall_floor"]
    assert report["mean_recall_at_10"] >= cfg["recall_floor"]


def test_fixture_pack_reindex_inflight() -> None:
    """Reindex-inflight pack records partial hits and respects rollback cap."""
    pack = PACKS / "pack_reindex_inflight"
    out = APP / "output" / "bench_pack_reindex.json"
    cfg = _parse_cfg()
    queries = pack / "queries.jsonl"
    _goldgen(pack / "corpus.json", pack / "query_specs.jsonl", queries)
    _run_bench(queries, out, pack / "corpus.json")
    report = _load_report(out)
    assert report["status"] == "ok"
    assert any(r["partial_hit"] for r in report["queries"])
    assert report["rollback_events"] <= cfg["max_rollback_events"]
    assert report["segments_ready"] >= cfg["min_segments_ready"]
    assert report["mean_recall_at_10"] >= cfg["recall_floor"]


def test_broken_batch_ablation_fails_efficiency() -> None:
    """Single-query batches cannot clear mean_batch_efficiency on the default pack."""
    batch_src = APP / "w8" / "w8_wave.go"
    backup = batch_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "broken_qk_fold.go").read_text(encoding="utf-8")
    out = APP / "output" / "bench_ablation_batch.json"
    cfg = _parse_cfg()
    try:
        batch_src.write_text(broken, encoding="utf-8")
        _run_bench(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        assert report["mean_batch_efficiency"] < cfg["min_batch_efficiency"] or report["status"] == "fail"
    finally:
        batch_src.write_text(backup, encoding="utf-8")
        _rebuild_benchd()
        _run_bench(APP / "data" / "queries_default.jsonl")
