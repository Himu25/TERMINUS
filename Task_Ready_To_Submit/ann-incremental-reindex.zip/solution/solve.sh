#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

require_file() {
  if [[ ! -f "$1" ]]; then
    echo "missing required file: $1" >&2
    exit 1
  fi
}

require_file /app/go.mod
require_file /app/config/reindex.toml
require_file /app/data/corpus_default.json
require_file /app/data/query_specs.jsonl
mkdir -p /app/bin /app/output

cp "${ROOT_DIR}/oracle/w8_wave.go" /app/w8/w8_wave.go
cp "${ROOT_DIR}/oracle/r3_peek.go" /app/j3/r3_peek.go
cp "${ROOT_DIR}/oracle/n7_slot.go" /app/p2/n7_slot.go
cp "${ROOT_DIR}/oracle/m3_bump.go" /app/k9/m3_bump.go
cp "${ROOT_DIR}/oracle/m3_reset.go" /app/k9/m3_reset.go

go build -o /app/bin/goldgen ./cmd/goldgen
/app/bin/goldgen \
  /app/data/corpus_default.json \
  /app/data/query_specs.jsonl \
  /app/data/queries_default.jsonl

go build -o /app/bin/benchd ./cmd/benchd
chmod +x /app/tools/run_bench
/app/tools/run_bench \
  /app/data/queries_default.jsonl \
  /app/output/reindex_bench.json

python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/reindex.toml")
cfg: dict[str, float | int] = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    key, val = (part.strip() for part in line.split("=", 1))
    if key.endswith("_floor") or key.startswith("min_"):
        cfg[key] = float(val)
    elif key.startswith("max_") or key in ("batch_window", "min_segments_ready"):
        cfg[key] = int(float(val))

report = json.loads(Path("/app/output/reindex_bench.json").read_text())
assert report["status"] == "ok", report
assert report["mean_recall_at_10"] >= cfg["recall_floor"]
assert report["mean_ndcg_at_10"] >= cfg["ndcg_floor"]
assert report["mean_batch_efficiency"] >= cfg["min_batch_efficiency"]
assert report["p95_query_units"] <= cfg["max_p95_query_units"]
assert report["peak_scratch_bytes"] <= cfg["max_peak_scratch_bytes"]
assert report["starved_lanes"] <= cfg["max_starved_lanes"]
assert report["segments_ready"] >= cfg["min_segments_ready"]
assert report["rollback_events"] <= cfg["max_rollback_events"]
assert report["index_epoch"] >= 1
partial = [q for q in report["queries"] if q.get("partial_hit")]
assert len(partial) >= 1
PY
