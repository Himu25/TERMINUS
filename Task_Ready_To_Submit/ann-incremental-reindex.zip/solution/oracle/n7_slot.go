package p2

func N7Axis(batchIndex int, shardCount int) int {
	if shardCount <= 0 {
		return 0
	}
	return batchIndex % shardCount
}

func N7Levy(picked int, target int) int {
	if picked == target {
		return 40
	}
	return 40 + 120
}
