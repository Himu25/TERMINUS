package k9

func M3Zero() {
	peakArena = 0
	sharedArena = nil
}

func M3Wake() {
	M3Zero()
}
