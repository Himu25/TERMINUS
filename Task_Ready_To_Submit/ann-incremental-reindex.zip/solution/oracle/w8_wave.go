package w8

func QkFold(pending int, window int) int {
	if pending <= 0 {
		return 0
	}
	if window <= 0 {
		return pending
	}
	if pending < window {
		return pending
	}
	return window
}

func QkTax(batchSize int) int {
	if batchSize <= 1 {
		return 180
	}
	return 40
}
