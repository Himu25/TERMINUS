package k9

var peakArena int
var sharedArena []float64

func M3Bump(dim int) []float64 {
	if cap(sharedArena) < dim {
		sharedArena = make([]float64, dim)
	}
	used := dim * 8
	if used > peakArena {
		peakArena = used
	}
	return sharedArena[:dim]
}

func M3High() int {
	return peakArena
}
