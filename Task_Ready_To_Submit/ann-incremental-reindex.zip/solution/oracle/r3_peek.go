package j3

import (
	"fmt"
	"sync"
)

type memoEntry struct {
	topIDs []string
	units  int
	epoch  int
}

var memoTable sync.Map

func R3Peek(queryID string, epoch int) ([]string, int, bool) {
	key := fmt.Sprintf("%s@%d", queryID, epoch)
	raw, ok := memoTable.Load(key)
	if !ok {
		return nil, 0, false
	}
	entry := raw.(memoEntry)
	return entry.topIDs, entry.units, true
}

func R3Save(queryID string, epoch int, topIDs []string, units int) {
	key := fmt.Sprintf("%s@%d", queryID, epoch)
	memoTable.Store(key, memoEntry{topIDs: topIDs, units: units, epoch: epoch})
}

func R3Zero() {
	memoTable = sync.Map{}
}
