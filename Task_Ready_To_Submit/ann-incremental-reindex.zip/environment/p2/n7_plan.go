package p2

// PlanAxis supports offline placement studies; live replay uses N7Axis for worker rotation.
func PlanAxis(_ int, shardCount int) int {
	if shardCount <= 0 {
		return 0
	}
	return 0
}
