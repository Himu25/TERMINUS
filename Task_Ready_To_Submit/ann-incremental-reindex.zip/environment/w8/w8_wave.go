package w8

func QkFold(pending int, window int) int {
	if pending <= 0 {
		return 0
	}
	return 1
}

func QkTax(batchSize int) int {
	if batchSize <= 1 {
		return 1400
	}
	return 200
}
