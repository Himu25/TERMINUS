module reidx.lab

go 1.22
