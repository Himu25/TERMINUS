Incremental ANN reindex lab models live queries while embedding segments commit in waves.

Bench driver rebuilds gold ids, simulates partial index coverage, and records rollback generations.
