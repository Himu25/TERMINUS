# Architecture notes

Corpus JSON is embedded, partitioned across shard lanes by doc id hash, reindexed in segment commit waves while live queries continue, probed per live lane, then merged globally.

`/app/output/reindex_bench.json` top-level keys: status, corpus_vectors, vector_dim, shard_count, queries_total, index_epoch, segments_ready, rollback_events, mean_recall_at_10, mean_ndcg_at_10, mean_shard_units, mean_merge_units, mean_batch_efficiency, p95_query_units, peak_scratch_bytes, starved_lanes, report_digest, queries.

Each queries row: query_id, recall_at_10, ndcg_at_10, gold_hits, shard_units, merge_units, query_units, shards_queried, top_ids, batch_size, cache_hit, served_epoch, partial_hit, stale_reads. Ranking metrics are between zero and one; gold_hits is non-negative. Unit fields are synthetic cost tallies, not wall-clock timings. query_units equals shard_units plus merge_units plus reindex overhead. mean_batch_efficiency is sum of realized per-query batch widths across commit ticks, divided by tick count and batch_window from reindex.toml (not queries_total). starved_lanes counts shard lanes that received zero worker touches during replay. Off-home worker lanes add scheduling surcharge to query_units; skew packs fail p95_query_units when surcharge constants are too large. peak_scratch_bytes is the high-water mark of scratch allocations during concurrent reindex and query. index_epoch is the serving generation after all commit waves and rollbacks. segments_ready is how many segments finished the latest commit wave. rollback_events counts generation rollbacks triggered by rollback_after query rows.

Digest covers every report field except report_digest, serialized as compact JSON with report_digest set to an empty string. Verifier mean recomputation allows four-decimal drift (2e-4).

Quality gates compare means against floors and ceilings in reindex.toml. Failover packs list dead_shards per query; only live lanes may be queried. Rollback rows list rollback_after and rollback_generation; a passing run keeps rollback_events at or below max_rollback_events.

Verifier fixture benches may write `/app/output/bench_pack_failover.json`, `/app/output/bench_pack_skew.json`, `/app/output/bench_pack_tight.json`, `/app/output/bench_pack_reindex.json`, and `/app/output/bench_ablation_batch.json`. Pack corpora and specs live under `/app/data/packs/`. Ablation sources ship only in the verifier tree.
