package k9

func M3Zero() {
	peakArena = 0
}

func M3Wake() {
	M3Zero()
}
