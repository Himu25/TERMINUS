package k9

var peakArena int

func M3Bump(dim int) []float64 {
	buf := make([]float64, dim*4)
	used := dim * 16 * 8
	if used > peakArena {
		peakArena = used
	}
	return buf
}

func M3High() int {
	return peakArena
}
