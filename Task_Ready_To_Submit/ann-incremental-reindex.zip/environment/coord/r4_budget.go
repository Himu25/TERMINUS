package coord

// R4Budget estimates legacy commit-wave tax for dashboards; benchd uses w8 coalesce tax instead.
func R4Budget(batchSize int) int {
	if batchSize <= 1 {
		return 1400
	}
	return 200
}
