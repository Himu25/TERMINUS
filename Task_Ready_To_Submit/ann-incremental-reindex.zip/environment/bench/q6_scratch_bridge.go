package bench

import "reidx.lab/k9"

func ScratchAlloc(dim int) []float64 {
	return k9.M3Bump(dim)
}

func ScratchPeak() int {
	return k9.M3High()
}
