package bench

import (
	"reidx.lab/lane"
	"reidx.lab/p2"
)

func ProbeUnits(lanes []lane.Lane, dim int, dead []int) int {
	return p2.NxTally(lanes, dim, dead)
}
