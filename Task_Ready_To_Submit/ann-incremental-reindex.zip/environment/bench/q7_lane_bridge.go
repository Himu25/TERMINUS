package bench

import "reidx.lab/p2"

func WorkerPick(batchIndex int, shardCount int) int {
	return p2.N7Axis(batchIndex, shardCount)
}

func WorkerTax(picked int, target int) int {
	return p2.N7Levy(picked, target)
}
