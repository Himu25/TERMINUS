package bench

import "reidx.lab/j3"

func MemoLookup(queryID string, epoch int) ([]string, int, bool) {
	return j3.R3Peek(queryID, epoch)
}

func MemoSave(queryID string, epoch int, topIDs []string, units int) {
	j3.R3Save(queryID, epoch, topIDs, units)
}
