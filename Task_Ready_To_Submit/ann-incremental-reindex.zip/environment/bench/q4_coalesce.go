package bench

import "reidx.lab/w8"

func CoalesceWindow(pending int, window int) int {
	return w8.QkFold(pending, window)
}

func CoalesceTax(batchSize int) int {
	return w8.QkTax(batchSize)
}
