package bench

import (
	"reidx.lab/coord"
	"reidx.lab/pkg/types"
)

func FoldTopK(partials [][]types.PartialHit, topK int) ([]types.PartialHit, int) {
	merged := coord.MxFold(partials, topK)
	return merged, coord.R4Weight(partials, topK)
}
