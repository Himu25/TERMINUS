package bench

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"

	"reidx.lab/w8"
	"reidx.lab/corpus"
	"reidx.lab/embed"
	"reidx.lab/lane"
	"reidx.lab/pkg/types"
	"reidx.lab/j3"
	"reidx.lab/k9"
)

func LoadCfg(path string) (types.ReindexCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.ReindexCfg{}, err
	}
	cfg := types.ReindexCfg{
		CorpusPath:         corpus.DefaultCorpusPath,
		BatchWindow:        8,
		MinSegmentsReady:   4,
		MaxRollbackEvents:  0,
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "vector_dim":
			fmt.Sscanf(val, "%d", &cfg.VectorDim)
		case "shard_count":
			fmt.Sscanf(val, "%d", &cfg.ShardCount)
		case "top_k":
			fmt.Sscanf(val, "%d", &cfg.TopK)
		case "batch_window":
			fmt.Sscanf(val, "%d", &cfg.BatchWindow)
		case "recall_floor":
			fmt.Sscanf(val, "%f", &cfg.RecallFloor)
		case "ndcg_floor":
			fmt.Sscanf(val, "%f", &cfg.NdcgFloor)
		case "max_mean_shard_units":
			fmt.Sscanf(val, "%d", &cfg.MaxMeanShardUnits)
		case "max_mean_merge_units":
			fmt.Sscanf(val, "%d", &cfg.MaxMeanMergeUnits)
		case "max_p95_query_units":
			fmt.Sscanf(val, "%d", &cfg.MaxP95QueryUnits)
		case "min_batch_efficiency":
			fmt.Sscanf(val, "%f", &cfg.MinBatchEfficiency)
		case "max_peak_scratch_bytes":
			fmt.Sscanf(val, "%d", &cfg.MaxPeakScratchBytes)
		case "max_starved_lanes":
			fmt.Sscanf(val, "%d", &cfg.MaxStarvedLanes)
		case "max_starved_lanes_skew":
			fmt.Sscanf(val, "%d", &cfg.MaxStarvedLanesSkew)
		case "failover_recall_floor":
			fmt.Sscanf(val, "%f", &cfg.FailoverRecallFloor)
		case "tight_security_recall_floor":
			fmt.Sscanf(val, "%f", &cfg.TightSecurityRecall)
		case "min_segments_ready":
			fmt.Sscanf(val, "%d", &cfg.MinSegmentsReady)
		case "max_rollback_events":
			fmt.Sscanf(val, "%d", &cfg.MaxRollbackEvents)
		case "corpus_path":
			cfg.CorpusPath = val
		}
	}
	return cfg, nil
}

func LoadQueries(path string) ([]types.QueryCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.QueryCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var qc types.QueryCase
		if err := json.Unmarshal([]byte(line), &qc); err != nil {
			return nil, err
		}
		out = append(out, qc)
	}
	return out, sc.Err()
}

func BuildLanes(docs []types.Doc, cfg types.ReindexCfg) []lane.Lane {
	lanes := lane.EmptyLanes(cfg.ShardCount)
	for _, doc := range docs {
		vec := embed.VecFromText(doc.Text, cfg.VectorDim)
		sid := lane.RouteDoc(doc.ID, cfg.ShardCount)
		lanes[sid].Rows = append(lanes[sid].Rows, w8.PackVec(doc.ID, vec))
	}
	return lanes
}

func Run(cfg types.ReindexCfg, cases []types.QueryCase) (types.BenchReport, error) {
	if override := os.Getenv("TB_CORPUS_PATH"); override != "" {
		cfg.CorpusPath = override
	}
	docs, err := corpus.Load(cfg.CorpusPath)
	if err != nil {
		return types.BenchReport{}, err
	}
	lanes := BuildLanes(docs, cfg)
	j3.R3Zero()
	k9.M3Wake()
	segmentCommitHits := make([]int, cfg.ShardCount)
	laneHits := make([]int, cfg.ShardCount)
	indexEpoch := 1
	segmentsReady := 0
	rollbackEvents := 0
	report := types.BenchReport{
		Status:        "ok",
		CorpusVectors: len(docs),
		VectorDim:     cfg.VectorDim,
		ShardCount:    cfg.ShardCount,
		QueriesTotal:  len(cases),
		IndexEpoch:    indexEpoch,
	}
	var sumRecall, sumNdcg, sumShard, sumMerge, sumBatch float64
	queryUnits := make([]int, 0, len(cases))
	report.Queries = make([]types.QueryRow, 0, len(cases))
	ticks := 0
	idx := 0
	for idx < len(cases) {
		n := CoalesceWindow(len(cases)-idx, cfg.BatchWindow)
		if n <= 0 {
			break
		}
		ticks++
		for j := 0; j < n; j++ {
			qc := cases[idx+j]
			sumBatch += float64(n)
			qv := embed.VecFromText(qc.Query, cfg.VectorDim)
			_ = ScratchAlloc(cfg.VectorDim)
			target := lane.RouteDoc(qc.QueryID, cfg.ShardCount)
			pick := WorkerPick(j, cfg.ShardCount)
			if pick >= 0 && pick < len(laneHits) {
				laneHits[pick]++
			}
			partial := segmentsReady < cfg.ShardCount
			stale := cfg.ShardCount - segmentsReady
			if stale < 0 {
				stale = 0
			}
			epoch := indexEpoch
			if top, units, ok := MemoLookup(qc.QueryID, epoch); ok {
				recall, ndcg, hits := rankScores(qc.GoldIDs, top, cfg.TopK)
				report.Queries = append(report.Queries, types.QueryRow{
					QueryID:       qc.QueryID,
					RecallAt10:    round4(recall),
					NdcgAt10:      round4(ndcg),
					GoldHits:      hits,
					ShardUnits:    units,
					MergeUnits:    0,
					QueryUnits:    units,
					ShardsQueried: 1,
					TopIDs:        top,
					BatchSize:     n,
					CacheHit:      true,
					ServedEpoch:   epoch,
					PartialHit:    partial,
					StaleReads:    stale,
				})
				sumRecall += recall
				sumNdcg += ndcg
				sumShard += float64(units)
				queryUnits = append(queryUnits, units)
				applyRollback(qc, &segmentsReady, &indexEpoch, &rollbackEvents)
				continue
			}
			partials := FanoutPartials(qv, lanes, qc.DeadShards, cfg.TopK)
			merged, mergeU := FoldTopK(partials, cfg.TopK)
			shardU := ProbeUnits(lanes, cfg.VectorDim, qc.DeadShards)
			schedU := CoalesceTax(n) + WorkerTax(pick, target)
			queryU := shardU + mergeU + schedU
			topIDs := make([]string, 0, len(merged))
			for _, hit := range merged {
				topIDs = append(topIDs, hit.DocID)
			}
			recall, ndcg, hits := rankScores(qc.GoldIDs, topIDs, cfg.TopK)
			row := types.QueryRow{
				QueryID:       qc.QueryID,
				RecallAt10:    round4(recall),
				NdcgAt10:      round4(ndcg),
				GoldHits:      hits,
				ShardUnits:    shardU,
				MergeUnits:    mergeU,
				QueryUnits:    queryU,
				ShardsQueried: len(partials),
				TopIDs:        topIDs,
				BatchSize:     n,
				CacheHit:      false,
				ServedEpoch:   epoch,
				PartialHit:    partial,
				StaleReads:    stale,
			}
			report.Queries = append(report.Queries, row)
			MemoSave(qc.QueryID, epoch, topIDs, queryU)
			sumRecall += recall
			sumNdcg += ndcg
			sumShard += float64(shardU)
			sumMerge += float64(mergeU)
			queryUnits = append(queryUnits, queryU)
			applyRollback(qc, &segmentsReady, &indexEpoch, &rollbackEvents)
		}
		pending := cfg.ShardCount - segmentsReady
		if pending > 0 {
			commitN := CoalesceWindow(pending, cfg.BatchWindow)
			for i := 0; i < commitN; i++ {
				pick := (segmentsReady + i) % cfg.ShardCount
				if pick >= 0 && pick < len(segmentCommitHits) {
					segmentCommitHits[pick]++
				}
				segmentsReady++
			}
		}
		if segmentsReady >= cfg.ShardCount {
			indexEpoch++
			segmentsReady = cfg.ShardCount
		}
		idx += n
	}
	starved := 0
	for _, c := range laneHits {
		if c == 0 {
			starved++
		}
	}
	report.StarvedLanes = starved
	report.PeakScratchBytes = ScratchPeak()
	report.IndexEpoch = indexEpoch
	report.SegmentsReady = segmentsReady
	report.RollbackEvents = rollbackEvents
	qn := float64(len(cases))
	if qn > 0 {
		report.MeanRecallAt10 = round4(sumRecall / qn)
		report.MeanNdcgAt10 = round4(sumNdcg / qn)
		report.MeanShardUnits = round4(sumShard / qn)
		report.MeanMergeUnits = round4(sumMerge / qn)
	}
	if ticks > 0 && cfg.BatchWindow > 0 {
		report.MeanBatchEfficiency = round4(sumBatch / float64(ticks) / float64(cfg.BatchWindow))
	}
	report.P95QueryUnits = p95(queryUnits)
	if !meetsFloors(cfg, report) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func applyRollback(qc types.QueryCase, segmentsReady *int, indexEpoch *int, rollbackEvents *int) {
	if !qc.RollbackAfter {
		return
	}
	target := qc.RollbackGeneration
	if target < 0 {
		target = 0
	}
	if *segmentsReady > target {
		*segmentsReady = target
		*rollbackEvents++
		if *indexEpoch > 1 {
			*indexEpoch--
		}
		j3.R3Zero()
	}
}

func meetsFloors(cfg types.ReindexCfg, report types.BenchReport) bool {
	if report.MeanRecallAt10 < cfg.RecallFloor {
		return false
	}
	if report.MeanNdcgAt10 < cfg.NdcgFloor {
		return false
	}
	if int(report.MeanShardUnits) > cfg.MaxMeanShardUnits {
		return false
	}
	if int(report.MeanMergeUnits) > cfg.MaxMeanMergeUnits {
		return false
	}
	if report.P95QueryUnits > cfg.MaxP95QueryUnits {
		return false
	}
	if report.MeanBatchEfficiency < cfg.MinBatchEfficiency {
		return false
	}
	if report.PeakScratchBytes > cfg.MaxPeakScratchBytes {
		return false
	}
	if report.StarvedLanes > cfg.MaxStarvedLanes {
		return false
	}
	if report.SegmentsReady < cfg.MinSegmentsReady {
		return false
	}
	if report.RollbackEvents > cfg.MaxRollbackEvents {
		return false
	}
	return true
}

func rankScores(gold, got []string, k int) (recall float64, ndcg float64, hits int) {
	if len(gold) == 0 {
		return 0, 0, 0
	}
	goldSet := make(map[string]struct{}, len(gold))
	for _, id := range gold {
		goldSet[id] = struct{}{}
	}
	if k <= 0 {
		k = len(got)
	}
	if k > len(got) {
		k = len(got)
	}
	rel := make([]float64, 0, k)
	for i := 0; i < k; i++ {
		if _, ok := goldSet[got[i]]; ok {
			hits++
			rel = append(rel, 1.0)
		} else {
			rel = append(rel, 0.0)
		}
	}
	recall = float64(hits) / float64(len(gold))
	var dcg, idcg float64
	for i, r := range rel {
		if r > 0 {
			dcg += r / math.Log2(float64(i+2))
		}
	}
	sort.Strings(gold)
	ideal := make([]float64, 0, len(gold))
	for i := 0; i < len(gold) && i < k; i++ {
		ideal = append(ideal, 1.0)
	}
	for i, r := range ideal {
		if r > 0 {
			idcg += r / math.Log2(float64(i+2))
		}
	}
	if idcg > 0 {
		ndcg = dcg / idcg
	}
	return recall, ndcg, hits
}

func p95(values []int) int {
	if len(values) == 0 {
		return 0
	}
	cp := append([]int(nil), values...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

type digestPayload struct {
	Status              string           `json:"status"`
	CorpusVectors       int              `json:"corpus_vectors"`
	VectorDim           int              `json:"vector_dim"`
	ShardCount          int              `json:"shard_count"`
	QueriesTotal        int              `json:"queries_total"`
	IndexEpoch          int              `json:"index_epoch"`
	SegmentsReady       int              `json:"segments_ready"`
	RollbackEvents      int              `json:"rollback_events"`
	MeanRecallAt10      float64          `json:"mean_recall_at_10"`
	MeanNdcgAt10        float64          `json:"mean_ndcg_at_10"`
	MeanShardUnits      float64          `json:"mean_shard_units"`
	MeanMergeUnits      float64          `json:"mean_merge_units"`
	MeanBatchEfficiency float64          `json:"mean_batch_efficiency"`
	P95QueryUnits       int              `json:"p95_query_units"`
	PeakScratchBytes    int              `json:"peak_scratch_bytes"`
	StarvedLanes        int              `json:"starved_lanes"`
	ReportDigest        string           `json:"report_digest"`
	Queries             []types.QueryRow `json:"queries"`
}

func digestBody(report types.BenchReport) string {
	payload := digestPayload{
		Status:              report.Status,
		CorpusVectors:       report.CorpusVectors,
		VectorDim:           report.VectorDim,
		ShardCount:          report.ShardCount,
		QueriesTotal:        report.QueriesTotal,
		IndexEpoch:          report.IndexEpoch,
		SegmentsReady:       report.SegmentsReady,
		RollbackEvents:      report.RollbackEvents,
		MeanRecallAt10:      report.MeanRecallAt10,
		MeanNdcgAt10:        report.MeanNdcgAt10,
		MeanShardUnits:      report.MeanShardUnits,
		MeanMergeUnits:      report.MeanMergeUnits,
		MeanBatchEfficiency: report.MeanBatchEfficiency,
		P95QueryUnits:       report.P95QueryUnits,
		PeakScratchBytes:    report.PeakScratchBytes,
		StarvedLanes:        report.StarvedLanes,
		ReportDigest:        "",
		Queries:             report.Queries,
	}
	raw, _ := json.Marshal(payload)
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func WriteReport(path string, report types.BenchReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}
