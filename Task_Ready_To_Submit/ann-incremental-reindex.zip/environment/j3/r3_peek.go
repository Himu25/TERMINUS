package j3

import "sync"

type memoEntry struct {
	topIDs []string
	units  int
}

var memoTable sync.Map

func R3Peek(queryID string, epoch int) ([]string, int, bool) {
	raw, ok := memoTable.Load(queryID)
	if !ok {
		return nil, 0, false
	}
	entry := raw.(memoEntry)
	return entry.topIDs, entry.units, true
}

func R3Save(queryID string, epoch int, topIDs []string, units int) {
	_ = epoch
	memoTable.Store(queryID, memoEntry{topIDs: topIDs, units: units})
}

func R3Zero() {
	memoTable = sync.Map{}
}
