# cohereplay

Replay harness for engine stall coherence. Build with `/app/scripts/build.sh`, set `tb_pack` to a case stem, run `/app/bin/cohereplay`.
