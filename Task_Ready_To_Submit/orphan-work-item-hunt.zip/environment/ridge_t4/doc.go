// ridge_t4 collapses WAL fragments via CGO.

package ridge_t4
