use std::collections::HashMap;
use std::os::raw::c_int;

#[repr(C)]
#[derive(Clone, Copy)]
pub struct WalWire {
	pub job_id: [u8; 64],
	pub wal_seq: i32,
	pub epoch: i32,
	pub label: [u8; 32],
}

#[repr(C)]
pub struct CellOut {
	pub collapsed: i32,
}

fn read_cstr(buf: &[u8]) -> &str {
	let end = buf.iter().position(|&b| b == 0).unwrap_or(buf.len());
	std::str::from_utf8(&buf[..end]).unwrap_or("")
}

fn accreteP(rows: &[WalWire]) -> (Vec<WalWire>, i32) {
	if rows.is_empty() {
		return (Vec::new(), 0);
	}
	let mut out = rows.to_vec();
	let collapsed = (rows.len() as i32) - (out.len() as i32);
	(out, collapsed)
}

#[no_mangle]
pub extern "C" fn rt_fold_rows(rows: *const WalWire, count: c_int) -> CellOut {
	if rows.is_null() || count <= 0 {
		return CellOut { collapsed: 0 };
	}
	let slice = unsafe { std::slice::from_raw_parts(rows, count as usize) };
	let (_kept, collapsed) = accreteP(slice);
	CellOut { collapsed }
}

// rt_materialize rebuilds kept rows into caller buffer — used by Go bridge.
#[no_mangle]
pub extern "C" fn rt_materialize(
	rows: *const WalWire,
	count: c_int,
	out: *mut WalWire,
	out_cap: c_int,
) -> c_int {
	if rows.is_null() || out.is_null() || count <= 0 || out_cap <= 0 {
		return 0;
	}
	let slice = unsafe { std::slice::from_raw_parts(rows, count as usize) };
	let (kept, _) = accreteP(slice);
	let limit = (out_cap as usize).min(kept.len());
	let dst = unsafe { std::slice::from_raw_parts_mut(out, limit) };
	for (i, row) in kept.iter().take(limit).enumerate() {
		dst[i] = *row;
	}
	limit as c_int
}

// rt_truth_map picks winning row per job id from collapsed set.
#[no_mangle]
pub extern "C" fn rt_pick_winners(
	rows: *const WalWire,
	count: c_int,
	out: *mut WalWire,
	out_cap: c_int,
) -> c_int {
	if rows.is_null() || out.is_null() || count <= 0 {
		return 0;
	}
	let slice = unsafe { std::slice::from_raw_parts(rows, count as usize) };
	let (kept, _) = accreteP(slice);
	let mut best: HashMap<String, WalWire> = HashMap::new();
	for row in kept {
		let job = read_cstr(&row.job_id).to_string();
		let cur = best.get(&job);
		let replace = match cur {
			None => true,
			Some(prev) => row.wal_seq > prev.wal_seq
				|| (row.wal_seq == prev.wal_seq && row.epoch >= prev.epoch),
		};
		if replace {
			best.insert(job, row);
		}
	}
	let mut winners: Vec<WalWire> = best.into_values().collect();
	winners.sort_by(|a, b| read_cstr(&a.job_id).cmp(read_cstr(&b.job_id)));
	let limit = (out_cap as usize).min(winners.len());
	let dst = unsafe { std::slice::from_raw_parts_mut(out, limit) };
	for (i, row) in winners.iter().take(limit).enumerate() {
		dst[i] = *row;
	}
	limit as c_int
}
