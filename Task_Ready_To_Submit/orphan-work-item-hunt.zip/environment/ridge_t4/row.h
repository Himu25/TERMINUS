#ifndef ROW_H
#define ROW_H

typedef struct {
	char job_id[64];
	int wal_seq;
	int epoch;
	char label[32];
} WalWire;

typedef struct {
	int collapsed;
} CellOut;

CellOut rt_fold_rows(const WalWire *rows, int count);
int rt_materialize(const WalWire *rows, int count, WalWire *out, int out_cap);
int rt_pick_winners(const WalWire *rows, int count, WalWire *out, int out_cap);

#endif
