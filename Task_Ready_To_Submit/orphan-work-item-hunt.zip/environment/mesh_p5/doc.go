// mesh_p5 handles dependency row normalization during replay.

package mesh_p5
