station readme
