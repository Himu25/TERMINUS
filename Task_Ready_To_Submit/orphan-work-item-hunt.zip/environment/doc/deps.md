# deps

go 1.22, rust 1.81, cgo enabled
