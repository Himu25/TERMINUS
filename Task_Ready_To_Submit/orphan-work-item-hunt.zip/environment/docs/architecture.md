# Replay layout

The replay stack lives under `/app`: a Go driver binary, bundle I/O, span trimming helpers, snapshot merge helpers, and a Rust static library reached through CGO. Case packs under `/app/cases` feed one bundle at a time via `tb_pack`.
