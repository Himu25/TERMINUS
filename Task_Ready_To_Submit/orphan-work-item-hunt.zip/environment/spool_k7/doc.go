// spool_k7 merges checkpoint rows with WAL replay truth.

package spool_k7
