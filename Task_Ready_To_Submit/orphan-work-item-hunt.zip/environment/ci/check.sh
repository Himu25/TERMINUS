#!/bin/bash
set -euo pipefail

test -x /app/bin/cohereplay
test -f /app/go.mod
