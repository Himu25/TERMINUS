hull readme
