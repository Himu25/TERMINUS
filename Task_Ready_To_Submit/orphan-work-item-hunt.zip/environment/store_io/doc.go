// Package store_io loads scenario bundles for cohereplay replay.
package store_io
