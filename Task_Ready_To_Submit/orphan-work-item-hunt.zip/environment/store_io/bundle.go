package store_io

// EdgeRow is one parent-to-child link in the replay graph.
type EdgeRow struct {
	Parent string `json:"parent"`
	Child  string `json:"child"`
}

// WalRow is one WAL or state-store fragment for a unit of work.
type WalRow struct {
	JobID  string `json:"job_id"`
	WalSeq int    `json:"wal_seq"`
	Epoch  int    `json:"epoch"`
	Label  string `json:"label"`
}

// SnapshotRow is a checkpoint row for one unit.
type SnapshotRow struct {
	JobID    string `json:"job_id"`
	CpSeq    int    `json:"cp_seq"`
	Complete bool   `json:"complete"`
}

// Bundle is one scenario pack under /app/cases.
type Bundle struct {
	ScenarioLabel string         `json:"scenario_label"`
	Catalog       []string       `json:"catalog"`
	Edges         []EdgeRow      `json:"edges"`
	Wal           []WalRow       `json:"wal"`
	Snapshots     []SnapshotRow  `json:"snapshots"`
	DetachTags    []string       `json:"detach_tags"`
	StateDb       []WalRow       `json:"state_db"`
}
