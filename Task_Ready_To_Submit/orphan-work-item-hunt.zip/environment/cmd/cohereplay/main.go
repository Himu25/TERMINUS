package main

import (
	"os"

	"axcohere/internal/scope_k2"
)

// cohereplay replays one scenario bundle named by tb_pack.
func main() {
	os.Exit(scope_k2.MainExit())
}
