// scope_k2 drives corrupted engine state into coherence audit counters.

package scope_k2
