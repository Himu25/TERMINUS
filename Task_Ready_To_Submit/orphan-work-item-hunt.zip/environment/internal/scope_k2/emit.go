package scope_k2

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"

	"axcohere/store_io"
)

type auditPayload struct {
	ScenarioRuns []AuditRun `json:"scenario_runs"`
}

// Run loads one pack via tb_pack and writes /app/output/coherence_audit.json.
func Run() error {
	stem := os.Getenv("tb_pack")
	if stem == "" {
		return errors.New("tb_pack must name a stem under /app/cases")
	}
	emit := "/app/output/coherence_audit.json"
	raw, err := os.ReadFile(filepath.Join("/app", "cases", stem+".json"))
	if err != nil {
		return err
	}
	var bundle store_io.Bundle
	if err := json.Unmarshal(raw, &bundle); err != nil {
		return err
	}
	run := opB(bundle)
	out := auditPayload{ScenarioRuns: []AuditRun{run}}
	if err := os.MkdirAll(filepath.Dir(emit), 0o755); err != nil {
		return err
	}
	buf, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		return err
	}
	tmp := emit + ".tmp"
	if err := os.WriteFile(tmp, buf, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, emit)
}

// MainExit is the cmd entry wrapper.
func MainExit() int {
	if err := Run(); err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		return 1
	}
	return 0
}
