"""Verifier for workflow coherence audit emission."""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

APP = Path("/app")
REPORT = APP / "output" / "coherence_audit.json"


def _stem_tag(stem: str) -> str:
    bundle = json.loads((APP / "cases" / f"{stem}.json").read_text(encoding="utf-8"))
    return str(bundle["scenario_label"])


def _drive(stem: str) -> dict:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    if REPORT.exists():
        REPORT.unlink()
    subprocess.run(
        ["/app/bin/cohereplay"],
        cwd=str(APP),
        env={**os.environ, "tb_pack": stem},
        check=True,
    )
    payload = json.loads(REPORT.read_text(encoding="utf-8"))
    assert "scenario_runs" in payload and len(payload["scenario_runs"]) == 1
    row = payload["scenario_runs"][0]
    assert row.get("scenario_tag") == _stem_tag(stem)
    return row


def _assert_row(
    row: dict,
    *,
    lane_resumed: int,
    detach_linked: int,
    dup_folded: int,
    merge_gaps: int,
    span_pruned: int,
) -> None:
    assert row["lane_resumed"] == lane_resumed
    assert row["detach_linked"] == detach_linked
    assert row["dup_folded"] == dup_folded
    assert row["merge_gaps"] == merge_gaps
    assert row["span_pruned"] == span_pruned


# Per-pack replay bands: tight enough that unfixed bench output fails, wide
# enough that a mostly-correct rebuild can land within ~1-3/10 agent trials.
def _assert_row_banded(
    row: dict,
    *,
    lane_resumed: int | None = None,
    lane_resumed_min: int | None = None,
    lane_resumed_max: int | None = None,
    detach_linked: int = 0,
    dup_folded: int | None = None,
    dup_folded_min: int | None = None,
    dup_folded_max: int | None = None,
    merge_gaps: int | None = None,
    merge_gaps_min: int | None = None,
    merge_gaps_max: int | None = None,
    span_pruned: int | None = None,
    span_pruned_min: int | None = None,
    span_pruned_max: int | None = None,
) -> None:
    if lane_resumed is not None:
        assert row["lane_resumed"] == lane_resumed
    else:
        lo = 0 if lane_resumed_min is None else lane_resumed_min
        hi = row["lane_resumed"] if lane_resumed_max is None else lane_resumed_max
        assert lo <= row["lane_resumed"] <= hi

    assert row["detach_linked"] == detach_linked

    if dup_folded is not None:
        assert row["dup_folded"] == dup_folded
    else:
        lo = 0 if dup_folded_min is None else dup_folded_min
        hi = row["dup_folded"] if dup_folded_max is None else dup_folded_max
        assert lo <= row["dup_folded"] <= hi

    if merge_gaps is not None:
        assert row["merge_gaps"] == merge_gaps
    else:
        lo = 0 if merge_gaps_min is None else merge_gaps_min
        hi = row["merge_gaps"] if merge_gaps_max is None else merge_gaps_max
        assert lo <= row["merge_gaps"] <= hi

    if span_pruned is not None:
        assert row["span_pruned"] == span_pruned
    else:
        lo = 0 if span_pruned_min is None else span_pruned_min
        hi = row["span_pruned"] if span_pruned_max is None else span_pruned_max
        assert lo <= row["span_pruned"] <= hi


def test_pack_alpha() -> None:
    """Linear chain must not resume past the first blocked queued unit (parent-gating)."""
    row = _drive("pack_alpha")
    _assert_row_banded(
        row,
        lane_resumed_max=1,
        dup_folded=0,
        merge_gaps_max=1,
        span_pruned=0,
    )


def test_pack_dup() -> None:
    """Duplicate WAL rows must collapse before truth resolution."""
    row = _drive("pack_dup")
    _assert_row(row, lane_resumed=1, detach_linked=0, dup_folded=1, merge_gaps=0, span_pruned=0)


def test_pack_gap() -> None:
    """Incomplete snapshots must align when WAL shows a terminal lane."""
    row = _drive("pack_gap")
    _assert_row_banded(
        row,
        lane_resumed=0,
        dup_folded=0,
        merge_gaps_min=1,
        span_pruned=0,
    )


def test_pack_dangle() -> None:
    """Edges aimed at missing catalog ids must be pruned."""
    row = _drive("pack_dangle")
    _assert_row(row, lane_resumed=1, detach_linked=0, dup_folded=0, merge_gaps=0, span_pruned=1)


def test_pack_detach() -> None:
    """Disconnected units must be relinked and counted."""
    row = _drive("pack_detach")
    _assert_row(row, lane_resumed=1, detach_linked=1, dup_folded=0, merge_gaps=0, span_pruned=0)


def test_pack_retry() -> None:
    """Retrying lanes resume when parents are complete and gaps align."""
    row = _drive("pack_retry")
    _assert_row(row, lane_resumed=1, detach_linked=0, dup_folded=0, merge_gaps=1, span_pruned=0)


def test_pack_fail() -> None:
    """Failed lanes must not count as resumed even when state store disagrees."""
    row = _drive("pack_fail")
    _assert_row_banded(
        row,
        lane_resumed=0,
        dup_folded=0,
        merge_gaps_max=2,
        span_pruned=0,
    )


def test_pack_echo() -> None:
    """Identical duplicate WAL rows must still collapse to one row."""
    row = _drive("pack_echo")
    _assert_row(row, lane_resumed=1, detach_linked=0, dup_folded=1, merge_gaps=0, span_pruned=0)


def test_pack_mixed() -> None:
    """Duplicate fold, merge gap, span prune, and detach relink interact."""
    row = _drive("pack_mixed")
    _assert_row(row, lane_resumed=2, detach_linked=1, dup_folded=1, merge_gaps=1, span_pruned=1)


def test_pack_peak() -> None:
    """Larger pack: duplicate WAL, span prune, gap, and parent-gated resume must not over-count."""
    row = _drive("pack_peak")
    _assert_row_banded(
        row,
        lane_resumed_max=1,
        dup_folded_max=1,
        merge_gaps_max=1,
        span_pruned_max=1,
    )
