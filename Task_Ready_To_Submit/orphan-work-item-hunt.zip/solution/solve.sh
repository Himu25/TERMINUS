#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TASK_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

if [ -f "/app/go.mod" ] && [ -d "/app/mesh_p5" ]; then
  env_dir="/app"
elif [ -d "$TASK_DIR/environment" ]; then
  env_dir="$TASK_DIR/environment"
elif [ -d "/environment" ] && [ -f "/environment/go.mod" ]; then
  env_dir="/environment"
else
  echo "Could not locate task environment layout." >&2
  exit 1
fi

cd "$SCRIPT_DIR"
patch -p1 --forward -d "$env_dir" <fixes.patch

bash "$env_dir/scripts/build.sh"

if [ ! -x "$env_dir/bin/cohereplay" ]; then
  echo "cohereplay binary missing after rebuild" >&2
  exit 1
fi

for probe in \
  pack_alpha pack_dup pack_gap pack_dangle pack_detach \
  pack_retry pack_fail pack_echo pack_mixed pack_peak
do
  rm -f "$env_dir/output/coherence_audit.json"
  (
    cd "$env_dir"
    export tb_pack="$probe"
    ./bin/cohereplay >/dev/null
  )
  python3 - "$env_dir" "$probe" <<'PY'
import json
import sys

env_dir, probe = sys.argv[1], sys.argv[2]
with open(f"{env_dir}/output/coherence_audit.json", encoding="utf-8") as fh:
    audit = json.load(fh)
runs = audit.get("scenario_runs")
assert isinstance(runs, list) and len(runs) == 1, f"{probe}: scenario_runs must be a single-entry array"
row = runs[0]
with open(f"{env_dir}/cases/{probe}.json", encoding="utf-8") as fh:
    bundle = json.load(fh)
assert row.get("scenario_tag") == bundle["scenario_label"], f"{probe}: scenario_tag mismatch"
for key in ("lane_resumed", "detach_linked", "dup_folded", "merge_gaps", "span_pruned"):
    value = row.get(key)
    assert isinstance(value, int) and value >= 0, f"{probe}: {key} must be a non-negative integer"
PY
done

echo "Oracle rebuilt cohereplay and validated all ten scenario bundles."
