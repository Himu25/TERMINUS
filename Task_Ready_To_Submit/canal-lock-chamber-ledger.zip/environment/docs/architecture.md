Canal lock transit replay ties together a Go transit ledger, Rust level integrator, and bash runners under `/app`.
The driver reads transit manifests from `/app/data`, level-band profiles, and level logs before emitting the transit report.
