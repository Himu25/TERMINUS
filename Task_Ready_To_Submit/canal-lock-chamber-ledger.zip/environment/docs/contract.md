# Transit report contract

Top-level fields:
- status: ok when all canal.toml guardrails pass, else fail
- basin_capacity_m3: total basin volume budget for the replay window
- volume_allocated_m3: billable volume consumed by finished transits
- volume_slack_m3: reservation surplus summed across transits
- transits_total: input JSONL row count
- transits_finished: transits marked served
- coverage_rate: transits_finished / transits_total
- slack_ratio: volume_slack_m3 / volume_allocated_m3 when allocated > 0
- chamber_violations: chamber dependency faults
- priority_inversions: scheduling-order faults among finished transits
- convoy_buffer_m3: convoy wave buffer volume absorbed
- tonnage_score: weighted priority score total for finished transits
- report_digest: SHA-256 hex of compact pre-digest JSON with report_digest empty
- transits: per-transit rows

Per-transit row fields: transit_id, cluster, urgency, reserve_m3, processed_m3, slack_m3, served, chamber_ready, transit_rank, convoy_wave, tonnage_score.
