package summ

import "clk.canal/pkg/types"

// SxFold folds transit rows for telemetry export (non-scheduling).
func SxFold(rows []types.TransitRow) int {
	total := 0
	for _, row := range rows {
		total += row.ProcessedM3
	}
	return total
}
