Shared daily basin-volume budget for inbound lock transits. Default manifest rows live in `/app/data/transit_manifest.jsonl`. See `/app/docs/architecture.md`.
