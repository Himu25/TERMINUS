module clk.canal

go 1.22
