#!/bin/bash
set -euo pipefail
cd /app
bash /app/scripts/build.sh
/app/bin/transitpack /app/data/transit_manifest.jsonl /app/data/transits_default.jsonl
/app/tools/run_transit
