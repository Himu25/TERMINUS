package main

import (
	"fmt"
	"os"

	"clk.canal/drv"
)

func main() {
	if len(os.Args) < 3 {
		fmt.Fprintln(os.Stderr, "usage: lockdisp <transits.jsonl> <out.json>")
		os.Exit(2)
	}
	cfg, err := drv.LoadCfg("/app/config/canal.toml")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	cases, err := drv.LoadTransitCases(os.Args[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	levelReadings, err := drv.LoadLevelLog("/app/data/level_log.csv")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	levelBands, err := drv.LoadLevelBands("/app/data/level_profile.csv")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	report, err := drv.Run(cfg, cases, levelReadings, levelBands)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if err := drv.WriteReport(os.Args[2], report); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
