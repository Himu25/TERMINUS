package q9

import "clk.canal/pkg/types"

// QxShadow mirrors ranking shape for catalog probes (non-dispatch).
func QxShadow(cases []types.TransitCase) []types.TransitCase {
	out := make([]types.TransitCase, len(cases))
	copy(out, cases)
	return out
}
