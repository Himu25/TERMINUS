package q9

import (
	"sort"

	"clk.canal/pkg/types"
)

// RxOrder ranks pending transits for canal lock dispatch.
func RxOrder(cases []types.TransitCase) []types.TransitCase {
	out := make([]types.TransitCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		return out[i].EstM3 < out[j].EstM3
	})
	return out
}
