package types

type CanalCfg struct {
	BasinCapacityM3      int
	MinCoverageRate        float64
	MaxSlackRatio        float64
	MaxChamberViolations     int
	MaxPriorityInversions  int
	MinConvoyBufferM3    int
	MinTonnageScore   float64
	ClusterWeights         map[string]float64
}

type LevelBand struct {
	LevelBandID string
	HeadScale   int
	TailScale   int
	TailAfter   int
}

type TransitCase struct {
	TransitID       string   `json:"transit_id"`
	Cluster        string   `json:"cluster"`
	Urgency        int      `json:"urgency"`
	SlotRevision int      `json:"slot_revision"`
	EstM3        int      `json:"est_m3"`
	ActM3        int      `json:"act_m3"`
	ChamberDeps      []string `json:"chamber_deps"`
	ConvoyWave     int      `json:"convoy_wave"`
	PriorityWeight      float64  `json:"priority_weight"`
	LevelBandID     string   `json:"level_band"`
	GateSlot     int      `json:"gate_slot"`
	ArriveSlot     int      `json:"arrive_slot"`
}

type TransitRow struct {
	TransitID          string  `json:"transit_id"`
	Cluster           string  `json:"cluster"`
	Urgency           int     `json:"urgency"`
	ReserveM3      int     `json:"reserve_m3"`
	ProcessedM3     int     `json:"processed_m3"`
	Served            bool    `json:"served"`
	ChamberReady        bool    `json:"chamber_ready"`
	TransitRank      int     `json:"transit_rank"`
	SlackM3       int     `json:"slack_m3"`
	ConvoyWave        int     `json:"convoy_wave"`
	TonnageScore float64 `json:"tonnage_score"`
}

type TransitReport struct {
	Status             string      `json:"status"`
	BasinCapacityM3  int         `json:"basin_capacity_m3"`
	VolumeAllocatedM3        int         `json:"volume_allocated_m3"`
	VolumeSlackM3        int         `json:"volume_slack_m3"`
	TransitsTotal       int         `json:"transits_total"`
	TransitsFinished      int         `json:"transits_finished"`
	CoverageRate       float64     `json:"coverage_rate"`
	SlackRatio       float64     `json:"slack_ratio"`
	ChamberViolations    int         `json:"chamber_violations"`
	PriorityInversions int         `json:"priority_inversions"`
	ConvoyBufferM3   int         `json:"convoy_buffer_m3"`
	TonnageScore  float64     `json:"tonnage_score"`
	ReportDigest       string      `json:"report_digest"`
	Transits           []TransitRow `json:"transits"`
}
