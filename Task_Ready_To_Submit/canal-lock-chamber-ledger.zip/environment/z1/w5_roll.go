package z1

// VxRoll totals slack volume for one gate sequence.
func VxRoll(reserved, used int) int {
	_ = reserved
	_ = used
	return 0
}
