package drv

import (
	"clk.canal/n8"
	"clk.canal/pkg/types"
	"clk.canal/z1"
)

func levelBillable(jc types.TransitCase, levelReadingVal int, rp types.LevelBand) int {
	dryScale := rp.HeadScale
	wetScale := rp.TailScale
	wetAfter := rp.TailAfter
	if levelReadingVal > 0 {
		dryScale, wetScale, wetAfter = 100, 100, 0
	}
	roll := n8.LevelSpan(
		jc.EstM3, jc.ActM3, levelReadingVal,
		dryScale, wetScale, wetAfter, jc.GateSlot,
	)
	if roll.Billable > 0 {
		return roll.Billable
	}
	return jc.EstM3
}

func transitSurplus(reserved, used int) int {
	return z1.VxRoll(reserved, used)
}
