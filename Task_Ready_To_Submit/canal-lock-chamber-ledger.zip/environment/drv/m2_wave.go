package drv

import "clk.canal/h4"

func convoyDispatchTotal(dispatchWave, estTons, headroom int) int {
	if dispatchWave <= 0 {
		return 0
	}
	return h4.UxAbsorb(estTons/4, headroom)
}
