package drv

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"

	"clk.canal/k2"
	"clk.canal/pkg/types"
	"clk.canal/q9"
	"clk.canal/summ"
	"clk.canal/u3"
)

func LoadCfg(path string) (types.CanalCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.CanalCfg{}, err
	}
	cfg := types.CanalCfg{
		BasinCapacityM3:     12000,
		MinCoverageRate:     0.75,
		MaxSlackRatio:         0.35,
		MaxChamberViolations:      0,
		MaxPriorityInversions: 1,
		MinConvoyBufferM3:      3,
		MinTonnageScore:     2.0,
		ClusterWeights:           map[string]float64{"cluster_alpha": 1.0, "cluster_beta": 1.0, "cluster_gamma": 1.0},
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "basin_capacity_m3":
			fmt.Sscanf(val, "%d", &cfg.BasinCapacityM3)
		case "min_coverage_rate":
			fmt.Sscanf(val, "%f", &cfg.MinCoverageRate)
		case "max_slack_ratio":
			fmt.Sscanf(val, "%f", &cfg.MaxSlackRatio)
		case "max_chamber_violations":
			fmt.Sscanf(val, "%d", &cfg.MaxChamberViolations)
		case "max_priority_inversions":
			fmt.Sscanf(val, "%d", &cfg.MaxPriorityInversions)
		case "min_convoy_buffer_m3":
			fmt.Sscanf(val, "%d", &cfg.MinConvoyBufferM3)
		case "min_tonnage_score":
			fmt.Sscanf(val, "%f", &cfg.MinTonnageScore)
		case "cluster_weight_alpha":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClusterWeights["cluster_alpha"] = w
		case "cluster_weight_beta":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClusterWeights["cluster_beta"] = w
		case "cluster_weight_gamma":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClusterWeights["cluster_gamma"] = w
		}
	}
	return cfg, nil
}

func LoadLevelBands(path string) (map[string]types.LevelBand, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]types.LevelBand)
	for i, row := range rows {
		if i == 0 || len(row) < 4 {
			continue
		}
		var peak, renew, after int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &peak)
		fmt.Sscanf(strings.TrimSpace(row[2]), "%d", &renew)
		fmt.Sscanf(strings.TrimSpace(row[3]), "%d", &after)
		id := strings.TrimSpace(row[0])
		out[id] = types.LevelBand{
			LevelBandID: id,
			HeadScale:  peak,
			TailScale: renew,
			TailAfter: after,
		}
	}
	return out, nil
}

func LoadTransitCases(path string) ([]types.TransitCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.TransitCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var jc types.TransitCase
		if err := json.Unmarshal([]byte(line), &jc); err != nil {
			return nil, err
		}
		if jc.LevelBandID == "" {
			jc.LevelBandID = "lower_pool"
		}
		out = append(out, jc)
	}
	return out, sc.Err()
}

func LoadLevelLog(path string) (map[string]int, error) {
	f, err := os.Open(path)
	if err != nil {
		return map[string]int{}, nil
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]int)
	for i, row := range rows {
		if i == 0 || len(row) < 2 {
			continue
		}
		var actTons int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &actTons)
		out[strings.TrimSpace(row[0])] = actTons
	}
	return out, nil
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

func levelBandFor(jc types.TransitCase, levelBands map[string]types.LevelBand) types.LevelBand {
	if rp, ok := levelBands[jc.LevelBandID]; ok {
		return rp
	}
	return types.LevelBand{LevelBandID: jc.LevelBandID, HeadScale: 100, TailScale: 100, TailAfter: 0}
}

func Run(cfg types.CanalCfg, cases []types.TransitCase, levelReadings map[string]int, levelBands map[string]types.LevelBand) (types.TransitReport, error) {
	ordered := q9.RxOrder(cases)
	report := types.TransitReport{
		Status:            "ok",
		BasinCapacityM3: cfg.BasinCapacityM3,
		TransitsTotal:         len(ordered),
	}
	done := make(map[string]bool)
	budgetLeft := cfg.BasinCapacityM3
	var spent, totalWaste, completed, depViol, inversions, renewTotal int
	var valueTotal float64
	prevRank := -1
	report.Transits = make([]types.TransitRow, 0, len(ordered))

	for idx, jc := range ordered {
		actualReady := true
		for _, depID := range jc.ChamberDeps {
			if !done[depID] {
				actualReady = false
				break
			}
		}
		depReady := k2.TxHold(jc.ChamberDeps, done)
		if len(jc.ChamberDeps) > 0 && !actualReady && depReady {
			depViol++
		}
		levelReadingVal := 0
		if act, ok := levelReadings[jc.TransitID]; ok && act > 0 {
			levelReadingVal = act
			jc.ActM3 = act
		}
		rp := levelBandFor(jc, levelBands)
		billable := levelBillable(jc, levelReadingVal, rp)
		reserveNeed := u3.AxNeed(jc.EstM3, billable)
		reserved, ok := u3.BxReserve(budgetLeft, reserveNeed)
		headroom := budgetLeft - reserved
		if jc.ConvoyWave > 0 {
			renewTotal += convoyDispatchTotal(jc.ConvoyWave, jc.EstM3, headroom)
		}
		used := 0
		finished := false
		if ok && depReady {
			used = jc.ActM3
			if used <= 0 {
				used = billable
			}
			if used > reserved {
				used = reserved
			}
			budgetLeft -= reserved
			spent += used
			finished = true
			completed++
			done[jc.TransitID] = true
			valueTotal += u3.VxValue(jc.PriorityWeight, used)
		}
		wasteAmt := transitSurplus(reserved, used)
		totalWaste += wasteAmt
		rankScore := jc.SlotRevision*10 + jc.Urgency
		if finished {
			if prevRank >= 0 && rankScore > prevRank {
				inversions++
			}
			prevRank = rankScore
		}
		row := types.TransitRow{
			TransitID:          jc.TransitID,
			Cluster:           jc.Cluster,
			Urgency:       jc.Urgency,
			ReserveM3:  reserved,
			ProcessedM3:      used,
			Served:      finished,
			ChamberReady:       depReady,
			TransitRank:   idx + 1,
			SlackM3:     wasteAmt,
			ConvoyWave:      jc.ConvoyWave,
			TonnageScore: round4(u3.VxValue(jc.PriorityWeight, used)),
		}
		report.Transits = append(report.Transits, row)
	}

	report.VolumeAllocatedM3 = spent
	report.VolumeSlackM3 = totalWaste
	report.TransitsFinished = completed
	if report.TransitsTotal > 0 {
		report.CoverageRate = round4(float64(completed) / float64(report.TransitsTotal))
	}
	if spent > 0 {
		report.SlackRatio = round4(float64(totalWaste) / float64(spent))
	}
	report.ChamberViolations = depViol
	report.PriorityInversions = inversions
	report.ConvoyBufferM3 = renewTotal
	report.TonnageScore = round4(valueTotal)
	hasDispatch := false
	for _, jc := range ordered {
		if jc.ConvoyWave > 0 {
			hasDispatch = true
			break
		}
	}
	if !meetsFloors(cfg, report, hasDispatch) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func meetsFloors(cfg types.CanalCfg, report types.TransitReport, hasDispatch bool) bool {
	if report.CoverageRate < cfg.MinCoverageRate {
		return false
	}
	if report.SlackRatio > cfg.MaxSlackRatio {
		return false
	}
	if report.ChamberViolations > cfg.MaxChamberViolations {
		return false
	}
	if report.PriorityInversions > cfg.MaxPriorityInversions {
		return false
	}
	if report.ConvoyBufferM3 < cfg.MinConvoyBufferM3 {
		if hasDispatch {
			return false
		}
	}
	if report.TonnageScore < cfg.MinTonnageScore {
		return false
	}
	for _, row := range report.Transits {
		if strings.HasPrefix(row.TransitID, "t_chamber_") && !row.ChamberReady && row.Served {
			return false
		}
		if strings.HasPrefix(row.TransitID, "t_gate_") && row.ConvoyWave > 0 && !row.Served {
			return false
		}
		if strings.HasPrefix(row.TransitID, "t_level_") && row.SlackM3 == 0 && row.ReserveM3 > row.ProcessedM3+50 {
			return false
		}
		if strings.HasPrefix(row.TransitID, "t_band_") && row.Served && row.ProcessedM3 > row.ReserveM3+200 {
			return false
		}
	}
	_ = summ.SxFold(report.Transits)
	return true
}

type digestPayload struct {
	Status              string         `json:"status"`
	BasinCapacityM3   int            `json:"basin_capacity_m3"`
	VolumeAllocatedM3          int            `json:"volume_allocated_m3"`
	VolumeSlackM3          int            `json:"volume_slack_m3"`
	TransitsTotal           int            `json:"transits_total"`
	TransitsFinished       int            `json:"transits_finished"`
	CoverageRate      float64        `json:"coverage_rate"`
	SlackRatio          float64        `json:"slack_ratio"`
	ChamberViolations       int            `json:"chamber_violations"`
	PriorityInversions  int            `json:"priority_inversions"`
	ConvoyBufferM3    int            `json:"convoy_buffer_m3"`
	TonnageScore   float64        `json:"tonnage_score"`
	ReportDigest        string         `json:"report_digest"`
	Transits            []types.TransitRow `json:"transits"`
}

func digestBody(report types.TransitReport) string {
	payload := digestPayload{
		Status:              report.Status,
		BasinCapacityM3:   report.BasinCapacityM3,
		VolumeAllocatedM3:         report.VolumeAllocatedM3,
		VolumeSlackM3:         report.VolumeSlackM3,
		TransitsTotal:        report.TransitsTotal,
		TransitsFinished:       report.TransitsFinished,
		CoverageRate:        report.CoverageRate,
		SlackRatio:        report.SlackRatio,
		ChamberViolations:     report.ChamberViolations,
		PriorityInversions:  report.PriorityInversions,
		ConvoyBufferM3:    report.ConvoyBufferM3,
		TonnageScore:   report.TonnageScore,
		ReportDigest:        "",
		Transits:            report.Transits,
	}
	raw, err := marshalDigestJSON(payload)
	if err != nil {
		return ""
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func marshalDigestJSON(payload digestPayload) ([]byte, error) {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return nil, err
	}
	b := buf.Bytes()
	if n := len(b); n > 0 && b[n-1] == '\n' {
		b = b[:n-1]
	}
	return b, nil
}

func WriteReport(path string, report types.TransitReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func p95(values []int) int {
	if len(values) == 0 {
		return 0
	}
	cp := append([]int(nil), values...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}
