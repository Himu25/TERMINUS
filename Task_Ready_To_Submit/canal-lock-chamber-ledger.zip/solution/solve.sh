#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/canal.toml
require_file /app/data/transit_manifest.jsonl
require_file /app/data/level_profile.csv
require_file /app/data/level_log.csv
mkdir -p /app/bin /app/output

log "apply patched sources"
cp "${ROOT_DIR}/oracle/p2_order.go" /app/q9/p2_order.go
cp "${ROOT_DIR}/oracle/d4_hold.go" /app/k2/d4_hold.go
cp "${ROOT_DIR}/oracle/b7_slot.go" /app/h4/b7_slot.go
cp "${ROOT_DIR}/oracle/w5_roll.go" /app/z1/w5_roll.go
cp "${ROOT_DIR}/oracle/lib.rs" /app/n8/src/lib.rs

log "rebuild dispatcher"
bash /app/scripts/build.sh

log "refresh default transit bundle"
/app/bin/transitpack /app/data/transit_manifest.jsonl /app/data/transits_default.jsonl

log "emit default transit report"
/app/tools/run_transit

log "post-run validation against canal.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/canal.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k in ("min_coverage_rate", "max_slack_ratio", "min_tonnage_score"):
        cfg[k] = float(v)
    elif k.startswith("max_") or k.startswith("min_") or k == "basin_capacity_m3":
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/transit_report.json").read_text())
assert report["status"] == "ok", report
assert report["coverage_rate"] >= cfg["min_coverage_rate"]
assert report["slack_ratio"] <= cfg["max_slack_ratio"]
assert report["chamber_violations"] <= cfg["max_chamber_violations"]
assert report["priority_inversions"] <= cfg["max_priority_inversions"]
assert report["convoy_buffer_m3"] >= cfg["min_convoy_buffer_m3"]
assert report["tonnage_score"] >= cfg["min_tonnage_score"]
for row in report["transits"]:
    if row["transit_id"].startswith("t_chamber_") and row["served"]:
        assert row["chamber_ready"], row
    if row["transit_id"].startswith("t_gate_"):
        assert row["served"], row
print("ok", report["coverage_rate"], report["slack_ratio"], report["tonnage_score"])
PY

log "oracle complete"
