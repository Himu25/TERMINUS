package h4

// UxAbsorb counts convoy buffer volume absorbed from spare headroom.
func UxAbsorb(burstNeed, headroom int) int {
	if burstNeed <= 0 || headroom <= 0 {
		return 0
	}
	if burstNeed > headroom {
		return headroom
	}
	return burstNeed
}
