package q9

import (
	"sort"

	"clk.canal/pkg/types"
)

// RxOrder ranks pending transits for canal lock dispatch.
func RxOrder(cases []types.TransitCase) []types.TransitCase {
	out := make([]types.TransitCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		a, b := out[i], out[j]
		if a.SlotRevision != b.SlotRevision {
			return a.SlotRevision > b.SlotRevision
		}
		if a.Urgency != b.Urgency {
			return a.Urgency > b.Urgency
		}
		if a.PriorityWeight != b.PriorityWeight {
			return a.PriorityWeight > b.PriorityWeight
		}
		return a.TransitID < b.TransitID
	})
	return out
}
