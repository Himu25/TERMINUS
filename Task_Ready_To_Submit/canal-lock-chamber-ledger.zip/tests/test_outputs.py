"""Validate /app/output/transit_report.json against canal.toml guardrails."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "transit_report.json"
TRANSITS = APP / "data" / "transits_default.jsonl"
CFG = APP / "config" / "canal.toml"
LEVEL_LOG = APP / "data" / "level_log.csv"
CASES = Path(__file__).resolve().parent / "data"

_DEFAULT_TRANSITS_TEXT = TRANSITS.read_text(encoding="utf-8") if TRANSITS.is_file() else ""

REPORT_KEYS = frozenset(
    {
        "status",
        "basin_capacity_m3",
        "volume_allocated_m3",
        "volume_slack_m3",
        "transits_total",
        "transits_finished",
        "coverage_rate",
        "slack_ratio",
        "chamber_violations",
        "priority_inversions",
        "convoy_buffer_m3",
        "tonnage_score",
        "report_digest",
        "transits",
    }
)
ROW_KEYS = frozenset(
    {
        "transit_id",
        "cluster",
        "urgency",
        "reserve_m3",
        "processed_m3",
        "slack_m3",
        "served",
        "chamber_ready",
        "transit_rank",
        "convoy_wave",
        "tonnage_score",
    }
)

# LevelBand bill bands: tight enough that peak-only metering fails, wide enough that
# a mostly-correct meter rebuild can land within ~1-3/10 agent trials.
_LEVEL_BLEND_NUM = 86
_LEVEL_BLEND_DEN = 100


def _level_band_bill_max(transits_text: str) -> int:
    raw = _transit_map_from_text(transits_text)["t_band_us"]["act_m3"]
    return (raw * _LEVEL_BLEND_NUM) // _LEVEL_BLEND_DEN


def _assert_level_band_blend(report: dict, transits_text: str, *, require_status: bool) -> None:
    bill_max = _level_band_bill_max(transits_text)
    us = next(r for r in report["transits"] if r["transit_id"] == "t_band_us")
    eu = next(r for r in report["transits"] if r["transit_id"] == "t_band_eu")
    assert us["served"] and eu["served"]
    assert us["reserve_m3"] <= bill_max, us
    assert eu["reserve_m3"] <= bill_max, eu
    assert eu["reserve_m3"] < us["reserve_m3"], (us, eu)
    assert eu["processed_m3"] < us["processed_m3"], (us, eu)
    if require_status:
        assert report["status"] == "ok"


def _load_level_logs() -> dict[str, int]:
    level_logs: dict[str, int] = {}
    if not LEVEL_LOG.is_file():
        return level_logs
    lines = LEVEL_LOG.read_text(encoding="utf-8").splitlines()
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        transit_id, act_m3 = (part.strip() for part in line.split(",", 1))
        level_logs[transit_id] = int(act_m3)
    return level_logs


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "basin_capacity_m3": 12000,
        "min_coverage_rate": 0.75,
        "max_slack_ratio": 0.35,
        "max_chamber_violations": 0,
        "max_priority_inversions": 1,
        "min_convoy_buffer_m3": 3,
        "min_tonnage_score": 2.0,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in ("min_coverage_rate", "max_slack_ratio", "min_tonnage_score"):
            cfg[key] = float(val)
        elif key in (
            "basin_capacity_m3",
            "max_chamber_violations",
            "max_priority_inversions",
            "min_convoy_buffer_m3",
        ):
            cfg[key] = int(float(val))
    return cfg


def _transit_rows_from_text(text: str) -> list[dict]:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def _transit_ids_from_text(text: str) -> list[str]:
    return [row["transit_id"] for row in _transit_rows_from_text(text)]


def _transit_map_from_text(text: str) -> dict[str, dict]:
    return {row["transit_id"]: row for row in _transit_rows_from_text(text)}


def _assert_transits_match_input(report: dict, transits_text: str) -> None:
    expected_ids = _transit_ids_from_text(transits_text)
    report_ids = [row["transit_id"] for row in report["transits"]]
    assert report["transits_total"] == len(expected_ids)
    assert len(report_ids) == len(expected_ids)
    assert set(report_ids) == set(expected_ids)


@pytest.fixture(autouse=True)
def restore_default_transits() -> None:
    yield
    if _DEFAULT_TRANSITS_TEXT:
        _atomic_write_text(TRANSITS, _DEFAULT_TRANSITS_TEXT)


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _swap_fixture(stem: str) -> str:
    src = CASES / f"{stem}.jsonl"
    text = src.read_text(encoding="utf-8")
    _atomic_write_text(TRANSITS, text)
    return text


def _expected_digest(report: dict) -> str:
    payload = dict(report)
    payload["report_digest"] = ""
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _invoke_default() -> None:
    proc = subprocess.run(
        ["/app/tools/run_transit"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "transit_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    _invoke_default()


def test_report_top_level_keys_exact() -> None:
    """Report must expose only the documented top-level keys."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS


def test_transit_row_schema() -> None:
    """Each transit row must match the documented per-transit schema."""
    report = _load_report()
    assert report["transits"]
    for row in report["transits"]:
        assert set(row.keys()) == ROW_KEYS
        assert isinstance(row["transit_id"], str) and row["transit_id"]
        assert isinstance(row["cluster"], str) and row["cluster"]
        assert isinstance(row["urgency"], int)
        assert row["reserve_m3"] >= 0
        assert row["processed_m3"] >= 0
        assert row["slack_m3"] >= 0
        assert isinstance(row["served"], bool)
        assert isinstance(row["chamber_ready"], bool)
        assert row["transit_rank"] >= 1
        assert row["convoy_wave"] >= 0
        assert row["tonnage_score"] >= 0.0


def test_passing_run_contract() -> None:
    """Default bundle must finish ok and meet canal.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["basin_capacity_m3"] == cfg["basin_capacity_m3"]
    _assert_transits_match_input(report, _DEFAULT_TRANSITS_TEXT)
    assert report["coverage_rate"] >= cfg["min_coverage_rate"]
    assert report["slack_ratio"] <= cfg["max_slack_ratio"]
    assert report["chamber_violations"] <= cfg["max_chamber_violations"]
    assert report["priority_inversions"] <= cfg["max_priority_inversions"]
    assert report["convoy_buffer_m3"] >= cfg["min_convoy_buffer_m3"]
    assert report["tonnage_score"] >= cfg["min_tonnage_score"]


def test_transits_total_matches_input_rows() -> None:
    """Report transit IDs must cover every input JSONL row with no drops or extras."""
    report = _load_report()
    _assert_transits_match_input(report, _DEFAULT_TRANSITS_TEXT)


def test_report_digest_matches_payload() -> None:
    """report_digest must hash the compact pre-digest JSON payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_deterministic_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_dep_rows_finish_in_order() -> None:
    """Dependency chain rows must complete only after prerequisites."""
    report = _load_report()
    ranks = {row["transit_id"]: row["transit_rank"] for row in report["transits"]}
    assert ranks["t_chamber_root"] < ranks["t_chamber_leaf"] < ranks["t_chamber_chain"]
    for row in report["transits"]:
        if row["transit_id"].startswith("t_chamber_") and row["served"]:
            assert row["chamber_ready"] is True, row


def test_prio_hot_ranks_before_cold() -> None:
    """Late priority revision rows must finish before stale low-revision peers."""
    report = _load_report()
    hot = next(r for r in report["transits"] if r["transit_id"] == "t_convoy_hot")
    cold = next(r for r in report["transits"] if r["transit_id"] == "t_convoy_cold")
    assert hot["served"] is True
    assert cold["served"] is True
    assert hot["transit_rank"] < cold["transit_rank"], (hot, cold)


def test_drift_accounting_semantics() -> None:
    """Drift rows reserve estimates, bill actuals, and record reserved minus used."""
    report = _load_report()
    inputs = _transit_map_from_text(_DEFAULT_TRANSITS_TEXT)
    level_logs = _load_level_logs()
    for row in report["transits"]:
        if not row["transit_id"].startswith("t_level_") or not row["served"]:
            continue
        spec = inputs[row["transit_id"]]
        expected_used = level_logs.get(row["transit_id"], spec["act_m3"])
        assert row["reserve_m3"] == spec["est_m3"]
        assert row["processed_m3"] == expected_used
        assert row["slack_m3"] == max(0, row["reserve_m3"] - row["processed_m3"])


def test_drift_rows_record_waste() -> None:
    """Drift-prone rows with inflated reservations must record slack_m3."""
    report = _load_report()
    drift_rows = [r for r in report["transits"] if r["transit_id"].startswith("t_level_")]
    assert drift_rows
    assert any(r["slack_m3"] > 0 for r in drift_rows if r["served"])


def test_burst_rows_complete() -> None:
    """Dispatch-wave rows with the t_gate_ prefix must complete under the default bundle."""
    report = _load_report()
    burst_rows = [r for r in report["transits"] if r["transit_id"].startswith("t_gate_")]
    assert burst_rows
    assert all(r["served"] for r in burst_rows), burst_rows


def test_transit_rows_respect_intensity() -> None:
    """Level-band rows must bill through blended intensity, not raw estimates alone."""
    _invoke_default()
    report = _load_report()
    bill_max = _level_band_bill_max(_DEFAULT_TRANSITS_TEXT)
    us = next(r for r in report["transits"] if r["transit_id"] == "t_band_us")
    eu = next(r for r in report["transits"] if r["transit_id"] == "t_band_eu")
    assert us["served"] and eu["served"]
    assert us["reserve_m3"] <= bill_max, us
    assert eu["reserve_m3"] <= bill_max, eu
    assert eu["reserve_m3"] < us["reserve_m3"], (us, eu)


def test_renew_late_row_completes() -> None:
    """Delayed dispatch-wave row j_renew_late must complete under the default bundle."""
    report = _load_report()
    renew = next(r for r in report["transits"] if r["transit_id"] == "j_renew_late")
    assert renew["served"] is True
    assert renew["convoy_wave"] > 0


def test_scenario_dep_chain() -> None:
    """Dependency-chain scenario must schedule deps before dependents."""
    transits_text = _swap_fixture("dep_chain")
    _invoke_default()
    report = _load_report()
    _assert_transits_match_input(report, transits_text)
    assert report["chamber_violations"] == 0
    assert report["status"] == "ok"
    ranks = {row["transit_id"]: row["transit_rank"] for row in report["transits"]}
    assert ranks["t_chamber_root"] < ranks["t_chamber_leaf"] < ranks["t_chamber_chain"]


def test_scenario_urgency_flip() -> None:
    """Urgency-flip scenario must schedule late revisions ahead of stale peers."""
    cfg = _parse_cfg()
    transits_text = _swap_fixture("urgency_flip")
    _invoke_default()
    report = _load_report()
    _assert_transits_match_input(report, transits_text)
    hot = next(r for r in report["transits"] if r["transit_id"] == "t_convoy_hot")
    cold = next(r for r in report["transits"] if r["transit_id"] == "t_convoy_cold")
    assert hot["transit_rank"] < cold["transit_rank"]
    assert report["priority_inversions"] <= cfg["max_priority_inversions"]
    assert report["status"] == "ok"


def test_scenario_est_drift() -> None:
    """Estimate-drift scenario must keep slack_ratio under max_slack_ratio."""
    cfg = _parse_cfg()
    transits_text = _swap_fixture("est_drift")
    _invoke_default()
    report = _load_report()
    _assert_transits_match_input(report, transits_text)
    inputs = _transit_map_from_text(transits_text)
    for row in report["transits"]:
        if not row["transit_id"].startswith("t_level_") or not row["served"]:
            continue
        spec = inputs[row["transit_id"]]
        assert row["reserve_m3"] == spec["est_m3"]
        assert row["slack_m3"] == max(0, row["reserve_m3"] - row["processed_m3"])
        assert row["slack_m3"] > 0
    assert report["slack_ratio"] <= cfg["max_slack_ratio"]
    assert report["status"] == "ok"


def test_scenario_burst_cluster() -> None:
    """Dispatch-cluster scenario must absorb enough dispatch buffer headroom."""
    cfg = _parse_cfg()
    transits_text = _swap_fixture("burst_cluster")
    _invoke_default()
    report = _load_report()
    _assert_transits_match_input(report, transits_text)
    burst_rows = [r for r in report["transits"] if r["transit_id"].startswith("t_gate_")]
    assert burst_rows
    assert all(r["served"] for r in burst_rows)
    assert report["convoy_buffer_m3"] >= cfg["min_convoy_buffer_m3"]
    assert report["status"] == "ok"


def test_scenario_value_mix() -> None:
    """Need-score mix scenario must meet tonnage_score floor."""
    cfg = _parse_cfg()
    transits_text = _swap_fixture("value_mix")
    _invoke_default()
    report = _load_report()
    _assert_transits_match_input(report, transits_text)
    assert report["tonnage_score"] >= cfg["min_tonnage_score"]


def test_scenario_level_meter() -> None:
    """Zero-estimate level-log row must bill act_m3 through the meter."""
    transits_text = _swap_fixture("level_meter")
    _invoke_default()
    report = _load_report()
    _assert_transits_match_input(report, transits_text)
    level_logs = _load_level_logs()
    expected_used = level_logs["t_band_meter"]
    row = next(r for r in report["transits"] if r["transit_id"] == "t_band_meter")
    assert row["served"] is True
    assert row["processed_m3"] == expected_used
    assert row["reserve_m3"] == expected_used
    assert row["slack_m3"] == 0


def test_scenario_transit_mix() -> None:
    """Level-band variability scenario must bill upper_pool below lower_pool for similar work."""
    transits_text = _swap_fixture("transit_mix")
    _invoke_default()
    report = _load_report()
    _assert_transits_match_input(report, transits_text)
    _assert_level_band_blend(report, transits_text, require_status=False)


def test_scenario_renew_delay() -> None:
    """Delayed dispatch-wave scenario must complete j_renew_late with dispatch buffer absorption."""
    cfg = _parse_cfg()
    transits_text = _swap_fixture("renew_delay")
    _invoke_default()
    report = _load_report()
    _assert_transits_match_input(report, transits_text)
    renew = next(r for r in report["transits"] if r["transit_id"] == "j_renew_late")
    assert renew["served"] is True
    assert report["convoy_buffer_m3"] >= cfg["min_convoy_buffer_m3"]
    assert report["status"] == "ok"
