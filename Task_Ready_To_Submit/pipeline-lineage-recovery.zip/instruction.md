Cluster bundles under `/app/clusters` drive `/app/bin/lineagerecover`. Replays write `/app/output/lineage_report.json` whose counters disagree with offline audits on several regression bundles: mesh cardinality overstated, log reconciliation shallow, dependency rows touching retired endpoints, script inventory not folding equivalent bodies, cyclic meshes reporting ordering residue, ownership holes on blank team values.

Rebuild from `/app` with `/app/scripts/build.sh`, set `tb_cluster` to a bundle stem, rerun the driver. Each replay must populate `cluster_runs` with exactly one row whose integer counters reconcile with the bundle — field presence alone is not enough. Regression stems are in `/app/docs/cluster_index.txt`.

The lone row carries cluster_tag from the bundle label plus seven counters. live_pipelines tallies pipeline ids absent from retired. rename_repairs tallies run_log rows whose logged id differs from the alias-closure id produced by chaining legacy_id to current_id mappings to a fixed point. dead_prunes tallies dependency edges with a retired endpoint. dag_edges tallies edges with both endpoints live. order_skips is live pipeline count minus nodes placed by lexicographic Kahn scheduling on live-only edges; a stalled scheduler reports the full unordered residue. ownership_gaps tallies live pipelines whose trimmed team string is empty.

Script inventory folds duplicate bodies: normalize each script by converting CRLF to LF and any remaining CR to LF; script_collapses tallies scripts whose normalized text matches an earlier bundle script in iteration order.

Signal completion once every stem in the index replays cleanly.
