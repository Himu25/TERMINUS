#!/bin/bash
set -euo pipefail

export PATH="/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/flux_p2/links.go <<'EOF'
package flux_p2

import "pipelinerec/pack_io"

func LiveSet(pipes []pack_io.PipeRow, retired map[string]bool) map[string]bool {
	out := make(map[string]bool, len(pipes))
	for _, row := range pipes {
		if retired[row.PipeID] {
			continue
		}
		out[row.PipeID] = true
	}
	return out
}

func FilterEdges(edges []pack_io.EdgeRow, live map[string]bool, retired map[string]bool) ([]pack_io.EdgeRow, int) {
	out := make([]pack_io.EdgeRow, 0, len(edges))
	prunes := 0
	for _, edge := range edges {
		if retired[edge.From] || retired[edge.To] {
			prunes++
		}
		if !live[edge.From] || !live[edge.To] {
			continue
		}
		out = append(out, edge)
	}
	return out, prunes
}

func HasCycle(edges []pack_io.EdgeRow, live map[string]bool) bool {
	adj := map[string][]string{}
	for id := range live {
		adj[id] = nil
	}
	for _, edge := range edges {
		if !live[edge.From] || !live[edge.To] {
			continue
		}
		adj[edge.From] = append(adj[edge.From], edge.To)
	}
	visited := map[string]bool{}
	stack := map[string]bool{}
	var walk func(string) bool
	walk = func(node string) bool {
		if stack[node] {
			return true
		}
		if visited[node] {
			return false
		}
		visited[node] = true
		stack[node] = true
		for _, next := range adj[node] {
			if walk(next) {
				return true
			}
		}
		delete(stack, node)
		return false
	}
	for node := range live {
		if walk(node) {
			return true
		}
	}
	return false
}
EOF

sed -i 's/skips++/skips += len(live) - len(order)/' /app/flux_p2/rank.go

cat > /app/tag_m4/resolve.go <<'EOF'
package tag_m4

import "pipelinerec/pack_io"

func ResolveID(logged string, aliases []pack_io.AliasRow) (string, bool) {
	byLegacy := map[string]string{}
	for _, row := range aliases {
		byLegacy[row.LegacyID] = row.CurrentID
	}
	cur := logged
	changed := false
	for {
		next, ok := byLegacy[cur]
		if !ok {
			break
		}
		changed = true
		cur = next
	}
	return cur, changed
}

func CountRepairs(logs []pack_io.LogRow, aliases []pack_io.AliasRow) int {
	repairs := 0
	for _, row := range logs {
		canon, ok := ResolveID(row.LoggedID, aliases)
		if ok && canon != row.LoggedID {
			repairs++
		}
	}
	return repairs
}
EOF

cat > /app/keel_m8/normalize.go <<'EOF'
package keel_m8

import "strings"

func FlattenBody(body string) string {
	return strings.ReplaceAll(strings.ReplaceAll(body, "\r\n", "\n"), "\r", "\n")
}
EOF

cat > /app/keel_m8/dedup.go <<'EOF'
package keel_m8

import (
	"pipelinerec/pack_io"
	"pipelinerec/ridge_n2"
)

func CollapseScripts(scripts []pack_io.ScriptRow) int {
	if len(scripts) == 0 {
		return 0
	}
	seen := map[uint64]bool{}
	collapses := 0
	for _, row := range scripts {
		body := FlattenBody(row.Body)
		fp := ridge_n2.Fingerprint(row.Path, body)
		if seen[fp] {
			collapses++
			continue
		}
		seen[fp] = true
	}
	return collapses
}
EOF

cat > /app/ridge_n2/fingerprint.go <<'EOF'
package ridge_n2

import "hash/fnv"

// Fingerprint returns a stable digest for one script payload.
func Fingerprint(path, body string) uint64 {
	h := fnv.New64a()
	_, _ = h.Write([]byte(body))
	return h.Sum64()
}
EOF

cat > /app/internal/driver/run.go <<'EOF'
package driver

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"pipelinerec/flux_p2"
	"pipelinerec/keel_m8"
	"pipelinerec/pack_io"
	"pipelinerec/tag_m4"
)

type LineageRun struct {
	ClusterTag      string `json:"cluster_tag"`
	LivePipelines   int    `json:"live_pipelines"`
	RenameRepairs   int    `json:"rename_repairs"`
	DeadPrunes      int    `json:"dead_prunes"`
	ScriptCollapses int    `json:"script_collapses"`
	DagEdges        int    `json:"dag_edges"`
	OrderSkips      int    `json:"order_skips"`
	OwnershipGaps   int    `json:"ownership_gaps"`
}

type lineagePayload struct {
	ClusterRuns []LineageRun `json:"cluster_runs"`
}

func retiredSet(ids []string) map[string]bool {
	out := make(map[string]bool, len(ids))
	for _, id := range ids {
		out[id] = true
	}
	return out
}

func ownershipGaps(pipes []pack_io.PipeRow, live map[string]bool) int {
	gaps := 0
	for _, row := range pipes {
		if !live[row.PipeID] {
			continue
		}
		if strings.TrimSpace(row.Team) == "" {
			gaps++
		}
	}
	return gaps
}

func simulate(bundle pack_io.Cluster) LineageRun {
	retired := retiredSet(bundle.Retired)
	live := flux_p2.LiveSet(bundle.Pipelines, retired)
	edges, prunes := flux_p2.FilterEdges(bundle.Edges, live, retired)
	_, orderSkips := flux_p2.TopoSort(edges, live)

	return LineageRun{
		ClusterTag:      bundle.ClusterLabel,
		LivePipelines:   len(live),
		RenameRepairs:   tag_m4.CountRepairs(bundle.RunLog, bundle.Aliases),
		DeadPrunes:      prunes,
		ScriptCollapses: keel_m8.CollapseScripts(bundle.Scripts),
		DagEdges:        len(edges),
		OrderSkips:      orderSkips,
		OwnershipGaps:   ownershipGaps(bundle.Pipelines, live),
	}
}

func Run() error {
	stem := os.Getenv("tb_cluster")
	if stem == "" {
		return errors.New("tb_cluster must name a stem under /app/clusters")
	}
	emit := "/app/output/lineage_report.json"
	raw, err := os.ReadFile(filepath.Join("/app", "clusters", stem+".json"))
	if err != nil {
		return err
	}
	var bundle pack_io.Cluster
	if err := json.Unmarshal(raw, &bundle); err != nil {
		return err
	}
	run := simulate(bundle)
	out := lineagePayload{ClusterRuns: []LineageRun{run}}
	if err := os.MkdirAll(filepath.Dir(emit), 0o755); err != nil {
		return err
	}
	buf, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		return err
	}
	tmp := emit + ".tmp"
	if err := os.WriteFile(tmp, buf, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, emit)
}

func MainExit() int {
	if err := Run(); err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		return 1
	}
	return 0
}
EOF

bash /app/scripts/build.sh

for probe in cluster_north cluster_east cluster_south cluster_central cluster_peak; do
  rm -f /app/output/lineage_report.json
  tb_cluster="$probe" /app/bin/lineagerecover >/dev/null
  test -s /app/output/lineage_report.json
done

echo "Oracle rebuilt lineagerecover and validated representative cluster bundles."
