package driver

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"

	"pipelinerec/flux_p2"
	"pipelinerec/keel_m8"
	"pipelinerec/pack_io"
	"pipelinerec/tag_m4"
)

type LineageRun struct {
	ClusterTag      string `json:"cluster_tag"`
	LivePipelines   int    `json:"live_pipelines"`   // active mesh after retirements
	RenameRepairs   int    `json:"rename_repairs"`   // run-log ids reconciled via alias chains
	DeadPrunes      int    `json:"dead_prunes"`      // dependency rows touching retired endpoints
	ScriptCollapses int    `json:"script_collapses"` // duplicate bodies after normalization
	DagEdges        int    `json:"dag_edges"`        // live-only dependency rows
	OrderSkips      int    `json:"order_skips"`      // nodes left unordered on cyclic live subgraphs
	OwnershipGaps   int    `json:"ownership_gaps"`   // live pipelines with empty trimmed team
}

type lineagePayload struct {
	ClusterRuns []LineageRun `json:"cluster_runs"`
}

func retiredSet(ids []string) map[string]bool {
	out := make(map[string]bool, len(ids))
	for _, id := range ids {
		out[id] = true
	}
	return out
}

func ownershipGaps(pipes []pack_io.PipeRow, live map[string]bool) int {
	gaps := 0
	for _, row := range pipes {
		if !live[row.PipeID] {
			continue
		}
		if row.Team == "" {
			gaps++
		}
	}
	return gaps
}

func simulate(bundle pack_io.Cluster) LineageRun {
	retired := retiredSet(bundle.Retired)
	live := flux_p2.LiveSet(bundle.Pipelines, retired)
	edges, _ := flux_p2.FilterEdges(bundle.Edges, live, retired)
	_, orderSkips := flux_p2.TopoSort(bundle.Edges, live)

	liveCount := len(live)

	return LineageRun{
		ClusterTag:      bundle.ClusterLabel,
		LivePipelines:   liveCount,
		RenameRepairs:   tag_m4.CountRepairs(bundle.RunLog, bundle.Aliases),
		DeadPrunes:      len(bundle.Retired),
		ScriptCollapses: keel_m8.CollapseScripts(bundle.Scripts),
		DagEdges:        len(edges),
		OrderSkips:      orderSkips,
		OwnershipGaps:   ownershipGaps(bundle.Pipelines, live),
	}
}

// Run loads one cluster via tb_cluster and writes the lineage report.
func Run() error {
	stem := os.Getenv("tb_cluster")
	if stem == "" {
		return errors.New("tb_cluster must name a stem under /app/clusters")
	}
	emit := "/app/output/lineage_report.json"
	raw, err := os.ReadFile(filepath.Join("/app", "clusters", stem+".json"))
	if err != nil {
		return err
	}
	var bundle pack_io.Cluster
	if err := json.Unmarshal(raw, &bundle); err != nil {
		return err
	}
	run := simulate(bundle)
	out := lineagePayload{ClusterRuns: []LineageRun{run}}
	if err := os.MkdirAll(filepath.Dir(emit), 0o755); err != nil {
		return err
	}
	buf, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		return err
	}
	tmp := emit + ".tmp"
	if err := os.WriteFile(tmp, buf, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, emit)
}

// MainExit is the cmd entry wrapper.
func MainExit() int {
	if err := Run(); err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		return 1
	}
	return 0
}
