package pack_io

// PipeRow is one pipeline definition in a cluster bundle.
type PipeRow struct {
	PipeID    string   `json:"pipe_id"`
	Team      string   `json:"team"`
	Script    string   `json:"script"`
	Sources   []string `json:"sources"`
	Transform string   `json:"transform"`
}

// EdgeRow is a dependency between pipelines.
type EdgeRow struct {
	From string `json:"from"`
	To   string `json:"to"`
}

// AliasRow maps a legacy job id to its current id.
type AliasRow struct {
	LegacyID  string `json:"legacy_id"`
	CurrentID string `json:"current_id"`
}

// ScriptRow carries script body text for fingerprinting.
type ScriptRow struct {
	Path string `json:"path"`
	Body string `json:"body"`
}

// LogRow is one execution log entry referencing a pipeline id.
type LogRow struct {
	LoggedID string `json:"logged_id"`
	Done     bool   `json:"done"`
}

// Cluster is one scenario pack under /app/clusters.
type Cluster struct {
	ClusterLabel string     `json:"cluster_label"`
	Pipelines    []PipeRow  `json:"pipelines"`
	Edges        []EdgeRow  `json:"edges"`
	Aliases      []AliasRow `json:"aliases"`
	Retired      []string   `json:"retired"`
	Scripts      []ScriptRow `json:"scripts"`
	RunLog       []LogRow   `json:"run_log"`
}
