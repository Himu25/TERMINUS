# Dependencies

Go 1.22. ridge_n2 supplies a small body fingerprint helper for script dedup.
