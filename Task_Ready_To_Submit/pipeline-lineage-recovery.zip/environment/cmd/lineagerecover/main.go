package main

import (
	"os"

	"pipelinerec/internal/driver"
)

func main() {
	os.Exit(driver.MainExit())
}
