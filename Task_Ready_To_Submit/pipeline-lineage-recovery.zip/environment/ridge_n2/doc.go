package ridge_n2
