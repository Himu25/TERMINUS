package ridge_n2

import "hash/fnv"

// Fingerprint returns a stable digest for one script payload.
func Fingerprint(path, body string) uint64 {
	h := fnv.New64a()
	_, _ = h.Write([]byte(path))
	return h.Sum64()
}
