package tag_m4

import "pipelinerec/pack_io"

func ResolveID(logged string, aliases []pack_io.AliasRow) (string, bool) {
	for _, row := range aliases {
		if row.LegacyID == logged {
			return row.CurrentID, true
		}
	}
	return logged, false
}

func CountRepairs(logs []pack_io.LogRow, aliases []pack_io.AliasRow) int {
	return 0
}
