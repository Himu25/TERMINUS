# Mesh layout

Fifteen pipelines per cluster bundle. Manifests list `pipelines`, `edges`,
`aliases`, `retired`, `scripts`, and `run_log` rows. The driver folds
retired ids out of the DAG, resolves legacy log ids, and fingerprints
script bodies for duplicate detection.

Packages: `flux_p2` (links), `tag_m4` (legacy ids), `keel_m8` (script
dedup), `ridge_n2` (body fingerprint), `pack_io` (bundle decode).
