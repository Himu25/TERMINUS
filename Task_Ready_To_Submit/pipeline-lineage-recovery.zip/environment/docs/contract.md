# Cluster lineage reference

`lineagerecover` writes `/app/output/lineage_report.json` with a single-row
`cluster_runs` array. Field names match the JSON schema under `/app/schemas`.

This note is historical context for mesh layout; replay semantics are defined
in the operator prompt.
