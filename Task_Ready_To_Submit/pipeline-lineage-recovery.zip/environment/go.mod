module pipelinerec

go 1.22
