package flux_p2

import "pipelinerec/pack_io"

func LiveSet(pipes []pack_io.PipeRow, retired map[string]bool) map[string]bool {
	out := make(map[string]bool, len(pipes))
	for _, row := range pipes {
		out[row.PipeID] = true
	}
	return out
}

func FilterEdges(edges []pack_io.EdgeRow, live map[string]bool, retired map[string]bool) ([]pack_io.EdgeRow, int) {
	out := make([]pack_io.EdgeRow, 0, len(edges))
	for _, edge := range edges {
		if !live[edge.From] || !live[edge.To] {
			continue
		}
		out = append(out, edge)
	}
	return out, 0
}

func HasCycle(edges []pack_io.EdgeRow, live map[string]bool) bool {
	adj := map[string][]string{}
	for id := range live {
		adj[id] = nil
	}
	for _, edge := range edges {
		if !live[edge.From] || !live[edge.To] {
			continue
		}
		adj[edge.From] = append(adj[edge.From], edge.To)
	}
	visited := map[string]bool{}
	stack := map[string]bool{}
	var walk func(string) bool
	walk = func(node string) bool {
		if stack[node] {
			return true
		}
		if visited[node] {
			return false
		}
		visited[node] = true
		stack[node] = true
		for _, next := range adj[node] {
			if walk(next) {
				return true
			}
		}
		delete(stack, node)
		return false
	}
	for node := range live {
		if walk(node) {
			return true
		}
	}
	return false
}
