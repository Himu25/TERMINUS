package flux_p2

import (
	"sort"

	"pipelinerec/pack_io"
)

// TopoSort returns a topological ordering of live pipeline ids.
func TopoSort(edges []pack_io.EdgeRow, live map[string]bool) ([]string, int) {
	indeg := map[string]int{}
	for id := range live {
		indeg[id] = 0
	}
	adj := map[string][]string{}
	for _, edge := range edges {
		if !live[edge.From] || !live[edge.To] {
			continue
		}
		adj[edge.From] = append(adj[edge.From], edge.To)
		indeg[edge.To]++
	}
	ready := make([]string, 0, len(live))
	for id := range live {
		if indeg[id] == 0 {
			ready = append(ready, id)
		}
	}
	sort.Strings(ready)
	order := make([]string, 0, len(live))
	skips := 0
	for len(order) < len(live) {
		if len(ready) == 0 {
			skips++
			break
		}
		cur := ready[0]
		ready = ready[1:]
		order = append(order, cur)
		for _, next := range adj[cur] {
			indeg[next]--
			if indeg[next] == 0 {
				ready = append(ready, next)
			}
		}
		sort.Strings(ready)
	}
	return order, skips
}
