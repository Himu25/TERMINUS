package keel_m8

// FlattenBody normalizes script text before fingerprint comparison.
func FlattenBody(body string) string {
	return body
}
