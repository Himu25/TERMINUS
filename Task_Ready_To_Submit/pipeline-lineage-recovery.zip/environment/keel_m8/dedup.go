package keel_m8

import "pipelinerec/pack_io"

func CollapseScripts(scripts []pack_io.ScriptRow) int {
	if len(scripts) == 0 {
		return 0
	}
	seen := map[string]bool{}
	collapses := 0
	for _, row := range scripts {
		key := row.Path
		if seen[key] {
			collapses++
			continue
		}
		seen[key] = true
	}
	return collapses
}
