#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
test -f go.mod
test -d clusters
test -x scripts/build.sh
