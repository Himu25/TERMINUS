# Pipeline lineage recovery workspace

Fifteen-team ETL mesh under `/app` with cluster bundles in `/app/clusters`.
The `lineagerecover` driver rebuilds dependency graphs from manifests,
execution logs, script bodies, and ownership tables.

Build with `/app/scripts/build.sh`. Set `tb_cluster` to a bundle stem and
run `/app/bin/lineagerecover`.
