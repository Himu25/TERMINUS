"""Verifier for multi-team pipeline lineage recovery."""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
REPORT = APP / "output" / "lineage_report.json"
FIXTURES = Path(__file__).resolve().parent / "fixtures" / "clusters"

REGRESSION_STEMS = (
    "cluster_north",
    "cluster_south",
    "cluster_east",
    "cluster_central",
    "cluster_peak",
)


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    """Rebuild lineagerecover from the agent-edited tree before scoring."""
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "PATH": "/usr/local/go/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _load(stem: str) -> dict:
    return json.loads((FIXTURES / f"{stem}.json").read_text(encoding="utf-8"))


def _drive(stem: str) -> dict:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    if REPORT.exists():
        REPORT.unlink()
    subprocess.run(
        ["/app/bin/lineagerecover"],
        cwd=str(APP),
        env={**os.environ, "tb_cluster": stem},
        check=True,
    )
    payload = json.loads(REPORT.read_text(encoding="utf-8"))
    assert "cluster_runs" in payload and len(payload["cluster_runs"]) == 1, (
        "cluster_runs must hold exactly one row per replay"
    )
    row = payload["cluster_runs"][0]
    assert row.get("cluster_tag") == _load(stem)["cluster_label"]
    return row


def _flatten_body(body: str) -> str:
    return body.replace("\r\n", "\n").replace("\r", "\n")


def _canonical_id(logged: str, aliases: list[dict]) -> str:
    by_legacy = {row["legacy_id"]: row["current_id"] for row in aliases}
    cur = logged
    while cur in by_legacy:
        cur = by_legacy[cur]
    return cur


def _topo_skips(edges: list[dict], live: set[str]) -> int:
    indeg = {node: 0 for node in live}
    adj: dict[str, list[str]] = {node: [] for node in live}
    for edge in edges:
        if edge["from"] not in live or edge["to"] not in live:
            continue
        adj[edge["from"]].append(edge["to"])
        indeg[edge["to"]] += 1
    ready = sorted(node for node in live if indeg[node] == 0)
    order: list[str] = []
    skips = 0
    while len(order) < len(live):
        if not ready:
            skips += len(live) - len(order)
            break
        cur = ready.pop(0)
        order.append(cur)
        for nxt in adj[cur]:
            indeg[nxt] -= 1
            if indeg[nxt] == 0:
                ready.append(nxt)
        ready.sort()
    return skips


def _expected(bundle: dict) -> dict:
    retired = set(bundle["retired"])
    live = {p["pipe_id"] for p in bundle["pipelines"] if p["pipe_id"] not in retired}
    rename_repairs = sum(
        1
        for row in bundle["run_log"]
        if _canonical_id(row["logged_id"], bundle["aliases"]) != row["logged_id"]
    )
    seen: set[str] = set()
    script_collapses = 0
    for script in bundle["scripts"]:
        body = _flatten_body(script["body"])
        if body in seen:
            script_collapses += 1
        else:
            seen.add(body)
    live_edges = [
        e for e in bundle["edges"] if e["from"] in live and e["to"] in live
    ]
    dead_prunes = sum(
        1
        for e in bundle["edges"]
        if e["from"] in retired or e["to"] in retired
    )
    ownership_gaps = sum(
        1
        for p in bundle["pipelines"]
        if p["pipe_id"] in live and not p.get("team", "").strip()
    )
    return {
        "live_pipelines": len(live),
        "rename_repairs": rename_repairs,
        "dead_prunes": dead_prunes,
        "script_collapses": script_collapses,
        "dag_edges": len(live_edges),
        "order_skips": _topo_skips(bundle["edges"], live),
        "ownership_gaps": ownership_gaps,
    }


def _assert_row(row: dict, stem: str) -> None:
    want = _expected(_load(stem))
    for key, val in want.items():
        assert row[key] == val, f"{stem} {key}: got {row[key]} want {val}"


def test_cluster_north() -> None:
    """Retired pipelines and renamed log ids must reconcile on the north mesh."""
    _assert_row(_drive("cluster_north"), "cluster_north")


def test_cluster_south() -> None:
    """Cyclic live subgraph must report ordering stress after retirements."""
    _assert_row(_drive("cluster_south"), "cluster_south")


def test_cluster_east() -> None:
    """Copied script bodies and CRLF variants must collapse."""
    _assert_row(_drive("cluster_east"), "cluster_east")


def test_cluster_central() -> None:
    """Full mesh with alias chains, retirees, copies, and ownership gaps."""
    _assert_row(_drive("cluster_central"), "cluster_central")


def test_cluster_peak() -> None:
    """Peak cluster combines retirements, renames, and triple script copies."""
    _assert_row(_drive("cluster_peak"), "cluster_peak")


def test_regression_matrix_covers_index() -> None:
    """Every stem listed for replay must be scored with independent counter math."""
    index = (APP / "docs" / "cluster_index.txt").read_text(encoding="utf-8").splitlines()
    indexed = [line.strip() for line in index if line.strip()]
    assert indexed == list(REGRESSION_STEMS)
    for stem in REGRESSION_STEMS:
        _assert_row(_drive(stem), stem)


def test_central_counters_not_shallow_defaults() -> None:
    """Central replay must show non-trivial rename, collapse, and ownership stress."""
    row = _drive("cluster_central")
    want = _expected(_load("cluster_central"))
    assert row["rename_repairs"] == want["rename_repairs"] and want["rename_repairs"] > 0
    assert row["script_collapses"] == want["script_collapses"] and want["script_collapses"] > 0
    assert row["ownership_gaps"] == want["ownership_gaps"] and want["ownership_gaps"] > 0
