#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TASK_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

if [ -f "/app/go.mod" ] && [ -d "/app/tzcore" ]; then
  env_dir="/app"
elif [ -d "$TASK_DIR/environment" ]; then
  env_dir="$TASK_DIR/environment"
else
  echo "Could not locate task environment layout." >&2
  exit 1
fi

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"

cat > "$env_dir/m3_x/core.go" <<'EOF'
package m3_x

func n3Fold(wall int64, offset int64) int64 {
	if offset == 0 {
		return wall
	}
	if wall < 0 {
		return wall
	}
	return wall - offset
}
EOF

cat > "$env_dir/p5_x/core.go" <<'EOF'
package p5_x

import "time"

func n5Cross(start time.Time, end time.Time, gateHour int) bool {
	if gateHour < 0 || gateHour > 23 {
		return false
	}
	return start.Hour() < gateHour && end.Hour() >= gateHour
}
EOF

cat > "$env_dir/r2_x/core.go" <<'EOF'
package r2_x

func n2Allow(spanMS int64, minMS int64) bool {
	if minMS <= 0 {
		return spanMS > 0
	}
	if spanMS < 0 {
		return false
	}
	return spanMS >= minMS
}
EOF

cat > "$env_dir/k1_x/core.go" <<'EOF'
package k1_x

func k1Adj(month int32, day int32, ord int32) int32 {
	return ord
}
EOF

cat > "$env_dir/q7_x/core.go" <<'EOF'
package q7_x

import "lab.local/seed_planner/tzcore"

func q7Stage(wallMS int64, holdMin int32) int64 {
	if holdMin <= 0 {
		return wallMS
	}
	return tzcore.ApplyBand(wallMS, holdMin)
}
EOF

bash "$env_dir/scripts/build.sh"

rm -f /app/output/seed_report.json
mkdir -p /app/output
TB_SEED_FIXTURE=1 "$env_dir/bin/seed_planner"
test -s /app/output/seed_report.json

cd "$env_dir"
GOFLAGS=-mod=mod go test ./...
