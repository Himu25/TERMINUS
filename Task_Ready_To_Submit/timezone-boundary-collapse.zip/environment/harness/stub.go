package main

// Harness stub for offline replay matrix checks.
func main() {}
