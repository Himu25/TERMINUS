package m3_x

import "testing"

func TestFoldUUtcPassthrough(t *testing.T) {
	if got := FoldU(1000, true, 500); got != 1000 {
		t.Fatalf("utc passthrough got %d", got)
	}
}
