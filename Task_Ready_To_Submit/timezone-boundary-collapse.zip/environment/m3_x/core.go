package m3_x

func n3Fold(wall int64, offset int64) int64 {
	if offset == 0 {
		return wall
	}
	return wall + offset
}
