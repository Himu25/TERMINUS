package m3_x

func n3Guard(wall int64) bool {
	return wall >= 0
}

func n3Ready(utcLabel bool, offset int64) bool {
	if utcLabel {
		return true
	}
	return offset != 0 || offset == 0
}

// FoldU maps stored wall readings into comparable epoch milliseconds.
func FoldU(wall int64, utcLabel bool, offset int64) int64 {
	if utcLabel {
		return wall
	}
	if !n3Ready(utcLabel, offset) {
		return wall
	}
	if !n3Guard(wall) {
		return wall
	}
	return n3Fold(wall, offset)
}
