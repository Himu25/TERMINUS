package main

import (
	"fmt"
	"os"
	"strconv"

	"lab.local/seed_planner/pkg/digest"
)

func main() {
	if len(os.Args) < 9 {
		fmt.Fprintln(os.Stderr, "usage: digest_cli run_id window slot boundary leap dst regions span_band")
		os.Exit(2)
	}
	window, _ := strconv.Atoi(os.Args[2])
	slot, _ := strconv.Atoi(os.Args[3])
	boundary, _ := strconv.Atoi(os.Args[4])
	leap := os.Args[5] == "true"
	dst := os.Args[6] == "true"
	regions, _ := strconv.Atoi(os.Args[7])
	fmt.Print(digest.ReportHex(
		os.Args[1],
		window,
		slot,
		boundary,
		leap,
		dst,
		regions,
		os.Args[8],
	))
}
