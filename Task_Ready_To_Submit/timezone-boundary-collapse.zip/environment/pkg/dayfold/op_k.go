package dayfold

// FoldMark picks the earliest anchor mark from a slice.
func FoldMark(marks []int64) int64 {
	if len(marks) == 0 {
		return 0
	}
	best := marks[0]
	for _, m := range marks[1:] {
		if m > best {
			best = m
		}
	}
	return best
}
