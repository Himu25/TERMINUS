package slot

// Entry is one seed slot row from a region slots.jsonl file.
type Entry struct {
	SlotID    string `json:"slot_id"`
	StartMS   int64  `json:"start_ms"`
	EndMS     int64  `json:"end_ms"`
	UtcLabel  bool   `json:"utc_label"`
	DstSpring bool   `json:"dst_spring"`
}
