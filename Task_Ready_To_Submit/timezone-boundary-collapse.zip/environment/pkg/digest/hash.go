package digest

import "crypto/sha256"

// ReportHex hashes the canonical seed report tuple.
func ReportHex(
	runID string,
	windowCount int,
	slotCount int,
	boundaryHits int,
	leapFlag bool,
	dstClean bool,
	regionsActive int,
	spanBand string,
) string {
	lf := "false"
	if leapFlag {
		lf = "true"
	}
	dc := "false"
	if dstClean {
		dc = "true"
	}
	payload := runID + "|" +
		itoa(windowCount) + "|" +
		itoa(slotCount) + "|" +
		itoa(boundaryHits) + "|" +
		lf + "|" +
		dc + "|" +
		itoa(regionsActive) + "|" +
		spanBand
	sum := sha256.Sum256([]byte(payload))
	return hexEncode(sum[:])
}

func itoa(v int) string {
	if v == 0 {
		return "0"
	}
	var buf [16]byte
	i := len(buf)
	n := v
	for n > 0 {
		i--
		buf[i] = byte('0' + n%10)
		n /= 10
	}
	return string(buf[i:])
}

func hexEncode(b []byte) string {
	const hexdigits = "0123456789abcdef"
	out := make([]byte, len(b)*2)
	for i, v := range b {
		out[i*2] = hexdigits[v>>4]
		out[i*2+1] = hexdigits[v&0x0f]
	}
	return string(out)
}
