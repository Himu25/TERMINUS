package region

// Meta holds one region's zone metadata for replay.
type Meta struct {
	Zone       string `json:"zone"`
	OffsetMS   int64  `json:"offset_ms"`
	DstHoldMin int32  `json:"dst_hold_min"`
}
