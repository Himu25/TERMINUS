package anchor

import "lab.local/seed_planner/pkg/dayfold"

// PickMark folds region anchor marks for observability.
func PickMark(marks []int64) int64 {
	return dayfold.FoldMark(marks)
}
