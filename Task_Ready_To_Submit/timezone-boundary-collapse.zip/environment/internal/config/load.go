package config

import (
	"encoding/json"
	"os"
	"path/filepath"

	"lab.local/seed_planner/pkg/region"
	"lab.local/seed_planner/pkg/slot"
)

// Pack describes one seed scenario root.
type Pack struct {
	RunID       string   `json:"run_id"`
	GateHour    int      `json:"gate_hour"`
	SpanTightH  int      `json:"span_tight_h"`
	MinSlotMS   int64    `json:"min_slot_ms"`
	AnchorLeap  bool     `json:"anchor_leap"`
	Regions     []string `json:"regions"`
}

// ActivePaths resolves the bundled active pack directory.
func ActivePaths(root string) (string, error) {
	return filepath.Join(root, "data", "active"), nil
}

// LoadPack reads seed_pack.json and region slot trees.
func LoadPack(dir string) (Pack, map[string]region.Meta, map[string][]slot.Entry, error) {
	raw, err := os.ReadFile(filepath.Join(dir, "seed_pack.json"))
	if err != nil {
		return Pack{}, nil, nil, err
	}
	var doc Pack
	if err := json.Unmarshal(raw, &doc); err != nil {
		return Pack{}, nil, nil, err
	}
	metas := make(map[string]region.Meta, len(doc.Regions))
	slots := make(map[string][]slot.Entry, len(doc.Regions))
	for _, rid := range doc.Regions {
		metaPath := filepath.Join(dir, "regions", rid, "meta.json")
		metaRaw, err := os.ReadFile(metaPath)
		if err != nil {
			return Pack{}, nil, nil, err
		}
		var meta region.Meta
		if err := json.Unmarshal(metaRaw, &meta); err != nil {
			return Pack{}, nil, nil, err
		}
		metas[rid] = meta
		seg := filepath.Join(dir, "regions", rid, "slots.jsonl")
		data, err := os.ReadFile(seg)
		if err != nil {
			if os.IsNotExist(err) {
				continue
			}
			return Pack{}, nil, nil, err
		}
		for _, line := range splitLines(string(data)) {
			if line == "" {
				continue
			}
			var row slot.Entry
			if err := json.Unmarshal([]byte(line), &row); err != nil {
				continue
			}
			slots[rid] = append(slots[rid], row)
		}
	}
	return doc, metas, slots, nil
}

func splitLines(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			out = append(out, s[start:i])
			start = i + 1
		}
	}
	if start < len(s) {
		out = append(out, s[start:])
	}
	return out
}
