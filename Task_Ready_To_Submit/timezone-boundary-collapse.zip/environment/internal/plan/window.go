package plan

import (
	"lab.local/seed_planner/p5_x"
	"lab.local/seed_planner/r2_x"
)

// AdmitWindow clips then gates one normalized window span.
func AdmitWindow(startMS int64, endMS int64, gateHour int, minMS int64) (int64, int64, bool) {
	start, end := p5_x.ClampW(startMS, endMS, gateHour)
	span := end - start
	return start, end, r2_x.GateS(span, minMS)
}
