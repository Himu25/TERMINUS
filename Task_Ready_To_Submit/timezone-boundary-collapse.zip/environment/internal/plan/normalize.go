package plan

import (
	"time"

	"lab.local/seed_planner/m3_x"
	"lab.local/seed_planner/q7_x"
	"lab.local/seed_planner/pkg/region"
	"lab.local/seed_planner/pkg/slot"
	"lab.local/seed_planner/tzcore"
)

// NormalizeSlot folds one slot's endpoints through offset and optional band shift.
func NormalizeSlot(row slot.Entry, meta region.Meta) (int64, int64) {
	start := m3_x.FoldU(row.StartMS, row.UtcLabel, meta.OffsetMS)
	end := m3_x.FoldU(row.EndMS, row.UtcLabel, meta.OffsetMS)
	if row.DstSpring && meta.DstHoldMin > 0 {
		start = q7_x.ApplyHold(start, meta.DstHoldMin)
		end = q7_x.ApplyHold(end, meta.DstHoldMin)
	}
	return start, end
}

// DayPair returns UTC anchor ordinals for two epoch millisecond endpoints.
func DayPair(startMS int64, endMS int64) (int32, int32) {
	startDT := time.UnixMilli(startMS).UTC()
	endDT := time.UnixMilli(endMS).UTC()
	return tzcore.DayOrdinal(int32(startDT.Year()), int32(startDT.Month()), int32(startDT.Day())),
		tzcore.DayOrdinal(int32(endDT.Year()), int32(endDT.Month()), int32(endDT.Day()))
}
