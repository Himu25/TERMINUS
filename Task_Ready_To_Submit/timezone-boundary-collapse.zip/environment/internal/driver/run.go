package driver

import (
	"encoding/json"
	"os"

	"lab.local/seed_planner/internal/config"
	"lab.local/seed_planner/internal/engine"
	"lab.local/seed_planner/pkg/digest"
)

// Report is the JSON shape written to seed_report.json.
type Report struct {
	SchemaVersion string `json:"schema_version"`
	RunID         string `json:"run_id"`
	WindowCount   int    `json:"window_count"`
	SlotCount     int    `json:"slot_count"`
	BoundaryHits  int    `json:"boundary_hits"`
	LeapFlag      bool   `json:"leap_flag"`
	DstClean      bool   `json:"dst_clean"`
	RegionsActive int    `json:"regions_active"`
	SpanBand      string `json:"span_band"`
	DigestHex     string `json:"digest_hex"`
}

// RunActive loads the active pack and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	pack, metas, slots, err := config.LoadPack(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(pack.GateHour, pack.SpanTightH, pack.MinSlotMS, pack.AnchorLeap, metas, slots)
	digestHex := digest.ReportHex(
		pack.RunID,
		out.WindowCount,
		out.SlotCount,
		out.BoundaryHits,
		out.LeapFlag,
		out.DstClean,
		out.RegionsActive,
		out.SpanBand,
	)
	return Report{
		SchemaVersion: "1",
		RunID:         pack.RunID,
		WindowCount:   out.WindowCount,
		SlotCount:     out.SlotCount,
		BoundaryHits:  out.BoundaryHits,
		LeapFlag:      out.LeapFlag,
		DstClean:      out.DstClean,
		RegionsActive: out.RegionsActive,
		SpanBand:      out.SpanBand,
		DigestHex:     digestHex,
	}, nil
}

// EmitReport writes the report JSON to outPath.
func EmitReport(outPath string, rep Report) error {
	if err := os.MkdirAll("/app/output", 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(outPath, raw, 0o644)
}
