package engine

import (
	"time"

	"lab.local/seed_planner/internal/plan"
	"lab.local/seed_planner/k1_x"
	"lab.local/seed_planner/pkg/region"
	"lab.local/seed_planner/pkg/slot"
)

// Outcome is the folded seed counters for one pack replay.
type Outcome struct {
	WindowCount   int
	SlotCount     int
	BoundaryHits  int
	LeapFlag      bool
	DstClean      bool
	RegionsActive int
	SpanBand      string
}

// Replay executes one pack through window fold and slot gate stages.
func Replay(
	gateHour int,
	spanTightH int,
	minSlotMS int64,
	anchorLeap bool,
	metas map[string]region.Meta,
	allSlots map[string][]slot.Entry,
) Outcome {
	spanTightMS := int64(spanTightH) * 3_600_000
	windowCount := 0
	boundaryHits := 0
	leapFlag := false
	dstClean := true
	regionsActive := 0
	maxSpan := int64(0)

	for rid, rows := range allSlots {
		meta := metas[rid]
		regionPass := false
		for _, row := range rows {
			start, end := plan.NormalizeSlot(row, meta)
			startOrd, endOrd := plan.DayPair(start, end)
			if startOrd != endOrd {
				boundaryHits++
			}
			startDT := time.UnixMilli(start).UTC()
			if anchorLeap && startDT.Month() == 2 && startDT.Day() == 29 {
				if k1_x.PickOrd(int32(startDT.Year()), 2, 29) == 60 {
					leapFlag = true
				}
			}
			clippedStart, clippedEnd, ok := plan.AdmitWindow(start, end, gateHour, minSlotMS)
			span := clippedEnd - clippedStart
			if row.DstSpring && meta.DstHoldMin > 0 && span <= 0 {
				dstClean = false
			}
			if ok {
				windowCount++
				regionPass = true
				if span > maxSpan {
					maxSpan = span
				}
			}
		}
		if regionPass {
			regionsActive++
		}
	}

	spanBand := "tight"
	if maxSpan > spanTightMS {
		spanBand = "wide"
	}

	return Outcome{
		WindowCount:   windowCount,
		SlotCount:     windowCount,
		BoundaryHits:  boundaryHits,
		LeapFlag:      leapFlag,
		DstClean:      dstClean,
		RegionsActive: regionsActive,
		SpanBand:      spanBand,
	}
}
