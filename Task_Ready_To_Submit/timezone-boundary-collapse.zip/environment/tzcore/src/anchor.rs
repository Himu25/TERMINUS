use std::os::raw::c_int;

fn leap_year(y: i32) -> bool {
    (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)
}

/// tb_anchor_day returns the calendar day ordinal for boundary counting.
#[no_mangle]
pub extern "C" fn tb_anchor_day(year: c_int, month: c_int, day: c_int) -> c_int {
    let y = year as i32;
    let m = month as i32;
    let d = day as i32;
    let days_before = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    if m < 1 || m > 12 {
        return 0;
    }
    let mut ord = days_before[(m - 1) as usize] + d;
    if m > 2 && leap_year(y) {
        ord += 1;
    }
    ord
}
