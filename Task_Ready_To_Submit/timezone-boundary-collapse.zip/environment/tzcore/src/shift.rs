use std::os::raw::{c_int, c_longlong};

fn band_delta(hold_min: i32) -> i64 {
    (hold_min as i64) * 60_000
}

/// tb_shift_band folds a hold band into wall time around a daylight gap.
#[no_mangle]
pub extern "C" fn tb_shift_band(wall_ms: c_longlong, hold_min: c_int) -> c_longlong {
    if hold_min == 0 {
        return wall_ms;
    }
    wall_ms - band_delta(hold_min)
}
