#ifndef TZ_FOLD_H
#define TZ_FOLD_H

#include <stdint.h>

int32_t tb_anchor_day(int32_t year, int32_t month, int32_t day);
long long tb_shift_band(long long wall_ms, int32_t hold_min);

#endif
