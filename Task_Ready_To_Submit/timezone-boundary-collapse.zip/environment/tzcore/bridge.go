package tzcore

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libtzcore.a -ldl -lm
#include "tz_fold.h"
*/
import "C"

// ApplyBand shifts wall time through the Rust hold-band folder.
func ApplyBand(wallMS int64, holdMin int32) int64 {
	return int64(C.tb_shift_band(C.longlong(wallMS), C.int(holdMin)))
}

// DayOrdinal returns the anchor day ordinal for one calendar date.
func DayOrdinal(year, month, day int32) int32 {
	return int32(C.tb_anchor_day(C.int(year), C.int(month), C.int(day)))
}
