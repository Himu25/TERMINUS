package p5_x

import "time"

func sameUtcDay(start time.Time, end time.Time) bool {
	return start.Year() == end.Year() && start.YearDay() == end.YearDay()
}

func n5Instant(start time.Time, gateHour int) time.Time {
	return time.Date(start.Year(), start.Month(), start.Day(), gateHour, 0, 0, 0, time.UTC)
}

func n5ValidHour(gateHour int) bool {
	return gateHour >= 0 && gateHour <= 23
}

// ClampW trims a window that crosses the configured gate hour on one UTC day.
func ClampW(startMS int64, endMS int64, gateHour int) (int64, int64) {
	if !n5ValidHour(gateHour) {
		return startMS, endMS
	}
	start := time.UnixMilli(startMS).UTC()
	end := time.UnixMilli(endMS).UTC()
	if !sameUtcDay(start, end) {
		return startMS, endMS
	}
	if n5Cross(start, end, gateHour) {
		gate := n5Instant(start, gateHour)
		return startMS, gate.UnixMilli()
	}
	return startMS, endMS
}
