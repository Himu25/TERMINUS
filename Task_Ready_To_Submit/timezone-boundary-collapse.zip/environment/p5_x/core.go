package p5_x

import "time"

func n5Cross(start time.Time, end time.Time, gateHour int) bool {
	return start.Hour() >= gateHour && end.Hour() >= gateHour
}
