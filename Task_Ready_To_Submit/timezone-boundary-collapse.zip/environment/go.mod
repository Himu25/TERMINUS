module lab.local/seed_planner

go 1.22
