Verifier builds via /app/scripts/build.sh and invokes /app/bin/digest_cli for digest checks.
Digest helper source: /app/tools/digest_cli
Session-scoped binary copy target: /tmp/seed_planner_verify_bin
Go toolchain path: /usr/local/go/bin/go
