Region slot files live under data/active/regions/<id>/slots.jsonl with meta.json per region.
