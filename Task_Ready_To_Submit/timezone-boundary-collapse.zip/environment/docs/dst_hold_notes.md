dst_hold_min is expressed in minutes for spring-gap folding.
