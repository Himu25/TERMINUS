Pack gate_hour marks the UTC hour boundary used during window clipping.
