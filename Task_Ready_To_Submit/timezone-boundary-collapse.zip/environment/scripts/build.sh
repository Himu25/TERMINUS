#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1

mkdir -p /app/bin
cd /app/tzcore
CARGO_TARGET_DIR=/app/tzcore/target cargo build --release --locked
cd /app
GOFLAGS=-mod=mod go build -trimpath -buildvcs=false -o /app/bin/seed_planner ./cmd/seed_planner
GOFLAGS=-mod=mod go build -trimpath -buildvcs=false -o /app/bin/digest_cli ./tools/digest_cli
