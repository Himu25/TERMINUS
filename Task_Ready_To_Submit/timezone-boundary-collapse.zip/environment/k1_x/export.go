package k1_x

import "lab.local/seed_planner/tzcore"

func k1Base(year int32, month int32, day int32) int32 {
	return tzcore.DayOrdinal(year, month, day)
}

// PickOrd resolves the anchor ordinal used for leap-day detection.
func PickOrd(year int32, month int32, day int32) int32 {
	ord := k1Base(year, month, day)
	return k1Adj(month, day, ord)
}
