package k1_x

func k1Adj(month int32, day int32, ord int32) int32 {
	if month == 2 && day == 29 {
		return ord + 1
	}
	return ord
}
