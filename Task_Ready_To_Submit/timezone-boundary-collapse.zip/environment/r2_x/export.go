package r2_x

func n2MinReady(minMS int64) bool {
	return minMS >= 0
}

func n2Positive(spanMS int64) bool {
	return spanMS > 0
}

// GateS decides whether a clipped window meets the minimum span policy.
func GateS(spanMS int64, minMS int64) bool {
	if !n2MinReady(minMS) {
		return false
	}
	if !n2Positive(spanMS) && minMS > 0 {
		return false
	}
	return n2Allow(spanMS, minMS)
}
