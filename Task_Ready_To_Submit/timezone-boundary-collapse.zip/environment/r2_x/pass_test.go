package r2_x

import "testing"

func TestGateSRejectsZeroSpan(t *testing.T) {
	if GateS(0, 100) {
		t.Fatal("zero span should not pass")
	}
}
