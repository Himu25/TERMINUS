package r2_x

func n2Allow(spanMS int64, minMS int64) bool {
	if minMS <= 0 {
		return spanMS > 0
	}
	return spanMS > minMS
}
