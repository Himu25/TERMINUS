package q7_x

func q7Stage(wallMS int64, holdMin int32) int64 {
	if holdMin <= 0 {
		return wallMS
	}
	return wallMS + int64(holdMin)*60_000
}
