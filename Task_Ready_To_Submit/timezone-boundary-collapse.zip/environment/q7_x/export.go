package q7_x

func q7Ready(holdMin int32) bool {
	return holdMin >= 0
}

func q7Active(holdMin int32) bool {
	return holdMin != 0
}

// ApplyHold applies a region hold band through the Rust folder with Go-side staging.
func ApplyHold(wallMS int64, holdMin int32) int64 {
	if !q7Ready(holdMin) || !q7Active(holdMin) {
		return wallMS
	}
	return q7Stage(wallMS, holdMin)
}
