// Report JSON for /app/output/seed_report.json:
//
// schema_version — string, must be "1"
// run_id — string, echoes active pack name
// window_count — admitted seed windows after clipping
// slot_count — same as window_count (one window per admitted slot)
// boundary_hits — slots whose anchor day ordinal differs between start and end
// leap_flag — true when anchor_leap pack flag is set and Feb 29 ordinal resolves to 60
// dst_clean — false when a dst_spring slot collapses to non-positive span after band fold
// regions_active — regions with at least one admitted slot
// span_band — string, "tight" or "wide" from max admitted span vs span_tight_h
// digest_hex — lowercase hex SHA-256 of run_id|window_count|slot_count|boundary_hits|leap_flag|dst_clean|regions_active|span_band
//
// Root object contains only these keys.
//
// Replay walks each region slots.jsonl row. Fold stored start_ms/end_ms through the
// region offset when utc_label is false; utc_label rows pass through unchanged. When
// dst_spring is true and the region carries dst_hold_min, both ends pass through the
// Rust hold-band folder before day ordinals are taken in UTC. boundary_hits increments
// when start and end ordinals differ. ClampW may trim the end when a window crosses
// gate_hour on the same UTC calendar day. GateS admits windows whose clipped span
// meets min_slot_ms from the pack.
package main

import (
	"log"
	"os"

	"lab.local/seed_planner/internal/driver"
)

func main() {
	if os.Getenv("TB_SEED_FIXTURE") != "1" {
		log.Fatal("TB_SEED_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/seed_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
