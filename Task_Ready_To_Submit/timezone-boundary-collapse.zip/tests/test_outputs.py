"""Verifier for cross-region seed planner replay report."""

import json
import os
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import pytest

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = APP / "data" / "replay"
OUT = APP / "output" / "seed_report.json"
VERIFY_BIN = "/tmp/seed_planner_verify_bin"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)
    subprocess.run(["cp", "/app/bin/seed_planner", VERIFY_BIN], check=True)


def _fold_u(wall: int, utc_label: bool, offset: int) -> int:
    if utc_label:
        return wall
    return wall - offset


def _clamp_w(start: int, end: int, gate_hour: int) -> tuple[int, int]:
    start_dt = datetime.fromtimestamp(start / 1000, tz=timezone.utc)
    end_dt = datetime.fromtimestamp(end / 1000, tz=timezone.utc)
    if start_dt.date() == end_dt.date() and start_dt.hour < gate_hour <= end_dt.hour:
        gate = start_dt.replace(hour=gate_hour, minute=0, second=0, microsecond=0)
        end = int(gate.timestamp() * 1000)
    return start, end


def _gate_s(span: int, min_ms: int) -> bool:
    return span >= min_ms


def _anchor_day(y: int, m: int, d: int) -> int:
    return datetime(y, m, d).timetuple().tm_yday


def _shift_band(wall: int, hold_min: int) -> int:
    return wall - hold_min * 60_000


def _digest_hex(
    run_id: str,
    window_count: int,
    slot_count: int,
    boundary_hits: int,
    leap_flag: bool,
    dst_clean: bool,
    regions_active: int,
    span_band: str,
) -> str:
    lf = "true" if leap_flag else "false"
    dc = "true" if dst_clean else "false"
    got = subprocess.run(
        [
            "/app/bin/digest_cli",
            run_id,
            str(window_count),
            str(slot_count),
            str(boundary_hits),
            lf,
            dc,
            str(regions_active),
            span_band,
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = FIXTURES / pack_name
    pack = json.loads((pack_dir / "seed_pack.json").read_text())
    gate_hour = pack["gate_hour"]
    span_tight = pack["span_tight_h"] * 3_600_000
    min_slot = pack["min_slot_ms"]
    anchor_leap = pack["anchor_leap"]

    window_count = 0
    boundary_hits = 0
    leap_flag = False
    dst_clean = True
    regions_active = 0
    max_span = 0

    for rid in pack["regions"]:
        meta = json.loads((pack_dir / "regions" / rid / "meta.json").read_text())
        offset = meta["offset_ms"]
        hold = meta["dst_hold_min"]
        region_pass = False
        seg = pack_dir / "regions" / rid / "slots.jsonl"
        if not seg.exists():
            continue
        for line in seg.read_text().splitlines():
            if not line.strip():
                continue
            slot = json.loads(line)
            s = _fold_u(slot["start_ms"], slot["utc_label"], offset)
            e = _fold_u(slot["end_ms"], slot["utc_label"], offset)
            if slot.get("dst_spring") and hold > 0:
                s = _shift_band(s, hold)
                e = _shift_band(e, hold)
            start_dt = datetime.fromtimestamp(s / 1000, tz=timezone.utc)
            end_dt = datetime.fromtimestamp(e / 1000, tz=timezone.utc)
            if _anchor_day(start_dt.year, start_dt.month, start_dt.day) != _anchor_day(
                end_dt.year, end_dt.month, end_dt.day
            ):
                boundary_hits += 1
            if anchor_leap and start_dt.month == 2 and start_dt.day == 29:
                if _anchor_day(start_dt.year, 2, 29) == 60:
                    leap_flag = True
            s, e = _clamp_w(s, e, gate_hour)
            span = e - s
            if slot.get("dst_spring") and hold > 0 and span <= 0:
                dst_clean = False
            if _gate_s(span, min_slot):
                window_count += 1
                region_pass = True
                if span > max_span:
                    max_span = span
        if region_pass:
            regions_active += 1

    span_band = "tight" if max_span <= span_tight else "wide"
    digest = _digest_hex(
        pack["run_id"],
        window_count,
        window_count,
        boundary_hits,
        leap_flag,
        dst_clean,
        regions_active,
        span_band,
    )
    return {
        "schema_version": "1",
        "run_id": pack["run_id"],
        "window_count": window_count,
        "slot_count": window_count,
        "boundary_hits": boundary_hits,
        "leap_flag": leap_flag,
        "dst_clean": dst_clean,
        "regions_active": regions_active,
        "span_band": span_band,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_SEED_FIXTURE": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_alpha_report_matches_multi_region_replay() -> None:
    """Alpha pack admits both region windows under tight span band."""
    _swap("seed_alpha")
    exp = _expected_from_fixture("seed_alpha")
    got = _run_tool()
    assert got == exp


def test_beta_report_matches_spring_gap_replay() -> None:
    """Beta pack folds the spring-gap slot through dst_hold_min band correction."""
    _swap("seed_beta")
    exp = _expected_from_fixture("seed_beta")
    got = _run_tool()
    assert got == exp


def test_gamma_report_matches_utc_local_mix() -> None:
    """Gamma pack admits utc_label and offset-encoded rows together."""
    _swap("seed_gamma")
    exp = _expected_from_fixture("seed_gamma")
    got = _run_tool()
    assert got == exp


def test_delta_leap_flag_on_feb29_anchor() -> None:
    """Delta pack sets leap_flag when anchor_leap is true and Feb 29 ordinal is 60."""
    _swap("seed_delta")
    exp = _expected_from_fixture("seed_delta")
    got = _run_tool()
    assert got == exp


def test_epsilon_gate_hour_clip_rejects_short_window() -> None:
    """Epsilon pack drops the slot when gate_hour clip leaves span below min_slot_ms."""
    _swap("seed_epsilon")
    exp = _expected_from_fixture("seed_epsilon")
    got = _run_tool()
    assert got == exp


def test_zeta_exact_min_span_admitted() -> None:
    """Zeta pack admits a slot whose clipped span equals min_slot_ms."""
    _swap("seed_zeta")
    exp = _expected_from_fixture("seed_zeta")
    got = _run_tool()
    assert got == exp


def test_go_subsystem_tests_pass() -> None:
    """Go unit tests under /app should pass after the repair."""
    env = {**os.environ, "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run(["go", "test", "./..."], cwd="/app", env=env, check=True)
