package main

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"

	"lab.local/grad_compress_tradeoff/internal/config"
	"lab.local/grad_compress_tradeoff/pkg/digest"
	"lab.local/grad_compress_tradeoff/pkg/trace"
)

func opK(values []float64, keep int) []int {
	type pair struct {
		i int
		v float64
	}
	pairs := make([]pair, len(values))
	for i, v := range values {
		pairs[i] = pair{i, v}
	}
	for i := 0; i < len(pairs); i++ {
		for j := i + 1; j < len(pairs); j++ {
			if math.Abs(pairs[j].v) > math.Abs(pairs[i].v) {
				pairs[i], pairs[j] = pairs[j], pairs[i]
			}
		}
	}
	if keep > len(pairs) {
		keep = len(pairs)
	}
	out := make([]int, keep)
	for i := 0; i < keep; i++ {
		out[i] = pairs[i].i
	}
	return out
}

func replay(pack config.Pack, streams map[string][]trace.Row) map[string]any {
	dim := pack.Dim
	keep := int(math.Ceil(float64(dim) * pack.KeepRatio))
	if keep < 1 {
		keep = 1
	}
	w := make([]float64, dim)
	carry := make([]float64, dim)
	wire := 0
	peak := 0.0
	recoveries := 0
	committed := 0

	byOrigin := map[int][]struct {
		wid string
		row trace.Row
	}{}
	for wid, rows := range streams {
		for _, row := range rows {
			byOrigin[row.Round] = append(byOrigin[row.Round], struct {
				wid string
				row trace.Row
			}{wid, row})
		}
	}

	for round := 1; round <= pack.MaxRound; round++ {
		if len(config.MissingAt(pack, round)) > 0 {
			recoveries++
			committed = committed
			continue
		}
		rows := byOrigin[round]
		present := map[string]struct{}{}
		for _, item := range rows {
			if item.row.Lag <= pack.LagAllow {
				present[item.wid] = struct{}{}
			}
		}
		if len(present) < len(pack.Workers) {
			recoveries++
			continue
		}
		var grads [][]float64
		for _, item := range rows {
			if item.row.Lag > pack.LagAllow {
				continue
			}
			vals := item.row.Values
			idxs := opK(vals, keep)
			restored := make([]float64, dim)
			for _, ix := range idxs {
				if ix >= 0 && ix < dim {
					restored[ix] = vals[ix]
				}
			}
			for i := range vals {
				if i < dim {
					carry[i] += vals[i] - restored[i]
				}
			}
			wire += len(idxs) * 12
			decay := 1.0
			if item.row.Lag > 0 {
				decay = 1.0 / float64(1+item.row.Lag)
			}
			for i := range restored {
				restored[i] *= decay
			}
			grads = append(grads, restored)
		}
		if len(grads) < len(pack.Workers) {
			recoveries++
			continue
		}
		merged := make([]float64, dim)
		for _, g := range grads {
			for i := range merged {
				merged[i] += g[i]
			}
		}
		inv := 1.0 / float64(len(grads))
		for i := range merged {
			merged[i] = merged[i]*inv + carry[i]
		}
		norm := 0.0
		for _, x := range merged {
			norm += x * x
		}
		norm = math.Sqrt(norm)
		if norm > peak {
			peak = norm
		}
		scale := 1.0
		if norm > pack.NormCap {
			scale = pack.NormCap / norm
		}
		for i := range merged {
			merged[i] *= scale
			w[i] -= pack.StepSize * merged[i]
		}
		committed = round
	}

	loss := 0.0
	for i := range w {
		d := w[i] - pack.Target[i]
		loss += d * d
	}
	loss = 0.5 * loss
	lossR := math.Round(loss*1e6) / 1e6
	peakR := math.Round(peak*1e6) / 1e6
	stable := peakR <= pack.NormCap && !math.IsInf(lossR, 0) && !math.IsNaN(lossR)
	return map[string]any{
		"schema_version":   "1",
		"run_id":           pack.RunID,
		"rounds_committed": committed,
		"bytes_on_wire":    wire,
		"loss_tail":        lossR,
		"peak_norm":        peakR,
		"recovery_count":   recoveries,
		"stable":           stable,
		"digest_hex":       digest.Hex(pack.RunID, committed, wire, lossR, peakR, recoveries, stable),
	}
}

func main() {
	if len(os.Args) != 2 {
		fmt.Fprintln(os.Stderr, "usage: ref_replay <fixture-root>")
		os.Exit(2)
	}
	root := os.Args[1]
	dir := config.ActiveDir{Root: root, Pack: filepath.Join(root, "run_pack.json"), Traces: filepath.Join(root, "traces")}
	pack, streams, err := config.LoadPack(dir)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	out := replay(pack, streams)
	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	_ = enc.Encode(out)
}
