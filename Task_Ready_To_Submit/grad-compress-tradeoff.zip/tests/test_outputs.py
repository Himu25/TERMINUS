"""Verifier for four-worker gradient compression replay report."""

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = Path("/tests") / "fixtures"
OUT = APP / "output" / "sync_report.json"
GO_BIN = "/usr/local/go/bin/go"
AGENT_BIN = "/app/bin/grad_replay"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    ref_src = Path("/tests/tools/ref_replay")
    ref_dst = Path("/app/tools/ref_replay")
    if ref_src.is_dir():
        ref_dst.mkdir(parents=True, exist_ok=True)
        shutil.copytree(ref_src, ref_dst, dirs_exist_ok=True)
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _digest_hex(
    run_id: str,
    committed: int,
    wire: int,
    loss: float,
    peak: float,
    recoveries: int,
    stable: bool,
) -> str:
    ck = "true" if stable else "false"
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/gen_digest",
            run_id,
            str(committed),
            str(wire),
            f"{loss:.6f}",
            f"{peak:.6f}",
            str(recoveries),
            ck,
            "-",
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _expected(pack_name: str) -> dict:
    root = FIXTURES / pack_name
    got = subprocess.run(
        [GO_BIN, "run", "-mod=mod", "/app/tools/ref_replay", str(root)],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
        env={**os.environ, "GOFLAGS": "-mod=mod"},
    )
    return json.loads(got.stdout)


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_GRAD_FIXTURE": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([AGENT_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_alpha_report_matches_replay() -> None:
    """Alpha pack should finish all rounds with deterministic replay totals."""
    _swap("pack_alpha")
    exp = _expected("pack_alpha")
    got = _run_tool()
    assert got == exp


def test_beta_sparse_lane_mass() -> None:
    """Beta sparse lanes should keep replay stable with lower tail loss."""
    _swap("pack_beta")
    exp = _expected("pack_beta")
    got = _run_tool()
    assert got == exp
    assert got["loss_tail"] < _expected("pack_alpha")["loss_tail"]


def test_gamma_delayed_rows_fold() -> None:
    """Gamma lagged member rows must still fold into their origin rounds."""
    _swap("pack_gamma")
    exp = _expected("pack_gamma")
    got = _run_tool()
    assert got["rounds_committed"] == exp["rounds_committed"]
    assert got["bytes_on_wire"] == exp["bytes_on_wire"]
    assert abs(got["loss_tail"] - exp["loss_tail"]) < 1e-5


def test_delta_peak_norm_capped() -> None:
    """Delta blast magnitudes must replay with bounded step energy after clipping."""
    _swap("pack_delta")
    exp = _expected("pack_delta")
    got = _run_tool()
    assert got == exp


def test_epsilon_recovery_count() -> None:
    """Epsilon sync fault pack should match reference recovery and commit totals."""
    _swap("pack_epsilon")
    exp = _expected("pack_epsilon")
    got = _run_tool()
    assert got["recovery_count"] == exp["recovery_count"]
    assert got["bytes_on_wire"] == exp["bytes_on_wire"]
    assert got["rounds_committed"] == exp["rounds_committed"]


def test_zeta_digest_matches_fields() -> None:
    """Report digest must match the scalar fold documented in main."""
    _swap("pack_alpha")
    got = _run_tool()
    want = _digest_hex(
        got["run_id"],
        got["rounds_committed"],
        got["bytes_on_wire"],
        got["loss_tail"],
        got["peak_norm"],
        got["recovery_count"],
        got["stable"],
    )
    assert got["digest_hex"] == want


def _go_test_env() -> dict:
    return {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }


def test_go_subsystem_tests_pass() -> None:
    """Go unit tests under /app must pass after the repair."""
    subprocess.run(
        [GO_BIN, "test", "./..."],
        cwd="/app",
        env=_go_test_env(),
        check=True,
    )


def test_lanepick_unit() -> None:
    """lanepick.Pick must select largest-magnitude lanes."""
    subprocess.run(
        [GO_BIN, "test", "-run", "TestPickKeepsLargest", "./internal/lanepick"],
        cwd="/app",
        env=_go_test_env(),
        check=True,
    )


def test_stale_opd_unit() -> None:
    """stale.OpD must admit rows within lag allowance."""
    subprocess.run(
        [GO_BIN, "test", "-run", "TestOpDAcceptsWithinAllow", "./internal/stale"],
        cwd="/app",
        env=_go_test_env(),
        check=True,
    )


def test_recover_opg_unit() -> None:
    """recover.OpG must preserve cursor at lastGood."""
    subprocess.run(
        [GO_BIN, "test", "-run", "TestOpGPreservesCursor", "./internal/recover"],
        cwd="/app",
        env=_go_test_env(),
        check=True,
    )


def test_clipfold_opm_unit() -> None:
    """clipfold.OpM must scale down when norm exceeds cap."""
    subprocess.run(
        [GO_BIN, "test", "-run", "TestOpMClipsDown", "./pkg/clipfold"],
        cwd="/app",
        env=_go_test_env(),
        check=True,
    )


def test_rust_op_k_unit() -> None:
    """Rust op_k must return indices of largest-magnitude entries."""
    subprocess.run(
        [
            "cargo",
            "test",
            "--manifest-path",
            "/app/wirefold/Cargo.toml",
        ],
        cwd="/app",
        env={**os.environ, "CARGO_TARGET_DIR": "/app/output/cargo-target"},
        check=True,
    )
