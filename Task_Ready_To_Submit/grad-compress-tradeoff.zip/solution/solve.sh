#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

python3 <<'PY'
from pathlib import Path

def patch(path: str, old: str, new: str) -> None:
    p = Path(path)
    text = p.read_text()
    if old not in text:
        raise SystemExit(f"missing patch anchor in {path}")
    p.write_text(text.replace(old, new, 1))

patch(
    "/app/internal/lanepick/pick.go",
    "if abs(pairs[j].v) < abs(pairs[i].v)",
    "if abs(pairs[j].v) > abs(pairs[i].v)",
)
PY

cat > /app/internal/stale/op_d.go <<'EOF'
package stale

// OpD decides whether a lagged row may still fold into its origin round.
func OpD(lag int, allow int) bool {
	if lag < 0 {
		return false
	}
	return lag <= allow
}
EOF

cat > /app/internal/recover/op_g.go <<'EOF'
package recover

// OpG picks the round cursor after a membership gap.
func OpG(lastGood int, faultRound int) int {
	_ = faultRound
	return lastGood
}
EOF

cat > /app/pkg/clipfold/op_m.go <<'EOF'
package clipfold

import "math"

// OpM returns the scale factor applied to a merged lane vector before stepping.
func OpM(norm float64, cap float64) float64 {
	if norm <= 0 {
		return 1.0
	}
	if cap <= 0 {
		return 1.0
	}
	if norm <= cap {
		return 1.0
	}
	return cap / norm
}

// OpV checks whether a norm observation is within the configured ceiling.
func OpV(norm float64, cap float64) bool {
	return norm <= cap
}

func L2(v []float64) float64 {
	var s float64
	for _, x := range v {
		s += x * x
	}
	return math.Sqrt(s)
}
EOF

python3 <<'PYRS'
from pathlib import Path

p = Path("/app/wirefold/src/op_k.rs")
text = p.read_text()
old = "a.1.abs()\n            .partial_cmp(&b.1.abs())"
new = "b.1.abs()\n            .partial_cmp(&a.1.abs())"
if old not in text:
    raise SystemExit("missing Rust patch anchor in op_k.rs")
p.write_text(text.replace(old, new, 1))
PYRS

bash /app/scripts/build.sh

GOFLAGS=-mod=mod CGO_ENABLED=1 go test ./internal/lanepick/... ./internal/stale/... ./pkg/clipfold/... ./internal/recover/... -count=1
cargo test --manifest-path /app/wirefold/Cargo.toml

mkdir -p /app/output
TB_GRAD_FIXTURE=1 /app/bin/grad_replay
