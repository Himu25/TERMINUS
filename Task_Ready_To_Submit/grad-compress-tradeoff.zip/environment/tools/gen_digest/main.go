package main

import (
	"fmt"
	"os"
	"strconv"

	"lab.local/grad_compress_tradeoff/pkg/digest"
)

func main() {
	if len(os.Args) < 9 {
		fmt.Fprintln(os.Stderr, "usage: gen_digest run_id committed wire loss peak recoveries stable ignored")
		os.Exit(2)
	}
	committed, _ := strconv.Atoi(os.Args[2])
	wire, _ := strconv.Atoi(os.Args[3])
	loss, _ := strconv.ParseFloat(os.Args[4], 64)
	peak, _ := strconv.ParseFloat(os.Args[5], 64)
	recoveries, _ := strconv.Atoi(os.Args[6])
	stable := os.Args[7] == "true"
	fmt.Print(digest.Hex(os.Args[1], committed, wire, loss, peak, recoveries, stable))
}
