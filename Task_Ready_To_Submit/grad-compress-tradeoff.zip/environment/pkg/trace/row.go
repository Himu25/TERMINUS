package trace

// Row is one member lane submission from a jsonl stream.
type Row struct {
	Round  int       `json:"round"`
	Lag    int       `json:"lag"`
	Values []float64 `json:"values"`
}
