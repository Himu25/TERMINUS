package digest

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
)

// Hex folds report scalars into a lowercase sha256 hex string.
func Hex(runID string, committed int, wire int, loss float64, peak float64, recoveries int, stable bool) string {
	st := "false"
	if stable {
		st = "true"
	}
	raw := fmt.Sprintf("%s|%d|%d|%.6f|%.6f|%d|%s", runID, committed, wire, loss, peak, recoveries, st)
	sum := sha256.Sum256([]byte(raw))
	return hex.EncodeToString(sum[:])
}
