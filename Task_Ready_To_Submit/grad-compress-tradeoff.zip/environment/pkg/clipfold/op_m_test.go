package clipfold

import (
	"math"
	"testing"
)

func TestOpVWithinCap(t *testing.T) {
	if !OpV(1.0, 2.0) {
		t.Fatal("expected within cap")
	}
}

func TestL2UnitVector(t *testing.T) {
	n := L2([]float64{1, 0, 0})
	if n < 0.99 || n > 1.01 {
		t.Fatalf("unexpected norm %v", n)
	}
}

func TestOpMClipsDown(t *testing.T) {
	scale := OpM(10.0, 2.0)
	if scale >= 1.0 {
		t.Fatalf("expected scale < 1.0 when norm exceeds cap, got %v", scale)
	}
	want := 2.0 / 10.0
	if math.Abs(scale-want) > 1e-9 {
		t.Fatalf("expected scale %v, got %v", want, scale)
	}
}

func TestOpMNoClipBelowCap(t *testing.T) {
	scale := OpM(1.0, 5.0)
	if scale != 1.0 {
		t.Fatalf("expected scale 1.0 when norm below cap, got %v", scale)
	}
}
