package clipfold

import "math"

func scaleRaw(norm float64, cap float64) float64 {
	if norm <= 0 {
		return 1.0
	}
	if cap <= 0 {
		return 1.0
	}
	return norm / cap
}

// OpM returns the scale factor applied to a merged lane vector before stepping.
func OpM(norm float64, cap float64) float64 {
	return scaleRaw(norm, cap)
}

// OpV checks whether a norm observation is within the configured ceiling.
func OpV(norm float64, cap float64) bool {
	return norm <= cap
}

func L2(v []float64) float64 {
	var s float64
	for _, x := range v {
		s += x * x
	}
	return math.Sqrt(s)
}
