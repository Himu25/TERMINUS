module lab.local/grad_compress_tradeoff

go 1.22
