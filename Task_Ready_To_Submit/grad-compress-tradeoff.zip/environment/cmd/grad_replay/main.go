// Outward report written to /app/output/sync_report.json.
//
// schema_version — string label for report version
// run_id — string, echoes active pack name
// rounds_committed — highest fully admitted round index
// bytes_on_wire — twelve bytes per kept lane index/value pair sent
// loss_tail — half squared L2 distance between final weights and pack target
// peak_norm — maximum pre-clip merged lane L2 norm observed
// recovery_count — membership gap rewinds counted
// stable — boolean; true when peak_norm <= norm_cap and loss is finite
// digest_hex — lowercase hex SHA-256 of run_id|rounds_committed|bytes_on_wire|loss_tail|peak_norm|recovery_count|stable
package main

import (
	"log"
	"os"

	"lab.local/grad_compress_tradeoff/internal/driver"
)

func main() {
	if os.Getenv("TB_GRAD_FIXTURE") != "1" {
		log.Fatal("TB_GRAD_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/sync_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
