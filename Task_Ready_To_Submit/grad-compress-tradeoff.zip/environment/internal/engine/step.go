package engine

import (
	"lab.local/grad_compress_tradeoff/pkg/clipfold"
)

func applyStep(merged []float64, stepSize float64, normCap float64) (peak float64) {
	norm := clipfold.L2(merged)
	peak = norm
	scale := clipfold.OpM(norm, normCap)
	for i := range merged {
		merged[i] *= scale
	}
	for i := range merged {
		merged[i] *= stepSize
	}
	return peak
}

func mergeLanes(memberGrads [][]float64, carry []float64, dim int) []float64 {
	merged := make([]float64, dim)
	for _, g := range memberGrads {
		for i := range merged {
			merged[i] += g[i]
		}
	}
	if len(memberGrads) == 0 {
		return merged
	}
	inv := 1.0 / float64(len(memberGrads))
	for i := range merged {
		merged[i] = (merged[i] * inv) + carry[i]
	}
	return merged
}

func subtractStep(w []float64, step []float64) {
	for i := range w {
		w[i] -= step[i]
	}
}
