package engine

import (
	"lab.local/grad_compress_tradeoff/internal/lanepick"
	"lab.local/grad_compress_tradeoff/internal/stale"
	"lab.local/grad_compress_tradeoff/pkg/trace"
)

func foldMemberRows(rows []memberRow, keep int, dim int, carry []float64, lagAllow int) ([][]float64, int, []float64) {
	var memberGrads [][]float64
	var wire int
	outCarry := append([]float64(nil), carry...)
	for _, item := range rows {
		if !stale.OpD(item.row.Lag, lagAllow) {
			continue
		}
		restored, sent, residual := compressRound(item.row.Values, keep, dim)
		wire += sent
		decay := stale.OpS(item.row.Lag)
		for i := range restored {
			restored[i] *= decay
		}
		for i := range outCarry {
			outCarry[i] += residual[i]
		}
		memberGrads = append(memberGrads, restored)
	}
	return memberGrads, wire, outCarry
}

func compressRound(values []float64, keep int, dim int) (restored []float64, sent int, residual []float64) {
	restored = make([]float64, dim)
	residual = make([]float64, len(values))
	copy(residual, values)
	idx, vals, sent := lanepick.Pick(values, keep)
	for i, v := range vals {
		pos := idx[i]
		if pos >= 0 && pos < dim {
			restored[pos] = v
			residual[pos] = values[pos] - v
		}
	}
	return restored, sent, residual
}

func rowsForRound(byOrigin map[int][]memberRow, round int) []memberRow {
	return byOrigin[round]
}

func rowLag(r trace.Row) int {
	return r.Lag
}
