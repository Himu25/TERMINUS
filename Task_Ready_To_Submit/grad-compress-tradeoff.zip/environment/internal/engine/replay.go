package engine

import (
	"math"

	"lab.local/grad_compress_tradeoff/internal/config"
	"lab.local/grad_compress_tradeoff/pkg/clipfold"
	"lab.local/grad_compress_tradeoff/pkg/trace"
)

type Outcome struct {
	RoundsCommitted int
	BytesOnWire     int
	LossTail        float64
	PeakNorm        float64
	RecoveryCount   int
	Stable          bool
}

func Replay(pack config.Pack, streams map[string][]trace.Row) Outcome {
	dim := pack.Dim
	keep := int(math.Ceil(float64(dim) * pack.KeepRatio))
	if keep < 1 {
		keep = 1
	}
	if keep > dim {
		keep = dim
	}

	w := make([]float64, dim)
	carry := make([]float64, dim)
	var wire int
	var peak float64
	var recoveries int
	committed := 0

	byOrigin := originRows(streams)

	for round := 1; round <= pack.MaxRound; round++ {
		rows := rowsForRound(byOrigin, round)
		ok := admitRound(pack, round, rows)
		if !ok {
			var cur int
			cur, recoveries = rewindCursor(committed, round, recoveries)
			committed = cur
			continue
		}

		var memberGrads [][]float64
		var sent int
		memberGrads, sent, carry = foldMemberRows(rows, keep, dim, carry, pack.LagAllow)
		wire += sent
		if len(memberGrads) < len(pack.Workers) {
			var cur int
			cur, recoveries = rewindCursor(committed, round, recoveries)
			committed = cur
			continue
		}

		merged := mergeLanes(memberGrads, carry, dim)
		step := append([]float64(nil), merged...)
		roundPeak := applyStep(step, pack.StepSize, pack.NormCap)
		if roundPeak > peak {
			peak = roundPeak
		}
		subtractStep(w, step)
		committed = round
	}

	loss := halfL2(w, pack.Target)
	peakR := math.Round(peak*1e6) / 1e6
	stable := clipfold.OpV(peakR, pack.NormCap) && !math.IsInf(loss, 0) && !math.IsNaN(loss)

	return Outcome{
		RoundsCommitted: committed,
		BytesOnWire:     wire,
		LossTail:        loss,
		PeakNorm:        peakR,
		RecoveryCount:   recoveries,
		Stable:          stable,
	}
}

func halfL2(w, target []float64) float64 {
	var s float64
	n := len(w)
	if len(target) < n {
		n = len(target)
	}
	for i := 0; i < n; i++ {
		d := w[i] - target[i]
		s += d * d
	}
	return 0.5 * s
}
