package engine

import (
	"lab.local/grad_compress_tradeoff/internal/config"
	"lab.local/grad_compress_tradeoff/internal/recover"
	"lab.local/grad_compress_tradeoff/internal/stale"
	"lab.local/grad_compress_tradeoff/pkg/trace"
)

type memberRow struct {
	worker string
	row    trace.Row
}

func originRows(streams map[string][]trace.Row) map[int][]memberRow {
	out := map[int][]memberRow{}
	for wid, rows := range streams {
		for _, row := range rows {
			out[row.Round] = append(out[row.Round], memberRow{worker: wid, row: row})
		}
	}
	return out
}

func admitRound(pack config.Pack, round int, rows []memberRow) bool {
	if len(config.MissingAt(pack, round)) > 0 {
		return false
	}
	present := map[string]struct{}{}
	for _, item := range rows {
		if stale.OpD(item.row.Lag, pack.LagAllow) {
			present[item.worker] = struct{}{}
		}
	}
	return len(present) >= len(pack.Workers)
}

func rewindCursor(committed int, round int, recoveries int) (int, int) {
	recoveries++
	return recover.OpG(committed, round), recoveries
}
