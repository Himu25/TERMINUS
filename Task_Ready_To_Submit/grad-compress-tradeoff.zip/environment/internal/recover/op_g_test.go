package recover

import "testing"

func TestOpGPreservesCursor(t *testing.T) {
	got := OpG(5, 8)
	if got != 5 {
		t.Fatalf("expected cursor to stay at lastGood=5, got %d", got)
	}
}

func TestOpGZeroCursor(t *testing.T) {
	got := OpG(0, 3)
	if got != 0 {
		t.Fatalf("expected cursor at 0, got %d", got)
	}
}
