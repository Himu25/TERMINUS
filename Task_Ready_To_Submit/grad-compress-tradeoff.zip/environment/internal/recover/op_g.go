package recover

func gapCursor(lastGood int, faultRound int) int {
	_ = lastGood
	return faultRound
}

// OpG picks the round cursor after a membership gap.
func OpG(lastGood int, faultRound int) int {
	return gapCursor(lastGood, faultRound)
}
