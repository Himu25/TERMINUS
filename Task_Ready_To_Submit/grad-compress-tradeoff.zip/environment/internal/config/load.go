package config

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"lab.local/grad_compress_tradeoff/pkg/trace"
)

type Fault struct {
	Round   int      `json:"round"`
	Missing []string `json:"missing"`
}

type Pack struct {
	RunID      string    `json:"run_id"`
	Dim        int       `json:"dim"`
	KeepRatio  float64   `json:"keep_ratio"`
	StepSize   float64   `json:"step_size"`
	NormCap    float64   `json:"norm_cap"`
	LagAllow   int       `json:"lag_allow"`
	Target     []float64 `json:"target"`
	Workers    []string  `json:"workers"`
	MaxRound   int       `json:"max_round"`
	SyncFaults []Fault   `json:"sync_faults"`
}

type ActiveDir struct {
	Root    string
	Pack    string
	Traces  string
}

func ActivePaths(appRoot string) (ActiveDir, error) {
	root := filepath.Join(appRoot, "data", "active")
	return ActiveDir{
		Root:   root,
		Pack:   filepath.Join(root, "run_pack.json"),
		Traces: filepath.Join(root, "traces"),
	}, nil
}

func LoadPack(dir ActiveDir) (Pack, map[string][]trace.Row, error) {
	raw, err := os.ReadFile(dir.Pack)
	if err != nil {
		return Pack{}, nil, err
	}
	var pack Pack
	if err := json.Unmarshal(raw, &pack); err != nil {
		return Pack{}, nil, err
	}
	streams := map[string][]trace.Row{}
	for _, wid := range pack.Workers {
		path := filepath.Join(dir.Traces, wid, "stream.jsonl")
		rows, err := readJSONL(path)
		if err != nil {
			return Pack{}, nil, fmt.Errorf("worker %s: %w", wid, err)
		}
		streams[wid] = rows
	}
	return pack, streams, nil
}

func readJSONL(path string) ([]trace.Row, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var out []trace.Row
	for _, line := range splitLines(string(data)) {
		if line == "" {
			continue
		}
		var row trace.Row
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return nil, err
		}
		out = append(out, row)
	}
	return out, nil
}

func splitLines(s string) []string {
	var lines []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			lines = append(lines, s[start:i])
			start = i + 1
		}
	}
	if start < len(s) {
		lines = append(lines, s[start:])
	}
	return lines
}

func MissingAt(pack Pack, round int) map[string]struct{} {
	out := map[string]struct{}{}
	for _, f := range pack.SyncFaults {
		if f.Round != round {
			continue
		}
		for _, m := range f.Missing {
			out[m] = struct{}{}
		}
	}
	return out
}
