package lanepick

// Pick retains keep lane index/value pairs from a dense vector.
func Pick(values []float64, keep int) (indices []int, vals []float64, wireBytes int) {
	if len(values) == 0 || keep <= 0 {
		return nil, nil, 0
	}
	type pair struct {
		i int
		v float64
	}
	pairs := make([]pair, len(values))
	for i, v := range values {
		pairs[i] = pair{i, v}
	}
	for i := 0; i < len(pairs); i++ {
		for j := i + 1; j < len(pairs); j++ {
			if abs(pairs[j].v) < abs(pairs[i].v) {
				pairs[i], pairs[j] = pairs[j], pairs[i]
			}
		}
	}
	if keep > len(pairs) {
		keep = len(pairs)
	}
	indices = make([]int, keep)
	vals = make([]float64, keep)
	for i := 0; i < keep; i++ {
		indices[i] = pairs[i].i
		vals[i] = pairs[i].v
	}
	return indices, vals, keep * 12
}

func abs(v float64) float64 {
	if v < 0 {
		return -v
	}
	return v
}
