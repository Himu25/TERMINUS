package lanepick

import "testing"

func TestPickKeepsLargest(t *testing.T) {
	vals := []float64{0.1, -5.0, 0.2, 3.0}
	idx, picked, _ := Pick(vals, 2)
	got := map[int]float64{}
	for i := range idx {
		got[idx[i]] = picked[i]
	}
	if _, ok := got[1]; !ok {
		t.Fatalf("expected index 1 (-5.0) in top-2, got indices %v", idx)
	}
	if _, ok := got[3]; !ok {
		t.Fatalf("expected index 3 (3.0) in top-2, got indices %v", idx)
	}
}

func TestPickWireBytes(t *testing.T) {
	vals := []float64{1.0, 2.0, 3.0, 4.0, 5.0}
	_, _, wire := Pick(vals, 3)
	if wire != 3*12 {
		t.Fatalf("expected wire bytes %d, got %d", 3*12, wire)
	}
}
