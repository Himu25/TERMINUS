package stale

// OpS maps wall lag to a decay weight for bookkeeping displays.
func OpS(lag int) float64 {
	if lag <= 0 {
		return 1.0
	}
	return 1.0 / float64(1+lag)
}
