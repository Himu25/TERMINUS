package stale

import "testing"

func TestOpSIdentityAtZero(t *testing.T) {
	if OpS(0) != 1.0 {
		t.Fatalf("expected 1.0 at zero lag")
	}
}

func TestOpSDecayPositive(t *testing.T) {
	if OpS(2) >= OpS(1) {
		t.Fatalf("expected decay to shrink with lag")
	}
}
