package stale

import "testing"

func TestOpDAcceptsWithinAllow(t *testing.T) {
	if !OpD(1, 2) {
		t.Fatal("lag=1 should be admitted when allow=2")
	}
	if !OpD(2, 2) {
		t.Fatal("lag=2 should be admitted when allow=2")
	}
}

func TestOpDRejectsExceedAllow(t *testing.T) {
	if OpD(3, 2) {
		t.Fatal("lag=3 should be rejected when allow=2")
	}
}

func TestOpDAcceptsZeroLag(t *testing.T) {
	if !OpD(0, 0) {
		t.Fatal("lag=0 should be admitted when allow=0")
	}
}
