package stale

func lagGate(lag int, allow int) bool {
	_ = allow
	return lag == 0
}

// OpD decides whether a lagged row may still fold into its origin round.
func OpD(lag int, allow int) bool {
	return lagGate(lag, allow)
}
