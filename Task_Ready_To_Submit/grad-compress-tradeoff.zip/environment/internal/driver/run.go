package driver

import (
	"encoding/json"
	"math"
	"os"

	"lab.local/grad_compress_tradeoff/internal/config"
	"lab.local/grad_compress_tradeoff/internal/engine"
	"lab.local/grad_compress_tradeoff/pkg/digest"
)

type Report struct {
	SchemaVersion   string  `json:"schema_version"`
	RunID           string  `json:"run_id"`
	RoundsCommitted int     `json:"rounds_committed"`
	BytesOnWire     int     `json:"bytes_on_wire"`
	LossTail        float64 `json:"loss_tail"`
	PeakNorm        float64 `json:"peak_norm"`
	RecoveryCount   int     `json:"recovery_count"`
	Stable          bool    `json:"stable"`
	DigestHex       string  `json:"digest_hex"`
}

func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	pack, streams, err := config.LoadPack(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(pack, streams)
	loss := math.Round(out.LossTail*1e6) / 1e6
	peak := math.Round(out.PeakNorm*1e6) / 1e6
	dig := digest.Hex(
		pack.RunID,
		out.RoundsCommitted,
		out.BytesOnWire,
		loss,
		peak,
		out.RecoveryCount,
		out.Stable,
	)
	return Report{
		SchemaVersion:   "1",
		RunID:           pack.RunID,
		RoundsCommitted: out.RoundsCommitted,
		BytesOnWire:     out.BytesOnWire,
		LossTail:        loss,
		PeakNorm:        peak,
		RecoveryCount:   out.RecoveryCount,
		Stable:          out.Stable,
		DigestHex:       dig,
	}, nil
}

func EmitReport(path string, rep Report) error {
	if err := os.MkdirAll("/app/output", 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}
