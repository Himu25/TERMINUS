package wirefold

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libwirefold.a -ldl -lm
#include "lane_gate.h"
*/
import "C"
import "unsafe"

const wireEntryBytes = 12

// PickLanes reduces a dense lane vector to the kept sparse pairs.
func PickLanes(values []float64, keep int) (indices []int, vals []float64, sent int) {
	if len(values) == 0 || keep <= 0 {
		return nil, nil, 0
	}
	outIdx := make([]C.uint, len(values))
	outVal := make([]C.double, len(values))
	n := int(C.cg_pick_lanes(
		(*C.double)(unsafe.Pointer(&values[0])),
		C.size_t(len(values)),
		C.size_t(keep),
		&outIdx[0],
		&outVal[0],
	))
	indices = make([]int, n)
	vals = make([]float64, n)
	for i := 0; i < n; i++ {
		indices[i] = int(outIdx[i])
		vals[i] = float64(outVal[i])
	}
	return indices, vals, n * wireEntryBytes
}

// WireTag returns a transport checksum for bookkeeping.
func WireTag(payload []byte) uint32 {
	if len(payload) == 0 {
		return 0
	}
	return uint32(C.cg_wire_tag((*C.uchar)(unsafe.Pointer(&payload[0])), C.size_t(len(payload))))
}
