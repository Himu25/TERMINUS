#pragma once

#include <stddef.h>

size_t cg_pick_lanes(const double *values, size_t len, size_t keep, unsigned *out_idx, double *out_val);
unsigned cg_wire_tag(const unsigned char *data, size_t len);
