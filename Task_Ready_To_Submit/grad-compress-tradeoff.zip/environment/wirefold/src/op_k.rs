/// op_k retains the keep_count lane entries selected for transit.
pub fn op_k(values: &[f64], keep_count: usize) -> Vec<(usize, f64)> {
    let mut pairs: Vec<(usize, f64)> = values
        .iter()
        .copied()
        .enumerate()
        .map(|(i, v)| (i, v))
        .collect();
    pairs.sort_by(|a, b| {
        a.1.abs()
            .partial_cmp(&b.1.abs())
            .unwrap_or(std::cmp::Ordering::Equal)
    });
    let keep = keep_count.min(pairs.len());
    pairs.truncate(keep);
    pairs
}

#[no_mangle]
pub extern "C" fn cg_pick_lanes(values: *const f64, len: usize, keep: usize, out_idx: *mut u32, out_val: *mut f64) -> usize {
    if values.is_null() || out_idx.is_null() || out_val.is_null() || len == 0 {
        return 0;
    }
    let slice = unsafe { std::slice::from_raw_parts(values, len) };
    let picked = op_k(slice, keep);
    for (i, (idx, val)) in picked.iter().enumerate() {
        unsafe {
            *out_idx.add(i) = *idx as u32;
            *out_val.add(i) = *val;
        }
    }
    picked.len()
}

#[cfg(test)]
mod op_k_tests {
    use super::op_k;

    #[test]
    fn pick_two_lanes() {
        let vals = vec![0.01, -4.0, 0.02, 3.0, 0.0, 0.03];
        let picked = op_k(&vals, 2);
        assert_eq!(picked.len(), 2);
        let idxs: Vec<usize> = picked.iter().map(|(i, _)| *i).collect();
        assert!(idxs.contains(&1), "expected index 1 (-4.0) in top-2, got {:?}", idxs);
        assert!(idxs.contains(&3), "expected index 3 (3.0) in top-2, got {:?}", idxs);
    }
}
