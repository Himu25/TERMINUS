/// op_h folds lane bytes into a wire tag for transport bookkeeping.
pub fn op_h(data: &[u8]) -> u32 {
    let mut acc: u32 = 0;
    for (i, b) in data.iter().enumerate() {
        acc ^= (*b as u32).wrapping_shl((i % 4) as u32 * 8);
    }
    acc
}

#[no_mangle]
pub extern "C" fn cg_wire_tag(data: *const u8, len: usize) -> u32 {
    if data.is_null() || len == 0 {
        return 0;
    }
    let slice = unsafe { std::slice::from_raw_parts(data, len) };
    op_h(slice)
}
