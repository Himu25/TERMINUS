#!/usr/bin/env bash
set -euo pipefail

log() { printf '[oracle] %s\n' "$1"; }

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

log "preflight: adaptive eval subset picker workspace"
test -f /app/go.mod
test -f /app/config/subset.toml
test -f /app/cmd/subset_bench/main.go
test -f /app/docs/replay_index.txt
test -f /app/data/active/eval_bundle.json
test -x /app/bin/subset_bench
mkdir -p /app/output

log "survey: audit contract and replay pack index"
sed -n '1,12p' /app/cmd/subset_bench/main.go
cat /app/docs/replay_index.txt

log "survey: stratum and rollup folding call sites"
cat /app/internal/metrics/block.go
grep -nE 'opRow|opQuota|scratchValidate|reconcileBlock' /app/internal/metrics/rollup.go

log "survey: rankstab cgo exports"
grep -nE 'kendall|seed_agree|signum|stable' /app/rankstab/src/lib.rs

log "baseline: rollup unit tests before repair (failures expected)"
set +e
GOFLAGS=-mod=mod CGO_ENABLED=1 go test ./internal/metrics/... -count=1
baseline_test_rc=$?
set -e
if [ "$baseline_test_rc" -eq 0 ]; then
  log "warning: baseline rollup tests passed unexpectedly"
fi

log "baseline: active pack replay before repair"
rm -f /app/output/subset_audit.json
TB_SUBSET_FIXTURE=1 /app/bin/subset_bench
python3 - <<'PY'
import json

report = json.load(open("/app/output/subset_audit.json"))
print(
    "baseline overfit_guard_band:",
    report.get("overfit_guard_band"),
    "stratum_coverage_pct:",
    report.get("stratum_coverage_pct"),
)
PY

write_block() {
  cat > /app/internal/metrics/block.go <<'EOF'
package metrics

import "lab.local/adaptive_eval_subset_pick/pkg/stratify"

func opQuota(picked, total, floorPct int) bool {
	if total == 0 {
		return true
	}
	return stratify.OpS(picked, total, floorPct)
}

func opQuotaPct(strataTotal, strataOK int) int {
	if strataTotal == 0 {
		return 0
	}
	return (strataOK * 100) / strataTotal
}
EOF
}

write_rollup() {
  cat > /app/internal/metrics/rollup.go <<'EOF'
package metrics

import (
	"lab.local/adaptive_eval_subset_pick/internal/config"
	"lab.local/adaptive_eval_subset_pick/internal/raregate"
	"lab.local/adaptive_eval_subset_pick/pkg/budgetgate"
	"lab.local/adaptive_eval_subset_pick/rankstab"
)

// Block holds folded audit counters before guard-band selection.
type Block struct {
	StratumCoveragePct int
	RareTaskRecallPct  int
	KendallTauX100     int
	SeedStabilityPct   int
	CostReductionPct   int
}

// Inputs carries per-pack aggregates assembled by the replay driver.
type Inputs struct {
	StrataTotal  map[int]int
	StrataPicked map[int]int
	RareTotal    int
	RareCounted  int
	PickedCost   int
	FullCost     int
	FullRanks    []int32
	SubRanks     []int32
	SeedIDs      []int32
	RankFlat     []int32
	PickedCount  int
	SeedCount    int
}

func opRowM(isRare, picked int) bool {
	return raregate.OpR(isRare, picked)
}

func opRowP(pickedCost, fullCost int) int {
	return budgetgate.OpB(pickedCost, fullCost)
}

func opRowK(full, subset []int32) int32 {
	return rankstab.KendallTauX100(full, subset)
}

func opRowL(seeds, ranks []int32, taskCount, seedCount int) int32 {
	return rankstab.SeedAgreePct(seeds, ranks, taskCount, seedCount)
}

func scratchValidate(in Inputs, bundle config.Bundle) bool {
	if in.FullCost <= 0 {
		return false
	}
	if in.PickedCost > in.FullCost {
		return false
	}
	if bundle.StratumFloorPct > 0 && len(in.StrataTotal) == 0 {
		return false
	}
	return in.RareCounted <= in.RareTotal
}

func reconcileBlock(blk Block, bundle config.Bundle) Block {
	if blk.StratumCoveragePct > 100 {
		blk.StratumCoveragePct = 100
	}
	if blk.RareTaskRecallPct > 100 {
		blk.RareTaskRecallPct = 100
	}
	if blk.KendallTauX100 > 100 {
		blk.KendallTauX100 = 100
	}
	if blk.KendallTauX100 < -100 {
		blk.KendallTauX100 = -100
	}
	return blk
}

// OpRowInc is exported for replay row folding.
func OpRowInc(isRare, picked int) bool {
	return opRowM(isRare, picked)
}

// Compute folds one replay block.
func Compute(in Inputs, bundle config.Bundle) Block {
	if !scratchValidate(in, bundle) {
		return Block{}
	}
	strataOK := 0
	for stratum, total := range in.StrataTotal {
		if opQuota(in.StrataPicked[stratum], total, bundle.StratumFloorPct) {
			strataOK++
		}
	}
	stratumCoverage := opQuotaPct(len(in.StrataTotal), strataOK)

	rareRecall := 0
	if in.RareTotal > 0 {
		rareRecall = (in.RareCounted * 100) / in.RareTotal
	}

	tau := int(opRowK(in.FullRanks, in.SubRanks))
	stability := int(opRowL(in.SeedIDs, in.RankFlat, in.PickedCount, in.SeedCount))
	costReduction := opRowP(in.PickedCost, in.FullCost)

	return Block{
		StratumCoveragePct: stratumCoverage,
		RareTaskRecallPct:  rareRecall,
		KendallTauX100:     tau,
		SeedStabilityPct:   stability,
		CostReductionPct:   costReduction,
	}
}

// OpSelMode selects trusted versus leaky from bundle floors and a folded block.
func OpSelMode(bundle config.Bundle, blk Block) string {
	blk = reconcileBlock(blk, bundle)
	if blk.StratumCoveragePct == 100 &&
		blk.RareTaskRecallPct >= bundle.RareFloorPct &&
		blk.KendallTauX100 >= bundle.TauFloorX100 &&
		blk.SeedStabilityPct >= bundle.StabilityFloorPct &&
		blk.CostReductionPct >= bundle.CostTargetPct {
		return "trusted"
	}
	return "leaky"
}
EOF
}

write_rankstab() {
  cat > /app/rankstab/src/lib.rs <<'EOF'
fn pair_sign(a: i32, b: i32) -> i32 {
    (a - b).signum()
}

/// rs_kendall_tau_x100 returns Kendall tau times 100 for paired rank slices.
#[no_mangle]
pub extern "C" fn rs_kendall_tau_x100(full: *const i32, subset: *const i32, n: usize) -> i32 {
    if n < 2 {
        return 100;
    }
    let mut concordant = 0i64;
    let mut discordant = 0i64;
    unsafe {
        for i in 0..n {
            for j in (i + 1)..n {
                let a = pair_sign(*full.add(i), *full.add(j));
                let b = pair_sign(*subset.add(i), *subset.add(j));
                let prod = (a as i64) * (b as i64);
                if prod > 0 {
                    concordant += 1;
                } else if prod < 0 {
                    discordant += 1;
                }
            }
        }
    }
    let denom = concordant + discordant;
    if denom == 0 {
        return 100;
    }
    let tau = (concordant - discordant) as f64 / denom as f64;
    (tau * 100.0).round() as i32
}

/// rs_seed_agree_pct measures cross-seed rank agreement for picked tasks.
#[no_mangle]
pub extern "C" fn rs_seed_agree_pct(
    seeds: *const i32,
    ranks: *const i32,
    task_count: usize,
    seed_count: usize,
) -> i32 {
    if task_count < 2 || seed_count < 2 {
        return 100;
    }
    let mut agree = 0i64;
    let mut total = 0i64;
    unsafe {
        for i in 0..task_count {
            for j in (i + 1)..task_count {
                let mut last_sign = 0i32;
                let mut stable = true;
                for s in 0..seed_count {
                    let base = s * task_count;
                    let a = *ranks.add(base + i);
                    let b = *ranks.add(base + j);
                    let sign = (a - b).signum();
                    if sign == 0 {
                        continue;
                    }
                    if last_sign == 0 {
                        last_sign = sign;
                    } else if sign != last_sign {
                        stable = false;
                        break;
                    }
                }
                total += 1;
                if stable {
                    agree += 1;
                }
                let _ = seeds;
            }
        }
    }
    if total == 0 {
        return 100;
    }
    ((agree * 100) / total) as i32
}
EOF
}

log "repair: stratum quota gate argument order in block.go"
write_block

log "repair: rollup row folding and guard-band reconcile in rollup.go"
write_rollup

log "repair: kendall tau and seed agreement in rankstab"
write_rankstab

log "rebuild subset_bench with CGO rankstab bridge"
bash /app/scripts/build.sh

log "verify: subsystem unit tests after repair"
GOFLAGS=-mod=mod CGO_ENABLED=1 go test ./internal/metrics/... ./pkg/stratify/... ./pkg/budgetgate/... ./internal/raregate/... -count=1

log "verify: replay each pack from replay_index.txt"
for pack in pack_alpha pack_skew pack_rare pack_tau pack_seed; do
  rm -rf /app/data/active
  cp -a "/app/data/replay/${pack}" /app/data/active
  rm -f /app/output/subset_audit.json
  TB_SUBSET_FIXTURE=1 /app/bin/subset_bench
  test -s /app/output/subset_audit.json
done

log "oracle complete"
