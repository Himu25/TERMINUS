"""Verifier for adaptive evaluation subset selection audit."""

import json
import os
import shutil
import subprocess

import pytest
from pathlib import Path

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = APP / "data" / "replay"
OUT = APP / "output" / "subset_audit.json"
GO_BIN = "/usr/local/go/bin/go"
VERIFY_BIN = "/tmp/subset_bench_verify_bin"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)
    subprocess.run(["cp", "/app/bin/subset_bench", VERIFY_BIN], check=True)


def _digest_hex(
    run_id: str,
    full_task_count: int,
    subset_size: int,
    stratum_coverage_pct: int,
    rare_task_recall_pct: int,
    kendall_tau_x100: int,
    seed_stability_pct: int,
    cost_reduction_pct: int,
    overfit_guard_band: str,
) -> str:
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            run_id,
            str(full_task_count),
            str(subset_size),
            str(stratum_coverage_pct),
            str(rare_task_recall_pct),
            str(kendall_tau_x100),
            str(seed_stability_pct),
            str(cost_reduction_pct),
            overfit_guard_band,
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _op_s(picked: int, total: int, floor_pct: int) -> bool:
    if total == 0:
        return True
    return picked * 100 >= total * floor_pct


def _op_r(is_rare: int, picked: int) -> bool:
    if is_rare == 0:
        return True
    return picked == 1


def _kendall_tau_x100(full: list[int], subset: list[int]) -> int:
    n = len(full)
    if n < 2:
        return 100
    concordant = discordant = 0
    for i in range(n):
        for j in range(i + 1, n):
            prod = (full[i] - full[j]) * (subset[i] - subset[j])
            if prod > 0:
                concordant += 1
            elif prod < 0:
                discordant += 1
    denom = concordant + discordant
    if denom == 0:
        return 100
    return int(round((concordant - discordant) / denom * 100))


def _seed_agree_pct(ranks_by_seed: list[list[int]], task_count: int, seed_count: int) -> int:
    if task_count < 2 or seed_count < 2:
        return 100
    agree = total = 0
    for i in range(task_count):
        for j in range(i + 1, task_count):
            last_sign = 0
            stable = True
            for s in range(seed_count):
                a = ranks_by_seed[s][i]
                b = ranks_by_seed[s][j]
                if a == b:
                    continue
                sign = 1 if a > b else -1
                if last_sign == 0:
                    last_sign = sign
                elif sign != last_sign:
                    stable = False
                    break
            total += 1
            if stable:
                agree += 1
    return (agree * 100) // total if total else 100


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = FIXTURES / pack_name
    bundle = json.loads((pack_dir / "eval_bundle.json").read_text())
    rows = []
    for line in (pack_dir / "candidates.jsonl").read_text().splitlines():
        if line.strip():
            rows.append(json.loads(line))
    rows.sort(key=lambda r: (r["task_id"], r["seed"]))

    meta: dict[str, dict] = {}
    seed_ranks: dict[int, dict[str, int]] = {}
    for row in rows:
        tid = row["task_id"]
        if tid not in meta:
            meta[tid] = {
                "stratum": row["stratum"],
                "rare": row["rare"],
                "cost": row["cost"],
                "full_rank": row["full_rank"],
                "picked": row["picked"],
            }
        if row["picked"] == 1:
            meta[tid]["picked"] = 1
        seed_ranks.setdefault(row["seed"], {})[tid] = row["subset_rank"]

    full_count = len(meta)
    subset_size = 0
    full_cost = 0
    picked_cost = 0
    strata_total: dict[int, int] = {}
    strata_picked: dict[int, int] = {}
    rare_total = 0
    rare_counted = 0
    picked_ids: list[str] = []

    for tid, m in meta.items():
        full_cost += m["cost"]
        strata_total[m["stratum"]] = strata_total.get(m["stratum"], 0) + 1
        if m["rare"] == 1:
            rare_total += 1
        if m["picked"] == 1:
            subset_size += 1
            picked_cost += m["cost"]
            picked_ids.append(tid)
            strata_picked[m["stratum"]] = strata_picked.get(m["stratum"], 0) + 1
            if m["rare"] == 1 and _op_r(m["rare"], m["picked"]):
                rare_counted += 1

    strata_ok = 0
    for stratum, total in strata_total.items():
        if _op_s(strata_picked.get(stratum, 0), total, bundle["stratum_floor_pct"]):
            strata_ok += 1
    stratum_coverage = (strata_ok * 100) // len(strata_total) if strata_total else 0

    rare_recall = (rare_counted * 100) // rare_total if rare_total else 100

    picked_ids.sort()
    full_ranks = [meta[i]["full_rank"] for i in picked_ids]
    sub_ranks = [seed_ranks[0][i] for i in picked_ids]
    tau = _kendall_tau_x100(full_ranks, sub_ranks)

    seed_count = bundle["seed_count"] or len(seed_ranks)
    ranks_by_seed = [
        [seed_ranks[s][i] for i in picked_ids] for s in range(seed_count)
    ]
    stability = _seed_agree_pct(ranks_by_seed, len(picked_ids), seed_count)

    cost_reduction = 100 - (picked_cost * 100) // full_cost if full_cost else 0

    band = "leaky"
    if (
        stratum_coverage == 100
        and rare_recall >= bundle["rare_floor_pct"]
        and tau >= bundle["tau_floor_x100"]
        and stability >= bundle["stability_floor_pct"]
        and cost_reduction >= bundle["cost_target_pct"]
    ):
        band = "trusted"

    digest = _digest_hex(
        bundle["run_id"],
        full_count,
        subset_size,
        stratum_coverage,
        rare_recall,
        tau,
        stability,
        cost_reduction,
        band,
    )
    return {
        "schema_version": "1",
        "run_id": bundle["run_id"],
        "full_task_count": full_count,
        "subset_size": subset_size,
        "stratum_coverage_pct": stratum_coverage,
        "rare_task_recall_pct": rare_recall,
        "kendall_tau_x100": tau,
        "seed_stability_pct": stability,
        "cost_reduction_pct": cost_reduction,
        "overfit_guard_band": band,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_SUBSET_FIXTURE": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_alpha_report_matches_replay() -> None:
    """Alpha pack should replay with trusted overfit guard and full stratum coverage."""
    _swap("pack_alpha")
    exp = _expected_from_fixture("pack_alpha")
    got = _run_tool()
    assert got == exp


def test_skew_report_matches_replay() -> None:
    """Skew pack should match replay counters for stratum coverage under a tight floor."""
    _swap("pack_skew")
    exp = _expected_from_fixture("pack_skew")
    got = _run_tool()
    assert got["stratum_coverage_pct"] == exp["stratum_coverage_pct"]


def test_rare_report_matches_replay() -> None:
    """Rare pack should match replay counters for rare-task recall."""
    _swap("pack_rare")
    exp = _expected_from_fixture("pack_rare")
    got = _run_tool()
    assert got["rare_task_recall_pct"] == exp["rare_task_recall_pct"]


def test_tau_report_matches_replay() -> None:
    """Tau pack should match replay kendall_tau_x100 against the full-bench ordering."""
    _swap("pack_tau")
    exp = _expected_from_fixture("pack_tau")
    got = _run_tool()
    assert got["kendall_tau_x100"] == exp["kendall_tau_x100"]


def test_seed_report_matches_replay() -> None:
    """Seed pack should match replay cross-seed stability for conflicting subset ranks."""
    _swap("pack_seed")
    exp = _expected_from_fixture("pack_seed")
    got = _run_tool()
    assert got["seed_stability_pct"] == exp["seed_stability_pct"]


def test_alpha_cost_reduction_matches_replay() -> None:
    """Alpha should meet the configured cost reduction target after replay."""
    _swap("pack_alpha")
    exp = _expected_from_fixture("pack_alpha")
    got = _run_tool()
    assert got["cost_reduction_pct"] == exp["cost_reduction_pct"]


def test_alpha_overfit_guard_matches_replay() -> None:
    """Alpha should land in the trusted overfit guard band when all gates pass."""
    _swap("pack_alpha")
    exp = _expected_from_fixture("pack_alpha")
    got = _run_tool()
    assert got["overfit_guard_band"] == exp["overfit_guard_band"]


def test_fold_unit_tests_pass() -> None:
    """Metrics-layer unit tests under /app/internal/metrics must pass after the repair."""
    subprocess.run(
        [GO_BIN, "test", "./internal/metrics/...", "-count=1"],
        cwd="/app",
        env={
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        },
        check=True,
    )


def test_go_subsystem_tests_pass() -> None:
    """Go tests under /app must pass after the repair."""
    subprocess.run(
        [GO_BIN, "test", "./...", "-count=1"],
        cwd="/app",
        env={
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        },
        check=True,
    )
