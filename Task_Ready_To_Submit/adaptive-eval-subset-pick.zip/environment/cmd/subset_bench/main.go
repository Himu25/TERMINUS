// subset_bench writes /app/output/subset_audit.json when TB_SUBSET_FIXTURE=1.
// Outward fields: schema_version, run_id, full_task_count, subset_size,
// stratum_coverage_pct, rare_task_recall_pct, kendall_tau_x100,
// seed_stability_pct, cost_reduction_pct, overfit_guard_band, digest_hex.
package main

import (
	"log"
	"os"

	"lab.local/adaptive_eval_subset_pick/internal/driver"
)

func main() {
	if os.Getenv("TB_SUBSET_FIXTURE") != "1" {
		log.Fatal("TB_SUBSET_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/subset_audit.json", rep); err != nil {
		log.Fatal(err)
	}
}
