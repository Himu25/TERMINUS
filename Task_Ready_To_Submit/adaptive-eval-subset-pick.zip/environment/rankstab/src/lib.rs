/// rs_kendall_tau_x100 returns Kendall tau times 100 for paired rank slices.
#[no_mangle]
pub extern "C" fn rs_kendall_tau_x100(full: *const i32, subset: *const i32, n: usize) -> i32 {
    if n < 2 {
        return 100;
    }
    let mut concordant = 0i64;
    let mut discordant = 0i64;
    unsafe {
        for i in 0..n {
            for j in (i + 1)..n {
                let a = *full.add(i) - *full.add(j);
                let b = *subset.add(i) - *subset.add(j);
                let prod = (a as i64) * (b as i64);
                if prod > 0 {
                    concordant += 1;
                } else if prod < 0 {
                    discordant += 1;
                }
            }
        }
    }
    let denom = concordant + discordant;
    if denom == 0 {
        return 100;
    }
    let tau = (concordant - discordant) as f64 / denom as f64;
    (tau * 100.0).round() as i32
}

/// rs_seed_agree_pct measures cross-seed rank agreement for picked tasks.
#[no_mangle]
pub extern "C" fn rs_seed_agree_pct(
    seeds: *const i32,
    ranks: *const i32,
    task_count: usize,
    seed_count: usize,
) -> i32 {
    if task_count < 2 || seed_count < 2 {
        return 100;
    }
    let mut agree = 0i64;
    let mut total = 0i64;
    unsafe {
        for i in 0..task_count {
            for j in (i + 1)..task_count {
                let mut last_sign = 0i32;
                let mut stable = true;
                for s in 0..seed_count {
                    let base = s * task_count;
                    let a = *ranks.add(base + i);
                    let b = *ranks.add(base + j);
                    let sign = (a - b).signum();
                    if sign == 0 {
                        continue;
                    }
                    if last_sign == 0 {
                        last_sign = sign;
                    } else if sign != last_sign {
                        stable = false;
                        break;
                    }
                }
                total += 1;
                if !stable {
                    agree += 1;
                }
                let _ = seeds;
            }
        }
    }
    if total == 0 {
        return 100;
    }
    ((agree * 100) / total) as i32
}
