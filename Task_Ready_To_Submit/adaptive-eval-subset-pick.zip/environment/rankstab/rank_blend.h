#pragma once

#include <stdint.h>

int32_t rs_kendall_tau_x100(const int32_t *full, const int32_t *subset, size_t n);
int32_t rs_seed_agree_pct(const int32_t *seeds, const int32_t *ranks, size_t task_count, size_t seed_count);
