package rankstab

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/librankstab.a -ldl -lm
#include "rank_blend.h"
*/
import "C"
import "unsafe"

// KendallTauX100 compares full-bench ranks to subset ranks for picked tasks.
func KendallTauX100(full []int32, subset []int32) int32 {
	if len(full) == 0 || len(full) != len(subset) {
		return 0
	}
	return int32(C.rs_kendall_tau_x100(
		(*C.int32_t)(unsafe.Pointer(&full[0])),
		(*C.int32_t)(unsafe.Pointer(&subset[0])),
		C.size_t(len(full)),
	))
}

// SeedAgreePct scores pairwise order stability across seeds.
func SeedAgreePct(seeds []int32, ranks []int32, taskCount, seedCount int) int32 {
	if taskCount == 0 || len(ranks) == 0 {
		return 0
	}
	return int32(C.rs_seed_agree_pct(
		(*C.int32_t)(unsafe.Pointer(&seeds[0])),
		(*C.int32_t)(unsafe.Pointer(&ranks[0])),
		C.size_t(taskCount),
		C.size_t(seedCount),
	))
}
