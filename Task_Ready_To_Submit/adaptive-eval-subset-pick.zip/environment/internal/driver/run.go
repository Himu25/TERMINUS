package driver

import (
	"encoding/json"
	"os"

	"lab.local/adaptive_eval_subset_pick/internal/config"
	"lab.local/adaptive_eval_subset_pick/internal/engine"
	"lab.local/adaptive_eval_subset_pick/pkg/digest"
)

// Report is the JSON shape written to /app/output/subset_audit.json.
type Report struct {
	SchemaVersion        string `json:"schema_version"`
	RunID                string `json:"run_id"`
	FullTaskCount        int    `json:"full_task_count"`
	SubsetSize           int    `json:"subset_size"`
	StratumCoveragePct   int    `json:"stratum_coverage_pct"`
	RareTaskRecallPct    int    `json:"rare_task_recall_pct"`
	KendallTauX100       int    `json:"kendall_tau_x100"`
	SeedStabilityPct     int    `json:"seed_stability_pct"`
	CostReductionPct     int    `json:"cost_reduction_pct"`
	OverfitGuardBand     string `json:"overfit_guard_band"`
	DigestHex            string `json:"digest_hex"`
}

// RunActive loads the active pack and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	bundle, rows, err := config.LoadBundle(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(bundle, rows)
	digestHex := digest.FoldReport(
		bundle.RunID,
		itoa(out.FullTaskCount),
		itoa(out.SubsetSize),
		itoa(out.StratumCoveragePct),
		itoa(out.RareTaskRecallPct),
		itoa(out.KendallTauX100),
		itoa(out.SeedStabilityPct),
		itoa(out.CostReductionPct),
		out.OverfitGuardBand,
	)
	return Report{
		SchemaVersion:      "1",
		RunID:              bundle.RunID,
		FullTaskCount:      out.FullTaskCount,
		SubsetSize:         out.SubsetSize,
		StratumCoveragePct: out.StratumCoveragePct,
		RareTaskRecallPct:  out.RareTaskRecallPct,
		KendallTauX100:     out.KendallTauX100,
		SeedStabilityPct:   out.SeedStabilityPct,
		CostReductionPct:   out.CostReductionPct,
		OverfitGuardBand:   out.OverfitGuardBand,
		DigestHex:          digestHex,
	}, nil
}

// EmitReport writes rep to path as compact JSON.
func EmitReport(path string, rep Report) error {
	if err := os.MkdirAll("/app/output", 0o755); err != nil {
		return err
	}
	raw, err := json.Marshal(rep)
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func itoa(v int) string {
	if v == 0 {
		return "0"
	}
	var buf [16]byte
	i := len(buf)
	n := v
	neg := false
	if n < 0 {
		neg = true
		n = -n
	}
	for n > 0 {
		i--
		buf[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		buf[i] = '-'
	}
	return string(buf[i:])
}
