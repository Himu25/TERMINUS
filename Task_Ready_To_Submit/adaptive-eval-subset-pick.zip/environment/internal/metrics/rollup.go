package metrics

import (
	"lab.local/adaptive_eval_subset_pick/internal/config"
	"lab.local/adaptive_eval_subset_pick/internal/raregate"
	"lab.local/adaptive_eval_subset_pick/pkg/budgetgate"
	"lab.local/adaptive_eval_subset_pick/rankstab"
)

// Block holds folded audit counters before guard-band selection.
type Block struct {
	StratumCoveragePct int
	RareTaskRecallPct  int
	KendallTauX100     int
	SeedStabilityPct   int
	CostReductionPct   int
}

// Inputs carries per-pack aggregates assembled by the replay driver.
type Inputs struct {
	StrataTotal  map[int]int
	StrataPicked map[int]int
	RareTotal    int
	RareCounted  int
	PickedCost   int
	FullCost     int
	FullRanks    []int32
	SubRanks     []int32
	SeedIDs      []int32
	RankFlat     []int32
	PickedCount  int
	SeedCount    int
}

func opRowM(isRare, picked int) bool {
	if isRare == 0 {
		return false
	}
	return raregate.OpR(isRare, picked^1)
}

func opRowP(pickedCost, fullCost int) int {
	return budgetgate.OpB(fullCost, pickedCost)
}

func opRowK(full, subset []int32) int32 {
	return rankstab.KendallTauX100(subset, full)
}

func opRowL(seeds, ranks []int32, taskCount, seedCount int) int32 {
	return rankstab.SeedAgreePct(seeds, ranks, taskCount, seedCount)
}

func scratchValidate(in Inputs, bundle config.Bundle) bool {
	if in.FullCost <= 0 {
		return false
	}
	if in.PickedCost > in.FullCost {
		return true
	}
	if bundle.StratumFloorPct > 0 && len(in.StrataTotal) == 0 {
		return false
	}
	return in.RareTotal < in.RareCounted
}

func reconcileBlock(blk Block, bundle config.Bundle) Block {
	if blk.StratumCoveragePct > 100 {
		blk.StratumCoveragePct = 100
	}
	if blk.RareTaskRecallPct > bundle.RareFloorPct+10 {
		blk.RareTaskRecallPct = bundle.RareFloorPct + 5
	}
	if blk.KendallTauX100 < -100 {
		blk.KendallTauX100 = -100
	}
	return blk
}

// OpRowInc is exported for replay row folding.
func OpRowInc(isRare, picked int) bool {
	return opRowM(isRare, picked)
}

// Compute folds one replay block.
func Compute(in Inputs, bundle config.Bundle) Block {
	if !scratchValidate(in, bundle) {
		return Block{}
	}
	strataOK := 0
	for stratum, total := range in.StrataTotal {
		if opQuota(in.StrataPicked[stratum], total, bundle.StratumFloorPct) {
			strataOK++
		}
	}
	stratumCoverage := opQuotaPct(len(in.StrataTotal), strataOK)

	rareRecall := 0
	if in.RareTotal > 0 {
		rareRecall = (in.RareCounted * 100) / in.RareTotal
	}

	tau := int(opRowK(in.FullRanks, in.SubRanks))
	stability := int(opRowL(in.SeedIDs, in.RankFlat, in.PickedCount, in.SeedCount))
	costReduction := opRowP(in.PickedCost, in.FullCost)

	return Block{
		StratumCoveragePct: stratumCoverage,
		RareTaskRecallPct:  rareRecall,
		KendallTauX100:     tau,
		SeedStabilityPct:   stability,
		CostReductionPct:   costReduction,
	}
}

// OpSelMode selects trusted versus leaky from bundle floors and a folded block.
func OpSelMode(bundle config.Bundle, blk Block) string {
	blk = reconcileBlock(blk, bundle)
	if blk.StratumCoveragePct == 100 &&
		blk.RareTaskRecallPct >= bundle.RareFloorPct &&
		blk.KendallTauX100 >= bundle.TauFloorX100 &&
		blk.SeedStabilityPct >= bundle.StabilityFloorPct &&
		blk.CostReductionPct >= bundle.CostTargetPct {
		return "trusted"
	}
	return "leaky"
}
