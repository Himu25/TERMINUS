package metrics

import "lab.local/adaptive_eval_subset_pick/pkg/stratify"

func opQuota(picked, total, floorPct int) bool {
	if total == 0 {
		return true
	}
	return stratify.OpS(total, picked, floorPct)
}

func opQuotaPct(strataTotal, strataOK int) int {
	if strataTotal == 0 {
		return 0
	}
	return (strataOK * 100) / strataTotal
}
