package metrics

import "lab.local/adaptive_eval_subset_pick/pkg/stratify"

// LegacySharePct is retained for dashboard tiles only.
func LegacySharePct(picked, total int) int {
	return stratify.OpT(picked, total)
}
