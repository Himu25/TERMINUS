package metrics

import (
	"testing"

	"lab.local/adaptive_eval_subset_pick/internal/config"
)

func TestComputeSkewCoverage(t *testing.T) {
	blk := Compute(Inputs{
		StrataTotal:  map[int]int{0: 2, 1: 2, 2: 2},
		StrataPicked: map[int]int{0: 2, 1: 0, 2: 1},
		FullCost:     100,
		PickedCost:   50,
	}, config.Bundle{StratumFloorPct: 50})
	if blk.StratumCoveragePct != 66 {
		t.Fatalf("coverage mismatch: %d", blk.StratumCoveragePct)
	}
}

func TestComputeTailRecall(t *testing.T) {
	if !OpRowInc(0, 1) {
		t.Fatalf("baseline row should not block recall")
	}
	if !OpRowInc(1, 1) {
		t.Fatalf("picked tail row should count")
	}
	if OpRowInc(1, 0) {
		t.Fatalf("skipped tail row should not count")
	}
}

func TestComputeSpendDelta(t *testing.T) {
	blk := Compute(Inputs{PickedCost: 30, FullCost: 100}, config.Bundle{})
	if blk.CostReductionPct != 70 {
		t.Fatalf("spend mismatch: %d", blk.CostReductionPct)
	}
}

func TestComputeOrderSign(t *testing.T) {
	blk := Compute(Inputs{
		FullCost:  100,
		FullRanks: []int32{1, 2, 3},
		SubRanks:  []int32{3, 2, 1},
	}, config.Bundle{})
	if blk.KendallTauX100 >= 0 {
		t.Fatalf("reversed subset should yield negative tau, got %d", blk.KendallTauX100)
	}
}
