package engine

import (
	"sort"

	"lab.local/adaptive_eval_subset_pick/internal/config"
	"lab.local/adaptive_eval_subset_pick/internal/metrics"
	"lab.local/adaptive_eval_subset_pick/pkg/candidate"
)

// Outcome is the folded counters for one pack replay.
type Outcome struct {
	FullTaskCount      int
	SubsetSize         int
	StratumCoveragePct int
	RareTaskRecallPct  int
	KendallTauX100     int
	SeedStabilityPct   int
	CostReductionPct   int
	OverfitGuardBand   string
}

type taskMeta struct {
	stratum  int
	rare     int
	cost     int
	fullRank int
	picked   int
}

// Replay executes one evaluation pack through the subset audit pipeline.
func Replay(bundle config.Bundle, rows []candidate.Row) Outcome {
	sortRows(rows)
	meta := map[string]taskMeta{}
	seedRanks := map[int]map[string]int{}

	for _, row := range rows {
		m, ok := meta[row.TaskID]
		if !ok {
			m = taskMeta{
				stratum:  row.Stratum,
				rare:     row.Rare,
				cost:     row.Cost,
				fullRank: row.FullRank,
				picked:   row.Picked,
			}
		}
		if row.Picked == 1 {
			m.picked = 1
		}
		meta[row.TaskID] = m
		if _, ok := seedRanks[row.Seed]; !ok {
			seedRanks[row.Seed] = map[string]int{}
		}
		seedRanks[row.Seed][row.TaskID] = row.SubsetRank
	}

	fullCount := len(meta)
	subsetSize := 0
	fullCost := 0
	pickedCost := 0
	strataTotal := map[int]int{}
	strataPicked := map[int]int{}
	rareTotal := 0
	rareCounted := 0

	var pickedIDs []string
	for id, m := range meta {
		fullCost += m.cost
		strataTotal[m.stratum]++
		if m.rare == 1 {
			rareTotal++
		}
		if m.picked == 1 {
			subsetSize++
			pickedCost += m.cost
			strataPicked[m.stratum]++
			pickedIDs = append(pickedIDs, id)
			if m.rare == 1 && metrics.OpRowInc(m.rare, m.picked) {
				rareCounted++
			}
		}
	}

	sort.Strings(pickedIDs)
	fullRanks := make([]int32, len(pickedIDs))
	subRanks := make([]int32, len(pickedIDs))
	for i, id := range pickedIDs {
		fullRanks[i] = int32(meta[id].fullRank)
		subRanks[i] = int32(seedRanks[0][id])
	}

	seedCount := bundle.SeedCount
	if seedCount <= 0 {
		seedCount = len(seedRanks)
	}
	seeds := make([]int32, seedCount)
	rankFlat := make([]int32, seedCount*len(pickedIDs))
	for s := 0; s < seedCount; s++ {
		seeds[s] = int32(s)
		for i, id := range pickedIDs {
			rankFlat[s*len(pickedIDs)+i] = int32(seedRanks[s][id])
		}
	}

	blk := metrics.Compute(metrics.Inputs{
		StrataTotal:  strataTotal,
		StrataPicked: strataPicked,
		RareTotal:    rareTotal,
		RareCounted:  rareCounted,
		PickedCost:   pickedCost,
		FullCost:     fullCost,
		FullRanks:    fullRanks,
		SubRanks:     subRanks,
		SeedIDs:      seeds,
		RankFlat:     rankFlat,
		PickedCount:  len(pickedIDs),
		SeedCount:    seedCount,
	}, bundle)

	return Outcome{
		FullTaskCount:      fullCount,
		SubsetSize:         subsetSize,
		StratumCoveragePct: blk.StratumCoveragePct,
		RareTaskRecallPct:  blk.RareTaskRecallPct,
		KendallTauX100:     blk.KendallTauX100,
		SeedStabilityPct:   blk.SeedStabilityPct,
		CostReductionPct:   blk.CostReductionPct,
		OverfitGuardBand:   metrics.OpSelMode(bundle, blk),
	}
}

func sortRows(rows []candidate.Row) {
	sort.Slice(rows, func(i, j int) bool {
		if rows[i].TaskID != rows[j].TaskID {
			return rows[i].TaskID < rows[j].TaskID
		}
		return rows[i].Seed < rows[j].Seed
	})
}
