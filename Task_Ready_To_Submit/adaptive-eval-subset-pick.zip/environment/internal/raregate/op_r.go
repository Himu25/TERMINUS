package raregate

// OpR decides whether a rare task counts toward recall when picked.
func OpR(isRare, picked int) bool {
	if isRare == 0 {
		return true
	}
	return picked == 1
}
