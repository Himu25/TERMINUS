package raregate

import "testing"

func TestOpRCountsRarePicks(t *testing.T) {
	if !OpR(1, 1) {
		t.Fatalf("recall gate mismatch")
	}
}
