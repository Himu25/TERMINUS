package config

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"lab.local/adaptive_eval_subset_pick/pkg/candidate"
)

// Bundle is eval_bundle.json for one replay pack.
type Bundle struct {
	RunID               string `json:"run_id"`
	SeedCount           int    `json:"seed_count"`
	StratumFloorPct     int    `json:"stratum_floor_pct"`
	RareFloorPct        int    `json:"rare_floor_pct"`
	TauFloorX100        int    `json:"tau_floor_x100"`
	StabilityFloorPct   int    `json:"stability_floor_pct"`
	CostTargetPct       int    `json:"cost_target_pct"`
	OverfitCeilingX100  int    `json:"overfit_ceiling_x100"`
}

// ActivePaths returns the active data directory under appRoot.
func ActivePaths(appRoot string) (string, error) {
	dir := filepath.Join(appRoot, "data", "active")
	st, err := os.Stat(dir)
	if err != nil {
		return "", err
	}
	if !st.IsDir() {
		return "", fmt.Errorf("active data is not a directory")
	}
	return dir, nil
}

// LoadBundle reads eval_bundle.json and candidates.jsonl from dir.
func LoadBundle(dir string) (Bundle, []candidate.Row, error) {
	raw, err := os.ReadFile(filepath.Join(dir, "eval_bundle.json"))
	if err != nil {
		return Bundle{}, nil, err
	}
	var bundle Bundle
	if err := json.Unmarshal(raw, &bundle); err != nil {
		return Bundle{}, nil, err
	}
	rows, err := loadCandidates(filepath.Join(dir, "candidates.jsonl"))
	if err != nil {
		return Bundle{}, nil, err
	}
	return bundle, rows, nil
}

func loadCandidates(path string) ([]candidate.Row, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	var out []candidate.Row
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := sc.Text()
		if line == "" {
			continue
		}
		var row candidate.Row
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return nil, err
		}
		out = append(out, row)
	}
	return out, sc.Err()
}
