package main

import (
	"fmt"
	"os"

	"lab.local/adaptive_eval_subset_pick/pkg/digest"
)

func main() {
	if len(os.Args) != 10 {
		fmt.Fprintln(os.Stderr, "usage: digest_cli run_id full subset stratum rare tau stability cost band")
		os.Exit(2)
	}
	fmt.Println(digest.FoldReport(os.Args[1:]...))
}
