Verifier helpers include /tmp/subset_bench_verify_bin and /app/tools/digest_cli for digest recomputation.
Build the subset bench with /app/scripts/build.sh using /usr/local/go/bin/go and cargo.
