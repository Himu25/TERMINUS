package stratify

// OpT formats a stratum share for log lines.
func OpT(picked, total int) int {
	if total == 0 {
		return 0
	}
	return (picked * 100) / total
}
