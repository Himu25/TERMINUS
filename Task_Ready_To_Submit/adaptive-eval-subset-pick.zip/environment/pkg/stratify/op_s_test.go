package stratify

import "testing"

func TestOpSExactFloor(t *testing.T) {
	if !OpS(2, 5, 40) {
		t.Fatalf("floor gate mismatch")
	}
}
