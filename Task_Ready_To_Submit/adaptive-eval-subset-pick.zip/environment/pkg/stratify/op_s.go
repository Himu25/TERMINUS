package stratify

// OpS reports whether a stratum meets its minimum picked share.
func OpS(picked, total, floorPct int) bool {
	if total == 0 {
		return true
	}
	return picked*100 >= total*floorPct
}
