package candidate

// Row is one seeded evaluation task draw in candidates.jsonl.
type Row struct {
	TaskID     string `json:"task_id"`
	Stratum    int    `json:"stratum"`
	Rare       int    `json:"rare"`
	Cost       int    `json:"cost"`
	FullRank   int    `json:"full_rank"`
	Seed       int    `json:"seed"`
	Picked     int    `json:"picked"`
	SubsetRank int    `json:"subset_rank"`
}
