package digest

import (
	"crypto/sha256"
	"encoding/hex"
	"strings"
)

// FoldReport hashes the audit counters in field order.
func FoldReport(parts ...string) string {
	raw := strings.Join(parts, "|")
	sum := sha256.Sum256([]byte(raw))
	return hex.EncodeToString(sum[:])
}
