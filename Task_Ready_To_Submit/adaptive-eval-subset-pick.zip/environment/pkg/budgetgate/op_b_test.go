package budgetgate

import "testing"

func TestOpBSavings(t *testing.T) {
	got := OpB(30, 100)
	if got != 70 {
		t.Fatalf("savings gate mismatch: %d", got)
	}
}
