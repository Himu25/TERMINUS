package budgetgate

// OpB returns the percent of evaluation cost removed by the subset.
func OpB(pickedCost, fullCost int) int {
	if fullCost == 0 {
		return 0
	}
	return 100 - (pickedCost*100)/fullCost
}
