pack_alpha exercises full guard bands. pack_skew stresses stratum floors. pack_rare stresses tail recall. pack_tau stresses rank correlation. pack_seed stresses cross-seed order agreement.
