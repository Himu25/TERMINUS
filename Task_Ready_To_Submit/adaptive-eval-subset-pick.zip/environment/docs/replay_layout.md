Swap packs into /app/data/active before running subset_bench with TB_SUBSET_FIXTURE=1.
