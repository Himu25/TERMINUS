Evaluation subset selection replays candidate pools from eval_bundle.json and candidates.jsonl.
