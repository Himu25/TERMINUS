"""Verifier for STIX indicator fusion audit report."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = APP / "data" / "replay"
OUT = APP / "output" / "fusion_audit_report.json"
SCHEMA = APP / "schemas" / "fusion_audit_report.schema.json"
GO_BIN = "/usr/local/go/bin/go"
VERIFY_BIN = "/app/bin/fusion_audit_run"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:/usr/local/go/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _digest_hex(
    run_id: str,
    raw: int,
    merged: int,
    binding: int,
    false_blocked: int,
    dedup: int,
) -> str:
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            run_id,
            str(raw),
            str(merged),
            str(binding),
            str(false_blocked),
            str(dedup),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _step_n2(value: str) -> str:
    return value.strip().lower()


def _op_k(left: str, right: str) -> bool:
    return left.casefold() == right.casefold()


def _op_m(confidence: int, binding: int) -> bool:
    return confidence >= binding


def _op_c(left: int, right: int) -> int:
    return max(left, right)


def _op_w(left: str, right: str) -> bool:
    return left == right


def _op_f(epoch: int, cutoff: int) -> bool:
    return epoch >= cutoff


def _load_pack(pack_dir: Path) -> tuple[dict, list[dict]]:
    plan = json.loads((pack_dir / "bundle_plan.json").read_text())
    rows: list[dict] = []
    for line in (pack_dir / "indicators.jsonl").read_text().splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return plan, rows


def _expected_from_fixture(pack_name: str) -> dict:
    plan, rows = _load_pack(FIXTURES / pack_name)
    filtered = [row for row in rows if _op_f(row["epoch"], plan["bundle_epoch"])]
    binding = plan["confidence_binding"]
    merged: list[dict] = []
    seen: set[str] = set()
    dedup_removed = 0
    false_blocked = 0

    for row in filtered:
        norm = _step_n2(row["value"])
        dedup_key = f"{row['type']}|{norm}|{row['confidence']}"
        if dedup_key in seen:
            dedup_removed += 1
            continue
        seen.add(dedup_key)

        placed = False
        for idx, item in enumerate(merged):
            if not _op_k(item["value"], norm):
                continue
            if not _op_w(item["type"], row["type"]):
                false_blocked += 1
                merged.append(
                    {
                        "type": row["type"],
                        "value": norm,
                        "confidence": row["confidence"],
                    }
                )
                placed = True
                break
            if _op_m(row["confidence"], binding):
                merged[idx]["confidence"] = _op_c(merged[idx]["confidence"], row["confidence"])
                placed = True
                break
        if not placed:
            merged.append(
                {
                    "type": row["type"],
                    "value": norm,
                    "confidence": row["confidence"],
                }
            )

    digest = _digest_hex(
        plan["run_id"],
        len(filtered),
        len(merged),
        binding,
        false_blocked,
        dedup_removed,
    )
    return {
        "schema_version": "1",
        "run_id": plan["run_id"],
        "raw_count": len(filtered),
        "merged_count": len(merged),
        "confidence_binding": binding,
        "false_merge_blocked": false_blocked,
        "dedup_removed": dedup_removed,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {
        **os.environ,
        "TB_FUSION_FIXTURE": "1",
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
    }
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def _validate_report_schema(report: dict, schema: dict) -> None:
    for key in schema["required"]:
        assert key in report
    assert isinstance(report["schema_version"], str)
    assert isinstance(report["run_id"], str)
    for int_key in (
        "raw_count",
        "merged_count",
        "confidence_binding",
        "false_merge_blocked",
        "dedup_removed",
    ):
        assert isinstance(report[int_key], int)
    assert isinstance(report["digest_hex"], str)


def test_report_satisfies_schema() -> None:
    """Emitted report must validate against the fusion audit JSON schema."""
    schema = json.loads(SCHEMA.read_text())
    _swap("bundle_alpha")
    got = _run_tool()
    _validate_report_schema(got, schema)


def test_alpha_report_matches_replay() -> None:
    """Alpha pack should replay with full fusion totals and digest."""
    _swap("bundle_alpha")
    exp = _expected_from_fixture("bundle_alpha")
    got = _run_tool()
    assert got == exp


def test_active_pack_replays_cleanly() -> None:
    """The bundled active pack should replay when left at the shipped default."""
    _swap("bundle_alpha")
    exp = _expected_from_fixture("bundle_alpha")
    got = _run_tool()
    assert got == exp


def test_indexed_replay_packs_match() -> None:
    """Every pack listed in the scenario index must replay with matching totals."""
    index_path = APP / "docs" / "scenario_index.txt"
    pack_names = [line.strip() for line in index_path.read_text().splitlines() if line.strip()]
    assert pack_names
    for pack_name in pack_names:
        _swap(pack_name)
        exp = _expected_from_fixture(pack_name)
        got = _run_tool()
        assert got == exp


def test_alpha_fusion_totals() -> None:
    """Alpha should keep every distinct indicator after normalization."""
    _swap("bundle_alpha")
    exp = _expected_from_fixture("bundle_alpha")
    got = _run_tool()
    assert got["raw_count"] == exp["raw_count"]
    assert got["merged_count"] == exp["merged_count"]


def test_beta_casefold_dedup() -> None:
    """Beta must dedup file hashes that differ only by case after normalization."""
    _swap("bundle_beta")
    exp = _expected_from_fixture("bundle_beta")
    got = _run_tool()
    assert got["dedup_removed"] == exp["dedup_removed"]


def test_beta_cross_case_merge() -> None:
    """Beta must merge case-variant file rows that carry different confidence scores."""
    _swap("bundle_beta")
    exp = _expected_from_fixture("bundle_beta")
    got = _run_tool()
    assert got["merged_count"] == exp["merged_count"]


def test_gamma_confidence_merge() -> None:
    """Gamma should merge rows at the binding threshold before counting survivors."""
    _swap("bundle_gamma")
    exp = _expected_from_fixture("bundle_gamma")
    got = _run_tool()
    assert got["merged_count"] == exp["merged_count"]
    assert got["confidence_binding"] == exp["confidence_binding"]


def test_delta_false_merge_blocked() -> None:
    """Delta must block cross-type merges that share the same normalized value."""
    _swap("bundle_delta")
    exp = _expected_from_fixture("bundle_delta")
    got = _run_tool()
    assert got["false_merge_blocked"] == exp["false_merge_blocked"]
    assert got["merged_count"] == exp["merged_count"]


def test_epsilon_stale_row_dropped() -> None:
    """Epsilon must ignore pre-cutoff bundle rows before fusion."""
    _swap("bundle_epsilon")
    exp = _expected_from_fixture("bundle_epsilon")
    got = _run_tool()
    assert got["raw_count"] == exp["raw_count"]
    assert got["merged_count"] == exp["merged_count"]


def test_go_subsystem_tests_pass() -> None:
    """Go tests under /app must pass after the repair."""
    subprocess.run(
        [GO_BIN, "test", "./..."],
        cwd="/app",
        env={
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:/usr/local/go/bin:" + os.environ.get("PATH", ""),
        },
        check=True,
    )
