#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

write_rust_norm() {
  cat > /app/stix_norm/src/step_n2.rs <<'EOF'
use std::ffi::{CStr, CString};
use std::os::raw::c_char;

pub fn step_n2(value: &str) -> String {
    let trimmed = value.trim();
    if trimmed.is_empty() {
        return String::new();
    }
    trimmed.to_lowercase()
}

#[no_mangle]
pub extern "C" fn step_n2_c(input: *const c_char) -> *mut c_char {
    let raw = unsafe {
        if input.is_null() {
            return std::ptr::null_mut();
        }
        CStr::from_ptr(input)
    };
    let normalized = step_n2(raw.to_str().unwrap_or(""));
    match CString::new(normalized) {
        Ok(out) => out.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

#[no_mangle]
pub extern "C" fn step_n2_free(ptr: *mut c_char) {
    if !ptr.is_null() {
        unsafe {
            let _ = CString::from_raw(ptr);
        }
    }
}
EOF
}

write_go_key() {
  cat > /app/internal/keyfold/op_k.go <<'EOF'
package keyfold

import (
	"fmt"
	"strings"
)

// OpK compares two normalized indicator values for fusion key equality.
func OpK(left string, right string) bool {
	if left == "" || right == "" {
		return left == right
	}
	return strings.EqualFold(left, right)
}

// FoldKey builds the dedup fingerprint for one normalized row.
func FoldKey(indType string, norm string, confidence int) string {
	return fmt.Sprintf("%s|%s|%d", indType, norm, confidence)
}
EOF
}

write_go_epoch() {
  cat > /app/internal/epochfold/op_f.go <<'EOF'
package epochfold

// OpF decides whether an indicator row survives bundle epoch filtering.
func OpF(epoch int, cutoff int) bool {
	if cutoff <= 0 {
		return epoch >= 0
	}
	return epoch >= cutoff
}
EOF
}

write_go_merge() {
  cat > /app/internal/merfold/op_m.go <<'EOF'
package merfold

// OpM decides whether confidence clears the bundle binding for fusion.
func OpM(confidence int, binding int) bool {
	if binding <= 0 {
		return confidence >= 0
	}
	return confidence >= binding
}
EOF
}

write_go_conf() {
  cat > /app/internal/conffold/op_c.go <<'EOF'
package conffold

// OpC folds two confidence scores after a successful merge.
func OpC(left int, right int) int {
	if left > right {
		return left
	}
	if right > left {
		return right
	}
	return left
}
EOF
}

write_go_type() {
  cat > /app/pkg/typegate/op_w.go <<'EOF'
package typegate

// OpW gates fusion on indicator type compatibility.
func OpW(left string, right string) bool {
	if left == "" || right == "" {
		return false
	}
	return left == right
}
EOF
}

write_rust_norm
write_go_key
write_go_epoch
write_go_merge
write_go_conf
write_go_type

bash /app/scripts/build.sh

rm -f /app/output/fusion_audit_report.json
mkdir -p /app/output
TB_FUSION_FIXTURE=1 /app/bin/fusion_audit_run
test -s /app/output/fusion_audit_report.json

GOFLAGS=-mod=mod go test ./...

python3 <<'PY'
import json
from pathlib import Path

rep = json.loads(Path("/app/output/fusion_audit_report.json").read_text())
for key in (
    "schema_version",
    "run_id",
    "raw_count",
    "merged_count",
    "confidence_binding",
    "false_merge_blocked",
    "dedup_removed",
    "digest_hex",
):
    if key not in rep:
        raise SystemExit(f"missing {key}")
PY
