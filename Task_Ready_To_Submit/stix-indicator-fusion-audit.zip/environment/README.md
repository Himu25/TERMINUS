STIX indicator fusion audit — mixed Rust/Go replay stack under `/app`.

See `/app/docs/replay_layout.md` for fixture layout and `/app/schemas/fusion_audit_report.schema.json` for the outward report shape.
