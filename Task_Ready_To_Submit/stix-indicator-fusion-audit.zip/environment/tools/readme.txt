Build helper: bash /app/scripts/build.sh
Digest helper: go run -mod=mod /app/tools/digest_cli <args>
Verifier replay invokes /usr/local/go/bin/go for digest checks and subsystem tests.
