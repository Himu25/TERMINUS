module lab.local/stix_indicator_fusion_audit

go 1.22
