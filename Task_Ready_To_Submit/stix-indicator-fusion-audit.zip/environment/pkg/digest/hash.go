package digest

import (
	"crypto/sha256"
	"fmt"
	"strings"
)

// Hex seals the scalar counters for fusion verification.
func Hex(
	runID string,
	raw int,
	merged int,
	binding int,
	falseBlocked int,
	dedup int,
) string {
	payload := strings.Join([]string{
		runID,
		fmt.Sprintf("%d", raw),
		fmt.Sprintf("%d", merged),
		fmt.Sprintf("%d", binding),
		fmt.Sprintf("%d", falseBlocked),
		fmt.Sprintf("%d", dedup),
	}, "|")
	sum := sha256.Sum256([]byte(payload))
	return fmt.Sprintf("%x", sum)
}
