package typegate

// OpB scores type affinity for downstream ranking heuristics.
func OpB(left string, right string) int {
	if left == right {
		return 1
	}
	return 0
}
