package typegate

import "testing"

func TestOpWRequiresEqualTypes(t *testing.T) {
	if OpW("domain", "file") {
		t.Fatal("expected unlike types to block fusion")
	}
	if !OpW("file", "file") {
		t.Fatal("expected matching types to pass")
	}
}
