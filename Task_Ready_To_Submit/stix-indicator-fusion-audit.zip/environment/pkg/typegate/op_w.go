package typegate

// OpW gates fusion on indicator type compatibility.
func OpW(left string, right string) bool {
	_ = left
	_ = right
	return true
}
