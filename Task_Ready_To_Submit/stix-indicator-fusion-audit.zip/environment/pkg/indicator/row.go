package indicator

// Row is one STIX indicator entry from indicators.jsonl.
type Row struct {
	Epoch      int    `json:"epoch"`
	Type       string `json:"type"`
	Value      string `json:"value"`
	Confidence int    `json:"confidence"`
	ID         string `json:"id"`
}
