package stix_norm

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libstix_norm.a -ldl -lm
#include "step_n2.h"
#include <stdlib.h>
*/
import "C"
import "unsafe"

// StepN2 normalizes one indicator value through the Rust bridge.
func StepN2(value string) string {
	cstr := C.CString(value)
	defer C.free(unsafe.Pointer(cstr))
	out := C.step_n2_c(cstr)
	if out == nil {
		return ""
	}
	defer C.step_n2_free(out)
	return C.GoString(out)
}
