use std::ffi::{CStr, CString};
use std::os::raw::c_char;

pub fn step_n2(value: &str) -> String {
    value.trim().to_string()
}

#[no_mangle]
pub extern "C" fn step_n2_c(input: *const c_char) -> *mut c_char {
    let raw = unsafe {
        if input.is_null() {
            return std::ptr::null_mut();
        }
        CStr::from_ptr(input)
    };
    let normalized = step_n2(raw.to_str().unwrap_or(""));
    match CString::new(normalized) {
        Ok(out) => out.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

#[no_mangle]
pub extern "C" fn step_n2_free(ptr: *mut c_char) {
    if !ptr.is_null() {
        unsafe {
            let _ = CString::from_raw(ptr);
        }
    }
}
