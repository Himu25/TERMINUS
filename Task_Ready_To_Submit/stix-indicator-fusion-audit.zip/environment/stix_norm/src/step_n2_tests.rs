#[cfg(test)]
mod step_n2_tests {
    use crate::step_n2;

    #[test]
    fn lowercases_value() {
        let got = step_n2("  AbC123  ");
        if got != "abc123" {
            panic!("expected lowercase trim, got {got}");
        }
    }
}
