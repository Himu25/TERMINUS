#ifndef STIX_NORM_STEP_N2_H
#define STIX_NORM_STEP_N2_H

#include <stdint.h>

char *step_n2_c(const char *input);
void step_n2_free(char *ptr);

#endif
