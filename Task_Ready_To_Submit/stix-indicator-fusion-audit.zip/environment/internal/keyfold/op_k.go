package keyfold

import "fmt"

// OpK compares two normalized indicator values for fusion key equality.
func OpK(left string, right string) bool {
	return left == right
}

// FoldKey builds the dedup fingerprint for one normalized row.
func FoldKey(indType string, norm string, confidence int) string {
	return fmt.Sprintf("%s|%s|%d", indType, norm, confidence)
}
