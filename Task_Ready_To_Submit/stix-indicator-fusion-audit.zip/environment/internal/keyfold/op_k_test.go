package keyfold

import "testing"

func TestOpKCaseInsensitiveMatch(t *testing.T) {
	if !OpK("DEADBEEF", "deadbeef") {
		t.Fatal("expected case-insensitive key match")
	}
}

func TestOpKRejectsDifferentValues(t *testing.T) {
	if OpK("alpha", "beta") {
		t.Fatal("expected different values to fail key match")
	}
}
