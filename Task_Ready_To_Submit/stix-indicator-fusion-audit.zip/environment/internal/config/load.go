package config

import (
	"encoding/json"
	"os"
	"path/filepath"
)

// Plan is the STIX bundle layout for one replay pack.
type Plan struct {
	RunID             string `json:"run_id"`
	BundleEpoch       int    `json:"bundle_epoch"`
	ConfidenceBinding int    `json:"confidence_binding"`
}

// LoadPlan reads bundle_plan.json from a pack directory.
func LoadPlan(packDir string) (Plan, error) {
	raw, err := os.ReadFile(filepath.Join(packDir, "bundle_plan.json"))
	if err != nil {
		return Plan{}, err
	}
	var plan Plan
	if err := json.Unmarshal(raw, &plan); err != nil {
		return Plan{}, err
	}
	return plan, nil
}
