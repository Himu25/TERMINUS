package merfold

// OpM decides whether confidence clears the bundle binding for fusion.
func OpM(confidence int, binding int) bool {
	return confidence > binding
}
