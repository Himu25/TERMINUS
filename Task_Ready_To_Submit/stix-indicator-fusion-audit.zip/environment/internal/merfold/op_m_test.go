package merfold

import "testing"

func TestOpMAcceptsAtBinding(t *testing.T) {
	if !OpM(75, 75) {
		t.Fatal("expected confidence at binding to allow merge")
	}
}

func TestOpMRejectsBelowBinding(t *testing.T) {
	if OpM(50, 75) {
		t.Fatal("expected confidence below binding to block merge")
	}
}
