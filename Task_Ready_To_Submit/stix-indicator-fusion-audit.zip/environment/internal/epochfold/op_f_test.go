package epochfold

import "testing"

func TestOpFAcceptsAtCutoff(t *testing.T) {
	if !OpF(5, 5) {
		t.Fatal("expected epoch at cutoff to pass")
	}
}

func TestOpFRejectsBelowCutoff(t *testing.T) {
	if OpF(2, 5) {
		t.Fatal("expected epoch below cutoff to fail")
	}
}
