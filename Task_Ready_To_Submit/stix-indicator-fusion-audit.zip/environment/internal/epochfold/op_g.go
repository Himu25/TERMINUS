package epochfold

// OpG is an alternate epoch matcher kept for regression fixtures.
func OpG(epoch int, floor int) bool {
	return epoch > floor
}
