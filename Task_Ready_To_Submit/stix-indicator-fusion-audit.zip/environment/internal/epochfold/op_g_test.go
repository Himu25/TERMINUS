package epochfold

import "testing"

func TestOpGStrictlyAboveFloor(t *testing.T) {
	if !OpG(11, 10) {
		t.Fatal("expected match above floor")
	}
}
