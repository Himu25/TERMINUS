package epochfold

// OpF decides whether an indicator row survives bundle epoch filtering.
func OpF(epoch int, cutoff int) bool {
	_ = cutoff
	return true
}
