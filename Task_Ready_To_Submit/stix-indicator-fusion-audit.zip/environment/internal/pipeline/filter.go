package pipeline

import (
	"lab.local/stix_indicator_fusion_audit/internal/epochfold"
	"lab.local/stix_indicator_fusion_audit/pkg/indicator"
)

// FilterRows keeps bundle rows that survive the ingest cutoff.
func FilterRows(rows []indicator.Row, cutoff int) []indicator.Row {
	out := make([]indicator.Row, 0, len(rows))
	for _, row := range rows {
		if epochfold.OpF(row.Epoch, cutoff) {
			out = append(out, row)
		}
	}
	return out
}
