package pipeline

import (
	"lab.local/stix_indicator_fusion_audit/internal/keyfold"
	"lab.local/stix_indicator_fusion_audit/pkg/indicator"
	"lab.local/stix_indicator_fusion_audit/stix_norm"
)

// NormalizeValue canonicalizes one indicator value for fusion keys.
func NormalizeValue(value string) string {
	return stix_norm.StepN2(value)
}

// DedupKey fingerprints one normalized row for exact duplicate removal.
func DedupKey(row indicator.Row, norm string) string {
	return keyfold.FoldKey(row.Type, norm, row.Confidence)
}
