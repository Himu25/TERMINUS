package pipeline

import (
	"lab.local/stix_indicator_fusion_audit/internal/keyfold"
	"lab.local/stix_indicator_fusion_audit/pkg/typegate"
)

// MatchDecision captures whether a candidate row can fuse with an existing survivor.
type MatchDecision struct {
	KeyMatch      bool
	TypeMismatch  bool
}

// InspectMatch compares normalized keys and indicator types before binding.
func InspectMatch(existingType string, existingValue string, candType string, norm string) MatchDecision {
	if !keyfold.OpK(existingValue, norm) {
		return MatchDecision{}
	}
	if !typegate.OpW(existingType, candType) {
		return MatchDecision{KeyMatch: true, TypeMismatch: true}
	}
	return MatchDecision{KeyMatch: true}
}
