package pipeline

import (
	"lab.local/stix_indicator_fusion_audit/internal/conffold"
	"lab.local/stix_indicator_fusion_audit/internal/merfold"
)

// ApplyBinding folds confidence when the candidate clears the bundle gate.
func ApplyBinding(existing *int, candidate int, binding int) bool {
	if !merfold.OpM(candidate, binding) {
		return false
	}
	*existing = conffold.OpC(*existing, candidate)
	return true
}
