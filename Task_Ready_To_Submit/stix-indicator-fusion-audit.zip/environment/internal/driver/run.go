package driver

import (
	"bufio"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"

	"lab.local/stix_indicator_fusion_audit/internal/config"
	"lab.local/stix_indicator_fusion_audit/internal/engine"
	"lab.local/stix_indicator_fusion_audit/pkg/digest"
	"lab.local/stix_indicator_fusion_audit/pkg/indicator"
)

type report struct {
	SchemaVersion     string `json:"schema_version"`
	RunID             string `json:"run_id"`
	RawCount          int    `json:"raw_count"`
	MergedCount       int    `json:"merged_count"`
	ConfidenceBinding int    `json:"confidence_binding"`
	FalseMergeBlocked int    `json:"false_merge_blocked"`
	DedupRemoved      int    `json:"dedup_removed"`
	DigestHex         string `json:"digest_hex"`
}

// RunActive replays the pack linked from /app/data/active.
func RunActive(appRoot string) (report, error) {
	return RunPack(filepath.Join(appRoot, "data", "active"))
}

// RunPack replays one fixture directory.
func RunPack(packDir string) (report, error) {
	plan, err := config.LoadPlan(packDir)
	if err != nil {
		return report{}, err
	}
	rows, err := loadIndicators(filepath.Join(packDir, "indicators.jsonl"))
	if err != nil {
		return report{}, err
	}
	out := engine.Replay(plan, rows)
	rep := report{
		SchemaVersion:     "1",
		RunID:             plan.RunID,
		RawCount:          out.RawCount,
		MergedCount:       out.MergedCount,
		ConfidenceBinding: out.ConfidenceBinding,
		FalseMergeBlocked: out.FalseMergeBlocked,
		DedupRemoved:      out.DedupRemoved,
		DigestHex: digest.Hex(
			plan.RunID,
			out.RawCount,
			out.MergedCount,
			out.ConfidenceBinding,
			out.FalseMergeBlocked,
			out.DedupRemoved,
		),
	}
	return rep, nil
}

// EmitReport writes the JSON artifact.
func EmitReport(path string, rep report) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}

func loadIndicators(path string) ([]indicator.Row, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := []indicator.Row{}
	scan := bufio.NewScanner(f)
	for scan.Scan() {
		line := strings.TrimSpace(scan.Text())
		if line == "" {
			continue
		}
		var row indicator.Row
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return nil, err
		}
		out = append(out, row)
	}
	return out, scan.Err()
}
