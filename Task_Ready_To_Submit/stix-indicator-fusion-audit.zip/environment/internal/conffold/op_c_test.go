package conffold

import "testing"

func TestOpCPrefersHigherConfidence(t *testing.T) {
	if got := OpC(80, 90); got != 90 {
		t.Fatalf("expected max confidence 90, got %d", got)
	}
}

func TestOpCSymmetric(t *testing.T) {
	if got := OpC(90, 80); got != 90 {
		t.Fatalf("expected max confidence 90, got %d", got)
	}
}
