package conffold

// OpC folds two confidence scores after a successful merge.
func OpC(left int, right int) int {
	if left < right {
		return left
	}
	return right
}
