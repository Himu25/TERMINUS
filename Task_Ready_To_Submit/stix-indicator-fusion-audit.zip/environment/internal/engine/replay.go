package engine

import (
	"fmt"

	"lab.local/stix_indicator_fusion_audit/internal/config"
	"lab.local/stix_indicator_fusion_audit/internal/pipeline"
	"lab.local/stix_indicator_fusion_audit/pkg/indicator"
)

// Outcome is the folded counters for one bundle replay.
type Outcome struct {
	RawCount          int
	MergedCount       int
	ConfidenceBinding int
	FalseMergeBlocked int
	DedupRemoved      int
}

type fusedRow struct {
	Type       string
	Value      string
	Confidence int
}

// Replay executes one indicator pack through the fusion audit pipeline.
func Replay(plan config.Plan, rows []indicator.Row) Outcome {
	filtered := pipeline.FilterRows(rows, plan.BundleEpoch)
	binding := plan.ConfidenceBinding
	merged := []fusedRow{}
	seen := map[string]bool{}
	dedupRemoved := 0
	falseBlocked := 0

	for _, row := range filtered {
		norm := pipeline.NormalizeValue(row.Value)
		dedupKey := pipeline.DedupKey(row, norm)
		if seen[dedupKey] {
			dedupRemoved++
			continue
		}
		seen[dedupKey] = true

		placed := false
		for i := range merged {
			decision := pipeline.InspectMatch(merged[i].Type, merged[i].Value, row.Type, norm)
			if !decision.KeyMatch {
				continue
			}
			if decision.TypeMismatch {
				falseBlocked++
				merged = append(merged, fusedRow{
					Type:       row.Type,
					Value:      norm,
					Confidence: row.Confidence,
				})
				placed = true
				break
			}
			if pipeline.ApplyBinding(&merged[i].Confidence, row.Confidence, binding) {
				placed = true
				break
			}
		}
		if !placed {
			merged = append(merged, fusedRow{
				Type:       row.Type,
				Value:      norm,
				Confidence: row.Confidence,
			})
		}
	}

	return Outcome{
		RawCount:          len(filtered),
		MergedCount:       len(merged),
		ConfidenceBinding: binding,
		FalseMergeBlocked: falseBlocked,
		DedupRemoved:      dedupRemoved,
	}
}

// Summary renders a compact trace for diagnostics.
func Summary(plan config.Plan, out Outcome) string {
	return fmt.Sprintf("%s raw=%d merged=%d", plan.RunID, out.RawCount, out.MergedCount)
}
