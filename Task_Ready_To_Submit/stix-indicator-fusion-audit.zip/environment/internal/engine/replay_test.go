package engine

import (
	"testing"

	"lab.local/stix_indicator_fusion_audit/internal/config"
	"lab.local/stix_indicator_fusion_audit/pkg/indicator"
)

func TestReplayEmptyBundle(t *testing.T) {
	plan := config.Plan{
		RunID:             "t-empty",
		BundleEpoch:       0,
		ConfidenceBinding: 50,
	}
	out := Replay(plan, nil)
	if out.RawCount != 0 || out.MergedCount != 0 {
		t.Fatalf("unexpected counters: %+v", out)
	}
}

func TestReplaySingleIndicator(t *testing.T) {
	plan := config.Plan{
		RunID:             "t-one",
		BundleEpoch:       0,
		ConfidenceBinding: 50,
	}
	rows := []indicator.Row{
		{Epoch: 0, Type: "domain", Value: "example.com", Confidence: 60, ID: "x1"},
	}
	out := Replay(plan, rows)
	if out.RawCount != 1 || out.MergedCount != 1 {
		t.Fatalf("expected one indicator through, got %+v", out)
	}
}
