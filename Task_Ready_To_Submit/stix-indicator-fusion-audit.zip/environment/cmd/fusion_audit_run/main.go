package main

import (
	"log"
	"os"

	"lab.local/stix_indicator_fusion_audit/internal/driver"
)

func main() {
	if os.Getenv("TB_FUSION_FIXTURE") != "1" {
		log.Fatal("TB_FUSION_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/fusion_audit_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
