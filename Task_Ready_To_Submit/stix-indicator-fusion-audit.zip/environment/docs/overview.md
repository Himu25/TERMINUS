# STIX indicator fusion audit

Rust value normalization bridge and Go fusion broker for offline bundle replay under `/app`.
