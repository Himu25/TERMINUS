# Fusion audit replay layout

Fixture packs live under `/app/data/replay/`. Pack names are listed in `/app/docs/scenario_index.txt`. The default ingest target is `/app/data/active/`.

Each pack directory contains:

- `bundle_plan.json` — pack metadata consumed by the replay driver.
- `indicators.jsonl` — ordered indicator rows for that pack.

The outward audit artifact is written to `/app/output/fusion_audit_report.json`. Field definitions are in `/app/schemas/fusion_audit_report.schema.json`.
