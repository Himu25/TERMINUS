"""Validate /app/output/join_integrity_bench.json against join.toml guardrails."""

from __future__ import annotations

import contextlib
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "join_integrity_bench.json"
CFG = APP / "config" / "join.toml"
MANIFEST = APP / "registry" / "join_manifest.json"
STREAMS = APP / "data" / "streams_default.jsonl"


def _fixture(name: str) -> Path:
    root = Path(__file__).resolve().parent
    for child in root.iterdir():
        if child.is_dir():
            candidate = child / name
            if candidate.is_file():
                return candidate
    raise FileNotFoundError(name)

REPORT_KEYS = frozenset(
    {
        "status",
        "entity_total",
        "consumer_count",
        "join_profile",
        "streams_total",
        "mean_join_match_rate",
        "mean_watermark_coverage",
        "mean_propagation_units",
        "mean_stale_units",
        "p95_material_units",
        "mean_balance_score",
        "dedup_purity_rate",
        "timestamp_order_rate",
        "mean_consumer_lag_units",
        "report_digest",
        "streams",
    }
)
STREAM_KEYS = frozenset(
    {
        "stream_id",
        "join_match_rate",
        "watermark_coverage",
        "propagation_units",
        "stale_units",
        "consumer_lag_units",
        "dedup_purity",
        "timestamp_order_rate",
        "workers_active",
        "balance_score",
        "entity_ids",
    }
)

_SUBPROC_ENV = os.environ.copy()
_path_prefix = "/usr/local/go/bin:/app/bin:"
_SUBPROC_ENV["PATH"] = _path_prefix + _SUBPROC_ENV.get("PATH", "")
_SUBPROC_ENV["LD_LIBRARY_PATH"] = "/app/lib:" + _SUBPROC_ENV.get("LD_LIBRARY_PATH", "")
_GO_BUILD_TIMEOUT = 120
_RUST_BUILD_TIMEOUT = 240
_RUN_TIMEOUT = 120

# Shipped join.toml defaults; enforced so lowering join.toml cannot pass balance checks.
ENFORCED_FLOORS: dict[str, float] = {
    "join_match_floor": 0.98,
    "watermark_coverage_floor": 0.95,
    "balance_floor": 0.72,
    "dedup_purity_floor": 0.95,
    "timestamp_order_floor": 0.95,
    "failover_join_match_floor": 0.9,
    "skew_balance_min": 0.65,
    "unicode_mix_join_match_floor": 0.9999,
}
ENFORCED_CEILINGS: dict[str, float | int] = {
    "max_mean_propagation_units": 2200,
    "max_mean_stale_units": 1200,
    "max_p95_material_units": 9000,
    "max_mean_consumer_lag_units": 800,
    "unicode_mix_max_stale_units": 0,
}


def _effective_floor(cfg: dict, key: str) -> float:
    return max(cfg[key], ENFORCED_FLOORS[key])


def _effective_ceiling(cfg: dict, key: str) -> float | int:
    return min(cfg[key], ENFORCED_CEILINGS[key])


def _parse_cfg() -> dict:
    cfg: dict = {
        "consumer_count": 4,
        "join_profile": "v3",
        "join_match_floor": 0.98,
        "watermark_coverage_floor": 0.95,
        "max_mean_propagation_units": 2200,
        "max_mean_stale_units": 1200,
        "max_p95_material_units": 9000,
        "balance_floor": 0.72,
        "dedup_purity_floor": 0.95,
        "timestamp_order_floor": 0.95,
        "max_mean_consumer_lag_units": 800,
        "failover_join_match_floor": 0.9,
        "skew_balance_min": 0.65,
        "unicode_mix_join_match_floor": 0.9999,
        "unicode_mix_max_stale_units": 0,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in (
            "join_match_floor",
            "watermark_coverage_floor",
            "balance_floor",
            "dedup_purity_floor",
            "timestamp_order_floor",
            "failover_join_match_floor",
            "skew_balance_min",
            "unicode_mix_join_match_floor",
        ):
            cfg[key] = float(val)
        elif key in (
            "consumer_count",
            "max_mean_propagation_units",
            "max_mean_stale_units",
            "max_p95_material_units",
            "max_mean_consumer_lag_units",
            "unicode_mix_max_stale_units",
        ):
            cfg[key] = int(float(val))
        elif key == "join_profile":
            cfg[key] = val
    return cfg


def _digest_payload(report: dict) -> dict:
    return {
        "status": report["status"],
        "entity_total": report["entity_total"],
        "consumer_count": report["consumer_count"],
        "join_profile": report["join_profile"],
        "streams_total": report["streams_total"],
        "mean_join_match_rate": report["mean_join_match_rate"],
        "mean_watermark_coverage": report["mean_watermark_coverage"],
        "mean_propagation_units": report["mean_propagation_units"],
        "mean_stale_units": report["mean_stale_units"],
        "p95_material_units": report["p95_material_units"],
        "mean_balance_score": report["mean_balance_score"],
        "dedup_purity_rate": report["dedup_purity_rate"],
        "timestamp_order_rate": report["timestamp_order_rate"],
        "mean_consumer_lag_units": report["mean_consumer_lag_units"],
        "report_digest": "",
        "streams": report["streams"],
    }


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _go_rebuild_and_run(
    streams_path: Path | None = None,
    out_path: Path | None = None,
) -> dict:
    """Rebuild only joinbench and run on the default stream pack."""
    streams_path = streams_path or STREAMS
    out_path = out_path or OUT
    env = dict(_SUBPROC_ENV)
    lib_dir = str(APP / "lib")
    env["CGO_LDFLAGS"] = f"-L{lib_dir} -lzetacore"
    out_path.unlink(missing_ok=True)
    subprocess.run(
        ["go", "build", "-o", str(APP / "bin" / "joinbench"), "./cmd/joinbench"],
        cwd=APP,
        check=True,
        timeout=_GO_BUILD_TIMEOUT,
        env=env,
    )
    subprocess.run(
        ["/app/bin/joinbench", streams_path.as_posix(), out_path.as_posix()],
        cwd=APP,
        check=True,
        timeout=_RUN_TIMEOUT,
        env=env,
    )
    return json.loads(out_path.read_text(encoding="utf-8"))


def _rebuild_and_run(
    streams_path: Path | None = None,
    out_path: Path | None = None,
) -> dict:
    """Full Rust+Go rebuild for ablation swaps that touch lib.rs."""
    streams_path = streams_path or STREAMS
    out_path = out_path or OUT
    out_path.unlink(missing_ok=True)
    subprocess.run(
        ["bash", "/app/scripts/build_all.sh"],
        cwd=APP,
        check=True,
        timeout=_RUST_BUILD_TIMEOUT,
        env=_SUBPROC_ENV,
    )
    subprocess.run(
        ["/app/bin/joinbench", streams_path.as_posix(), out_path.as_posix()],
        cwd=APP,
        check=True,
        timeout=_RUN_TIMEOUT,
        env=_SUBPROC_ENV,
    )
    return json.loads(out_path.read_text(encoding="utf-8"))


@contextlib.contextmanager
def _swap_file(src: Path, dst: Path):
    """Temporarily replace dst with src, restoring original on exit."""
    backup = dst.read_bytes()
    shutil.copy2(src, dst)
    os.utime(dst)
    try:
        yield
    finally:
        dst.write_bytes(backup)


def _stream_rows(report: dict) -> dict[str, dict]:
    return {row["stream_id"]: row for row in report["streams"]}


@pytest.fixture(scope="module")
def cfg() -> dict:
    return _parse_cfg()


@pytest.fixture(scope="module")
def default_report() -> dict:
    if not OUT.is_file():
        pytest.fail(f"missing agent output at {OUT}")
    try:
        return json.loads(OUT.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        pytest.fail(f"invalid JSON at {OUT}: {exc}")


def test_report_schema_and_digest(default_report: dict) -> None:
    """Top-level schema and report_digest must match compact pre-digest JSON."""
    assert set(default_report.keys()) == REPORT_KEYS
    assert re.fullmatch(r"[0-9a-f]{64}", default_report["report_digest"])
    assert default_report["report_digest"] == _expected_digest(default_report)
    for row in default_report["streams"]:
        assert set(row.keys()) == STREAM_KEYS


def test_join_toml_floors_not_lowered(cfg: dict) -> None:
    """Shipped join.toml quality floors must not be lowered or ceilings raised."""
    for key, minimum in ENFORCED_FLOORS.items():
        assert cfg[key] == minimum, f"{key} changed from shipped floor {minimum}"
    for key, maximum in ENFORCED_CEILINGS.items():
        assert cfg[key] == maximum, f"{key} changed from shipped ceiling {maximum}"


def test_default_pack_quality_floors(default_report: dict, cfg: dict) -> None:
    """Default stream pack must meet join.toml mean floors and ceilings."""
    assert default_report["status"] == "ok"
    assert default_report["streams_total"] == len(
        [ln for ln in STREAMS.read_text(encoding="utf-8").splitlines() if ln.strip()]
    )
    assert default_report["mean_join_match_rate"] >= _effective_floor(cfg, "join_match_floor")
    assert default_report["mean_watermark_coverage"] >= _effective_floor(
        cfg, "watermark_coverage_floor"
    )
    assert int(default_report["mean_propagation_units"]) <= _effective_ceiling(
        cfg, "max_mean_propagation_units"
    )
    assert int(default_report["mean_stale_units"]) <= _effective_ceiling(cfg, "max_mean_stale_units")
    assert default_report["p95_material_units"] <= _effective_ceiling(cfg, "max_p95_material_units")
    assert default_report["mean_balance_score"] >= _effective_floor(cfg, "balance_floor")
    assert default_report["dedup_purity_rate"] >= _effective_floor(cfg, "dedup_purity_floor")
    assert default_report["timestamp_order_rate"] >= _effective_floor(cfg, "timestamp_order_floor")
    assert int(default_report["mean_consumer_lag_units"]) <= _effective_ceiling(
        cfg, "max_mean_consumer_lag_units"
    )


def test_unicode_mix_stream_row(default_report: dict, cfg: dict) -> None:
    """s_unicode_mix must reach full join match on unicode-heavy entities."""
    row = _stream_rows(default_report)["s_unicode_mix"]
    assert row["join_match_rate"] >= _effective_floor(cfg, "unicode_mix_join_match_floor")
    assert row["stale_units"] <= _effective_ceiling(cfg, "unicode_mix_max_stale_units")


def test_late_arrival_stream_watermark(default_report: dict, cfg: dict) -> None:
    """Late-arrival window on s_late_arrival must still meet watermark_coverage_floor."""
    row = _stream_rows(default_report)["s_late_arrival"]
    assert row["watermark_coverage"] >= _effective_floor(cfg, "watermark_coverage_floor")
    assert row["join_match_rate"] >= _effective_floor(cfg, "join_match_floor")


def test_clock_skew_timestamp_order(default_report: dict, cfg: dict) -> None:
    """Ingest skew on s_clock_skew must still yield timestamp_order_rate at floor."""
    row = _stream_rows(default_report)["s_clock_skew"]
    assert row["timestamp_order_rate"] >= _effective_floor(cfg, "timestamp_order_floor")


def test_dup_burst_dedup_purity(default_report: dict, cfg: dict) -> None:
    """Duplicate replay on s_dup_burst must meet dedup_purity on the stream row."""
    row = _stream_rows(default_report)["s_dup_burst"]
    assert row["dedup_purity"] >= _effective_floor(cfg, "dedup_purity_floor")


def test_failover_streams_keep_integrity(default_report: dict, cfg: dict) -> None:
    """Failover streams must stay above failover_join_match_floor with reduced workers_active."""
    rows = _stream_rows(default_report)
    fail = rows["s_failover_lane"]
    multi = rows["s_failover_multi"]
    assert fail["workers_active"] == cfg["consumer_count"] - 1
    assert multi["workers_active"] == cfg["consumer_count"] - 2
    assert fail["join_match_rate"] >= _effective_floor(cfg, "failover_join_match_floor")
    assert multi["join_match_rate"] >= _effective_floor(cfg, "failover_join_match_floor")


def test_size_skew_balance_floor(default_report: dict, cfg: dict) -> None:
    """Uneven entity payload sizes must still yield balance_score at or above skew_balance_min."""
    row = _stream_rows(default_report)["s_size_skew"]
    assert row["balance_score"] >= _effective_floor(cfg, "skew_balance_min")


def test_watermark_gap_join_match(default_report: dict, cfg: dict) -> None:
    """Multi-key spread on s_watermark_gap must still meet join_match_floor."""
    row = _stream_rows(default_report)["s_watermark_gap"]
    assert row["join_match_rate"] >= _effective_floor(cfg, "join_match_floor")


def test_join_profile_matches_manifest(default_report: dict) -> None:
    """join_profile in the report must match registry join_manifest.json."""
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    assert default_report["join_profile"] == manifest["join_profile"]


def test_determinism_repeat_run(default_report: dict) -> None:
    """Identical inputs must yield byte-identical join_integrity_bench.json."""
    first = OUT.read_bytes()
    OUT.unlink(missing_ok=True)
    subprocess.run(
        ["/app/bin/joinbench", STREAMS.as_posix(), OUT.as_posix()],
        cwd=APP,
        check=True,
        timeout=_RUN_TIMEOUT,
        env=_SUBPROC_ENV,
    )
    second = OUT.read_bytes()
    assert first == second


def test_z_ablation_m1_fails_watermark() -> None:
    """Truncated read window must not satisfy watermark coverage on s_late_arrival."""
    with _swap_file(_fixture("z_w1.go"), APP / "ax" / "w1.go"):
        report = _go_rebuild_and_run(out_path=APP / "output" / "join_ablation_m1.json")
    row = _stream_rows(report)["s_late_arrival"]
    assert report["status"] == "fail" or row["watermark_coverage"] < ENFORCED_FLOORS[
        "watermark_coverage_floor"
    ]


def test_z_ablation_m2_fails_timestamp_rate() -> None:
    """Ingest-time sort key must drop timestamp_order_rate on s_clock_skew."""
    with _swap_file(_fixture("z_w2.go"), APP / "bx" / "w2.go"):
        report = _go_rebuild_and_run(out_path=APP / "output" / "join_ablation_m2.json")
    row = _stream_rows(report)["s_clock_skew"]
    assert row["timestamp_order_rate"] < ENFORCED_FLOORS["timestamp_order_floor"]


def test_z_ablation_m3_fails_purity() -> None:
    """Entity-only seq gate must collapse dedup_purity on s_dup_burst."""
    with _swap_file(_fixture("z_w3.go"), APP / "cx" / "w3.go"):
        report = _go_rebuild_and_run(out_path=APP / "output" / "join_ablation_m3.json")
    row = _stream_rows(report)["s_dup_burst"]
    assert row["dedup_purity"] < ENFORCED_FLOORS["dedup_purity_floor"]


def test_z_ablation_m5_fails_balance() -> None:
    """Single-lane assignment must fail balance on s_size_skew."""
    with _swap_file(_fixture("z_w5.go"), APP / "cx" / "w5.go"):
        report = _go_rebuild_and_run(out_path=APP / "output" / "join_ablation_m5.json")
    row = _stream_rows(report)["s_size_skew"]
    assert row["balance_score"] < ENFORCED_FLOORS["skew_balance_min"]


def test_z_ablation_m6_fails_unicode() -> None:
    """Broken Rust normalization must collapse join_match_rate on s_unicode_mix."""
    with _swap_file(_fixture("z_r1.rs"), APP / "zfold" / "src" / "lib.rs"):
        report = _rebuild_and_run(out_path=APP / "output" / "join_ablation_m6.json")
    row = _stream_rows(report)["s_unicode_mix"]
    assert row["join_match_rate"] < 0.95
