#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

log "preflight: streaming join integrity workspace"
test -f /app/go.mod
test -f /app/config/join.toml
test -f /app/data/entities_default.json
test -f /app/data/stream_specs.jsonl
mkdir -p /app/bin /app/lib /app/output

log "survey: guardrails and subsystem layout"
grep -nE 'watermark|propagation|join|timestamp|lag' \
  /app/config/join.toml /app/metrics/guardrails.txt /app/policies/retention.txt 2>/dev/null | head -n 20 || true
wc -l /app/bench/drive.go /app/scripts/build_all.sh

log "apply oracle patches to streaming subsystems"
install -m 0644 "${ROOT_DIR}/oracle/w1.go" /app/ax/w1.go
install -m 0644 "${ROOT_DIR}/oracle/w2.go" /app/bx/w2.go
install -m 0644 "${ROOT_DIR}/oracle/w3.go" /app/cx/w3.go
install -m 0644 "${ROOT_DIR}/oracle/w5.go" /app/cx/w5.go
install -m 0644 "${ROOT_DIR}/oracle/w6.go" /app/dx/w6.go
install -m 0644 "${ROOT_DIR}/oracle/r1.rs" /app/zfold/src/lib.rs

log "rebuild Rust shared library and Go joinbench driver"
bash /app/scripts/build_all.sh

log "regenerate default stream pack after materializer repair"
/app/bin/refgen \
  /app/data/entities_default.json \
  /app/data/stream_specs.jsonl \
  /app/data/streams_default.jsonl

log "run default join integrity bench report"
export LD_LIBRARY_PATH="/app/lib:${LD_LIBRARY_PATH:-}"
chmod +x /app/scripts/run_bench.sh
/app/scripts/run_bench.sh /app/data/streams_default.jsonl /app/output/join_integrity_bench.json

log "done"
