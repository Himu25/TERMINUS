package cx

import (
	"sort"
	"unicode/utf8"

	"joinlab.dev/streamjoin/pkg/types"
)

// KpBx assigns entities to consumer lanes for one stream scenario.
func KpBx(entities []types.Entity, workers int) [][]types.Entity {
	if workers < 1 {
		workers = 1
	}
	sort.Slice(entities, func(i, j int) bool {
		return utf8.RuneCountInString(entities[i].Payload) > utf8.RuneCountInString(entities[j].Payload)
	})
	out := make([][]types.Entity, workers)
	loads := make([]int, workers)
	left, right := 0, len(entities)-1
	for left <= right {
		if left == right {
			lane := minLoadLane(loads)
			out[lane] = append(out[lane], entities[left])
			loads[lane] += utf8.RuneCountInString(entities[left].Payload)
			break
		}
		lane := minLoadLane(loads)
		out[lane] = append(out[lane], entities[left], entities[right])
		loads[lane] += utf8.RuneCountInString(entities[left].Payload) + utf8.RuneCountInString(entities[right].Payload)
		left++
		right--
	}
	return out
}

func minLoadLane(loads []int) int {
	lane := 0
	for i := 1; i < len(loads); i++ {
		if loads[i] < loads[lane] {
			lane = i
		}
	}
	return lane
}
