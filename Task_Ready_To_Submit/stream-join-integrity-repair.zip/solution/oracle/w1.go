package ax

import "joinlab.dev/streamjoin/pkg/types"

// DlApplyWindow returns the event slice visible to materialization after lag budgeting.
func DlApplyWindow(events []types.StreamEvent, lagCap int) []types.StreamEvent {
	if lagCap <= 0 || len(events) <= lagCap {
		return events
	}
	return events[len(events)-lagCap:]
}

// DlLagUnits estimates synthetic consumer lag from the ordered event log.
func DlLagUnits(events []types.StreamEvent) int {
	if len(events) < 2 {
		return 0
	}
	minMs := events[0].EventMs
	maxMs := events[0].EventMs
	for _, ev := range events[1:] {
		if ev.EventMs < minMs {
			minMs = ev.EventMs
		}
		if ev.EventMs > maxMs {
			maxMs = ev.EventMs
		}
	}
	return int(maxMs - minMs)
}
