package main

import (
	"fmt"
	"os"

	"joinlab.dev/streamjoin/bench"
)

func main() {
	if len(os.Args) < 3 {
		fmt.Fprintln(os.Stderr, "usage: joinbench <streams.jsonl> <out.json>")
		os.Exit(2)
	}
	cfg, err := bench.LoadCfg("/app/config/join.toml")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	cases, err := bench.LoadStreams(os.Args[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	report, err := bench.Run(cfg, cases)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if err := bench.WriteReport(os.Args[2], report); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
