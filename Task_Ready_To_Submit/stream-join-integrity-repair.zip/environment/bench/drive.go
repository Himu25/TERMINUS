package bench

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"
	"unicode/utf8"

	"joinlab.dev/streamjoin/corpus"
	"joinlab.dev/streamjoin/ax"
	"joinlab.dev/streamjoin/cx"
	"joinlab.dev/streamjoin/ledger"
	"joinlab.dev/streamjoin/pipeline"
	"joinlab.dev/streamjoin/pkg/types"
	"joinlab.dev/streamjoin/dx"
	"joinlab.dev/streamjoin/bx"
)

func Run(cfg types.JoinCfg, cases []types.StreamCase) (types.JoinReport, error) {
	if override := os.Getenv("TB_ENTITY_PATH"); override != "" {
		cfg.CorpusPath = override
	}
	entities, err := corpus.Load(cfg.CorpusPath)
	if err != nil {
		return types.JoinReport{}, err
	}
	byID := corpus.ByID(entities)
	report := types.JoinReport{
		Status:        "ok",
		EntityTotal:   len(entities),
		ConsumerCount: cfg.ConsumerCount,
		JoinProfile:  cfg.JoinProfile,
		StreamsTotal:  len(cases),
	}
	var sumIntegrity, sumFresh, sumProp, sumStale, sumBal, sumDedup, sumOrder, sumLag float64
	materialVals := make([]int, 0, len(cases))
	report.Streams = make([]types.StreamRow, 0, len(cases))

	for _, sc := range cases {
		cx.KpReset()
		streamEntities := make([]types.Entity, 0, len(sc.EntityIDs))
		for _, id := range sc.EntityIDs {
			if e, ok := byID[id]; ok {
				streamEntities = append(streamEntities, e)
			}
		}
		events := synthEvents(streamEntities, sc)
		sort.Slice(events, func(i, j int) bool {
			return bx.ThOrderKey(events[i]) < bx.ThOrderKey(events[j])
		})
		orderRate := timestampOrderRate(events)
		lagUnits := ax.DlLagUnits(events)
		windowed := ax.DlApplyWindow(events, sc.LagCapUnits)
		dedupTotal, dedupKept := 0, 0
		accepted := make([]types.StreamEvent, 0, len(windowed))
		for _, ev := range windowed {
			dedupTotal++
			if cx.KpAccept(ev.EntityID, ev.Seq) {
				dedupKept++
				accepted = append(accepted, ev)
			}
		}
		dedupPurity := 1.0
		if dedupTotal > 0 {
			dedupPurity = float64(dedupKept) / float64(dedupTotal)
		}
		watermark := bx.ThWatermark(accepted)

		active := cx.KpWx(cfg.ConsumerCount, sc.DeadWorkers)
		lanes := cx.KpBx(entityPayloads(accepted), cfg.ConsumerCount)
		var spill []types.Entity
		firstLive := -1
		for lane, batch := range lanes {
			if lane >= cfg.ConsumerCount {
				continue
			}
			if isDead(lane, sc.DeadWorkers) {
				spill = append(spill, batch...)
				lanes[lane] = nil
				continue
			}
			if firstLive < 0 {
				firstLive = lane
			}
		}
		if firstLive >= 0 && len(spill) > 0 {
			lanes[firstLive] = append(lanes[firstLive], spill...)
		}

		matches := 0
		propUnits := 0
		staleUnits := 0
		materialUnits := 0
		perLaneRunes := make([]int, cfg.ConsumerCount)
		unicodeHits, unicodeTotal := 0, 0
		freshHits := 0

		for lane, batch := range lanes {
			if lane >= cfg.ConsumerCount || isDead(lane, sc.DeadWorkers) {
				continue
			}
			for _, ent := range batch {
				runes := utf8.RuneCountInString(ent.Payload)
				perLaneRunes[lane] += runes
				key := dx.SgHx(ent.ID)
				var digest string
				if cached, ok := dx.SgRd(key); ok {
					digest = cached.Digest
					if digest != ledger.DgFold(ent.Payload) {
						staleUnits += runes
					}
				} else {
					dg, _, alloc, err := dx.SgZc(ent.Payload)
					if err != nil {
						return types.JoinReport{}, err
					}
					digest = dg
					dx.SgWr(key, digest, 0)
					materialUnits += alloc
				}
				if digest == ledger.DgFold(ent.Payload) {
					matches++
					if eventMsForEntity(accepted, ent.ID) <= watermark {
						freshHits++
					}
				}
				if pipeline.HasUnicodeRunes(ent.Payload) {
					unicodeTotal++
					if digest == ledger.DgFold(ent.Payload) {
						unicodeHits++
					}
				}
			}
		}

		baseRunes := 0
		for _, r := range perLaneRunes {
			baseRunes += r
		}
		propUnits = baseRunes
		if active < cfg.ConsumerCount {
			propUnits = baseRunes * cfg.ConsumerCount
		}

		integrity := 0.0
		if len(streamEntities) > 0 {
			integrity = float64(matches) / float64(len(streamEntities))
		}
		freshness := 0.0
		if len(streamEntities) > 0 {
			freshness = float64(freshHits) / float64(len(streamEntities))
		}
		balance := balanceScore(perLaneRunes, sc.DeadWorkers)
		row := types.StreamRow{
			StreamID:           sc.StreamID,
			JoinMatchRate:   round4(integrity),
			WatermarkCoverage:     round4(freshness),
			PropagationUnits:   propUnits,
			StaleUnits:         staleUnits,
			ConsumerLagUnits:   lagUnits,
			DedupPurity:        round4(dedupPurity),
			TimestampOrderRate: round4(orderRate),
			WorkersActive:      active,
			BalanceScore:       round4(balance),
			EntityIDs:          append([]string(nil), sc.EntityIDs...),
		}
		report.Streams = append(report.Streams, row)
		sumIntegrity += integrity
		sumFresh += freshness
		sumProp += float64(propUnits)
		sumStale += float64(staleUnits)
		sumBal += balance
		sumDedup += dedupPurity
		sumOrder += orderRate
		sumLag += float64(lagUnits)
		materialVals = append(materialVals, materialUnits)
		_ = unicodeHits
		_ = unicodeTotal
	}

	n := float64(len(cases))
	if n > 0 {
		report.MeanJoinMatchRate = round4(sumIntegrity / n)
		report.MeanWatermarkCoverage = round4(sumFresh / n)
		report.MeanPropagationUnits = round4(sumProp / n)
		report.MeanStaleUnits = round4(sumStale / n)
		report.MeanBalanceScore = round4(sumBal / n)
		report.DedupPurityRate = round4(sumDedup / n)
		report.TimestampOrderRate = round4(sumOrder / n)
		report.MeanConsumerLagUnits = round4(sumLag / n)
	}
	report.P95MaterialUnits = p95(materialVals)
	if !meetsFloors(cfg, report) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func synthEvents(entities []types.Entity, sc types.StreamCase) []types.StreamEvent {
	replay := 1
	if sc.DupReplay > 1 {
		replay = sc.DupReplay
	}
	out := make([]types.StreamEvent, 0, len(entities)*replay)
	for i, ent := range entities {
		eventMs := int64(1000 + i*100)
		ingestMs := eventMs
		if sc.IngestSkewMs > 0 {
			ingestMs = eventMs + int64(sc.IngestSkewMs) - int64(i*200)
		}
		for r := 0; r < replay; r++ {
			seq := uint64(i+1) + uint64(r)*10000
			out = append(out, types.StreamEvent{
				EntityID: ent.ID,
				Seq:      seq,
				EventMs:  eventMs,
				IngestMs: ingestMs,
				Payload:  ent.Payload,
			})
		}
	}
	return out
}

func entityPayloads(events []types.StreamEvent) []types.Entity {
	out := make([]types.Entity, 0, len(events))
	for _, ev := range events {
		out = append(out, types.Entity{ID: ev.EntityID, Payload: ev.Payload})
	}
	return out
}

func eventMsForEntity(events []types.StreamEvent, entityID string) int64 {
	var max int64
	for _, ev := range events {
		if ev.EntityID == entityID && ev.EventMs > max {
			max = ev.EventMs
		}
	}
	return max
}

func timestampOrderRate(events []types.StreamEvent) float64 {
	if len(events) < 2 {
		return 1.0
	}
	ordered := append([]types.StreamEvent(nil), events...)
	sort.Slice(ordered, func(i, j int) bool {
		return ordered[i].EventMs < ordered[j].EventMs
	})
	matches := 0
	for i := 1; i < len(events); i++ {
		if events[i].EventMs >= events[i-1].EventMs {
			matches++
		}
	}
	return float64(matches) / float64(len(events)-1)
}

func isDead(lane int, dead []int) bool {
	for _, d := range dead {
		if d == lane {
			return true
		}
	}
	return false
}

func balanceScore(perLane []int, dead []int) float64 {
	vals := make([]int, 0, len(perLane))
	total := 0
	for i, v := range perLane {
		if isDead(i, dead) || v == 0 {
			continue
		}
		vals = append(vals, v)
		total += v
	}
	if total == 0 || len(vals) == 0 {
		return 1.0
	}
	activeConfigured := 0
	for i := range perLane {
		if !isDead(i, dead) {
			activeConfigured++
		}
	}
	if len(dead) == 0 && activeConfigured > 1 && len(vals) == 1 {
		return 0.0
	}
	minV, maxV := vals[0], vals[0]
	for _, v := range vals {
		if v < minV {
			minV = v
		}
		if v > maxV {
			maxV = v
		}
	}
	spread := float64(maxV-minV) / float64(total)
	score := 1.0 - spread
	if score < 0 {
		return 0
	}
	if score > 1 {
		return 1
	}
	return score
}

func meetsFloors(cfg types.JoinCfg, report types.JoinReport) bool {
	if report.MeanJoinMatchRate < cfg.IntegrityFloor {
		return false
	}
	if report.MeanWatermarkCoverage < cfg.FreshnessFloor {
		return false
	}
	if int(report.MeanPropagationUnits) > cfg.MaxMeanPropagationUnits {
		return false
	}
	if int(report.MeanStaleUnits) > cfg.MaxMeanStaleUnits {
		return false
	}
	if report.P95MaterialUnits > cfg.MaxP95MaterialUnits {
		return false
	}
	if report.MeanBalanceScore < cfg.BalanceFloor {
		return false
	}
	if report.DedupPurityRate < cfg.DedupPurityFloor {
		return false
	}
	if report.TimestampOrderRate < cfg.TimestampOrderFloor {
		return false
	}
	if int(report.MeanConsumerLagUnits) > cfg.MaxMeanConsumerLagUnits {
		return false
	}
	return true
}

func round4(v float64) float64 {
	if v > 1 {
		return 1
	}
	if v < 0 {
		return 0
	}
	return math.Round(v*10000+0.5) / 10000
}

func p95(vals []int) int {
	if len(vals) == 0 {
		return 0
	}
	cp := append([]int(nil), vals...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}

type digestPayload struct {
	Status               string             `json:"status"`
	EntityTotal          int                `json:"entity_total"`
	ConsumerCount        int                `json:"consumer_count"`
	JoinProfile         string             `json:"join_profile"`
	StreamsTotal         int                `json:"streams_total"`
	MeanJoinMatchRate float64            `json:"mean_join_match_rate"`
	MeanWatermarkCoverage   float64            `json:"mean_watermark_coverage"`
	MeanPropagationUnits float64            `json:"mean_propagation_units"`
	MeanStaleUnits       float64            `json:"mean_stale_units"`
	P95MaterialUnits     int                `json:"p95_material_units"`
	MeanBalanceScore     float64            `json:"mean_balance_score"`
	DedupPurityRate      float64            `json:"dedup_purity_rate"`
	TimestampOrderRate   float64            `json:"timestamp_order_rate"`
	MeanConsumerLagUnits float64            `json:"mean_consumer_lag_units"`
	ReportDigest         string             `json:"report_digest"`
	Streams              []types.StreamRow  `json:"streams"`
}

func digestBody(report types.JoinReport) string {
	payload := digestPayload{
		Status:               report.Status,
		EntityTotal:          report.EntityTotal,
		ConsumerCount:        report.ConsumerCount,
		JoinProfile:         report.JoinProfile,
		StreamsTotal:         report.StreamsTotal,
		MeanJoinMatchRate: report.MeanJoinMatchRate,
		MeanWatermarkCoverage:   report.MeanWatermarkCoverage,
		MeanPropagationUnits: report.MeanPropagationUnits,
		MeanStaleUnits:       report.MeanStaleUnits,
		P95MaterialUnits:     report.P95MaterialUnits,
		MeanBalanceScore:     report.MeanBalanceScore,
		DedupPurityRate:      report.DedupPurityRate,
		TimestampOrderRate:   report.TimestampOrderRate,
		MeanConsumerLagUnits: report.MeanConsumerLagUnits,
		ReportDigest:         "",
		Streams:              report.Streams,
	}
	raw, _ := json.Marshal(payload)
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func WriteReport(path string, report types.JoinReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}

func SanityProfile(profile string) error {
	if strings.TrimSpace(profile) == "" {
		return fmt.Errorf("empty join profile")
	}
	return nil
}
