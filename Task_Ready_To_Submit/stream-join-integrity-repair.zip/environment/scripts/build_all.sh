#!/bin/bash
set -euo pipefail

ROOT="/app"
mkdir -p "${ROOT}/bin" "${ROOT}/lib" "${ROOT}/output" "${ROOT}/output/cargo-target"

export CARGO_TARGET_DIR="${ROOT}/output/cargo-target"
export CARGO_HOME="${CARGO_HOME:-/usr/local/cargo}"
export CGO_LDFLAGS="-L${ROOT}/lib -lzetacore"
export LD_LIBRARY_PATH="${ROOT}/lib:${LD_LIBRARY_PATH:-}"

cd "${ROOT}/zfold"
cargo build --release --locked
install -m 0644 "${CARGO_TARGET_DIR}/release/libzetacore.so" "${ROOT}/lib/libzetacore.so"

cd "${ROOT}"
go build -o "${ROOT}/bin/joinbench" ./cmd/joinbench
go build -o "${ROOT}/bin/refgen" ./cmd/refgen

export LD_LIBRARY_PATH="${ROOT}/lib:${LD_LIBRARY_PATH:-}"

"${ROOT}/bin/refgen" \
  "${ROOT}/data/entities_default.json" \
  "${ROOT}/data/stream_specs.jsonl" \
  "${ROOT}/data/streams_default.jsonl"

install -m 0755 "${ROOT}/bin/joinbench" "${ROOT}/bin/joinmat"
