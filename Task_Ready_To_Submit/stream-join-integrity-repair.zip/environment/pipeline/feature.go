package pipeline

/*
#cgo LDFLAGS: -L${SRCDIR}/../lib -lzetacore
#include <stdlib.h>
#include <stdint.h>
char *ztFeat(const char *text, uint32_t *out_count, uint32_t *out_alloc);
void ztFree(char *ptr);
*/
import "C"
import (
	"fmt"
	"unsafe"
)

// FtEncode materializes a join-side digest via the Rust helper.
func FtEncode(text string) (digest string, tokens uint32, alloc int, err error) {
	cstr := C.CString(text)
	defer C.free(unsafe.Pointer(cstr))
	var count C.uint32_t
	var allocU C.uint32_t
	ptr := C.ztFeat(cstr, &count, &allocU)
	if ptr == nil {
		return "", 0, 0, fmt.Errorf("ztFeat failed")
	}
	defer C.ztFree(ptr)
	digest = C.GoString(ptr)
	return digest, uint32(count), int(allocU), nil
}

// HasUnicodeRunes reports whether text contains non-ASCII runes.
func HasUnicodeRunes(text string) bool {
	for _, r := range text {
		if r > 127 {
			return true
		}
	}
	return false
}
