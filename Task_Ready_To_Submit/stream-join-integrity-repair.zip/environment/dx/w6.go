package dx

import (
	"sync"

	"joinlab.dev/streamjoin/pipeline"
)

type Entry struct {
	Digest string
	Tokens uint32
}

var globalMu sync.Mutex
var globalTable = map[string]Entry{}

// SgHx derives a cache slot for an entity id.
func SgHx(entityID string) string {
	if len(entityID) >= 4 {
		return entityID[:4]
	}
	return entityID
}

// SgRd returns cached digest when present.
func SgRd(key string) (Entry, bool) {
	globalMu.Lock()
	defer globalMu.Unlock()
	e, ok := globalTable[key]
	return e, ok
}

// SgWr records a digest under key.
func SgWr(key, digest string, tokens uint32) {
	globalMu.Lock()
	defer globalMu.Unlock()
	globalTable[key] = Entry{Digest: digest, Tokens: tokens}
}

// SgZc runs materialization under the global cache lock.
func SgZc(text string) (digest string, tokens uint32, alloc int, err error) {
	globalMu.Lock()
	defer globalMu.Unlock()
	d, t, a, err := pipeline.FtEncode(text)
	return d, t, a, err
}
