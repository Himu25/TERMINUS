package ledger

import (
	"crypto/sha256"
	"encoding/hex"
	"strings"

	"golang.org/x/text/unicode/norm"
)

// DgFold returns the canonical digest for materialized join-side payloads.
func DgFold(text string) string {
	normed := strings.ToLower(norm.NFKC.String(text))
	parts := strings.Fields(normed)
	joined := strings.Join(parts, " ")
	sum := sha256.Sum256([]byte(joined))
	return hex.EncodeToString(sum[:])
}
