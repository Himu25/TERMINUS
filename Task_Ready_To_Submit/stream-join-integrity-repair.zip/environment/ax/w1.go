package ax

import "joinlab.dev/streamjoin/pkg/types"

// DlApplyWindow returns the event slice visible to materialization after lag budgeting.
func DlApplyWindow(events []types.StreamEvent, lagCap int) []types.StreamEvent {
	if len(events) <= 1 {
		return events
	}
	cut := len(events) / 2
	if lagCap > 0 && cut > lagCap {
		cut = lagCap
	}
	return events[:cut]
}

// DlLagUnits estimates synthetic consumer lag from the tail of the ordered log.
func DlLagUnits(events []types.StreamEvent) int {
	if len(events) == 0 {
		return 0
	}
	tail := events[len(events)-1]
	return int(tail.IngestMs - events[0].EventMs)
}
