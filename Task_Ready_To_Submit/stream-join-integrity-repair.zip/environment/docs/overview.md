Streaming join integrity lab under /app simulates multi-stream joins with Go consumers and a Rust materializer. See architecture.md for report schema and bench entrypoints.
