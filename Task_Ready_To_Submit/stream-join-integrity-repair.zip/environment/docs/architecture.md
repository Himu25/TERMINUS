# Architecture notes

Entity snapshots live at `/app/data/entities_default.json`. Stream scenarios are JSONL with `stream_id`, `entity_ids`, and optional `dead_workers`, `ingest_skew_ms`, `dup_replay`, or `lag_cap_units`. The Go driver `/app/bin/joinbench` loads `/app/config/join.toml`, materializes payloads through the Rust helper built from `/app/zfold`, and writes `/app/output/join_integrity_bench.json`. Rebuild with `/app/scripts/build_all.sh` and run `/app/scripts/run_bench.sh`.

Top-level report and per-stream row JSON field names match `pkg/types` (`JoinReport`, `StreamRow`). `report_digest` is computed from compact JSON with `report_digest` cleared before hashing; see `bench/drive.go` `digestBody`.

`join_match_rate` is the fraction of entities whose materialized digest matches the canonical fold in `ledger/fold.go`. Unit fields are synthetic cost tallies, not wall-clock timings. `propagation_units` adds a serial penalty when fewer consumers are active than `consumer_count`. `stale_units` counts extra rune work when a hot slot returns a digest that does not match the canonical fold.

Quality gates compare means against floors and ceilings in `join.toml`. Regenerate the default stream pack with `/app/bin/refgen` after entity edits.

Verifier ablation swaps may land in Go or Rust sources under `/app/ax`, `/app/bx`, `/app/cx`, `/app/dx`, or `/app/zfold` using fixture filenames `z_w1.go`, `z_w2.go`, `z_w3.go`, and `z_r1.rs`. Grading prepends `/usr/local/go/bin:/app/bin:` to PATH when invoking joinbench.
