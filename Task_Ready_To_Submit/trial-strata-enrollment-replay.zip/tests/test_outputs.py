"""Validate /app/output/enroll_report.json against trial.toml guardrails."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "enroll_report.json"
EVENTS = APP / "data" / "events_default.jsonl"
LAYOUT = APP / "data" / "strata_layout.json"
CFG = APP / "config" / "trial.toml"
CASES = Path(__file__).resolve().parent / "data"

_DEFAULT_EVENTS_TEXT = EVENTS.read_text(encoding="utf-8") if EVENTS.is_file() else ""

REPORT_KEYS = frozenset(
    {
        "status",
        "events_processed",
        "report_ok",
        "max_drift_units",
        "fill_total_bp",
        "pending_peak",
        "screen_carry_total",
        "enrolled_total",
        "report_digest",
        "sites",
        "strata",
    }
)
SITE_KEYS = frozenset(
    {
        "site_id",
        "fill_bp",
        "pending_peak",
        "enrolled",
        "drift_units",
    }
)
STRATUM_KEYS = frozenset(
    {
        "stratum_id",
        "filled",
        "fill_ratio_bp",
        "drift_units",
    }
)


def _parse_cfg() -> dict[str, int]:
    cfg: dict[str, int] = {
        "max_drift_units": 0,
        "max_pending_peak": 50000,
        "min_enrolled_total": 1,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in cfg:
            cfg[key] = int(float(val))
    return cfg


def _load_layout() -> dict[str, dict]:
    raw = json.loads(LAYOUT.read_text(encoding="utf-8"))
    stratum_arm = {k: v for k, v in raw["stratum_arm_bp"].items()}
    pending_scale = {1: 120, 2: 240, 3: 360}
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key == "pending_scale_slot1":
            pending_scale[1] = int(float(val))
        elif key == "pending_scale_slot2":
            pending_scale[2] = int(float(val))
        elif key == "pending_scale_slot3":
            pending_scale[3] = int(float(val))
    return {
        "stratum_arm_bp": stratum_arm,
        "pending_scale_slot1": pending_scale[1],
        "pending_scale_slot2": pending_scale[2],
        "pending_scale_slot3": pending_scale[3],
    }


def _parse_events(text: str) -> list[dict]:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if line:
            rows.append(json.loads(line))
    return rows


def _channel_rank(channel_id: str) -> int:
    if not channel_id:
        return 99
    last = channel_id[-1]
    if last.isdigit():
        return int(last)
    return 99


def _sort_events(rows: list[dict]) -> list[dict]:
    return sorted(
        rows,
        key=lambda row: (
            row["seq"],
            _channel_rank(row["channel_id"]),
            row["channel_id"],
            row["stratum_id"],
        ),
    )


def _slot_key(site: str, stratum: str, slot: int) -> str:
    return f"{site}:{stratum}:{slot}"


def _expected_from_events(events_text: str) -> dict[str, dict]:
    layout = _load_layout()
    stratum_arm = layout["stratum_arm_bp"]
    pending_scale = {
        1: layout["pending_scale_slot1"],
        2: layout["pending_scale_slot2"],
        3: layout["pending_scale_slot3"],
    }
    ordered = _sort_events(_parse_events(events_text))
    slots: dict[str, dict] = {}
    site_fill: dict[str, int] = {}
    site_occ: dict[str, int] = {}
    site_carry: dict[str, int] = {}
    stratum_fill: dict[str, int] = {}
    stratum_count: dict[str, int] = {}

    for ev in ordered:
        site = ev["site_id"]
        key = _slot_key(site, ev["stratum_id"], ev["slot"])
        arm = stratum_arm[ev["stratum_id"]]
        weight = ev["weight"]
        if ev["event_type"] in ("enroll", "withdraw"):
            delta = weight * arm // 100
            if ev["event_type"] == "withdraw":
                delta = -delta
            site_fill[site] = site_fill.get(site, 0) + delta
            stratum_fill[ev["stratum_id"]] = stratum_fill.get(ev["stratum_id"], 0) + delta
            if ev["event_type"] == "enroll":
                stratum_count[ev["stratum_id"]] = stratum_count.get(ev["stratum_id"], 0) + 1
            else:
                stratum_count[ev["stratum_id"]] = stratum_count.get(ev["stratum_id"], 0) - 1
        if ev["event_type"] == "enroll":
            if key not in slots:
                site_occ[site] = site_occ.get(site, 0) + 1
            slots[key] = {"slot": ev["slot"], "weight": weight}
        elif ev["event_type"] == "withdraw" and key in slots:
            del slots[key]
            site_occ[site] = site_occ.get(site, 0) - 1
        elif ev["event_type"] == "screen_fail":
            site_carry[site] = site_carry.get(site, 0) + 1

    sites: dict[str, dict] = {}
    for site in sorted({ev["site_id"] for ev in ordered}):
        prefix = f"{site}:"
        slot_enrolled = sum(1 for k in slots if k.startswith(prefix))
        peak = 0
        for k, info in slots.items():
            if not k.startswith(prefix):
                continue
            pending = info["weight"] * pending_scale[info["slot"]] // 1000
            peak = max(peak, pending)
        sites[site] = {
            "fill_bp": site_fill.get(site, 0),
            "enrolled": site_occ.get(site, 0),
            "pending_peak": peak,
            "drift_units": abs(site_occ.get(site, 0) - slot_enrolled),
        }

    strata: dict[str, dict] = {}
    for stratum in sorted({ev["stratum_id"] for ev in ordered}):
        filled = max(stratum_count.get(stratum, 0), 0)
        fill_val = stratum_fill.get(stratum, 0)
        ratio = fill_val // filled if filled > 0 else 0
        strata[stratum] = {
            "filled": filled,
            "fill_ratio_bp": ratio,
            "drift_units": 0,
        }

    total_fill = sum(v["fill_bp"] for v in sites.values())
    total_enrolled = sum(v["enrolled"] for v in sites.values())
    global_pending = max((v["pending_peak"] for v in sites.values()), default=0)
    max_drift = max((v["drift_units"] for v in sites.values()), default=0)
    total_carry = sum(site_carry.values())
    return {
        "sites": sites,
        "strata": strata,
        "fill_total_bp": total_fill,
        "enrolled_total": total_enrolled,
        "pending_peak": global_pending,
        "screen_carry_total": total_carry,
        "max_drift_units": max_drift,
        "events_processed": len(ordered),
    }


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _swap_fixture(stem: str) -> str:
    src = CASES / f"{stem}.jsonl"
    text = src.read_text(encoding="utf-8")
    _atomic_write_text(EVENTS, text)
    return text


def _expected_digest(report: dict) -> str:
    payload = dict(report)
    payload["report_digest"] = ""
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _invoke_default() -> None:
    proc = subprocess.run(
        ["/app/tools/run_replay"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "enroll_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


def _site_map(report: dict) -> dict[str, dict]:
    return {row["site_id"]: row for row in report["sites"]}


def _stratum_map(report: dict) -> dict[str, dict]:
    return {row["stratum_id"]: row for row in report["strata"]}


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    _invoke_default()


@pytest.fixture(autouse=True)
def restore_default_events() -> None:
    yield
    if _DEFAULT_EVENTS_TEXT:
        _atomic_write_text(EVENTS, _DEFAULT_EVENTS_TEXT)


def test_g1_schema() -> None:
    """Report must expose only the documented top-level keys."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS


def test_g8_row_shape() -> None:
    """Each site and stratum row must match the documented schemas."""
    report = _load_report()
    assert report["sites"]
    assert report["strata"]
    for row in report["sites"]:
        assert set(row.keys()) == SITE_KEYS
        assert isinstance(row["site_id"], str) and row["site_id"]
        assert isinstance(row["fill_bp"], int)
        assert isinstance(row["pending_peak"], int)
        assert isinstance(row["enrolled"], int)
        assert isinstance(row["drift_units"], int)
    for row in report["strata"]:
        assert set(row.keys()) == STRATUM_KEYS
        assert isinstance(row["stratum_id"], str) and row["stratum_id"]
        assert isinstance(row["filled"], int)
        assert isinstance(row["fill_ratio_bp"], int)
        assert isinstance(row["drift_units"], int)


def test_g2_guardrails() -> None:
    """Default bundle must finish ok and meet trial.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["report_ok"]
    assert report["max_drift_units"] <= cfg["max_drift_units"]
    assert report["enrolled_total"] >= cfg["min_enrolled_total"]
    assert report["pending_peak"] <= cfg["max_pending_peak"]


def test_g3_total_a() -> None:
    """Default replay fill_total_bp must match layout-derived replay."""
    expected = _expected_from_events(_DEFAULT_EVENTS_TEXT)
    report = _load_report()
    assert report["fill_total_bp"] == expected["fill_total_bp"]


def test_g4_total_b() -> None:
    """Default replay enrolled_total must match slot-derived enrollment."""
    expected = _expected_from_events(_DEFAULT_EVENTS_TEXT)
    report = _load_report()
    assert report["enrolled_total"] == expected["enrolled_total"]


def test_g16_carry_default() -> None:
    """Default replay screen_carry_total must match event-derived carryover."""
    expected = _expected_from_events(_DEFAULT_EVENTS_TEXT)
    report = _load_report()
    assert report["screen_carry_total"] == expected["screen_carry_total"]


def test_g17_strata_default() -> None:
    """Default replay stratum rows must match layout-derived fill ratios."""
    expected = _expected_from_events(_DEFAULT_EVENTS_TEXT)
    report = _load_report()
    strata = _stratum_map(report)
    for stratum_id, exp in expected["strata"].items():
        row = strata[stratum_id]
        assert row["filled"] == exp["filled"]
        assert row["fill_ratio_bp"] == exp["fill_ratio_bp"]


def test_g5_row_a() -> None:
    """S01 fill after stratum-B withdraw must match layout-derived replay."""
    expected = _expected_from_events(_DEFAULT_EVENTS_TEXT)
    report = _load_report()
    s01 = _site_map(report)["S01"]
    assert s01["fill_bp"] == expected["sites"]["S01"]["fill_bp"]


def test_g6_row_b() -> None:
    """S01 enrolled after stratum-B withdraw must match WAL ledger."""
    cfg = _parse_cfg()
    expected = _expected_from_events(_DEFAULT_EVENTS_TEXT)
    report = _load_report()
    s01 = _site_map(report)["S01"]
    assert s01["enrolled"] == expected["sites"]["S01"]["enrolled"]
    assert s01["drift_units"] <= cfg["max_drift_units"]


def test_g7_row_c() -> None:
    """S04 slot clash must reflect R1-first tie resolution."""
    expected = _expected_from_events(_DEFAULT_EVENTS_TEXT)
    report = _load_report()
    s04 = _site_map(report)["S04"]
    assert s04["fill_bp"] == expected["sites"]["S04"]["fill_bp"]
    assert s04["enrolled"] == expected["sites"]["S04"]["enrolled"]


def test_g9_count() -> None:
    """events_processed must equal non-empty rows in the active bundle."""
    expected = _expected_from_events(_DEFAULT_EVENTS_TEXT)
    report = _load_report()
    assert report["events_processed"] == expected["events_processed"]


def test_g15_digest() -> None:
    """report_digest must hash the compact pre-digest JSON payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_g10_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_g11_case_a() -> None:
    """Dual-channel open scenario must reconcile S01 fill and enrolled."""
    events_text = _swap_fixture("dual_channel_open")
    _invoke_default()
    expected = _expected_from_events(events_text)
    report = _load_report()
    cfg = _parse_cfg()
    s01 = _site_map(report)["S01"]
    assert s01["drift_units"] <= cfg["max_drift_units"]
    assert s01["fill_bp"] == expected["sites"]["S01"]["fill_bp"]
    assert s01["enrolled"] == expected["sites"]["S01"]["enrolled"]


def test_g12_case_b() -> None:
    """Stacked triple scenario must reconcile S02 fill and pending peak."""
    events_text = _swap_fixture("stacked_triple")
    _invoke_default()
    expected = _expected_from_events(events_text)
    report = _load_report()
    cfg = _parse_cfg()
    s02 = _site_map(report)["S02"]
    assert s02["drift_units"] <= cfg["max_drift_units"]
    assert s02["fill_bp"] == expected["sites"]["S02"]["fill_bp"]
    assert s02["enrolled"] == expected["sites"]["S02"]["enrolled"]
    assert s02["pending_peak"] == expected["sites"]["S02"]["pending_peak"]


def test_g13_case_c() -> None:
    """Slot clash scenario must keep R1-first weight on S04."""
    events_text = _swap_fixture("slot_clash")
    _invoke_default()
    expected = _expected_from_events(events_text)
    report = _load_report()
    cfg = _parse_cfg()
    s04 = _site_map(report)["S04"]
    assert s04["drift_units"] <= cfg["max_drift_units"]
    assert s04["fill_bp"] == expected["sites"]["S04"]["fill_bp"]
    assert s04["pending_peak"] == expected["sites"]["S04"]["pending_peak"]


def test_g14_case_d() -> None:
    """Withdraw-after-peer scenario must reconcile S01 ledger drift and carryover."""
    events_text = _swap_fixture("clear_after_peer")
    _invoke_default()
    expected = _expected_from_events(events_text)
    cfg = _parse_cfg()
    report = _load_report()
    s01 = _site_map(report)["S01"]
    assert s01["drift_units"] <= cfg["max_drift_units"]
    assert s01["enrolled"] == expected["sites"]["S01"]["enrolled"]
    assert report["screen_carry_total"] == expected["screen_carry_total"]
