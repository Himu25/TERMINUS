module tsr.lab

go 1.24
