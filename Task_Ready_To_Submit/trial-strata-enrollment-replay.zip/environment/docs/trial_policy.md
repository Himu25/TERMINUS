Trial enrollment replay semantics

Stratum fill uses subject weight times stratum arm from /app/data/strata_layout.json (basis-point arms keyed by stratum_id). Enroll events add fill; withdraw events subtract the same arm used at placement.

Pending peak per site is the maximum open screen load: weight times the slot pending scale from /app/config/trial.toml divided by 1000.

Enrolled counts distinct occupied slots per site after replay. Ledger slot keys combine site_id, stratum_id, and slot. Screen-failure carryover increments per site on screen_fail events and feeds screen_carry_total. Drift units compare ledger enrollment against slot-derived enrollment for each site.

Channel tie-break: when seq values match, lower channel_id runs first when channel_priority_asc is true in /app/config/trial.toml.

Report JSON top-level fields: status, events_processed, report_ok, max_drift_units, fill_total_bp, pending_peak, screen_carry_total, enrolled_total, report_digest, sites, strata. Each site row carries site_id, fill_bp, pending_peak, enrolled, drift_units. Each stratum row carries stratum_id, filled, fill_ratio_bp, drift_units. Report digest is 64 lowercase hex from compact JSON with report_digest blanked.
