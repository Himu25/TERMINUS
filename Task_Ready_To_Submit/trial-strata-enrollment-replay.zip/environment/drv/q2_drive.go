package drv

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"sort"
	"strings"

	"tsr.lab/j2"
	"tsr.lab/m7"
	"tsr.lab/p2"
	"tsr.lab/pkg/types"
	"tsr.lab/s4"
)

func LoadCfg(path string) (types.TrialCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.TrialCfg{}, err
	}
	cfg := types.TrialCfg{
		MaxDriftUnits:      0,
		MaxPendingPeak:     50000,
		MinEnrolledTotal:   1,
		ChannelPriorityAsc: true,
		PendingScaleMilli: map[int]int{
			1: 120,
			2: 240,
			3: 360,
		},
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "max_drift_units":
			fmt.Sscanf(val, "%d", &cfg.MaxDriftUnits)
		case "max_pending_peak":
			fmt.Sscanf(val, "%d", &cfg.MaxPendingPeak)
		case "min_enrolled_total":
			fmt.Sscanf(val, "%d", &cfg.MinEnrolledTotal)
		case "channel_priority_asc":
			cfg.ChannelPriorityAsc = val == "true" || val == "1"
		case "pending_scale_slot1":
			var v int
			fmt.Sscanf(val, "%d", &v)
			cfg.PendingScaleMilli[1] = v
		case "pending_scale_slot2":
			var v int
			fmt.Sscanf(val, "%d", &v)
			cfg.PendingScaleMilli[2] = v
		case "pending_scale_slot3":
			var v int
			fmt.Sscanf(val, "%d", &v)
			cfg.PendingScaleMilli[3] = v
		}
	}
	return cfg, nil
}

func LoadLayout(path string) (types.StrataLayout, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.StrataLayout{}, err
	}
	var layout struct {
		StratumArmBP map[string]int `json:"stratum_arm_bp"`
	}
	if err := json.Unmarshal(raw, &layout); err != nil {
		return types.StrataLayout{}, err
	}
	return types.StrataLayout{StratumArmBP: layout.StratumArmBP}, nil
}

func LoadEvents(path string) ([]types.EventRow, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.EventRow, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var row types.EventRow
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return nil, err
		}
		out = append(out, row)
	}
	return out, sc.Err()
}

func opCode(kind string) int {
	if kind == "withdraw" {
		return 1
	}
	return 0
}

func pendingFor(weight, slot int, cfg types.TrialCfg) int {
	scale, ok := cfg.PendingScaleMilli[slot]
	if !ok {
		scale = 100
	}
	return weight * scale / 1000
}

func sitePeakPending(site string, slots map[string]slotInfo, cfg types.TrialCfg) int {
	peak := 0
	for key, info := range slots {
		if !strings.HasPrefix(key, site+":") {
			continue
		}
		val := pendingFor(info.weight, info.slot, cfg)
		if val > peak {
			peak = val
		}
	}
	return peak
}

type slotInfo struct {
	slot   int
	weight int
}

func replaySiteState(slots map[string]slotInfo, site string) (fillBP int64, peak int, enrolled int) {
	prefix := site + ":"
	for key := range slots {
		if !strings.HasPrefix(key, prefix) {
			continue
		}
		enrolled++
	}
	return 0, 0, enrolled
}

func Run(cfg types.TrialCfg, layout types.StrataLayout, events []types.EventRow) (types.EnrollReport, error) {
	ordered := p2.UxPick(events)
	state := m7.MkK1()
	siteFill := make(map[string]int64)
	stratumFill := make(map[string]int64)
	stratumCount := make(map[string]int)
	slotMeta := make(map[string]slotInfo)

	for _, ev := range ordered {
		arm := layout.StratumArmBP[ev.StratumID]
		if ev.EventType == "enroll" || ev.EventType == "withdraw" {
			delta := s4.Q0Span(opCode(ev.EventType), ev.Weight, arm)
			siteFill[ev.SiteID] += delta
			stratumFill[ev.StratumID] += delta
			if ev.EventType == "enroll" {
				stratumCount[ev.StratumID]++
			} else if ev.EventType == "withdraw" {
				stratumCount[ev.StratumID]--
			}
		}
		m7.RxAccum(state, ev.SiteID, ev.StratumID, ev.Slot, ev.EventType, ev.Weight)
		key := fmt.Sprintf("%s:%s:%d", ev.SiteID, ev.StratumID, ev.Slot)
		switch ev.EventType {
		case "enroll":
			slotMeta[key] = slotInfo{slot: ev.Slot, weight: ev.Weight}
		case "withdraw":
			delete(slotMeta, key)
		}
	}

	siteIDs := make([]string, 0)
	seen := make(map[string]bool)
	for _, ev := range events {
		if !seen[ev.SiteID] {
			seen[ev.SiteID] = true
			siteIDs = append(siteIDs, ev.SiteID)
		}
	}
	sort.Strings(siteIDs)

	stratumIDs := make([]string, 0)
	seenStrata := make(map[string]bool)
	for _, ev := range events {
		if !seenStrata[ev.StratumID] {
			seenStrata[ev.StratumID] = true
			stratumIDs = append(stratumIDs, ev.StratumID)
		}
	}
	sort.Strings(stratumIDs)

	report := types.EnrollReport{
		Status:          "ok",
		EventsProcessed: len(ordered),
		Sites:           make([]types.SiteSnapshot, 0, len(siteIDs)),
		Strata:          make([]types.StratumSnapshot, 0, len(stratumIDs)),
	}
	var totalFill int64
	maxDrift := 0
	globalPendingPeak := 0
	totalEnrolled := 0
	totalCarry := 0

	for _, site := range siteIDs {
		enrolled := state.SiteOcc[site]
		fill := siteFill[site]
		peak := sitePeakPending(site, slotMeta, cfg)
		_, _, enrolledCheck := replaySiteState(slotMeta, site)
		drift := j2.S6Fold(fill, enrolled, enrolledCheck)
		if drift < 0 {
			drift = -drift
		}
		if drift > maxDrift {
			maxDrift = drift
		}
		if peak > globalPendingPeak {
			globalPendingPeak = peak
		}
		totalFill += fill
		totalEnrolled += enrolled
		totalCarry += state.SiteCarry[site]
		report.Sites = append(report.Sites, types.SiteSnapshot{
			SiteID:      site,
			FillBP:      fill,
			PendingPeak: peak,
			Enrolled:    enrolled,
			DriftUnits:  drift,
		})
	}

	for _, stratum := range stratumIDs {
		filled := stratumCount[stratum]
		if filled < 0 {
			filled = 0
		}
		fill := stratumFill[stratum]
		ratio := 0
		if filled > 0 {
			ratio = int(fill) / filled
		}
		report.Strata = append(report.Strata, types.StratumSnapshot{
			StratumID:   stratum,
			Filled:      filled,
			FillRatioBP: ratio,
			DriftUnits:  0,
		})
	}

	report.FillTotalBP = totalFill
	report.PendingPeak = globalPendingPeak
	report.EnrolledTotal = totalEnrolled
	report.ScreenCarryTotal = totalCarry
	report.MaxDriftUnits = maxDrift
	report.ReportOK = maxDrift <= cfg.MaxDriftUnits &&
		globalPendingPeak <= cfg.MaxPendingPeak &&
		totalEnrolled >= cfg.MinEnrolledTotal
	if !report.ReportOK {
		report.Status = "drift"
	}

	digest, err := digestFor(report)
	if err != nil {
		return types.EnrollReport{}, err
	}
	report.ReportDigest = digest
	return report, nil
}

func digestFor(report types.EnrollReport) (string, error) {
	payload := report
	payload.ReportDigest = ""
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return "", err
	}
	raw := bytes.TrimSpace(buf.Bytes())
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:]), nil
}

func WriteReport(path string, report types.EnrollReport) error {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	enc.SetIndent("", "  ")
	if err := enc.Encode(report); err != nil {
		return err
	}
	return os.WriteFile(path, bytes.TrimSpace(buf.Bytes()), 0o644)
}
