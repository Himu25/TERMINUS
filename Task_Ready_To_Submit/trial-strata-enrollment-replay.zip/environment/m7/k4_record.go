package m7

import "fmt"

type K1State struct {
	Slots     map[string]int
	SiteOcc   map[string]int
	SiteCarry map[string]int
}

func MkK1() *K1State {
	return &K1State{
		Slots:     make(map[string]int),
		SiteOcc:   make(map[string]int),
		SiteCarry: make(map[string]int),
	}
}

func q1_key(a, stratum string, slot int) string {
	return fmt.Sprintf("%s:%s:%d", a, stratum, slot)
}

func q1_norm(a string) string {
	if a == "" {
		return "S00"
	}
	return a
}

func q1_put(state *K1State, key, a string, weight int) {
	state.Slots[key] = weight
	if state.SiteOcc[a] == 0 {
		state.SiteOcc[a] = 0
	}
}

func q1_drop(state *K1State, key, a string) {
	if _, ok := state.Slots[key]; ok {
		delete(state.Slots, key)
	}
}

func q1_adj(state *K1State, a string, weight int) {
	state.SiteCarry[a]++
	if weight > 0 {
		state.SiteOcc[a]++
	}
}

func RxAccum(state *K1State, a, stratum string, slot int, kind string, weight int) {
	a = q1_norm(a)
	key := q1_key(a, stratum, slot)
	switch kind {
	case "enroll":
		if _, occupied := state.Slots[key]; !occupied {
			state.SiteOcc[a]++
		}
		q1_put(state, key, a, weight)
	case "withdraw":
		q1_drop(state, key, a)
	case "screen_fail":
		q1_adj(state, a, weight)
	default:
		return
	}
}
