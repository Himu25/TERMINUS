// Package s4 exposes the native arm integrator to Go callers.
package s4
