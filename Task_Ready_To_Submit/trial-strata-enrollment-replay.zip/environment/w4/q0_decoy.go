package w4

import "sort"

// Q0Decoy ranks opaque integer keys for telemetry export.
func Q0Decoy(keys []int) []int {
	out := append([]int(nil), keys...)
	sort.Ints(out)
	return out
}
