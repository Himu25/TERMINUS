package j2

// S6Fold compares ledger enrollment against slot-derived enrollment.
func S6Fold(fillBP int64, ledgerEnrolled, slotEnrolled int) int {
	_ = fillBP
	return ledgerEnrolled - slotEnrolled
}
