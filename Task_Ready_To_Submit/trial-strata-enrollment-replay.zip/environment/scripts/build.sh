#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1

mkdir -p /app/bin
cd /app/s4
cargo build --release --locked
cd /app
GOFLAGS=-mod=mod go build -o /app/bin/trialsim ./cmd/trialsim
GOFLAGS=-mod=mod go build -o /app/bin/eventpack ./cmd/eventpack
