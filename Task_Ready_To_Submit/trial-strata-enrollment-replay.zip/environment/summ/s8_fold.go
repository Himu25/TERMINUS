package summ

import "tsr.lab/pkg/types"

// S8Fold totals fill basis points across site snapshots.
func S8Fold(sites []types.SiteSnapshot) int64 {
	var sum int64
	for _, site := range sites {
		sum += site.FillBP
	}
	return sum
}
