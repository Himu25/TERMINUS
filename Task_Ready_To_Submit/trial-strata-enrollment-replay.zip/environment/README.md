# Trial strata enrollment replay lab

Mixed Rust/Go replay stack under `/app`. Build with `/app/scripts/build.sh` and run the default bundle via `/app/tools/run_replay`.

Policy notes live under `/app/docs/`. Site registry under `/app/registry/`.
