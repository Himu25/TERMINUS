package p2

import (
	"sort"

	"tsr.lab/pkg/types"
)

func q2_rank(id string) int {
	if len(id) == 0 {
		return 99
	}
	last := id[len(id)-1]
	if last >= '0' && last <= '9' {
		return int(last - '0')
	}
	return 99
}

func q2_less(a, b types.EventRow) bool {
	if a.Seq != b.Seq {
		return a.Seq < b.Seq
	}
	ra, rb := q2_rank(a.ChannelID), q2_rank(b.ChannelID)
	if ra != rb {
		return ra > rb
	}
	if a.ChannelID != b.ChannelID {
		return a.ChannelID > b.ChannelID
	}
	return a.StratumID > b.StratumID
}

func UxPick(rows []types.EventRow) []types.EventRow {
	out := make([]types.EventRow, len(rows))
	copy(out, rows)
	sort.SliceStable(out, func(i, j int) bool {
		return q2_less(out[i], out[j])
	})
	return out
}
