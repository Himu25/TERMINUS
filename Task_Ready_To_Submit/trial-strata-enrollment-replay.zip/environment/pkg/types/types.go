// EnrollReport is written to /app/output/enroll_report.json by trialsim.
// Top-level keys: status, events_processed, report_ok, max_drift_units,
// fill_total_bp, pending_peak, screen_carry_total, enrolled_total,
// report_digest, sites, strata.
package types

type TrialCfg struct {
	MaxDriftUnits     int
	MaxPendingPeak    int
	MinEnrolledTotal  int
	ChannelPriorityAsc bool
	PendingScaleMilli map[int]int
}

type StrataLayout struct {
	StratumArmBP map[string]int `json:"stratum_arm_bp"`
}

type EventRow struct {
	EventID   string `json:"event_id"`
	Seq       int    `json:"seq"`
	ChannelID string `json:"channel_id"`
	SiteID    string `json:"site_id"`
	StratumID string `json:"stratum_id"`
	Slot      int    `json:"slot"`
	EventType string `json:"event_type"`
	Weight    int    `json:"weight"`
}

type SiteSnapshot struct {
	SiteID      string `json:"site_id"`
	FillBP      int64  `json:"fill_bp"`
	PendingPeak int    `json:"pending_peak"`
	Enrolled    int    `json:"enrolled"`
	DriftUnits  int    `json:"drift_units"`
}

type StratumSnapshot struct {
	StratumID   string `json:"stratum_id"`
	Filled      int    `json:"filled"`
	FillRatioBP int    `json:"fill_ratio_bp"`
	DriftUnits  int    `json:"drift_units"`
}

type EnrollReport struct {
	Status           string            `json:"status"`
	EventsProcessed  int               `json:"events_processed"`
	ReportOK         bool              `json:"report_ok"`
	MaxDriftUnits    int               `json:"max_drift_units"`
	FillTotalBP      int64             `json:"fill_total_bp"`
	PendingPeak      int               `json:"pending_peak"`
	ScreenCarryTotal int               `json:"screen_carry_total"`
	EnrolledTotal    int               `json:"enrolled_total"`
	ReportDigest     string            `json:"report_digest"`
	Sites            []SiteSnapshot    `json:"sites"`
	Strata           []StratumSnapshot `json:"strata"`
}
