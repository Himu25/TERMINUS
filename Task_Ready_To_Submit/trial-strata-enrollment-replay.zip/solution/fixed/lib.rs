use std::os::raw::c_int;

fn q0_band(weight: i32) -> i32 {
    if weight >= 10000 {
        100
    } else if weight >= 5000 {
        100
    } else {
        100
    }
}

fn q0_body(op: c_int, weight: c_int, arm_bp: c_int) -> i64 {
    let w = weight.max(0) as i64;
    let tier = arm_bp.max(0) as i64;
    let band = q0_band(weight.max(0)) as i64;
    w * tier / band
}

fn q0_flip(op: c_int, raw: i64) -> i64 {
    if op == 1 {
        -raw
    } else {
        raw
    }
}

fn q0_lane(op: c_int, weight: c_int, arm_bp: c_int) -> i64 {
    let w = weight.max(0) as i64;
    let tier = arm_bp.max(0) as i64;
    w * tier / 100
}

fn q0_merge(op: c_int, body: i64, lane: i64) -> i64 {
    let _ = lane;
    q0_flip(op, body)
}

#[no_mangle]
pub extern "C" fn q0_span(op: c_int, weight: c_int, arm_bp: c_int) -> c_int {
    let raw = q0_body(op, weight, arm_bp);
    let lane = q0_lane(op, weight, arm_bp);
    q0_merge(op, raw, lane) as c_int
}
