#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/trial.toml
require_file /app/data/events_manifest.jsonl
require_file /app/data/strata_layout.json
mkdir -p /app/bin /app/output

log "install corrected stratification engine"
install -m 0644 "${ROOT_DIR}/fixed/lib.rs" /app/s4/src/lib.rs

log "install corrected WAL ledger"
install -m 0644 "${ROOT_DIR}/fixed/k4_record.go" /app/m7/k4_record.go

log "install corrected channel ordering"
install -m 0644 "${ROOT_DIR}/fixed/t9_pick.go" /app/p2/t9_pick.go

log "rebuild replay harness"
bash /app/scripts/build.sh

log "refresh default event bundle"
/app/bin/eventpack /app/data/events_manifest.jsonl /app/data/events_default.jsonl

log "emit default enrollment report"
/app/tools/run_replay

log "post-run validation against trial.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg = {}
for line in Path("/app/config/trial.toml").read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = (part.strip() for part in line.split("=", 1))
    if k in ("max_drift_units", "max_pending_peak", "min_enrolled_total"):
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/enroll_report.json").read_text())
assert report["status"] == "ok", report
assert report["report_ok"]
assert report["max_drift_units"] <= cfg["max_drift_units"]
assert report["enrolled_total"] >= cfg["min_enrolled_total"]
assert report["pending_peak"] <= cfg["max_pending_peak"]
print("ok", report["fill_total_bp"], report["enrolled_total"])
PY

log "oracle complete"
