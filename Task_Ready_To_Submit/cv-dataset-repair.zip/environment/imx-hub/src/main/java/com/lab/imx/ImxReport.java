package com.lab.imx;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Map;

public final class ImxReport {
    public static final String KEY_VAL_ACCURACY = "val_accuracy";
    public static final String KEY_CORRUPT_REMOVED = "corrupt_removed";
    public static final String KEY_CLASS_BALANCE = "class_balance_score";
    public static final String KEY_BBOX_IOU = "bbox_iou_mean";
    public static final String KEY_AUG_FLIP = "aug_flip_ok";
    public static final String KEY_AUDIT_PASSED = "audit_passed";

    public record Summary(
            double valAccuracy,
            int corruptRemoved,
            double classBalanceScore,
            double bboxIouMean,
            int augFlipOk) {
    }

    private ImxReport() {
    }

    public static void write(Path out, Summary summary, boolean auditPassed) throws IOException {
        Files.createDirectories(out.getParent());
        String json = String.format(
                Locale.US,
                "{\n"
                        + "  \"summary\": {\n"
                        + "    \"val_accuracy\": %.6f,\n"
                        + "    \"corrupt_removed\": %d,\n"
                        + "    \"class_balance_score\": %.6f,\n"
                        + "    \"bbox_iou_mean\": %.6f,\n"
                        + "    \"aug_flip_ok\": %d\n"
                        + "  },\n"
                        + "  \"audit_passed\": %s\n"
                        + "}\n",
                summary.valAccuracy(),
                summary.corruptRemoved(),
                summary.classBalanceScore(),
                summary.bboxIouMean(),
                summary.augFlipOk(),
                auditPassed ? "true" : "false");
        Files.writeString(out, json);
    }

    public static boolean gatesOk(Summary summary, ImxConfig cfg) {
        return summary.valAccuracy() >= cfg.gateAcc()
                && summary.classBalanceScore() >= cfg.gateBal()
                && summary.bboxIouMean() >= cfg.gateIou()
                && summary.augFlipOk() == 1
                && summary.corruptRemoved() >= 2;
    }
}
