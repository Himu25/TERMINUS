package com.lab.imx;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ImxSample {
    public record Row(ImxLabel label, double[] normBox, double[] features, int mappedClass) {
    }

    private ImxSample() {
    }

    public static List<Row> capRows(List<Row> rows) {
        Map<Integer, List<Row>> byClass = new HashMap<>();
        for (Row row : rows) {
            byClass.computeIfAbsent(row.mappedClass(), k -> new ArrayList<>()).add(row);
        }
        int cap = byClass.values().stream().mapToInt(List::size).max().orElse(0);
        if (cap == 0) {
            return List.of();
        }
        List<Row> out = new ArrayList<>();
        for (List<Row> bucket : byClass.values()) {
            List<Row> copy = new ArrayList<>(bucket);
            Collections.sort(copy, (a, b) -> a.label().image.compareTo(b.label().image));
            for (int i = 0; i < cap; i++) {
                out.add(copy.get(i));
            }
        }
        Collections.sort(out, (a, b) -> a.label().image.compareTo(b.label().image));
        return out;
    }

    public static double minorityFrac(List<Row> rows) {
        if (rows.isEmpty()) {
            return 0.0;
        }
        Map<Integer, Integer> counts = new HashMap<>();
        for (Row row : rows) {
            counts.merge(row.mappedClass(), 1, Integer::sum);
        }
        int classes = counts.size();
        if (classes <= 1) {
            return 0.0;
        }
        double minFrac = counts.values().stream().mapToInt(v -> v).min().orElse(0)
                / (double) rows.size();
        double target = 1.0 / classes;
        return Math.min(1.0, minFrac / target);
    }
}
