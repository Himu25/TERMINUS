package com.lab.imx;

import com.lab.aug.ImxWarp;
import com.lab.geom.ImxGeom;
import com.lab.raster.ImxFrame;
import com.lab.scan.ImxProbe;
import com.lab.tags.ImxTags;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ImxGate {
  public static void main(String[] args) throws Exception {
    Path root = Path.of("/app");
    ImxConfig cfg =
        ImxConfig.load(root.resolve("config/training.properties"), root.resolve("config/frame_canon.json"));
    Path manifest = root.resolve("data/split_manifest.tsv");
    Path rasterDir = root.resolve("data/png");
    Path labelDir = root.resolve("data/labels");
    Map<Integer, Integer> remap =
        ImxRemap.load(root.resolve("config/class_remap.json"));

    List<String[]> manifestRows = new ArrayList<>();
    for (String line : Files.readAllLines(manifest)) {
      if (line.startsWith("image")) {
        continue;
      }
      String[] cols = line.split("\t");
      manifestRows.add(cols);
    }

    int corruptRemoved = 0;
    List<ImxSample.Row> train = new ArrayList<>();
    List<ImxSample.Row> val = new ArrayList<>();
    double iouSum = 0.0;
    int iouCount = 0;

    for (String[] cols : manifestRows) {
      String image = cols[0];
      String split = cols[1];
      Path rasterPath = rasterDir.resolve(image);
      if (!ImxProbe.reconcile_b(rasterPath, cfg.minProbeBytes())) {
        corruptRemoved++;
        continue;
      }
      Path labelPath = labelDir.resolve(image.replace(".png", ".json"));
      if (!Files.exists(labelPath)) {
        corruptRemoved++;
        continue;
      }
      ImxLabel label = ImxLabel.parse(labelPath);
      BufferedImage raw = ImxRaster.load(rasterPath);
      BufferedImage framed =
          ImxFrame.step_d(raw, cfg.canonWidth(), cfg.canonHeight());
      double scaleX = cfg.canonWidth() / (double) raw.getWidth();
      double scaleY = cfg.canonHeight() / (double) raw.getHeight();
      double[] scaledBox =
          new double[] {
            label.box[0] * scaleX,
            label.box[1] * scaleY,
            label.box[2] * scaleX,
            label.box[3] * scaleY
          };
      double[] normBox = ImxGeom.op_a(scaledBox, cfg.canonWidth(), cfg.canonHeight());
      double[] truth =
          ImxGeom.op_a(
              new double[] {label.box[0], label.box[1], label.box[2], label.box[3]},
              raw.getWidth(),
              raw.getHeight());
      iouSum += ImxGeom.iou(normBox, truth);
      iouCount++;
      int rawClass = Integer.parseInt(cols[2]);
      int mapped = ImxTags.phase_c(rawClass, remap);
      double[] features = ImxRaster.poolRgb(framed, normBox);
      ImxSample.Row row = new ImxSample.Row(label, normBox, features, mapped);
      if ("val".equals(split)) {
        val.add(row);
      } else {
        train.add(row);
      }
    }

    List<ImxSample.Row> balancedTrain = ImxSample.capRows(train);
    double balanceScore = ImxSample.minorityFrac(train);
    double valAccuracy = ImxFold.evaluate(train, val, cfg.knnK());
    double bboxIouMean = iouCount == 0 ? 0.0 : iouSum / iouCount;
    int augFlipOk = rowMirrorOk(train, cfg) ? 1 : 0;

    ImxReport.Summary summary =
        new ImxReport.Summary(valAccuracy, corruptRemoved, balanceScore, bboxIouMean, augFlipOk);
    boolean auditPassed = ImxReport.gatesOk(summary, cfg);
    ImxReport.write(root.resolve("output/repair_report.json"), summary, auditPassed);
  }

  private static boolean rowMirrorOk(List<ImxSample.Row> rows, ImxConfig cfg) throws IOException {
    int samples = Math.min(4, rows.size());
    for (int i = 0; i < samples; i++) {
      ImxSample.Row row = rows.get(i);
      double[] flipped = ImxWarp.bind_e(row.normBox(), cfg.canonWidth());
      double expect = 1.0 - row.normBox()[0] - row.normBox()[2];
      if (Math.abs(flipped[0] - expect) > 1e-3) {
        return false;
      }
    }
    return true;
  }
}
