package com.lab.imx;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ImxConfig {
    private final Map<String, String> props = new HashMap<>();
    private final int canonW;
    private final int canonH;

    private ImxConfig(Map<String, String> props, int canonW, int canonH) {
        this.props.putAll(props);
        this.canonW = canonW;
        this.canonH = canonH;
    }

    public static ImxConfig load(Path propsPath, Path framePath) throws IOException {
        Map<String, String> map = new HashMap<>();
        for (String line : Files.readAllLines(propsPath)) {
            String st = line.trim();
            if (st.isEmpty() || st.startsWith("#") || !st.contains("=")) {
                continue;
            }
            int eq = st.indexOf('=');
            map.put(st.substring(0, eq).trim(), st.substring(eq + 1).trim());
        }
        String body = Files.readString(framePath);
        Matcher w = Pattern.compile("\"width\"\\s*:\\s*(\\d+)").matcher(body);
        Matcher h = Pattern.compile("\"height\"\\s*:\\s*(\\d+)").matcher(body);
        int width = w.find() ? Integer.parseInt(w.group(1)) : 64;
        int height = h.find() ? Integer.parseInt(h.group(1)) : 64;
        return new ImxConfig(map, width, height);
    }

    public double gateAcc() {
        return Double.parseDouble(props.getOrDefault("summary.accuracy_floor", "0.72"));
    }

    public double gateBal() {
        return Double.parseDouble(props.getOrDefault("summary.balance_floor", "0.55"));
    }

    public double gateIou() {
        return Double.parseDouble(props.getOrDefault("summary.bbox_iou_floor", "0.80"));
    }

    public long minProbeBytes() {
        return Long.parseLong(props.getOrDefault("probe.min_bytes", "32"));
    }

    public int knnK() {
        return Integer.parseInt(props.getOrDefault("fold.k", "1"));
    }

    public int canonWidth() {
        return canonW;
    }

    public int canonHeight() {
        return canonH;
    }
}
