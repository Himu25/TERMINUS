package com.lab.imx;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class ImxFold {
    private ImxFold() {
    }

    public static double evaluate(List<ImxSample.Row> train, List<ImxSample.Row> val, int k) {
        if (val.isEmpty()) {
            return 0.0;
        }
        int correct = 0;
        for (ImxSample.Row probe : val) {
            List<Neighbor> neighbors = new ArrayList<>();
            for (ImxSample.Row cand : train) {
                double dist = l2(probe.features(), cand.features());
                neighbors.add(new Neighbor(dist, cand.mappedClass()));
            }
            neighbors.sort(Comparator.comparingDouble(Neighbor::dist));
            int limit = Math.min(k, neighbors.size());
            int[] votes = new int[8];
            for (int i = 0; i < limit; i++) {
                votes[neighbors.get(i).cls()]++;
            }
            int pred = 0;
            int best = -1;
            for (int i = 0; i < votes.length; i++) {
                if (votes[i] > best) {
                    best = votes[i];
                    pred = i;
                }
            }
            if (pred == probe.mappedClass()) {
                correct++;
            }
        }
        return correct / (double) val.size();
    }

    private static double l2(double[] a, double[] b) {
        double sum = 0.0;
        for (int i = 0; i < a.length; i++) {
            double d = a[i] - b[i];
            sum += d * d;
        }
        return sum;
    }

    private record Neighbor(double dist, int cls) {
    }
}
