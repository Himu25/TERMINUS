package com.lab.imx;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ImxLabel {
    public final String image;
    public final int classId;
    public final double[] box;
    public final String split;

    public ImxLabel(String image, int classId, double[] box, String split) {
        this.image = image;
        this.classId = classId;
        this.box = box;
        this.split = split;
    }

    public static ImxLabel parse(Path path) throws IOException {
        String body = Files.readString(path);
        Matcher img = Pattern.compile("\"image\"\\s*:\\s*\"([^\"]+)\"").matcher(body);
        Matcher cls = Pattern.compile("\"class_id\"\\s*:\\s*(\\d+)").matcher(body);
        Matcher split = Pattern.compile("\"split\"\\s*:\\s*\"([^\"]+)\"").matcher(body);
        Matcher box = Pattern.compile("\"box\"\\s*:\\s*\\[([^\\]]+)\\]").matcher(body);
        if (!img.find() || !cls.find() || !box.find() || !split.find()) {
            throw new IOException("malformed label " + path);
        }
        String[] parts = box.group(1).split(",");
        double[] coords = new double[4];
        for (int i = 0; i < 4; i++) {
            coords[i] = Double.parseDouble(parts[i].trim());
        }
        return new ImxLabel(img.group(1), Integer.parseInt(cls.group(1)), coords, split.group(1));
    }
}
