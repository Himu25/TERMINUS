package com.lab.imx;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ImxStats {
    private ImxStats() {
    }

    public static Map<Integer, Integer> histogram(List<ImxSample.Row> rows) {
        Map<Integer, Integer> counts = new HashMap<>();
        for (ImxSample.Row row : rows) {
            counts.merge(row.mappedClass(), 1, Integer::sum);
        }
        return counts;
    }
}
