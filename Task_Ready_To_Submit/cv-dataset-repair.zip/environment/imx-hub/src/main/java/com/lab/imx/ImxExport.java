package com.lab.imx;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

public final class ImxExport {
    private ImxExport() {
    }

    public static void writeSidecar(Path out, String image, double[] normBox) throws IOException {
        String line =
                String.format(
                        Locale.US,
                        "{\"file\":\"%s\",\"bbox\":[%.4f,%.4f,%.4f,%.4f]}\n",
                        image,
                        normBox[0],
                        normBox[1],
                        normBox[2],
                        normBox[3]);
        Files.writeString(out, line);
    }
}
