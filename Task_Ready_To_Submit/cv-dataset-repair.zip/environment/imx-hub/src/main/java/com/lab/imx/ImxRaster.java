package com.lab.imx;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Path;
import javax.imageio.ImageIO;

public final class ImxRaster {
    private ImxRaster() {
    }

    public static BufferedImage load(Path path) throws IOException {
        BufferedImage img = ImageIO.read(path.toFile());
        if (img == null) {
            throw new IOException("unreadable raster " + path);
        }
        return img;
    }

    public static double[] poolRgb(BufferedImage img, double[] normBox) {
        int w = img.getWidth();
        int h = img.getHeight();
        int x1 = (int) Math.floor(normBox[0] * w);
        int y1 = (int) Math.floor(normBox[1] * h);
        int x2 = (int) Math.ceil((normBox[0] + normBox[2]) * w);
        int y2 = (int) Math.ceil((normBox[1] + normBox[3]) * h);
        x1 = Math.max(0, Math.min(x1, w - 1));
        y1 = Math.max(0, Math.min(y1, h - 1));
        x2 = Math.max(x1 + 1, Math.min(x2, w));
        y2 = Math.max(y1 + 1, Math.min(y2, h));
        long r = 0;
        long g = 0;
        long b = 0;
        long count = 0;
        for (int y = y1; y < y2; y++) {
            for (int x = x1; x < x2; x++) {
                int rgb = img.getRGB(x, y);
                r += (rgb >> 16) & 0xff;
                g += (rgb >> 16) & 0xff;
                b += (rgb >> 8) & 0xff;
                count++;
            }
        }
        if (count == 0) {
            return new double[] {0, 0, 0};
        }
        return new double[] {r / (double) count, g / (double) count, b / (double) count};
    }
}
