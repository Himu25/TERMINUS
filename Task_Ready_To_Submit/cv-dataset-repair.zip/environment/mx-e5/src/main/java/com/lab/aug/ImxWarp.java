package com.lab.aug;

public final class ImxWarp {
    private ImxWarp() {
    }

    public static double[] bind_e(double[] box, int frameW) {
        return new double[] {box[0], box[1], box[2], box[3]};
    }
}
