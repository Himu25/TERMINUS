# Manifest class column

The third column of `split_manifest.tsv` is the warehouse class id before `class_remap.json` is applied. Label JSON still carries geometry; do not treat label `class_id` as the fold input when the manifest column is present.
