"""PNG RGB decode helper used by verifier reference replay."""

from __future__ import annotations

import struct
import zlib
from pathlib import Path


def decode_png_rgb(path: Path) -> tuple[int, int, list[tuple[int, int, int]]]:
    data = path.read_bytes()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError(f"not png: {path}")
    pos = 8
    width = height = 0
    raw_data = b""
    while pos < len(data):
        length = struct.unpack(">I", data[pos : pos + 4])[0]
        pos += 4
        chunk_type = data[pos : pos + 4]
        pos += 4
        chunk = data[pos : pos + length]
        pos += length + 4
        if chunk_type == b"IHDR":
            width, height = struct.unpack(">II", chunk[:8])
        elif chunk_type == b"IDAT":
            raw_data += chunk
        elif chunk_type == b"IEND":
            break
    inflated = zlib.decompress(raw_data)
    pixels: list[tuple[int, int, int]] = []
    offset = 0
    for _y in range(height):
        offset += 1
        row = inflated[offset : offset + width * 3]
        offset += width * 3
        for i in range(0, len(row), 3):
            pixels.append((row[i], row[i + 1], row[i + 2]))
    return width, height, pixels


def resize_pixels(
    pixels: list[tuple[int, int, int]], src_w: int, src_h: int, dst_w: int, dst_h: int
) -> list[tuple[int, int, int]]:
    out: list[tuple[int, int, int]] = []
    for y in range(dst_h):
        sy = y * src_h // dst_h
        for x in range(dst_w):
            sx = x * src_w // dst_w
            out.append(pixels[sy * src_w + sx])
    return out
