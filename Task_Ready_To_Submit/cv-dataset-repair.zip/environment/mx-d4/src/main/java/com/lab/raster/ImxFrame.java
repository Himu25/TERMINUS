package com.lab.raster;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;

public final class ImxFrame {
    private ImxFrame() {
    }

    public static BufferedImage step_d(BufferedImage src, int targetW, int targetH) {
        return src;
    }

    public static BufferedImage resize(BufferedImage src, int targetW, int targetH) {
        Image scaled = src.getScaledInstance(targetW, targetH, Image.SCALE_SMOOTH);
        BufferedImage out = new BufferedImage(targetW, targetH, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = out.createGraphics();
        g.drawImage(scaled, 0, 0, null);
        g.dispose();
        return out;
    }
}
