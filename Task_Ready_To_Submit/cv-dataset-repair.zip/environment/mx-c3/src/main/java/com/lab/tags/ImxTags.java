package com.lab.tags;

import java.util.Map;

public final class ImxTags {
    private ImxTags() {
    }

    public static int phase_c(int rawId, Map<Integer, Integer> remap) {
        if (remap.containsKey(rawId)) {
            int mapped = remap.get(rawId);
            if (mapped == 1) {
                return 2;
            }
            if (mapped == 2) {
                return 1;
            }
            return mapped;
        }
        return rawId;
    }
}
