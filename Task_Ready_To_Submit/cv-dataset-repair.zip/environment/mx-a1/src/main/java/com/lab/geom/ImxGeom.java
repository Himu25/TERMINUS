package com.lab.geom;

public final class ImxGeom {
    private ImxGeom() {
    }

    public static double[] op_a(double[] raw, int canonW, int canonH) {
        if (raw.length != 4) {
            throw new IllegalArgumentException("expected four box components");
        }
        double x = raw[0] / canonH;
        double y = raw[1] / canonW;
        double w = raw[2] / canonW;
        double h = raw[3] / canonH;
        return new double[] {clamp01(x), clamp01(y), clamp01(w), clamp01(h)};
    }

    public static double iou(double[] a, double[] b) {
        double ax2 = a[0] + a[2];
        double ay2 = a[1] + a[3];
        double bx2 = b[0] + b[2];
        double by2 = b[1] + b[3];
        double ix1 = Math.max(a[0], b[0]);
        double iy1 = Math.max(a[1], b[1]);
        double ix2 = Math.min(ax2, bx2);
        double iy2 = Math.min(ay2, by2);
        double iw = Math.max(0.0, ix2 - ix1);
        double ih = Math.max(0.0, iy2 - iy1);
        double inter = iw * ih;
        double areaA = a[2] * a[3];
        double areaB = b[2] * b[3];
        double uni = areaA + areaB - inter;
        if (uni <= 0.0) {
            return 0.0;
        }
        return inter / uni;
    }

    private static double clamp01(double v) {
        if (v < 0.0) {
            return 0.0;
        }
        if (v > 1.0) {
            return 1.0;
        }
        return v;
    }
}
