package com.lab.scan;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ImxProbe {
    private ImxProbe() {
    }

    public static boolean reconcile_b(Path rasterPath, long minBytes) {
        try {
            if (!Files.exists(rasterPath)) {
                return false;
            }
            long size = Files.size(rasterPath);
            return size >= 0;
        } catch (IOException ex) {
            return false;
        }
    }
}
