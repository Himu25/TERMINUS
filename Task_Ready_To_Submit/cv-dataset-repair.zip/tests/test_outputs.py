"""Validate repair_report.json against workshop gates and independent replay."""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

sys.path.insert(0, "/app/lib")
from pngutil import decode_png_rgb, resize_pixels  # noqa: E402

APP = Path("/app")
OUT = APP / "output" / "repair_report.json"
MANIFEST = APP / "data" / "split_manifest.tsv"
LABEL_DIR = APP / "data" / "labels"
RASTER_DIR = APP / "data" / "png"
PROPS = APP / "config" / "training.properties"
FRAME_CANON = APP / "config" / "frame_canon.json"
AUDIT_TOOL = APP / "tools" / "dataset_audit"
JAR_BIN = APP / "bin" / "imx-hub.jar"
FIXTURES = Path(__file__).resolve().parent / "fixtures"
METRIC_EPS = 1e-5
FLIP_TOL = 1e-3
REMAP_PATH = APP / "config" / "class_remap.json"
REPORT_SUMMARY_KEYS = frozenset(
    {
        "val_accuracy",
        "corrupt_removed",
        "class_balance_score",
        "bbox_iou_mean",
        "aug_flip_ok",
    }
)


def _load_remap() -> dict[int, int]:
    doc = json.loads(REMAP_PATH.read_text(encoding="utf-8"))
    return {int(k): int(v) for k, v in doc.items()}


def _phase_c(raw_id: int, remap: dict[int, int]) -> int:
    return remap.get(raw_id, raw_id)


def _props() -> dict[str, float]:
    cfg: dict[str, float] = {}
    for line in PROPS.read_text(encoding="utf-8").splitlines():
        st = line.strip()
        if not st or st.startswith("#") or "=" not in st:
            continue
        key, val = st.split("=", 1)
        cfg[key.strip()] = float(val.strip())
    return cfg


def _canon_size() -> tuple[int, int]:
    body = FRAME_CANON.read_text(encoding="utf-8")
    w = int(re.search(r'"width"\s*:\s*(\d+)', body).group(1))
    h = int(re.search(r'"height"\s*:\s*(\d+)', body).group(1))
    return w, h


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)
    if hasattr(os, "sync"):
        os.sync()


def _probe_ok(path: Path, min_bytes: float) -> bool:
    if not path.exists():
        return False
    data = path.read_bytes()
    if len(data) < min_bytes:
        return False
    if len(data) < 8:
        return False
    return data[0] == 0x89 and data[1] == 0x50 and data[2] == 0x4E and data[3] == 0x47


def _norm_box(raw: list[float], canon_w: int, canon_h: int) -> list[float]:
    return [raw[0] / canon_w, raw[1] / canon_h, raw[2] / canon_w, raw[3] / canon_h]


def _truth_box(raw: list[float], src_w: int, src_h: int) -> list[float]:
    return [raw[0] / src_w, raw[1] / src_h, raw[2] / src_w, raw[3] / src_h]


def _iou(a: list[float], b: list[float]) -> float:
    ax2, ay2 = a[0] + a[2], a[1] + a[3]
    bx2, by2 = b[0] + b[2], b[1] + b[3]
    ix1, iy1 = max(a[0], b[0]), max(a[1], b[1])
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    iw, ih = max(0.0, ix2 - ix1), max(0.0, iy2 - iy1)
    inter = iw * ih
    uni = a[2] * a[3] + b[2] * b[3] - inter
    return 0.0 if uni <= 0 else inter / uni


def _mean_rgb(
    pixels: list[tuple[int, int, int]], w: int, h: int, box: list[float]
) -> list[float]:
    x1 = max(0, min(w - 1, int(box[0] * w)))
    y1 = max(0, min(h - 1, int(box[1] * h)))
    x2 = max(x1 + 1, min(w, int((box[0] + box[2]) * w + 0.999)))
    y2 = max(y1 + 1, min(h, int((box[1] + box[3]) * h + 0.999)))
    rs = gs = bs = cnt = 0
    for y in range(y1, y2):
        for x in range(x1, x2):
            r, g, b = pixels[y * w + x]
            rs += r
            gs += g
            bs += b
            cnt += 1
    if cnt == 0:
        return [0.0, 0.0, 0.0]
    return [rs / cnt, gs / cnt, bs / cnt]


def _balance_score(rows: list[dict]) -> float:
    if not rows:
        return 0.0
    counts: dict[int, int] = {}
    for row in rows:
        counts[row["cls"]] = counts.get(row["cls"], 0) + 1
    if len(counts) <= 1:
        return 0.0
    min_frac = min(counts.values()) / len(rows)
    return min(1.0, min_frac / (1.0 / len(counts)))


def _knn_accuracy(train: list[dict], val: list[dict], k: int) -> float:
    if not val:
        return 0.0
    correct = 0
    for probe in val:
        neighbors = sorted(
            ((sum((probe["feat"][i] - t["feat"][i]) ** 2 for i in range(3)), t["cls"]) for t in train),
            key=lambda item: item[0],
        )[:k]
        votes: dict[int, int] = {}
        for _, cls in neighbors:
            votes[cls] = votes.get(cls, 0) + 1
        pred = max(votes, key=votes.get)
        if pred == probe["cls"]:
            correct += 1
    return correct / len(val)


def _assert_audit_tool_integrity() -> None:
    assert AUDIT_TOOL.is_file()
    text = AUDIT_TOOL.read_text(encoding="utf-8")
    assert "exec java -jar /app/bin/imx-hub.jar" in text


def _build_gate_jar_from_sources() -> Path:
    """Compile the shaded hub from module sources without replacing the published jar."""
    subprocess.run(
        ["mvn", "-q", "-f", "/app/pom.xml", "-DskipTests", "package"],
        check=True,
        cwd="/app",
        timeout=300,
    )
    built = next((APP / "imx-hub" / "target").glob("v7hub-*.jar"), None)
    assert built is not None and built.stat().st_size > 0
    return built


def _expected_mirror_x_from_raw(image: str) -> float:
    """Horizontal mirror anchor from label JSON and source raster dimensions only."""
    label_path = LABEL_DIR / image.replace(".png", ".json")
    doc = json.loads(label_path.read_text(encoding="utf-8"))
    src_w, src_h, _ = decode_png_rgb(RASTER_DIR / image)
    canon_w, canon_h = _canon_size()
    scale_x = canon_w / src_w
    scale_y = canon_h / src_h
    scaled = [
        doc["box"][0] * scale_x,
        doc["box"][1] * scale_y,
        doc["box"][2] * scale_x,
        doc["box"][3] * scale_y,
    ]
    norm = _norm_box(scaled, canon_w, canon_h)
    return 1.0 - norm[0] - norm[2]


def _mirror_x_from_norm(norm: list[float]) -> float:
    return 1.0 - norm[0] - norm[2]


def _flip_ok_for_rows(rows: list[dict]) -> int:
    """Expected mirror flag: every train row must mirror consistently."""
    if not rows:
        return 0
    for row in rows:
        expect_x = _expected_mirror_x_from_raw(row["image"])
        actual_x = _mirror_x_from_norm(row["norm"])
        if abs(actual_x - expect_x) > FLIP_TOL:
            return 0
    return 1


def _assert_flip_ok(report: dict) -> None:
    want = _independent_summary()["summary"]["aug_flip_ok"]
    assert report["summary"]["aug_flip_ok"] == want
    assert want


def _assert_report_schema(report: dict) -> None:
    assert set(report.keys()) == {"summary", "audit_passed"}
    summary = report["summary"]
    assert set(summary.keys()) == REPORT_SUMMARY_KEYS
    assert isinstance(report["audit_passed"], bool)
    assert isinstance(summary["corrupt_removed"], int)
    assert isinstance(summary["aug_flip_ok"], int)
    assert summary["aug_flip_ok"] in {0, 1}


def _assert_audit_passed_consistent(report: dict) -> None:
    props = _props()
    summary = report["summary"]
    gates = (
        summary["val_accuracy"] >= props["summary.accuracy_floor"]
        and summary["class_balance_score"] >= props["summary.balance_floor"]
        and summary["bbox_iou_mean"] >= props["summary.bbox_iou_floor"]
        and bool(summary["aug_flip_ok"])
        and summary["corrupt_removed"] >= 2
    )
    assert report["audit_passed"] is gates


def _collect_pipeline_rows() -> tuple[list[dict], list[dict], list[dict], int, float, int]:
    canon_w, canon_h = _canon_size()
    min_bytes = _props()["probe.min_bytes"]
    remap = _load_remap()
    train: list[dict] = []
    val: list[dict] = []
    corrupt_removed = 0
    iou_sum = 0.0
    iou_count = 0

    for line in MANIFEST.read_text(encoding="utf-8").splitlines():
        if line.startswith("image"):
            continue
        image, split, raw_cls = line.split("\t")
        raster_path = RASTER_DIR / image
        if not _probe_ok(raster_path, min_bytes):
            corrupt_removed += 1
            continue
        label_path = LABEL_DIR / image.replace(".png", ".json")
        if not label_path.exists():
            corrupt_removed += 1
            continue
        doc = json.loads(label_path.read_text(encoding="utf-8"))
        src_w, src_h, pixels = decode_png_rgb(raster_path)
        framed = resize_pixels(pixels, src_w, src_h, canon_w, canon_h)
        scale_x = canon_w / src_w
        scale_y = canon_h / src_h
        scaled = [
            doc["box"][0] * scale_x,
            doc["box"][1] * scale_y,
            doc["box"][2] * scale_x,
            doc["box"][3] * scale_y,
        ]
        norm = _norm_box(scaled, canon_w, canon_h)
        truth = _truth_box(doc["box"], src_w, src_h)
        iou_sum += _iou(norm, truth)
        iou_count += 1
        mapped = _phase_c(int(raw_cls), remap)
        feat = _mean_rgb(framed, canon_w, canon_h, norm)
        row = {"cls": mapped, "feat": feat, "norm": norm, "image": image}
        if split == "val":
            val.append(row)
        else:
            train.append(row)

    by_cls: dict[int, list[dict]] = {}
    for row in train:
        by_cls.setdefault(row["cls"], []).append(row)
    cap = min(len(v) for v in by_cls.values()) if by_cls else 0
    balanced: list[dict] = []
    for bucket in by_cls.values():
        balanced.extend(sorted(bucket, key=lambda r: r["image"])[:cap])

    return train, val, balanced, corrupt_removed, iou_sum, iou_count


def _independent_summary() -> dict:
    props = _props()
    knn_k = int(props.get("fold.knn_k", 3))
    train, val, balanced, corrupt_removed, iou_sum, iou_count = _collect_pipeline_rows()
    summary = {
        "val_accuracy": round(_knn_accuracy(balanced, val, knn_k), 6),
        "corrupt_removed": corrupt_removed,
        "class_balance_score": round(_balance_score(balanced), 6),
        "bbox_iou_mean": round(iou_sum / iou_count if iou_count else 0.0, 6),
        "aug_flip_ok": _flip_ok_for_rows(train),
    }
    audit_passed = (
        summary["val_accuracy"] >= props["summary.accuracy_floor"]
        and summary["class_balance_score"] >= props["summary.balance_floor"]
        and summary["bbox_iou_mean"] >= props["summary.bbox_iou_floor"]
        and bool(summary["aug_flip_ok"])
        and summary["corrupt_removed"] >= 2
    )
    return {"summary": summary, "audit_passed": audit_passed}


def _assert_report_fields_match_independent_pipeline(
    report: dict,
    fields: frozenset[str],
    *,
    check_audit_passed: bool = False,
) -> None:
    expected = _independent_summary()
    got = report["summary"]
    want = expected["summary"]
    if "corrupt_removed" in fields:
        assert got["corrupt_removed"] == want["corrupt_removed"]
    if "aug_flip_ok" in fields:
        assert got["aug_flip_ok"] == want["aug_flip_ok"]
    if "val_accuracy" in fields:
        assert abs(got["val_accuracy"] - want["val_accuracy"]) <= METRIC_EPS
    if "class_balance_score" in fields:
        assert abs(got["class_balance_score"] - want["class_balance_score"]) <= METRIC_EPS
    if "bbox_iou_mean" in fields:
        assert abs(got["bbox_iou_mean"] - want["bbox_iou_mean"]) <= METRIC_EPS
    if check_audit_passed:
        assert report["audit_passed"] is expected["audit_passed"]


def _run_audit(
    *,
    match_fields: frozenset[str] | None = None,
    check_audit_passed: bool = False,
    require_audit_ok: bool = False,
) -> dict:
    _assert_audit_tool_integrity()
    cmd = ["/app/tools/dataset_audit"]
    subprocess.run(cmd, check=True, cwd="/app", timeout=240)
    report = json.loads(OUT.read_text(encoding="utf-8"))
    if require_audit_ok:
        _assert_audit_ok(report)
    fields = match_fields if match_fields is not None else frozenset(
        {
            "val_accuracy",
            "corrupt_removed",
            "class_balance_score",
            "bbox_iou_mean",
            "aug_flip_ok",
        }
    )
    _assert_report_fields_match_independent_pipeline(
        report,
        fields,
        check_audit_passed=check_audit_passed,
    )
    return report


@contextmanager
def _apply_fixture(fixture_name: str) -> Iterator[None]:
    doc = json.loads((FIXTURES / f"{fixture_name}.json").read_text(encoding="utf-8"))
    label_backups: dict[Path, str] = {}
    manifest_backup = MANIFEST.read_text(encoding="utf-8")
    remap_backup = REMAP_PATH.read_text(encoding="utf-8")
    try:
        if "manifest" in doc:
            _atomic_write_text(MANIFEST, doc["manifest"])
        if "remap" in doc:
            _atomic_write_text(REMAP_PATH, json.dumps(doc["remap"], indent=2) + "\n")
        for name, payload in doc.get("labels", {}).items():
            path = LABEL_DIR / name
            label_backups[path] = path.read_text(encoding="utf-8")
            _atomic_write_text(path, json.dumps(payload, indent=2) + "\n")
        yield
    finally:
        _atomic_write_text(MANIFEST, manifest_backup)
        _atomic_write_text(REMAP_PATH, remap_backup)
        for path, text in label_backups.items():
            _atomic_write_text(path, text)


def _assert_audit_ok(report: dict) -> None:
    props = _props()
    summary = report["summary"]
    assert report["audit_passed"] is True
    assert summary["val_accuracy"] >= props["summary.accuracy_floor"]
    assert summary["bbox_iou_mean"] >= props["summary.bbox_iou_floor"]
    assert summary["class_balance_score"] >= props["summary.balance_floor"]
    _assert_flip_ok(report)
    assert summary["corrupt_removed"] >= 2


class TestReportIntegrity:
    """Schema, replay parity, and determinism for the audit summary."""

    def test_repair_report_schema(self) -> None:
        """Report must expose only the ImxReport summary contract."""
        report = _run_audit()
        _assert_report_schema(report)

    def test_all_summary_fields_match_independent_recompute(self) -> None:
        """Every summary metric must agree with verifier replay within 1e-5."""
        report = _run_audit(
            match_fields=REPORT_SUMMARY_KEYS,
            check_audit_passed=True,
        )
        _assert_report_schema(report)

    def test_audit_passed_consistent_with_summary_gates(self) -> None:
        """audit_passed must reflect workshop floors, not a spoofed flag."""
        report = _run_audit(check_audit_passed=True)
        _assert_audit_passed_consistent(report)

    def test_deterministic_double_audit_run(self) -> None:
        """Repeated audits must emit identical summary numbers."""
        first = _run_audit(match_fields=REPORT_SUMMARY_KEYS)
        second = _run_audit(match_fields=REPORT_SUMMARY_KEYS)
        assert first["summary"] == second["summary"]
        assert first["audit_passed"] == second["audit_passed"]

    def test_flip_geometry_on_all_train_rows(self) -> None:
        """Mirror geometry must hold for every train row, not a subsample."""
        train, _, _, _, _, _ = _collect_pipeline_rows()
        assert _flip_ok_for_rows(train)
        report = _run_audit(match_fields=frozenset({"aug_flip_ok"}))
        _assert_flip_ok(report)

    def test_corrupt_removed_exact_independent_count(self) -> None:
        """corrupt_removed must equal the independent purge tally."""
        report = _run_audit(match_fields=frozenset({"corrupt_removed"}))
        expected = _independent_summary()["summary"]["corrupt_removed"]
        assert report["summary"]["corrupt_removed"] == expected


class TestGateArtifact:
    """Published jar integrity and probe behavior."""

    def test_shade_jar_matches_published_copy(self) -> None:
        """Fresh Maven shade output must match the published gate jar bytes."""
        built = _build_gate_jar_from_sources()
        assert built.read_bytes() == JAR_BIN.read_bytes()

    def test_probe_gate_matches_python_replay(self) -> None:
        """Probe gate must agree with verifier replay on workshop rasters."""
        min_bytes = _props()["probe.min_bytes"]
        assert _probe_ok(RASTER_DIR / "frame_00.png", min_bytes)
        assert not _probe_ok(RASTER_DIR / "bad_zero.png", min_bytes)


class TestBundledRepair:
    """Default lab split clears every workshop gate."""

    def test_bundled_audit_passes(self) -> None:
        """Bundled lab split must satisfy workshop gates."""
        report = _run_audit(require_audit_ok=True, check_audit_passed=True)
        _assert_audit_ok(report)

    def test_corrupt_media_removed(self) -> None:
        """Corrupt rasters must be excluded from training."""
        report = _run_audit(
            match_fields=frozenset({"corrupt_removed"}),
        )
        assert report["summary"]["corrupt_removed"] >= 2

    def test_class_balance_recovered(self) -> None:
        """Rebalanced train fold must clear the balance floor."""
        props = _props()
        report = _run_audit(
            match_fields=frozenset({"class_balance_score"}),
        )
        assert report["summary"]["class_balance_score"] >= props["summary.balance_floor"]

    def test_bbox_iou_mean(self) -> None:
        """Mapped geometry must align with canonical frame coordinates."""
        props = _props()
        report = _run_audit(
            match_fields=frozenset({"bbox_iou_mean"}),
        )
        assert report["summary"]["bbox_iou_mean"] >= props["summary.bbox_iou_floor"]

    def test_aug_flip_consistency(self) -> None:
        """Horizontal mirror pass must keep geometry consistent."""
        report = _run_audit(
            match_fields=frozenset({"aug_flip_ok"}),
        )
        _assert_flip_ok(report)


class TestFixtureScenarios:
    """Regression slices swap manifests, labels, and remap tables."""

    def test_fixture_shifted_boxes(self) -> None:
        """Offset box coordinates in labels still recover IoU after geometry fix."""
        with _apply_fixture("scenario_shifted_boxes"):
            props = _props()
            report = _run_audit(
                match_fields=frozenset({"bbox_iou_mean"}),
            )
            assert report["summary"]["bbox_iou_mean"] >= props["summary.bbox_iou_floor"]

    def test_fixture_skewed_labels(self) -> None:
        """Skewed manifest class ids must recover holdout accuracy."""
        with _apply_fixture("scenario_skewed_labels"):
            props = _props()
            report = _run_audit(
                match_fields=frozenset({"val_accuracy"}),
            )
            assert report["summary"]["val_accuracy"] >= props["summary.accuracy_floor"]

    def test_fixture_remap_table_reload(self) -> None:
        """class_remap.json overrides must flow through the gate after repair."""
        with _apply_fixture("scenario_manifest_class_drift"):
            props = _props()
            report = _run_audit(
                match_fields=frozenset({"val_accuracy", "class_balance_score"}),
                check_audit_passed=True,
            )
            assert report["summary"]["val_accuracy"] >= props["summary.accuracy_floor"]
            assert report["summary"]["class_balance_score"] >= props["summary.balance_floor"]

    def test_fixture_unbalanced_eval_pool(self) -> None:
        """Fold must score the capped train pool, not the raw train bag."""
        with _apply_fixture("scenario_unbalanced_eval_pool"):
            props = _props()
            report = _run_audit(
                match_fields=frozenset({"val_accuracy", "class_balance_score"}),
            )
            assert report["summary"]["val_accuracy"] >= props["summary.accuracy_floor"]
            assert report["summary"]["class_balance_score"] >= props["summary.balance_floor"]

    def test_fixture_mixed_dims(self) -> None:
        """Non-canonical raster sizes must normalize without collapsing IoU."""
        with _apply_fixture("scenario_mixed_dims"):
            props = _props()
            report = _run_audit(
                match_fields=frozenset({"bbox_iou_mean"}),
            )
            assert report["summary"]["bbox_iou_mean"] >= props["summary.bbox_iou_floor"]

    def test_fixture_truncated_rasters(self) -> None:
        """Truncated and zero-byte rasters must be purged from the fold."""
        with _apply_fixture("scenario_truncated_rasters"):
            report = _run_audit(
                match_fields=frozenset({"corrupt_removed"}),
            )
            assert report["summary"]["corrupt_removed"] >= 3

    def test_fixture_heavy_minority(self) -> None:
        """Heavy majority skew must still yield acceptable balance score."""
        with _apply_fixture("scenario_heavy_minority"):
            props = _props()
            report = _run_audit(
                match_fields=frozenset({"class_balance_score"}),
            )
            assert report["summary"]["class_balance_score"] >= props["summary.balance_floor"]

    def test_fixture_flip_regress(self) -> None:
        """Mirror regression slice must keep aug_flip_ok at unity."""
        with _apply_fixture("scenario_flip_regress"):
            report = _run_audit(
                match_fields=frozenset({"aug_flip_ok"}),
            )
            _assert_flip_ok(report)

    def test_fixture_full_holdout(self) -> None:
        """Expanded holdout manifest must clear accuracy band."""
        with _apply_fixture("scenario_full_holdout"):
            props = _props()
            report = _run_audit(
                match_fields=frozenset({"val_accuracy", "bbox_iou_mean"}),
            )
            assert report["summary"]["val_accuracy"] >= props["summary.accuracy_floor"]
            assert report["summary"]["bbox_iou_mean"] >= props["summary.bbox_iou_floor"]

    def test_fixture_combined_stress(self) -> None:
        """Combined shifted boxes and extra corrupt media must still pass gates."""
        with _apply_fixture("scenario_combined_stress"):
            props = _props()
            report = _run_audit(
                match_fields=frozenset(
                    {
                        "corrupt_removed",
                        "bbox_iou_mean",
                        "aug_flip_ok",
                        "val_accuracy",
                        "class_balance_score",
                    }
                ),
                check_audit_passed=True,
            )
            _assert_audit_ok(report)
            assert report["summary"]["corrupt_removed"] >= 3
            assert report["summary"]["val_accuracy"] >= props["summary.accuracy_floor"]
            assert report["summary"]["bbox_iou_mean"] >= props["summary.bbox_iou_floor"]
            train, _, _, _, _, _ = _collect_pipeline_rows()
            assert _flip_ok_for_rows(train)

    def test_fixture_holdout_box_drift(self) -> None:
        """Drifted holdout boxes must still clear accuracy and IoU bands."""
        with _apply_fixture("scenario_holdout_box_drift"):
            props = _props()
            report = _run_audit(
                match_fields=frozenset({"val_accuracy", "bbox_iou_mean", "aug_flip_ok"}),
            )
            assert report["summary"]["val_accuracy"] >= props["summary.accuracy_floor"]
            assert report["summary"]["bbox_iou_mean"] >= props["summary.bbox_iou_floor"]
            _assert_flip_ok(report)

    def test_fixture_multi_shift_boxes(self) -> None:
        """Multiple shifted annotations must still clear IoU and mirror gates."""
        with _apply_fixture("scenario_multi_shift_boxes"):
            props = _props()
            report = _run_audit(
                match_fields=frozenset({"bbox_iou_mean", "aug_flip_ok"}),
            )
            assert report["summary"]["bbox_iou_mean"] >= props["summary.bbox_iou_floor"]
            _assert_flip_ok(report)
            train, _, _, _, _, _ = _collect_pipeline_rows()
            assert _flip_ok_for_rows(train)
