#!/bin/bash
set -euo pipefail

log() { printf '[oracle] %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight module sources"
require_file /app/mx-a1/src/main/java/com/lab/geom/ImxGeom.java
require_file /app/mx-b2/src/main/java/com/lab/scan/ImxProbe.java
require_file /app/mx-c3/src/main/java/com/lab/tags/ImxTags.java
require_file /app/mx-d4/src/main/java/com/lab/raster/ImxFrame.java
require_file /app/mx-e5/src/main/java/com/lab/aug/ImxWarp.java
require_file /app/imx-hub/src/main/java/com/lab/imx/ImxRemap.java
require_file /app/imx-hub/src/main/java/com/lab/imx/ImxGate.java

log "patch geometry op_a axis divisors"
sed -i 's/raw\[0\] \/ canonH/raw[0] \/ canonW/' /app/mx-a1/src/main/java/com/lab/geom/ImxGeom.java
sed -i 's/raw\[1\] \/ canonW/raw[1] \/ canonH/' /app/mx-a1/src/main/java/com/lab/geom/ImxGeom.java
grep -q 'raw\[0\] / canonW' /app/mx-a1/src/main/java/com/lab/geom/ImxGeom.java
grep -q 'raw\[1\] / canonH' /app/mx-a1/src/main/java/com/lab/geom/ImxGeom.java

log "patch raster probe reconcile_b"
perl -0pi -e 's/long size = Files\.size\(rasterPath\);\n            return size >= 0;/long size = Files.size(rasterPath);\n            if (size < minBytes) {\n                return false;\n            }\n            byte[] head = Files.readAllBytes(rasterPath);\n            if (head.length < 8) {\n                return false;\n            }\n            return head[0] == (byte) 0x89\n                    \&\& head[1] == 0x50\n                    \&\& head[2] == 0x4E\n                    \&\& head[3] == 0x47;/s' /app/mx-b2/src/main/java/com/lab/scan/ImxProbe.java
grep -q '0x89' /app/mx-b2/src/main/java/com/lab/scan/ImxProbe.java

log "patch tag remap phase_c"
perl -0pi -e 's/public static int phase_c\(int rawId, Map<Integer, Integer> remap\) \{.*?\n    \}/public static int phase_c(int rawId, Map<Integer, Integer> remap) {\n        return remap.getOrDefault(rawId, rawId);\n    }/s' /app/mx-c3/src/main/java/com/lab/tags/ImxTags.java
grep -q 'getOrDefault' /app/mx-c3/src/main/java/com/lab/tags/ImxTags.java

log "patch frame normalization step_d"
sed -i 's/return src;/if (src.getWidth() == targetW \&\& src.getHeight() == targetH) {\n            return src;\n        }\n        return resize(src, targetW, targetH);/' /app/mx-d4/src/main/java/com/lab/raster/ImxFrame.java
grep -q 'return resize(src, targetW, targetH);' /app/mx-d4/src/main/java/com/lab/raster/ImxFrame.java

log "patch warp mirror bind_e"
perl -0pi -e 's/return new double\[\] \{box\[0\], box\[1\], box\[2\], box\[3\]\};/double mirroredX = 1.0 - box[0] - box[2];\n        return new double[] {mirroredX, box[1], box[2], box[3]};/' /app/mx-e5/src/main/java/com/lab/aug/ImxWarp.java
grep -q 'mirroredX' /app/mx-e5/src/main/java/com/lab/aug/ImxWarp.java

log "restore class_remap.json loader"
cat > /app/imx-hub/src/main/java/com/lab/imx/ImxRemap.java <<'EOF'
package com.lab.imx;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ImxRemap {
    private static final Pattern ENTRY = Pattern.compile("\"(\\d+)\"\\s*:\\s*(\\d+)");

    private ImxRemap() {
    }

    public static Map<Integer, Integer> load(Path path) throws IOException {
        String body = Files.readString(path);
        Map<Integer, Integer> out = new HashMap<>();
        Matcher matcher = ENTRY.matcher(body);
        while (matcher.find()) {
            out.put(Integer.parseInt(matcher.group(1)), Integer.parseInt(matcher.group(2)));
        }
        if (out.isEmpty()) {
            return Map.of(0, 0, 1, 1, 2, 2, 3, 3);
        }
        return out;
    }
}
EOF
grep -q 'ENTRY.matcher' /app/imx-hub/src/main/java/com/lab/imx/ImxRemap.java

log "patch fold balance cap and knn metric in hub driver"
sed -i 's/mapToInt(List::size).max()/mapToInt(List::size).min()/' /app/imx-hub/src/main/java/com/lab/imx/ImxSample.java
grep -q 'mapToInt(List::size).min()' /app/imx-hub/src/main/java/com/lab/imx/ImxSample.java
perl -0pi -e 's/return sum;/return Math.sqrt(sum);/' /app/imx-hub/src/main/java/com/lab/imx/ImxFold.java
grep -q 'Math.sqrt(sum)' /app/imx-hub/src/main/java/com/lab/imx/ImxFold.java
sed -i 's/props.getOrDefault("fold.k", "1")/props.getOrDefault("fold.knn_k", "3")/' /app/imx-hub/src/main/java/com/lab/imx/ImxConfig.java
grep -q 'fold.knn_k' /app/imx-hub/src/main/java/com/lab/imx/ImxConfig.java

log "patch feature channel order in poolRgb"
sed -i 's/g += (rgb >> 16) \& 0xff;/g += (rgb >> 8) \& 0xff;/' /app/imx-hub/src/main/java/com/lab/imx/ImxRaster.java
sed -i 's/b += (rgb >> 8) \& 0xff;/b += rgb \& 0xff;/' /app/imx-hub/src/main/java/com/lab/imx/ImxRaster.java
grep -q 'g += (rgb >> 8)' /app/imx-hub/src/main/java/com/lab/imx/ImxRaster.java

log "patch gate to score capped train pool"
perl -0pi -e 's/double balanceScore = ImxSample\.minorityFrac\(train\);/double balanceScore = ImxSample.minorityFrac(balancedTrain);/' /app/imx-hub/src/main/java/com/lab/imx/ImxGate.java
perl -0pi -e 's/double valAccuracy = ImxFold\.evaluate\(train, val, cfg\.knnK\(\)\);/double valAccuracy = ImxFold.evaluate(balancedTrain, val, cfg.knnK());/' /app/imx-hub/src/main/java/com/lab/imx/ImxGate.java
grep -q 'minorityFrac(balancedTrain)' /app/imx-hub/src/main/java/com/lab/imx/ImxGate.java
grep -q 'evaluate(balancedTrain, val' /app/imx-hub/src/main/java/com/lab/imx/ImxGate.java

log "patch mirror audit to scan every train row"
perl -0pi -e 's/int samples = Math\.min\(4, rows\.size\(\)\);\n    for \(int i = 0; i < samples; i\+\+\)/for (int i = 0; i < rows.size(); i++)/' /app/imx-hub/src/main/java/com/lab/imx/ImxGate.java
grep -q 'i < rows.size()' /app/imx-hub/src/main/java/com/lab/imx/ImxGate.java

log "rebuild shaded jar"
cd /app
mvn -q -f /app/pom.xml -DskipTests package
install -m 0644 /app/imx-hub/target/v7hub-1.0.0.jar /app/bin/imx-hub.jar
test -s /app/bin/imx-hub.jar

log "smoke audit via dataset_audit wrapper"
cmd=(/app/tools/dataset_audit)
"${cmd[@]}"
require_file /app/output/repair_report.json

log "cross-check audit_passed in report"
grep -q '"audit_passed": true' /app/output/repair_report.json
grep -q '"aug_flip_ok": 1' /app/output/repair_report.json

log "oracle complete"
