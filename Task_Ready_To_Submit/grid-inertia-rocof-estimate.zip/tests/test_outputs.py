"""Verifier for the inertia replay bench."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "inertia_report.json"
BIN = "/app/bin/inertia_lab"
ACTIVE_MANIFEST = APP / "data/active/manifest.json"
REPORT_EXAMPLE = APP / "schemas/report.example.json"
FIXTURE_INDEX = APP / "docs/fixture_index.txt"
REG_EU = APP / "data/regression/evt_eu_solo/manifest.json"
REG_PAIR = APP / "data/regression/evt_na_pair/manifest.json"
REG_MIXED = APP / "data/regression/evt_fleet_mixed/manifest.json"

SCHEMA_VERSION = 2
PASS_TOL = 0.02
LANE_TOL = 0.05


def _run_lab(manifest: Path | None = None) -> dict:
    env = {
        **os.environ,
        "TB_PMU_FIXTURE": "1",
        "LD_LIBRARY_PATH": "/app/target/release",
    }
    if manifest is not None:
        env["TB_PMU_MANIFEST"] = str(manifest)
    subprocess.run([BIN], cwd="/app", env=env, check=True)
    return json.loads(OUT.read_text())


@pytest.fixture(scope="session")
def active_report() -> dict:
    """Single active-bundle replay shared across behavioral tests."""
    return _run_lab()


def _event_row(report: dict, name: str) -> dict:
    for row in report["events"]:
        if row["name"] == name:
            return row
    raise KeyError(name)


def test_i01_report_shape(active_report: dict) -> None:
    """Report carries the lab schema version and active lab id."""
    manifest = json.loads(ACTIVE_MANIFEST.read_text())
    example = json.loads(REPORT_EXAMPLE.read_text())
    assert active_report["schema_version"] == SCHEMA_VERSION
    assert active_report["lab_id"] == manifest["lab_id"]
    assert active_report["events_total"] == len(manifest["events"])
    for key in example:
        if key != "events":
            assert key in active_report


def test_i02_bundle_clean(active_report: dict) -> None:
    """Every active event completes with low inertia relative error."""
    assert active_report["events_passed"] == active_report["events_total"]
    assert active_report["max_inertia_rel_error"] <= PASS_TOL
    assert active_report["steady_ok"] == 1
    assert active_report["multi_ok"] == 1
    for row in active_report["events"]:
        assert row["passed"] == 1
        if row["lane"] != "steady":
            assert row["rel_error"] <= LANE_TOL


def test_i03_eu_solo_tol(active_report: dict) -> None:
    """EU solo event inertia stays within the lab tolerance."""
    row = _event_row(active_report, "evt_eu_solo")
    assert row["rel_error"] <= LANE_TOL
    assert row["lane"] == "solo"


def test_i04_na_pair_tol(active_report: dict) -> None:
    """Two-unit NA fleet event stays within tolerance."""
    row = _event_row(active_report, "evt_na_pair")
    assert row["rel_error"] <= LANE_TOL
    assert row["lane"] == "fleet"
    assert row["unit_count"] == 2


def test_i05_fleet_mixed_tol(active_report: dict) -> None:
    """Cross-area fleet event stays within tolerance."""
    row = _event_row(active_report, "evt_fleet_mixed")
    assert row["rel_error"] <= LANE_TOL
    assert row["lane"] == "fleet"


def test_i06_na_triple_tol(active_report: dict) -> None:
    """Three-unit NA fleet event stays within tolerance."""
    row = _event_row(active_report, "evt_na_triple")
    assert row["rel_error"] <= LANE_TOL
    assert row["lane"] == "fleet"
    assert row["unit_count"] == 3


def test_i07_bad_unit_tol(active_report: dict) -> None:
    """Fleet event with a rejected unit lane stays within tolerance."""
    row = _event_row(active_report, "evt_bad_unit")
    assert row["rel_error"] <= LANE_TOL
    assert row["lane"] == "fleet"


def test_i08_steady_gate(active_report: dict) -> None:
    """Steady-lane events report near-zero slope and pass."""
    assert active_report["steady_ok"] == 1
    for name in ("evt_steady_east", "evt_steady_west"):
        row = _event_row(active_report, name)
        assert row["passed"] == 1
        assert row["lane"] == "steady"
        assert abs(row["rocof_hz_s"]) < 0.001


def test_i09_digest_bind(active_report: dict) -> None:
    """Report digest matches digest_cli over counters."""
    proc = subprocess.run(
        [
            "/app/bin/digest_cli",
            str(active_report["events_total"]),
            str(active_report["events_passed"]),
            f"{active_report['max_inertia_rel_error']:.12e}",
            str(active_report["steady_ok"]),
            str(active_report["multi_ok"]),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    assert proc.stdout.strip() == active_report["digest_hex"]


def test_i10_go_units() -> None:
    """Go plan package unit tests pass."""
    env = {
        **os.environ,
        "CGO_ENABLED": "1",
        "CGO_CFLAGS": "-I/app/gi_k7",
        "CGO_LDFLAGS": "-L/app/target/release -lgi_k7 -lm",
        "GOFLAGS": "-mod=mod",
    }
    subprocess.run(
        ["go", "test", "./internal/plan/..."],
        cwd="/app",
        env=env,
        check=True,
    )


def test_i11_rust_units() -> None:
    """Rust workspace smoke tests pass."""
    env = {**os.environ, "CARGO_TARGET_DIR": "/app/target"}
    subprocess.run(
        ["cargo", "test", "--release", "-p", "gi_k7", "smoke"],
        cwd="/app",
        env=env,
        check=True,
    )


def test_i12_regression_eu() -> None:
    """EU solo regression bundle stays within tolerance."""
    report = _run_lab(manifest=REG_EU)
    row = _event_row(report, "evt_eu_solo")
    assert row["rel_error"] <= LANE_TOL


def test_i13_regression_pair() -> None:
    """NA pair regression bundle stays within tolerance."""
    report = _run_lab(manifest=REG_PAIR)
    row = _event_row(report, "evt_na_pair")
    assert row["rel_error"] <= LANE_TOL


def test_i14_regression_mixed() -> None:
    """Mixed fleet regression bundle stays within tolerance."""
    report = _run_lab(manifest=REG_MIXED)
    row = _event_row(report, "evt_fleet_mixed")
    assert row["rel_error"] <= LANE_TOL


def test_i15_fixture_index() -> None:
    """Fixture index lists every regression bundle on disk."""
    text = FIXTURE_INDEX.read_text()
    assert "evt_eu_solo" in text
    assert "evt_na_pair" in text
    assert "evt_fleet_mixed" in text
    assert str(REG_EU) in text
    assert str(REG_PAIR) in text
    assert str(REG_MIXED) in text


def test_i16_na_solo_tol(active_report: dict) -> None:
    """Single NA solo event stays within tolerance."""
    row = _event_row(active_report, "evt_na_solo")
    assert row["rel_error"] <= LANE_TOL
    assert row["lane"] == "solo"
