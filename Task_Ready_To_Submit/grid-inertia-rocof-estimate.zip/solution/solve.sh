#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/gi_k7/src/k7_rf.rs <<'EOF'
fn area_table(code: u32) -> f64 {
    match code {
        2 => 50.0,
        1 => 60.0,
        0 => 60.0,
        _ => 60.0,
    }
}

pub fn op_f0(code: u32) -> f64 {
    area_table(code)
}

#[no_mangle]
pub extern "C" fn gi_op_f0(code: u32) -> f64 {
    op_f0(code)
}
EOF

cat > /app/internal/window/op_w.go <<'EOF'
package window

type Sample struct {
	TUs    float64
	FHz    float64
	MarkOK int
}

type Lane struct {
	Code   uint32
	Points []Sample
}

func OpW(lanes []Lane) (freqs [][]float64, times [][]float64) {
	if len(lanes) == 0 {
		return nil, nil
	}
	var tMin, tMax float64 = 1e18, -1e18
	for _, lane := range lanes {
		for _, pt := range lane.Points {
			if pt.TUs < tMin {
				tMin = pt.TUs
			}
			if pt.TUs > tMax {
				tMax = pt.TUs
			}
		}
	}
	const dt = 33333.0
	var grid []float64
	for t := tMin; t <= tMax+1; t += dt {
		grid = append(grid, t)
	}
	freqs = make([][]float64, len(lanes))
	times = make([][]float64, len(lanes))
	for li, lane := range lanes {
		for _, tg := range grid {
			f := interpAt(lane.Points, tg)
			freqs[li] = append(freqs[li], f)
			times[li] = append(times[li], tg)
		}
	}
	return freqs, times
}

func interpAt(pts []Sample, t float64) float64 {
	if len(pts) == 0 {
		return 0
	}
	if t <= pts[0].TUs {
		return pts[0].FHz
	}
	last := pts[len(pts)-1]
	if t >= last.TUs {
		return last.FHz
	}
	for i := 1; i < len(pts); i++ {
		a := pts[i-1]
		b := pts[i]
		if t >= a.TUs && t <= b.TUs {
			if b.TUs == a.TUs {
				return a.FHz
			}
			w := (t - a.TUs) / (b.TUs - a.TUs)
			return a.FHz + w*(b.FHz-a.FHz)
		}
	}
	return last.FHz
}
EOF

perl -0pi -e 's/func OpA\(lanes \[\]window.Lane, deltaP float64, baseCode uint32\) \(rocof, inertia, relErr float64\) \{\n\tfreqs, times := window.OpW\(lanes\)/func OpA(lanes []window.Lane, deltaP float64, baseCode uint32) (rocof, inertia, relErr float64) {\n\tlanes = opQ1(lanes)\n\tfreqs, times := window.OpW(lanes)/' /app/internal/agg/op_a.go

perl -0pi -e 's/\n\t\trocof, inertia, relErr := agg.OpAWithRef\(lanes, evt.DeltaPMw, evt.RefHS, evt.BaseCode\)\n\t\t_ = agg.DiscardRejected\(lanes\)/\n\t\trocof, inertia, relErr := agg.OpAWithRef(lanes, evt.DeltaPMw, evt.RefHS, evt.BaseCode)/' /app/internal/driver/run.go

bash /app/scripts/build.sh

rm -f /app/output/inertia_report.json
mkdir -p /app/output
TB_PMU_FIXTURE=1 /app/bin/inertia_lab
test -s /app/output/inertia_report.json

env CGO_ENABLED=1 CGO_CFLAGS="-I/app/gi_k7" CGO_LDFLAGS="-L/app/target/release -lgi_k7 -lm" GOFLAGS=-mod=mod \
  go test ./internal/plan/...

cargo test --release -p gi_k7 smoke
