module gridlab

go 1.24
