package fold

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
)

func DigestReport(total, passed int, maxErr float64, steadyOK, multiOK int) string {
	payload := fmt.Sprintf("%d|%d|%.12e|%d|%d", total, passed, maxErr, steadyOK, multiOK)
	sum := sha256.Sum256([]byte(payload))
	return hex.EncodeToString(sum[:16])
}

func OpF(total int) uint32 {
	return uint32(total % 997)
}
