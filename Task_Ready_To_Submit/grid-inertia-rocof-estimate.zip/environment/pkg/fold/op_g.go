package fold

func OpG(n uint64) uint64 {
	if n < 16 {
		return 16
	}
	return n
}
