# Inertia replay bench

Multi-language PMU replay stack. Build with `/app/scripts/build.sh`, run `/app/bin/inertia_lab`.
