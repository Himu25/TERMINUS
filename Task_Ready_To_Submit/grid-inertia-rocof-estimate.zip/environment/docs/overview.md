Offline PMU replay bench. Rust gi_k7 core linked through CGO; Go driver aggregates unit lanes and emits JSON counters.
