package window

type Sample struct {
	TUs    float64
	FHz    float64
	MarkOK int
}

type Lane struct {
	Code   uint32
	Points []Sample
}

func OpW(lanes []Lane) (freqs [][]float64, times [][]float64) {
	if len(lanes) == 0 {
		return nil, nil
	}
	minLen := len(lanes[0].Points)
	for _, lane := range lanes[1:] {
		if len(lane.Points) < minLen {
			minLen = len(lane.Points)
		}
	}
	freqs = make([][]float64, len(lanes))
	times = make([][]float64, len(lanes))
	for i := 0; i < minLen; i++ {
		for li, lane := range lanes {
			pt := lane.Points[i]
			freqs[li] = append(freqs[li], pt.FHz)
			times[li] = append(times[li], pt.TUs)
		}
	}
	return freqs, times
}
