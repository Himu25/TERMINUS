package bridge

/*
#cgo CFLAGS: -I${SRCDIR}/../../gi_k7
#cgo LDFLAGS: -L${SRCDIR}/../../target/release -Wl,-rpath,${SRCDIR}/../../target/release -lgi_k7 -lm
#include "gi_k7.h"
*/
import "C"
import "unsafe"

func OpF0(code uint32) float64 {
	return float64(C.gi_op_f0(C.uint32_t(code)))
}

func OpR3(freq, tUs []float64) float64 {
	if len(freq) < 2 || len(tUs) < 2 {
		return 0
	}
	n := len(freq)
	if len(tUs) < n {
		n = len(tUs)
	}
	return float64(C.gi_op_r3(
		(*C.double)(unsafe.Pointer(&freq[0])),
		(*C.double)(unsafe.Pointer(&tUs[0])),
		C.uint32_t(n),
	))
}

func OpH2(rocof, deltaP, baseHz float64) float64 {
	return float64(C.gi_op_h2(C.double(rocof), C.double(deltaP), C.double(baseHz)))
}
