package agg

import "gridlab/internal/window"

func opQ1(lanes []window.Lane) []window.Lane {
	out := make([]window.Lane, 0, len(lanes))
	for _, lane := range lanes {
		pts := make([]window.Sample, 0, len(lane.Points))
		for _, pt := range lane.Points {
			if pt.MarkOK == 0 {
				continue
			}
			pts = append(pts, pt)
		}
		if len(pts) > 0 {
			lane.Points = pts
			out = append(out, lane)
		}
	}
	return out
}

func DiscardRejected(lanes []window.Lane) []window.Lane {
	return opQ1(lanes)
}
