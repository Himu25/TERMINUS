package agg

import (
	"math"

	"gridlab/internal/bridge"
	"gridlab/internal/window"
)

func OpA(lanes []window.Lane, deltaP float64, baseCode uint32) (rocof, inertia, relErr float64) {
	freqs, times := window.OpW(lanes)
	rocof = meanRocof(freqs, times)
	baseHz := bridge.OpF0(baseCode)
	inertia = bridge.OpH2(rocof, deltaP, baseHz)
	return rocof, inertia, relErr
}

func OpAWithRef(lanes []window.Lane, deltaP, refH float64, baseCode uint32) (rocof, inertia, relErr float64) {
	rocof, inertia, _ = OpA(lanes, deltaP, baseCode)
	if refH == 0 {
		return rocof, inertia, 0
	}
	relErr = math.Abs(inertia-refH) / math.Abs(refH)
	return rocof, inertia, relErr
}

func meanRocof(freqs [][]float64, times [][]float64) float64 {
	if len(freqs) == 0 {
		return 0
	}
	var sum float64
	var n float64
	for i := range freqs {
		if len(freqs[i]) < 2 {
			continue
		}
		sum += bridge.OpR3(freqs[i], times[i])
		n++
	}
	if n == 0 {
		return 0
	}
	return sum / n
}
