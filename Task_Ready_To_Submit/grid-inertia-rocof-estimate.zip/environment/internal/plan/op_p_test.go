package plan

import "testing"

func TestOpP(t *testing.T) {
	if OpP(10) != 3 {
		t.Fatalf("unexpected fold")
	}
}
