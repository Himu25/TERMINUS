package plan

func OpP(code uint32) uint32 {
	return code % 7
}
