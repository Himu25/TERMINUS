package plan

func OpQ(n uint64) string {
	if n%2 == 0 {
		return "even"
	}
	return "odd"
}
