package driver

import (
	"encoding/json"
	"math"
	"os"
	"path/filepath"

	"gridlab/internal/agg"
	"gridlab/internal/window"
	"gridlab/pkg/fold"
)

type StreamSpec struct {
	Region   string  `json:"region"`
	UnitID   string  `json:"unit_id"`
	Seed     uint64  `json:"seed"`
	OffsetUs float64 `json:"offset_us"`
	MarkOK   int     `json:"mark_ok"`
}

type EventSpec struct {
	Name      string       `json:"name"`
	Lane      string       `json:"lane"`
	DeltaPMw  float64      `json:"delta_p_mw"`
	RefHS     float64      `json:"ref_h_s"`
	BaseCode  uint32       `json:"base_code"`
	Streams   []StreamSpec `json:"streams"`
}

type CaseRoot struct {
	LabID  string      `json:"lab_id"`
	Events []EventSpec `json:"events"`
}

type EventRow struct {
	Name      string  `json:"name"`
	UnitCount int     `json:"unit_count"`
	RocofHzS  float64 `json:"rocof_hz_s"`
	InertiaHS float64 `json:"inertia_h_s"`
	RelError  float64 `json:"rel_error"`
	Passed    int     `json:"passed"`
	Lane      string  `json:"lane"`
}

type Report struct {
	SchemaVersion       int        `json:"schema_version"`
	LabID               string     `json:"lab_id"`
	EventsTotal         int        `json:"events_total"`
	EventsPassed        int        `json:"events_passed"`
	MaxInertiaRelError  float64    `json:"max_inertia_rel_error"`
	SteadyOK            int        `json:"steady_ok"`
	MultiOK             int        `json:"multi_ok"`
	DigestHex           string     `json:"digest_hex"`
	Events              []EventRow `json:"events"`
}

const passTol = 0.02
const laneTol = 0.05

func OpL0(path string) (*CaseRoot, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var b CaseRoot
	if err := json.Unmarshal(raw, &b); err != nil {
		return nil, err
	}
	return &b, nil
}

func Run(manifestPath, outPath string) error {
	b, err := OpL0(manifestPath)
	if err != nil {
		return err
	}
	report := Report{
		SchemaVersion: 2,
		LabID:         b.LabID,
		EventsTotal:   len(b.Events),
		SteadyOK:      1,
		MultiOK:       1,
	}
	var maxErr float64
	for _, evt := range b.Events {
		lanes := SynthLanes(evt)
		rocof, inertia, relErr := agg.OpAWithRef(lanes, evt.DeltaPMw, evt.RefHS, evt.BaseCode)
		_ = agg.DiscardRejected(lanes)
		row := EventRow{
			Name:      evt.Name,
			UnitCount: len(evt.Streams),
			RocofHzS:  rocof,
			InertiaHS: inertia,
			RelError:  relErr,
			Lane:      evt.Lane,
		}
		ok := relErr <= laneTol || evt.RefHS == 0
		if evt.Lane == "steady" {
			ok = math.Abs(rocof) < 0.001
		}
		if ok {
			row.Passed = 1
			report.EventsPassed++
		}
		if relErr > maxErr && evt.RefHS != 0 {
			maxErr = relErr
		}
		if evt.Lane == "steady" && row.Passed == 0 {
			report.SteadyOK = 0
		}
		if evt.Lane == "fleet" && row.Passed == 0 {
			report.MultiOK = 0
		}
		report.Events = append(report.Events, row)
	}
	report.MaxInertiaRelError = maxErr
	report.DigestHex = fold.DigestReport(
		report.EventsTotal,
		report.EventsPassed,
		report.MaxInertiaRelError,
		report.SteadyOK,
		report.MultiOK,
	)
	if err := os.MkdirAll(filepath.Dir(outPath), 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(outPath, raw, 0o644)
}

func SynthLanes(evt EventSpec) []window.Lane {
	lanes := make([]window.Lane, 0, len(evt.Streams))
	eventBase := baseHzFor(evt.BaseCode)
	rocofTrue := 0.0
	if evt.RefHS != 0 {
		rocofTrue = -evt.DeltaPMw / (2.0 * eventBase * evt.RefHS)
	}
	for _, spec := range evt.Streams {
		code := regionCode(spec.Region)
		base := baseHzFor(code)
		pts := synthPoints(spec.Seed, spec.OffsetUs, base, rocofTrue, spec.MarkOK)
		lanes = append(lanes, window.Lane{Code: code, Points: pts})
	}
	return lanes
}

func regionCode(region string) uint32 {
	switch region {
	case "eu_central":
		return 2
	case "na_west":
		return 1
	default:
		return 0
	}
}

func baseHzFor(code uint32) float64 {
	if code == 2 {
		return 50.0
	}
	return 60.0
}

func synthPoints(seed uint64, offsetUs, baseHz, rocofTrue float64, markOK int) []window.Sample {
	const n = 24
	const dt = 33333.0
	pts := make([]window.Sample, n)
	state := seed ^ 0xDEADBEEFCAFEBABE
	for i := 0; i < n; i++ {
		t := offsetUs + float64(i)*dt
		f := baseHz + rocofTrue*t*1e-6
		if markOK == 0 && i == n/2 {
			state = state*6364136223846793005 + 1
			f += 5.0 + float64(state%1000)/100.0
		}
		pts[i] = window.Sample{TUs: t, FHz: f, MarkOK: markOK}
	}
	return pts
}
