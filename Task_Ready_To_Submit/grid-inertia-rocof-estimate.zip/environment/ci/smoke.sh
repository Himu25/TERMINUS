#!/usr/bin/env bash
set -euo pipefail
test -x /app/bin/inertia_lab
test -x /app/bin/digest_cli
