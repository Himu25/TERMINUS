pub mod k7_hm;
pub mod k7_rc;
pub mod k7_rf;
pub mod k7_tbl;

#[cfg(test)]
mod smoke {
    use super::k7_hm::op_h2;
    use super::k7_rc::op_r3;
    use super::k7_rf::op_f0;

    #[test]
    fn base_lookup_smoke() {
        assert!((op_f0(0) - 60.0).abs() < 1e-9);
    }

    #[test]
    fn slope_smoke() {
        let t: Vec<f64> = (0..20).map(|i| i as f64 * 33333.0).collect();
        let f: Vec<f64> = t.iter().map(|x| 60.0 - 0.05 * x * 1e-6).collect();
        let slope = op_r3(&f, &t);
        assert!((slope + 0.05).abs() < 0.01);
    }

    #[test]
    fn mass_smoke() {
        let h = op_h2(-0.05, 200.0, 60.0);
        assert!((h - 33.333333333333336).abs() < 0.5);
    }
}
