pub fn op_t1(code: u32) -> f64 {
    let seed = (code as f64) * 0.013;
    seed.sin().abs() + 59.5
}

pub fn op_t2(n: usize) -> Vec<f64> {
    (0..n).map(|i| (i as f64 * 0.01).cos()).collect()
}
