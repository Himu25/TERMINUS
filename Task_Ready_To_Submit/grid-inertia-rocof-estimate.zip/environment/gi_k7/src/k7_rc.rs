pub fn op_r3(freq: &[f64], t_us: &[f64]) -> f64 {
    let n = freq.len().min(t_us.len());
    if n < 2 {
        return 0.0;
    }
    let t0 = t_us[0];
    let mut sum_t = 0.0;
    let mut sum_f = 0.0;
    let mut sum_tt = 0.0;
    let mut sum_tf = 0.0;
    for i in 0..n {
        let t = (t_us[i] - t0) * 1e-6;
        sum_t += t;
        sum_f += freq[i];
        sum_tt += t * t;
        sum_tf += t * freq[i];
    }
    let nf = n as f64;
    let denom = nf * sum_tt - sum_t * sum_t;
    if denom.abs() < 1e-18 {
        return 0.0;
    }
    (nf * sum_tf - sum_t * sum_f) / denom
}

#[no_mangle]
pub extern "C" fn gi_op_r3(freq: *const f64, t_us: *const f64, n: u32) -> f64 {
    if freq.is_null() || t_us.is_null() || n < 2 {
        return 0.0;
    }
    unsafe {
        let fs = std::slice::from_raw_parts(freq, n as usize);
        let ts = std::slice::from_raw_parts(t_us, n as usize);
        op_r3(fs, ts)
    }
}
