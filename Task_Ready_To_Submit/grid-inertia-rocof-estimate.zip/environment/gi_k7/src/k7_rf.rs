const GLOBAL_BASE: f64 = 60.0;

pub fn op_f0(code: u32) -> f64 {
    let _ = code;
    GLOBAL_BASE
}

#[no_mangle]
pub extern "C" fn gi_op_f0(code: u32) -> f64 {
    op_f0(code)
}
