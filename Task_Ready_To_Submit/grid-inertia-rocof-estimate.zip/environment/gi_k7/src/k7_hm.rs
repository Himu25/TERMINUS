pub fn op_h2(rocof: f64, delta_p: f64, base_hz: f64) -> f64 {
    if rocof.abs() < 1e-9 || base_hz.abs() < 1e-9 {
        return 0.0;
    }
    -delta_p / (2.0 * base_hz * rocof)
}

#[no_mangle]
pub extern "C" fn gi_op_h2(rocof: f64, delta_p: f64, base_hz: f64) -> f64 {
    op_h2(rocof, delta_p, base_hz)
}
