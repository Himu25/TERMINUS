#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

double gi_op_f0(uint32_t code);
double gi_op_r3(const double *freq, const double *t_us, uint32_t n);
double gi_op_h2(double rocof, double delta_p, double base_hz);

#ifdef __cplusplus
}
#endif
