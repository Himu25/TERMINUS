package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
	"strconv"
)

func main() {
	if len(os.Args) < 6 {
		os.Exit(2)
	}
	total, _ := strconv.Atoi(os.Args[1])
	passed, _ := strconv.Atoi(os.Args[2])
	maxErr, _ := strconv.ParseFloat(os.Args[3], 64)
	steady, _ := strconv.Atoi(os.Args[4])
	multi, _ := strconv.Atoi(os.Args[5])
	payload := fmt.Sprintf("%d|%d|%.12e|%d|%d", total, passed, maxErr, steady, multi)
	sum := sha256.Sum256([]byte(payload))
	fmt.Println(hex.EncodeToString(sum[:16]))
}
