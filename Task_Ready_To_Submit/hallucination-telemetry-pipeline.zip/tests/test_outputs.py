"""Verifier for hallucination telemetry monitor reports."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any

APP = Path("/app")
REPORT = APP / "output" / "monitor_report.json"
SCENARIOS = APP / "scenarios"
FX = Path(__file__).resolve().parent / "fx"


def _units(r: dict[str, Any]) -> int:
    return r["stage_embed"] + r["stage_index"] + r["stage_rerank"] + r["stage_merge"]


def _clip(rows: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], int]:
    seen: set[str] = set()
    out: list[dict[str, Any]] = []
    repairs = 0
    for row in rows:
        key = f"{row['lane'].strip()}|{row['request_id'].strip()}"
        if key in seen:
            repairs += 1
            continue
        seen.add(key)
        out.append(dict(row))
    return out, repairs


def _shift(rows: list[dict[str, Any]], spread_lag: int) -> tuple[list[dict[str, Any]], int]:
    out = [dict(r) for r in rows]
    fail_epoch: dict[str, int] = {}
    skips = 0
    for row in out:
        if not row["retrieval_ok"]:
            if row["lane"] not in fail_epoch:
                fail_epoch[row["lane"]] = row["epoch"]
            continue
        ep = fail_epoch.get(row["lane"])
        if ep is not None and spread_lag > 0 and row["epoch"] > ep and row["epoch"] <= ep + spread_lag:
            if row["stage_merge"] > 0:
                row["stage_merge"] = 0
                skips += 1
    return out, skips


def _grounding_milli(r: dict[str, Any], budget: int, floor_pct: int) -> int:
    if not r["retrieval_ok"]:
        return 0
    need = max(1, r["citation_need"])
    base = r["citation_hits"] * 1000 // need
    floor = r["budget_tokens"] * floor_pct // 100
    if r["budget_tokens"] > 0 and r["emitted_tokens"] < floor:
        base = base * 3 // 4
    if _units(r) > budget:
        base //= 2
    return min(1000, base)


def _hallucinates(r: dict[str, Any], budget: int, floor_pct: int) -> bool:
    if not r["retrieval_ok"]:
        return True
    if r["citation_need"] == 0:
        return False
    return _grounding_milli(r, budget, floor_pct) < 550


def _worst_stage(r: dict[str, Any]) -> str:
    order = [
        ("embed", r["stage_embed"]),
        ("index", r["stage_index"]),
        ("rerank", r["stage_rerank"]),
        ("merge", r["stage_merge"]),
    ]
    return max(order, key=lambda item: (item[1], ["embed", "index", "rerank", "merge"].index(item[0])))[0]


def _expected(stem: str) -> dict[str, Any]:
    batch = json.loads((SCENARIOS / f"{stem}.json").read_text(encoding="utf-8"))
    trimmed, repairs = _clip(batch["trace"])
    shifted, skips = _shift(trimmed, batch["spread_lag"])
    budget = batch["latency_budget"]
    floor = batch["trim_floor_pct"]
    milli = [_grounding_milli(r, budget, floor) for r in shifted]
    kept = len(shifted)
    mean = round(sum(milli) / kept / 1000, 4) if kept else 0.0
    hall = sum(1 for i, r in enumerate(shifted) if _hallucinates(r, budget, floor))
    spike = 0
    threshold = batch["spike_threshold"]
    lag = batch["correlation_lag"]
    for j, r in enumerate(shifted):
        if not _hallucinates(r, budget, floor):
            continue
        for i in range(max(0, j - lag), j + 1):
            if shifted[i]["spike_flag"] or _units(shifted[i]) > threshold:
                spike += 1
                break
    degraded = sum(
        1 for r in shifted if _units(r) > threshold and _worst_stage(r) != "embed"
    )
    trunc = sum(
        1
        for r in shifted
        if r["budget_tokens"] > 0 and r["emitted_tokens"] < r["budget_tokens"] * floor // 100
    )
    fallback = sum(
        1
        for r in shifted
        if (not r["retrieval_ok"] and r["fallback_tag"] != "degraded")
        or (r["retrieval_ok"] and r["fallback_tag"] == "cache")
    )
    over = sum(1 for r in shifted if _units(r) > budget)
    return {
        "scenario_tag": batch["scenario_label"],
        "requests_kept": kept,
        "mean_grounding": mean,
        "hallucination_events": hall,
        "latency_overruns": over,
        "spike_correlated": spike,
        "degraded_stage_hits": degraded,
        "truncation_events": trunc,
        "fallback_mismatches": fallback,
        "intermittent_skips": skips,
        "replay_repairs": repairs,
    }


def _run_only(stem: str) -> dict[str, Any]:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    if REPORT.exists():
        REPORT.unlink()
    subprocess.run(
        ["/app/bin/monitord"],
        cwd="/app",
        env={**os.environ, "tb_scenario": stem},
        check=True,
    )
    payload = json.loads(REPORT.read_text(encoding="utf-8"))
    assert len(payload["monitor_runs"]) == 1
    return payload["monitor_runs"][0]


def _drive(stem: str) -> dict[str, Any]:
    row = _run_only(stem)
    want = _expected(stem)
    assert row.get("scenario_tag") == want["scenario_tag"]
    for key, val in want.items():
        if key == "scenario_tag":
            continue
        assert row[key] == val, f"{stem}.{key}: got {row[key]!r} want {val!r}"
    return row


def test_scenario_steady_grounding_floors() -> None:
    """Steady bundle keeps grounding above hallucination thresholds under spike flags."""
    _drive("scenario_steady")


def test_scenario_lane_dup_cross_lane_replay() -> None:
    """Shared request_id across lanes must remain distinct after narrowing."""
    _drive("scenario_lane_dup")


def test_scenario_intermittent_failure_spread() -> None:
    """Lane failures surface fallback mismatches and merge stabilization skips."""
    _drive("scenario_intermittent")


def test_scenario_truncation_partial_context() -> None:
    """Emitted tokens below trim_floor_pct register truncation and grounding loss."""
    _drive("scenario_truncation")


def test_scenario_fallback_cache_mismatch() -> None:
    """Cache fallback on healthy retrieval is an inconsistent routing decision."""
    _drive("scenario_fallback")


def test_scenario_spike_correlation_window() -> None:
    """Hallucination rows correlate when a spike window lies at row index j-lag..j inclusive."""
    _drive("scenario_spike_corr")


def test_scenario_stage_hot_index_rerank() -> None:
    """Hot rows attribute bottlenecks to index or rerank rather than embed alone."""
    _drive("scenario_stage_hot")


def test_scenario_composite_stress() -> None:
    """Composite bundle mixes replay repair, truncation, fallback, spikes, and spread."""
    _drive("scenario_composite")


def _rebuild_monitord() -> None:
    subprocess.run(["cargo", "build", "--release"], cwd="/app/spine_r9", check=True)
    subprocess.run(
        ["go", "build", "-o", "/app/bin/monitord", "./cmd/monitord"],
        cwd="/app",
        env={**os.environ, "CGO_ENABLED": "1"},
        check=True,
    )


def _ablate_copy(rel: str, broken_src: Path) -> None:
    target = APP / rel
    backup = target.with_suffix(target.suffix + ".orig")
    if not backup.exists():
        shutil.copy2(target, backup)
    shutil.copy2(broken_src, target)
    _rebuild_monitord()


def _restore(rel: str) -> None:
    target = APP / rel
    backup = target.with_suffix(target.suffix + ".orig")
    if backup.exists():
        shutil.copy2(backup, target)
        backup.unlink()


def _ablate_check(rel: str, broken_src: Path, stem: str, predicate) -> None:
    _ablate_copy(rel, broken_src)
    try:
        row = _run_only(stem)
        predicate(row)
    finally:
        _restore(rel)
        _rebuild_monitord()


def test_ablation_lane_key_regression() -> None:
    """Reverting lane|request narrowing must break cross-lane duplicate handling."""
    want = _expected("scenario_lane_dup")

    def check(row: dict[str, Any]) -> None:
        assert row["requests_kept"] != want["requests_kept"] or row["replay_repairs"] != want["replay_repairs"]

    _ablate_check("flux_p2/narrow.go", FX / "broken_narrow.go", "scenario_lane_dup", check)


def test_ablation_fallback_audit_regression() -> None:
    """Reverting routing audit must hide cache-on-healthy mismatches."""
    floor = _expected("scenario_fallback")["fallback_mismatches"]

    def check(row: dict[str, Any]) -> None:
        assert row["fallback_mismatches"] < floor

    _ablate_check("route_f4/audit.go", FX / "broken_audit.go", "scenario_fallback", check)


def test_ablation_truncation_floor_regression() -> None:
    """Reverting trim_floor_pct truncation must under-count partial context events."""
    floor = _expected("scenario_truncation")["truncation_events"]

    def check(row: dict[str, Any]) -> None:
        assert row["truncation_events"] < floor

    _ablate_check("internal/runner/tally.go", FX / "broken_tally.go", "scenario_truncation", check)
