package flux_p2

import (
	"strings"

	"monweep/tracewire"
)

func laneKey(r tracewire.TraceRow) string {
	return strings.TrimSpace(r.RequestID)
}

func ClipSpan(rows []tracewire.TraceRow) ([]tracewire.TraceRow, int) {
	seen := map[string]bool{}
	out := make([]tracewire.TraceRow, 0, len(rows))
	noise := 0
	for idx := range rows {
		r := rows[idx]
		key := laneKey(r)
		if seen[key] {
			noise++
			continue
		}
		seen[key] = true
		out = append(out, r)
	}
	return out, noise
}

func Units(r tracewire.TraceRow) int {
	return r.StageEmbed + r.StageIndex + r.StageRerank + r.StageMerge
}

func WorstStage(r tracewire.TraceRow) string {
	return "embed"
}

func CorrelateSpikes(rows []tracewire.TraceRow, threshold, lag, budget, floorPct int) int {
	return 0
}

func StageDegraded(rows []tracewire.TraceRow, threshold int) int {
	return 0
}
