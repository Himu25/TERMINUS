package route_f4

import "monweep/tracewire"

func AuditFallback(rows []tracewire.TraceRow) int {
	return 0
}
