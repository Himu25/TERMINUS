#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/flux_p2/narrow.go <<'EOF'
package flux_p2

import (
	"strings"

	"monweep/tracewire"
)

func laneKey(r tracewire.TraceRow) string {
	var b strings.Builder
	b.WriteString(strings.TrimSpace(r.Lane))
	b.WriteByte('|')
	b.WriteString(strings.TrimSpace(r.RequestID))
	return b.String()
}

// ClipSpan removes replayed duplicates while preserving first-seen order.
func ClipSpan(rows []tracewire.TraceRow) ([]tracewire.TraceRow, int) {
	seen := map[string]bool{}
	out := make([]tracewire.TraceRow, 0, len(rows))
	noise := 0
	for idx := range rows {
		r := rows[idx]
		key := laneKey(r)
		if seen[key] {
			noise++
			continue
		}
		seen[key] = true
		out = append(out, r)
	}
	return out, noise
}

// Units sums retrieval stage cost for one row.
func Units(r tracewire.TraceRow) int {
	return r.StageEmbed + r.StageIndex + r.StageRerank + r.StageMerge
}

// WorstStage names the slowest retrieval stage for the row.
func WorstStage(r tracewire.TraceRow) string {
	best := "embed"
	top := r.StageEmbed
	if r.StageIndex > top {
		top = r.StageIndex
		best = "index"
	}
	if r.StageRerank > top {
		top = r.StageRerank
		best = "rerank"
	}
	if r.StageMerge > top {
		best = "merge"
	}
	return best
}

func rowGroundingMilli(r tracewire.TraceRow, budget, floorPct int) int {
	if !r.RetrievalOK {
		return 0
	}
	need := r.CitationNeed
	if need < 1 {
		need = 1
	}
	base := r.CitationHits * 1000 / need
	floor := r.BudgetTokens * floorPct / 100
	if r.BudgetTokens > 0 && r.EmittedTokens < floor {
		base = base * 3 / 4
	}
	if Units(r) > budget {
		base /= 2
	}
	if base > 1000 {
		base = 1000
	}
	return base
}

func rowHallucinates(r tracewire.TraceRow, budget, floorPct int) bool {
	if !r.RetrievalOK {
		return true
	}
	if r.CitationNeed == 0 {
		return false
	}
	return rowGroundingMilli(r, budget, floorPct) < 550
}

// CorrelateSpikes counts hallucinations preceded by a spike within correlation_lag.
func CorrelateSpikes(rows []tracewire.TraceRow, threshold, lag, budget, floorPct int) int {
	hits := 0
	for j := range rows {
		if !rowHallucinates(rows[j], budget, floorPct) {
			continue
		}
		for i := 0; i <= j; i++ {
			if i < j-lag {
				continue
			}
			if rows[i].SpikeFlag || Units(rows[i]) > threshold {
				hits++
				break
			}
		}
	}
	return hits
}

// StageDegraded counts rows whose bottleneck is not embed while hot.
func StageDegraded(rows []tracewire.TraceRow, threshold int) int {
	n := 0
	for idx := range rows {
		r := rows[idx]
		if Units(r) <= threshold {
			continue
		}
		if WorstStage(r) != "embed" {
			n++
		}
	}
	return n
}
EOF

cat > /app/route_f4/audit.go <<'EOF'
package route_f4

import "monweep/tracewire"

// AuditFallback counts inconsistent fallback routing decisions.
func AuditFallback(rows []tracewire.TraceRow) int {
	mismatch := 0
	for idx := range rows {
		r := rows[idx]
		if !r.RetrievalOK && r.FallbackTag != "degraded" {
			mismatch++
		}
		if r.RetrievalOK && r.FallbackTag == "cache" {
			mismatch++
		}
	}
	return mismatch
}
EOF

cat > /app/internal/runner/tally.go <<'EOF'
package runner

import "monweep/tracewire"

func countTrunc(rows []tracewire.TraceRow, floorPct int) int {
	n := 0
	for idx := range rows {
		r := rows[idx]
		floor := r.BudgetTokens * floorPct / 100
		if r.BudgetTokens > 0 && r.EmittedTokens < floor {
			n++
		}
	}
	return n
}

func countOverruns(rows []tracewire.TraceRow, budget int) int {
	n := 0
	for idx := range rows {
		u := rows[idx].StageEmbed + rows[idx].StageIndex + rows[idx].StageRerank + rows[idx].StageMerge
		if u > budget {
			n++
		}
	}
	return n
}
EOF

rm -f /app/flux_p2/prune.go /app/route_f4/fallback.go /app/internal/runner/trimclip.go

sed -i 's/CorrelateSpikes(shifted, batch.SpikeThreshold, batch.CorrelationLag)/CorrelateSpikes(shifted, batch.SpikeThreshold, batch.CorrelationLag, batch.LatencyBudget, batch.TrimFloorPct)/' \
  /app/internal/runner/drive.go

bash /app/scripts/build.sh
