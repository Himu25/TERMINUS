module monweep

go 1.22
