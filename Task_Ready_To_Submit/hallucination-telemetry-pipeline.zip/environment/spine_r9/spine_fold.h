#ifndef SPINE_FOLD_H
#define SPINE_FOLD_H

#include <stdbool.h>
#include <stddef.h>

typedef struct {
    int citation_hits;
    int citation_need;
    int emitted_tokens;
    int budget_tokens;
    int trim_floor_pct;
    int retrieval_units;
    int latency_budget;
    bool retrieval_ok;
} sf_row;

typedef struct {
    int grounding_milli_sum;
    int hallucination_events;
    int requests_kept;
    int degraded_stage_hits;
} sf_roll;

sf_roll sf_meter_span(const sf_row *rows, size_t count);

#endif
