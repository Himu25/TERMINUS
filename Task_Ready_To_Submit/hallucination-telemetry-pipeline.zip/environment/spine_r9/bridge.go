package spine_r9

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libspine_fold.a -ldl -lm
#include "spine_fold.h"
*/
import "C"

import (
	"unsafe"

	"monweep/flux_p2"
	"monweep/tracewire"
)

// MonitorView is the folded telemetry view for one scenario.
type MonitorView struct {
	MeanGroundingMilli int
	HallucinationEvents int
	RequestsKept       int
}

// FoldSpan aggregates grounding after narrowing and shift.
func FoldSpan(rows []tracewire.TraceRow, budget, floorPct int) MonitorView {
	if len(rows) == 0 {
		ct := C.sf_meter_span(nil, 0)
		return viewFrom(ct)
	}
	cRows := make([]C.sf_row, len(rows))
	for idx := range rows {
		r := rows[idx]
		cRows[idx] = C.sf_row{
			citation_hits:   C.int(r.CitationHits),
			citation_need:   C.int(r.CitationNeed),
			emitted_tokens:  C.int(r.EmittedTokens),
			budget_tokens:   C.int(r.BudgetTokens),
			trim_floor_pct:  C.int(floorPct),
			retrieval_units: C.int(flux_p2.Units(r)),
			latency_budget:  C.int(budget),
			retrieval_ok:    C.bool(r.RetrievalOK),
		}
	}
	ct := C.sf_meter_span((*C.sf_row)(unsafe.Pointer(&cRows[0])), C.size_t(len(cRows)))
	return viewFrom(ct)
}

func viewFrom(ct C.sf_roll) MonitorView {
	return MonitorView{
		MeanGroundingMilli: int(ct.grounding_milli_sum),
		HallucinationEvents: int(ct.hallucination_events),
		RequestsKept:       int(ct.requests_kept),
	}
}
