use std::cmp;

#[repr(C)]
pub struct SfRow {
    pub citation_hits: i32,
    pub citation_need: i32,
    pub emitted_tokens: i32,
    pub budget_tokens: i32,
    pub trim_floor_pct: i32,
    pub retrieval_units: i32,
    pub latency_budget: i32,
    pub retrieval_ok: bool,
}

#[repr(C)]
pub struct SfRoll {
    pub grounding_milli_sum: i32,
    pub hallucination_events: i32,
    pub requests_kept: i32,
    pub degraded_stage_hits: i32,
}

fn row_grounding(r: &SfRow) -> i32 {
    if !r.retrieval_ok {
        return 0;
    }
    let need = cmp::max(1, r.citation_need);
    let mut base = (r.citation_hits * 1000) / need;
    let floor = (r.budget_tokens * r.trim_floor_pct) / 100;
    if r.budget_tokens > 0 && r.emitted_tokens < floor {
        base = base * 3 / 4;
    }
    if r.retrieval_units > r.latency_budget {
        base /= 2;
    }
    cmp::min(1000, base)
}

fn row_hallucinates(r: &SfRow, grounding_milli: i32) -> bool {
    if !r.retrieval_ok {
        return true;
    }
    if r.citation_need == 0 {
        return false;
    }
    grounding_milli < 550
}

#[no_mangle]
pub extern "C" fn sf_meter_span(rows: *const SfRow, count: usize) -> SfRoll {
    let mut roll = SfRoll {
        grounding_milli_sum: 0,
        hallucination_events: 0,
        requests_kept: 0,
        degraded_stage_hits: 0,
    };
    if rows.is_null() || count == 0 {
        return roll;
    }
    let slice = unsafe { std::slice::from_raw_parts(rows, count) };
    for r in slice {
        roll.requests_kept += 1;
        let g = row_grounding(r);
        roll.grounding_milli_sum += g;
        if row_hallucinates(r, g) {
            roll.hallucination_events += 1;
        }
    }
    roll
}
