package tracewire

// TraceRow is one assistant request with retrieval telemetry.
type TraceRow struct {
	Lane          string `json:"lane"`
	RequestID     string `json:"request_id"`
	StageEmbed    int    `json:"stage_embed"`
	StageIndex    int    `json:"stage_index"`
	StageRerank   int    `json:"stage_rerank"`
	StageMerge    int    `json:"stage_merge"`
	BudgetTokens  int    `json:"budget_tokens"`
	EmittedTokens int    `json:"emitted_tokens"`
	CitationHits  int    `json:"citation_hits"`
	CitationNeed  int    `json:"citation_need"`
	RetrievalOK   bool   `json:"retrieval_ok"`
	FallbackTag   string `json:"fallback_tag"`
	SpikeFlag     bool   `json:"spike_flag"`
	Epoch         int    `json:"epoch"`
}

// Scenario is one replay bundle under /app/scenarios.
type Scenario struct {
	ScenarioLabel  string     `json:"scenario_label"`
	LatencyBudget  int        `json:"latency_budget"`
	SpikeThreshold int        `json:"spike_threshold"`
	CorrelationLag int        `json:"correlation_lag"`
	SpreadLag      int        `json:"spread_lag"`
	TrimFloorPct   int        `json:"trim_floor_pct"`
	Trace          []TraceRow `json:"trace"`
}
