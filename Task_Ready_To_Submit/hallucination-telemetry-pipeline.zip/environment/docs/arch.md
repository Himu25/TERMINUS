# Architecture

Go packages narrow traces, audit fallback routing, and emit JSON. Rust spine_r9 meters grounding via cgo.
