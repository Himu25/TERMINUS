# Stage ledger

## Retrieval units and stages

Retrieval units are the sum of embed, index, rerank, and merge stage counters on each row after shift stabilization (merge may be cleared during spread handling).

Worst-stage attribution picks the stage with the highest unit count; ties break toward merge, then rerank, then index, then embed. Rows above `spike_threshold` whose worst stage is not embed increment `degraded_stage_hits`.

## Grounding meter (Rust)

Grounding uses citation hits over citation need in permille. Failed retrieval yields zero grounding and counts as a hallucination. Zero `citation_need` is never a hallucination. Otherwise grounding below 550 permille is a hallucination.

Partial context applies a three-quarters factor when `emitted_tokens` fall below `trim_floor_pct` percent of `budget_tokens`. Latency overrun halves grounding when units exceed `latency_budget`.

`mean_grounding` is the mean permille score divided by 1000, rounded to four decimal places.

## Replay narrowing

Duplicate `lane|request_id` keys drop after the first seen row; each dropped row increments `replay_repairs`.

## Intermittent retrieval spread

After a failed retrieval on a lane, rows on that lane with epoch inside `spread_lag` of the failure clear merge units for budget stabilization; each cleared merge increments `intermittent_skips`.

## Truncation

`truncation_events` counts rows whose `emitted_tokens` are below `trim_floor_pct` percent of `budget_tokens` while budget is positive.

## Fallback routing

`fallback_mismatches` counts rows where retrieval failed but `fallback_tag` is not `degraded`, or retrieval succeeded but `fallback_tag` is `cache`.

## Spike correlation

`spike_correlated` increments once per hallucination row. After replay narrowing and spread stabilization, rows are scanned in slice order (index `0..n-1`); `epoch` does not define the window.

For hallucination row index `j`, look back along row indices from `max(0, j - correlation_lag)` through `j` inclusive. If any row in that index window is a spike window (`spike_flag` or retrieval units above `spike_threshold`), count this hallucination once and continue to the next hallucination row.

Implement and extend `CorrelateSpikes` in `flux_p2/narrow.go`. If hallucination detection needs budget or trim inputs, widen the function signature and pass them from `internal/runner/drive.go` at the existing `SpikeCorrelated` assignment. Do not route `spike_correlated` through a new helper the runner does not call; verifier ablations replace `flux_p2/narrow.go` wholesale.

## Latency overruns

`latency_overruns` counts rows whose retrieval units exceed `latency_budget`.
