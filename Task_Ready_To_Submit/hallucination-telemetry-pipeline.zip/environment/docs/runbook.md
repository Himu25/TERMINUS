# Runbook

Set tb_scenario to a JSON stem under /app/scenarios (for example scenario_steady, scenario_lane_dup, scenario_intermittent, scenario_truncation, scenario_fallback, scenario_spike_corr, scenario_stage_hot, scenario_composite) and run /app/bin/monitord after /app/scripts/build.sh.
