package keel_m8

import "monweep/tracewire"

// ShiftSpan clears merge units for rows that follow a failed retrieval on the same lane.
func ShiftSpan(rows []tracewire.TraceRow, spreadLag int, _ int) ([]tracewire.TraceRow, int) {
	out := make([]tracewire.TraceRow, len(rows))
	copy(out, rows)
	skips := 0
	failEpoch := map[string]int{}
	for idx := range out {
		r := &out[idx]
		if !r.RetrievalOK {
			if _, seen := failEpoch[r.Lane]; !seen {
				failEpoch[r.Lane] = r.Epoch
			}
			continue
		}
		ep, failed := failEpoch[r.Lane]
		if failed && spreadLag > 0 && r.Epoch > ep && r.Epoch <= ep+spreadLag {
			if r.StageMerge > 0 {
				r.StageMerge = 0
				skips++
			}
		}
	}
	return out, skips
}
