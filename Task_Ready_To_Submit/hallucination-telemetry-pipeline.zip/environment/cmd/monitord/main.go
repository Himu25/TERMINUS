// monitord replays one scenario from /app/scenarios when tb_scenario is set.
//
// Output /app/output/monitor_report.json carries monitor_runs[0] with:
// scenario_tag,
// requests_kept (rows after replay narrowing),
// mean_grounding (Rust meter mean, four decimal places),
// hallucination_events (grounding below contract or failed retrieval),
// latency_overruns (retrieval units above latency_budget),
// spike_correlated (per hallucination row: spike window at row index j-lag..j inclusive on stabilized trace),
// degraded_stage_hits (non-embed bottleneck while above spike_threshold),
// truncation_events (emitted below trim_floor_pct of budget),
// fallback_mismatches (non-degraded tag on failed retrieval or cache on healthy path),
// intermittent_skips (merge units cleared inside spread_lag after failure),
// replay_repairs (duplicate lane|request_id rows removed during narrowing).
package main

import (
	"os"

	"monweep/internal/runner"
)

func main() {
	os.Exit(runner.MainExit())
}
