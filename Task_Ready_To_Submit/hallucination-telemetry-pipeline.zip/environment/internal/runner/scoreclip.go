package runner

import (
	"monweep/spine_r9"
	"monweep/tracewire"
)

func runSeal(rows []tracewire.TraceRow, budget, floorPct int) spine_r9.MonitorView {
	return spine_r9.FoldSpan(rows, budget, floorPct)
}
