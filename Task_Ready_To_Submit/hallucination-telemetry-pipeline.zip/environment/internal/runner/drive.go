package runner

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"

	"monweep/flux_p2"
	"monweep/route_f4"
	"monweep/tracewire"
)

// MonitorRun is one scenario emission.
type MonitorRun struct {
	ScenarioTag         string  `json:"scenario_tag"`
	RequestsKept        int     `json:"requests_kept"`
	MeanGrounding       float64 `json:"mean_grounding"`
	HallucinationEvents int     `json:"hallucination_events"`
	LatencyOverruns     int     `json:"latency_overruns"`
	SpikeCorrelated     int     `json:"spike_correlated"`
	DegradedStageHits   int     `json:"degraded_stage_hits"`
	TruncationEvents    int     `json:"truncation_events"`
	FallbackMismatches  int     `json:"fallback_mismatches"`
	IntermittentSkips   int     `json:"intermittent_skips"`
	ReplayRepairs       int     `json:"replay_repairs"`
}

type monitorPayload struct {
	MonitorRuns []MonitorRun `json:"monitor_runs"`
}

// Run loads one scenario using tb_scenario, writes /app/output/monitor_report.json.
func Run() error {
	stem := os.Getenv("tb_scenario")
	if stem == "" {
		return errors.New("tb_scenario must name a stem under /app/scenarios")
	}
	emit := "/app/output/monitor_report.json"
	raw, err := os.ReadFile(filepath.Join("/app", "scenarios", stem+".json"))
	if err != nil {
		return err
	}
	var batch tracewire.Scenario
	if err := json.Unmarshal(raw, &batch); err != nil {
		return err
	}
	trimmed, repairs := runClip(batch.Trace)
	shifted, skips := runShift(trimmed, batch.SpreadLag, batch.SpikeThreshold)
	view := runSeal(shifted, batch.LatencyBudget, batch.TrimFloorPct)
	mean := 0.0
	if view.RequestsKept > 0 {
		mean = float64(view.MeanGroundingMilli) / float64(view.RequestsKept) / 1000.0
	}
	run := MonitorRun{
		ScenarioTag:         batch.ScenarioLabel,
		RequestsKept:        view.RequestsKept,
		MeanGrounding:       round4(mean),
		HallucinationEvents: view.HallucinationEvents,
		LatencyOverruns:     countOverruns(shifted, batch.LatencyBudget),
		SpikeCorrelated:     flux_p2.CorrelateSpikes(shifted, batch.SpikeThreshold, batch.CorrelationLag),
		DegradedStageHits:   flux_p2.StageDegraded(shifted, batch.SpikeThreshold),
		TruncationEvents:    countTrunc(shifted, batch.TrimFloorPct),
		FallbackMismatches:  route_f4.AuditFallback(shifted),
		IntermittentSkips:   skips,
		ReplayRepairs:       repairs,
	}
	out := monitorPayload{MonitorRuns: []MonitorRun{run}}
	if err := os.MkdirAll(filepath.Dir(emit), 0o755); err != nil {
		return err
	}
	buf, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		return err
	}
	tmp := emit + ".tmp"
	if err := os.WriteFile(tmp, buf, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, emit)
}

func round4(v float64) float64 {
	return float64(int(v*10000+0.5)) / 10000
}

// MainExit is a thin wrapper for cmd.
func MainExit() int {
	if err := Run(); err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		return 1
	}
	return 0
}
