// Package runner drives one scenario replay into monitor_report.json.
package runner
