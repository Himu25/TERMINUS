package runner

import "monweep/tracewire"

func countTrunc(rows []tracewire.TraceRow, floorPct int) int {
	n := 0
	for idx := range rows {
		r := rows[idx]
		if r.EmittedTokens == 0 && r.BudgetTokens > 0 {
			n++
		}
	}
	return n
}

func countOverruns(rows []tracewire.TraceRow, budget int) int {
	n := 0
	for idx := range rows {
		u := rows[idx].StageEmbed + rows[idx].StageIndex + rows[idx].StageRerank + rows[idx].StageMerge
		if u > budget {
			n++
		}
	}
	return n
}
