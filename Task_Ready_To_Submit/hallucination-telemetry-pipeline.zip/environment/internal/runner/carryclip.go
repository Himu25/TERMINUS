package runner

import (
	"monweep/flux_p2"
	"monweep/keel_m8"
	"monweep/tracewire"
)

func runClip(rows []tracewire.TraceRow) ([]tracewire.TraceRow, int) {
	return flux_p2.ClipSpan(rows)
}

func runShift(rows []tracewire.TraceRow, lag, threshold int) ([]tracewire.TraceRow, int) {
	return keel_m8.ShiftSpan(rows, lag, threshold)
}
