# Hallucination telemetry pipeline

Offline replay harness for enterprise assistant retrieval monitoring.
