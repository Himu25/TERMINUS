// Package route_f4 audits fallback routing against retrieval health.
package route_f4
