package route_f4

import "monweep/tracewire"

// AuditFallback counts inconsistent fallback routing decisions.
func AuditFallback(rows []tracewire.TraceRow) int {
	mismatch := 0
	for idx := range rows {
		r := rows[idx]
		if !r.RetrievalOK && r.FallbackTag == "degraded" {
			mismatch++
		}
		if r.RetrievalOK && r.FallbackTag == "primary" {
			mismatch++
		}
	}
	return mismatch
}
