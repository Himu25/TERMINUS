// Package flux_p2 narrows replayed traces and correlates latency spikes.
package flux_p2
