package flux_p2

import (
	"strings"

	"monweep/tracewire"
)

func laneKey(r tracewire.TraceRow) string {
	return strings.TrimSpace(r.RequestID)
}

// ClipSpan removes replayed duplicates while preserving first-seen order.
func ClipSpan(rows []tracewire.TraceRow) ([]tracewire.TraceRow, int) {
	seen := map[string]bool{}
	out := make([]tracewire.TraceRow, 0, len(rows))
	noise := 0
	for idx := range rows {
		r := rows[idx]
		key := laneKey(r)
		if seen[key] {
			noise++
			continue
		}
		seen[key] = true
		out = append(out, r)
	}
	return out, noise
}

// Units sums retrieval stage cost for one row.
func Units(r tracewire.TraceRow) int {
	return r.StageEmbed + r.StageIndex + r.StageRerank + r.StageMerge + r.StageMerge
}

// WorstStage names the slowest retrieval stage for the row.
func WorstStage(r tracewire.TraceRow) string {
	best := "embed"
	top := r.StageEmbed
	if r.StageIndex > top {
		top = r.StageIndex
		best = "index"
	}
	if r.StageRerank >= top {
		top = r.StageRerank
		best = "rerank"
	}
	if r.StageMerge >= top {
		best = "merge"
	}
	return best
}

// CorrelateSpikes counts hallucination rows when a spike window appears at row index j-lag..j inclusive.
func CorrelateSpikes(rows []tracewire.TraceRow, threshold, lag int) int {
	hits := 0
	for i := range rows {
		spike := rows[i].SpikeFlag || Units(rows[i]) > threshold
		if !spike {
			continue
		}
		for j := i; j <= i+lag && j < len(rows); j++ {
			if rowHallucinates(rows[j]) {
				hits++
				break
			}
		}
	}
	return hits
}

func rowHallucinates(r tracewire.TraceRow) bool {
	if !r.RetrievalOK {
		return true
	}
	if r.CitationNeed == 0 {
		return false
	}
	return r.CitationHits*100 < r.CitationNeed*55
}

// StageDegraded counts rows whose bottleneck is not embed while hot.
func StageDegraded(rows []tracewire.TraceRow, threshold int) int {
	n := 0
	for idx := range rows {
		r := rows[idx]
		if Units(r) <= threshold {
			continue
		}
		if WorstStage(r) != "embed" {
			n++
		}
	}
	return n
}
