"""Validate /app/output/compress_bench.json against pipeline.toml guardrails.

Covers report schema, digest determinism, default-bundle quality floors,
failover and billing rows, fixture bundles from /app/docs/fixture_queries.txt,
worker-imbalance ablations, serialization sync-unit ceilings, and corrupted-partial
decode ablations that prove partial fixes cannot pass.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "compress_bench.json"
CFG = APP / "config" / "pipeline.toml"
RUNNER = APP / "tools" / "run_bench"
GO_BIN = "go"
GO_BUILD_TIMEOUT_SEC = 180
VERIFIER_GOCACHE = Path("/tmp/tbench-pec-verifier-gocache")
PACK_SOURCE = APP / "data" / "fixture_packs"
ACTIVE_PACKS = Path("/tmp/tbench-pec-active-packs")
FIXTURES = Path(__file__).resolve().parent / "fixtures"

REPORT_KEYS = frozenset(
    {
        "status",
        "corpus_vectors",
        "vector_dim",
        "worker_count",
        "batches_total",
        "mean_cosine_fidelity",
        "mean_compress_ratio",
        "mean_worker_units",
        "mean_sync_units",
        "p95_batch_units",
        "mean_balance_score",
        "mean_reject_rate",
        "report_digest",
        "batches",
    }
)
QUERY_KEYS = frozenset(
    {
        "batch_id",
        "cosine_fidelity",
        "compress_ratio",
        "intact_chunks",
        "worker_units",
        "sync_units",
        "batch_units",
        "workers_active",
        "rejects_bad",
        "balance_score",
        "chunk_ids",
    }
)
def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "vector_dim": 32,
        "worker_count": 4,
        "top_k": 10,
        "fidelity_floor": 0.82,
        "compress_ratio_floor": 0.72,
        "max_mean_worker_units": 4200,
        "max_mean_sync_units": 180,
        "max_p95_batch_units": 5200,
        "failover_fidelity_floor": 0.65,
        "tight_pack_fidelity_floor": 0.5,
        "billing_pack_min_fidelity": 0.6667,
        "billing_pack_min_intact": 2,
        "skew_balance_min_fidelity": 0.7,
        "balance_floor": 0.72,
        "max_mean_reject_rate": 0.0,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in (
            "fidelity_floor",
            "compress_ratio_floor",
            "failover_fidelity_floor",
            "tight_pack_fidelity_floor",
            "billing_pack_min_fidelity",
            "skew_balance_min_fidelity",
            "balance_floor",
            "max_mean_reject_rate",
        ):
            cfg[key] = float(val)
        elif key == "billing_pack_min_intact":
            cfg[key] = int(float(val))
        elif key in (
            "vector_dim",
            "worker_count",
            "top_k",
            "max_mean_worker_units",
            "max_mean_sync_units",
            "max_p95_batch_units",
        ):
            cfg[key] = int(float(val))
    return cfg


def _round4(value: float) -> float:
    return round(value * 10000 + 0.5) / 10000


def _expected_means(rows: list[dict]) -> tuple[float, float, float, float]:
    if not rows:
        return 0.0, 0.0, 0.0, 0.0
    total = len(rows)
    recall = sum(row["cosine_fidelity"] for row in rows) / total
    ndcg = sum(row["compress_ratio"] for row in rows) / total
    shard_u = sum(row["worker_units"] for row in rows) / total
    merge_u = sum(row["sync_units"] for row in rows) / total
    return _round4(recall), _round4(ndcg), _round4(shard_u), _round4(merge_u)


def _digest_payload(report: dict) -> dict:
    return {
        "status": report["status"],
        "corpus_vectors": report["corpus_vectors"],
        "vector_dim": report["vector_dim"],
        "worker_count": report["worker_count"],
        "batches_total": report["batches_total"],
        "mean_cosine_fidelity": report["mean_cosine_fidelity"],
        "mean_compress_ratio": report["mean_compress_ratio"],
        "mean_worker_units": report["mean_worker_units"],
        "mean_sync_units": report["mean_sync_units"],
        "p95_batch_units": report["p95_batch_units"],
        "mean_balance_score": report["mean_balance_score"],
        "mean_reject_rate": report["mean_reject_rate"],
        "report_digest": "",
        "batches": report["batches"],
    }


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _assert_query_row(row: dict) -> None:
    assert set(row) == QUERY_KEYS
    assert isinstance(row["batch_id"], str) and row["batch_id"]
    assert isinstance(row["cosine_fidelity"], (int, float))
    assert isinstance(row["compress_ratio"], (int, float))
    assert isinstance(row["intact_chunks"], int)
    assert isinstance(row["worker_units"], int)
    assert isinstance(row["sync_units"], int)
    assert isinstance(row["batch_units"], int)
    assert isinstance(row["workers_active"], int)
    assert isinstance(row["chunk_ids"], list)
    assert 0.0 <= float(row["cosine_fidelity"]) <= 1.0
    assert 0.0 <= float(row["compress_ratio"]) <= 1.0
    assert row["intact_chunks"] >= 0
    assert row["worker_units"] >= 0
    assert row["sync_units"] >= 0
    assert row["batch_units"] == row["worker_units"] + row["sync_units"]
    assert row["workers_active"] >= 0
    assert isinstance(row["rejects_bad"], int) and row["rejects_bad"] >= 0
    assert isinstance(row["balance_score"], (int, float))
    assert 0.0 <= float(row["balance_score"]) <= 1.0
    for doc_id in row["chunk_ids"]:
        assert isinstance(doc_id, str) and doc_id


def _assert_report_schema(data: dict) -> None:
    assert set(data) == REPORT_KEYS
    assert isinstance(data["status"], str) and data["status"] in {"ok", "fail"}
    for int_key in (
        "corpus_vectors",
        "vector_dim",
        "worker_count",
        "batches_total",
        "p95_batch_units",
    ):
        assert isinstance(data[int_key], int), int_key
        assert data[int_key] >= 0, int_key
    for float_key in (
        "mean_cosine_fidelity",
        "mean_compress_ratio",
        "mean_worker_units",
        "mean_sync_units",
        "mean_balance_score",
        "mean_reject_rate",
    ):
        assert isinstance(data[float_key], (int, float)), float_key
        assert float(data[float_key]) >= 0.0, float_key
    digest = data["report_digest"]
    assert isinstance(digest, str) and len(digest) == 64
    assert digest == digest.lower()
    assert re.fullmatch(r"[0-9a-f]{64}", digest)
    assert isinstance(data["batches"], list)
    for row in data["batches"]:
        _assert_query_row(row)


def _load_report(path: Path = OUT) -> dict:
    assert path.is_file(), f"missing report at {path}"
    data = json.loads(path.read_text(encoding="utf-8"))
    _assert_report_schema(data)
    return data


_STOPWORDS = frozenset({"the", "a", "an", "and", "or"})


def _fnv1a_64(data: bytes) -> int:
    digest = 14695981039346656037
    for byte in data:
        digest ^= byte
        digest = (digest * 1099511628211) & ((1 << 64) - 1)
    return digest


def _qx_prep(text: str) -> str:
    parts = text.lower().split()
    kept = [part for part in parts if part not in _STOPWORDS]
    if not kept:
        return " ".join(parts)
    return " ".join(kept)


def _vec_from_text(text: str, dim: int) -> list[float]:
    seed = _fnv1a_64(text.encode("utf-8"))
    out: list[float] = []
    for _ in range(dim):
        seed = (seed * 6364136223846793005 + 1442695040888963407) & ((1 << 64) - 1)
        out.append(((seed >> 33) % 1000) / 500.0 - 1.0)
    norm = sum(value * value for value in out) ** 0.5
    if norm > 0:
        out = [value / norm for value in out]
    return out


def _dot(a: list[float], b: list[float]) -> float:
    return sum(x * y for x, y in zip(a, b))


def _reference_top_gold_ids(
    corpus_path: Path,
    query: str,
    *,
    use_prep: bool,
    dim: int,
    top_k: int,
) -> list[str]:
    payload = json.loads(corpus_path.read_text(encoding="utf-8"))
    vectors = payload["vectors"]
    qtext = _qx_prep(query) if use_prep else query
    qv = _vec_from_text(qtext, dim)
    scored = [
        (_dot(qv, _vec_from_text(doc["text"], dim)), doc["id"]) for doc in vectors
    ]
    scored.sort(key=lambda pair: pair[0], reverse=True)
    return [doc_id for _, doc_id in scored[:top_k]]


def _gold_ids_for(batch_id: str, batches_path: Path) -> list[str]:
    for line in batches_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        if row["batch_id"] == batch_id:
            gold = row["gold_ids"]
            assert isinstance(gold, list) and gold
            return gold
    raise AssertionError(f"batch_id {batch_id} not found in {batches_path}")


def _verifier_build_env(base: dict[str, str] | None = None) -> dict[str, str]:
    env = dict(base or os.environ.copy())
    env["GOCACHE"] = str(VERIFIER_GOCACHE)
    return env


def _stage_pack_fixtures() -> Path:
    """Copy immutable pack fixtures so agent writes under /tests cannot block verifier."""
    assert PACK_SOURCE.is_dir(), f"missing canonical pack fixtures at {PACK_SOURCE}"
    if ACTIVE_PACKS.exists():
        shutil.rmtree(ACTIVE_PACKS)
    shutil.copytree(PACK_SOURCE, ACTIVE_PACKS)
    return ACTIVE_PACKS


def _rebuild_benchd(env: dict[str, str] | None = None) -> None:
    build_env = _verifier_build_env(env)
    VERIFIER_GOCACHE.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        [GO_BIN, "build", "-o", "/app/bin/benchd", "./cmd/benchd"],
        cwd=APP,
        env=build_env,
        check=True,
        capture_output=True,
        text=True,
        timeout=GO_BUILD_TIMEOUT_SEC,
    )


def _labelsync(corpus_path: Path, specs_path: Path, out_path: Path) -> None:
    subprocess.run(
        [
            "/app/bin/refgen",
            corpus_path.as_posix(),
            specs_path.as_posix(),
            out_path.as_posix(),
        ],
        check=True,
        capture_output=True,
        text=True,
    )


def _fixture_batches_path(pack: Path) -> Path:
    return APP / "output" / f"fixture_{pack.name}_batches.jsonl"


def _run_bench(
    query_path: Path,
    out_path: Path = OUT,
    corpus_path: Path | None = None,
    *,
    rebuild: bool = False,
) -> None:
    env = os.environ.copy()
    if corpus_path is not None:
        env["TB_CORPUS_PATH"] = str(corpus_path)
    else:
        env.pop("TB_CORPUS_PATH", None)
    if out_path.exists():
        out_path.unlink()
    if rebuild:
        _rebuild_benchd(env)
    subprocess.run(
        [
            "/app/bin/benchd",
            query_path.as_posix(),
            out_path.as_posix(),
        ],
        cwd=APP,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )


def _assert_ok_default(report: dict) -> None:
    cfg = _parse_cfg()
    assert report["status"] == "ok"
    assert report["mean_cosine_fidelity"] >= cfg["fidelity_floor"]
    assert report["mean_compress_ratio"] >= cfg["compress_ratio_floor"]
    assert report["mean_worker_units"] <= cfg["max_mean_worker_units"]
    assert report["mean_sync_units"] <= cfg["max_mean_sync_units"]
    assert report["p95_batch_units"] <= cfg["max_p95_batch_units"]
    assert report["mean_balance_score"] >= cfg["balance_floor"]
    assert report["mean_reject_rate"] <= cfg["max_mean_reject_rate"]


@pytest.fixture(scope="session", autouse=True)
def _default_bench_run() -> None:
    _stage_pack_fixtures()
    build_env = _verifier_build_env()
    VERIFIER_GOCACHE.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        [GO_BIN, "build", "-o", "/app/bin/refgen", "./cmd/refgen"],
        cwd=APP,
        env=build_env,
        check=True,
        capture_output=True,
        text=True,
        timeout=GO_BUILD_TIMEOUT_SEC,
    )
    _rebuild_benchd(build_env)
    _labelsync(
        APP / "data" / "corpus_default.json",
        APP / "data" / "batch_specs.jsonl",
        APP / "data" / "batches_default.jsonl",
    )
    _run_bench(APP / "data" / "batches_default.jsonl")


def test_runner_exists() -> None:
    """Documented bench driver is present and executable."""
    assert RUNNER.is_file() and os.access(RUNNER, os.X_OK)


def test_report_schema_keys() -> None:
    """compress_bench.json exposes the contract field set only."""
    report = _load_report()
    _assert_ok_default(report)
    assert report["batches_total"] == len(report["batches"])


def test_per_query_row_keys() -> None:
    """Each batches[] row uses the documented sub-schema and valid metric ranges."""
    report = _load_report()
    _assert_ok_default(report)
    for row in report["batches"]:
        _assert_query_row(row)


def test_status_ok_and_mean_floors() -> None:
    """Default bundle clears fidelity, compress_ratio, balance, and unit ceilings with status ok."""
    _assert_ok_default(_load_report())


def test_unit_budgets_within_caps() -> None:
    """Synthetic worker, sync, and p95 batch units stay under pipeline.toml ceilings."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["status"] == "ok"
    assert report["mean_worker_units"] <= cfg["max_mean_worker_units"]
    assert report["mean_sync_units"] <= cfg["max_mean_sync_units"]
    assert report["p95_batch_units"] <= cfg["max_p95_batch_units"]
    assert report["mean_balance_score"] >= cfg["balance_floor"]
    assert report["mean_reject_rate"] <= cfg["max_mean_reject_rate"]


def test_summary_means_recomputed_from_query_rows() -> None:
    """Mean summary fields must match per-batch rows within tolerance."""
    report = _load_report()
    want_recall, want_ndcg, want_shard, want_merge = _expected_means(report["batches"])
    assert report["mean_cosine_fidelity"] == pytest.approx(want_recall, abs=2e-4)
    assert report["mean_compress_ratio"] == pytest.approx(want_ndcg, abs=2e-4)
    assert report["mean_worker_units"] == pytest.approx(want_shard, abs=2e-4)
    assert report["mean_sync_units"] == pytest.approx(want_merge, abs=2e-4)


def test_p95_batch_units_matches_rows() -> None:
    """p95_batch_units is the 95th percentile of per-query batch_units."""
    report = _load_report()
    units = sorted(row["batch_units"] for row in report["batches"])
    idx = max(0, int(len(units) * 0.95 + 0.999999) - 1)
    assert report["p95_batch_units"] == units[idx]


def test_sync_units_weight_formula() -> None:
    """sync_units follows top_k * (workers_active + 1) for each batch row."""
    report = _load_report()
    cfg = _parse_cfg()
    top_k = int(cfg["top_k"])
    for row in report["batches"]:
        want = top_k * (row["workers_active"] + 1)
        assert row["sync_units"] == want


def test_report_digest_format() -> None:
    """report_digest is 64-char lowercase hex."""
    digest = _load_report()["report_digest"]
    assert len(digest) == 64
    assert digest == digest.lower()
    assert re.fullmatch(r"[0-9a-f]{64}", digest)


def test_report_digest_matches_body() -> None:
    """report_digest is SHA-256 of the compact pre-digest payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_repeat_run_byte_identical() -> None:
    """Back-to-back default runs emit identical report bytes."""
    _assert_ok_default(_load_report())
    first = OUT.read_bytes()
    _run_bench(APP / "data" / "batches_default.jsonl")
    second = OUT.read_bytes()
    assert first == second


def test_batches_total_matches_pack_line_count() -> None:
    """batches_total equals non-empty lines in the default batch JSONL."""
    report = _load_report()
    expected = sum(
        1
        for line in (APP / "data" / "batches_default.jsonl")
        .read_text(encoding="utf-8")
        .splitlines()
        if line.strip()
    )
    assert report["batches_total"] == expected
    assert len(report["batches"]) == expected


def test_corpus_vectors_matches_manifest() -> None:
    """corpus_vectors and vector_dim track the worker registry manifest."""
    report = _load_report()
    manifest = json.loads((APP / "registry" / "shard_manifest.json").read_text(encoding="utf-8"))
    assert report["corpus_vectors"] == manifest["count"]
    assert report["vector_dim"] == manifest["dim"]
    assert report["worker_count"] == manifest["shards"]


def test_b_billing_refund_fidelity_floor() -> None:
    """b_billing_refund must recover most gold neighbors and match recall accounting."""
    report = _load_report()
    cfg = _parse_cfg()
    batches_path = APP / "data" / "batches_default.jsonl"
    gold_ids = _gold_ids_for("b_billing_refund", batches_path)
    row = next(r for r in report["batches"] if r["batch_id"] == "b_billing_refund")
    assert row["intact_chunks"] >= cfg["billing_pack_min_intact"]
    assert row["cosine_fidelity"] >= cfg["billing_pack_min_fidelity"]
    assert row["cosine_fidelity"] == pytest.approx(
        row["intact_chunks"] / len(gold_ids),
        abs=2e-4,
    )


def test_b_search_ann_compress_ratio_floor() -> None:
    """b_search_ann ndcg must be positive once ranking is repaired."""
    report = _load_report()
    cfg = _parse_cfg()
    row = next(r for r in report["batches"] if r["batch_id"] == "b_search_ann")
    assert row["compress_ratio"] >= cfg["compress_ratio_floor"] / (2 * cfg["top_k"])


def test_b_latency_skew_fidelity_floor() -> None:
    """b_latency_skew must clear the latency skew recall floor from pipeline.toml."""
    report = _load_report()
    cfg = _parse_cfg()
    row = next(r for r in report["batches"] if r["batch_id"] == "b_latency_skew")
    assert row["cosine_fidelity"] >= cfg["skew_balance_min_fidelity"]


def test_query_rows_preserve_input_order() -> None:
    """batches[] row order matches non-empty lines in the input JSONL pack."""
    report = _load_report()
    order = [
        json.loads(line)["batch_id"]
        for line in (APP / "data" / "batches_default.jsonl")
        .read_text(encoding="utf-8")
        .splitlines()
        if line.strip()
    ]
    assert [row["batch_id"] for row in report["batches"]] == order


def test_failover_queries_skip_dead_workers() -> None:
    """Failover rows use only live workers and clear failover_fidelity_floor."""
    report = _load_report()
    cfg = _parse_cfg()
    specs = {
        json.loads(line)["batch_id"]: json.loads(line).get("dead_workers", [])
        for line in (APP / "data" / "batch_specs.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    }
    for row in report["batches"]:
        if not row["batch_id"].startswith("b_failover"):
            continue
        dead = specs[row["batch_id"]]
        assert row["workers_active"] == cfg["worker_count"] - len(dead)
        assert row["cosine_fidelity"] >= cfg["failover_fidelity_floor"]
        assert row["worker_units"] < cfg["max_mean_worker_units"]


def test_b_cross_billing_ops_multi_intact_chunks() -> None:
    """Cross-topic query should hit multiple gold ids and clear the billing recall floor."""
    report = _load_report()
    cfg = _parse_cfg()
    batches_path = APP / "data" / "batches_default.jsonl"
    gold_ids = _gold_ids_for("b_cross_billing_ops", batches_path)
    row = next(r for r in report["batches"] if r["batch_id"] == "b_cross_billing_ops")
    assert row["intact_chunks"] >= cfg["billing_pack_min_intact"]
    assert row["cosine_fidelity"] >= cfg["billing_pack_min_fidelity"]
    assert row["cosine_fidelity"] == pytest.approx(
        row["intact_chunks"] / len(gold_ids),
        abs=2e-4,
    )


def test_fixture_pack_failover_recall() -> None:
    """Failover fixture pack clears per-row failover recall floor."""
    pack = ACTIVE_PACKS / "pack_failover"
    out = APP / "output" / "bench_pack_failover.json"
    cfg = _parse_cfg()
    queries = _fixture_batches_path(pack)
    _labelsync(pack / "corpus.json", pack / "batch_specs.jsonl", queries)
    _run_bench(queries, out, pack / "corpus.json")
    report = _load_report(out)
    assert report["status"] == "ok"
    for row in report["batches"]:
        assert row["cosine_fidelity"] >= cfg["failover_fidelity_floor"]


def test_fixture_pack_skew_queries_recall() -> None:
    """Skew query pack clears mean recall floor."""
    pack = ACTIVE_PACKS / "pack_skew_queries"
    out = APP / "output" / "bench_pack_skew.json"
    cfg = _parse_cfg()
    queries = _fixture_batches_path(pack)
    _labelsync(pack / "corpus.json", pack / "batch_specs.jsonl", queries)
    _run_bench(queries, out, pack / "corpus.json")
    report = _load_report(out)
    assert report["status"] == "ok"
    assert report["mean_cosine_fidelity"] >= cfg["fidelity_floor"]


def test_goldgen_query_prep_required_for_recall() -> None:
    """Gold labels must use the same stopword preparation as the bench driver."""
    cfg = _parse_cfg()
    probe_query = "the billing refund chargeback dispute"
    probe_spec = APP / "output" / "probe_prep_spec.jsonl"
    probe_queries = APP / "output" / "probe_prep_batches.jsonl"
    probe_mismatch = APP / "output" / "probe_prep_queries_mismatch.jsonl"
    probe_out = APP / "output" / "bench_goldgen_prep_ablation.json"
    probe_out_mismatch = APP / "output" / "bench_goldgen_prep_mismatch.json"
    probe_spec.write_text(
        json.dumps(
            {
                "batch_id": "q_prep_probe",
                "query": probe_query,
                "dead_workers": [],
            }
        )
        + "\n",
        encoding="utf-8",
    )
    corpus = APP / "data" / "corpus_default.json"
    dim = int(cfg["vector_dim"])
    top_k = int(cfg["top_k"])

    expected_prep_gold = _reference_top_gold_ids(
        corpus,
        probe_query,
        use_prep=True,
        dim=dim,
        top_k=top_k,
    )
    expected_raw_gold = _reference_top_gold_ids(
        corpus,
        probe_query,
        use_prep=False,
        dim=dim,
        top_k=top_k,
    )
    assert expected_prep_gold != expected_raw_gold

    _labelsync(corpus, probe_spec, probe_queries)
    generated = json.loads(
        probe_queries.read_text(encoding="utf-8").strip().splitlines()[0]
    )
    assert generated["gold_ids"] == expected_prep_gold

    mismatch_row = {
        "batch_id": "q_prep_probe",
        "query": probe_query,
        "gold_ids": expected_raw_gold,
        "dead_workers": [],
    }
    probe_mismatch.write_text(
        json.dumps(mismatch_row) + "\n",
        encoding="utf-8",
    )

    _run_bench(probe_queries, probe_out)
    aligned = next(
        row
        for row in _load_report(probe_out)["batches"]
        if row["batch_id"] == "q_prep_probe"
    )
    _run_bench(probe_mismatch, probe_out_mismatch)
    mismatched = next(
        row
        for row in _load_report(probe_out_mismatch)["batches"]
        if row["batch_id"] == "q_prep_probe"
    )
    assert float(aligned["cosine_fidelity"]) >= 0.8
    assert float(aligned["cosine_fidelity"]) > float(mismatched["cosine_fidelity"]) + 0.05


def test_fixture_pack_multi_dead_recall() -> None:
    """Multi-dead fixture pack clears failover recall on every row."""
    pack = ACTIVE_PACKS / "pack_multi_dead"
    out = APP / "output" / "bench_pack_multi_dead.json"
    cfg = _parse_cfg()
    queries = _fixture_batches_path(pack)
    _labelsync(pack / "corpus.json", pack / "batch_specs.jsonl", queries)
    _run_bench(queries, out, pack / "corpus.json")
    report = _load_report(out)
    assert report["status"] == "ok"
    for row in report["batches"]:
        assert row["cosine_fidelity"] >= cfg["failover_fidelity_floor"]


def test_fixture_pack_tight_recall_security_row() -> None:
    """Tight recall bundle clears security-query recall floor."""
    pack = ACTIVE_PACKS / "pack_tight_recall"
    out = APP / "output" / "bench_pack_tight.json"
    cfg = _parse_cfg()
    queries = _fixture_batches_path(pack)
    _labelsync(pack / "corpus.json", pack / "batch_specs.jsonl", queries)
    _run_bench(queries, out, pack / "corpus.json")
    report = _load_report(out)
    assert report["status"] == "ok"
    sec = next(r for r in report["batches"] if r["batch_id"] == "b_tight_security")
    assert sec["cosine_fidelity"] >= cfg["tight_pack_fidelity_floor"]


def test_broken_fan_ablation_fails_failover() -> None:
    """Worker-imbalance fan-out (single live worker) must fail failover batches."""
    fan_src = APP / "coord" / "c1_fan.go"
    backup = fan_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "broken_c1_fan.go").read_text(encoding="utf-8")
    out = APP / "output" / "bench_ablation_fan.json"
    cfg = _parse_cfg()
    try:
        fan_src.write_text(broken, encoding="utf-8")
        _run_bench(APP / "data" / "batches_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        fail_rows = [r for r in report["batches"] if r["batch_id"].startswith("b_failover")]
        assert any(r["cosine_fidelity"] < cfg["failover_fidelity_floor"] for r in fail_rows)
    finally:
        fan_src.write_text(backup, encoding="utf-8")
        _rebuild_benchd()
        _run_bench(APP / "data" / "batches_default.jsonl")


def test_broken_rank_ablation_fails_recall() -> None:
    """Ascending half-dimension ranker cannot clear recall floor."""
    rank_src = APP / "lane" / "l2_rank.go"
    backup = rank_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "broken_l2_rank.go").read_text(encoding="utf-8")
    out = APP / "output" / "bench_ablation_rank.json"
    cfg = _parse_cfg()
    try:
        rank_src.write_text(broken, encoding="utf-8")
        _run_bench(APP / "data" / "batches_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        assert report["mean_cosine_fidelity"] < cfg["fidelity_floor"] or report["status"] == "fail"
    finally:
        rank_src.write_text(backup, encoding="utf-8")
        _rebuild_benchd()
        _run_bench(APP / "data" / "batches_default.jsonl")


def test_broken_bank_ablation_fails_recall() -> None:
    """Corrupted partial row decode must collapse cosine fidelity on billing batches."""
    bank_src = APP / "codec" / "c0_bank.go"
    backup = bank_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "broken_c0_bank.go").read_text(encoding="utf-8")
    out = APP / "output" / "bench_ablation_bank.json"
    cfg = _parse_cfg()
    try:
        bank_src.write_text(broken, encoding="utf-8")
        _run_bench(APP / "data" / "batches_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        row = next(r for r in report["batches"] if r["batch_id"] == "b_billing_refund")
        assert row["cosine_fidelity"] < cfg["billing_pack_min_fidelity"]
    finally:
        bank_src.write_text(backup, encoding="utf-8")
        _rebuild_benchd()
        _run_bench(APP / "data" / "batches_default.jsonl")


def test_broken_join_ablation_fails_cross_topic() -> None:
    """Serialization merge ordering bug must break cross-topic intact chunk recovery."""
    join_src = APP / "coord" / "c2_join.go"
    backup = join_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "broken_c2_join.go").read_text(encoding="utf-8")
    out = APP / "output" / "bench_ablation_join.json"
    cfg = _parse_cfg()
    try:
        join_src.write_text(broken, encoding="utf-8")
        _run_bench(APP / "data" / "batches_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        row = next(r for r in report["batches"] if r["batch_id"] == "b_cross_billing_ops")
        assert row["cosine_fidelity"] < cfg["billing_pack_min_fidelity"]
    finally:
        join_src.write_text(backup, encoding="utf-8")
        _rebuild_benchd()
        _run_bench(APP / "data" / "batches_default.jsonl")


def test_broken_cost_ablation_exceeds_unit_caps() -> None:
    """Dead-worker penalty tally blows p95 batch units above pipeline.toml ceiling."""
    cost_src = APP / "node" / "n9_cost.go"
    backup = cost_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "broken_n9_cost.go").read_text(encoding="utf-8")
    out = APP / "output" / "bench_ablation_cost.json"
    cfg = _parse_cfg()
    try:
        cost_src.write_text(broken, encoding="utf-8")
        _run_bench(APP / "data" / "batches_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        assert report["p95_batch_units"] > cfg["max_p95_batch_units"] or report["status"] == "fail"
    finally:
        cost_src.write_text(backup, encoding="utf-8")
        _rebuild_benchd()
        _run_bench(APP / "data" / "batches_default.jsonl")


def test_broken_route_ablation_fails_mean_recall() -> None:
    """Pinning every document to partition zero cannot clear multi-dead failover recall."""
    route_src = APP / "lane" / "s1_store.go"
    backup = route_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "broken_s1_store.go").read_text(encoding="utf-8")
    out = APP / "output" / "bench_ablation_route.json"
    cfg = _parse_cfg()
    try:
        route_src.write_text(broken, encoding="utf-8")
        _labelsync(
            APP / "data" / "corpus_default.json",
            APP / "data" / "batch_specs.jsonl",
            APP / "data" / "batches_default.jsonl",
        )
        _run_bench(APP / "data" / "batches_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        multi = next(r for r in report["batches"] if r["batch_id"] == "b_failover_multi")
        assert multi["cosine_fidelity"] < cfg["failover_fidelity_floor"]
    finally:
        route_src.write_text(backup, encoding="utf-8")
        _labelsync(
            APP / "data" / "corpus_default.json",
            APP / "data" / "batch_specs.jsonl",
            APP / "data" / "batches_default.jsonl",
        )
        _rebuild_benchd()
        _run_bench(APP / "data" / "batches_default.jsonl")


def test_broken_prune_ablation_fails_failover() -> None:
    """Keeping only one hit per partition cannot clear failover recall floors."""
    prune_src = APP / "lane" / "l3_prune.go"
    backup = prune_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "broken_l3_prune.go").read_text(encoding="utf-8")
    out = APP / "output" / "bench_ablation_prune.json"
    cfg = _parse_cfg()
    try:
        prune_src.write_text(broken, encoding="utf-8")
        _run_bench(APP / "data" / "batches_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        fail_rows = [r for r in report["batches"] if r["batch_id"].startswith("b_failover")]
        assert any(r["cosine_fidelity"] < cfg["failover_fidelity_floor"] for r in fail_rows)
    finally:
        prune_src.write_text(backup, encoding="utf-8")
        _rebuild_benchd()
        _run_bench(APP / "data" / "batches_default.jsonl")


def test_mean_balance_score_floor() -> None:
    """mean_balance_score must clear balance_floor from pipeline.toml."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["mean_balance_score"] >= cfg["balance_floor"]


def test_mean_reject_rate_zero_on_default() -> None:
    """Clean default bundle keeps rejects_bad at zero on every batch row."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["mean_reject_rate"] <= cfg["max_mean_reject_rate"]
    for row in report["batches"]:
        assert row["rejects_bad"] == 0


def test_corrupted_packed_row_rejects_before_merge() -> None:
    """Mutated packed bytes that no longer match Sig must reject before merge."""
    batches_path = APP / "data" / "batches_default.jsonl"
    corrupt_id = _gold_ids_for("b_billing_refund", batches_path)[0]
    drive_src = APP / "bench" / "b5_drive.go"
    backup = drive_src.read_text(encoding="utf-8")
    hook = (
        "\t\trow := codec.VkStore(doc.ID, vec)\n"
        f'\t\tif doc.ID == "{corrupt_id}" && len(row.Raw) > 0 {{\n'
        "\t\t\trow.Raw[0] ^= 0xff\n"
        "\t\t}\n"
        "\t\tlanes[sid].Rows = append(lanes[sid].Rows, row)"
    )
    needle = "\t\tlanes[sid].Rows = append(lanes[sid].Rows, codec.VkStore(doc.ID, vec))"
    patched = backup.replace(needle, hook)
    assert patched != backup, "BuildLanes pack hook site missing"
    out = APP / "output" / "bench_corrupt_sig.json"
    try:
        drive_src.write_text(patched, encoding="utf-8")
        _rebuild_benchd()
        if out.exists():
            out.unlink()
        subprocess.run(
            [RUNNER.as_posix(), batches_path.as_posix(), out.as_posix()],
            cwd=APP,
            check=True,
            capture_output=True,
            text=True,
        )
        report = _load_report(out)
        row = next(r for r in report["batches"] if r["batch_id"] == "b_billing_refund")
        assert row["rejects_bad"] > 0
        assert corrupt_id not in row["chunk_ids"]
    finally:
        drive_src.write_text(backup, encoding="utf-8")
        _rebuild_benchd()
        _run_bench(APP / "data" / "batches_default.jsonl")


def test_b_balance_spread_uses_all_workers() -> None:
    """b_balance_spread must fan out to every live worker with a strong balance score."""
    report = _load_report()
    cfg = _parse_cfg()
    row = next(r for r in report["batches"] if r["batch_id"] == "b_balance_spread")
    assert row["workers_active"] == cfg["worker_count"]
    assert row["balance_score"] >= cfg["balance_floor"]


def test_broken_integr_ablation_rejects_all() -> None:
    """Dropping every partial before merge must collapse billing fidelity."""
    integr_src = APP / "lane" / "w4_integr.go"
    backup = integr_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "broken_w4_integr.go").read_text(encoding="utf-8")
    out = APP / "output" / "bench_ablation_integr.json"
    cfg = _parse_cfg()
    try:
        integr_src.write_text(broken, encoding="utf-8")
        _run_bench(APP / "data" / "batches_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        row = next(r for r in report["batches"] if r["batch_id"] == "b_billing_refund")
        assert row["cosine_fidelity"] < cfg["billing_pack_min_fidelity"]
    finally:
        integr_src.write_text(backup, encoding="utf-8")
        _rebuild_benchd()
        _run_bench(APP / "data" / "batches_default.jsonl")


def test_broken_balance_ablation_fails_status() -> None:
    """Flat balance scoring must fail balance_floor even when recall recovers."""
    balance_src = APP / "coord" / "s5_balance.go"
    backup = balance_src.read_text(encoding="utf-8")
    broken = 'package coord\n\nfunc BxScore(perWorker []int) float64 {\n\t_ = perWorker\n\treturn 0.35\n}\n'
    out = APP / "output" / "bench_ablation_balance.json"
    cfg = _parse_cfg()
    try:
        balance_src.write_text(broken, encoding="utf-8")
        _run_bench(APP / "data" / "batches_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        assert report["mean_balance_score"] < cfg["balance_floor"] or report["status"] == "fail"
    finally:
        balance_src.write_text(backup, encoding="utf-8")
        _rebuild_benchd()
        _run_bench(APP / "data" / "batches_default.jsonl")
