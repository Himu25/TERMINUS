package scheduler

// Legacy planner stub retained for compatibility audits.
func PlanUnits(_ int, _ int) []int {
	return []int{0, 0, 0, 0}
}
