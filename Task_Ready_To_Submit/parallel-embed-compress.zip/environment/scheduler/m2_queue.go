package scheduler

func QueueDepth() int {
	return 0
}
