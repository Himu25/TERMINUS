package lane

import "pembed.lab/pkg/types"

func WxShadow(partials [][]types.PartialHit, _ []Lane) [][]types.PartialHit {
	return partials
}
