package corpus

import (
	"encoding/json"
	"os"

	"pembed.lab/pkg/types"
)

const DefaultCorpusPath = "/app/data/corpus_default.json"

func Load(path string) ([]types.Doc, error) {
	if path == "" {
		path = DefaultCorpusPath
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var pack types.Corpus
	if err := json.Unmarshal(raw, &pack); err != nil {
		return nil, err
	}
	return pack.Vectors, nil
}
