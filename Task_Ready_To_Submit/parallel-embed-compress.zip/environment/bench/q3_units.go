package bench

import (
	"pembed.lab/lane"
	"pembed.lab/node"
)

func ProbeUnits(lanes []lane.Lane, dim int, dead []int) int {
	return node.NxTally(lanes, dim, dead)
}
