package bench

import (
	"pembed.lab/coord"
	"pembed.lab/pkg/types"
)

func FoldTopK(partials [][]types.PartialHit, topK int) ([]types.PartialHit, int) {
	return coord.JxFold(partials, topK)
}
