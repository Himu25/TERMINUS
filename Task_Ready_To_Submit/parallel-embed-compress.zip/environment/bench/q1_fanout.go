package bench

import (
	"pembed.lab/coord"
	"pembed.lab/lane"
	"pembed.lab/pkg/types"
)

func FanoutPartials(query []float64, lanes []lane.Lane, dead []int, topK int) [][]types.PartialHit {
	live := coord.LxPick(lanes, dead)
	partials := make([][]types.PartialHit, 0, len(live))
	for _, ln := range live {
		partials = append(partials, lane.PxScan(query, ln, topK))
	}
	return partials
}
