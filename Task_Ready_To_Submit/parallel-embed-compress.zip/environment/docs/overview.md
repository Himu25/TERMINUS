Shard-topk relay lab models a coordinator fan-out to embedding shards.

Bench driver rebuilds gold ids then runs distributed search.
