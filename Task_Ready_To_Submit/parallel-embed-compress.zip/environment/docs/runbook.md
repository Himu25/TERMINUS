Rebuild benchd after Go changes. Regenerate queries jsonl when corpus or specs change.

Run /app/tools/run_bench with query jsonl and output path.
