module pembed.lab

go 1.22
