package types

type Doc struct {
	ID   string `json:"id"`
	Text string `json:"text"`
}

type Corpus struct {
	Vectors []Doc `json:"vectors"`
}

type BatchCase struct {
	BatchID    string   `json:"batch_id"`
	Query      string   `json:"query"`
	GoldIDs    []string `json:"gold_ids,omitempty"`
	DeadWorkers []int    `json:"dead_workers,omitempty"`
}

type BatchRow struct {
	BatchID        string   `json:"batch_id"`
	CosineFidelity float64  `json:"cosine_fidelity"`
	CompressRatio  float64  `json:"compress_ratio"`
	IntactChunks   int      `json:"intact_chunks"`
	WorkerUnits    int      `json:"worker_units"`
	SyncUnits      int      `json:"sync_units"`
	BatchUnits     int      `json:"batch_units"`
	WorkersActive  int      `json:"workers_active"`
	RejectsBad     int      `json:"rejects_bad"`
	BalanceScore   float64  `json:"balance_score"`
	ChunkIDs       []string `json:"chunk_ids"`
}

type BenchReport struct {
	Status         string     `json:"status"`
	CorpusVectors  int        `json:"corpus_vectors"`
	VectorDim      int        `json:"vector_dim"`
	WorkerCount     int        `json:"worker_count"`
	BatchesTotal   int        `json:"batches_total"`
	MeanCosineFidelity float64    `json:"mean_cosine_fidelity"`
	MeanCompressRatio   float64    `json:"mean_compress_ratio"`
	MeanWorkerUnits float64    `json:"mean_worker_units"`
	MeanSyncUnits     float64    `json:"mean_sync_units"`
	P95BatchUnits     int        `json:"p95_batch_units"`
	MeanBalanceScore  float64    `json:"mean_balance_score"`
	MeanRejectRate    float64    `json:"mean_reject_rate"`
	ReportDigest      string     `json:"report_digest"`
	Batches           []BatchRow `json:"batches"`
}

type ClusterCfg struct {
	VectorDim              int
	WorkerCount             int
	TopK                   int
	RecallFloor            float64
	NdcgFloor              float64
	MaxMeanWorkerUnits      int
	MaxMeanSyncUnits      int
	MaxP95BatchUnits       int
	FailoverRecallFloor    float64
	TightSecurityRecall    float64
	BalanceFloor           float64
	MaxMeanRejectRate      float64
	CorpusPath             string
}

type PartialHit struct {
	DocID string
	Score float64
	Shard int
}
