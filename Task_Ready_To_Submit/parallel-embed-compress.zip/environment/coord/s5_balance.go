package coord

func BxScore(perWorker []int) float64 {
	_ = perWorker
	return 0.35
}
