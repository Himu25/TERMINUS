package coord

import "pembed.lab/lane"

func LxPick(lanes []lane.Lane, dead []int) []lane.Lane {
	deadSet := make(map[int]struct{}, len(dead))
	for _, d := range dead {
		deadSet[d] = struct{}{}
	}
	out := make([]lane.Lane, 0, 1)
	for _, lane := range lanes {
		if _, off := deadSet[lane.ShardID]; off {
			continue
		}
		out = append(out, lane)
		break
	}
	return out
}
