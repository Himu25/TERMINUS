package codec

// Legacy unpack path kept for migration diffs only.
func LegacyOpen(r Row) []float64 {
	return r.Open()
}
