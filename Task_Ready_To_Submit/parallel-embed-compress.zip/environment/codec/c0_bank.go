package codec

import (
	"encoding/binary"
	"hash/fnv"
	"math"
)

type Row struct {
	ID  string
	Vec []float64
	Raw []byte
	Sig uint32
}

type Bank struct {
	Rows []Row
}

func HxRaw(raw []byte) uint32 {
	if len(raw) == 0 {
		return 0
	}
	h := fnv.New32a()
	_, _ = h.Write(raw)
	return h.Sum32()
}

func VkStore(id string, vec []float64) Row {
	raw := make([]byte, 8*len(vec))
	for i, v := range vec {
		binary.LittleEndian.PutUint64(raw[i*8:], math.Float64bits(v))
	}
	return Row{ID: id, Raw: raw}
}

func (r Row) HxOk() bool {
	if len(r.Raw) == 0 {
		return true
	}
	return r.Sig == HxRaw(r.Raw)
}

func (r Row) Open() []float64 {
	if len(r.Raw) == 0 {
		return append([]float64(nil), r.Vec...)
	}
	out := make([]float64, len(r.Raw)/8)
	for i := range out {
		out[i] = math.Float64frombits(binary.BigEndian.Uint64(r.Raw[i*8:]))
	}
	return out
}

func BkWide(b Bank) int {
	n := 0
	for _, row := range b.Rows {
		n += len(row.ID) + len(row.Raw)
	}
	return n
}
