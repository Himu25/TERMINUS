#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight: parallel embedding compression workspace"
require_file /app/go.mod
require_file /app/config/pipeline.toml
require_file /app/config/stopwords.txt
require_file /app/data/corpus_default.json
require_file /app/data/batch_specs.jsonl
require_file /app/registry/shard_manifest.json
mkdir -p /app/bin /app/output

log "restore little-endian packed row decode"
cp "${ROOT_DIR}/oracle/c0_bank.go" /app/codec/c0_bank.go

log "restore stable document-to-partition routing"
cp "${ROOT_DIR}/oracle/s1_store.go" /app/lane/s1_store.go

log "install multi-partition fan-out picker"
cp "${ROOT_DIR}/oracle/c1_fan.go" /app/coord/c1_fan.go

log "install per-partition partial ranker"
cp "${ROOT_DIR}/oracle/l2_rank.go" /app/lane/l2_rank.go

log "restore full partial lists before global merge"
cp "${ROOT_DIR}/oracle/l3_prune.go" /app/lane/l3_prune.go

log "install global merge stage"
cp "${ROOT_DIR}/oracle/c2_join.go" /app/coord/c2_join.go

log "install synthetic probe unit tally"
cp "${ROOT_DIR}/oracle/n9_cost.go" /app/node/n9_cost.go

log "enable partial chunk signature gate before merge"
cp "${ROOT_DIR}/oracle/w4_integr.go" /app/lane/w4_integr.go

log "install worker load-balance scoring"
cp "${ROOT_DIR}/oracle/s5_balance.go" /app/coord/s5_balance.go

log "align gold regeneration with bench query preparation"
cp "${ROOT_DIR}/oracle/refgen_main.go" /app/cmd/refgen/main.go

log "verify patched sources compile before gold regeneration"
go build -o /app/bin/refgen ./cmd/refgen

log "regenerate query gold ids with repaired distributed search path"
/app/bin/refgen /app/data/corpus_default.json /app/data/batch_specs.jsonl /app/data/batches_default.jsonl

log "rebuild bench driver and emit default search bench report"
go build -o /app/bin/benchd ./cmd/benchd
chmod +x /app/tools/run_bench
/app/tools/run_bench /app/data/batches_default.jsonl /app/output/compress_bench.json

log "post-run validation against pipeline.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/pipeline.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k.endswith("_floor") or k.startswith("billing_"):
        cfg[k] = float(v)
    elif k.startswith("max_"):
        cfg[k] = int(float(v))

manifest = json.loads(Path("/app/registry/shard_manifest.json").read_text())
pack_path = Path("/app/data/batches_default.jsonl")
pack_order = [
    json.loads(line)["batch_id"]
    for line in pack_path.read_text().splitlines()
    if line.strip()
]

report = json.loads(Path("/app/output/compress_bench.json").read_text())
assert report["status"] == "ok", report
assert report["corpus_vectors"] == manifest["count"]
assert report["vector_dim"] == manifest["dim"]
assert report["worker_count"] == manifest["shards"]
assert report["batches_total"] == len(pack_order)
assert [row["batch_id"] for row in report["batches"]] == pack_order
assert report["mean_cosine_fidelity"] >= cfg["fidelity_floor"]
assert report["mean_balance_score"] >= cfg["balance_floor"]
assert report["mean_reject_rate"] <= cfg["max_mean_reject_rate"]
assert report["p95_batch_units"] <= cfg["max_p95_batch_units"]

bill = next(q for q in report["batches"] if q["batch_id"] == "b_billing_refund")
assert bill["intact_chunks"] >= int(cfg["billing_pack_min_intact"])
assert bill["cosine_fidelity"] >= cfg["billing_pack_min_fidelity"]

skew = next(q for q in report["batches"] if q["batch_id"] == "b_latency_skew")
assert skew["cosine_fidelity"] >= cfg["skew_balance_min_fidelity"]

fail = [q for q in report["batches"] if q["batch_id"].startswith("b_failover")]
for row in fail:
    assert row["cosine_fidelity"] >= cfg["failover_fidelity_floor"], row
print("ok", report["mean_cosine_fidelity"], report["p95_batch_units"], len(fail))
PY

log "oracle complete"
