package lane

import (
	"hash/fnv"

	"pembed.lab/codec"
)

type Lane struct {
	ShardID int
	Rows    []codec.Row
}

func MkLanes(shardCount int) []Lane {
	lanes := make([]Lane, shardCount)
	for i := range lanes {
		lanes[i].ShardID = i
	}
	return lanes
}

func ShMap(id string, shardCount int) int {
	if shardCount <= 0 {
		return 0
	}
	h := fnv.New32a()
	_, _ = h.Write([]byte(id))
	return int(h.Sum32() % uint32(shardCount))
}
