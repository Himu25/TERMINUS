package coord

import (
	"sort"

	"pembed.lab/lane"
	"pembed.lab/pkg/types"
)

func MxFold(partials [][]types.PartialHit, topK int) []types.PartialHit {
	best := make(map[string]types.PartialHit)
	for _, block := range partials {
		for _, hit := range block {
			cur, ok := best[hit.DocID]
			if !ok || hit.Score > cur.Score {
				best[hit.DocID] = hit
			}
		}
	}
	flat := make([]types.PartialHit, 0, len(best))
	for _, hit := range best {
		flat = append(flat, hit)
	}
	sort.Slice(flat, func(i, j int) bool {
		if flat[i].Score == flat[j].Score {
			return flat[i].DocID < flat[j].DocID
		}
		return flat[i].Score > flat[j].Score
	})
	if topK <= 0 || topK > len(flat) {
		topK = len(flat)
	}
	return flat[:topK]
}

func R4Weight(partials [][]types.PartialHit, topK int) int {
	if len(partials) == 0 {
		return 0
	}
	return topK * (len(partials) + 1)
}

func MxSpan(partials [][]types.PartialHit) int {
	n := 0
	for _, block := range partials {
		n += len(block)
	}
	return n
}

func JxFold(partials [][]types.PartialHit, topK int) ([]types.PartialHit, int) {
	weight := R4Weight(partials, topK)
	pruned := lane.TxPrune(partials, topK)
	merged := MxFold(pruned, topK)
	return merged, weight
}
