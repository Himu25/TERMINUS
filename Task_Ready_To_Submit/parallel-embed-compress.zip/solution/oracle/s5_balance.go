package coord

import "math"

func BxScore(perWorker []int) float64 {
	if len(perWorker) == 0 {
		return 0
	}
	active := make([]int, 0, len(perWorker))
	for _, u := range perWorker {
		if u > 0 {
			active = append(active, u)
		}
	}
	if len(active) == 0 {
		return 0
	}
	var sum float64
	for _, u := range active {
		sum += float64(u)
	}
	mean := sum / float64(len(active))
	if mean <= 0 {
		return 0
	}
	var varSum float64
	for _, u := range active {
		d := float64(u) - mean
		varSum += d * d
	}
	cv := math.Sqrt(varSum/float64(len(active))) / mean
	score := 1.0 - cv
	if score < 0 {
		return 0
	}
	return math.Round(score*10000) / 10000
}
