package lane

import (
	"pembed.lab/codec"
	"pembed.lab/pkg/types"
)

func rowIndex(lanes []Lane) map[string]codec.Row {
	out := make(map[string]codec.Row)
	for _, ln := range lanes {
		for _, row := range ln.Rows {
			out[row.ID] = row
		}
	}
	return out
}

func WxGate(partials [][]types.PartialHit, lanes []Lane) ([][]types.PartialHit, int) {
	lookup := rowIndex(lanes)
	rejects := 0
	out := make([][]types.PartialHit, 0, len(partials))
	for _, block := range partials {
		kept := make([]types.PartialHit, 0, len(block))
		for _, hit := range block {
			row, ok := lookup[hit.DocID]
			if !ok || !row.HxOk() {
				rejects++
				continue
			}
			kept = append(kept, hit)
		}
		out = append(out, kept)
	}
	return out, rejects
}
