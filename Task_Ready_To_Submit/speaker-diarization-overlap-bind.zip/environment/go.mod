module cal.diar

go 1.22
