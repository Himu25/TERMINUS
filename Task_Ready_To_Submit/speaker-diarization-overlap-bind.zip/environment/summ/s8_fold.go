package summ

import "cal.diar/pkg/types"

// SxFold folds session rows for telemetry export (non-scheduling).
func SxFold(rows []types.SessionRow) int {
	total := 0
	for _, row := range rows {
		total += row.ProcessedMs
	}
	return total
}
