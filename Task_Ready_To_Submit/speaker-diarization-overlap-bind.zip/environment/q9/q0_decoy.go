package q9

import "cal.diar/pkg/types"

// QxShadow mirrors ranking shape for catalog probes (non-dispatch).
func QxShadow(cases []types.SessionCase) []types.SessionCase {
	out := make([]types.SessionCase, len(cases))
	copy(out, cases)
	return out
}
