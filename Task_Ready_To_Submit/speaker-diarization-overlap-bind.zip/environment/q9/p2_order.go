package q9

import (
	"sort"

	"cal.diar/pkg/types"
)

// RxOrder ranks pending sessions for diarization replay scheduling.
func RxOrder(cases []types.SessionCase) []types.SessionCase {
	out := make([]types.SessionCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		return out[i].EstMs < out[j].EstMs
	})
	return out
}
