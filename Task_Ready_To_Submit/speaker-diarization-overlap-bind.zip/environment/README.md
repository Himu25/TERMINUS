Call-analytics diarization replay lab. Bundled session tapes live in `/app/data/session_manifest.jsonl`. See `/app/docs/architecture.md`.
