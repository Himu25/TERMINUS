# Diar report contract

Top-level fields:
- status: ok when all analytics.toml guardrails pass, else fail
- frame_budget_ms: total frame budget for the replay window
- frames_allocated_ms: billable duration consumed by bound sessions
- frames_slack_ms: reservation surplus summed across sessions
- sessions_total: input JSONL row count
- sessions_bound: sessions marked served
- coverage_rate: sessions_bound / sessions_total
- slack_ratio: frames_slack_ms / frames_allocated_ms when allocated > 0
- binding_violations: turn-binding dependency faults
- turn_inversions: scheduling-order faults among finished sessions
- overlap_buffer_ms: overlap-wave buffer duration absorbed
- cluster_stability_score: weighted bind score total for finished sessions
- report_digest: SHA-256 hex of compact pre-digest JSON with report_digest empty
- sessions: per-session rows

Per-session row fields: session_id, cluster, urgency, reserve_ms, processed_ms, slack_ms, served, bind_ready, turn_rank, overlap_wave, cluster_stability_score.
