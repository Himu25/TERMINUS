Speaker diarization replay ties together a Go session ledger, Rust frame-score integrator, and bash runners under `/app`.
The driver reads session manifests from `/app/data`, score-band profiles, and frame logs before emitting the diar report.
