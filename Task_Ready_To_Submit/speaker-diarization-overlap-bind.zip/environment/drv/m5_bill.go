package drv

import (
	"cal.diar/n8"
	"cal.diar/pkg/types"
	"cal.diar/z1"
)

func levelBillable(jc types.SessionCase, levelReadingVal int, rp types.ScoreBand) int {
	dryScale := rp.HeadScale
	wetScale := rp.TailScale
	wetAfter := rp.TailAfter
	if levelReadingVal > 0 {
		dryScale, wetScale, wetAfter = 100, 100, 0
	}
	roll := n8.FrameSpan(
		jc.EstMs, jc.ActMs, levelReadingVal,
		dryScale, wetScale, wetAfter, jc.FrameSlot,
	)
	if roll.Billable > 0 {
		return roll.Billable
	}
	return jc.EstMs
}

func sessionSurplus(reserved, used int) int {
	return z1.VxRoll(reserved, used)
}
