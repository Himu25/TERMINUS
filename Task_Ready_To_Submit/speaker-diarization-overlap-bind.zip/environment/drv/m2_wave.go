package drv

import "cal.diar/h4"

func overlapDispatchTotal(dispatchWave, estTons, headroom int) int {
	if dispatchWave <= 0 {
		return 0
	}
	return h4.UxAbsorb(estTons/4, headroom)
}
