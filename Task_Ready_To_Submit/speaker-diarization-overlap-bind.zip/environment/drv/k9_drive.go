package drv

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"

	"cal.diar/k2"
	"cal.diar/pkg/types"
	"cal.diar/q9"
	"cal.diar/summ"
	"cal.diar/u3"
)

func LoadCfg(path string) (types.AnalyticsCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.AnalyticsCfg{}, err
	}
	cfg := types.AnalyticsCfg{
		FrameBudgetMs:     12000,
		MinCoverageRate:     0.75,
		MaxSlackRatio:         0.35,
		MaxBindingViolations:      0,
		MaxTurnInversions: 1,
		MinOverlapBufferMs:      3,
		MinClusterStabilityScore:     2.0,
		ClusterWeights:           map[string]float64{"cluster_alpha": 1.0, "cluster_beta": 1.0, "cluster_gamma": 1.0},
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "frame_budget_ms":
			fmt.Sscanf(val, "%d", &cfg.FrameBudgetMs)
		case "min_coverage_rate":
			fmt.Sscanf(val, "%f", &cfg.MinCoverageRate)
		case "max_slack_ratio":
			fmt.Sscanf(val, "%f", &cfg.MaxSlackRatio)
		case "max_binding_violations":
			fmt.Sscanf(val, "%d", &cfg.MaxBindingViolations)
		case "max_turn_inversions":
			fmt.Sscanf(val, "%d", &cfg.MaxTurnInversions)
		case "min_overlap_buffer_ms":
			fmt.Sscanf(val, "%d", &cfg.MinOverlapBufferMs)
		case "min_cluster_stability_score":
			fmt.Sscanf(val, "%f", &cfg.MinClusterStabilityScore)
		case "cluster_weight_alpha":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClusterWeights["cluster_alpha"] = w
		case "cluster_weight_beta":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClusterWeights["cluster_beta"] = w
		case "cluster_weight_gamma":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.ClusterWeights["cluster_gamma"] = w
		}
	}
	return cfg, nil
}

func LoadScoreBands(path string) (map[string]types.ScoreBand, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]types.ScoreBand)
	for i, row := range rows {
		if i == 0 || len(row) < 4 {
			continue
		}
		var peak, renew, after int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &peak)
		fmt.Sscanf(strings.TrimSpace(row[2]), "%d", &renew)
		fmt.Sscanf(strings.TrimSpace(row[3]), "%d", &after)
		id := strings.TrimSpace(row[0])
		out[id] = types.ScoreBand{
			ScoreBandID: id,
			HeadScale:  peak,
			TailScale: renew,
			TailAfter: after,
		}
	}
	return out, nil
}

func LoadSessionCases(path string) ([]types.SessionCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.SessionCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var jc types.SessionCase
		if err := json.Unmarshal([]byte(line), &jc); err != nil {
			return nil, err
		}
		if jc.ScoreBandID == "" {
			jc.ScoreBandID = "lower_pool"
		}
		out = append(out, jc)
	}
	return out, sc.Err()
}

func LoadLevelLog(path string) (map[string]int, error) {
	f, err := os.Open(path)
	if err != nil {
		return map[string]int{}, nil
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]int)
	for i, row := range rows {
		if i == 0 || len(row) < 2 {
			continue
		}
		var actTons int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &actTons)
		out[strings.TrimSpace(row[0])] = actTons
	}
	return out, nil
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

func levelBandFor(jc types.SessionCase, levelBands map[string]types.ScoreBand) types.ScoreBand {
	if rp, ok := levelBands[jc.ScoreBandID]; ok {
		return rp
	}
	return types.ScoreBand{ScoreBandID: jc.ScoreBandID, HeadScale: 100, TailScale: 100, TailAfter: 0}
}

func Run(cfg types.AnalyticsCfg, cases []types.SessionCase, levelReadings map[string]int, levelBands map[string]types.ScoreBand) (types.DiarReport, error) {
	ordered := q9.RxOrder(cases)
	report := types.DiarReport{
		Status:            "ok",
		FrameBudgetMs: cfg.FrameBudgetMs,
		SessionsTotal:         len(ordered),
	}
	done := make(map[string]bool)
	budgetLeft := cfg.FrameBudgetMs
	var spent, totalWaste, completed, depViol, inversions, renewTotal int
	var valueTotal float64
	prevRank := -1
	report.Sessions = make([]types.SessionRow, 0, len(ordered))

	for idx, jc := range ordered {
		actualReady := true
		for _, depID := range jc.BindDeps {
			if !done[depID] {
				actualReady = false
				break
			}
		}
		depReady := k2.TxHold(jc.BindDeps, done)
		if len(jc.BindDeps) > 0 && !actualReady && depReady {
			depViol++
		}
		levelReadingVal := 0
		if act, ok := levelReadings[jc.SessionID]; ok && act > 0 {
			levelReadingVal = act
			jc.ActMs = act
		}
		rp := levelBandFor(jc, levelBands)
		billable := levelBillable(jc, levelReadingVal, rp)
		reserveNeed := u3.AxNeed(jc.EstMs, billable)
		reserved, ok := u3.BxReserve(budgetLeft, reserveNeed)
		headroom := budgetLeft - reserved
		if jc.OverlapWave > 0 {
			renewTotal += overlapDispatchTotal(jc.OverlapWave, jc.EstMs, headroom)
		}
		used := 0
		finished := false
		if ok && depReady {
			used = jc.ActMs
			if used <= 0 {
				used = billable
			}
			if used > reserved {
				used = reserved
			}
			budgetLeft -= reserved
			spent += used
			finished = true
			completed++
			done[jc.SessionID] = true
			valueTotal += u3.VxValue(jc.BindWeight, used)
		}
		wasteAmt := sessionSurplus(reserved, used)
		totalWaste += wasteAmt
		rankScore := jc.TapeRevision*10 + jc.Urgency
		if finished {
			if prevRank >= 0 && rankScore > prevRank {
				inversions++
			}
			prevRank = rankScore
		}
		row := types.SessionRow{
			SessionID:          jc.SessionID,
			Cluster:           jc.Cluster,
			Urgency:       jc.Urgency,
			ReserveMs:  reserved,
			ProcessedMs:      used,
			Served:      finished,
			BindReady:       depReady,
			TurnRank:   idx + 1,
			SlackMs:     wasteAmt,
			OverlapWave:      jc.OverlapWave,
			ClusterStabilityScore: round4(u3.VxValue(jc.BindWeight, used)),
		}
		report.Sessions = append(report.Sessions, row)
	}

	report.FramesAllocatedMs = spent
	report.FramesSlackMs = totalWaste
	report.SessionsBound = completed
	if report.SessionsTotal > 0 {
		report.CoverageRate = round4(float64(completed) / float64(report.SessionsTotal))
	}
	if spent > 0 {
		report.SlackRatio = round4(float64(totalWaste) / float64(spent))
	}
	report.BindingViolations = depViol
	report.TurnInversions = inversions
	report.OverlapBufferMs = renewTotal
	report.ClusterStabilityScore = round4(valueTotal)
	hasDispatch := false
	for _, jc := range ordered {
		if jc.OverlapWave > 0 {
			hasDispatch = true
			break
		}
	}
	if !meetsFloors(cfg, report, hasDispatch) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func meetsFloors(cfg types.AnalyticsCfg, report types.DiarReport, hasDispatch bool) bool {
	if report.CoverageRate < cfg.MinCoverageRate {
		return false
	}
	if report.SlackRatio > cfg.MaxSlackRatio {
		return false
	}
	if report.BindingViolations > cfg.MaxBindingViolations {
		return false
	}
	if report.TurnInversions > cfg.MaxTurnInversions {
		return false
	}
	if report.OverlapBufferMs < cfg.MinOverlapBufferMs {
		if hasDispatch {
			return false
		}
	}
	if report.ClusterStabilityScore < cfg.MinClusterStabilityScore {
		return false
	}
	for _, row := range report.Sessions {
		if strings.HasPrefix(row.SessionID, "s_bind_") && !row.BindReady && row.Served {
			return false
		}
		if strings.HasPrefix(row.SessionID, "s_overlap_") && row.OverlapWave > 0 && !row.Served {
			return false
		}
		if strings.HasPrefix(row.SessionID, "s_frame_") && row.SlackMs == 0 && row.ReserveMs > row.ProcessedMs+50 {
			return false
		}
		if strings.HasPrefix(row.SessionID, "s_band_") && row.Served && row.ProcessedMs > row.ReserveMs+200 {
			return false
		}
	}
	_ = summ.SxFold(report.Sessions)
	return true
}

type digestPayload struct {
	Status              string         `json:"status"`
	FrameBudgetMs   int            `json:"frame_budget_ms"`
	FramesAllocatedMs          int            `json:"frames_allocated_ms"`
	FramesSlackMs          int            `json:"frames_slack_ms"`
	SessionsTotal           int            `json:"sessions_total"`
	SessionsBound       int            `json:"sessions_bound"`
	CoverageRate      float64        `json:"coverage_rate"`
	SlackRatio          float64        `json:"slack_ratio"`
	BindingViolations       int            `json:"binding_violations"`
	TurnInversions  int            `json:"turn_inversions"`
	OverlapBufferMs    int            `json:"overlap_buffer_ms"`
	ClusterStabilityScore   float64        `json:"cluster_stability_score"`
	ReportDigest        string         `json:"report_digest"`
	Sessions            []types.SessionRow `json:"sessions"`
}

func digestBody(report types.DiarReport) string {
	payload := digestPayload{
		Status:              report.Status,
		FrameBudgetMs:   report.FrameBudgetMs,
		FramesAllocatedMs:         report.FramesAllocatedMs,
		FramesSlackMs:         report.FramesSlackMs,
		SessionsTotal:        report.SessionsTotal,
		SessionsBound:       report.SessionsBound,
		CoverageRate:        report.CoverageRate,
		SlackRatio:        report.SlackRatio,
		BindingViolations:     report.BindingViolations,
		TurnInversions:  report.TurnInversions,
		OverlapBufferMs:    report.OverlapBufferMs,
		ClusterStabilityScore:   report.ClusterStabilityScore,
		ReportDigest:        "",
		Sessions:            report.Sessions,
	}
	raw, err := marshalDigestJSON(payload)
	if err != nil {
		return ""
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func marshalDigestJSON(payload digestPayload) ([]byte, error) {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return nil, err
	}
	b := buf.Bytes()
	if n := len(b); n > 0 && b[n-1] == '\n' {
		b = b[:n-1]
	}
	return b, nil
}

func WriteReport(path string, report types.DiarReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func p95(values []int) int {
	if len(values) == 0 {
		return 0
	}
	cp := append([]int(nil), values...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}
