#!/bin/bash
set -euo pipefail
cd /app
bash /app/scripts/build.sh
/app/bin/sessionpack /app/data/session_manifest.jsonl /app/data/sessions_default.jsonl
/app/tools/run_session
