package types

type AnalyticsCfg struct {
	FrameBudgetMs      int
	MinCoverageRate        float64
	MaxSlackRatio        float64
	MaxBindingViolations     int
	MaxTurnInversions  int
	MinOverlapBufferMs    int
	MinClusterStabilityScore   float64
	ClusterWeights         map[string]float64
}

type ScoreBand struct {
	ScoreBandID string
	HeadScale   int
	TailScale   int
	TailAfter   int
}

type SessionCase struct {
	SessionID       string   `json:"session_id"`
	Cluster        string   `json:"cluster"`
	Urgency        int      `json:"urgency"`
	TapeRevision int      `json:"tape_revision"`
	EstMs        int      `json:"est_ms"`
	ActMs        int      `json:"act_ms"`
	BindDeps      []string `json:"bind_deps"`
	OverlapWave     int      `json:"overlap_wave"`
	BindWeight      float64  `json:"bind_weight"`
	ScoreBandID     string   `json:"score_band"`
	FrameSlot     int      `json:"frame_slot"`
	StartSlot     int      `json:"start_slot"`
}

type SessionRow struct {
	SessionID          string  `json:"session_id"`
	Cluster           string  `json:"cluster"`
	Urgency           int     `json:"urgency"`
	ReserveMs      int     `json:"reserve_ms"`
	ProcessedMs     int     `json:"processed_ms"`
	Served            bool    `json:"served"`
	BindReady        bool    `json:"bind_ready"`
	TurnRank      int     `json:"turn_rank"`
	SlackMs       int     `json:"slack_ms"`
	OverlapWave        int     `json:"overlap_wave"`
	ClusterStabilityScore float64 `json:"cluster_stability_score"`
}

type DiarReport struct {
	Status             string      `json:"status"`
	FrameBudgetMs  int         `json:"frame_budget_ms"`
	FramesAllocatedMs        int         `json:"frames_allocated_ms"`
	FramesSlackMs        int         `json:"frames_slack_ms"`
	SessionsTotal       int         `json:"sessions_total"`
	SessionsBound      int         `json:"sessions_bound"`
	CoverageRate       float64     `json:"coverage_rate"`
	SlackRatio       float64     `json:"slack_ratio"`
	BindingViolations    int         `json:"binding_violations"`
	TurnInversions int         `json:"turn_inversions"`
	OverlapBufferMs   int         `json:"overlap_buffer_ms"`
	ClusterStabilityScore  float64     `json:"cluster_stability_score"`
	ReportDigest       string      `json:"report_digest"`
	Sessions           []SessionRow `json:"sessions"`
}
