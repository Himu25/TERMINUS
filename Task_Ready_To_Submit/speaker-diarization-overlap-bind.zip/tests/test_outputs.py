"""Validate /app/output/diar_report.json against analytics.toml guardrails for diarization replay."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "diar_report.json"
SESSIONS_DEFAULT = APP / "data" / "sessions_default.jsonl"
CFG = APP / "config" / "analytics.toml"
FRAME_LOG = APP / "data" / "frame_log.csv"
CASES = Path(__file__).resolve().parent / "data"

_DEFAULT_SESSIONS_TEXT = (
    SESSIONS_DEFAULT.read_text(encoding="utf-8") if SESSIONS_DEFAULT.is_file() else ""
)

REPORT_KEYS = frozenset(
    {
        "status",
        "frame_budget_ms",
        "frames_allocated_ms",
        "frames_slack_ms",
        "sessions_total",
        "sessions_bound",
        "coverage_rate",
        "slack_ratio",
        "binding_violations",
        "turn_inversions",
        "overlap_buffer_ms",
        "cluster_stability_score",
        "report_digest",
        "sessions",
    }
)
ROW_KEYS = frozenset(
    {
        "session_id",
        "cluster",
        "urgency",
        "reserve_ms",
        "processed_ms",
        "slack_ms",
        "served",
        "bind_ready",
        "turn_rank",
        "overlap_wave",
        "cluster_stability_score",
    }
)

# ScoreBand bill bands: tight enough that peak-only metering fails, wide enough that
# a mostly-correct meter rebuild can land within ~1-3/10 agent trials.
_SCORE_BAND_BLEND_NUM = 86
_SCORE_BAND_BLEND_DEN = 100


def _score_band_bill_max(sessions_text: str) -> int:
    raw = _session_map_from_text(sessions_text)["s_band_us"]["act_ms"]
    return (raw * _SCORE_BAND_BLEND_NUM) // _SCORE_BAND_BLEND_DEN


def _assert_score_band_blend(report: dict, sessions_text: str, *, require_status: bool) -> None:
    bill_max = _score_band_bill_max(sessions_text)
    us = next(r for r in report["sessions"] if r["session_id"] == "s_band_us")
    eu = next(r for r in report["sessions"] if r["session_id"] == "s_band_eu")
    assert us["served"] and eu["served"]
    assert us["reserve_ms"] <= bill_max, us
    assert eu["reserve_ms"] <= bill_max, eu
    assert eu["reserve_ms"] < us["reserve_ms"], (us, eu)
    assert eu["processed_ms"] < us["processed_ms"], (us, eu)
    if require_status:
        assert report["status"] == "ok"


def _load_frame_logs() -> dict[str, int]:
    frame_logs: dict[str, int] = {}
    if not FRAME_LOG.is_file():
        return frame_logs
    lines = FRAME_LOG.read_text(encoding="utf-8").splitlines()
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        session_id, act_ms = (part.strip() for part in line.split(",", 1))
        frame_logs[session_id] = int(act_ms)
    return frame_logs


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "frame_budget_ms": 12000,
        "min_coverage_rate": 0.75,
        "max_slack_ratio": 0.35,
        "max_binding_violations": 0,
        "max_turn_inversions": 1,
        "min_overlap_buffer_ms": 3,
        "min_cluster_stability_score": 2.0,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in ("min_coverage_rate", "max_slack_ratio", "min_cluster_stability_score"):
            cfg[key] = float(val)
        elif key in (
            "frame_budget_ms",
            "max_binding_violations",
            "max_turn_inversions",
            "min_overlap_buffer_ms",
        ):
            cfg[key] = int(float(val))
    return cfg


def _session_rows_from_text(text: str) -> list[dict]:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def _session_ids_from_text(text: str) -> list[str]:
    return [row["session_id"] for row in _session_rows_from_text(text)]


def _session_map_from_text(text: str) -> dict[str, dict]:
    return {row["session_id"]: row for row in _session_rows_from_text(text)}


def _assert_sessions_match_input(report: dict, sessions_text: str) -> None:
    expected_ids = _session_ids_from_text(sessions_text)
    report_ids = [row["session_id"] for row in report["sessions"]]
    assert report["sessions_total"] == len(expected_ids)
    assert len(report_ids) == len(expected_ids)
    assert set(report_ids) == set(expected_ids)


@pytest.fixture(autouse=True)
def restore_default_sessions() -> None:
    yield
    if _DEFAULT_SESSIONS_TEXT:
        _atomic_write_text(SESSIONS_DEFAULT, _DEFAULT_SESSIONS_TEXT)


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _swap_fixture(stem: str) -> str:
    src = CASES / f"{stem}.jsonl"
    text = src.read_text(encoding="utf-8")
    _atomic_write_text(SESSIONS_DEFAULT, text)
    return text


def _expected_digest(report: dict) -> str:
    payload = dict(report)
    payload["report_digest"] = ""
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _invoke_default() -> None:
    proc = subprocess.run(
        ["/app/tools/run_session"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "diar_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    _invoke_default()


def test_report_top_level_keys_exact() -> None:
    """Report must expose only the documented top-level keys."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS


def test_session_row_schema() -> None:
    """Each session row must match the documented per-session schema."""
    report = _load_report()
    assert report["sessions"]
    for row in report["sessions"]:
        assert set(row.keys()) == ROW_KEYS
        assert isinstance(row["session_id"], str) and row["session_id"]
        assert isinstance(row["cluster"], str) and row["cluster"]
        assert isinstance(row["urgency"], int)
        assert row["reserve_ms"] >= 0
        assert row["processed_ms"] >= 0
        assert row["slack_ms"] >= 0
        assert isinstance(row["served"], bool)
        assert isinstance(row["bind_ready"], bool)
        assert row["turn_rank"] >= 1
        assert row["overlap_wave"] >= 0
        assert row["cluster_stability_score"] >= 0.0
        assert row["slack_ms"] == max(0, row["reserve_ms"] - row["processed_ms"])


def test_passing_run_contract() -> None:
    """Default bundle must finish ok and meet analytics.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["frame_budget_ms"] == cfg["frame_budget_ms"]
    _assert_sessions_match_input(report, _DEFAULT_SESSIONS_TEXT)
    assert report["sessions_bound"] == sum(1 for row in report["sessions"] if row["served"])
    assert report["coverage_rate"] >= cfg["min_coverage_rate"]
    assert report["slack_ratio"] <= cfg["max_slack_ratio"]
    assert report["binding_violations"] <= cfg["max_binding_violations"]
    assert report["turn_inversions"] <= cfg["max_turn_inversions"]
    assert report["overlap_buffer_ms"] >= cfg["min_overlap_buffer_ms"]
    assert report["cluster_stability_score"] >= cfg["min_cluster_stability_score"]


def test_sessions_total_matches_input_rows() -> None:
    """Report session IDs must cover every input JSONL row with no drops or extras."""
    report = _load_report()
    _assert_sessions_match_input(report, _DEFAULT_SESSIONS_TEXT)


def test_report_digest_matches_payload() -> None:
    """report_digest must hash the compact pre-digest JSON payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_deterministic_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_dep_rows_finish_in_order() -> None:
    """Dependency chain rows must complete only after prerequisites."""
    report = _load_report()
    ranks = {row["session_id"]: row["turn_rank"] for row in report["sessions"]}
    assert ranks["s_bind_root"] < ranks["s_bind_leaf"] < ranks["s_bind_chain"]
    for row in report["sessions"]:
        if row["session_id"].startswith("s_bind_") and row["served"]:
            assert row["bind_ready"] is True, row


def test_prio_hot_ranks_before_cold() -> None:
    """Late priority revision rows must finish before stale low-revision peers."""
    report = _load_report()
    hot = next(r for r in report["sessions"] if r["session_id"] == "s_overlap_hot")
    cold = next(r for r in report["sessions"] if r["session_id"] == "s_overlap_cold")
    assert hot["served"] is True
    assert cold["served"] is True
    assert hot["turn_rank"] < cold["turn_rank"], (hot, cold)


def test_drift_accounting_semantics() -> None:
    """Drift rows reserve estimates, bill actuals, and record reserved minus used."""
    report = _load_report()
    inputs = _session_map_from_text(_DEFAULT_SESSIONS_TEXT)
    frame_logs = _load_frame_logs()
    for row in report["sessions"]:
        if not row["session_id"].startswith("s_frame_") or not row["served"]:
            continue
        spec = inputs[row["session_id"]]
        expected_used = frame_logs.get(row["session_id"], spec["act_ms"])
        assert row["reserve_ms"] == spec["est_ms"]
        assert row["processed_ms"] == expected_used
        assert row["slack_ms"] == max(0, row["reserve_ms"] - row["processed_ms"])


def test_drift_rows_record_waste() -> None:
    """Drift-prone rows with inflated reservations must record slack_ms."""
    report = _load_report()
    drift_rows = [r for r in report["sessions"] if r["session_id"].startswith("s_frame_")]
    assert drift_rows
    assert any(r["slack_ms"] > 0 for r in drift_rows if r["served"])


def test_burst_rows_complete() -> None:
    """Overlap-wave rows with the s_overlap_ prefix must complete under the default bundle."""
    report = _load_report()
    burst_rows = [r for r in report["sessions"] if r["session_id"].startswith("s_overlap_")]
    assert burst_rows
    assert all(r["served"] for r in burst_rows), burst_rows


def test_session_rows_respect_intensity() -> None:
    """Score-band rows must bill through blended intensity, not raw estimates alone."""
    _invoke_default()
    report = _load_report()
    bill_max = _score_band_bill_max(_DEFAULT_SESSIONS_TEXT)
    us = next(r for r in report["sessions"] if r["session_id"] == "s_band_us")
    eu = next(r for r in report["sessions"] if r["session_id"] == "s_band_eu")
    assert us["served"] and eu["served"]
    assert us["reserve_ms"] <= bill_max, us
    assert eu["reserve_ms"] <= bill_max, eu
    assert eu["reserve_ms"] < us["reserve_ms"], (us, eu)


def test_overlap_late_row_completes() -> None:
    """Delayed overlap-wave row j_overlap_late must complete under the default bundle."""
    report = _load_report()
    late = next(r for r in report["sessions"] if r["session_id"] == "j_overlap_late")
    assert late["served"] is True
    assert late["overlap_wave"] > 0


def test_scenario_dep_chain() -> None:
    """Dependency-chain scenario must schedule deps before dependents."""
    sessions_text = _swap_fixture("dep_chain")
    _invoke_default()
    report = _load_report()
    _assert_sessions_match_input(report, sessions_text)
    assert report["binding_violations"] == 0
    assert report["status"] == "ok"
    ranks = {row["session_id"]: row["turn_rank"] for row in report["sessions"]}
    assert ranks["s_bind_root"] < ranks["s_bind_leaf"] < ranks["s_bind_chain"]


def test_scenario_urgency_flip() -> None:
    """Urgency-flip scenario must schedule late revisions ahead of stale peers."""
    cfg = _parse_cfg()
    sessions_text = _swap_fixture("urgency_flip")
    _invoke_default()
    report = _load_report()
    _assert_sessions_match_input(report, sessions_text)
    hot = next(r for r in report["sessions"] if r["session_id"] == "s_overlap_hot")
    cold = next(r for r in report["sessions"] if r["session_id"] == "s_overlap_cold")
    assert hot["turn_rank"] < cold["turn_rank"]
    assert report["turn_inversions"] <= cfg["max_turn_inversions"]
    assert report["status"] == "ok"


def test_scenario_est_drift() -> None:
    """Estimate-drift scenario must keep slack_ratio under max_slack_ratio."""
    cfg = _parse_cfg()
    sessions_text = _swap_fixture("est_drift")
    _invoke_default()
    report = _load_report()
    _assert_sessions_match_input(report, sessions_text)
    inputs = _session_map_from_text(sessions_text)
    for row in report["sessions"]:
        if not row["session_id"].startswith("s_frame_") or not row["served"]:
            continue
        spec = inputs[row["session_id"]]
        assert row["reserve_ms"] == spec["est_ms"]
        assert row["slack_ms"] == max(0, row["reserve_ms"] - row["processed_ms"])
        assert row["slack_ms"] > 0
    assert report["slack_ratio"] <= cfg["max_slack_ratio"]
    assert report["status"] == "ok"


def test_scenario_burst_cluster() -> None:
    """Overlap-cluster scenario must absorb enough overlap buffer headroom."""
    cfg = _parse_cfg()
    sessions_text = _swap_fixture("burst_cluster")
    _invoke_default()
    report = _load_report()
    _assert_sessions_match_input(report, sessions_text)
    burst_rows = [r for r in report["sessions"] if r["session_id"].startswith("s_overlap_")]
    assert burst_rows
    assert all(r["served"] for r in burst_rows)
    assert report["overlap_buffer_ms"] >= cfg["min_overlap_buffer_ms"]
    assert report["status"] == "ok"


def test_scenario_value_mix() -> None:
    """Need-score mix scenario must meet cluster_stability_score floor."""
    cfg = _parse_cfg()
    sessions_text = _swap_fixture("value_mix")
    _invoke_default()
    report = _load_report()
    _assert_sessions_match_input(report, sessions_text)
    assert report["cluster_stability_score"] >= cfg["min_cluster_stability_score"]


def test_scenario_frame_meter() -> None:
    """Zero-estimate frame-log row must bill act_ms through the meter."""
    sessions_text = _swap_fixture("frame_meter")
    _invoke_default()
    report = _load_report()
    _assert_sessions_match_input(report, sessions_text)
    frame_logs = _load_frame_logs()
    expected_used = frame_logs["s_band_meter"]
    row = next(r for r in report["sessions"] if r["session_id"] == "s_band_meter")
    assert row["served"] is True
    assert row["processed_ms"] == expected_used
    assert row["reserve_ms"] == expected_used
    assert row["slack_ms"] == 0


def test_scenario_session_mix() -> None:
    """Score-band variability scenario must bill upper_pool below lower_pool for similar work."""
    sessions_text = _swap_fixture("session_mix")
    _invoke_default()
    report = _load_report()
    _assert_sessions_match_input(report, sessions_text)
    _assert_score_band_blend(report, sessions_text, require_status=False)


def test_scenario_overlap_delay() -> None:
    """Delayed overlap-wave scenario must complete j_overlap_late with overlap buffer absorption."""
    cfg = _parse_cfg()
    sessions_text = _swap_fixture("overlap_delay")
    _invoke_default()
    report = _load_report()
    _assert_sessions_match_input(report, sessions_text)
    late = next(r for r in report["sessions"] if r["session_id"] == "j_overlap_late")
    assert late["served"] is True
    assert report["overlap_buffer_ms"] >= cfg["min_overlap_buffer_ms"]
    assert report["status"] == "ok"
