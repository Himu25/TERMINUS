#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/analytics.toml
require_file /app/data/session_manifest.jsonl
require_file /app/data/frame_profile.csv
require_file /app/data/frame_log.csv
mkdir -p /app/bin /app/output

log "apply patched sources"
cp "${ROOT_DIR}/oracle/p2_order.go" /app/q9/p2_order.go
cp "${ROOT_DIR}/oracle/d4_hold.go" /app/k2/d4_hold.go
cp "${ROOT_DIR}/oracle/b7_slot.go" /app/h4/b7_slot.go
cp "${ROOT_DIR}/oracle/w5_roll.go" /app/z1/w5_roll.go
cp "${ROOT_DIR}/oracle/lib.rs" /app/n8/src/lib.rs

log "rebuild diardisp"
bash /app/scripts/build.sh

log "refresh default session bundle"
/app/bin/sessionpack /app/data/session_manifest.jsonl /app/data/sessions_default.jsonl

log "emit default session report"
/app/tools/run_session

log "post-run validation against analytics.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/analytics.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k in ("min_coverage_rate", "max_slack_ratio", "min_cluster_stability_score"):
        cfg[k] = float(v)
    elif k.startswith("max_") or k.startswith("min_") or k == "frame_budget_ms":
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/diar_report.json").read_text())
assert report["status"] == "ok", report
assert report["coverage_rate"] >= cfg["min_coverage_rate"]
assert report["slack_ratio"] <= cfg["max_slack_ratio"]
assert report["binding_violations"] <= cfg["max_binding_violations"]
assert report["turn_inversions"] <= cfg["max_turn_inversions"]
assert report["overlap_buffer_ms"] >= cfg["min_overlap_buffer_ms"]
assert report["cluster_stability_score"] >= cfg["min_cluster_stability_score"]
for row in report["sessions"]:
    if row["session_id"].startswith("s_bind_") and row["served"]:
        assert row["bind_ready"], row
    if row["session_id"].startswith("s_overlap_"):
        assert row["served"], row
print("ok", report["coverage_rate"], report["slack_ratio"], report["cluster_stability_score"])
PY

log "oracle complete"
