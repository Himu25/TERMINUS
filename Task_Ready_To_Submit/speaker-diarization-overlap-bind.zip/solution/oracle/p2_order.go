package q9

import (
	"sort"

	"cal.diar/pkg/types"
)

// RxOrder ranks pending sessions for diarization replay scheduling.
func RxOrder(cases []types.SessionCase) []types.SessionCase {
	out := make([]types.SessionCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		a, b := out[i], out[j]
		if a.TapeRevision != b.TapeRevision {
			return a.TapeRevision > b.TapeRevision
		}
		if a.Urgency != b.Urgency {
			return a.Urgency > b.Urgency
		}
		if a.BindWeight != b.BindWeight {
			return a.BindWeight > b.BindWeight
		}
		return a.SessionID < b.SessionID
	})
	return out
}
