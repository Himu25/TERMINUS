package z1

// VxRoll totals slack volume for one overlap wave.
func VxRoll(reserved, used int) int {
	if reserved <= used {
		return 0
	}
	return reserved - used
}
