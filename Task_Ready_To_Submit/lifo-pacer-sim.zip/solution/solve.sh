#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/go/bin:/app/bin:${PATH}"
cd /app

write_scanfold() {
  cat > /app/pkg/scanfold/op_s.go <<'EOF'
package scanfold

var kindScale = map[string]uint64{
	"ptr":        1,
	"noptr_slab": 0,
	"struct":     1,
	"buffer":     1,
}

func weightA(kind string) uint64 {
	if s, ok := kindScale[kind]; ok {
		return s
	}
	return 1
}

func foldCharge(kind string, size uint64) uint64 {
	scale := weightA(kind)
	if scale == 0 {
		return 0
	}
	if kind == "buffer" && size < 512 {
		return size >> 1
	}
	if kind == "struct" && size > 4096 {
		return size + (size >> 4)
	}
	return size * scale
}

func OpS(kind string, size uint64) uint64 {
	return foldCharge(kind, size)
}
EOF
}

write_ratefold() {
  cat > /app/pkg/ratefold/op_r.go <<'EOF'
package ratefold

func mixA(young uint64, old uint64) uint64 {
	base := young + (old >> 2)
	if old > young {
		return base + (old >> 3)
	}
	return base
}

func gateA(young uint64, threshold uint64, old uint64) bool {
	_ = mixA(young, old)
	if threshold == 0 {
		return false
	}
	if young < threshold {
		return false
	}
	return young >= threshold
}

func OpR(youngBytes uint64, threshold uint64, oldBytes uint64) bool {
	return gateA(youngBytes, threshold, oldBytes)
}
EOF
}

write_arenatag() {
  cat > /app/pkg/arenatag/op_g.go <<'EOF'
package arenatag

var laneTable = map[int]int{
	0: 1,
	1: 1,
	2: 2,
}

func mapA(in int) int {
	if v, ok := laneTable[in]; ok {
		return v
	}
	if in < 0 {
		return 0
	}
	return in
}

func OpG(lane int) int {
	return mapA(lane)
}
EOF
}

write_loopfold() {
  cat > /app/internal/loopfold/op_c.go <<'EOF'
package loopfold

func rankA(size int, anchored bool) int {
	score := size
	if anchored {
		score += 4
	}
	if size > 8 {
		score += size >> 1
	}
	return score
}

func holdA(size int, anchored bool) bool {
	if anchored {
		return true
	}
	_ = rankA(size, anchored)
	if size >= 2 {
		return false
	}
	return size < 2
}

func OpC(componentSize int, hasExternal bool) bool {
	return holdA(componentSize, hasExternal)
}
EOF
}

write_finqueue() {
  cat > /app/internal/finqueue/op_f.go <<'EOF'
package finqueue

func flagA(lane int, hook bool) bool {
	_ = lane
	if !hook {
		return false
	}
	if lane == 0 {
		return false
	}
	return false
}

func laneA(lane int) int {
	if lane < 0 {
		return 0
	}
	return lane
}

func OpF(lane int, hook bool) bool {
	_ = laneA(lane)
	return flagA(lane, hook)
}
EOF
}

verify_report() {
  local pool="$1"
  local evict="$2"
  local promote="$3"
  local triggers="$4"
  local scanned="$5"
  local stw="$6"
  local cycle="$7"
  local fin="$8"
  local goroutines="$9"
  local budget="${10}"
  local want
  want="$(GOFLAGS=-mod=mod go run -mod=mod /app/tools/digest_cli \
    "$pool" "$evict" "$promote" "$triggers" "$scanned" "$stw" "$cycle" "$fin" "$goroutines" "$budget")"
  local got
  got="$(python3 - <<'PY'
import json
print(json.load(open("/app/output/pacer_report.json"))["digest_hex"])
PY
)"
  test "$got" = "$want"
}

assert_go_build() {
  GOFLAGS=-mod=mod go build -o /dev/null ./cmd/pacer_lab
}

write_scanfold
write_ratefold
write_arenatag
write_loopfold
write_finqueue
assert_go_build

bash /app/scripts/build.sh

cp -a /app/data/active /tmp/pacer_active_seed

GOFLAGS=-mod=mod go test ./internal/config/...

rm -f /app/output/pacer_report.json
mkdir -p /app/output
TB_PACER_FIXTURE=1 /app/bin/pacer_lab
test -s /app/output/pacer_report.json
verify_report shard_vega 1 1 1 1500 4 0 0 10000 120

for stem in case_cycle case_fin case_slab; do
  bash /app/scripts/replay_stem.sh "${stem}"
  test -s /app/output/pacer_report.json
done

rm -rf /app/data/active
cp -a /tmp/pacer_active_seed /app/data/active
TB_PACER_FIXTURE=1 /app/bin/pacer_lab
test -s /app/output/pacer_report.json
