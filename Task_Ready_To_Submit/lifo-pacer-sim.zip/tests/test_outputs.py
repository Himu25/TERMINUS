"""Verifier for game-shard allocation pacing lab reports."""

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
ACTIVE = APP / "data" / "active"
REGRESSION = APP / "data" / "regression"
OUT = APP / "output" / "pacer_report.json"
BIN = "/app/bin/pacer_lab"
GO_BIN = "go"
ACTIVE_SEED = APP / "data" / "active_seed"
STEM_INDEX = APP / "docs" / "fixture_index.txt"

EXPECTED_ACTIVE = {
    "schema_version": "1",
    "pool_id": "shard_vega",
    "goroutines_live": 10000,
    "nursery_evictions": 1,
    "old_promotions": 1,
    "trigger_events": 1,
    "bytes_scanned": 1500,
    "stw_units": 4,
    "cycle_retained": 0,
    "fin_misfires": 0,
}

EXPECTED_STEMS = {
    "case_cycle": {
        "schema_version": "1",
        "pool_id": "stem_cycle",
        "goroutines_live": 10000,
        "nursery_evictions": 3,
        "old_promotions": 0,
        "trigger_events": 1,
        "bytes_scanned": 3064,
        "stw_units": 8,
        "cycle_retained": 0,
        "fin_misfires": 0,
    },
    "case_fin": {
        "schema_version": "1",
        "pool_id": "stem_fin",
        "goroutines_live": 10000,
        "nursery_evictions": 1,
        "old_promotions": 1,
        "trigger_events": 1,
        "bytes_scanned": 2600,
        "stw_units": 4,
        "cycle_retained": 0,
        "fin_misfires": 0,
    },
    "case_slab": {
        "schema_version": "1",
        "pool_id": "stem_slab",
        "goroutines_live": 10000,
        "nursery_evictions": 2,
        "old_promotions": 0,
        "trigger_events": 1,
        "bytes_scanned": 1100,
        "stw_units": 4,
        "cycle_retained": 0,
        "fin_misfires": 0,
    },
}

METRIC_KEYS = [
    "schema_version",
    "pool_id",
    "goroutines_live",
    "nursery_evictions",
    "old_promotions",
    "trigger_events",
    "bytes_scanned",
    "stw_units",
    "cycle_retained",
    "fin_misfires",
    "digest_hex",
]


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "0",
        "PATH": "/usr/local/go/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)
    if ACTIVE_SEED.exists():
        shutil.rmtree(ACTIVE_SEED)
    shutil.copytree(ACTIVE, ACTIVE_SEED)


def _digest_hex(
    pool_id: str,
    evict: int,
    promote: int,
    triggers: int,
    scanned: int,
    stw: int,
    cycle: int,
    fin: int,
    goroutines: int,
    budget: int,
) -> str:
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            pool_id,
            str(evict),
            str(promote),
            str(triggers),
            str(scanned),
            str(stw),
            str(cycle),
            str(fin),
            str(goroutines),
            str(budget),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _load_plan(pack_dir: Path) -> dict:
    return json.loads((pack_dir / "workload_plan.json").read_text())


def _with_digest(metrics: dict, budget: int) -> dict:
    out = dict(metrics)
    out["digest_hex"] = _digest_hex(
        out["pool_id"],
        out["nursery_evictions"],
        out["old_promotions"],
        out["trigger_events"],
        out["bytes_scanned"],
        out["stw_units"],
        out["cycle_retained"],
        out["fin_misfires"],
        out["goroutines_live"],
        budget,
    )
    return out


def _run_driver(pack_dir: Path) -> dict:
    shutil.rmtree(ACTIVE, ignore_errors=True)
    source = ACTIVE_SEED if pack_dir == ACTIVE else pack_dir
    shutil.copytree(source, ACTIVE)
    env = {**os.environ, "TB_PACER_FIXTURE": "1"}
    subprocess.run([BIN], cwd="/app", env=env, check=True)
    return json.loads(OUT.read_text())


def _assert_report(got: dict, want: dict) -> None:
    for key in METRIC_KEYS:
        assert got[key] == want[key], f"{key}: got {got[key]!r}, want {want[key]!r}"


def test_active_report_matches_contract() -> None:
    """Active shard_vega replay matches the signed-off pacing report."""
    got = _run_driver(ACTIVE)
    plan = _load_plan(ACTIVE)
    want = _with_digest(EXPECTED_ACTIVE, plan["stw_budget_units"])
    _assert_report(got, want)


def test_active_stw_within_plan_budget() -> None:
    """Active replay stays within the workload plan stop-the-world budget."""
    got = _run_driver(ACTIVE)
    plan = _load_plan(ACTIVE)
    assert got["stw_units"] <= plan["stw_budget_units"]


def test_stem_case_cycle_digest() -> None:
    """Cycle regression stem matches the signed-off report digest."""
    pack = REGRESSION / "case_cycle"
    got = _run_driver(pack)
    plan = _load_plan(pack)
    want = _with_digest(EXPECTED_STEMS["case_cycle"], plan["stw_budget_units"])
    _assert_report(got, want)


def test_stem_case_fin_digest() -> None:
    """Fin regression stem matches the signed-off report digest."""
    pack = REGRESSION / "case_fin"
    got = _run_driver(pack)
    plan = _load_plan(pack)
    want = _with_digest(EXPECTED_STEMS["case_fin"], plan["stw_budget_units"])
    _assert_report(got, want)


def test_stem_case_slab_budget_and_digest() -> None:
    """Slab-heavy regression stem stays within budget with matching digest."""
    pack = REGRESSION / "case_slab"
    got = _run_driver(pack)
    plan = _load_plan(pack)
    assert got["stw_units"] <= plan["stw_budget_units"]
    want = _with_digest(EXPECTED_STEMS["case_slab"], plan["stw_budget_units"])
    _assert_report(got, want)


def test_fixture_index_stems_covered() -> None:
    """Every stem listed in fixture_index.txt has a signed-off expected report."""
    stems = [
        line.strip()
        for line in STEM_INDEX.read_text().splitlines()
        if line.strip()
    ]
    assert set(stems) == set(EXPECTED_STEMS)


def test_config_loader_smoke() -> None:
    """Packaged config loader tests stay green after collector repairs."""
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "PATH": "/usr/local/go/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(
        [GO_BIN, "test", "./internal/config/..."],
        cwd="/app",
        env=env,
        check=True,
    )
