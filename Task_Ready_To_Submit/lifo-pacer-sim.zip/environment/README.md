# Allocation pacing lab

Game-shard heap pacing simulation. Build with `/app/scripts/build.sh`, driver `/app/bin/pacer_lab`, traces under `/app/data`.
