package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
	"strconv"
)

func main() {
	if len(os.Args) != 11 {
		fmt.Fprintln(os.Stderr, "usage: digest_cli pool evict promote triggers scanned stw cycle fin goroutines budget")
		os.Exit(2)
	}
	pool := os.Args[1]
	evict, _ := strconv.ParseUint(os.Args[2], 10, 32)
	promote, _ := strconv.ParseUint(os.Args[3], 10, 32)
	triggers, _ := strconv.ParseUint(os.Args[4], 10, 32)
	scanned, _ := strconv.ParseUint(os.Args[5], 10, 64)
	stw, _ := strconv.ParseUint(os.Args[6], 10, 32)
	cycle, _ := strconv.ParseUint(os.Args[7], 10, 32)
	fin, _ := strconv.ParseUint(os.Args[8], 10, 32)
	goro, _ := strconv.ParseUint(os.Args[9], 10, 32)
	budget, _ := strconv.ParseUint(os.Args[10], 10, 32)
	payload := fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%d|%d|%d|%d",
		pool, evict, promote, triggers, scanned, stw, cycle, fin, goro, budget,
	)
	sum := sha256.Sum256([]byte(payload))
	fmt.Println(hex.EncodeToString(sum[:]))
}
