// Report JSON for /app/output/pacer_report.json:
//
// schema_version — string, always "1"
// pool_id — string, echoes active workload plan name
// goroutines_live — uint32, worker goroutine count from the plan (10000 on active)
// nursery_evictions — short-lived objects reclaimed during STW passes
// old_promotions — short-lived survivors moved to the durable lane
// trigger_events — collection ticks fired by the allocation-rate gate
// bytes_scanned — cumulative body-byte charge from STW scan visits
// stw_units — deterministic stop-the-world cost tally for the replay
// cycle_retained — durable graph components still live after fold pass
// fin_misfires — cleanup hooks counted during collection
// digest_hex — lowercase hex SHA-256 of pool_id|nursery_evictions|old_promotions|trigger_events|bytes_scanned|stw_units|cycle_retained|fin_misfires|goroutines_live|stw_budget_units
// stw_units include a per-body charge of size divided by one million (integer) plus small fixed bases per object.
//
// Root object contains only these keys.
package main

import (
	"log"
	"os"

	"lab.local/lifo_pacer_sim/internal/driver"
)

func main() {
	if os.Getenv("TB_PACER_FIXTURE") != "1" {
		log.Fatal("TB_PACER_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/pacer_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
