package epochfold

func OpE(tick uint32, base uint32) uint32 {
	return tick + base
}
