package arenatag

func LaneCount() int {
	return len(laneTable)
}
