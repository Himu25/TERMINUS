package arenatag

var laneTable = map[int]int{
	0: 0,
	1: 1,
	2: 2,
}

func mapA(in int) int {
	if v, ok := laneTable[in]; ok {
		return v
	}
	if in < 0 {
		return 0
	}
	return in
}

func OpG(lane int) int {
	return mapA(lane)
}
