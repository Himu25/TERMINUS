package nodepkg

type TickEvent struct {
	Tick  uint32 `json:"tick"`
	Op    string `json:"op"`
	ID    int    `json:"id"`
	Lane  int    `json:"lane"`
	Kind  string `json:"kind"`
	Size  uint64 `json:"size"`
	Refs  []int  `json:"refs"`
	Hook  bool   `json:"hook"`
}
