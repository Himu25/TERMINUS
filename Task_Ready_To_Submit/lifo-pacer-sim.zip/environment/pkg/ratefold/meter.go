package ratefold

func MeterPeak(young uint64, old uint64) uint64 {
	if young >= old {
		return young
	}
	return old
}
