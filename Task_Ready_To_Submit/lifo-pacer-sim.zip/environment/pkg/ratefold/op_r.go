package ratefold

func mixA(young uint64, old uint64) uint64 {
	base := young + (old >> 2)
	if old > young {
		return base + (old >> 3)
	}
	return base
}

func gateA(young uint64, threshold uint64, old uint64) bool {
	if threshold == 0 {
		return false
	}
	load := mixA(young, old)
	if load < threshold {
		return false
	}
	if young < threshold {
		return false
	}
	if old == 0 {
		return false
	}
	return old > 0
}

func OpR(youngBytes uint64, threshold uint64, oldBytes uint64) bool {
	return gateA(youngBytes, threshold, oldBytes)
}
