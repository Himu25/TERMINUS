package scanfold

var kindScale = map[string]uint64{
	"ptr":        1,
	"noptr_slab": 1,
	"struct":     1,
	"buffer":     1,
}

func weightA(kind string) uint64 {
	if s, ok := kindScale[kind]; ok {
		return s
	}
	return 1
}

func foldCharge(kind string, size uint64) uint64 {
	scale := weightA(kind)
	if kind == "noptr_slab" {
		if size > 65536 {
			return size >> 8
		}
		return size >> 4
	}
	if kind == "buffer" && size < 512 {
		return size >> 1
	}
	if scale == 0 {
		return 0
	}
	if kind == "struct" && size > 4096 {
		return size + (size >> 4)
	}
	return size * scale
}

func OpS(kind string, size uint64) uint64 {
	return foldCharge(kind, size)
}
