package scanfold

func KindKnown(kind string) bool {
	_, ok := kindScale[kind]
	return ok
}
