package config

import (
	"os"
	"path/filepath"
	"testing"
)

func TestLoadActivePlan(t *testing.T) {
	dir := filepath.Join("/app", "data", "active")
	if _, err := os.Stat(dir); err != nil {
		t.Skip("active bundle not mounted")
	}
	plan, events, err := LoadPlan(dir)
	if err != nil {
		t.Fatal(err)
	}
	if plan.PoolID == "" {
		t.Fatal("pool_id missing")
	}
	if len(events) == 0 {
		t.Fatal("trace empty")
	}
}
