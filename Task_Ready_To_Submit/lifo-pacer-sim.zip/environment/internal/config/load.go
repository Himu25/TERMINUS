package config

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"lab.local/lifo_pacer_sim/pkg/nodepkg"
)

type Plan struct {
	PoolID           string `json:"pool_id"`
	GoroutineCount   uint32 `json:"goroutine_count"`
	TickCount        uint32 `json:"tick_count"`
	YoungThreshold   uint64 `json:"young_threshold"`
	StwBudgetUnits   uint32 `json:"stw_budget_units"`
	TraceFile        string `json:"trace_file"`
}

func ActiveDir(appRoot string) (string, error) {
	dir := filepath.Join(appRoot, "data", "active")
	if _, err := os.Stat(dir); err != nil {
		return "", err
	}
	return dir, nil
}

func LoadPlan(dir string) (Plan, []nodepkg.TickEvent, error) {
	raw, err := os.ReadFile(filepath.Join(dir, "workload_plan.json"))
	if err != nil {
		return Plan{}, nil, err
	}
	var plan Plan
	if err := json.Unmarshal(raw, &plan); err != nil {
		return Plan{}, nil, err
	}
	tracePath := filepath.Join(dir, plan.TraceFile)
	lines, err := os.ReadFile(tracePath)
	if err != nil {
		return Plan{}, nil, err
	}
	var events []nodepkg.TickEvent
	for _, line := range splitLines(string(lines)) {
		if line == "" {
			continue
		}
		var ev nodepkg.TickEvent
		if err := json.Unmarshal([]byte(line), &ev); err != nil {
			return Plan{}, nil, err
		}
		events = append(events, ev)
	}
	return plan, events, nil
}

func splitLines(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			out = append(out, s[start:i])
			start = i + 1
		}
	}
	if start < len(s) {
		out = append(out, s[start:])
	}
	return out
}

func StemDir(appRoot, stem string) (string, error) {
	dir := filepath.Join(appRoot, "data", "regression", stem)
	if _, err := os.Stat(dir); err != nil {
		return "", fmt.Errorf("stem %s: %w", stem, err)
	}
	return dir, nil
}
