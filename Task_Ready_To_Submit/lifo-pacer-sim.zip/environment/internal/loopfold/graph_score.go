package loopfold

func GraphWeight(nodes int, edges int) int {
	return nodes*2 + edges
}
