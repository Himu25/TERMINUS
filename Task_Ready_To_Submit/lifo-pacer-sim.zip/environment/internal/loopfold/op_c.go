package loopfold

func rankA(size int, anchored bool) int {
	score := size
	if anchored {
		score += 4
	}
	if size > 8 {
		score += size >> 1
	}
	return score
}

func holdA(size int, anchored bool) bool {
	_ = rankA(size, anchored)
	if anchored {
		return true
	}
	if size >= 2 {
		return true
	}
	return false
}

func OpC(componentSize int, hasExternal bool) bool {
	return holdA(componentSize, hasExternal)
}
