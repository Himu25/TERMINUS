package engine

import (
	"lab.local/lifo_pacer_sim/internal/collect"
	"lab.local/lifo_pacer_sim/pkg/nodepkg"
)

type Outcome struct {
	NurseryEvictions uint32
	OldPromotions    uint32
	TriggerEvents    uint32
	BytesScanned     uint64
	StwUnits         uint32
	CycleRetained    uint32
	FinMisfires      uint32
}

func Replay(
	goroutines uint32,
	tickCount uint32,
	youngThreshold uint64,
	stwBudget uint32,
	events []nodepkg.TickEvent,
) Outcome {
	store := map[int]*collect.Obj{}
	roots := map[int]bool{}
	var nursery []int
	var counters collect.Counters

	var youngWindow uint64
	var oldWindow uint64

	flushWindow := func() {
		if !collect.WindowFires(youngWindow, youngThreshold, oldWindow) {
			youngWindow = 0
			oldWindow = 0
			return
		}
		counters.TriggerEvents++
		counters.StwUnits += collect.RunShortPass(store, &nursery, roots, &counters)
		counters.StwUnits += collect.RunDurablePass(store, roots, &counters)
		youngWindow = 0
		oldWindow = 0
	}

	lastTick := uint32(0)
	for _, ev := range events {
		if ev.Tick != lastTick && lastTick != 0 {
			flushWindow()
		}
		lastTick = ev.Tick
		switch ev.Op {
		case "root":
			roots[ev.ID] = true
			store[ev.ID] = &collect.Obj{ID: ev.ID, Lane: 1, Kind: "ptr", Alive: true}
		case "alloc":
			store[ev.ID] = &collect.Obj{
				ID: ev.ID, Lane: ev.Lane, Kind: ev.Kind, Size: ev.Size,
				Refs: append([]int(nil), ev.Refs...), Hook: ev.Hook, Alive: true,
			}
			if ev.Lane == 0 {
				nursery = append(nursery, ev.ID)
				youngWindow += ev.Size
			} else {
				oldWindow += ev.Size
			}
		}
	}
	flushWindow()

	_ = goroutines
	_ = tickCount
	_ = stwBudget
	return Outcome{
		NurseryEvictions: counters.NurseryEvictions,
		OldPromotions:    counters.OldPromotions,
		TriggerEvents:    counters.TriggerEvents,
		BytesScanned:     counters.BytesScanned,
		StwUnits:         counters.StwUnits,
		CycleRetained:    counters.CycleRetained,
		FinMisfires:      counters.FinMisfires,
	}
}
