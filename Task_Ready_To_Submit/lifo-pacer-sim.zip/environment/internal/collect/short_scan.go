package collect

import "lab.local/lifo_pacer_sim/pkg/scanfold"

func ChargeBody(kind string, size uint64) uint64 {
	return scanfold.OpS(kind, size)
}
