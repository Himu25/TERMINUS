package collect

import "lab.local/lifo_pacer_sim/internal/loopfold"

func RetainComponent(size int, external bool) bool {
	return loopfold.OpC(size, external)
}
