package collect

type Obj struct {
	ID    int
	Lane  int
	Kind  string
	Size  uint64
	Refs  []int
	Hook  bool
	Alive bool
}

type Counters struct {
	NurseryEvictions uint32
	OldPromotions    uint32
	TriggerEvents    uint32
	BytesScanned     uint64
	StwUnits         uint32
	CycleRetained    uint32
	FinMisfires      uint32
}
