package collect

import "lab.local/lifo_pacer_sim/pkg/ratefold"

func WindowFires(young uint64, threshold uint64, old uint64) bool {
	return ratefold.OpR(young, threshold, old)
}
