package collect

import (
	"lab.local/lifo_pacer_sim/internal/finqueue"
	"lab.local/lifo_pacer_sim/pkg/arenatag"
)

func PromoteLane(lane int) int {
	return arenatag.OpG(lane)
}

func HookMisfire(lane int, hook bool) bool {
	return finqueue.OpF(lane, hook)
}
