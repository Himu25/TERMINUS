package collect

func RunShortPass(store map[int]*Obj, nursery *[]int, roots map[int]bool, out *Counters) uint32 {
	var stw uint32
	for len(*nursery) > 0 {
		id := (*nursery)[len(*nursery)-1]
		*nursery = (*nursery)[:len(*nursery)-1]
		o, ok := store[id]
		if !ok || !o.Alive || o.Lane != 0 {
			continue
		}
		scan := ChargeBody(o.Kind, o.Size)
		out.BytesScanned += scan
		stw += 2 + uint32(scan/1_000_000)
		if reachable(o, store, roots) {
			o.Lane = PromoteLane(o.Lane)
			out.OldPromotions++
			if HookMisfire(o.Lane, o.Hook) {
				out.FinMisfires++
			}
			continue
		}
		o.Alive = false
		delete(store, id)
		out.NurseryEvictions++
	}
	return stw
}

func reachable(o *Obj, store map[int]*Obj, roots map[int]bool) bool {
	if roots[o.ID] {
		return true
	}
	seen := map[int]bool{o.ID: true}
	stack := append([]int(nil), o.Refs...)
	for len(stack) > 0 {
		id := stack[len(stack)-1]
		stack = stack[:len(stack)-1]
		if seen[id] {
			continue
		}
		seen[id] = true
		if roots[id] {
			return true
		}
		t := store[id]
		if t == nil || !t.Alive {
			continue
		}
		if t.Lane == 1 {
			return true
		}
		stack = append(stack, t.Refs...)
	}
	return false
}
