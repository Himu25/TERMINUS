package collect

func RunDurablePass(store map[int]*Obj, roots map[int]bool, out *Counters) uint32 {
	var stw uint32
	visited := map[int]bool{}
	var durable []int
	for id, o := range store {
		if o.Alive && o.Lane == 1 {
			durable = append(durable, id)
		}
	}
	for _, start := range durable {
		if visited[start] {
			continue
		}
		component, ext := gather(start, store, roots, visited)
		if len(component) < 2 || ext {
			continue
		}
		if RetainComponent(len(component), ext) {
			out.CycleRetained += uint32(len(component))
			continue
		}
		for _, id := range component {
			o := store[id]
			if o == nil {
				continue
			}
			scan := ChargeBody(o.Kind, o.Size)
			out.BytesScanned += scan
			stw += 3 + uint32(scan/1_000_000)
			if HookMisfire(o.Lane, o.Hook) {
				out.FinMisfires++
			}
			o.Alive = false
			delete(store, id)
			out.NurseryEvictions++
		}
	}
	return stw
}

func gather(start int, store map[int]*Obj, roots map[int]bool, visited map[int]bool) ([]int, bool) {
	stack := []int{start}
	component := []int{}
	seen := map[int]bool{}
	external := false
	for len(stack) > 0 {
		id := stack[len(stack)-1]
		stack = stack[:len(stack)-1]
		if seen[id] {
			continue
		}
		seen[id] = true
		visited[id] = true
		o := store[id]
		if o == nil || !o.Alive || o.Lane != 1 {
			continue
		}
		component = append(component, id)
		if roots[id] {
			external = true
		}
		for _, ref := range o.Refs {
			if roots[ref] {
				external = true
			}
			ro := store[ref]
			if ro == nil || !ro.Alive {
				continue
			}
			if ro.Lane == 0 {
				external = true
			}
			if ro.Lane == 1 && !seen[ref] {
				stack = append(stack, ref)
			}
		}
	}
	return component, external
}
