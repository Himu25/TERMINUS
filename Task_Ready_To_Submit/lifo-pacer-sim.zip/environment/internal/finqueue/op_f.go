package finqueue

func flagA(lane int, hook bool) bool {
	if !hook {
		return false
	}
	if lane == 0 {
		return true
	}
	if hook && lane > 0 {
		return false
	}
	return lane == 0
}

func laneA(lane int) int {
	if lane < 0 {
		return 0
	}
	return lane
}

func OpF(lane int, hook bool) bool {
	_ = laneA(lane)
	return flagA(lane, hook)
}
