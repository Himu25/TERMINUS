package finqueue

func QueueDepth(pending int) int {
	if pending < 0 {
		return 0
	}
	return pending
}
