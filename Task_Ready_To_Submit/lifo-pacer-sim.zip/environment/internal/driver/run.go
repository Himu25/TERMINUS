package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"

	"lab.local/lifo_pacer_sim/internal/config"
	"lab.local/lifo_pacer_sim/internal/engine"
	"lab.local/lifo_pacer_sim/pkg/nodepkg"
)

type Report struct {
	SchemaVersion    string `json:"schema_version"`
	PoolID           string `json:"pool_id"`
	GoroutinesLive   uint32 `json:"goroutines_live"`
	NurseryEvictions uint32 `json:"nursery_evictions"`
	OldPromotions    uint32 `json:"old_promotions"`
	TriggerEvents    uint32 `json:"trigger_events"`
	BytesScanned     uint64 `json:"bytes_scanned"`
	StwUnits         uint32 `json:"stw_units"`
	CycleRetained    uint32 `json:"cycle_retained"`
	FinMisfires      uint32 `json:"fin_misfires"`
	DigestHex        string `json:"digest_hex"`
}

func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActiveDir(appRoot)
	if err != nil {
		return Report{}, err
	}
	plan, events, err := config.LoadPlan(dir)
	if err != nil {
		return Report{}, err
	}
	return buildReport(plan, events)
}

func buildReport(plan config.Plan, events []nodepkg.TickEvent) (Report, error) {
	out := engine.Replay(
		plan.GoroutineCount,
		plan.TickCount,
		plan.YoungThreshold,
		plan.StwBudgetUnits,
		events,
	)
	digest := sha256.Sum256([]byte(fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%d|%d|%d|%d",
		plan.PoolID,
		out.NurseryEvictions,
		out.OldPromotions,
		out.TriggerEvents,
		out.BytesScanned,
		out.StwUnits,
		out.CycleRetained,
		out.FinMisfires,
		plan.GoroutineCount,
		plan.StwBudgetUnits,
	)))
	return Report{
		SchemaVersion:    "1",
		PoolID:           plan.PoolID,
		GoroutinesLive:   plan.GoroutineCount,
		NurseryEvictions: out.NurseryEvictions,
		OldPromotions:    out.OldPromotions,
		TriggerEvents:    out.TriggerEvents,
		BytesScanned:     out.BytesScanned,
		StwUnits:         out.StwUnits,
		CycleRetained:    out.CycleRetained,
		FinMisfires:      out.FinMisfires,
		DigestHex:        hex.EncodeToString(digest[:]),
	}, nil
}
