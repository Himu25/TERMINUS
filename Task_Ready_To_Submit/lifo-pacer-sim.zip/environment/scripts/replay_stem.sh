#!/bin/bash
set -euo pipefail

stem="${1:-}"
if [ -z "$stem" ]; then
  echo "usage: replay_stem.sh <stem_name>" >&2
  exit 2
fi

src="/app/data/regression/${stem}"
dst="/app/data/active"
rm -rf "${dst}"
mkdir -p "${dst}"
cp "${src}/workload_plan.json" "${dst}/"
cp "${src}/trace.jsonl" "${dst}/"
export TB_PACER_FIXTURE=1
/app/bin/pacer_lab
