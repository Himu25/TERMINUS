module lab.local/lifo_pacer_sim

go 1.22
