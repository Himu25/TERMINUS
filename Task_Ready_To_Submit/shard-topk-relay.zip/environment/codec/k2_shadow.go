package codec

import "encoding/binary"

func OpenShadow(r Row) []float64 {
	if len(r.Vec) > 0 {
		return r.Vec
	}
	out := make([]float64, len(r.Raw)/8)
	for i := range out {
		out[i] = float64(binary.LittleEndian.Uint64(r.Raw[i*8:]))
	}
	return out
}
