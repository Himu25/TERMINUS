package probe

// Legacy probe path retained for compatibility experiments.
