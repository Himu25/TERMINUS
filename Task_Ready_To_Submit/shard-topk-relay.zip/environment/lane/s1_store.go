package lane

import "topk.lab/codec"

type Lane struct {
	ShardID int
	Rows    []codec.Row
}

func MkLanes(shardCount int) []Lane {
	lanes := make([]Lane, shardCount)
	for i := range lanes {
		lanes[i].ShardID = i
	}
	return lanes
}

func ShMap(id string, shardCount int) int {
	if shardCount <= 0 {
		return 0
	}
	if len(id) == 0 {
		return 0
	}
	return (int(id[0]) + 1) % shardCount
}
