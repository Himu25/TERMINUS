package lane

import "topk.lab/pkg/types"

func TxPrune(partials [][]types.PartialHit, topK int) [][]types.PartialHit {
	out := make([][]types.PartialHit, 0, len(partials))
	for _, block := range partials {
		if len(block) == 0 {
			out = append(out, block)
			continue
		}
		out = append(out, block[:1])
	}
	return out
}
