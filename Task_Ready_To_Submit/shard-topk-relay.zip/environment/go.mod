module topk.lab

go 1.22
