package bench

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"

	"topk.lab/codec"
	"topk.lab/corpus"
	"topk.lab/embed"
	"topk.lab/lane"
	"topk.lab/pkg/types"
)

func LoadCfg(path string) (types.ClusterCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.ClusterCfg{}, err
	}
	cfg := types.ClusterCfg{CorpusPath: corpus.DefaultCorpusPath}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "vector_dim":
			fmt.Sscanf(val, "%d", &cfg.VectorDim)
		case "shard_count":
			fmt.Sscanf(val, "%d", &cfg.ShardCount)
		case "top_k":
			fmt.Sscanf(val, "%d", &cfg.TopK)
		case "recall_floor":
			fmt.Sscanf(val, "%f", &cfg.RecallFloor)
		case "ndcg_floor":
			fmt.Sscanf(val, "%f", &cfg.NdcgFloor)
		case "max_mean_shard_units":
			fmt.Sscanf(val, "%d", &cfg.MaxMeanShardUnits)
		case "max_mean_merge_units":
			fmt.Sscanf(val, "%d", &cfg.MaxMeanMergeUnits)
		case "max_p95_query_units":
			fmt.Sscanf(val, "%d", &cfg.MaxP95QueryUnits)
		case "failover_recall_floor":
			fmt.Sscanf(val, "%f", &cfg.FailoverRecallFloor)
		case "tight_security_recall_floor":
			fmt.Sscanf(val, "%f", &cfg.TightSecurityRecall)
		case "corpus_path":
			cfg.CorpusPath = val
		}
	}
	return cfg, nil
}

func LoadQueries(path string) ([]types.QueryCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.QueryCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var qc types.QueryCase
		if err := json.Unmarshal([]byte(line), &qc); err != nil {
			return nil, err
		}
		out = append(out, qc)
	}
	return out, sc.Err()
}

func BuildLanes(docs []types.Doc, cfg types.ClusterCfg) []lane.Lane {
	lanes := lane.MkLanes(cfg.ShardCount)
	for _, doc := range docs {
		vec := embed.VecFromText(doc.Text, cfg.VectorDim)
		sid := lane.ShMap(doc.ID, cfg.ShardCount)
		lanes[sid].Rows = append(lanes[sid].Rows, codec.VkStore(doc.ID, vec))
	}
	return lanes
}

func Run(cfg types.ClusterCfg, cases []types.QueryCase) (types.BenchReport, error) {
	if override := os.Getenv("TB_CORPUS_PATH"); override != "" {
		cfg.CorpusPath = override
	}
	docs, err := corpus.Load(cfg.CorpusPath)
	if err != nil {
		return types.BenchReport{}, err
	}
	lanes := BuildLanes(docs, cfg)
	report := types.BenchReport{
		Status:        "ok",
		CorpusVectors: len(docs),
		VectorDim:     cfg.VectorDim,
		ShardCount:    cfg.ShardCount,
		QueriesTotal:  len(cases),
	}
	var sumRecall, sumNdcg, sumShard, sumMerge float64
	queryUnits := make([]int, 0, len(cases))
	report.Queries = make([]types.QueryRow, 0, len(cases))
	for _, qc := range cases {
		qv := embed.VecFromText(embed.QxPrep(qc.Query), cfg.VectorDim)
		partials := FanoutPartials(qv, lanes, qc.DeadShards, cfg.TopK)
		merged, mergeU := FoldTopK(partials, cfg.TopK)
		shardU := ProbeUnits(lanes, cfg.VectorDim, qc.DeadShards)
		queryU := shardU + mergeU
		topIDs := make([]string, 0, len(merged))
		for _, hit := range merged {
			topIDs = append(topIDs, hit.DocID)
		}
		recall, ndcg, hits := rankScores(qc.GoldIDs, topIDs, cfg.TopK)
		row := types.QueryRow{
			QueryID:       qc.QueryID,
			RecallAt10:    round4(recall),
			NdcgAt10:      round4(ndcg),
			GoldHits:      hits,
			ShardUnits:    shardU,
			MergeUnits:    mergeU,
			QueryUnits:    queryU,
			ShardsQueried: len(partials),
			TopIDs:        topIDs,
		}
		report.Queries = append(report.Queries, row)
		sumRecall += recall
		sumNdcg += ndcg
		sumShard += float64(shardU)
		sumMerge += float64(mergeU)
		queryUnits = append(queryUnits, queryU)
	}
	n := float64(len(cases))
	if n > 0 {
		report.MeanRecallAt10 = round4(sumRecall / n)
		report.MeanNdcgAt10 = round4(sumNdcg / n)
		report.MeanShardUnits = round4(sumShard / n)
		report.MeanMergeUnits = round4(sumMerge / n)
	}
	report.P95QueryUnits = p95(queryUnits)
	if !meetsFloors(cfg, report) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func meetsFloors(cfg types.ClusterCfg, report types.BenchReport) bool {
	if report.MeanRecallAt10 < cfg.RecallFloor {
		return false
	}
	if report.MeanNdcgAt10 < cfg.NdcgFloor {
		return false
	}
	if int(report.MeanShardUnits) > cfg.MaxMeanShardUnits {
		return false
	}
	if int(report.MeanMergeUnits) > cfg.MaxMeanMergeUnits {
		return false
	}
	if report.P95QueryUnits > cfg.MaxP95QueryUnits {
		return false
	}
	return true
}

func rankScores(gold, got []string, k int) (recall float64, ndcg float64, hits int) {
	if len(gold) == 0 {
		return 0, 0, 0
	}
	goldSet := make(map[string]struct{}, len(gold))
	for _, id := range gold {
		goldSet[id] = struct{}{}
	}
	if k <= 0 {
		k = len(got)
	}
	if k > len(got) {
		k = len(got)
	}
	rel := make([]float64, 0, k)
	for i := 0; i < k; i++ {
		if _, ok := goldSet[got[i]]; ok {
			hits++
			rel = append(rel, 1.0)
		} else {
			rel = append(rel, 0.0)
		}
	}
	recall = float64(hits) / float64(len(gold))
	var dcg, idcg float64
	for i, r := range rel {
		if r > 0 {
			dcg += r / math.Log2(float64(i+2))
		}
	}
	sort.Strings(gold)
	ideal := make([]float64, 0, len(gold))
	for i := 0; i < len(gold) && i < k; i++ {
		ideal = append(ideal, 1.0)
	}
	for i, r := range ideal {
		if r > 0 {
			idcg += r / math.Log2(float64(i+2))
		}
	}
	if idcg > 0 {
		ndcg = dcg / idcg
	}
	return recall, ndcg, hits
}

func p95(values []int) int {
	if len(values) == 0 {
		return 0
	}
	cp := append([]int(nil), values...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

type digestPayload struct {
	Status         string           `json:"status"`
	CorpusVectors  int              `json:"corpus_vectors"`
	VectorDim      int              `json:"vector_dim"`
	ShardCount     int              `json:"shard_count"`
	QueriesTotal   int              `json:"queries_total"`
	MeanRecallAt10 float64          `json:"mean_recall_at_10"`
	MeanNdcgAt10   float64          `json:"mean_ndcg_at_10"`
	MeanShardUnits float64          `json:"mean_shard_units"`
	MeanMergeUnits float64          `json:"mean_merge_units"`
	P95QueryUnits  int              `json:"p95_query_units"`
	ReportDigest   string           `json:"report_digest"`
	Queries        []types.QueryRow `json:"queries"`
}

func digestBody(report types.BenchReport) string {
	payload := digestPayload{
		Status:         report.Status,
		CorpusVectors:  report.CorpusVectors,
		VectorDim:      report.VectorDim,
		ShardCount:     report.ShardCount,
		QueriesTotal:   report.QueriesTotal,
		MeanRecallAt10: report.MeanRecallAt10,
		MeanNdcgAt10:   report.MeanNdcgAt10,
		MeanShardUnits: report.MeanShardUnits,
		MeanMergeUnits: report.MeanMergeUnits,
		P95QueryUnits:  report.P95QueryUnits,
		ReportDigest:   "",
		Queries:        report.Queries,
	}
	raw, err := marshalDigestJSON(payload)
	if err != nil {
		return ""
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func marshalDigestJSON(payload digestPayload) ([]byte, error) {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return nil, err
	}
	b := buf.Bytes()
	if n := len(b); n > 0 && b[n-1] == '\n' {
		b = b[:n-1]
	}
	return b, nil
}

func WriteReport(path string, report types.BenchReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}
