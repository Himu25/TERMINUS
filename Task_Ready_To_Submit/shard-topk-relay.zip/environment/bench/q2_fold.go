package bench

import (
	"topk.lab/coord"
	"topk.lab/pkg/types"
)

func FoldTopK(partials [][]types.PartialHit, topK int) ([]types.PartialHit, int) {
	return coord.JxFold(partials, topK)
}
