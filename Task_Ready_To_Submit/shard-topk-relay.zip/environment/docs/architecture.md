# Architecture notes

Corpus JSON is embedded, partitioned across shard lanes, scored per active partition, shaped before global merge, then folded into a final top-k list. The coordinator fold path must still invoke partial-list shaping before global merge; repair that stage in place rather than removing it from the call chain. Partition placement follows `stable-mod` in `/app/registry/shard_manifest.json`: FNV-1a 32-bit over each document id's UTF-8 bytes, reduced modulo shard count (same mapping bench lane loading and `ShMap` must use).

Query-label regeneration runs via `/app/bin/lbgen` built from `cmd/lbgen`. The bench driver applies `embed.QxPrep` before embedding; lbgen must use that same preparation on query text. Gold ids are chosen by scoring every corpus document directly with text embeddings from each document's text field and sorting by dot product — a full-corpus pass independent of fanout, prune, merge, and packed lane row decode. Do not produce gold rows by calling the distributed retrieval coordinator path or by reading stored codec vectors; labels must stay fixed when retrieval profiles change.

`/app/output/search_bench.json` top-level keys: status, corpus_vectors, vector_dim, shard_count, queries_total, mean_recall_at_10, mean_ndcg_at_10, mean_shard_units, mean_merge_units, p95_query_units, report_digest, queries. status is ok when cluster.toml guardrails pass, otherwise fail — no other status strings.

Each queries row: query_id, recall_at_10, ndcg_at_10, gold_hits, shard_units, merge_units, query_units, shards_queried, top_ids. Ranking metrics are between zero and one; gold_hits is non-negative. Unit fields are synthetic cost tallies, not wall-clock timings. query_units equals shard_units plus merge_units.

Digest covers every report field except report_digest, serialized as compact JSON with report_digest set to an empty string. benchd computes the digest from that payload before writing the indented report file; do not hash the pretty-printed file or recompute from hand-edited means.

The bench driver assigns shard_units through `bench/q3_units.go`, which delegates to the node package for partition cost accounting. Quality gates compare means against floors and ceilings in cluster.toml. Failover packs list dead_shards per query; only active partitions may be queried.

Gold-label regeneration must apply the same query normalization as the bench driver so regenerated labels score higher recall than raw-text labels on the same corpus.
