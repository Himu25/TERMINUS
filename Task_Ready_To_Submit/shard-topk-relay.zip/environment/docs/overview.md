Coordinator fan-out lab for distributed embedding search.

Bench driver rebuilds gold ids then runs partitioned retrieval.
