Rebuild benchd after Go changes. Regenerate queries jsonl when corpus or specs change.

Run /app/tools/run_bench with query jsonl and output path. Pack and ablation regressions write bench_pack_failover.json, bench_pack_skew.json, bench_pack_tight.json, bench_pack_multi_dead.json, bench_ablation_fan.json, bench_ablation_rank.json, bench_ablation_bank.json, bench_ablation_join.json, bench_ablation_cost.json, bench_ablation_route.json, and bench_ablation_prune.json under /app/output/.
