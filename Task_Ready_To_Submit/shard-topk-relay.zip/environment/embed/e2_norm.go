package embed

import (
	"os"
	"strings"
)

var stopSet = map[string]struct{}{}

func init() {
	raw, err := os.ReadFile("/app/config/stopwords.txt")
	if err != nil {
		return
	}
	for _, tok := range strings.Fields(string(raw)) {
		stopSet[strings.ToLower(tok)] = struct{}{}
	}
}

func QxPrep(text string) string {
	parts := strings.Fields(strings.ToLower(text))
	if len(parts) == 0 {
		return text
	}
	kept := make([]string, 0, len(parts))
	for _, p := range parts {
		if _, drop := stopSet[p]; drop {
			continue
		}
		kept = append(kept, p)
	}
	if len(kept) == 0 {
		return strings.Join(parts, " ")
	}
	return strings.Join(kept, " ")
}
