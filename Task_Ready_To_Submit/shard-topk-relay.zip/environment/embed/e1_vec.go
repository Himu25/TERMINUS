package embed

import (
	"hash/fnv"
	"math"
)

func VecFromText(text string, dim int) []float64 {
	if dim <= 0 {
		dim = 32
	}
	out := make([]float64, dim)
	h := fnv.New64a()
	_, _ = h.Write([]byte(text))
	seed := h.Sum64()
	for i := 0; i < dim; i++ {
		seed = seed*6364136223846793005 + 1442695040888963407
		v := float64(int64(seed>>33)%1000) / 500.0
		out[i] = v - 1.0
	}
	norm := 0.0
	for _, x := range out {
		norm += x * x
	}
	if norm > 0 {
		inv := 1.0 / math.Sqrt(norm)
		for i := range out {
			out[i] *= inv
		}
	}
	return out
}

func Dot(a, b []float64) float64 {
	n := len(a)
	if len(b) < n {
		n = len(b)
	}
	var s float64
	for i := 0; i < n; i++ {
		s += a[i] * b[i]
	}
	return s
}
