package net

// Placeholder for future RPC transport experiments.
