Helper scripts live under /app/tools.
