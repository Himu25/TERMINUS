package types

type Doc struct {
	ID   string `json:"id"`
	Text string `json:"text"`
}

type Corpus struct {
	Vectors []Doc `json:"vectors"`
}

type QueryCase struct {
	QueryID    string   `json:"query_id"`
	Query      string   `json:"query"`
	GoldIDs    []string `json:"gold_ids,omitempty"`
	DeadShards []int    `json:"dead_shards,omitempty"`
}

type QueryRow struct {
	QueryID       string   `json:"query_id"`
	RecallAt10    float64  `json:"recall_at_10"`
	NdcgAt10      float64  `json:"ndcg_at_10"`
	GoldHits      int      `json:"gold_hits"`
	ShardUnits    int      `json:"shard_units"`
	MergeUnits    int      `json:"merge_units"`
	QueryUnits    int      `json:"query_units"`
	ShardsQueried int      `json:"shards_queried"`
	TopIDs        []string `json:"top_ids"`
}

type BenchReport struct {
	Status         string     `json:"status"`
	CorpusVectors  int        `json:"corpus_vectors"`
	VectorDim      int        `json:"vector_dim"`
	ShardCount     int        `json:"shard_count"`
	QueriesTotal   int        `json:"queries_total"`
	MeanRecallAt10 float64    `json:"mean_recall_at_10"`
	MeanNdcgAt10   float64    `json:"mean_ndcg_at_10"`
	MeanShardUnits float64    `json:"mean_shard_units"`
	MeanMergeUnits float64    `json:"mean_merge_units"`
	P95QueryUnits  int        `json:"p95_query_units"`
	ReportDigest   string     `json:"report_digest"`
	Queries        []QueryRow `json:"queries"`
}

type ClusterCfg struct {
	VectorDim              int
	ShardCount             int
	TopK                   int
	RecallFloor            float64
	NdcgFloor              float64
	MaxMeanShardUnits      int
	MaxMeanMergeUnits      int
	MaxP95QueryUnits       int
	FailoverRecallFloor    float64
	TightSecurityRecall    float64
	CorpusPath             string
}

type PartialHit struct {
	DocID string
	Score float64
	Shard int
}
