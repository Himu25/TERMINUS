package coord

import (
	"sort"

	"topk.lab/pkg/types"
)

func MxStitch(partials [][]types.PartialHit, topK int) []types.PartialHit {
	flat := make([]types.PartialHit, 0)
	for _, block := range partials {
		flat = append(flat, block...)
	}
	sort.Slice(flat, func(i, j int) bool {
		return flat[i].DocID < flat[j].DocID
	})
	if topK <= 0 || topK > len(flat) {
		topK = len(flat)
	}
	return flat[:topK]
}
