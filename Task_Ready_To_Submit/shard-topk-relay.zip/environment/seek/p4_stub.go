package seek

// Legacy seek path retained for compatibility experiments.
