package lane

import "topk.lab/pkg/types"

func TxPrune(partials [][]types.PartialHit, topK int) [][]types.PartialHit {
	return partials
}
