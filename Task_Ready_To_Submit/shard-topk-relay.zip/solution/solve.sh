#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight: distributed top-k workspace"
require_file /app/go.mod
require_file /app/config/cluster.toml
require_file /app/config/stopwords.txt
require_file /app/data/corpus_default.json
require_file /app/data/query_specs.jsonl
mkdir -p /app/bin /app/output

log "survey: guardrails and subsystem layout"
grep -nE 'recall|shard_units|failover|billing|stopword' \
  /app/config/cluster.toml /app/metrics/guardrails.txt /app/policies/relay_policy.txt 2>/dev/null | head -n 20 || true
wc -l /app/coord/c1_fan.go /app/lane/l2_rank.go /app/coord/c2_join.go /app/node/n9_cost.go /app/codec/c0_bank.go

log "restore little-endian packed row decode"
cp "${ROOT_DIR}/oracle/c0_bank.go" /app/codec/c0_bank.go

log "restore stable document-to-partition routing"
cp "${ROOT_DIR}/oracle/s1_store.go" /app/lane/s1_store.go

log "install multi-partition fan-out picker"
cp "${ROOT_DIR}/oracle/c1_fan.go" /app/coord/c1_fan.go

log "install per-partition partial ranker"
cp "${ROOT_DIR}/oracle/l2_rank.go" /app/lane/l2_rank.go

log "restore full partial lists before global merge"
cp "${ROOT_DIR}/oracle/l3_prune.go" /app/lane/l3_prune.go

log "install global merge stage"
cp "${ROOT_DIR}/oracle/c2_join.go" /app/coord/c2_join.go

log "install synthetic probe unit tally"
cp "${ROOT_DIR}/oracle/n9_cost.go" /app/node/n9_cost.go

log "align gold regeneration with bench query preparation"
python3 - <<'PY'
from pathlib import Path
path = Path("/app/cmd/lbgen/main.go")
text = path.read_text()
needle = "embed.VecFromText(spec.Query, cfg.VectorDim)"
repl = "embed.VecFromText(embed.QxPrep(spec.Query), cfg.VectorDim)"
if needle not in text:
    raise SystemExit("lbgen query embedding site not found")
path.write_text(text.replace(needle, repl, 1))
PY

log "verify patched sources compile before gold regeneration"
go build -o /app/bin/lbgen ./cmd/lbgen

log "regenerate query gold ids with repaired distributed search path"
/app/bin/lbgen /app/data/corpus_default.json /app/data/query_specs.jsonl /app/data/queries_default.jsonl

log "rebuild bench driver and emit default search bench report"
go build -o /app/bin/benchd ./cmd/benchd
chmod +x /app/tools/run_bench
/app/tools/run_bench /app/data/queries_default.jsonl /app/output/search_bench.json

log "post-run validation against cluster.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/cluster.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k.endswith("_floor") or k.startswith("billing_"):
        cfg[k] = float(v)
    elif k.startswith("max_"):
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/search_bench.json").read_text())
assert report["status"] == "ok", report
assert report["mean_recall_at_10"] >= cfg["recall_floor"]
assert report["p95_query_units"] <= cfg["max_p95_query_units"]
bill = next(q for q in report["queries"] if q["query_id"] == "q_billing_refund")
assert bill["gold_hits"] >= int(cfg["billing_refund_min_gold_hits"])
assert bill["recall_at_10"] >= cfg["billing_refund_min_recall"]
fail = [q for q in report["queries"] if q["query_id"].startswith("q_failover")]
for row in fail:
    assert row["recall_at_10"] >= cfg["failover_recall_floor"], row
print("ok", report["mean_recall_at_10"], report["p95_query_units"], len(fail))
PY

log "oracle complete"
