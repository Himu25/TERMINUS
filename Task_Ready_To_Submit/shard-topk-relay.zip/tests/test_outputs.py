"""Validate /app/output/search_bench.json against cluster.toml guardrails.

Covers report schema, digest determinism, default-bundle quality floors,
failover and billing rows, alternate corpus/query packs, and ablations that
prove partial fixes cannot pass.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "search_bench.json"
CFG = APP / "config" / "cluster.toml"
RUNNER = APP / "tools" / "run_bench"
FIXTURES = Path(__file__).resolve().parent / "fixtures"
BUILD_TIMEOUT_SEC = 300

REPORT_KEYS = frozenset(
    {
        "status",
        "corpus_vectors",
        "vector_dim",
        "shard_count",
        "queries_total",
        "mean_recall_at_10",
        "mean_ndcg_at_10",
        "mean_shard_units",
        "mean_merge_units",
        "p95_query_units",
        "report_digest",
        "queries",
    }
)
QUERY_KEYS = frozenset(
    {
        "query_id",
        "recall_at_10",
        "ndcg_at_10",
        "gold_hits",
        "shard_units",
        "merge_units",
        "query_units",
        "shards_queried",
        "top_ids",
    }
)
def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "vector_dim": 32,
        "shard_count": 4,
        "top_k": 10,
        "recall_floor": 0.82,
        "ndcg_floor": 0.72,
        "max_mean_shard_units": 4200,
        "max_mean_merge_units": 180,
        "max_p95_query_units": 5200,
        "failover_recall_floor": 0.65,
        "tight_security_recall_floor": 0.5,
        "billing_refund_min_recall": 0.6667,
        "billing_refund_min_gold_hits": 2,
        "latency_skew_min_recall": 0.7,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in (
            "recall_floor",
            "ndcg_floor",
            "failover_recall_floor",
            "tight_security_recall_floor",
            "billing_refund_min_recall",
            "latency_skew_min_recall",
        ):
            cfg[key] = float(val)
        elif key == "billing_refund_min_gold_hits":
            cfg[key] = int(float(val))
        elif key in (
            "vector_dim",
            "shard_count",
            "top_k",
            "max_mean_shard_units",
            "max_mean_merge_units",
            "max_p95_query_units",
        ):
            cfg[key] = int(float(val))
    return cfg


def _round4(value: float) -> float:
    return round(value * 10000 + 0.5) / 10000


def _expected_means(rows: list[dict]) -> tuple[float, float, float, float]:
    if not rows:
        return 0.0, 0.0, 0.0, 0.0
    total = len(rows)
    recall = sum(row["recall_at_10"] for row in rows) / total
    ndcg = sum(row["ndcg_at_10"] for row in rows) / total
    shard_u = sum(row["shard_units"] for row in rows) / total
    merge_u = sum(row["merge_units"] for row in rows) / total
    return _round4(recall), _round4(ndcg), _round4(shard_u), _round4(merge_u)


def _digest_payload(report: dict) -> dict:
    return {
        "status": report["status"],
        "corpus_vectors": report["corpus_vectors"],
        "vector_dim": report["vector_dim"],
        "shard_count": report["shard_count"],
        "queries_total": report["queries_total"],
        "mean_recall_at_10": report["mean_recall_at_10"],
        "mean_ndcg_at_10": report["mean_ndcg_at_10"],
        "mean_shard_units": report["mean_shard_units"],
        "mean_merge_units": report["mean_merge_units"],
        "p95_query_units": report["p95_query_units"],
        "report_digest": "",
        "queries": report["queries"],
    }


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _assert_query_row(row: dict) -> None:
    assert set(row) == QUERY_KEYS
    assert isinstance(row["query_id"], str) and row["query_id"]
    assert isinstance(row["recall_at_10"], (int, float))
    assert isinstance(row["ndcg_at_10"], (int, float))
    assert isinstance(row["gold_hits"], int)
    assert isinstance(row["shard_units"], int)
    assert isinstance(row["merge_units"], int)
    assert isinstance(row["query_units"], int)
    assert isinstance(row["shards_queried"], int)
    assert isinstance(row["top_ids"], list)
    assert 0.0 <= float(row["recall_at_10"]) <= 1.0
    assert 0.0 <= float(row["ndcg_at_10"]) <= 1.0
    assert row["gold_hits"] >= 0
    assert row["shard_units"] >= 0
    assert row["merge_units"] >= 0
    assert row["query_units"] == row["shard_units"] + row["merge_units"]
    assert row["shards_queried"] >= 0
    for doc_id in row["top_ids"]:
        assert isinstance(doc_id, str) and doc_id


def _assert_report_schema(data: dict) -> None:
    assert set(data) == REPORT_KEYS
    assert isinstance(data["status"], str) and data["status"] in {"ok", "fail"}
    for int_key in (
        "corpus_vectors",
        "vector_dim",
        "shard_count",
        "queries_total",
        "p95_query_units",
    ):
        assert isinstance(data[int_key], int), int_key
        assert data[int_key] >= 0, int_key
    for float_key in (
        "mean_recall_at_10",
        "mean_ndcg_at_10",
        "mean_shard_units",
        "mean_merge_units",
    ):
        assert isinstance(data[float_key], (int, float)), float_key
        assert float(data[float_key]) >= 0.0, float_key
    digest = data["report_digest"]
    assert isinstance(digest, str) and len(digest) == 64
    assert digest == digest.lower()
    assert re.fullmatch(r"[0-9a-f]{64}", digest)
    assert isinstance(data["queries"], list)
    for row in data["queries"]:
        _assert_query_row(row)


def _load_report(path: Path = OUT) -> dict:
    assert path.is_file(), f"missing report at {path}"
    data = json.loads(path.read_text(encoding="utf-8"))
    _assert_report_schema(data)
    return data


_STOPWORDS = frozenset({"the", "a", "an", "and", "or"})


def _fnv1a_64(data: bytes) -> int:
    digest = 14695981039346656037
    for byte in data:
        digest ^= byte
        digest = (digest * 1099511628211) & ((1 << 64) - 1)
    return digest


def _fnv32a(data: bytes) -> int:
    digest = 2166136261
    for byte in data:
        digest ^= byte
        digest = (digest * 16777619) & 0xFFFFFFFF
    return digest


def _shard_for_doc(doc_id: str, shard_count: int) -> int:
    if shard_count <= 0:
        return 0
    return _fnv32a(doc_id.encode("utf-8")) % shard_count


def _qx_prep(text: str) -> str:
    parts = text.lower().split()
    kept = [part for part in parts if part not in _STOPWORDS]
    if not kept:
        return " ".join(parts)
    return " ".join(kept)


def _vec_from_text(text: str, dim: int) -> list[float]:
    seed = _fnv1a_64(text.encode("utf-8"))
    out: list[float] = []
    for _ in range(dim):
        seed = (seed * 6364136223846793005 + 1442695040888963407) & ((1 << 64) - 1)
        out.append(((seed >> 33) % 1000) / 500.0 - 1.0)
    norm = sum(value * value for value in out) ** 0.5
    if norm > 0:
        out = [value / norm for value in out]
    return out


def _dot(a: list[float], b: list[float]) -> float:
    return sum(x * y for x, y in zip(a, b))


def _reference_top_gold_ids(
    corpus_path: Path,
    query: str,
    *,
    use_prep: bool,
    dim: int,
    top_k: int,
) -> list[str]:
    payload = json.loads(corpus_path.read_text(encoding="utf-8"))
    vectors = payload["vectors"]
    qtext = _qx_prep(query) if use_prep else query
    qv = _vec_from_text(qtext, dim)
    scored = [
        (_dot(qv, _vec_from_text(doc["text"], dim)), doc["id"]) for doc in vectors
    ]
    scored.sort(key=lambda pair: pair[0], reverse=True)
    return [doc_id for _, doc_id in scored[:top_k]]


def _gold_ids_for(query_id: str, queries_path: Path) -> list[str]:
    for line in queries_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        if row["query_id"] == query_id:
            gold = row["gold_ids"]
            assert isinstance(gold, list) and gold
            return gold
    raise AssertionError(f"query_id {query_id} not found in {queries_path}")


def _rebuild_benchd(env: dict[str, str] | None = None) -> None:
    subprocess.run(
        ["go", "build", "-o", "/app/bin/benchd", "./cmd/benchd"],
        cwd=APP,
        env=env or os.environ.copy(),
        check=True,
        capture_output=True,
        text=True,
        timeout=BUILD_TIMEOUT_SEC,
    )


def _restore_source(src: Path, backup: str) -> None:
    src.write_text(backup, encoding="utf-8")
    _rebuild_benchd()


def _labelsync(corpus_path: Path, specs_path: Path, out_path: Path) -> None:
    subprocess.run(
        [
            "/app/bin/lbgen",
            corpus_path.as_posix(),
            specs_path.as_posix(),
            out_path.as_posix(),
        ],
        check=True,
        capture_output=True,
        text=True,
    )


def _run_bench(
    query_path: Path,
    out_path: Path = OUT,
    corpus_path: Path | None = None,
    *,
    rebuild: bool = False,
) -> None:
    env = os.environ.copy()
    if corpus_path is not None:
        env["TB_CORPUS_PATH"] = str(corpus_path)
    else:
        env.pop("TB_CORPUS_PATH", None)
    if out_path.exists():
        out_path.unlink()
    if rebuild:
        _rebuild_benchd(env)
    subprocess.run(
        [
            "/app/bin/benchd",
            query_path.as_posix(),
            out_path.as_posix(),
        ],
        cwd=APP,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )


def _assert_ok_default(report: dict) -> None:
    cfg = _parse_cfg()
    assert report["status"] == "ok"
    assert report["mean_recall_at_10"] >= cfg["recall_floor"]
    assert report["mean_ndcg_at_10"] >= cfg["ndcg_floor"]
    assert report["mean_shard_units"] <= cfg["max_mean_shard_units"]
    assert report["mean_merge_units"] <= cfg["max_mean_merge_units"]
    assert report["p95_query_units"] <= cfg["max_p95_query_units"]


@pytest.fixture(scope="session", autouse=True)
def _default_bench_run() -> None:
    subprocess.run(
        ["go", "build", "-o", "/app/bin/lbgen", "./cmd/lbgen"],
        cwd=APP,
        check=True,
        capture_output=True,
        text=True,
        timeout=BUILD_TIMEOUT_SEC,
    )
    _rebuild_benchd()
    _labelsync(
        APP / "data" / "corpus_default.json",
        APP / "data" / "query_specs.jsonl",
        APP / "data" / "queries_default.jsonl",
    )
    _run_bench(APP / "data" / "queries_default.jsonl")


def test_runner_exists() -> None:
    """Documented bench driver is present and executable."""
    assert RUNNER.is_file() and os.access(RUNNER, os.X_OK)


def test_report_schema_keys() -> None:
    """search_bench.json exposes the contract field set only."""
    report = _load_report()
    _assert_ok_default(report)
    assert report["queries_total"] == len(report["queries"])


def test_per_query_row_keys() -> None:
    """Each queries[] row uses the documented sub-schema and valid metric ranges."""
    report = _load_report()
    _assert_ok_default(report)
    for row in report["queries"]:
        _assert_query_row(row)


def test_status_ok_and_mean_floors() -> None:
    """Default bundle clears recall, ndcg, and unit ceilings with status ok."""
    _assert_ok_default(_load_report())


def test_unit_budgets_within_caps() -> None:
    """Synthetic shard, merge, and p95 query units stay under cluster.toml ceilings."""
    report = _load_report()
    cfg = _parse_cfg()
    assert report["status"] == "ok"
    assert report["mean_shard_units"] <= cfg["max_mean_shard_units"]
    assert report["mean_merge_units"] <= cfg["max_mean_merge_units"]
    assert report["p95_query_units"] <= cfg["max_p95_query_units"]


def test_summary_means_recomputed_from_query_rows() -> None:
    """Mean recall, ndcg, and unit fields must match per-query rows."""
    report = _load_report()
    want_recall, want_ndcg, want_shard, want_merge = _expected_means(report["queries"])
    assert report["mean_recall_at_10"] == pytest.approx(want_recall, abs=2e-4)
    assert report["mean_ndcg_at_10"] == pytest.approx(want_ndcg, abs=2e-4)
    assert report["mean_shard_units"] == pytest.approx(want_shard, abs=2e-4)
    assert report["mean_merge_units"] == pytest.approx(want_merge, abs=2e-4)


def test_p95_query_units_matches_rows() -> None:
    """p95_query_units is the 95th percentile of per-query query_units."""
    report = _load_report()
    units = sorted(row["query_units"] for row in report["queries"])
    idx = max(0, int(len(units) * 0.95 + 0.999999) - 1)
    assert report["p95_query_units"] == units[idx]


def test_merge_units_weight_formula() -> None:
    """merge_units follows top_k * (shards_queried + 1) for each query row."""
    report = _load_report()
    cfg = _parse_cfg()
    top_k = int(cfg["top_k"])
    for row in report["queries"]:
        want = top_k * (row["shards_queried"] + 1)
        assert row["merge_units"] == want


def test_report_digest_format() -> None:
    """report_digest is 64-char lowercase hex."""
    digest = _load_report()["report_digest"]
    assert len(digest) == 64
    assert digest == digest.lower()
    assert re.fullmatch(r"[0-9a-f]{64}", digest)


def test_report_digest_matches_body() -> None:
    """report_digest is SHA-256 of the compact pre-digest payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_repeat_run_byte_identical() -> None:
    """Back-to-back default runs emit identical report bytes."""
    _assert_ok_default(_load_report())
    first = OUT.read_bytes()
    _run_bench(APP / "data" / "queries_default.jsonl")
    second = OUT.read_bytes()
    assert first == second


def test_queries_total_matches_pack_line_count() -> None:
    """queries_total equals non-empty lines in the default query JSONL."""
    report = _load_report()
    expected = sum(
        1
        for line in (APP / "data" / "queries_default.jsonl")
        .read_text(encoding="utf-8")
        .splitlines()
        if line.strip()
    )
    assert report["queries_total"] == expected
    assert len(report["queries"]) == expected


def test_corpus_vectors_matches_manifest() -> None:
    """corpus_vectors and vector_dim track the shard manifest."""
    report = _load_report()
    manifest = json.loads((APP / "registry" / "shard_manifest.json").read_text(encoding="utf-8"))
    assert report["corpus_vectors"] == manifest["count"]
    assert report["vector_dim"] == manifest["dim"]
    assert report["shard_count"] == manifest["shards"]


def test_q_billing_refund_recall_floor() -> None:
    """q_billing_refund must recover most gold neighbors and match recall accounting."""
    report = _load_report()
    cfg = _parse_cfg()
    queries_path = APP / "data" / "queries_default.jsonl"
    gold_ids = _gold_ids_for("q_billing_refund", queries_path)
    row = next(r for r in report["queries"] if r["query_id"] == "q_billing_refund")
    assert row["gold_hits"] >= cfg["billing_refund_min_gold_hits"]
    assert row["recall_at_10"] >= cfg["billing_refund_min_recall"]
    assert row["recall_at_10"] == pytest.approx(
        row["gold_hits"] / len(gold_ids),
        abs=2e-4,
    )


def test_q_search_ann_ndcg_floor() -> None:
    """q_search_ann ndcg must be positive once ranking is repaired."""
    report = _load_report()
    cfg = _parse_cfg()
    row = next(r for r in report["queries"] if r["query_id"] == "q_search_ann")
    assert row["ndcg_at_10"] >= cfg["ndcg_floor"] / (2 * cfg["top_k"])


def test_q_latency_skew_recall_floor() -> None:
    """q_latency_skew must clear the latency skew recall floor from cluster.toml."""
    report = _load_report()
    cfg = _parse_cfg()
    row = next(r for r in report["queries"] if r["query_id"] == "q_latency_skew")
    assert row["recall_at_10"] >= cfg["latency_skew_min_recall"]


def test_query_rows_preserve_input_order() -> None:
    """queries[] row order matches non-empty lines in the input JSONL pack."""
    report = _load_report()
    order = [
        json.loads(line)["query_id"]
        for line in (APP / "data" / "queries_default.jsonl")
        .read_text(encoding="utf-8")
        .splitlines()
        if line.strip()
    ]
    assert [row["query_id"] for row in report["queries"]] == order


def test_failover_queries_skip_dead_shards() -> None:
    """Failover rows query only live lanes and clear the failover recall floor."""
    report = _load_report()
    cfg = _parse_cfg()
    specs = {
        json.loads(line)["query_id"]: json.loads(line).get("dead_shards", [])
        for line in (APP / "data" / "query_specs.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    }
    for row in report["queries"]:
        if not row["query_id"].startswith("q_failover"):
            continue
        dead = specs[row["query_id"]]
        assert row["shards_queried"] == cfg["shard_count"] - len(dead)
        assert row["recall_at_10"] >= cfg["failover_recall_floor"]
        assert row["shard_units"] < cfg["max_mean_shard_units"]


def test_q_cross_billing_ops_multi_gold_hits() -> None:
    """Cross-topic query should hit multiple gold ids and clear the billing recall floor."""
    report = _load_report()
    cfg = _parse_cfg()
    queries_path = APP / "data" / "queries_default.jsonl"
    gold_ids = _gold_ids_for("q_cross_billing_ops", queries_path)
    row = next(r for r in report["queries"] if r["query_id"] == "q_cross_billing_ops")
    assert row["gold_hits"] >= cfg["billing_refund_min_gold_hits"]
    assert row["recall_at_10"] >= cfg["billing_refund_min_recall"]
    assert row["recall_at_10"] == pytest.approx(
        row["gold_hits"] / len(gold_ids),
        abs=2e-4,
    )


def test_fixture_pack_failover_recall() -> None:
    """Failover fixture pack clears per-row failover recall floor."""
    pack = FIXTURES / "pack_failover"
    out = APP / "output" / "bench_pack_failover.json"
    cfg = _parse_cfg()
    queries = pack / "queries.jsonl"
    _labelsync(pack / "corpus.json", pack / "query_specs.jsonl", queries)
    _run_bench(queries, out, pack / "corpus.json")
    report = _load_report(out)
    assert report["status"] == "ok"
    for row in report["queries"]:
        assert row["recall_at_10"] >= cfg["failover_recall_floor"]


def test_fixture_pack_skew_queries_recall() -> None:
    """Skew query pack clears mean recall floor."""
    pack = FIXTURES / "pack_skew_queries"
    out = APP / "output" / "bench_pack_skew.json"
    cfg = _parse_cfg()
    queries = pack / "queries.jsonl"
    _labelsync(pack / "corpus.json", pack / "query_specs.jsonl", queries)
    _run_bench(queries, out, pack / "corpus.json")
    report = _load_report(out)
    assert report["status"] == "ok"
    assert report["mean_recall_at_10"] >= cfg["recall_floor"]


def test_goldgen_query_prep_required_for_recall() -> None:
    """Gold labels must use the same stopword preparation as the bench driver."""
    cfg = _parse_cfg()
    probe_query = "the billing refund chargeback dispute"
    probe_spec = APP / "output" / "probe_prep_spec.jsonl"
    probe_queries = APP / "output" / "probe_prep_queries.jsonl"
    probe_mismatch = APP / "output" / "probe_prep_queries_mismatch.jsonl"
    probe_out = APP / "output" / "bench_goldgen_prep_ablation.json"
    probe_out_mismatch = APP / "output" / "bench_goldgen_prep_mismatch.json"
    probe_id = "q_prep_probe"
    probe_spec.write_text(
        json.dumps(
            {
                "query_id": probe_id,
                "query": probe_query,
                "dead_shards": [],
            }
        )
        + "\n",
        encoding="utf-8",
    )
    corpus = APP / "data" / "corpus_default.json"
    dim = int(cfg["vector_dim"])
    top_k = int(cfg["top_k"])

    expected_prep_gold = _reference_top_gold_ids(
        corpus,
        probe_query,
        use_prep=True,
        dim=dim,
        top_k=top_k,
    )
    expected_raw_gold = _reference_top_gold_ids(
        corpus,
        probe_query,
        use_prep=False,
        dim=dim,
        top_k=top_k,
    )
    assert expected_prep_gold != expected_raw_gold

    _labelsync(corpus, probe_spec, probe_queries)
    generated = json.loads(
        probe_queries.read_text(encoding="utf-8").strip().splitlines()[0]
    )
    assert generated["gold_ids"] == expected_prep_gold

    mismatch_row = {
        "query_id": "q_prep_probe",
        "query": probe_query,
        "gold_ids": expected_raw_gold,
        "dead_shards": [],
    }
    probe_mismatch.write_text(
        json.dumps(mismatch_row) + "\n",
        encoding="utf-8",
    )

    _run_bench(probe_queries, probe_out)
    aligned = next(
        row
        for row in _load_report(probe_out)["queries"]
        if row["query_id"] == "q_prep_probe"
    )
    _run_bench(probe_mismatch, probe_out_mismatch)
    mismatched = next(
        row
        for row in _load_report(probe_out_mismatch)["queries"]
        if row["query_id"] == "q_prep_probe"
    )
    assert float(aligned["recall_at_10"]) >= 0.8
    assert float(aligned["recall_at_10"]) > float(mismatched["recall_at_10"]) + 0.05


def test_fixture_pack_multi_dead_recall() -> None:
    """Multi-dead fixture pack clears failover recall on every row."""
    pack = FIXTURES / "pack_multi_dead"
    out = APP / "output" / "bench_pack_multi_dead.json"
    cfg = _parse_cfg()
    queries = pack / "queries.jsonl"
    _labelsync(pack / "corpus.json", pack / "query_specs.jsonl", queries)
    _run_bench(queries, out, pack / "corpus.json")
    report = _load_report(out)
    assert report["status"] == "ok"
    for row in report["queries"]:
        assert row["recall_at_10"] >= cfg["failover_recall_floor"]


def test_fixture_pack_tight_recall_security_row() -> None:
    """Tight recall bundle clears security-query recall floor."""
    pack = FIXTURES / "pack_tight_recall"
    out = APP / "output" / "bench_pack_tight.json"
    cfg = _parse_cfg()
    queries = pack / "queries.jsonl"
    _labelsync(pack / "corpus.json", pack / "query_specs.jsonl", queries)
    _run_bench(queries, out, pack / "corpus.json")
    report = _load_report(out)
    assert report["status"] == "ok"
    sec = next(r for r in report["queries"] if r["query_id"] == "q_tight_security")
    assert sec["recall_at_10"] >= cfg["tight_security_recall_floor"]


def test_top_ids_length_capped_at_top_k() -> None:
    """Each query row returns at most top_k ranked document ids."""
    report = _load_report()
    cfg = _parse_cfg()
    top_k = int(cfg["top_k"])
    for row in report["queries"]:
        assert len(row["top_ids"]) <= top_k


def test_failover_top_ids_on_live_partitions_only() -> None:
    """Failover rows must return hits routed only to partitions not marked dead."""
    report = _load_report()
    cfg = _parse_cfg()
    shard_count = int(cfg["shard_count"])
    specs = {
        json.loads(line)["query_id"]: json.loads(line).get("dead_shards", [])
        for line in (APP / "data" / "query_specs.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    }
    dead_sets = {qid: set(dead) for qid, dead in specs.items()}
    for row in report["queries"]:
        if not row["query_id"].startswith("q_failover"):
            continue
        dead = dead_sets.get(row["query_id"], set())
        for doc_id in row["top_ids"]:
            shard = _shard_for_doc(doc_id, shard_count)
            assert shard not in dead


def test_gold_hits_never_exceed_top_k() -> None:
    """gold_hits cannot exceed the configured top_k cap."""
    report = _load_report()
    cfg = _parse_cfg()
    top_k = int(cfg["top_k"])
    for row in report["queries"]:
        assert row["gold_hits"] <= top_k


def test_ablation_fan_profile_fails_failover() -> None:
    """Alternate fan-out profile cannot clear failover recall on multi-shard gold."""
    fan_src = APP / "coord" / "c1_fan.go"
    backup = fan_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "profile_fan_limit.go").read_text(encoding="utf-8")
    out = APP / "output" / "bench_ablation_fan.json"
    cfg = _parse_cfg()
    try:
        fan_src.write_text(broken, encoding="utf-8")
        _run_bench(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        fail_rows = [r for r in report["queries"] if r["query_id"].startswith("q_failover")]
        assert any(r["recall_at_10"] < cfg["failover_recall_floor"] for r in fail_rows)
    finally:
        _restore_source(fan_src, backup)


def test_ablation_rank_profile_fails_recall() -> None:
    """Alternate rank profile cannot clear recall floor or status ok."""
    rank_src = APP / "lane" / "l2_rank.go"
    backup = rank_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "profile_rank_half.go").read_text(encoding="utf-8")
    out = APP / "output" / "bench_ablation_rank.json"
    cfg = _parse_cfg()
    try:
        rank_src.write_text(broken, encoding="utf-8")
        _run_bench(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        assert report["status"] == "fail"
        assert report["mean_recall_at_10"] < cfg["recall_floor"]
    finally:
        _restore_source(rank_src, backup)


def test_ablation_bank_profile_fails_recall() -> None:
    """Alternate packed-row decode profile cannot clear billing recall floor."""
    bank_src = APP / "codec" / "c0_bank.go"
    backup = bank_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "profile_bank_be.go").read_text(encoding="utf-8")
    out = APP / "output" / "bench_ablation_bank.json"
    cfg = _parse_cfg()
    try:
        bank_src.write_text(broken, encoding="utf-8")
        _run_bench(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        row = next(r for r in report["queries"] if r["query_id"] == "q_billing_refund")
        assert row["recall_at_10"] < cfg["billing_refund_min_recall"]
    finally:
        _restore_source(bank_src, backup)


def test_ablation_join_profile_fails_cross_topic() -> None:
    """Alternate global merge profile cannot clear cross-topic billing recall floor."""
    join_src = APP / "coord" / "c2_join.go"
    backup = join_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "profile_join_asc.go").read_text(encoding="utf-8")
    out = APP / "output" / "bench_ablation_join.json"
    cfg = _parse_cfg()
    try:
        join_src.write_text(broken, encoding="utf-8")
        _run_bench(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        row = next(r for r in report["queries"] if r["query_id"] == "q_cross_billing_ops")
        assert row["recall_at_10"] < cfg["billing_refund_min_recall"]
    finally:
        _restore_source(join_src, backup)


def test_ablation_cost_profile_exceeds_unit_caps() -> None:
    """Alternate unit tally profile blows p95 query units above cluster.toml ceiling."""
    cost_src = APP / "node" / "n9_cost.go"
    backup = cost_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "profile_cost_penalty.go").read_text(encoding="utf-8")
    out = APP / "output" / "bench_ablation_cost.json"
    cfg = _parse_cfg()
    try:
        cost_src.write_text(broken, encoding="utf-8")
        _run_bench(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        assert report["p95_query_units"] > cfg["max_p95_query_units"] or report["status"] == "fail"
    finally:
        _restore_source(cost_src, backup)


def test_ablation_route_profile_fails_failover() -> None:
    """Alternate document routing profile cannot clear multi-dead failover recall."""
    route_src = APP / "lane" / "s1_store.go"
    backup = route_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "profile_route_char.go").read_text(encoding="utf-8")
    out = APP / "output" / "bench_ablation_route.json"
    cfg = _parse_cfg()
    try:
        route_src.write_text(broken, encoding="utf-8")
        _labelsync(
            APP / "data" / "corpus_default.json",
            APP / "data" / "query_specs.jsonl",
            APP / "data" / "queries_default.jsonl",
        )
        _run_bench(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        multi = next(r for r in report["queries"] if r["query_id"] == "q_failover_multi")
        assert multi["recall_at_10"] < cfg["failover_recall_floor"]
    finally:
        route_src.write_text(backup, encoding="utf-8")
        _labelsync(
            APP / "data" / "corpus_default.json",
            APP / "data" / "query_specs.jsonl",
            APP / "data" / "queries_default.jsonl",
        )
        _rebuild_benchd()


def test_ablation_prune_profile_fails_failover() -> None:
    """Alternate partial-list shaping profile cannot clear failover recall floors."""
    prune_src = APP / "lane" / "l3_prune.go"
    backup = prune_src.read_text(encoding="utf-8")
    broken = (FIXTURES / "profile_prune_one.go").read_text(encoding="utf-8")
    out = APP / "output" / "bench_ablation_prune.json"
    cfg = _parse_cfg()
    try:
        prune_src.write_text(broken, encoding="utf-8")
        _run_bench(APP / "data" / "queries_default.jsonl", out, rebuild=True)
        report = _load_report(out)
        fail_rows = [r for r in report["queries"] if r["query_id"].startswith("q_failover")]
        assert any(r["recall_at_10"] < cfg["failover_recall_floor"] for r in fail_rows)
    finally:
        _restore_source(prune_src, backup)
