package coord

import "topk.lab/lane"

func LxPick(lanes []lane.Lane, dead []int) []lane.Lane {
	_ = dead
	if len(lanes) == 0 {
		return nil
	}
	return []lane.Lane{lanes[0]}
}
