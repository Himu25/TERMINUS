"""Verifier for /app/output/plugin_matrix.json."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
REPORT = APP / "output" / "plugin_matrix.json"
SCENARIOS = APP / "fixtures" / "scenarios"
SLOT_BIN = APP / "bin" / "slot"
MODS = ("echo_lane", "old_lane", "heap_lane", "dup_alpha", "dup_beta")

# Expected matrix rows after loader fixes (embedded in verifier; not agent-visible).
EXPECTED_ROWS: dict[str, dict] = {
    "basic_route": {
        "finish_reason": "complete",
        "loaded_count": 1,
        "route_reply": "PONG:ping",
        "leak_bytes": 0,
        "fork_child_ok": False,
        "reject_code": "",
        "sla_ok": True,
    },
    "legacy_row": {
        "finish_reason": "reject",
        "loaded_count": 0,
        "route_reply": "",
        "leak_bytes": 0,
        "fork_child_ok": False,
        "reject_code": "abi_mismatch",
        "sla_ok": True,
    },
    "heap_handoff": {
        "finish_reason": "complete",
        "loaded_count": 1,
        "route_reply": "HEAP:cell",
        "leak_bytes": 0,
        "fork_child_ok": False,
        "reject_code": "",
        "sla_ok": True,
    },
    "dup_pair": {
        "finish_reason": "reject",
        "loaded_count": 1,
        "route_reply": "",
        "leak_bytes": 0,
        "fork_child_ok": False,
        "reject_code": "symbol_conflict",
        "sla_ok": True,
    },
    "chain_row": {
        "finish_reason": "reject",
        "loaded_count": 1,
        "route_reply": "",
        "leak_bytes": 0,
        "fork_child_ok": False,
        "reject_code": "symbol_conflict",
        "sla_ok": True,
    },
    "fork_lane": {
        "finish_reason": "complete",
        "loaded_count": 1,
        "route_reply": "",
        "leak_bytes": 0,
        "fork_child_ok": True,
        "reject_code": "",
        "sla_ok": True,
    },
    "fork_heap": {
        "finish_reason": "complete",
        "loaded_count": 1,
        "route_reply": "",
        "leak_bytes": 0,
        "fork_child_ok": True,
        "reject_code": "",
        "sla_ok": True,
    },
    "wide_input": {
        "finish_reason": "complete",
        "loaded_count": 1,
        "route_reply": "PONG:wideping99",
        "leak_bytes": 0,
        "fork_child_ok": False,
        "reject_code": "",
        "sla_ok": True,
    },
}


def _env() -> dict[str, str]:
    return os.environ.copy()


def rebuild_binaries() -> None:
    subprocess.run(
        ["go", "build", "-o", "/app/matrix", "./cmd/matrix"],
        cwd=str(APP),
        check=True,
        env=_env(),
    )
    subprocess.run(
        ["cargo", "build", "--release"],
        cwd=str(APP),
        check=True,
        env=_env(),
    )
    for name in MODS:
        lib_dir = APP / "mods" / name / "lib"
        lib_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(
            APP / "target" / "release" / f"lib{name}.so",
            lib_dir / f"lib{name}.so",
        )
    (APP / "bin").mkdir(parents=True, exist_ok=True)
    shutil.copy2(APP / "target" / "release" / "slot", SLOT_BIN)


def run_matrix(out: Path | None = None) -> None:
    target = out or REPORT
    target.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        [
            "/app/matrix",
            "-scenarios",
            str(SCENARIOS),
            "-out",
            str(target),
        ],
        cwd=str(APP),
        check=True,
        env=_env(),
    )


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    rebuild_binaries()


@pytest.fixture()
def report() -> dict:
    run_matrix()
    return json.loads(REPORT.read_text())


def _scenario(report: dict, name: str) -> dict:
    for row in report["scenarios"]:
        if row["name"] == name:
            return row
    raise AssertionError(f"missing scenario {name!r}")


def test_report_schema(report: dict) -> None:
    """plugin_matrix.json matches the published contract."""
    assert isinstance(report, dict)
    rows = report["scenarios"]
    assert isinstance(rows, list) and len(rows) == 8
    names = sorted(r["name"] for r in rows)
    assert names == [
        "basic_route",
        "chain_row",
        "dup_pair",
        "fork_heap",
        "fork_lane",
        "heap_handoff",
        "legacy_row",
        "wide_input",
    ]
    for row in rows:
        assert set(row.keys()) >= {
            "name",
            "finish_reason",
            "loaded_count",
            "route_reply",
            "leak_bytes",
            "fork_child_ok",
            "reject_code",
            "sla_ok",
        }


def test_outcome_partition(report: dict) -> None:
    """Every bundled scenario completes routing or rejects with a code."""
    for name in (
        "basic_route",
        "heap_handoff",
        "fork_lane",
        "fork_heap",
        "wide_input",
    ):
        assert (
            _scenario(report, name)["finish_reason"]
            == EXPECTED_ROWS[name]["finish_reason"]
        )
    for name in ("legacy_row", "dup_pair", "chain_row"):
        assert (
            _scenario(report, name)["finish_reason"]
            == EXPECTED_ROWS[name]["finish_reason"]
        )


def test_echo_reply(report: dict) -> None:
    """Basic route returns the pong reply for ping input."""
    exp = EXPECTED_ROWS["basic_route"]
    row = _scenario(report, "basic_route")
    assert row["route_reply"] == exp["route_reply"]
    assert row["loaded_count"] == exp["loaded_count"]
    assert row["leak_bytes"] == 0
    assert row["sla_ok"] == EXPECTED_ROWS["basic_route"]["sla_ok"]


def test_revision_gate(report: dict) -> None:
    """Legacy wire revision is rejected before attach."""
    exp = EXPECTED_ROWS["legacy_row"]
    row = _scenario(report, "legacy_row")
    assert row["reject_code"] == exp["reject_code"]
    assert row["loaded_count"] == exp["loaded_count"]


def test_preserves_width(report: dict) -> None:
    """Wide payloads keep every byte through routing."""
    exp = EXPECTED_ROWS["wide_input"]
    row = _scenario(report, "wide_input")
    assert row["route_reply"] == exp["route_reply"]
    assert row["loaded_count"] == exp["loaded_count"]


def test_allocator_handoff(report: dict) -> None:
    """Heap payload is returned and fully released."""
    exp = EXPECTED_ROWS["heap_handoff"]
    row = _scenario(report, "heap_handoff")
    assert row["route_reply"] == exp["route_reply"]
    assert row["leak_bytes"] == exp["leak_bytes"]
    assert row["sla_ok"] == exp["sla_ok"]


def test_paired_collision(report: dict) -> None:
    """Paired modules with colliding entry symbols reject the second attach."""
    exp = EXPECTED_ROWS["dup_pair"]
    row = _scenario(report, "dup_pair")
    assert row["reject_code"] == exp["reject_code"]
    assert row["loaded_count"] == exp["loaded_count"]


def test_sequential_collision(report: dict) -> None:
    """Chained attach stops after the first module when the second entry collides."""
    exp = EXPECTED_ROWS["chain_row"]
    row = _scenario(report, "chain_row")
    assert row["reject_code"] == exp["reject_code"]
    assert row["loaded_count"] == exp["loaded_count"]
    assert row["route_reply"] == ""
    assert row["sla_ok"] == exp["sla_ok"]


def test_settlement_flags(report: dict) -> None:
    """Complete rows clear sla_ok once allocator debt is zero."""
    for name in ("basic_route", "heap_handoff", "wide_input", "fork_lane", "fork_heap"):
        assert _scenario(report, name)["sla_ok"] == EXPECTED_ROWS[name]["sla_ok"]


def test_fork_survival_echo(report: dict) -> None:
    """Forked worker finishes routing without tearing down the mapped module."""
    exp = EXPECTED_ROWS["fork_lane"]
    row = _scenario(report, "fork_lane")
    assert row["fork_child_ok"] is exp["fork_child_ok"]
    assert row["finish_reason"] == exp["finish_reason"]


def test_fork_survival_heap(report: dict) -> None:
    """Forked replay with a heap module keeps the worker alive through routing."""
    exp = EXPECTED_ROWS["fork_heap"]
    row = _scenario(report, "fork_heap")
    assert row["fork_child_ok"] is exp["fork_child_ok"]
    assert row["finish_reason"] == exp["finish_reason"]
    assert row["leak_bytes"] == exp["leak_bytes"]


def test_matrix_rows_match_contract(report: dict) -> None:
    """Every fixture row settles to the repaired loader contract."""
    for name, expected in EXPECTED_ROWS.items():
        row = _scenario(report, name)
        assert row["loaded_count"] == expected["loaded_count"]
        assert row["leak_bytes"] == expected["leak_bytes"]
        assert row["fork_child_ok"] == expected["fork_child_ok"]
        assert row["reject_code"] == expected["reject_code"]
        assert row["route_reply"] == expected["route_reply"]
        assert row["sla_ok"] == expected["sla_ok"]


def test_plugin_path_exercised() -> None:
    """Matrix replay requires the anchor worker and dynamically loaded modules."""
    lib = APP / "mods" / "echo_lane" / "lib" / "libecho_lane.so"
    backup = Path("/logs/verifier/libecho_lane.so.bak")
    one_scenario = Path("/logs/verifier/one_scenario")
    one_scenario.mkdir(parents=True, exist_ok=True)
    shutil.copy2(SCENARIOS / "basic_route.json", one_scenario / "basic_route.json")
    probe_out = Path("/logs/verifier/corrupt_probe.json")
    if probe_out.exists():
        probe_out.unlink()
    shutil.copy2(lib, backup)
    try:
        lib.write_bytes(b"\x00" * 64)
        proc = subprocess.run(
            [
                "/app/matrix",
                "-scenarios",
                str(one_scenario),
                "-out",
                str(probe_out),
            ],
            cwd=str(APP),
            env=_env(),
            capture_output=True,
            text=True,
        )
        assert proc.returncode != 0 or not probe_out.exists() or (
            json.loads(probe_out.read_text())["scenarios"][0]["route_reply"]
            != EXPECTED_ROWS["basic_route"]["route_reply"]
        )
    finally:
        shutil.copy2(backup, lib)

    broken_cfg = Path("/logs/verifier/broken_host.toml")
    broken_cfg.write_text('anchor_bin = "/bin/false"\n')
    bad = subprocess.run(
        [
            "/app/matrix",
            "-config",
            str(broken_cfg),
            "-scenarios",
            str(SCENARIOS),
            "-out",
            str(Path("/logs/verifier/broken_out.json")),
        ],
        cwd=str(APP),
        env=_env(),
        capture_output=True,
        text=True,
    )
    assert bad.returncode != 0


def test_fresh_module_path(report: dict) -> None:
    """Repaired attach reads freshly built modules, not audit copies in hooks/stale-libs."""
    row = _scenario(report, "basic_route")
    assert row["route_reply"] == EXPECTED_ROWS["basic_route"]["route_reply"]
    stale_echo = APP / "hooks" / "stale-libs" / "libecho_lane.so"
    stale_heap = APP / "hooks" / "stale-libs" / "libheap_lane.so"
    assert stale_echo.is_file()
    assert stale_heap.is_file()


def test_stale_heap_shadow_immunity(report: dict) -> None:
    """Heap handoff must use the built heap module, not the audit shadow copy."""
    row = _scenario(report, "heap_handoff")
    exp = EXPECTED_ROWS["heap_handoff"]
    assert row["route_reply"] == exp["route_reply"]
    assert row["leak_bytes"] == exp["leak_bytes"]
    shadow = APP / "hooks" / "stale-libs" / "libheap_lane.so"
    backup = Path("/logs/verifier/libheap_lane_shadow.bak")
    shutil.copy2(shadow, backup)
    try:
        shadow.write_bytes(b"\x00" * 64)
        rebuild_binaries()
        run_matrix()
        again = json.loads(REPORT.read_text())
        row2 = _scenario(again, "heap_handoff")
        assert row2["route_reply"] == exp["route_reply"]
        assert row2["leak_bytes"] == exp["leak_bytes"]
    finally:
        shutil.copy2(backup, shadow)
        rebuild_binaries()


def test_anchor_go_counter_parity(report: dict) -> None:
    """Go report counters must match anchor replay for every fixture row."""
    for name, expected in EXPECTED_ROWS.items():
        row = _scenario(report, name)
        assert row["loaded_count"] == expected["loaded_count"]
        assert row["leak_bytes"] == expected["leak_bytes"]
        assert row["sla_ok"] == expected["sla_ok"]


def test_attach_budget_enforced(report: dict) -> None:
    """Dup and chain fixtures reject the second attach when single-slot policy is enforced."""
    for name in ("dup_pair", "chain_row"):
        row = _scenario(report, name)
        assert row["reject_code"] == EXPECTED_ROWS[name]["reject_code"]
        assert row["loaded_count"] == EXPECTED_ROWS[name]["loaded_count"]


def test_rebuild_from_source(report: dict) -> None:
    """Fresh go and rust rebuilds reproduce the same plugin matrix."""
    rebuild_binaries()
    run_matrix()
    again = json.loads(REPORT.read_text())
    assert again["scenarios"] == report["scenarios"]
