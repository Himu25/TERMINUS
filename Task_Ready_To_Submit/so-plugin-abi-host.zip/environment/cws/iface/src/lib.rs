//! Stable C-layout wire table shared between host and modules.

pub const HOST_WIRE: u32 = 2;

#[repr(C)]
#[derive(Copy, Clone)]
pub struct OutCell {
    pub ptr: *mut u8,
    pub len: u32,
}

#[repr(C)]
#[derive(Copy, Clone)]
pub struct WireTable {
    pub wire_rev: u32,
    pub boot: Option<extern "C" fn(*mut u8) -> i32>,
    pub step: Option<extern "C" fn(*mut u8, *const u8, u32, *mut OutCell) -> i32>,
    pub halt: Option<extern "C" fn(*mut u8)>,
    pub drop_cell: Option<extern "C" fn(*mut u8, u32)>,
}

pub const ENTRY: &[u8] = b"module_slot\0";
