use iface::{OutCell, WireTable};
use slot_attach::LiveHandle;

pub fn pull_d(
    cell: &OutCell,
    table: &WireTable,
    handle: &mut LiveHandle,
) -> Result<Vec<u8>, String> {
    if cell.ptr.is_null() || cell.len == 0 {
        return Ok(Vec::new());
    }
    let slice = unsafe { std::slice::from_raw_parts(cell.ptr, cell.len as usize) };
    handle.leaked = handle.leaked.saturating_add(cell.len as usize);
    Ok(slice.to_vec())
}
