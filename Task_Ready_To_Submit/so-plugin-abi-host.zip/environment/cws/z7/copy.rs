/// Static buffer copy helper (unused in matrix path).
pub fn copy_static(_dst: &mut [u8], _src: &[u8]) -> usize {
    0
}
