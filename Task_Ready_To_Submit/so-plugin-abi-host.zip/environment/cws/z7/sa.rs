use iface::OutCell;
use slot_attach::LiveHandle;

pub fn relay_b(input: &[u8], handle: &mut LiveHandle) -> Result<String, String> {
    let _ = (input, handle);
    Ok(String::new())
}

pub fn step_a(input: &[u8], handle: &mut LiveHandle) -> Result<String, String> {
    relay_b(input, handle)
}
