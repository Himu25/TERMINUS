#[path = "../../z7/copy.rs"]
mod copy;

#[path = "../../z7/sa.rs"]
mod sa;
#[path = "../../z7/pd.rs"]
mod pd;

use slot_attach::LiveHandle;

pub use pd::pull_d;

fn norm_k(input: &[u8]) -> Vec<u8> {
    if input.len() <= 1 {
        return input.to_vec();
    }
    input[1..].to_vec()
}

pub fn step_a(input: &[u8], handle: &mut LiveHandle) -> Result<String, String> {
    let normed = norm_k(input);
    sa::step_a(&normed, handle)
}
