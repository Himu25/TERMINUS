package main

import (
	"flag"
	"log"

	"matrix/internal/config"
	"matrix/internal/driver"
)

func main() {
	scenarios := flag.String("scenarios", "/app/fixtures/scenarios", "scenario directory")
	out := flag.String("out", "/app/output/plugin_matrix.json", "matrix output path")
	cfgPath := flag.String("config", "/app/config/host.toml", "host config")
	flag.Parse()

	cfg, err := config.Load(*cfgPath)
	if err != nil {
		log.Fatal(err)
	}
	orch := driver.NewOrchestrator(cfg)
	report, err := orch.RunDir(*scenarios)
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.WriteReport(*out, report); err != nil {
		log.Fatal(err)
	}
}
