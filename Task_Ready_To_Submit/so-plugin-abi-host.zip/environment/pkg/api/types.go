package api

type ScenarioFile struct {
	Name     string   `json:"name"`
	ModNames []string `json:"mod_names"`
	Input    string   `json:"input"`
	Fork     bool     `json:"fork"`
}

type ScenarioRow struct {
	Name          string `json:"name"`
	FinishReason  string `json:"finish_reason"`
	LoadedCount   int    `json:"loaded_count"`
	RouteReply    string `json:"route_reply"`
	LeakBytes     int    `json:"leak_bytes"`
	ForkChildOK   bool   `json:"fork_child_ok"`
	RejectCode    string `json:"reject_code"`
	SlaOK         bool   `json:"sla_ok"`
}

type MatrixReport struct {
	Scenarios []ScenarioRow `json:"scenarios"`
}

type AnchorResult struct {
	Reply         string `json:"reply"`
	LeakBytes     int    `json:"leak_bytes"`
	ForkChildOK   bool   `json:"fork_child_ok"`
	LoadedCount   int    `json:"loaded_count"`
	RejectCode    string `json:"reject_code"`
	SlaOK         bool   `json:"sla_ok"`
}
