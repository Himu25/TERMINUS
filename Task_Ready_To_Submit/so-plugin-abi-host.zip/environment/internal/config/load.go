package config

import (
	"os"

	"github.com/BurntSushi/toml"
)

type Defaults struct {
	AnchorBin string `toml:"anchor_bin"`
}

func Load(path string) (*Defaults, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var cfg Defaults
	if err := toml.Unmarshal(raw, &cfg); err != nil {
		return nil, err
	}
	if cfg.AnchorBin == "" {
		cfg.AnchorBin = "/app/bin/slot"
	}
	return &cfg, nil
}
