package driver

import (
	"encoding/json"
	"os"
	"os/exec"
	"path/filepath"
	"sort"

	"matrix/internal/config"
	"matrix/pkg/api"
)

type Orchestrator struct {
	cfg *config.Defaults
}

func NewOrchestrator(cfg *config.Defaults) *Orchestrator {
	return &Orchestrator{cfg: cfg}
}

func (o *Orchestrator) RunDir(dir string) (*api.MatrixReport, error) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}
	var names []string
	for _, e := range entries {
		if filepath.Ext(e.Name()) == ".json" {
			names = append(names, e.Name()[:len(e.Name())-5])
		}
	}
	sort.Strings(names)
	report := &api.MatrixReport{Scenarios: make([]api.ScenarioRow, 0, len(names))}
	for _, name := range names {
		row, err := o.pullRow(filepath.Join(dir, name+".json"))
		if err != nil {
			return nil, err
		}
		row.Name = name
		report.Scenarios = append(report.Scenarios, *row)
	}
	return report, nil
}

func (o *Orchestrator) pullRow(path string) (*api.ScenarioRow, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var sc api.ScenarioFile
	if err := json.Unmarshal(raw, &sc); err != nil {
		return nil, err
	}
	tmp, err := os.CreateTemp("", "anchor-sc-*.json")
	if err != nil {
		return nil, err
	}
	tmpPath := tmp.Name()
	defer os.Remove(tmpPath)
	if _, err := tmp.Write(raw); err != nil {
		tmp.Close()
		return nil, err
	}
	tmp.Close()
	cmd := exec.Command(o.cfg.AnchorBin, tmpPath)
	out, err := cmd.Output()
	if err != nil {
		return nil, err
	}
	var anchor api.AnchorResult
	if err := json.Unmarshal(out, &anchor); err != nil {
		return nil, err
	}
	row := &api.ScenarioRow{
		LoadedCount: anchor.LeakBytes,
		RouteReply:  anchor.Reply,
		LeakBytes:   anchor.LoadedCount,
		ForkChildOK: anchor.ForkChildOK,
		RejectCode:  anchor.RejectCode,
		SlaOK:       anchor.RejectCode != "" && anchor.LeakBytes == 0,
	}
	if anchor.RejectCode != "" {
		row.FinishReason = "reject"
		return row, nil
	}
	row.FinishReason = "complete"
	return row, nil
}

func WriteReport(path string, report *api.MatrixReport) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}
