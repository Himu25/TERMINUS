#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
cd /app

build_mods() {
  local crates=(echo_lane old_lane heap_lane dup_alpha dup_beta)
  cargo build --release -p slot-runner
  for c in "${crates[@]}"; do
    cargo build --release -p "${c}"
    install -d -m 0755 "/app/mods/${c}/lib"
    install -m 0755 "/app/target/release/lib${c}.so" "/app/mods/${c}/lib/lib${c}.so"
  done
  install -d -m 0755 /app/bin
  install -m 0755 /app/target/release/slot /app/bin/slot
}

build_mods
go build -o /app/matrix ./cmd/matrix
mkdir -p /app/output
/app/matrix -scenarios /app/fixtures/scenarios -out /app/output/plugin_matrix.json
