#[path = "../../k2/track.rs"]
mod track;

#[path = "../../k2/cache.rs"]
mod cache;

#[path = "../../k2/ledger.rs"]
mod ledger;

#[path = "../../k2/registry.rs"]
mod registry;

#[path = "../../k2/gb.rs"]
mod gb;
#[path = "../../k2/hc.rs"]
mod hc;
#[path = "../../k2/pe.rs"]
mod pe;

use iface::WireTable;
use libloading::Library;

pub struct LiveHandle {
    pub lib: Option<Library>,
    pub table: WireTable,
    pub state: Vec<u8>,
    pub path: String,
    pub leaked: usize,
}

pub use gb::*;
pub use hc::*;
pub use pe::*;
