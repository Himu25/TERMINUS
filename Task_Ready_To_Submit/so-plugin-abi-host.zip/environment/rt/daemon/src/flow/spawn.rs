use slot_attach::{probe_e, LiveHandle};

pub fn run(input: &[u8], handle: Option<&mut LiveHandle>) -> bool {
    let Some(h) = handle else {
        return false;
    };
    probe_e(input, h).unwrap_or(false)
}
