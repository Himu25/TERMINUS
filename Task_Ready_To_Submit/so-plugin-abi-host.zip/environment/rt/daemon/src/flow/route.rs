use slot_attach::LiveHandle;
use slot_wire::step_a;

pub fn carry_h(input: &[u8], handle: Option<&mut LiveHandle>) -> (String, usize) {
    let Some(h) = handle else {
        return (String::new(), 0);
    };
    let reply = step_a(input, h).unwrap_or_default();
    (reply, 0)
}
