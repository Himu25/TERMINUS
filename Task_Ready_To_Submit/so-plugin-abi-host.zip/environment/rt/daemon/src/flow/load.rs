use slot_attach::{seal_p, LiveHandle};
use std::path::PathBuf;

pub fn prepare(mod_names: &[String]) -> (Vec<LiveHandle>, String) {
    let mut handles = Vec::new();
    for name in mod_names {
        let path = PathBuf::from("/app/mods")
            .join(name)
            .join("lib")
            .join(format!("lib{name}.so"));
        match seal_p(&path) {
            Ok(h) => handles.push(h),
            Err(code) => return (handles, code),
        }
    }
    (handles, String::new())
}
