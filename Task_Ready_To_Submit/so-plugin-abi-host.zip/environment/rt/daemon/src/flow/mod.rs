mod load;
mod route;
mod spawn;
mod unload;
mod settle;

use serde::Serialize;
use slot_attach::LiveHandle;
use std::path::PathBuf;

#[derive(Serialize)]
pub struct FlowOut {
    pub reply: String,
    pub leak_bytes: usize,
    pub fork_child_ok: bool,
    pub loaded_count: usize,
    pub reject_code: String,
    pub sla_ok: bool,
}

pub fn execute(doc: &serde_json::Value) -> FlowOut {
    let mod_names: Vec<String> = doc["mod_names"]
        .as_array()
        .unwrap()
        .iter()
        .map(|v| v.as_str().unwrap().to_string())
        .collect();
    let input = doc["input"].as_str().unwrap_or("").as_bytes();
    let fork = doc["fork"].as_bool().unwrap_or(false);

    let (handles, reject_code) = load::prepare(&mod_names);
    if !reject_code.is_empty() {
        return FlowOut {
            reply: String::new(),
            leak_bytes: 0,
            fork_child_ok: false,
            loaded_count: handles.len(),
            sla_ok: settle::settle_sla(0, &reject_code),
            reject_code,
        };
    }

    let mut handles = handles;
    let mut reply = String::new();
    let mut leak_bytes = 0usize;
    let mut fork_child_ok = false;

    if fork {
        fork_child_ok = spawn::run(input, handles.first_mut());
    } else {
        let (r, leak) = route::carry_h(input, handles.first_mut());
        reply = r;
        leak_bytes = leak;
    }

    unload::finish(&mut handles);

    FlowOut {
        reply,
        leak_bytes,
        fork_child_ok,
        loaded_count: handles.len(),
        reject_code: String::new(),
        sla_ok: settle::settle_sla(leak_bytes, "") && leak_bytes > 0,
    }
}
