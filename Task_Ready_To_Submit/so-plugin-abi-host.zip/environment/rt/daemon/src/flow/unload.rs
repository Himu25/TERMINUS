use slot_attach::{halt_c, probe_e, LiveHandle};

pub fn finish(handles: &mut [LiveHandle]) {
    for h in handles.iter_mut() {
        halt_c(h);
    }
}
