pub fn settle_sla(leak_bytes: usize, reject_code: &str) -> bool {
    if !reject_code.is_empty() {
        return leak_bytes == 0;
    }
    leak_bytes == 0
}
