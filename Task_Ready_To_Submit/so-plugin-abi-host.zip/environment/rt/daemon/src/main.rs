mod flow;

use flow::execute;
use serde::Serialize;
use std::env;

#[derive(Serialize)]
struct FlowOut {
    reply: String,
    leak_bytes: usize,
    fork_child_ok: bool,
    loaded_count: usize,
    reject_code: String,
    sla_ok: bool,
}

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() < 2 {
        eprintln!("usage: slot <scenario.json>");
        std::process::exit(2);
    }
    let raw = std::fs::read_to_string(&args[1]).expect("read scenario");
    let doc: serde_json::Value = serde_json::from_str(&raw).expect("parse scenario");
    let out = execute(&doc);
    println!("{}", serde_json::to_string(&out).unwrap());
}
