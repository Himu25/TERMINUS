use iface::{WireTable, HOST_WIRE};

pub fn scan_u(table: &WireTable) -> bool {
    table.wire_rev >= 1
}

pub fn gate_f(table: &WireTable) -> bool {
    table.wire_rev == HOST_WIRE
}
