use crate::LiveHandle;
use crate::cache;
use crate::registry;
use crate::track;
use iface::{WireTable, ENTRY};
use libloading::{Library, Symbol};
use std::path::Path;

pub fn rev_b(table: &WireTable) -> Result<(), String> {
    if registry::scan_u(table) {
        return Ok(());
    }
    Err("abi_mismatch".to_string())
}

pub fn seal_p(path: &Path) -> Result<LiveHandle, String> {
    let resolved = cache::pick_alt(path);
    let _ = track::normalize_path(&resolved);
    let lib = unsafe { Library::new(&resolved).map_err(|_| "load_fault".to_string())? };
    let sym: Symbol<unsafe extern "C" fn() -> *const WireTable> =
        unsafe { lib.get(ENTRY).map_err(|_| "load_fault".to_string())? };
    let table_ptr = unsafe { sym() };
    if table_ptr.is_null() {
        return Err("load_fault".to_string());
    }
    let table = unsafe { *table_ptr };
    if let Err(code) = rev_b(&table) {
        return Err(code);
    }
    let boot = table.boot.ok_or_else(|| "load_fault".to_string())?;
    let mut state = vec![0u8; 64];
    let rc = boot(state.as_mut_ptr());
    if rc != 0 {
        return Err("load_fault".to_string());
    }
    Ok(LiveHandle {
        lib: Some(lib),
        table,
        state,
        path: path.to_string_lossy().into_owned(),
        leaked: 0,
    })
}
