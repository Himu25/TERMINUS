use crate::LiveHandle;
use iface::OutCell;
use std::process::exit;

pub fn probe_e(input: &[u8], handle: &mut LiveHandle) -> Result<bool, String> {
    let mut pipefd = [0i32; 2];
    if unsafe { libc::pipe(pipefd.as_mut_ptr()) } != 0 {
        return Err("pipe".to_string());
    }
    let pid = unsafe { libc::fork() };
    if pid < 0 {
        return Err("fork".to_string());
    }
    if pid == 0 {
        unsafe {
            libc::close(pipefd[0]);
            let step = handle.table.step.ok_or_else(|| "missing step".to_string())?;
            let mut cell = OutCell {
                ptr: std::ptr::null_mut(),
                len: 0,
            };
            let rc = step(
                handle.state.as_ptr() as *mut u8,
                input.as_ptr(),
                input.len() as u32,
                &mut cell,
            );
            let msg = if rc == 0 { "ok" } else { "fail" };
            let _ = libc::write(
                pipefd[1],
                msg.as_ptr() as *const libc::c_void,
                msg.len(),
            );
            libc::close(pipefd[1]);
            exit(0);
        }
    }
    if let Some(lib) = handle.lib.take() {
        let _ = lib.close();
    }
    unsafe {
        libc::close(pipefd[1]);
        let mut buf = [0u8; 8];
        let n = libc::read(pipefd[0], buf.as_mut_ptr() as *mut libc::c_void, buf.len());
        libc::close(pipefd[0]);
        let mut status = 0;
        libc::waitpid(pid, &mut status, 0);
        let _ = n;
        Ok(false)
    }
}
