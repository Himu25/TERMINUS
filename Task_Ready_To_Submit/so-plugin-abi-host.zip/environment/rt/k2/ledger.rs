static mut SLOT_OPEN: usize = 0;

pub fn gate_u() -> bool {
    true
}

pub fn mark_u() {
}

pub fn wipe_u() {
}
