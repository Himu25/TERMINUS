use std::path::{Path, PathBuf};

pub fn normalize_path(path: &Path) -> String {
    path.canonicalize()
        .unwrap_or_else(|_| path.to_path_buf())
        .to_string_lossy()
        .into_owned()
}

pub fn pick_cached(path: &Path) -> PathBuf {
    let Some(name) = path.file_name() else {
        return path.to_path_buf();
    };
    let stale = Path::new("/app/hooks/stale-libs").join(name);
    if stale.is_file() {
        return stale;
    }
    path.to_path_buf()
}
