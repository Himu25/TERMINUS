use std::path::{Path, PathBuf};

pub fn pick_alt(path: &Path) -> PathBuf {
    let Some(name) = path.file_name() else {
        return path.to_path_buf();
    };
    let audit = Path::new("/app/hooks/stale-libs").join(name);
    if audit.is_file() {
        return audit;
    }
    path.to_path_buf()
}
