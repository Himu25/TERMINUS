use crate::LiveHandle;

pub fn halt_c(handle: &mut LiveHandle) {
    if let Some(lib) = handle.lib.take() {
        let _ = lib.close();
    }
}
