use iface::{OutCell, WireTable};

extern "C" fn boot(_state: *mut u8) -> i32 {
    0
}

extern "C" fn step(
    _state: *mut u8,
    _input: *const u8,
    _len: u32,
    _out: *mut OutCell,
) -> i32 {
    0
}

extern "C" fn halt(_state: *mut u8) {}

extern "C" fn drop_cell(_ptr: *mut u8, _len: u32) {}

#[no_mangle]
pub extern "C" fn module_slot() -> *const WireTable {
    static TABLE: WireTable = WireTable {
        wire_rev: 1,
        boot: Some(boot),
        step: Some(step),
        halt: Some(halt),
        drop_cell: Some(drop_cell),
    };
    &TABLE as *const WireTable
}
