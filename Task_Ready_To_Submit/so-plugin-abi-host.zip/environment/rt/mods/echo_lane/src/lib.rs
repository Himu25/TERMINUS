use iface::{OutCell, WireTable, HOST_WIRE};
use std::slice;

extern "C" fn boot(state: *mut u8) -> i32 {
    if state.is_null() {
        return -1;
    }
    unsafe {
        *state = 1;
    }
    0
}

extern "C" fn step(
    state: *mut u8,
    input: *const u8,
    len: u32,
    out: *mut OutCell,
) -> i32 {
    if state.is_null() || input.is_null() || out.is_null() {
        return -1;
    }
    unsafe {
        if *state == 0 {
            return -1;
        }
        let bytes = slice::from_raw_parts(input, len as usize);
        let mut msg = b"PONG:".to_vec();
        msg.extend_from_slice(bytes);
        let out_buf = slice::from_raw_parts_mut(state.add(1), 127);
        let take = msg.len().min(out_buf.len());
        out_buf[..take].copy_from_slice(&msg[..take]);
        (*out).ptr = state.add(1);
        (*out).len = take as u32;
    }
    0
}

extern "C" fn halt(state: *mut u8) {
    if !state.is_null() {
        unsafe {
            *state = 0;
        }
    }
}

extern "C" fn drop_cell(_ptr: *mut u8, _len: u32) {}

#[no_mangle]
pub extern "C" fn module_slot() -> *const WireTable {
    static TABLE: WireTable = WireTable {
        wire_rev: HOST_WIRE,
        boot: Some(boot),
        step: Some(step),
        halt: Some(halt),
        drop_cell: Some(drop_cell),
    };
    &TABLE as *const WireTable
}
