use iface::{OutCell, WireTable, HOST_WIRE};
use std::slice;

extern "C" fn boot(_state: *mut u8) -> i32 {
    0
}

extern "C" fn step(
    _state: *mut u8,
    input: *const u8,
    len: u32,
    out: *mut OutCell,
) -> i32 {
    if input.is_null() || out.is_null() {
        return -1;
    }
    unsafe {
        let bytes = slice::from_raw_parts(input, len as usize);
        let mut msg = b"HEAP:".to_vec();
        msg.extend_from_slice(bytes);
        let boxed = msg.into_boxed_slice();
        let len = boxed.len() as u32;
        let ptr = Box::into_raw(boxed) as *mut u8;
        (*out).ptr = ptr;
        (*out).len = len;
    }
    0
}

extern "C" fn halt(_state: *mut u8) {}

extern "C" fn drop_cell(ptr: *mut u8, len: u32) {
    if ptr.is_null() || len == 0 {
        return;
    }
    unsafe {
        let _ = Box::from_raw(slice::from_raw_parts_mut(ptr, len as usize));
    }
}

#[no_mangle]
pub extern "C" fn module_slot() -> *const WireTable {
    static TABLE: WireTable = WireTable {
        wire_rev: HOST_WIRE,
        boot: Some(boot),
        step: Some(step),
        halt: Some(halt),
        drop_cell: Some(drop_cell),
    };
    &TABLE as *const WireTable
}
