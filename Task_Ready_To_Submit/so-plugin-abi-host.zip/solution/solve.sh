#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
cd /app

cat > cws/tpkt/src/lib.rs <<'EOF'
#[path = "../../z7/copy.rs"]
mod copy;

#[path = "../../z7/sa.rs"]
mod sa;
#[path = "../../z7/pd.rs"]
mod pd;

use slot_attach::LiveHandle;

pub use pd::pull_d;

fn norm_k(input: &[u8]) -> Vec<u8> {
    input.to_vec()
}

pub fn step_a(input: &[u8], handle: &mut LiveHandle) -> Result<String, String> {
    let normed = norm_k(input);
    sa::step_a(&normed, handle)
}
EOF

cat > cws/z7/sa.rs <<'EOF'
use iface::OutCell;
use slot_attach::LiveHandle;

pub fn step_a(input: &[u8], handle: &mut LiveHandle) -> Result<String, String> {
    let table = handle.table;
    let step = table.step.ok_or_else(|| "missing step".to_string())?;
    let mut cell = OutCell {
        ptr: std::ptr::null_mut(),
        len: 0,
    };
    let rc = step(
        handle.state.as_mut_ptr(),
        input.as_ptr(),
        input.len() as u32,
        &mut cell,
    );
    if rc != 0 {
        return Err(format!("step rc={rc}"));
    }
    let bytes = super::pull_d(&cell, &table, handle)?;
    Ok(String::from_utf8_lossy(&bytes).into_owned())
}
EOF

cat > cws/z7/pd.rs <<'EOF'
use iface::{OutCell, WireTable};
use slot_attach::LiveHandle;

pub fn pull_d(
    cell: &OutCell,
    table: &WireTable,
    handle: &mut LiveHandle,
) -> Result<Vec<u8>, String> {
    if cell.ptr.is_null() || cell.len == 0 {
        return Ok(Vec::new());
    }
    let slice = unsafe { std::slice::from_raw_parts(cell.ptr, cell.len as usize) };
    let out = slice.to_vec();
    if let Some(drop_cell) = table.drop_cell {
        drop_cell(cell.ptr, cell.len);
    } else {
        handle.leaked = handle.leaked.saturating_add(cell.len as usize);
    }
    Ok(out)
}
EOF

cat > rt/k2/track.rs <<'EOF'
use std::path::{Path, PathBuf};

pub fn normalize_path(path: &Path) -> String {
    path.canonicalize()
        .unwrap_or_else(|_| path.to_path_buf())
        .to_string_lossy()
        .into_owned()
}

pub fn pick_cached(path: &Path) -> PathBuf {
    path.to_path_buf()
}
EOF

cat > rt/k2/ledger.rs <<'EOF'
static mut SLOT_OPEN: usize = 0;

pub fn gate_u() -> bool {
    unsafe { SLOT_OPEN == 0 }
}

pub fn mark_u() {
    unsafe {
        SLOT_OPEN += 1;
    }
}

pub fn wipe_u() {
    unsafe {
        if SLOT_OPEN > 0 {
            SLOT_OPEN -= 1;
        }
    }
}
EOF

cat > rt/k2/gb.rs <<'EOF'
use crate::ledger;
use crate::LiveHandle;
use crate::registry;
use crate::track;
use iface::{WireTable, ENTRY};
use libloading::{Library, Symbol};
use std::path::Path;

pub fn rev_b(table: &WireTable) -> Result<(), String> {
    if registry::gate_f(table) {
        return Ok(());
    }
    Err("abi_mismatch".to_string())
}

pub fn seal_p(path: &Path) -> Result<LiveHandle, String> {
    if !ledger::gate_u() {
        return Err("symbol_conflict".to_string());
    }
    let resolved = track::pick_cached(path);
    let _ = track::normalize_path(&resolved);
    let lib = unsafe { Library::new(&resolved).map_err(|_| "load_fault".to_string())? };
    let sym: Symbol<unsafe extern "C" fn() -> *const WireTable> =
        unsafe { lib.get(ENTRY).map_err(|_| "load_fault".to_string())? };
    let table_ptr = unsafe { sym() };
    if table_ptr.is_null() {
        return Err("load_fault".to_string());
    }
    let table = unsafe { *table_ptr };
    if let Err(code) = rev_b(&table) {
        return Err(code);
    }
    let boot = table.boot.ok_or_else(|| "load_fault".to_string())?;
    let mut state = vec![0u8; 64];
    let rc = boot(state.as_mut_ptr());
    if rc != 0 {
        return Err("load_fault".to_string());
    }
    ledger::mark_u();
    Ok(LiveHandle {
        lib: Some(lib),
        table,
        state,
        path: path.to_string_lossy().into_owned(),
        leaked: 0,
    })
}
EOF

cat > rt/k2/hc.rs <<'EOF'
use crate::ledger;
use crate::LiveHandle;

pub fn halt_c(handle: &mut LiveHandle) {
    if let Some(halt) = handle.table.halt {
        halt(handle.state.as_mut_ptr());
    }
    if let Some(lib) = handle.lib.take() {
        let _ = lib.close();
    }
    ledger::wipe_u();
}
EOF

cat > rt/k2/pe.rs <<'EOF'
use crate::LiveHandle;
use iface::OutCell;
use std::process::exit;

pub fn probe_e(input: &[u8], handle: &mut LiveHandle) -> Result<bool, String> {
    let mut pipefd = [0i32; 2];
    if unsafe { libc::pipe(pipefd.as_mut_ptr()) } != 0 {
        return Err("pipe".to_string());
    }
    let pid = unsafe { libc::fork() };
    if pid < 0 {
        return Err("fork".to_string());
    }
    if pid == 0 {
        unsafe {
            libc::close(pipefd[0]);
            let step = handle.table.step.ok_or_else(|| "missing step".to_string())?;
            let mut cell = OutCell {
                ptr: std::ptr::null_mut(),
                len: 0,
            };
            let rc = step(
                handle.state.as_ptr() as *mut u8,
                input.as_ptr(),
                input.len() as u32,
                &mut cell,
            );
            let msg = if rc == 0 { "ok" } else { "fail" };
            let _ = libc::write(
                pipefd[1],
                msg.as_ptr() as *const libc::c_void,
                msg.len(),
            );
            libc::close(pipefd[1]);
            exit(0);
        }
    }
    unsafe {
        libc::close(pipefd[1]);
        let mut buf = [0u8; 8];
        let n = libc::read(pipefd[0], buf.as_mut_ptr() as *mut libc::c_void, buf.len());
        libc::close(pipefd[0]);
        let mut status = 0;
        libc::waitpid(pid, &mut status, 0);
        if n <= 0 {
            return Ok(false);
        }
        Ok(std::str::from_utf8(&buf[..n as usize])
            .unwrap_or("")
            .starts_with("ok"))
    }
}
EOF

cat > rt/daemon/src/flow/route.rs <<'EOF'
use slot_attach::LiveHandle;
use slot_wire::step_a;

pub fn carry_h(input: &[u8], handle: Option<&mut LiveHandle>) -> (String, usize) {
    let Some(h) = handle else {
        return (String::new(), 0);
    };
    let reply = step_a(input, h).unwrap_or_default();
    (reply, h.leaked)
}
EOF

sed -i 's/sla_ok: settle::settle_sla(leak_bytes, "") && leak_bytes > 0,/sla_ok: leak_bytes == 0,/' rt/daemon/src/flow/mod.rs
sed -i 's/sla_ok: settle::settle_sla(0, \&reject_code),/sla_ok: true,/' rt/daemon/src/flow/mod.rs

sed -i 's/LoadedCount: anchor.LeakBytes/LoadedCount: anchor.LoadedCount/' internal/driver/run.go
sed -i 's/LeakBytes:   anchor.LoadedCount/LeakBytes:   anchor.LeakBytes/' internal/driver/run.go
sed -i 's/SlaOK:       anchor.RejectCode != "" && anchor.LeakBytes == 0/SlaOK:       anchor.SlaOK/' internal/driver/run.go

bash /app/ci/run_plugin_matrix.sh
