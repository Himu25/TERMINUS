#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/pkg/votecount/op_k.go <<'EOF'
package votecount

func quorumMet(count int, need int) bool {
	if need <= 0 {
		return false
	}
	if count < 0 {
		return false
	}
	return count >= need
}

func OpK(voterCount int, need int) bool {
	return quorumMet(voterCount, need)
}
EOF

cat > /app/internal/sigtag/op_m.go <<'EOF'
package sigtag

import "lab.local/quorum_split_diagnosis/pkg/frame"

func tagOk(seq uint32, serviceID string, ver uint32, stored uint16) bool {
	want := frame.WireCRC(seq, serviceID, ver)
	return want == stored
}

func op_m(seq uint32, serviceID string, ver uint32, stored uint16) bool {
	if serviceID == "" {
		return stored == 0 && seq == 0
	}
	return tagOk(seq, serviceID, ver, stored)
}

func OpSeal(seq uint32, serviceID string, ver uint32, stored uint16) bool {
	return op_m(seq, serviceID, ver, stored)
}
EOF

cat > /app/pkg/rosterfold/op_f.go <<'EOF'
package rosterfold

func minMark(marks []int64) int64 {
	if len(marks) == 0 {
		return 0
	}
	best := marks[0]
	for _, m := range marks[1:] {
		if m < best {
			best = m
		}
	}
	return best
}

func OpF(marks []int64) int64 {
	return minMark(marks)
}
EOF

cat > /app/membergate/src/lib.rs <<'EOF'
#[no_mangle]
pub extern "C" fn mg_fold_skew(base_ms: i64, lag_ms: i64) -> i64 {
    if lag_ms == 0 {
        return base_ms;
    }
    base_ms - lag_ms
}
EOF

bash /app/scripts/build.sh

rm -f /app/output/split_report.json
mkdir -p /app/output
TB_SPLIT_FIXTURE=1 /app/bin/split_diag
test -s /app/output/split_report.json

GOFLAGS=-mod=mod go test ./...
