"""Verifier for five-node quorum split diagnosis report."""

import json
import os
import shutil
import subprocess
from collections import defaultdict
from pathlib import Path

import pytest

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = Path("/tests") / "fixtures"
OUT = APP / "output" / "split_report.json"
GO_BIN = "go"
VERIFY_BIN = "/app/bin/split_diag"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _digest_hex(
    cluster_id: str,
    leader_term: int,
    stable_seq: int,
    repair: int,
    gaps: int,
    nodes_active: int,
    revert: int,
    keep: int,
    band: str,
    membership_clean: bool,
) -> str:
    ck = "true" if membership_clean else "false"
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            cluster_id,
            str(leader_term),
            str(stable_seq),
            str(repair),
            str(gaps),
            str(nodes_active),
            str(revert),
            str(keep),
            band,
            ck,
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _crc16(seq: int, voter_id: str, ver: int) -> int:
    s = sum(voter_id.encode()) & 0xFFFFFFFF
    s ^= seq ^ ver
    return s & 0xFFFF


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = FIXTURES / pack_name
    plan = json.loads((pack_dir / "cluster_plan.json").read_text())
    q = plan["q_size"]
    sep_seq = plan["sep_seq"]
    stable_term = plan["stable_term"]
    prop_tight = plan["timeout_tight_ms"]
    offsets: dict[str, int] = {}
    freezes: list[int] = []
    rows: list[dict] = []
    for rid in plan["nodes"]:
        meta = json.loads((pack_dir / "nodes" / rid / "node_meta.json").read_text())
        lag = int(meta.get("link_delay_ms", 0))
        offsets[rid] = int(meta["clock_skew_ms"]) - lag
        freezes.append(meta["depart_mark"])
        seg = pack_dir / "nodes" / rid / "beat_001.jsonl"
        if not seg.exists():
            continue
        for line in seg.read_text().splitlines():
            if not line.strip():
                continue
            entry = json.loads(line)
            entry["node"] = rid
            rows.append(entry)
    wm = min(freezes) if freezes else 0
    by_seq: dict[int, list] = defaultdict(list)
    all_rows: dict[int, list] = defaultdict(list)
    for entry in rows:
        seq = entry["round_seq"]
        all_rows[seq].append(entry)
        if seq > wm:
            by_seq[seq].append(entry)
    accepted: dict[int, int] = {}
    repair = 0
    loss = 0
    live: set[str] = set()
    membership_clean = True
    node_keep: dict[str, bool] = {}
    for seq in sorted(by_seq):
        buckets: dict[tuple, list] = defaultdict(list)
        for entry in by_seq[seq]:
            buckets[(entry["ver"], entry["node"])].append(entry)
        picked = None
        best_adj = None
        for (ver, node), items in buckets.items():
            if len({it["voter_id"] for it in items}) < q:
                continue
            valid = [
                it
                for it in items
                if _crc16(it["round_seq"], it["voter_id"], it["ver"]) == it["crc"]
            ]
            if len(valid) < q:
                continue
            adj = min(it["sent_ms"] - offsets[it["node"]] for it in valid)
            if picked is None or adj < best_adj:
                picked, best_adj = (ver, node), adj
        if picked is None:
            loss += 1
            continue
        ver, node = picked
        items = buckets[(ver, node)]
        repair += sum(
            1
            for it in items
            if _crc16(it["round_seq"], it["voter_id"], it["ver"]) != it["crc"]
        )
        if ver > sep_seq and len({it["voter_id"] for it in items if _crc16(it["round_seq"], it["voter_id"], it["ver"]) == it["crc"]}) < q:
            membership_clean = False
        if ver >= stable_term:
            node_keep[node] = True
        for it in items:
            if _crc16(it["round_seq"], it["voter_id"], it["ver"]) == it["crc"]:
                live.add(it["node"])
        accepted[seq] = ver
    stable_seq = 0
    s = 1
    while True:
        if s <= wm or s in accepted:
            stable_seq = s
            s += 1
        else:
            break
    leader_term = 0
    for seq, seq_rows in all_rows.items():
        if seq > stable_seq:
            continue
        for entry in seq_rows:
            if seq in accepted and entry["ver"] == accepted[seq]:
                if _crc16(entry["round_seq"], entry["voter_id"], entry["ver"]) == entry["crc"] and entry["ver"] > leader_term:
                    leader_term = entry["ver"]
            elif seq <= wm and entry["ver"] > leader_term:
                leader_term = entry["ver"]
    revert = 0
    keep = 0
    for rid in offsets:
        if node_keep.get(rid):
            keep += 1
        else:
            revert += 1
    spread = max(offsets.values()) - min(offsets.values())
    band = "tight" if spread <= prop_tight else "wide"
    digest = _digest_hex(
        plan["cluster_id"],
        leader_term,
        stable_seq,
        repair,
        loss,
        len(live),
        revert,
        keep,
        band,
        membership_clean,
    )
    return {
        "schema_version": "1",
        "cluster_id": plan["cluster_id"],
        "leader_term": leader_term,
        "stable_seq": stable_seq,
        "vote_repairs": repair,
        "split_gaps": loss,
        "nodes_active": len(live),
        "demote_count": revert,
        "promote_count": keep,
        "timeout_band": band,
        "membership_clean": membership_clean,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_SPLIT_FIXTURE": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_alpha_report_matches_quorum_replay() -> None:
    """Alpha cluster should reach tight timeout band with full five-node chain."""
    _swap("cluster_alpha")
    exp = _expected_from_fixture("cluster_alpha")
    got = _run_tool()
    assert got["stable_seq"] == exp["stable_seq"]
    assert got["split_gaps"] == exp["split_gaps"]
    assert got["leader_term"] == exp["leader_term"]
    assert got["timeout_band"] == exp["timeout_band"]
    assert got["digest_hex"] == exp["digest_hex"]
    assert got["nodes_active"] == exp["nodes_active"]
    assert got["membership_clean"] == exp["membership_clean"]


def test_beta_report_matches_quorum_replay() -> None:
    """Beta cluster applies link delay smear when folding node skew for replay."""
    _swap("cluster_beta")
    exp = _expected_from_fixture("cluster_beta")
    got = _run_tool()
    assert got["timeout_band"] == exp["timeout_band"]
    assert got["promote_count"] == exp["promote_count"]
    assert got["demote_count"] == exp["demote_count"]
    assert got["nodes_active"] == exp["nodes_active"]


def test_gamma_split_gaps_after_lone_version() -> None:
    """Gamma stops the chain when only one node carries a high term row."""
    _swap("cluster_gamma")
    exp = _expected_from_fixture("cluster_gamma")
    got = _run_tool()
    assert got["split_gaps"] == exp["split_gaps"]
    assert got["stable_seq"] == exp["stable_seq"]


def test_delta_high_split_gaps() -> None:
    """Delta orphan high step should not extend the global chain."""
    _swap("cluster_delta")
    exp = _expected_from_fixture("cluster_delta")
    got = _run_tool()
    assert got["split_gaps"] == exp["split_gaps"]
    assert got["stable_seq"] == exp["stable_seq"]


def test_epsilon_vote_repairs_nonzero() -> None:
    """Epsilon should count one integrity repair on the winning version group."""
    _swap("cluster_epsilon")
    exp = _expected_from_fixture("cluster_epsilon")
    got = _run_tool()
    assert got["vote_repairs"] == exp["vote_repairs"]
    assert got["stable_seq"] == exp["stable_seq"]
    assert got["membership_clean"] == exp["membership_clean"]


def test_zeta_stable_seq_watermark() -> None:
    """Alpha cluster stable_seq tracks replay watermark fold."""
    _swap("cluster_alpha")
    exp = _expected_from_fixture("cluster_alpha")
    got = _run_tool()
    assert got["stable_seq"] == exp["stable_seq"]


def test_theta_promote_demote_split() -> None:
    """Beta partial heal should split promote and demote counts across nodes."""
    _swap("cluster_beta")
    exp = _expected_from_fixture("cluster_beta")
    got = _run_tool()
    assert got["promote_count"] == exp["promote_count"]
    assert got["demote_count"] == exp["demote_count"]


def test_go_subsystem_tests_pass() -> None:
    """Go unit tests under /app must pass after the repair."""
    subprocess.run(
        [GO_BIN, "test", "./..."],
        cwd="/app",
        env={
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        },
        check=True,
    )
