// Report JSON for /app/output/split_report.json:
//
// schema_version — string, always "1"
// cluster_id — string, echoes active cluster plan name
// leader_term — uint32, highest term in the consistent leader chain
// stable_seq — highest contiguous election round included after folding the earliest node depart_mark watermark
// vote_repairs — ballot rows in the winning term group whose integrity tag failed validation
// split_gaps — election rounds above the watermark without q_size voter agreement on one term
// nodes_active — count of cluster nodes contributing to accepted ballots
// demote_count — nodes assigned fallback term after partial heal
// promote_count — nodes kept on stable term
// timeout_band — string, "tight" or "wide"
// membership_clean — boolean (not 0/1 strings)
// digest_hex — lowercase hex SHA-256 of cluster_id|leader_term|stable_seq|vote_repairs|split_gaps|nodes_active|demote_count|promote_count|timeout_band|membership_clean
//
// Root object contains only these keys.
package main

import (
	"log"
	"os"

	"lab.local/quorum_split_diagnosis/internal/driver"
)

func main() {
	if os.Getenv("TB_SPLIT_FIXTURE") != "1" {
		log.Fatal("TB_SPLIT_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/split_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
