package skew

import (
	"lab.local/quorum_split_diagnosis/pkg/frame"
	"lab.local/quorum_split_diagnosis/pkg/timenorm"
)

// AdjustWall normalizes sent time for a beat row.
func AdjustWall(row frame.Row, offset int64) int64 {
	return timenorm.OpT(row.WallMS, offset)
}
