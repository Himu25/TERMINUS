package freeze

import (
	"lab.local/quorum_split_diagnosis/pkg/rosterfold"
	node "lab.local/quorum_split_diagnosis/pkg/nodepkg"
)

// Watermark collects depart marks from node profiles.
func Watermark(profiles []node.Profile) int64 {
	marks := make([]int64, 0, len(profiles))
	for _, p := range profiles {
		marks = append(marks, int64(p.DepartMark))
	}
	return rosterfold.OpF(marks)
}
