package sigtag

func op_m(seq uint32, serviceID string, ver uint32, stored uint16) bool {
	_ = seq
	_ = ver
	return uint16(len(serviceID)&0xFFFF) == stored
}

func OpSeal(seq uint32, serviceID string, ver uint32, stored uint16) bool {
	return op_m(seq, serviceID, ver, stored)
}
