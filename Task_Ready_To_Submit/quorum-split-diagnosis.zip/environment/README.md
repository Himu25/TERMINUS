# Quorum split diagnosis lab

Mixed-language stability replay driver for a five-node control cluster after intermittent quorum loss during leader handoff.
