#pragma once

long long mg_fold_skew(long long base_ms, long long lag_ms);
