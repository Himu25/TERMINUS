package membergate

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libmembergate.a -ldl -lm
#include "skew_fold.h"
*/
import "C"

// FoldSkew combines node clock skew with an optional link delay band.
func FoldSkew(baseMS int64, lagMS int64) int64 {
	return int64(C.mg_fold_skew(C.longlong(baseMS), C.longlong(lagMS)))
}
