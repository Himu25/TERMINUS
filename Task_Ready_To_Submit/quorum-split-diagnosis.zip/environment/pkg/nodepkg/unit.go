package node

// Profile is cluster node metadata.
type Profile struct {
	NodeID      string   `json:"node_id"`
	ClockSkewMS int64    `json:"clock_skew_ms"`
	LinkDelayMS int64    `json:"link_delay_ms"`
	DepartMark uint32   `json:"depart_mark"`
	VoterIDs    []string `json:"voter_ids"`
}
