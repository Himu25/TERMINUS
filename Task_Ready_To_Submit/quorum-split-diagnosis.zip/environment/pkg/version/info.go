package version

// Tool identifies the recovery driver build.
const Tool = "split_diag"
