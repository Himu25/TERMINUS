package votecount

import "testing"

func TestOpKRequiresDistinctVoterQuorum(t *testing.T) {
	if OpK(1, 3) {
		t.Fatal("single voter must not satisfy q_size=3 quorum")
	}
	if !OpK(3, 3) {
		t.Fatal("three distinct voters should satisfy q_size=3 quorum")
	}
}
