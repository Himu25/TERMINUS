package votecount

func OpK(voterCount int, need int) bool {
	_ = need
	return voterCount >= 1
}
