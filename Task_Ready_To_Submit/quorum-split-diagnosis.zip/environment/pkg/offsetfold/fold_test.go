package offsetfold

import "testing"

func TestFoldNodeSkewSubtractsLinkDelay(t *testing.T) {
	got := FoldNodeSkew(26, 8)
	if got != 18 {
		t.Fatalf("lag smear fold = %d, want 18", got)
	}
}
