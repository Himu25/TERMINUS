package offsetfold

import "lab.local/quorum_split_diagnosis/membergate"

// FoldNodeSkew applies optional link delay smear to the recorded clock skew baseline.
func FoldNodeSkew(skewMS int64, propLagMS int64) int64 {
	return membergate.FoldSkew(skewMS, propLagMS)
}
