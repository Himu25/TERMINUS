package frame

// Row is one append-only beat line from a node segment.
type Row struct {
	RoundSeq uint32 `json:"round_seq"`
	Ver        uint32 `json:"ver"`
	WallMS     int64  `json:"sent_ms"`
	VoterID  string `json:"voter_id"`
	CRC        uint16 `json:"crc"`
	Node     string `json:"node"`
}
