package rosterfold

import "testing"

func TestOpFFoldsEarliestDepartMark(t *testing.T) {
	got := OpF([]int64{6, 2, 5, 3})
	if got != 2 {
		t.Fatalf("watermark fold = %d, want earliest mark 2", got)
	}
}
