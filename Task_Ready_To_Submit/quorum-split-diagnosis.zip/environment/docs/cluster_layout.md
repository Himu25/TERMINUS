# Cluster layout

Fifty logical voters are grouped across five cluster nodes (ten voters per node).
Each node contributes heartbeat tapes, clock skew metadata, link delay bands, and a depart_mark watermark used during replay.
