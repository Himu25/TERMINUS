module lab.local/quorum_split_diagnosis

go 1.22
