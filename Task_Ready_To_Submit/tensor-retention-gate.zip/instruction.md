The distributed Rust trainer under `/app` cannot complete its default job plan. Running `/app/tools/job_runner` against the shipped configuration produces wrong counters, broken rank coordination, and resource accounting that exceeds headroom even though the job config looks generous.

Investigate the full trainer pipeline and repair the defects. Do not raise slot_ceiling, hand-write `/app/output/train_report.json`, or weaken digest or tally verification.

Rebuild `/app/bin/tb_exec` with release `cargo build` from `/app/Cargo.toml`, installing the release artifact named `job_runner` to `/app/bin/tb_exec` while keeping the Cargo binary name unchanged. `/app/tools/job_runner` execs `/app/bin/tb_exec`, reads `/app/config/train_job.toml`, and writes `/app/output/train_report.json` with status, epochs_done, target_epochs, peak_slots, slot_ceiling, rank_agree, final_loss, opening_loss, micro_steps, scheduler_ticks, and job_digest.

scheduler_ticks tracks scheduler steps across the full epoch plan (target_epochs times steps_per_epoch), not rank_count. micro_steps tracks rank micro-batches and scales with scheduler_ticks times rank_count. Worker lane slot_tally values and tape ledger peaks are per-step snapshots of live retention, not cumulative lifetime totals; peak_slots is the highest per-step live slot count seen during the run.

On success the run finishes every planned epoch with peak_slots below slot_ceiling, aligned cross-rank lane markers, finite positive opening and closing losses that differ and follow the shard-driven SGD trace over manifest rows, and a lowercase 64-character hex job_digest of the job bytes. Repeat runs on unchanged inputs emit identical report bytes, and counter or digest fields follow live edits to the job file. Alternate job configs with a lowered slot_ceiling still finish the full epoch plan with sound tape, pull, and fuse accounting. Editing shard row content shifts opening_loss.

Crushing slot_ceiling beneath the healthy-run peak halts before the schedule finishes. Lane-marker divergence — including the fuse-skew lab hook documented in `/app/hooks/deploy_notes.txt` — surfaces in rank_agree.
