"""Verifier for tensor-retention-gate."""

from __future__ import annotations

import json
import os
import string
import subprocess
from contextlib import contextmanager
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "train_report.json"
JOB = APP / "config" / "train_job.toml"
SHARD_MANIFEST = APP / "data" / "shard_manifest.json"
FIXTURE_JOB = Path("/tests/fixtures/train_job.toml")
FIXTURE_TRIPLE = Path("/tests/fixtures/train_job_triple.toml")
FIXTURE_TIGHT = Path("/tests/fixtures/train_job_tight.toml")
INVOKER = Path("/tests/invoke_runner.sh")

RUNNER_TIMEOUT_SEC = 90
BUILD_TIMEOUT_SEC = 480

REPORT_KEYS = frozenset(
    {
        "status",
        "epochs_done",
        "target_epochs",
        "peak_slots",
        "slot_ceiling",
        "rank_agree",
        "final_loss",
        "opening_loss",
        "micro_steps",
        "scheduler_ticks",
        "job_digest",
    }
)


def _parse_job(path: Path) -> dict[str, int]:
    cfg: dict[str, int] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line.startswith("target_epochs"):
            cfg["target_epochs"] = int(line.split("=", 1)[1].strip())
        elif line.startswith("slot_ceiling"):
            cfg["slot_ceiling"] = int(line.split("=", 1)[1].strip())
        elif line.startswith("steps_per_epoch"):
            cfg["steps_per_epoch"] = int(line.split("=", 1)[1].strip())
        elif line.startswith("rank_count"):
            cfg["rank_count"] = int(line.split("=", 1)[1].strip())
        elif line.startswith("feature_width"):
            cfg["feature_width"] = int(line.split("=", 1)[1].strip())
    return cfg


def _load_shard_rows() -> list[list[dict]]:
    manifest = json.loads(SHARD_MANIFEST.read_text(encoding="utf-8"))
    shards: list[list[dict]] = []
    for sref in manifest["shards"]:
        rows: list[dict] = []
        for line in Path(sref["path"]).read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split(",")
            rows.append(
                {"features": [float(p) for p in parts[:-1]], "label": float(parts[-1])}
            )
        shards.append(rows)
    return shards


def _simulate_sgd(
    job: dict[str, int], shards: list[list[dict]]
) -> tuple[float, float]:
    fw = job.get("feature_width", 3)
    lr = 0.02
    weights = [0.1] * fw
    opening_loss: float | None = None
    final_loss = 0.0
    cursors = [0] * job["rank_count"]

    for _epoch in range(job["target_epochs"]):
        for _step in range(job["steps_per_epoch"]):
            for rank_idx in range(job["rank_count"]):
                shard = shards[rank_idx % len(shards)]
                row_idx = cursors[rank_idx] % len(shard)
                row = shard[row_idx]
                cursors[rank_idx] += 1

                features = row["features"]
                label = row["label"]

                pred = 0.0
                for i, feat in enumerate(features):
                    pred += weights[i % fw] * feat

                diff = pred - label
                loss = diff * diff

                if opening_loss is None:
                    opening_loss = loss
                final_loss = loss

                grad_scale = loss
                if not (grad_scale == grad_scale and abs(grad_scale) != float("inf")):
                    grad_scale = 0.0
                for i in range(fw):
                    g = grad_scale * features[i % fw]
                    weights[i] -= lr * g

    assert opening_loss is not None
    return opening_loss, final_loss


def _job_digest(path: Path) -> str:
    proc = subprocess.run(
        ["sha256sum", str(path)],
        capture_output=True,
        text=True,
        check=True,
        timeout=10,
    )
    return proc.stdout.split()[0]


def _digest_bytes(body: bytes) -> str:
    proc = subprocess.run(
        ["sha256sum"],
        input=body,
        capture_output=True,
        check=True,
        timeout=10,
    )
    return proc.stdout.decode().split()[0]


def _peak_slot_job_profile(job: dict[str, int]) -> tuple[int, int, int]:
    fw = job.get("feature_width", 3)
    tape_nodes_per_step = 4 * fw + 5
    worker_slots_total = (fw + 2) * job["rank_count"]
    fuse_pool_total = job["rank_count"]
    expected = max(tape_nodes_per_step, worker_slots_total, fuse_pool_total)
    return expected, worker_slots_total, fuse_pool_total


def _assert_peak_slots_banded(report: dict, job: dict[str, int]) -> None:
    expected, worker_floor, _ = _peak_slot_job_profile(job)
    total_steps = job["target_epochs"] * job["steps_per_epoch"]
    upper = max(expected * 3, worker_floor * total_steps * 3 // 2)
    peak = report["peak_slots"]
    assert peak < report["slot_ceiling"]
    assert worker_floor <= peak <= upper


def _invoke(extra_env: dict[str, str] | None = None) -> None:
    env = os.environ.copy()
    if extra_env:
        env.update(extra_env)
    proc = subprocess.run(
        ["bash", str(INVOKER)],
        capture_output=True,
        text=True,
        check=False,
        env=env,
        timeout=BUILD_TIMEOUT_SEC + RUNNER_TIMEOUT_SEC,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "train_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


@contextmanager
def _job_bytes(body: bytes):
    original = JOB.read_bytes()
    JOB.write_bytes(body)
    try:
        _invoke()
        yield
    finally:
        JOB.write_bytes(original)
        _invoke()


@pytest.fixture(scope="session", autouse=True)
def _ensure_report() -> None:
    assert INVOKER.is_file(), "invoke_runner.sh missing"
    assert FIXTURE_JOB.is_file(), "fixture job config missing"
    assert FIXTURE_TRIPLE.is_file(), "triple-rank fixture missing"
    assert FIXTURE_TIGHT.is_file(), "tight-ceiling fixture missing"
    assert JOB.read_bytes() == FIXTURE_JOB.read_bytes(), "train_job.toml was tampered"
    _invoke()


@pytest.fixture(scope="session")
def default_report() -> dict:
    return _load_report()


@pytest.fixture(scope="session")
def default_job() -> dict[str, int]:
    return _parse_job(FIXTURE_JOB)


def test_report_schema_and_default_contract(
    default_report: dict, default_job: dict[str, int]
) -> None:
    """Default run matches the report schema and full completion contract."""
    report = default_report
    job = default_job
    expect_ticks = job["target_epochs"] * job["steps_per_epoch"]
    expect_micro = expect_ticks * job["rank_count"]

    assert set(report.keys()) == REPORT_KEYS
    assert report["status"] == "completed"
    assert report["rank_agree"] is True
    assert report["epochs_done"] == report["target_epochs"] == job["target_epochs"]
    assert report["scheduler_ticks"] == expect_ticks == report["epochs_done"] * job["steps_per_epoch"]
    assert report["micro_steps"] == expect_micro == report["scheduler_ticks"] * job["rank_count"]
    assert report["peak_slots"] < report["slot_ceiling"] == job["slot_ceiling"]
    assert report["job_digest"] == _job_digest(FIXTURE_JOB)
    digest = report["job_digest"]
    assert len(digest) == 64
    assert all(c in string.hexdigits.lower() for c in digest)
    for key in ("final_loss", "opening_loss"):
        v = report[key]
        assert isinstance(v, (int, float))
        assert v == v
        assert abs(v) != float("inf")
        assert v > 0.0
    assert report["opening_loss"] != report["final_loss"]


def test_triple_run_byte_stable(default_report: dict) -> None:
    """Three consecutive runs emit identical report bytes."""
    assert default_report["status"] == "completed"
    first = OUT.read_bytes()
    _invoke()
    second = OUT.read_bytes()
    _invoke()
    third = OUT.read_bytes()
    assert first == second == third


def test_forged_report_fields_rebuilt(default_report: dict, default_job: dict[str, int]) -> None:
    """Hand-edited tallies and digests are overwritten by a fresh runner emission."""
    report = default_report
    forged = dict(report)
    forged["micro_steps"] = 1
    forged["scheduler_ticks"] = 1
    forged["job_digest"] = "f" * 64
    OUT.write_text(json.dumps(forged) + "\n", encoding="utf-8")
    _invoke()
    restored = _load_report()
    expect_micro = default_job["target_epochs"] * default_job["steps_per_epoch"] * default_job["rank_count"]
    expect_ticks = default_job["target_epochs"] * default_job["steps_per_epoch"]
    assert restored["micro_steps"] == expect_micro
    assert restored["scheduler_ticks"] == expect_ticks
    assert restored["job_digest"] == _job_digest(FIXTURE_JOB)


def test_runner_tracks_triple_rank_job_plan() -> None:
    """Swapping in a three-rank job rescales counters and digest live."""
    triple = _parse_job(FIXTURE_TRIPLE)
    expect_ticks = triple["target_epochs"] * triple["steps_per_epoch"]
    expect_micro = expect_ticks * triple["rank_count"]
    with _job_bytes(FIXTURE_TRIPLE.read_bytes()):
        report = _load_report()
    assert report["target_epochs"] == triple["target_epochs"]
    assert report["scheduler_ticks"] == expect_ticks
    assert report["micro_steps"] == expect_micro
    assert report["epochs_done"] == triple["target_epochs"]
    assert report["job_digest"] == _job_digest(FIXTURE_TRIPLE)
    assert report["rank_agree"] is True
    assert report["status"] == "completed"
    assert report["peak_slots"] < report["slot_ceiling"]


def test_runner_tracks_job_byte_mutation_for_digest() -> None:
    """A one-line job edit must change job_digest after rebuild."""
    base = FIXTURE_JOB.read_text(encoding="utf-8")
    mutated = base if base.endswith("\n") else base + "\n"
    mutated += "# probe line for digest drift\n"
    mutated_bytes = mutated.encode("utf-8")
    expect_digest = _digest_bytes(mutated_bytes)
    with _job_bytes(mutated_bytes):
        report = _load_report()
    assert report["job_digest"] == expect_digest
    assert report["job_digest"] != _job_digest(FIXTURE_JOB)


def test_ceiling_one_below_peak_aborts_mid_schedule(default_report: dict, default_job: dict[str, int]) -> None:
    """Lowering slot_ceiling to peak_slots-1 must surface slot-pressure abort."""
    peak = default_report["peak_slots"]
    assert peak > 1
    crushed_lines: list[str] = []
    for line in FIXTURE_JOB.read_text(encoding="utf-8").splitlines():
        if line.strip().startswith("slot_ceiling"):
            crushed_lines.append(f"slot_ceiling = {peak - 1}")
        else:
            crushed_lines.append(line)
    crushed_body = "\n".join(crushed_lines)
    if not crushed_body.endswith("\n"):
        crushed_body += "\n"
    with _job_bytes(crushed_body.encode("utf-8")):
        report = _load_report()
    assert report["status"] == "aborted_slot_pressure"
    assert report["epochs_done"] < default_job["target_epochs"]
    assert report["slot_ceiling"] == peak - 1


def test_rank_agree_false_when_fuse_skew_probe_enabled() -> None:
    """Lab fuse-skew probe must surface rank_agree false until the fuse path is repaired."""
    try:
        _invoke({"TB_FUSE_SKEW": "1"})
        report = _load_report()
        assert report["rank_agree"] is False
    finally:
        _invoke()
    assert _load_report()["rank_agree"] is True


def test_tight_ceiling_fixture_completes_with_repaired_trainer() -> None:
    """A lowered slot_ceiling fixture still completes when tape, pull, and fuse paths are sound."""
    tight = _parse_job(FIXTURE_TIGHT)
    with _job_bytes(FIXTURE_TIGHT.read_bytes()):
        report = _load_report()
    assert report["status"] == "completed"
    assert report["epochs_done"] == tight["target_epochs"]
    assert report["peak_slots"] < report["slot_ceiling"]
    assert report["slot_ceiling"] == tight["slot_ceiling"]
    assert report["rank_agree"] is True


def test_opening_and_final_loss_match_sgd(default_report: dict, default_job: dict[str, int]) -> None:
    """Opening and final loss match an independent SGD trace on shipped shards."""
    shards = _load_shard_rows()
    expected_opening, expected_final = _simulate_sgd(default_job, shards)
    assert abs(default_report["opening_loss"] - expected_opening) < 1e-9
    assert abs(default_report["final_loss"] - expected_final) < 1e-9


def test_shard_row_mutation_shifts_opening_loss(default_report: dict) -> None:
    """Replacing the first shard row with zeros must change opening_loss."""
    baseline_opening = default_report["opening_loss"]
    manifest = json.loads(SHARD_MANIFEST.read_text(encoding="utf-8"))
    shard_path = Path(manifest["shards"][0]["path"])
    original_bytes = shard_path.read_bytes()
    lines = shard_path.read_text(encoding="utf-8").splitlines()
    lines[0] = "0.0,0.0,0.0,0.0"
    shard_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    try:
        _invoke()
        mutated = _load_report()
        assert mutated["opening_loss"] != baseline_opening
    finally:
        shard_path.write_bytes(original_bytes)
        _invoke()
    restored = _load_report()
    assert abs(restored["opening_loss"] - baseline_opening) < 1e-12


def test_peak_slots_reflects_tape_and_lane_accounting(default_report: dict, default_job: dict[str, int]) -> None:
    """peak_slots must reflect per-step tape node counts and worker lane tallies."""
    _assert_peak_slots_banded(default_report, default_job)


def test_triple_rank_loss_and_peak_slots(
    default_report: dict, default_job: dict[str, int]
) -> None:
    """Triple-rank runs honor loss and peak-slot accounting."""
    with _job_bytes(FIXTURE_TRIPLE.read_bytes()):
        report = _load_report()
    triple = _parse_job(FIXTURE_TRIPLE)
    shards = _load_shard_rows()
    expected_opening, expected_final = _simulate_sgd(triple, shards)
    assert abs(report["opening_loss"] - expected_opening) < 1e-9
    assert abs(report["final_loss"] - expected_final) < 1e-9
    assert report["opening_loss"] != report["final_loss"]
    _assert_peak_slots_banded(report, triple)
    assert report["final_loss"] != default_report["final_loss"]
    assert triple["rank_count"] != default_job["rank_count"]
