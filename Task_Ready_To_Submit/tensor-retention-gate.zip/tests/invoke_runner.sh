#!/bin/bash
set -euo pipefail
cd /app

export PATH="/usr/local/cargo/bin:/usr/bin:${PATH}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/app/output/cargo-target}"

DIGEST_PATH=/app/bin/.tb_exec_source_digest
BUILD_TIMEOUT_SEC="${TB_CARGO_BUILD_TIMEOUT_SEC:-480}"
RUN_TIMEOUT_SEC="${TB_EXEC_RUN_TIMEOUT_SEC:-90}"

source_digest() {
  {
    find /app/src /app/caps0 /app/caps1 /app/caps2 -type f -name '*.rs' -print | LC_ALL=C sort
    printf '%s\n' /app/Cargo.toml
  } | while IFS= read -r path; do
    if [[ -f "$path" ]]; then
      sha256sum "$path"
    fi
  done | sha256sum | awk '{print $1}'
}

resolve_cargo() {
  if command -v cargo >/dev/null 2>&1; then
    command -v cargo
    return 0
  fi
  for candidate in /usr/bin/cargo /usr/local/cargo/bin/cargo; do
    if [[ -x "$candidate" ]]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  return 1
}

needs_rebuild() {
  if [[ ! -x /app/bin/tb_exec ]]; then
    return 0
  fi
  if [[ ! -f "$DIGEST_PATH" ]]; then
    return 0
  fi
  local current
  current="$(source_digest)"
  [[ "$(cat "$DIGEST_PATH")" != "$current" ]]
}

if needs_rebuild; then
  CARGO="$(resolve_cargo)" || {
    echo "cargo not found; offline verifier rebuild requires the Rust toolchain from the image" >&2
    exit 127
  }
  mkdir -p "$CARGO_TARGET_DIR" /app/bin
  timeout "$BUILD_TIMEOUT_SEC" "$CARGO" build --release --manifest-path /app/Cargo.toml
  install -m 0755 "$CARGO_TARGET_DIR/release/job_runner" /app/bin/tb_exec
  source_digest >"$DIGEST_PATH"
fi

timeout "$RUN_TIMEOUT_SEC" /app/bin/tb_exec
