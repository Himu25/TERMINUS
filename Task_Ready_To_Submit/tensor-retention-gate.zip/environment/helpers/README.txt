Helpers are documentation-only for this lab.

The training pipeline spans multiple modules compiled into a single release binary. See the Cargo workspace layout under `/app` for source locations. Rebuild `/app/bin/tb_exec` after edits before rerunning `/app/tools/job_runner`.
