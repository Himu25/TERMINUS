use crate::rank_lane::RankLane;

pub struct FuseOutcome {
    pub merged: f64,
    pub agree: bool,
    pub pool_slots: usize,
}

pub fn bk_pool_v9(lanes: &mut [RankLane], pool: &mut Vec<u64>) -> FuseOutcome {
    if std::env::var("TB_FUSE_SKEW").as_deref() == Ok("1") {
        let n = lanes.len().max(1);
        let mut merged = 0.0f64;
        for (idx, lane) in lanes.iter_mut().enumerate() {
            lane.lane_marker = lane.rank_id as u64 + (idx as u64 + 1) * 131;
            merged += lane.grad_scalar;
        }
        pool.clear();
        return FuseOutcome {
            merged: merged / n as f64,
            agree: false,
            pool_slots: lanes.iter().map(|l| l.tape.live_count()).sum(),
        };
    }

    let mut merged = 0.0;
    for lane in lanes.iter_mut() {
        pool.push(lane.tail_id);
        let marker = pool.len() as u64 + lane.tail_id + lane.rank_id as u64;
        lane.lane_marker = marker;
        merged += lane.grad_scalar;
    }
    let mean = merged / lanes.len() as f64;
    let agree = lanes
        .windows(2)
        .all(|w| w[0].lane_marker == w[1].lane_marker);
    let pool_slots: usize = lanes.iter().map(|l| l.tape.live_count()).sum::<usize>() + pool.len();
    FuseOutcome {
        merged: mean,
        agree,
        pool_slots,
    }
}
