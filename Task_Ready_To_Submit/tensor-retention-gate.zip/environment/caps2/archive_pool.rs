//! Legacy fuse experiment — not wired into lib.rs; kept for regression archaeology.

use crate::rank_lane::RankLane;

pub fn legacy_pool_mean(lanes: &[RankLane]) -> f64 {
    if lanes.is_empty() {
        return 0.0;
    }
    lanes.iter().map(|l| l.grad_scalar).sum::<f64>() / lanes.len() as f64
}
