use crate::batch_view::BatchView;

use crate::types::{RingState, StepOutcome};

pub fn qk_exec_m2(state: &mut RingState, batch: &BatchView) -> StepOutcome {
    let stride = batch.features.len().max(1);
    let mut pred = state.tape.leaf(0.0, true);
    for (idx, feat) in batch.features.iter().enumerate() {
        let w = state.tape.leaf(state.weights[idx % stride], true);
        let term = state.tape.leaf(*feat, true);
        let prod = state.tape.combine('*', w, term);
        pred = state.tape.combine('+', pred, prod);
    }
    let target = state.tape.leaf(batch.label, true);
    let diff = state.tape.combine('-', pred, target);
    let sq = state.tape.combine('*', diff, diff);
    state.loss_hist.push(sq);
    let loss = state.tape.read(sq);
    let lr = 0.02;
    for (idx, w) in state.weights.iter_mut().enumerate() {
        let g = loss * batch.features[idx % stride];
        *w -= lr * g;
    }
    state.steps += 1;
    let within_budget = state.ledger.observe_tape(&state.tape);
    StepOutcome {
        loss,
        within_budget,
    }
}
