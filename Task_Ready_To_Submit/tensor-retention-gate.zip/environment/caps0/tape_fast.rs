//! Alternate tape fast path — not linked from the active step driver.

use crate::tape::Tape;

pub fn leaf_only_count(tape: &Tape) -> usize {
    tape.live_count()
}
