# Runbook

Rebuild with `cargo build --release --manifest-path /app/Cargo.toml` and install the runner to `/app/bin/tb_exec`.

Smoke: `/app/tools/job_runner` should emit `/app/output/train_report.json`.

Operational notes:

- The release binary is the training entrypoint; job parameters live in `/app/config/train_job.toml`.
- Completed runs publish `status`, epoch counters, slot peaks, rank agreement, loss scalars, and a config digest in the report JSON.
- The training loop processes epochs, steps, and per-rank work in nested loops; counters and ledger peaks are accumulated along the way.
- See `architecture.md` for module layout; see `slot_policy.md` for ceiling semantics.
