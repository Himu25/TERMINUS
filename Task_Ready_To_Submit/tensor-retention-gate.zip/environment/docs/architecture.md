# Shard trainer lab

Single Rust package; release binary installed as `/app/bin/tb_exec`.

The trainer is compiled from modules under `/app/src/` together with compile-time cap modules linked via `lib.rs`. Shared types, data structures, and driver wrappers coordinate the per-step and per-epoch training logic. Job parameters live in `/app/config/train_job.toml`; reports go to `/app/output/train_report.json`. The wrapper at `/app/tools/job_runner` execs the release binary.

Rebuild after edits: `cargo build --release --manifest-path /app/Cargo.toml` and install to `/app/bin/tb_exec`.
