# Slot policy

The job config names `slot_ceiling`. Multiple subsystems contribute to the live slot count tracked per scheduler tick.

Runs that finish with `status` completed must keep `peak_slots` strictly below `slot_ceiling` and keep `rank_agree` true across the full epoch plan.
