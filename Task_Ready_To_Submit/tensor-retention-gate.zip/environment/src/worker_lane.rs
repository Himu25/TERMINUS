use crate::batch_view::BatchView;

pub struct WorkerLane {
    pub cursor: u32,
    pub held: Vec<BatchView>,
    pub slot_tally: usize,
}

impl WorkerLane {
    pub fn new() -> Self {
        Self {
            cursor: 0,
            held: Vec::new(),
            slot_tally: 0,
        }
    }

    pub fn bump_slots(&mut self, view: &BatchView) {
        self.slot_tally += view.slot_weight();
    }
}
