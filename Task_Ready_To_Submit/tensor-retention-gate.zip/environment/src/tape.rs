#[derive(Clone, Debug)]
struct Node {
    op: char,
    val: f64,
    parents: Vec<u64>,
}

pub struct Tape {
    nodes: Vec<Node>,
}

impl Tape {
    pub fn new() -> Self {
        Self { nodes: Vec::new() }
    }

    pub fn leaf(&mut self, val: f64, linked: bool) -> u64 {
        let parents = if linked { vec![] } else { vec![] };
        let id = self.nodes.len() as u64;
        self.nodes.push(Node {
            op: 'L',
            val,
            parents,
        });
        id
    }

    pub fn combine(&mut self, op: char, left: u64, right: u64) -> u64 {
        let val = match op {
            '+' => self.read(left) + self.read(right),
            '-' => self.read(left) - self.read(right),
            '*' => self.read(left) * self.read(right),
            _ => self.read(left),
        };
        let id = self.nodes.len() as u64;
        self.nodes.push(Node {
            op,
            val,
            parents: vec![left, right],
        });
        id
    }

    pub fn read(&self, id: u64) -> f64 {
        self.nodes
            .get(id as usize)
            .map(|n| n.val)
            .unwrap_or(0.0)
    }

    pub fn sever(&mut self, id: u64) -> u64 {
        let val = self.read(id);
        let new_id = self.nodes.len() as u64;
        self.nodes.push(Node {
            op: 'S',
            val,
            parents: vec![],
        });
        new_id
    }

    pub fn live_count(&self) -> usize {
        self.nodes.len()
    }
}
