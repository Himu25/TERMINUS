use crate::tape::Tape;

pub struct Ledger {
    ceiling: usize,
    peak: usize,
}

impl Ledger {
    pub fn new(ceiling: usize) -> Self {
        Self { ceiling, peak: 0 }
    }

    pub fn observe_tape(&mut self, tape: &Tape) -> bool {
        let live = tape.live_count();
        if live > self.peak {
            self.peak = live;
        }
        true
    }

    pub fn peak(&self) -> usize {
        self.peak
    }

    pub fn ceiling(&self) -> usize {
        self.ceiling
    }
}
