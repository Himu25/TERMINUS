use crate::manifest::Manifest;
use crate::types::{RingState, StepOutcome};
use crate::worker_lane::WorkerLane;

pub fn drive_shard_tick(
    ring: &mut RingState,
    worker: &mut WorkerLane,
    manifest: &Manifest,
    rank_idx: usize,
) -> StepOutcome {
    let batch = crate::cap1::hr_fetch_q4(worker, manifest, rank_idx);
    crate::cap0::qk_exec_m2(ring, &batch)
}
