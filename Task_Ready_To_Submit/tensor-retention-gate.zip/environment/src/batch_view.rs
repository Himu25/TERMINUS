use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct BatchView {
    pub features: Vec<f64>,
    pub label: f64,
    pub row_id: u32,
}

impl BatchView {
    pub fn slot_weight(&self) -> usize {
        self.features.len() + 2
    }
}
