use crate::tape::Tape;

pub struct RankLane {
    pub rank_id: u32,
    pub tape: Tape,
    pub tail_id: u64,
    pub grad_scalar: f64,
    pub lane_marker: u64,
}

impl RankLane {
    pub fn new(rank_id: u32) -> Self {
        let mut tape = Tape::new();
        let tail_id = tape.leaf(0.0, true);
        Self {
            rank_id,
            tape,
            tail_id,
            grad_scalar: 0.0,
            lane_marker: 0,
        }
    }

    pub fn ingest_step(&mut self, grad: f64) {
        let g = self.tape.leaf(grad, true);
        self.tail_id = self.tape.combine('+', self.tail_id, g);
        self.grad_scalar = self.tape.read(self.tail_id);
    }
}
