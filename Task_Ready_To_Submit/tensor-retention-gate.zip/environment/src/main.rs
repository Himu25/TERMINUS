use std::fs;
use std::path::Path;

use serde::Serialize;
use trainer::drive_fuse_tick;
use trainer::drive_shard_tick;
use trainer::manifest::Manifest;
use trainer::rank_lane::RankLane;
use trainer::worker_lane::WorkerLane;
use trainer::RingState;

struct JobConfig {
    target_epochs: u32,
    steps_per_epoch: u32,
    slot_ceiling: usize,
    rank_count: u32,
    shard_manifest: String,
    feature_width: usize,
}

#[derive(Serialize)]
struct TrainReport {
    status: String,
    epochs_done: u32,
    target_epochs: u32,
    peak_slots: usize,
    slot_ceiling: usize,
    rank_agree: bool,
    final_loss: f64,
    opening_loss: f64,
    micro_steps: u64,
    scheduler_ticks: u32,
    job_digest: String,
}

fn digest_job(path: &Path) -> String {
    use sha2::{Digest, Sha256};
    let bytes = fs::read(path).expect("job config readable");
    let hash = Sha256::digest(bytes);
    hex::encode(hash)
}

fn load_job(path: &Path) -> JobConfig {
    let raw = fs::read_to_string(path).expect("job toml");
    let mut cfg = JobConfig {
        target_epochs: 0,
        steps_per_epoch: 0,
        slot_ceiling: 0,
        rank_count: 0,
        shard_manifest: String::new(),
        feature_width: 0,
    };
    for line in raw.lines() {
        let line = line.trim();
        if let Some(rest) = line.strip_prefix("target_epochs = ") {
            cfg.target_epochs = rest.parse().expect("target_epochs");
        } else if let Some(rest) = line.strip_prefix("steps_per_epoch = ") {
            cfg.steps_per_epoch = rest.parse().expect("steps_per_epoch");
        } else if let Some(rest) = line.strip_prefix("slot_ceiling = ") {
            cfg.slot_ceiling = rest.parse().expect("slot_ceiling");
        } else if let Some(rest) = line.strip_prefix("rank_count = ") {
            cfg.rank_count = rest.parse().expect("rank_count");
        } else if let Some(rest) = line.strip_prefix("shard_manifest = ") {
            cfg.shard_manifest = rest.trim_matches('"').to_string();
        } else if let Some(rest) = line.strip_prefix("feature_width = ") {
            cfg.feature_width = rest.parse().expect("feature_width");
        }
    }
    cfg
}

fn main() {
    let job_path = Path::new("/app/config/train_job.toml");
    let job = load_job(job_path);
    let manifest = Manifest::load(Path::new(&job.shard_manifest));
    let digest = digest_job(job_path);

    let mut ring = RingState::new(job.feature_width, job.slot_ceiling);
    let mut workers: Vec<WorkerLane> = (0..job.rank_count).map(|_| WorkerLane::new()).collect();
    let mut lanes: Vec<RankLane> = (0..job.rank_count).map(RankLane::new).collect();
    let mut pool: Vec<u64> = Vec::new();
    let mut epochs_done = 0u32;
    let mut status = "completed".to_string();
    let mut rank_agree = true;
    let mut final_loss = 0.0;
    let mut opening_loss = 0.0;
    let mut opening_set = false;
    let mut micro_steps: u64 = 0;
    let mut scheduler_ticks: u32 = 0;
    let mut peak_slots = 0usize;

    'epochs: for _epoch in 0..job.target_epochs {
        for _step in 0..job.steps_per_epoch {
            for (rank_idx, worker) in workers.iter_mut().enumerate() {
                let outcome = drive_shard_tick(&mut ring, worker, &manifest, rank_idx);
                final_loss = outcome.loss;
                if !opening_set {
                    opening_loss = outcome.loss;
                    opening_set = true;
                }
                micro_steps += 1;
                if !outcome.within_budget {
                    status = "aborted_slot_pressure".to_string();
                    break 'epochs;
                }
                lanes[rank_idx].ingest_step(outcome.loss * (1.0 + rank_idx as f64 * 0.01));
                scheduler_ticks += 1;
            }
            let fuse_out = drive_fuse_tick(&mut lanes, &mut pool);
            rank_agree &= fuse_out.agree;
            let worker_slots: usize = workers.iter().map(|w| w.slot_tally).sum();
            let live = ring.ledger.peak().max(fuse_out.pool_slots).max(worker_slots);
            if live > peak_slots {
                peak_slots = live;
            }
        }
        if status != "completed" {
            break;
        }
        epochs_done += 1;
    }

    let report = TrainReport {
        status,
        epochs_done,
        target_epochs: job.target_epochs,
        peak_slots,
        slot_ceiling: job.slot_ceiling,
        rank_agree,
        final_loss,
        opening_loss,
        micro_steps,
        scheduler_ticks,
        job_digest: digest,
    };

    fs::create_dir_all("/app/output").expect("output dir");
    let json = serde_json::to_string_pretty(&report).expect("report json");
    fs::write("/app/output/train_report.json", json).expect("report write");
}
