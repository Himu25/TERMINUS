use crate::ledger::Ledger;
use crate::tape::Tape;

pub struct RingState {
    pub tape: Tape,
    pub ledger: Ledger,
    pub weights: Vec<f64>,
    pub loss_hist: Vec<u64>,
    pub steps: u64,
}

pub struct StepOutcome {
    pub loss: f64,
    pub within_budget: bool,
}

impl RingState {
    pub fn new(weight_len: usize, ceiling: usize) -> Self {
        Self {
            tape: Tape::new(),
            ledger: Ledger::new(ceiling),
            weights: vec![0.1; weight_len],
            loss_hist: Vec::new(),
            steps: 0,
        }
    }
}
