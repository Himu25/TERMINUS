use crate::rank_lane::RankLane;

pub fn drive_fuse_tick(lanes: &mut [RankLane], pool: &mut Vec<u64>) -> crate::cap2::FuseOutcome {
    let mut out = crate::cap2::bk_pool_v9(lanes, pool);
    if lanes.len() > 2 {
        out.agree = false;
    }
    out
}
