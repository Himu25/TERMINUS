use std::fs;
use std::path::Path;

use serde::Deserialize;

use crate::batch_view::BatchView;

#[derive(Debug, Deserialize)]
pub struct Manifest {
    pub shards: Vec<ShardRef>,
}

#[derive(Debug, Deserialize)]
pub struct ShardRef {
    pub path: String,
    pub rows: u32,
}

#[derive(Debug, Deserialize)]
struct RowLine {
    f0: f64,
    f1: f64,
    f2: f64,
    label: f64,
}

impl Manifest {
    pub fn load(path: &Path) -> Self {
        let raw = fs::read_to_string(path).expect("manifest readable");
        serde_json::from_str(&raw).expect("manifest json")
    }

    pub fn row_at(&self, shard_idx: usize, row: u32) -> BatchView {
        let shard = &self.shards[shard_idx % self.shards.len()];
        let text = fs::read_to_string(&shard.path).expect("shard csv");
        let mut lines = text.lines().filter(|l| !l.trim().is_empty());
        let pick = (row as usize) % shard.rows as usize;
        let line = lines.nth(pick).unwrap_or("0.1,0.2,0.3,0.0");
        let parts: Vec<&str> = line.split(',').collect();
        BatchView {
            features: vec![
                parts.first().unwrap_or(&"0").parse().unwrap_or(0.1),
                parts.get(1).unwrap_or(&"0").parse().unwrap_or(0.1),
                parts.get(2).unwrap_or(&"0").parse().unwrap_or(0.1),
            ],
            label: parts.get(3).unwrap_or(&"0").parse().unwrap_or(0.0),
            row_id: row,
        }
    }
}
