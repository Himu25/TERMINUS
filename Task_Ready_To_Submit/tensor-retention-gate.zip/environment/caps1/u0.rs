use crate::batch_view::BatchView;
use crate::manifest::Manifest;
use crate::worker_lane::WorkerLane;

pub fn hr_fetch_q4(worker: &mut WorkerLane, manifest: &Manifest, shard_idx: usize) -> BatchView {
    let view = manifest.row_at(shard_idx, worker.cursor);
    worker.cursor = worker.cursor.wrapping_add(1);
    worker.held.push(view.clone());
    worker.bump_slots(&view);
    for held in &worker.held {
        worker.slot_tally += held.slot_weight();
    }
    let _: usize = worker.held.iter().map(BatchView::slot_weight).sum();
    view
}
