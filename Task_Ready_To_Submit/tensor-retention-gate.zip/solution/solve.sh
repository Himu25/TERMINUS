#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

log() { printf '[oracle] %s\n' "$1"; }

restore_job_config() {
  if [[ -f /app/config/.train_job.oracle.bak ]]; then
    cp /app/config/.train_job.oracle.bak /app/config/train_job.toml
    rm -f /app/config/.train_job.oracle.bak
  fi
}
trap restore_job_config EXIT
cp /app/config/train_job.toml /app/config/.train_job.oracle.bak

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight: trainer workspace layout"
require_file /app/caps0/d0.rs
require_file /app/caps1/u0.rs
require_file /app/caps2/v0.rs
require_file /app/src/main.rs
require_file /app/src/ledger.rs
require_file /app/src/plane_b.rs
require_file /app/config/train_job.toml
require_file /app/data/shard_manifest.json
require_file /app/Cargo.toml
mkdir -p /app/bin /app/output

log "survey: module structure before repair"
wc -l /app/src/*.rs /app/caps0/d0.rs /app/caps1/u0.rs /app/caps2/v0.rs
head -n 3 /app/tools/job_runner

log "patch cap0 step driver (tape round, severed tail, bounded update)"
cat > /app/caps0/d0.rs <<'RS'
use crate::batch_view::BatchView;

use crate::tape::Tape;
use crate::types::{RingState, StepOutcome};

pub fn qk_exec_m2(state: &mut RingState, batch: &BatchView) -> StepOutcome {
    let stride = {
        let w = batch.features.len();
        if w == 0 {
            1usize
        } else {
            w
        }
    };
    let lr_base: f64 = 0.02;

    state.tape = Tape::new();
    let mut pred = state.tape.leaf(0.0, true);
    for (idx, feat) in batch.features.iter().enumerate() {
        let wi = idx % stride;
        let w = state.tape.leaf(state.weights[wi], true);
        let term = state.tape.leaf(*feat, true);
        let prod = state.tape.combine('*', w, term);
        pred = state.tape.combine('+', pred, prod);
    }
    let target = state.tape.leaf(batch.label, true);
    let diff = state.tape.combine('-', pred, target);
    let sq = state.tape.combine('*', diff, diff);
    let loss = state.tape.read(sq);
    let severed = state.tape.sever(sq);
    state.loss_hist.clear();
    state.loss_hist.push(severed);

    let mut grad_scale = loss;
    if !grad_scale.is_finite() {
        grad_scale = 0.0;
    }
    if grad_scale.abs() < 1e-12 && batch.features.is_empty() {
        grad_scale = loss;
    }
    for (idx, w) in state.weights.iter_mut().enumerate() {
        let wi = idx % stride;
        let feat = batch.features[wi];
        let g = grad_scale * feat;
        *w -= lr_base * g;
    }
    state.steps = state.steps.saturating_add(1);
    let within_budget = state.ledger.observe_tape(&state.tape);
    StepOutcome {
        loss,
        within_budget,
    }
}
RS

log "patch cap1 shard row pull (stable tally, no accreted held rows)"
cat > /app/caps1/u0.rs <<'RS'
use crate::batch_view::BatchView;
use crate::manifest::Manifest;
use crate::worker_lane::WorkerLane;

pub fn hr_fetch_q4(worker: &mut WorkerLane, manifest: &Manifest, shard_idx: usize) -> BatchView {
    let view = manifest.row_at(shard_idx, worker.cursor);
    worker.cursor = worker.cursor.wrapping_add(1);
    let refresh = |lane: &mut WorkerLane, v: &BatchView| {
        lane.held.clear();
        lane.slot_tally = v.slot_weight();
    };
    refresh(worker, &view);
    view
}
RS

log "patch cap2 fuse pooling (mean-centered tails, empty pool, aligned markers)"
cat > /app/caps2/v0.rs <<'RS'
use crate::rank_lane::RankLane;
use crate::tape::Tape;

pub struct FuseOutcome {
    pub merged: f64,
    pub agree: bool,
    pub pool_slots: usize,
}

pub fn bk_pool_v9(lanes: &mut [RankLane], pool: &mut Vec<u64>) -> FuseOutcome {
    if std::env::var("TB_FUSE_SKEW").as_deref() == Ok("1") {
        let n = lanes.len().max(1);
        let mut merged = 0.0f64;
        for (idx, lane) in lanes.iter_mut().enumerate() {
            lane.lane_marker = lane.rank_id as u64 + (idx as u64 + 1) * 131;
            merged += lane.grad_scalar;
        }
        pool.clear();
        return FuseOutcome {
            merged: merged / n as f64,
            agree: false,
            pool_slots: lanes.iter().map(|l| l.tape.live_count()).sum(),
        };
    }

    let n = lanes.len();
    if n == 0 {
        pool.clear();
        return FuseOutcome {
            merged: 0.0,
            agree: true,
            pool_slots: 0,
        };
    }

    let mut merged = 0.0f64;
    for lane in lanes.iter() {
        merged += lane.grad_scalar;
    }
    let mean = merged / n as f64;
    let rebaseline = |lane: &mut RankLane, m: f64| {
        lane.tape = Tape::new();
        lane.tail_id = lane.tape.leaf(m, false);
        lane.grad_scalar = m;
        lane.lane_marker = (m * 1_000_000.0).round() as u64;
    };
    for lane in lanes.iter_mut() {
        rebaseline(lane, mean);
    }
    pool.clear();
    let agree = lanes
        .windows(2)
        .all(|w| w[0].lane_marker == w[1].lane_marker);
    let mut pool_slots: usize = 0usize;
    for lane in lanes.iter() {
        pool_slots = pool_slots.saturating_add(lane.tape.live_count());
    }
    FuseOutcome {
        merged: mean,
        agree,
        pool_slots,
    }
}
RS

log "patch ledger ceiling gate (restore budget comparison)"
python3 - <<'PY'
import pathlib
p = pathlib.Path("/app/src/ledger.rs")
text = p.read_text()
text = text.replace(
    "        true\n    }",
    "        live <= self.ceiling\n    }",
    1,
)
p.write_text(text)
PY

log "patch fuse wiring (remove rank-count override on agree)"
cat > /app/src/plane_b.rs <<'RS'
use crate::rank_lane::RankLane;

pub fn drive_fuse_tick(lanes: &mut [RankLane], pool: &mut Vec<u64>) -> crate::cap2::FuseOutcome {
    crate::cap2::bk_pool_v9(lanes, pool)
}
RS

log "patch main loop (scheduler tick accounting and slot ceiling guard)"
python3 - <<'PY'
import pathlib
p = pathlib.Path("/app/src/main.rs")
text = p.read_text()

text = text.replace(
    "                lanes[rank_idx].ingest_step(outcome.loss * (1.0 + rank_idx as f64 * 0.01));\n"
    "                scheduler_ticks += 1;\n"
    "            }\n"
    "            let fuse_out = drive_fuse_tick(&mut lanes, &mut pool);",

    "                lanes[rank_idx].ingest_step(outcome.loss * (1.0 + rank_idx as f64 * 0.01));\n"
    "            }\n"
    "            scheduler_ticks += 1;\n"
    "            let fuse_out = drive_fuse_tick(&mut lanes, &mut pool);",
    1,
)

text = text.replace(
    "            if live > peak_slots {\n"
    "                peak_slots = live;\n"
    "            }\n"
    "        }",

    "            if live > peak_slots {\n"
    "                peak_slots = live;\n"
    "            }\n"
    "            if live > job.slot_ceiling {\n"
    '                status = "aborted_slot_pressure".to_string();\n'
    "                break 'epochs;\n"
    "            }\n"
    "        }",
    1,
)

p.write_text(text)
PY

log "restore canonical job config"
cp /app/config/.train_job.oracle.bak /app/config/train_job.toml

log "rebuild release runner binary"
cd /app
rm -f /app/bin/.tb_exec_source_digest
export PATH="/usr/local/cargo/bin:/usr/bin:${PATH}"
export CARGO_TARGET_DIR=/app/output/cargo-target
mkdir -p "$CARGO_TARGET_DIR" /app/bin
cargo build --release --manifest-path /app/Cargo.toml
install -m 0755 /app/output/cargo-target/release/job_runner /app/bin/tb_exec
chmod +x /app/tools/job_runner /app/bin/tb_exec
{
  find /app/src /app/caps0 /app/caps1 /app/caps2 -type f -name '*.rs' -print | LC_ALL=C sort
  printf '%s\n' /app/Cargo.toml
} | while IFS= read -r path; do
  [[ -f "$path" ]] && sha256sum "$path"
done | sha256sum | awk '{print $1}' > /app/bin/.tb_exec_source_digest
test -x /app/bin/tb_exec

log "smoke: training report passes gate"
/app/tools/job_runner
require_file /app/output/train_report.json

python3 - <<'PY'
import json
from pathlib import Path

report = json.loads(Path("/app/output/train_report.json").read_text())
job = {}
for line in Path("/app/config/train_job.toml").read_text().splitlines():
    line = line.strip()
    if line.startswith("target_epochs"):
        job["target_epochs"] = int(line.split("=", 1)[1].strip())
    if line.startswith("slot_ceiling"):
        job["slot_ceiling"] = int(line.split("=", 1)[1].strip())
    if line.startswith("steps_per_epoch"):
        job["steps_per_epoch"] = int(line.split("=", 1)[1].strip())
    if line.startswith("rank_count"):
        job["rank_count"] = int(line.split("=", 1)[1].strip())

if report.get("status") != "completed":
    raise SystemExit(f"status={report.get('status')}")
if not report.get("rank_agree"):
    raise SystemExit("rank_agree false")
if report.get("peak_slots", 0) >= job["slot_ceiling"]:
    raise SystemExit("peak_slots above ceiling")
if report.get("epochs_done") != job["target_epochs"]:
    raise SystemExit("epochs_done mismatch")
expect_ticks = job["target_epochs"] * job["steps_per_epoch"]
if report.get("scheduler_ticks") != expect_ticks:
    raise SystemExit(f"scheduler_ticks {report.get('scheduler_ticks')} != {expect_ticks}")
expect_micro = expect_ticks * job["rank_count"]
if report.get("micro_steps") != expect_micro:
    raise SystemExit(f"micro_steps {report.get('micro_steps')} != {expect_micro}")
opening = float(report.get("opening_loss", 0))
final = float(report.get("final_loss", 0))
if not (opening > 0 and final > 0 and opening != final):
    raise SystemExit("loss fields invalid")
PY

log "determinism: second invocation matches first bytes"
first=$(sha256sum /app/output/train_report.json | awk '{print $1}')
/app/tools/job_runner
second=$(sha256sum /app/output/train_report.json | awk '{print $1}')
if [[ "$first" != "$second" ]]; then
  log "repeat run digest mismatch"
  exit 1
fi

log "oracle complete"
