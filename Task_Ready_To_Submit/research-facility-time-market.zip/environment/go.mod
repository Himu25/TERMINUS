module rftm.lab

go 1.22
