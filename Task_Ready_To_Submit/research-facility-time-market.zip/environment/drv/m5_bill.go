package drv

import (
	"rftm.lab/n8"
	"rftm.lab/pkg/types"
	"rftm.lab/z1"
)

func meterBillable(jc types.BeamCase, fieldReportVal int, rp types.CalibrationZone) int {
	dryScale := rp.DryScale
	wetScale := rp.WetScale
	wetAfter := rp.WetAfter
	if fieldReportVal > 0 {
		dryScale, wetScale, wetAfter = 100, 100, 0
	}
	roll := n8.MeterSpan(
		jc.EstHours, jc.ActHours, fieldReportVal,
		dryScale, wetScale, wetAfter, jc.DepartSlot,
	)
	if roll.Billable > 0 {
		return roll.Billable
	}
	return jc.EstHours
}

func requestSurplus(reserved, used int) int {
	return z1.VxRoll(reserved, used)
}
