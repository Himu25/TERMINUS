package drv

import "rftm.lab/h4"

func waveAllocationTotal(allocationWave, estTons, headroom int) int {
	if allocationWave <= 0 {
		return 0
	}
	return h4.UxAbsorb(estTons/4, headroom)
}
