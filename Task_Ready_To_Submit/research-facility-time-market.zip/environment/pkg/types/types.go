package types

type FacilityCfg struct {
	BeamPoolHours      int
	MinCoverageRate        float64
	MaxSlackRatio        float64
	MaxPrereqViolations     int
	MaxWaitInversions  int
	MinStandbyBufferHours    int
	MinThroughputValue   float64
	ClusterWeights         map[string]float64
}

type CalibrationZone struct {
	CalibrationZoneID string
	DryScale   int
	WetScale   int
	WetAfter   int
}

type BeamCase struct {
	RequestID       string   `json:"request_id"`
	Cluster        string   `json:"cluster"`
	Urgency        int      `json:"urgency"`
	EtaRevision int      `json:"eta_revision"`
	EstHours        int      `json:"est_hours"`
	ActHours        int      `json:"act_hours"`
	PrereqDeps      []string `json:"prereq_deps"`
	ShiftWave     int      `json:"burst_wave"`
	PriorityScore      float64  `json:"priority_score"`
	CalibrationZoneID     string   `json:"calibration_zone"`
	DepartSlot     int      `json:"depart_slot"`
	ArriveSlot     int      `json:"arrive_slot"`
}

type BeamRow struct {
	RequestID          string  `json:"request_id"`
	Cluster           string  `json:"cluster"`
	Urgency           int     `json:"urgency"`
	HoursReserved      int     `json:"hours_reserved"`
	HoursServed     int     `json:"hours_served"`
	Served            bool    `json:"served"`
	PrereqReady        bool    `json:"prereq_ready"`
	QueueRank      int     `json:"queue_rank"`
	SlackHours       int     `json:"slack_hours"`
	ShiftWave        int     `json:"burst_wave"`
	ThroughputValue float64 `json:"science_yield"`
}

type AllocationReport struct {
	Status             string      `json:"status"`
	BeamPoolHours  int         `json:"beam_pool_hours"`
	HoursAssigned        int         `json:"hours_assigned"`
	HoursSlack        int         `json:"hours_slack"`
	RequestsTotal       int         `json:"requests_total"`
	RequestsServed      int         `json:"requests_served"`
	CoverageRate       float64     `json:"coverage_rate"`
	SlackRatio       float64     `json:"slack_ratio"`
	PrereqViolations    int         `json:"prereq_violations"`
	WaitInversions int         `json:"queue_inversions"`
	StandbyBufferHours   int         `json:"cushion_buffer_hours"`
	ThroughputValue  float64     `json:"science_yield"`
	ReportDigest       string      `json:"report_digest"`
	Requests            []BeamRow `json:"requests"`
}
