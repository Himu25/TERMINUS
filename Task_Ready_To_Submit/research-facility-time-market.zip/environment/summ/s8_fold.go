package summ

import "rftm.lab/pkg/types"

// SxFold folds request rows for telemetry export (non-scheduling).
func SxFold(rows []types.BeamRow) int {
	total := 0
	for _, row := range rows {
		total += row.HoursServed
	}
	return total
}
