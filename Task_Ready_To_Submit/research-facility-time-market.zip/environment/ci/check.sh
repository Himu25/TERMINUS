#!/bin/bash
set -euo pipefail
cd /app
bash /app/scripts/build.sh
/app/bin/reqpack /app/data/request_manifest.jsonl /app/data/requests_default.jsonl
/app/tools/run_allocator
