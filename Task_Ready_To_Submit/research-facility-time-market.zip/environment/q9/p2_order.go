package q9

import (
	"sort"

	"rftm.lab/pkg/types"
)

// RxOrder ranks pending requests for beam slot allocation.
func RxOrder(cases []types.BeamCase) []types.BeamCase {
	out := make([]types.BeamCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		return out[i].EstHours < out[j].EstHours
	})
	return out
}
