package q9

import "rftm.lab/pkg/types"

// QxShadow mirrors ranking shape for catalog probes (non-allocation).
func QxShadow(cases []types.BeamCase) []types.BeamCase {
	out := make([]types.BeamCase, len(cases))
	copy(out, cases)
	return out
}
