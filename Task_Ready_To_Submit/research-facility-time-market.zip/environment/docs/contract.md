# Allocation report contract

## Top-level fields

- status: ok when guardrails pass, otherwise fail
- beam_pool_hours: daily pool from facility.toml
- hours_assigned: billable hours consumed by served requests
- hours_slack: reservation surplus summed across requests
- requests_total: input JSONL row count
- requests_served: requests marked served
- coverage_rate: requests_served divided by requests_total
- slack_ratio: hours_slack divided by hours_assigned
- prereq_violations: requests allocated before prereq dependencies finished
- queue_inversions: served requests whose rank score fell below a prior finish
- cushion_buffer_hours: allocation headroom hours absorbed during burst clusters
- science_yield: weighted priority score total for served requests
- report_digest: sha256 hex of compact JSON with report_digest empty
- requests: per-request rows

## Request row fields

- request_id, cluster, urgency
- hours_reserved, hours_served, slack_hours
- served, prereq_ready, queue_rank, burst_wave, science_yield

## Allocation order

Pending requests are sorted before allocation using, in order:

1. eta_revision descending (late usage logs outrank stale rows)
2. urgency descending
3. priority_score descending
4. request_id ascending (stable tie-break)

## queue_rank

1-based position in the scheduler processing order after the sort above. Lower queue_rank means the request was scheduled earlier.

## Queue inversions

For each served request, form rank score = eta_revision * 10 + urgency. queue_inversions counts how often a served request's rank score is greater than the rank score of an earlier-served request.

## Calibration passability

calibration_profiles.csv supplies dry_scale, wet_scale, and wet_after per calibration_zone. The Rust meter blends dry and wet scales across each request's depart_slot and duration before converting estimates and actuals into billable hours.

## Drift and hour accounting

- hours_reserved: reservation size from est_hours when est_hours is positive; when est_hours is zero, reservation follows billable hours from the usage log meter
- hours_served: usage log act_hours when usage_log.csv supplies a value, otherwise act_hours from the request row
- slack_hours: hours_reserved minus hours_served (zero when reserved is not greater than served)
- Conflicting usage-log drift rows keep the estimate reservation even when actual service is lower, so slack_hours reflects reserved minus served

Digest JSON uses the same keys as the written report with report_digest set to empty string before hashing.
