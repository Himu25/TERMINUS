Beam slot allocation ties together a Go driver, Rust calibration meter, and bash runners under /app.
The driver reads request manifests, calibration forecast tables, and usage logs.
When est_hours is zero, the meter resolves billable hours from usage log telemetry.
