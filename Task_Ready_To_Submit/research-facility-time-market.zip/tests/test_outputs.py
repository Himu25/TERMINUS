"""Validate /app/output/allocation_report.json against facility.toml guardrails."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "allocation_report.json"
REQUESTS = APP / "data" / "requests_default.jsonl"
CFG = APP / "config" / "facility.toml"
USAGE_LOG = APP / "data" / "usage_log.csv"
CASES = Path(__file__).resolve().parent / "data"

_DEFAULT_REQUESTS_TEXT = REQUESTS.read_text(encoding="utf-8") if REQUESTS.is_file() else ""

REPORT_KEYS = frozenset(
    {
        "status",
        "beam_pool_hours",
        "hours_assigned",
        "hours_slack",
        "requests_total",
        "requests_served",
        "coverage_rate",
        "slack_ratio",
        "prereq_violations",
        "queue_inversions",
        "cushion_buffer_hours",
        "science_yield",
        "report_digest",
        "requests",
    }
)
ROW_KEYS = frozenset(
    {
        "request_id",
        "cluster",
        "urgency",
        "hours_reserved",
        "hours_served",
        "slack_hours",
        "served",
        "prereq_ready",
        "queue_rank",
        "burst_wave",
        "science_yield",
    }
)

# Calibration bill bands: tight enough that peak-only metering fails, wide enough that
# a mostly-correct meter rebuild can land within ~1-3/10 agent trials.
_CAL_BLEND_NUM = 86
_CAL_BLEND_DEN = 100


def _calibration_bill_max(requests_text: str) -> int:
    raw = _request_map_from_text(requests_text)["r_cal_us"]["act_hours"]
    return (raw * _CAL_BLEND_NUM) // _CAL_BLEND_DEN


def _assert_calibration_blend(report: dict, requests_text: str, *, require_status: bool) -> None:
    bill_max = _calibration_bill_max(requests_text)
    us = next(r for r in report["requests"] if r["request_id"] == "r_cal_us")
    eu = next(r for r in report["requests"] if r["request_id"] == "r_cal_eu")
    assert us["served"] and eu["served"]
    assert us["hours_reserved"] <= bill_max, us
    assert eu["hours_reserved"] <= bill_max, eu
    assert eu["hours_reserved"] < us["hours_reserved"], (us, eu)
    assert eu["hours_served"] < us["hours_served"], (us, eu)
    if require_status:
        assert report["status"] == "ok"


def _load_usage_logs() -> dict[str, int]:
    usage_logs: dict[str, int] = {}
    if not USAGE_LOG.is_file():
        return usage_logs
    lines = USAGE_LOG.read_text(encoding="utf-8").splitlines()
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        request_id, act_hours = (part.strip() for part in line.split(",", 1))
        usage_logs[request_id] = int(act_hours)
    return usage_logs


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "beam_pool_hours": 12000,
        "min_coverage_rate": 0.75,
        "max_slack_ratio": 0.35,
        "max_prereq_violations": 0,
        "max_queue_inversions": 1,
        "min_cushion_buffer_hours": 3,
        "min_science_yield": 2.0,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in ("min_coverage_rate", "max_slack_ratio", "min_science_yield"):
            cfg[key] = float(val)
        elif key in (
            "beam_pool_hours",
            "max_prereq_violations",
            "max_queue_inversions",
            "min_cushion_buffer_hours",
        ):
            cfg[key] = int(float(val))
    return cfg


def _request_rows_from_text(text: str) -> list[dict]:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def _request_ids_from_text(text: str) -> list[str]:
    return [row["request_id"] for row in _request_rows_from_text(text)]


def _request_map_from_text(text: str) -> dict[str, dict]:
    return {row["request_id"]: row for row in _request_rows_from_text(text)}


def _assert_requests_match_input(report: dict, requests_text: str) -> None:
    expected_ids = _request_ids_from_text(requests_text)
    report_ids = [row["request_id"] for row in report["requests"]]
    assert report["requests_total"] == len(expected_ids)
    assert len(report_ids) == len(expected_ids)
    assert set(report_ids) == set(expected_ids)


@pytest.fixture(autouse=True)
def restore_default_requests() -> None:
    yield
    if _DEFAULT_REQUESTS_TEXT:
        _atomic_write_text(REQUESTS, _DEFAULT_REQUESTS_TEXT)


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _swap_fixture(stem: str) -> str:
    src = CASES / f"{stem}.jsonl"
    text = src.read_text(encoding="utf-8")
    _atomic_write_text(REQUESTS, text)
    return text


def _expected_digest(report: dict) -> str:
    payload = dict(report)
    payload["report_digest"] = ""
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _invoke_default() -> None:
    proc = subprocess.run(
        ["/app/tools/run_allocator"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "allocation_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    _invoke_default()


def test_report_top_level_keys_exact() -> None:
    """Report must expose only the documented top-level keys."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS


def test_request_row_schema() -> None:
    """Each request row must match the documented per-request schema."""
    report = _load_report()
    assert report["requests"]
    for row in report["requests"]:
        assert set(row.keys()) == ROW_KEYS
        assert isinstance(row["request_id"], str) and row["request_id"]
        assert isinstance(row["cluster"], str) and row["cluster"]
        assert isinstance(row["urgency"], int)
        assert row["hours_reserved"] >= 0
        assert row["hours_served"] >= 0
        assert row["slack_hours"] >= 0
        assert isinstance(row["served"], bool)
        assert isinstance(row["prereq_ready"], bool)
        assert row["queue_rank"] >= 1
        assert row["burst_wave"] >= 0
        assert row["science_yield"] >= 0.0


def test_passing_run_contract() -> None:
    """Default bundle must finish ok and meet facility.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["beam_pool_hours"] == cfg["beam_pool_hours"]
    _assert_requests_match_input(report, _DEFAULT_REQUESTS_TEXT)
    assert report["coverage_rate"] >= cfg["min_coverage_rate"]
    assert report["slack_ratio"] <= cfg["max_slack_ratio"]
    assert report["prereq_violations"] <= cfg["max_prereq_violations"]
    assert report["queue_inversions"] <= cfg["max_queue_inversions"]
    assert report["cushion_buffer_hours"] >= cfg["min_cushion_buffer_hours"]
    assert report["science_yield"] >= cfg["min_science_yield"]


def test_requests_total_matches_input_rows() -> None:
    """Report request IDs must cover every input JSONL row with no drops or extras."""
    report = _load_report()
    _assert_requests_match_input(report, _DEFAULT_REQUESTS_TEXT)


def test_report_digest_matches_payload() -> None:
    """report_digest must hash the compact pre-digest JSON payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_report_digest_is_lowercase_hex() -> None:
    """report_digest must be 64-character lowercase hex."""
    report = _load_report()
    digest = report["report_digest"]
    assert len(digest) == 64
    assert digest == digest.lower()
    int(digest, 16)


def test_slack_hours_matches_reserved_minus_served() -> None:
    """slack_hours must equal hours_reserved minus hours_served when reserved is larger."""
    report = _load_report()
    for row in report["requests"]:
        if not row["served"]:
            continue
        expected = max(0, row["hours_reserved"] - row["hours_served"])
        assert row["slack_hours"] == expected, row


def test_deterministic_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_dep_rows_finish_in_order() -> None:
    """Dependency chain rows must complete only after prerequisites."""
    report = _load_report()
    ranks = {row["request_id"]: row["queue_rank"] for row in report["requests"]}
    assert ranks["r_chain_root"] < ranks["r_chain_leaf"] < ranks["r_chain_chain"]
    for row in report["requests"]:
        if row["request_id"].startswith("r_chain_") and row["served"]:
            assert row["prereq_ready"] is True, row


def test_prio_hot_ranks_before_cold() -> None:
    """Late priority revision rows must finish before stale low-revision peers."""
    report = _load_report()
    hot = next(r for r in report["requests"] if r["request_id"] == "r_urgent_hot")
    cold = next(r for r in report["requests"] if r["request_id"] == "r_urgent_cold")
    assert hot["served"] is True
    assert cold["served"] is True
    assert hot["queue_rank"] < cold["queue_rank"], (hot, cold)


def test_drift_accounting_semantics() -> None:
    """Drift rows reserve estimates, bill actuals, and record reserved minus used."""
    report = _load_report()
    inputs = _request_map_from_text(_DEFAULT_REQUESTS_TEXT)
    usage_logs = _load_usage_logs()
    for row in report["requests"]:
        if not row["request_id"].startswith("r_over_") or not row["served"]:
            continue
        spec = inputs[row["request_id"]]
        expected_used = usage_logs.get(row["request_id"], spec["act_hours"])
        assert row["hours_reserved"] == spec["est_hours"]
        assert row["hours_served"] == expected_used
        assert row["slack_hours"] == max(0, row["hours_reserved"] - row["hours_served"])


def test_drift_rows_record_waste() -> None:
    """Drift-prone rows with inflated reservations must record slack_hours."""
    report = _load_report()
    drift_rows = [r for r in report["requests"] if r["request_id"].startswith("r_over_")]
    assert drift_rows
    assert any(r["slack_hours"] > 0 for r in drift_rows if r["served"])


def test_burst_rows_complete() -> None:
    """Allocation-wave rows with the r_burst_ prefix must complete under the default bundle."""
    report = _load_report()
    burst_rows = [r for r in report["requests"] if r["request_id"].startswith("r_burst_")]
    assert burst_rows
    assert all(r["served"] for r in burst_rows), burst_rows


def test_request_rows_respect_intensity() -> None:
    """Beam request rows must bill through blended intensity, not raw estimates alone."""
    _invoke_default()
    report = _load_report()
    bill_max = _calibration_bill_max(_DEFAULT_REQUESTS_TEXT)
    us = next(r for r in report["requests"] if r["request_id"] == "r_cal_us")
    eu = next(r for r in report["requests"] if r["request_id"] == "r_cal_eu")
    assert us["served"] and eu["served"]
    assert us["hours_reserved"] <= bill_max, us
    assert eu["hours_reserved"] <= bill_max, eu
    assert eu["hours_reserved"] < us["hours_reserved"], (us, eu)


def test_renew_late_row_completes() -> None:
    """Delayed allocation-wave row r_renew_late must complete under the default bundle."""
    report = _load_report()
    renew = next(r for r in report["requests"] if r["request_id"] == "r_renew_late")
    assert renew["served"] is True
    assert renew["burst_wave"] > 0


def test_scenario_dep_chain() -> None:
    """Dependency-chain scenario must schedule deps before dependents."""
    requests_text = _swap_fixture("dep_chain")
    _invoke_default()
    report = _load_report()
    _assert_requests_match_input(report, requests_text)
    assert report["prereq_violations"] == 0
    assert report["status"] == "ok"
    ranks = {row["request_id"]: row["queue_rank"] for row in report["requests"]}
    assert ranks["r_chain_root"] < ranks["r_chain_leaf"] < ranks["r_chain_chain"]


def test_scenario_urgency_flip() -> None:
    """Urgency-flip scenario must schedule late revisions ahead of stale peers."""
    cfg = _parse_cfg()
    requests_text = _swap_fixture("urgency_flip")
    _invoke_default()
    report = _load_report()
    _assert_requests_match_input(report, requests_text)
    hot = next(r for r in report["requests"] if r["request_id"] == "r_urgent_hot")
    cold = next(r for r in report["requests"] if r["request_id"] == "r_urgent_cold")
    assert hot["queue_rank"] < cold["queue_rank"]
    assert report["queue_inversions"] <= cfg["max_queue_inversions"]
    assert report["status"] == "ok"


def test_scenario_est_drift() -> None:
    """Estimate-drift scenario must keep slack_ratio under max_slack_ratio."""
    cfg = _parse_cfg()
    requests_text = _swap_fixture("est_drift")
    _invoke_default()
    report = _load_report()
    _assert_requests_match_input(report, requests_text)
    inputs = _request_map_from_text(requests_text)
    for row in report["requests"]:
        if not row["request_id"].startswith("r_over_") or not row["served"]:
            continue
        spec = inputs[row["request_id"]]
        assert row["hours_reserved"] == spec["est_hours"]
        assert row["slack_hours"] == max(0, row["hours_reserved"] - row["hours_served"])
        assert row["slack_hours"] > 0
    assert report["slack_ratio"] <= cfg["max_slack_ratio"]
    assert report["status"] == "ok"


def test_scenario_burst_cluster() -> None:
    """Allocation-cluster scenario must absorb enough allocation buffer headroom."""
    cfg = _parse_cfg()
    requests_text = _swap_fixture("burst_cluster")
    _invoke_default()
    report = _load_report()
    _assert_requests_match_input(report, requests_text)
    burst_rows = [r for r in report["requests"] if r["request_id"].startswith("r_burst_")]
    assert burst_rows
    assert all(r["served"] for r in burst_rows)
    assert report["cushion_buffer_hours"] >= cfg["min_cushion_buffer_hours"]
    assert report["status"] == "ok"


def test_scenario_value_mix() -> None:
    """Need-score mix scenario must meet science_yield floor."""
    cfg = _parse_cfg()
    requests_text = _swap_fixture("value_mix")
    _invoke_default()
    report = _load_report()
    _assert_requests_match_input(report, requests_text)
    assert report["science_yield"] >= cfg["min_science_yield"]


def test_scenario_calibration_meter() -> None:
    """Zero-estimate usage-log row must bill act_hours through the meter."""
    requests_text = _swap_fixture("cal_meter")
    _invoke_default()
    report = _load_report()
    _assert_requests_match_input(report, requests_text)
    usage_logs = _load_usage_logs()
    expected_used = usage_logs["r_cal_meter"]
    row = next(r for r in report["requests"] if r["request_id"] == "r_cal_meter")
    assert row["served"] is True
    assert row["hours_served"] == expected_used
    assert row["hours_reserved"] == expected_used
    assert row["slack_hours"] == 0


def test_scenario_request_mix() -> None:
    """Calibration-zone variability scenario must bill eu-west below us-east for similar work."""
    requests_text = _swap_fixture("request_mix")
    _invoke_default()
    report = _load_report()
    _assert_requests_match_input(report, requests_text)
    _assert_calibration_blend(report, requests_text, require_status=False)


def test_scenario_renew_delay() -> None:
    """Delayed allocation-wave scenario must complete r_renew_late with allocation buffer absorption."""
    cfg = _parse_cfg()
    requests_text = _swap_fixture("renew_delay")
    _invoke_default()
    report = _load_report()
    _assert_requests_match_input(report, requests_text)
    renew = next(r for r in report["requests"] if r["request_id"] == "r_renew_late")
    assert renew["served"] is True
    assert report["cushion_buffer_hours"] >= cfg["min_cushion_buffer_hours"]
    assert report["status"] == "ok"
