package q9

import (
	"sort"

	"rftm.lab/pkg/types"
)

// RxOrder ranks pending requests for beam slot allocation.
func RxOrder(cases []types.BeamCase) []types.BeamCase {
	out := make([]types.BeamCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		a, b := out[i], out[j]
		if a.EtaRevision != b.EtaRevision {
			return a.EtaRevision > b.EtaRevision
		}
		if a.Urgency != b.Urgency {
			return a.Urgency > b.Urgency
		}
		if a.PriorityScore != b.PriorityScore {
			return a.PriorityScore > b.PriorityScore
		}
		return a.RequestID < b.RequestID
	})
	return out
}
