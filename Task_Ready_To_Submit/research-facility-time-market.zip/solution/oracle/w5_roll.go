package z1

// VxRoll totals slack hours for one burst cluster.
func VxRoll(reserved, used int) int {
	if reserved <= used {
		return 0
	}
	return reserved - used
}
