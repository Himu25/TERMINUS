#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/facility.toml
require_file /app/data/request_manifest.jsonl
require_file /app/data/calibration_profiles.csv
require_file /app/data/usage_log.csv
mkdir -p /app/bin /app/output

log "apply patched sources"
cp "${ROOT_DIR}/oracle/p2_order.go" /app/q9/p2_order.go
cp "${ROOT_DIR}/oracle/d4_hold.go" /app/k2/d4_hold.go
cp "${ROOT_DIR}/oracle/b7_slot.go" /app/h4/b7_slot.go
cp "${ROOT_DIR}/oracle/w5_roll.go" /app/z1/w5_roll.go
cp "${ROOT_DIR}/oracle/lib.rs" /app/n8/src/lib.rs

log "rebuild allocator"
bash /app/scripts/build.sh

log "refresh default request bundle"
/app/bin/reqpack /app/data/request_manifest.jsonl /app/data/requests_default.jsonl

log "emit default allocation report"
/app/tools/run_allocator

log "post-run validation against facility.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/facility.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k in ("min_coverage_rate", "max_slack_ratio", "min_science_yield"):
        cfg[k] = float(v)
    elif k.startswith("max_") or k.startswith("min_") or k == "beam_pool_hours":
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/allocation_report.json").read_text())
assert report["status"] == "ok", report
assert report["coverage_rate"] >= cfg["min_coverage_rate"]
assert report["slack_ratio"] <= cfg["max_slack_ratio"]
assert report["prereq_violations"] <= cfg["max_prereq_violations"]
assert report["queue_inversions"] <= cfg["max_queue_inversions"]
assert report["cushion_buffer_hours"] >= cfg["min_cushion_buffer_hours"]
assert report["science_yield"] >= cfg["min_science_yield"]
for row in report["requests"]:
    if row["request_id"].startswith("r_chain_") and row["served"]:
        assert row["prereq_ready"], row
    if row["request_id"].startswith("r_burst_"):
        assert row["served"], row
print("ok", report["coverage_rate"], report["slack_ratio"], report["science_yield"])
PY

log "oracle complete"
