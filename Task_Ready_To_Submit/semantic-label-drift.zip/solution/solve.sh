#!/bin/bash
set -euo pipefail

log() { printf '[oracle] %s\n' "$1"; }

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

verify_report() {
  GOCACHE=/app/output/go-build go run "${ROOT_DIR}/oracle/verify_report.go"
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/probe/p3_scan.go
require_file /app/cohort/c5_lane.go
require_file /app/relabel/r6_lift.go
require_file /app/quota/q7_trim.go
require_file /app/slfold/src/lib.rs
require_file /app/registry/ontology.json
require_file /app/config/bench_profiles.json
require_file /app/docs/contract.md

log "survey guideline revisions and overlap aliases"
grep -nE 'revision|overlap|canonical' \
  /app/docs/architecture.md /app/policies/guideline_policy.txt 2>/dev/null | head -n 12 || true

log "install oracle Rust label-map bridge"
cp "${ROOT_DIR}/oracle/lib.rs" /app/slfold/src/lib.rs

log "install oracle Go drift modules"
cp "${ROOT_DIR}/oracle/p3_scan.go" /app/probe/p3_scan.go
cp "${ROOT_DIR}/oracle/c5_lane.go" /app/cohort/c5_lane.go
cp "${ROOT_DIR}/oracle/r6_lift.go" /app/relabel/r6_lift.go
cp "${ROOT_DIR}/oracle/q7_trim.go" /app/quota/q7_trim.go

log "rebuild slfold and driftd"
mkdir -p /app/bin /app/lib /app/output
export LD_LIBRARY_PATH="/app/lib:${LD_LIBRARY_PATH:-}"
bash /app/scripts/build_all.sh
chmod +x /app/tools/drift_audit

log "default profile smoke"
/app/tools/drift_audit
require_file /app/output/drift_report.json
verify_report

log "stress profile confirmation"
/app/tools/drift_audit /app/config/stress_profiles.json
verify_report

log "oracle complete"
