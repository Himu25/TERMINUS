package relabel

import (
	"driftgate.lab/probe"
	"driftgate.lab/pkg/types"
)

func RepairRows(rows []types.Row, drift map[string]struct{}, centroids map[int][]float64) []types.Row {
	out := make([]types.Row, len(rows))
	copy(out, rows)
	for i, row := range out {
		if _, ok := drift[row.ID]; ok {
			out[i].Label = probe.NearestClass(row.Features, centroids)
		} else {
			out[i].Label = probe.CanonLabel(row.GuidelineRev, row.Label)
		}
		out[i].GuidelineRev = 3
	}
	return out
}
