package quota

import (
	"driftgate.lab/probe"
	"driftgate.lab/pkg/types"
)

func MinorityFrac(rows []types.Row) float64 {
	if len(rows) == 0 {
		return 0
	}
	counts := map[int]int{}
	for _, row := range rows {
		counts[row.Label]++
	}
	minCount := len(rows)
	for _, c := range counts {
		if c < minCount {
			minCount = c
		}
	}
	return float64(minCount) / float64(len(rows)) * float64(len(counts))
}

func CapBalance(rows []types.Row) []types.Row {
	if len(rows) == 0 {
		return rows
	}
	counts := map[int]int{}
	for _, row := range rows {
		counts[row.Label]++
	}
	cap := len(rows)
	for _, c := range counts {
		if c < cap {
			cap = c
		}
	}
	used := map[int]int{}
	var out []types.Row
	for _, row := range rows {
		used[row.Label]++
		if used[row.Label] <= cap {
			out = append(out, row)
		}
	}
	return out
}

func ValAccuracy(rows []types.Row, centroids map[int][]float64) float64 {
	if len(rows) == 0 {
		return 0
	}
	correct := 0
	for _, row := range rows {
		nearest := probe.NearestClass(row.Features, centroids)
		assigned := probe.CanonLabel(row.GuidelineRev, row.Label)
		if assigned == nearest {
			correct++
		}
	}
	return float64(correct) / float64(len(rows))
}
