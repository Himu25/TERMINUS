package cohort

import (
	"fmt"

	"driftgate.lab/pkg/types"
)

func CountSubsets(rows []types.Row, drift map[string]struct{}) int {
	groups := map[string]int{}
	for _, row := range rows {
		if _, ok := drift[row.ID]; !ok {
			continue
		}
		key := row.Annotator + ":" + fmt.Sprintf("%d", row.Batch)
		groups[key]++
	}
	count := 0
	for _, n := range groups {
		if n >= 2 {
			count++
		}
	}
	return count
}
