//go:build ignore

package main

import (
	"encoding/json"
	"fmt"
	"os"
)

func main() {
	body, err := os.ReadFile("/app/output/drift_report.json")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	var report struct {
		Suites []struct {
			Name          string `json:"name"`
			DriftDetected int    `json:"drift_detected"`
			SubsetCount   int    `json:"subset_count"`
		} `json:"suites"`
		Summary struct {
			DriftRecall  float64 `json:"drift_recall"`
			BalanceScore float64 `json:"balance_score"`
			ValAccuracy  float64 `json:"val_accuracy"`
			PassesGate   bool    `json:"passes_gate"`
		} `json:"summary"`
	}
	if err := json.Unmarshal(body, &report); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	summary := report.Summary
	if !summary.PassesGate {
		fmt.Fprintln(os.Stderr, "passes_gate false")
		os.Exit(1)
	}
	if summary.DriftRecall < 0.95 {
		fmt.Fprintln(os.Stderr, "drift recall floor miss")
		os.Exit(1)
	}
	if summary.BalanceScore < 0.90 {
		fmt.Fprintln(os.Stderr, "balance floor miss")
		os.Exit(1)
	}
	if summary.ValAccuracy < 0.95 {
		fmt.Fprintln(os.Stderr, "val accuracy floor miss")
		os.Exit(1)
	}
	for _, suite := range report.Suites {
		if suite.Name == "anchor_holdout" {
			if suite.DriftDetected != 0 || suite.SubsetCount != 0 {
				fmt.Fprintln(os.Stderr, "anchor drift")
				os.Exit(1)
			}
		}
	}
}
