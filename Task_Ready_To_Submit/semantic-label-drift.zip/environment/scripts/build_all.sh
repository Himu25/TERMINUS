#!/bin/bash
set -euo pipefail

ROOT="/app"
mkdir -p "${ROOT}/bin" "${ROOT}/lib" "${ROOT}/output" "${ROOT}/output/cargo-target"

export CARGO_TARGET_DIR="${ROOT}/output/cargo-target"
export CARGO_HOME="${CARGO_HOME:-/usr/local/cargo}"
export CGO_LDFLAGS="-L${ROOT}/lib -lslfold"
export LD_LIBRARY_PATH="${ROOT}/lib:${LD_LIBRARY_PATH:-}"

cd "${ROOT}/slfold"
cargo build --release --locked
install -m 0644 "${CARGO_TARGET_DIR}/release/libslfold.so" "${ROOT}/lib/libslfold.so"

cd "${ROOT}"
go build -o "${ROOT}/bin/driftd" ./cmd/driftd
