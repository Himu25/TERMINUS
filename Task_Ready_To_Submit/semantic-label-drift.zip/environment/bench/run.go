package bench

import (
	"encoding/json"
	"fmt"
	"os"
	"strings"

	"driftgate.lab/cohort"
	"driftgate.lab/ingest"
	"driftgate.lab/pkg/types"
	"driftgate.lab/probe"
	"driftgate.lab/quota"
	"driftgate.lab/relabel"
)

type Floors struct {
	AnchorBalance float64
	AnchorVal     float64
	SkewDrift     float64
	SkewBalance   float64
	SkewVal       float64
	OverlapDrift  float64
	OverlapSubsets float64
	OverlapBalance float64
	OverlapVal     float64
	MixDrift       float64
	MixBalance     float64
	MixVal         float64
	CombinedDrift  float64
	CombinedSubsets float64
	CombinedBalance float64
	CombinedVal     float64
	DriftRecall    float64
	BalanceFloor   float64
	ValFloor       float64
}

func LoadCentroids(path string) (map[int][]float64, error) {
	body, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var raw map[string][]float64
	if err := json.Unmarshal(body, &raw); err != nil {
		return nil, err
	}
	out := make(map[int][]float64, len(raw))
	for key, vec := range raw {
		var cls int
		if _, err := fmt.Sscanf(key, "%d", &cls); err != nil {
			return nil, err
		}
		out[cls] = vec
	}
	return out, nil
}

func LoadFloors(path string) (Floors, error) {
	body, err := os.ReadFile(path)
	if err != nil {
		return Floors{}, err
	}
	var floors Floors
	for _, line := range strings.Split(string(body), "\n") {
		line = strings.Split(line, "#")[0]
		line = strings.TrimSpace(line)
		if line == "" || !strings.Contains(line, "=") {
			continue
		}
		key, val := strings.TrimSpace(line[:strings.Index(line, "=")]), strings.TrimSpace(line[strings.Index(line, "=")+1:])
		var f float64
		if _, err := fmt.Sscanf(val, "%f", &f); err != nil {
			return Floors{}, err
		}
		switch key {
		case "anchor_balance_floor":
			floors.AnchorBalance = f
		case "anchor_val_floor":
			floors.AnchorVal = f
		case "skew_drift_floor":
			floors.SkewDrift = f
		case "skew_balance_floor":
			floors.SkewBalance = f
		case "skew_val_floor":
			floors.SkewVal = f
		case "overlap_drift_floor":
			floors.OverlapDrift = f
		case "overlap_subset_floor":
			floors.OverlapSubsets = f
		case "overlap_balance_floor":
			floors.OverlapBalance = f
		case "overlap_val_floor":
			floors.OverlapVal = f
		case "mix_drift_floor":
			floors.MixDrift = f
		case "mix_balance_floor":
			floors.MixBalance = f
		case "mix_val_floor":
			floors.MixVal = f
		case "combined_drift_floor":
			floors.CombinedDrift = f
		case "combined_subset_floor":
			floors.CombinedSubsets = f
		case "combined_balance_floor":
			floors.CombinedBalance = f
		case "combined_val_floor":
			floors.CombinedVal = f
		case "drift_recall_floor":
			floors.DriftRecall = f
		case "balance_floor":
			floors.BalanceFloor = f
		case "val_floor":
			floors.ValFloor = f
		}
	}
	return floors, nil
}

func LoadProfile(path string) (types.Profile, error) {
	body, err := os.ReadFile(path)
	if err != nil {
		return types.Profile{}, err
	}
	var profile types.Profile
	if err := json.Unmarshal(body, &profile); err != nil {
		return types.Profile{}, err
	}
	return profile, nil
}

func round4(v float64) float64 {
	return float64(int(v*10000+0.5)) / 10000
}

func EvalSuite(name string, path string, centroids map[int][]float64) (types.SuiteStat, error) {
	rows, err := ingest.LoadRows(path)
	if err != nil {
		return types.SuiteStat{}, err
	}
	driftIDs := probe.DetectDrift(rows, centroids)
	drift := map[string]struct{}{}
	for _, id := range driftIDs {
		drift[id] = struct{}{}
	}
	repaired := relabel.RepairRows(rows, drift, centroids)
	balanced := quota.CapBalance(repaired)
	return types.SuiteStat{
		Name:          name,
		Total:         len(rows),
		DriftDetected: len(driftIDs),
		SubsetCount:   cohort.CountSubsets(rows, drift),
		RepairedCount: len(driftIDs),
		BalanceScore:  round4(quota.MinorityFrac(balanced)),
		ValAccuracy:   round4(quota.ValAccuracy(balanced, centroids)),
	}, nil
}

func suiteFloor(name string, floors Floors) (drift, subset, balance, val float64, hasSubset bool) {
	switch name {
	case "anchor_holdout":
		return 0, 0, floors.AnchorBalance, floors.AnchorVal, false
	case "version_skew_suite":
		return floors.SkewDrift, 0, floors.SkewBalance, floors.SkewVal, false
	case "overlap_suite":
		return floors.OverlapDrift, floors.OverlapSubsets, floors.OverlapBalance, floors.OverlapVal, true
	case "guideline_mix_suite":
		return floors.MixDrift, 0, floors.MixBalance, floors.MixVal, false
	case "combined_drift_suite":
		return floors.CombinedDrift, floors.CombinedSubsets, floors.CombinedBalance, floors.CombinedVal, true
	default:
		return 0, 0, floors.BalanceFloor, floors.ValFloor, false
	}
}

func passesSuite(stat types.SuiteStat, floors Floors) bool {
	driftFloor, subset, bal, val, hasSubset := suiteFloor(stat.Name, floors)
	if stat.Name == "anchor_holdout" {
		return stat.DriftDetected == 0 && stat.BalanceScore >= bal && stat.ValAccuracy >= val
	}
	if float64(stat.DriftDetected) < driftFloor {
		return false
	}
	if hasSubset && float64(stat.SubsetCount) < subset {
		return false
	}
	if stat.BalanceScore < bal {
		return false
	}
	if stat.ValAccuracy < val {
		return false
	}
	return true
}

func Run(profilePath string) (types.Report, error) {
	centroids, err := LoadCentroids("/app/registry/centroids.json")
	if err != nil {
		return types.Report{}, err
	}
	floors, err := LoadFloors("/app/config/thresholds.toml")
	if err != nil {
		return types.Report{}, err
	}
	profile, err := LoadProfile(profilePath)
	if err != nil {
		return types.Report{}, err
	}
	var suites []types.SuiteStat
	for _, entry := range profile.Suites {
		stat, err := EvalSuite(entry.Name, entry.Path, centroids)
		if err != nil {
			return types.Report{}, err
		}
		suites = append(suites, stat)
	}
	var driftSum, balanceSum, valSum float64
	for _, stat := range suites {
		balanceSum += stat.BalanceScore
		valSum += stat.ValAccuracy
		driftFloor, _, _, _, _ := suiteFloor(stat.Name, floors)
		if stat.Name == "anchor_holdout" {
			continue
		}
		if driftFloor > 0 {
			driftSum += float64(stat.DriftDetected) / driftFloor
		}
	}
	n := float64(len(suites))
	driftRecall := round4(driftSum / float64(len(suites)-1))
	summary := types.Summary{
		DriftRecall:  driftRecall,
		BalanceScore: round4(balanceSum / n),
		ValAccuracy:  round4(valSum / n),
		PassesGate:   true,
	}
	for _, stat := range suites {
		if !passesSuite(stat, floors) {
			summary.PassesGate = false
			break
		}
	}
	if summary.DriftRecall < floors.DriftRecall {
		summary.PassesGate = false
	}
	if summary.BalanceScore < floors.BalanceFloor {
		summary.PassesGate = false
	}
	if summary.ValAccuracy < floors.ValFloor {
		summary.PassesGate = false
	}
	return types.Report{Suites: suites, Summary: summary}, nil
}

func WriteReport(path string, report types.Report) error {
	body, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	body = append(body, '\n')
	return os.WriteFile(path, body, 0o644)
}
