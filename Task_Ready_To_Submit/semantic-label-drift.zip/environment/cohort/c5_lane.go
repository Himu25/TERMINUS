package cohort

import "driftgate.lab/pkg/types"

// CountSubsets tallies annotator-batch pairs that contain multiple drifted rows.
func CountSubsets(rows []types.Row, drift map[string]struct{}) int {
	seen := map[int]struct{}{}
	for _, row := range rows {
		if _, ok := drift[row.ID]; !ok {
			continue
		}
		seen[row.Label] = struct{}{}
	}
	return len(seen)
}
