package ingest

import (
	"bufio"
	"encoding/json"
	"os"

	"driftgate.lab/pkg/types"
)

func LoadRows(path string) ([]types.Row, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	var rows []types.Row
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := sc.Text()
		if line == "" {
			continue
		}
		var raw struct {
			ID           string    `json:"id"`
			Features     []float64 `json:"features"`
			Label        int       `json:"label"`
			Annotator    string    `json:"annotator"`
			Batch        int       `json:"batch"`
			GuidelineRev int       `json:"guideline_rev"`
			Caption      string    `json:"caption"`
		}
		if err := json.Unmarshal([]byte(line), &raw); err != nil {
			return nil, err
		}
		rows = append(rows, types.Row{
			ID:           raw.ID,
			Features:     raw.Features,
			Label:        raw.Label,
			Annotator:    raw.Annotator,
			Batch:        raw.Batch,
			GuidelineRev: raw.GuidelineRev,
			Caption:      raw.Caption,
		})
	}
	return rows, sc.Err()
}
