Helper scripts are not shipped; use /app/tools/drift_audit and /app/scripts/build_all.sh.
