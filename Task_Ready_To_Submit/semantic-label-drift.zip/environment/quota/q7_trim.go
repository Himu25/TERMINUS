package quota

import (
	"driftgate.lab/pkg/types"
)

func MinorityFrac(rows []types.Row) float64 {
	if len(rows) == 0 {
		return 0
	}
	counts := map[int]int{}
	for _, row := range rows {
		counts[row.Label]++
	}
	maxCount := 0
	for _, c := range counts {
		if c > maxCount {
			maxCount = c
		}
	}
	return float64(maxCount) / float64(len(rows)) * float64(len(counts))
}

func CapBalance(rows []types.Row) []types.Row {
	if len(rows) == 0 {
		return rows
	}
	counts := map[int]int{}
	for _, row := range rows {
		counts[row.Label]++
	}
	cap := 0
	for _, c := range counts {
		if c > cap {
			cap = c
		}
	}
	used := map[int]int{}
	var out []types.Row
	for _, row := range rows {
		used[row.Label]++
		if used[row.Label] <= cap {
			out = append(out, row)
		}
	}
	return out
}

func ValAccuracy(rows []types.Row, centroids map[int][]float64) float64 {
	if len(rows) == 0 {
		return 0
	}
	correct := 0
	for _, row := range rows {
		nearest := 0
		best := 1e18
		for cls, center := range centroids {
			var sum float64
			for i := range row.Features {
				d := row.Features[i] - center[i]
				sum += d * d
			}
			if sum < best {
				best = sum
				nearest = cls
			}
		}
		if row.Label == nearest {
			correct++
		}
	}
	return float64(correct) / float64(len(rows))
}
