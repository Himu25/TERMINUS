module driftgate.lab

go 1.22
