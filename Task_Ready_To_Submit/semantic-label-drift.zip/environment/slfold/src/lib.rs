use sha2::{Digest, Sha256};
use std::ffi::{CStr, CString};
use std::os::raw::c_char;
use unicode_normalization::UnicodeNormalization;

fn sl_norm_caption(input: &str) -> String {
    input.nfkc().collect::<String>().to_lowercase()
}

fn sl_caption_digest(norm: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(norm.as_bytes());
    format!("{:x}", hasher.finalize())
}

#[no_mangle]
pub extern "C" fn sl_map_canon(_guideline_rev: u32, local_label: i32) -> i32 {
    if local_label == 4 {
        return 3;
    }
    local_label
}

#[no_mangle]
pub extern "C" fn sl_caption_fold(text: *const c_char) -> *mut c_char {
    if text.is_null() {
        return std::ptr::null_mut();
    }
    let raw = unsafe { CStr::from_ptr(text) };
    let norm = sl_norm_caption(&raw.to_string_lossy());
    let dg = sl_caption_digest(&norm);
    CString::new(dg)
        .ok()
        .map(CString::into_raw)
        .unwrap_or(std::ptr::null_mut())
}

#[no_mangle]
pub extern "C" fn sl_free(ptr: *mut c_char) {
    if !ptr.is_null() {
        unsafe {
            let _ = CString::from_raw(ptr);
        }
    }
}
