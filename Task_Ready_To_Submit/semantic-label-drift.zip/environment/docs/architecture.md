# Architecture

Ontology revisions 1–3 map local integer labels to canonical classes 0–3. Revision 2 adds local label 4 as an alias of canonical class 2 (overlapping categories).

Drift detection compares canonical assigned labels against the nearest centroid class from feature vectors. Repair rewrites drifted rows to the active guideline revision with nearest-centroid labels. Balance trimming caps per-class counts at the minority class size.

Batch isolation feeds `subset_count`. Among rows flagged as drift, group by annotator and batch together (not batch alone). Each annotator-batch pair with more than one drifted row adds one to the count; a single drifted row in a pair does not. `subset_count` is computed identically for every suite, including `anchor_holdout` where it is naturally zero.
