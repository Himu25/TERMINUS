# Semantic label drift pipeline

The workspace under `/app` ingests versioned training JSONL, maps local labels through `/app/registry/ontology.json`, scores feature centroids from `/app/registry/centroids.json`, and emits `/app/output/drift_report.json`.

Build the audit driver with `/app/scripts/build_all.sh` (Rust shared library plus Go `driftd`). Run benches through `/app/tools/drift_audit` with an optional profile path; default profile is `/app/config/bench_profiles.json`.

The Go packages `probe`, `cohort`, `relabel`, and `quota` implement detection, batch isolation, canonical repair, and class-balance trimming. Caption folding for semantic keys is exported from the Rust crate via CGO.
