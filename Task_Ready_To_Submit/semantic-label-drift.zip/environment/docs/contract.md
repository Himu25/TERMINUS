# Drift report contract

Each suite row includes `name`, `total`, `drift_detected`, `subset_count`, `repaired_count`, `balance_score`, and `val_accuracy` as JSON numbers rounded to four decimal places.

`subset_count` is batch isolation: after drift detection, group drifted rows by annotator and batch, then count pairs where more than one row drifted. Singleton drift within a pair does not increment the count. `subset_count` is computed identically for every suite, including `anchor_holdout` where it is naturally zero.

`balance_score` is class balance on the post-`CapBalance` repaired row set: cap each class at the minority class count on repaired rows, then compute `(min_class_count / total_balanced_rows) × n_classes`, where `min_class_count` is the smallest per-class count in that capped set, `total_balanced_rows` is the row count after capping, and `n_classes` is the number of distinct classes present.

Hidden verifier profiles use the `*_hidden` suffix and must be treated identically to their non-hidden counterparts (for example, `overlap_hidden` follows the same scoring rules as `overlap_suite`).

Summary carries `drift_recall`, `balance_score`, `val_accuracy`, and `passes_gate`. Gate floors live in `/app/config/thresholds.toml`. `anchor_holdout` must keep `drift_detected` and `subset_count` at zero.

Canonical labels for a row use `(guideline_rev, label)` through the ontology map before comparing to the nearest centroid class from features. `val_accuracy` scores rows by canonical assignment against nearest-centroid class, not raw local label integers.
