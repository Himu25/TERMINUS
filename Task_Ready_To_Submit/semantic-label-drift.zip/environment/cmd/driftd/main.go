package main

import (
	"fmt"
	"os"

	"driftgate.lab/bench"
)

func main() {
	profile := "/app/config/bench_profiles.json"
	if len(os.Args) > 1 {
		profile = os.Args[1]
	}
	report, err := bench.Run(profile)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if err := bench.WriteReport("/app/output/drift_report.json", report); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
