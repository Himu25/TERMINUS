"""Validate drift_report.json against drift-audit gates and independent replay."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "drift_report.json"
BENCH = APP / "tools" / "drift_audit"
PROFILE = APP / "config" / "bench_profiles.json"
STRESS_PROFILE = APP / "config" / "stress_profiles.json"
THRESHOLDS = APP / "config" / "thresholds.toml"
CENTROIDS = APP / "registry" / "centroids.json"
ONTOLOGY = APP / "registry" / "ontology.json"
FIXTURES = Path(__file__).resolve().parent / "fixtures"

SUBSET_SUITES = frozenset({"overlap_suite", "combined_drift_suite"})

# Per-suite replay bands: tight enough that unfixed bench output fails, wide
# enough that a mostly-correct rebuild can land within ~1-3/10 agent trials.
_REPLAY_DRIFT_TOL: dict[str, int] = {
    "anchor_holdout": 0,
    "version_skew_suite": 2,
    "guideline_mix_suite": 2,
    "overlap_suite": 3,
    "combined_drift_suite": 4,
}
_REPLAY_SUBSET_TOL: dict[str, int] = {
    "overlap_suite": 1,
    "combined_drift_suite": 1,
}
_REPLAY_BALANCE_TOL: dict[str, float] = {
    "anchor_holdout": 0.0,
    "version_skew_suite": 0.08,
    "guideline_mix_suite": 0.10,
    "overlap_suite": 0.12,
    "combined_drift_suite": 0.15,
}
_REPLAY_VAL_ACC_TOL: dict[str, float] = {
    "anchor_holdout": 0.0,
    "version_skew_suite": 0.06,
    "guideline_mix_suite": 0.08,
    "overlap_suite": 0.10,
    "combined_drift_suite": 0.12,
}


def _parse_thresholds(path: Path) -> dict[str, float]:
    floors: dict[str, float] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.split("#", 1)[0].strip()
        if not stripped or "=" not in stripped:
            continue
        key, raw = stripped.split("=", 1)
        floors[key.strip()] = float(raw.strip())
    return floors


_FLOOR_DATA = _parse_thresholds(THRESHOLDS)


def _load_centroids() -> dict[int, list[float]]:
    raw = json.loads(CENTROIDS.read_text(encoding="utf-8"))
    return {int(k): v for k, v in raw.items()}


def _load_ontology() -> dict[int, dict[int, int]]:
    raw = json.loads(ONTOLOGY.read_text(encoding="utf-8"))
    return {int(rev): {int(k): int(v) for k, v in mapping.items()} for rev, mapping in raw.items()}


def _dist(a: list[float], b: list[float]) -> float:
    return sum((x - y) ** 2 for x, y in zip(a, b)) ** 0.5


def _nearest_class(feat: list[float], centroids: dict[int, list[float]]) -> int:
    return min(centroids, key=lambda c: _dist(feat, centroids[c]))


def _canon_label(rev: int, local: int, ontology: dict[int, dict[int, int]]) -> int:
    return ontology[rev][local]


def _load_rows(path: Path) -> list[dict]:
    rows: list[dict] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return rows


def _independent_suite_metrics(path: Path) -> dict[str, float | int]:
    centroids = _load_centroids()
    ontology = _load_ontology()
    rows = _load_rows(path)
    drift_ids: set[str] = set()
    for row in rows:
        nearest = _nearest_class(row["features"], centroids)
        assigned = _canon_label(row["guideline_rev"], row["label"], ontology)
        if assigned != nearest:
            drift_ids.add(row["id"])
    groups: dict[tuple[str, int], int] = {}
    for row in rows:
        if row["id"] not in drift_ids:
            continue
        key = (row["annotator"], row["batch"])
        groups[key] = groups.get(key, 0) + 1
    subset_count = sum(1 for c in groups.values() if c >= 2)
    repaired = []
    for row in rows:
        fixed = dict(row)
        if row["id"] in drift_ids:
            fixed["label"] = _nearest_class(row["features"], centroids)
        else:
            fixed["label"] = _canon_label(row["guideline_rev"], row["label"], ontology)
        fixed["guideline_rev"] = 3
        repaired.append(fixed)
    counts: dict[int, int] = {}
    for row in repaired:
        counts[row["label"]] = counts.get(row["label"], 0) + 1
    cap = min(counts.values()) if counts else 0
    used: dict[int, int] = {}
    balanced = []
    for row in repaired:
        used[row["label"]] = used.get(row["label"], 0) + 1
        if used[row["label"]] <= cap:
            balanced.append(row)
    minority = 0.0
    if balanced:
        bcounts: dict[int, int] = {}
        for row in balanced:
            bcounts[row["label"]] = bcounts.get(row["label"], 0) + 1
        minority = min(bcounts.values()) / len(balanced) * len(bcounts)
    val_acc = 0.0
    if balanced:
        val_acc = sum(
            1
            for r in balanced
            if _canon_label(r["guideline_rev"], r["label"], ontology)
            == _nearest_class(r["features"], centroids)
        ) / len(balanced)
    return {
        "total": len(rows),
        "drift_detected": len(drift_ids),
        "subset_count": subset_count,
        "repaired_count": len(drift_ids),
        "balance_score": round(minority, 4),
        "val_accuracy": round(val_acc, 4),
    }


def _run_bench(profile: Path | None = None) -> None:
    cmd = [str(BENCH)]
    if profile is not None:
        cmd.append(str(profile))
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "drift_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


def _suite(report: dict, name: str) -> dict:
    return next(s for s in report["suites"] if s["name"] == name)


def _suite_drift_floor(name: str) -> float:
    mapping = {
        "anchor_holdout": 0,
        "version_skew_suite": _FLOOR_DATA["skew_drift_floor"],
        "overlap_suite": _FLOOR_DATA["overlap_drift_floor"],
        "guideline_mix_suite": _FLOOR_DATA["mix_drift_floor"],
        "combined_drift_suite": _FLOOR_DATA["combined_drift_floor"],
    }
    return mapping[name]


def _suite_subset_floor(name: str) -> float:
    mapping = {
        "overlap_suite": _FLOOR_DATA["overlap_subset_floor"],
        "combined_drift_suite": _FLOOR_DATA["combined_subset_floor"],
    }
    return mapping.get(name, 0)


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    _run_bench()


def test_report_schema_and_suite_order() -> None:
    """Report lists suites in bench profile order with required fields."""
    report = _load_report()
    profile = json.loads(PROFILE.read_text(encoding="utf-8"))
    expected_names = [s["name"] for s in profile["suites"]]
    assert [s["name"] for s in report["suites"]] == expected_names
    for suite in report["suites"]:
        for key in (
            "total",
            "drift_detected",
            "subset_count",
            "repaired_count",
            "balance_score",
            "val_accuracy",
        ):
            assert key in suite


def test_anchor_holdout_zero_drift() -> None:
    """anchor_holdout keeps drift_detected at zero."""
    suite = _suite(_load_report(), "anchor_holdout")
    assert suite["drift_detected"] == 0
    assert suite["subset_count"] == 0
    assert suite["balance_score"] >= _FLOOR_DATA["anchor_balance_floor"]
    assert suite["val_accuracy"] >= _FLOOR_DATA["anchor_val_floor"]


def test_version_skew_suite_detects_drift() -> None:
    """Version-skewed slices meet drift and balance floors."""
    suite = _suite(_load_report(), "version_skew_suite")
    assert suite["drift_detected"] >= _FLOOR_DATA["skew_drift_floor"]
    assert suite["balance_score"] >= _FLOOR_DATA["skew_balance_floor"]
    assert suite["val_accuracy"] >= _FLOOR_DATA["skew_val_floor"]


def test_overlap_suite_subset_isolation() -> None:
    """Overlapping revision-2 categories isolate grouped batches."""
    suite = _suite(_load_report(), "overlap_suite")
    assert suite["drift_detected"] >= _FLOOR_DATA["overlap_drift_floor"]
    assert suite["subset_count"] >= _FLOOR_DATA["overlap_subset_floor"]
    assert suite["balance_score"] >= _FLOOR_DATA["overlap_balance_floor"]
    assert suite["val_accuracy"] >= _FLOOR_DATA["overlap_val_floor"]


def test_guideline_mix_suite_repair() -> None:
    """Mixed guideline revisions are detected and repaired."""
    suite = _suite(_load_report(), "guideline_mix_suite")
    assert suite["drift_detected"] >= _FLOOR_DATA["mix_drift_floor"]
    assert suite["balance_score"] >= _FLOOR_DATA["mix_balance_floor"]
    assert suite["val_accuracy"] >= _FLOOR_DATA["mix_val_floor"]


def test_combined_drift_suite_stress() -> None:
    """Combined drift mix meets drift, subset, balance, and val floors."""
    suite = _suite(_load_report(), "combined_drift_suite")
    assert suite["drift_detected"] >= _FLOOR_DATA["combined_drift_floor"]
    assert suite["subset_count"] >= _FLOOR_DATA["combined_subset_floor"]
    assert suite["balance_score"] >= _FLOOR_DATA["combined_balance_floor"]
    assert suite["val_accuracy"] >= _FLOOR_DATA["combined_val_floor"]


def test_summary_passes_gate() -> None:
    """Summary drift_recall, balance_score, val_accuracy, and passes_gate align."""
    report = _load_report()
    summary = report["summary"]
    assert summary["drift_recall"] >= _FLOOR_DATA["drift_recall_floor"]
    assert summary["balance_score"] >= _FLOOR_DATA["balance_floor"]
    assert summary["val_accuracy"] >= _FLOOR_DATA["val_floor"]
    assert summary["passes_gate"] is True


def _assert_suite_metrics_match_independent_replay(suite_names: frozenset[str]) -> None:
    report = _load_report()
    profile = json.loads(PROFILE.read_text(encoding="utf-8"))
    for entry, suite in zip(profile["suites"], report["suites"], strict=True):
        if suite["name"] not in suite_names:
            continue
        replay = _independent_suite_metrics(Path(entry["path"]))
        name = suite["name"]
        assert suite["total"] == replay["total"]
        drift_tol = _REPLAY_DRIFT_TOL.get(name, 0)
        assert abs(suite["drift_detected"] - replay["drift_detected"]) <= drift_tol
        assert abs(suite["subset_count"] - replay["subset_count"]) <= _REPLAY_SUBSET_TOL.get(
            name, 0
        )
        assert abs(suite["repaired_count"] - replay["repaired_count"]) <= drift_tol
        assert (
            abs(suite["balance_score"] - replay["balance_score"])
            <= _REPLAY_BALANCE_TOL.get(name, 0.0)
        )
        assert (
            abs(suite["val_accuracy"] - replay["val_accuracy"])
            <= _REPLAY_VAL_ACC_TOL.get(name, 0.0)
        )


def _assert_subset_suite_metrics_match_independent_replay(
    suite_names: frozenset[str],
) -> None:
    """Replay isolation counts and val accuracy; balance trim checked elsewhere."""
    report = _load_report()
    profile = json.loads(PROFILE.read_text(encoding="utf-8"))
    for entry, suite in zip(profile["suites"], report["suites"], strict=True):
        if suite["name"] not in suite_names:
            continue
        replay = _independent_suite_metrics(Path(entry["path"]))
        name = suite["name"]
        assert suite["total"] == replay["total"]
        drift_tol = _REPLAY_DRIFT_TOL.get(name, 0)
        assert abs(suite["drift_detected"] - replay["drift_detected"]) <= drift_tol
        assert abs(suite["subset_count"] - replay["subset_count"]) <= _REPLAY_SUBSET_TOL.get(
            name, 0
        )
        assert abs(suite["repaired_count"] - replay["repaired_count"]) <= drift_tol
        assert (
            abs(suite["val_accuracy"] - replay["val_accuracy"])
            <= _REPLAY_VAL_ACC_TOL.get(name, 0.0)
        )


def test_suite_metrics_match_independent_replay() -> None:
    """Anchor, version-skew, and guideline-mix rows match independent replay."""
    _assert_suite_metrics_match_independent_replay(
        frozenset({"anchor_holdout", "version_skew_suite", "guideline_mix_suite"})
    )


def test_subset_suites_metrics_match_independent_replay() -> None:
    """Overlap and combined rows match independent replay (subset isolation)."""
    _assert_subset_suite_metrics_match_independent_replay(SUBSET_SUITES)


def test_stress_profile_floors() -> None:
    """Stress profile applies the same per-suite floors as the default bench."""
    _run_bench(STRESS_PROFILE)
    report = _load_report()
    for suite in report["suites"]:
        assert suite["drift_detected"] >= _suite_drift_floor(suite["name"])
        if suite["name"] in SUBSET_SUITES:
            assert suite["subset_count"] >= _suite_subset_floor(suite["name"])
    _run_bench()


def test_repeat_run_byte_identical() -> None:
    """Back-to-back bench runs emit identical report bytes."""
    _run_bench()
    first = OUT.read_bytes()
    _run_bench()
    second = OUT.read_bytes()
    assert first == second


def test_accuracies_four_decimal_places() -> None:
    """Numeric metrics are rounded to four decimal places."""
    report = _load_report()
    for suite in report["suites"]:
        for key in ("balance_score", "val_accuracy"):
            val = suite[key]
            assert val == round(val, 4)
    for key in ("drift_recall", "balance_score", "val_accuracy"):
        val = report["summary"][key]
        assert val == round(val, 4)


def test_hidden_version_skew_profile() -> None:
    """Verifier-only version-skew pack detects cross-revision drift."""
    profile_path = APP / "output" / "profile_version_skew_hidden.json"
    profile_path.write_text(
        (FIXTURES / "profile_version_skew_hidden.json").read_text(encoding="utf-8"),
        encoding="utf-8",
    )
    _run_bench(profile_path)
    suite = _suite(_load_report(), "version_skew_hidden")
    assert suite["drift_detected"] >= _FLOOR_DATA["pack_skew_drift_floor"]
    assert suite["val_accuracy"] >= _FLOOR_DATA["pack_skew_val_floor"]
    _run_bench()


def test_hidden_overlap_profile() -> None:
    """Verifier-only overlap pack isolates revision-2 alias batches."""
    profile_path = APP / "output" / "profile_overlap_hidden.json"
    profile_path.write_text(
        (FIXTURES / "profile_overlap_hidden.json").read_text(encoding="utf-8"),
        encoding="utf-8",
    )
    _run_bench(profile_path)
    suite = _suite(_load_report(), "overlap_hidden")
    assert suite["subset_count"] >= _FLOOR_DATA["pack_overlap_subset_floor"]
    assert suite["drift_detected"] >= _FLOOR_DATA["pack_overlap_drift_floor"]
    _run_bench()


def test_hidden_guideline_mix_profile() -> None:
    """Verifier-only mixed-revision pack repairs guideline drift."""
    profile_path = APP / "output" / "profile_guideline_mix_hidden.json"
    profile_path.write_text(
        (FIXTURES / "profile_guideline_mix_hidden.json").read_text(encoding="utf-8"),
        encoding="utf-8",
    )
    _run_bench(profile_path)
    suite = _suite(_load_report(), "guideline_mix_hidden")
    assert suite["drift_detected"] >= _FLOOR_DATA["pack_mix_drift_floor"]
    assert suite["balance_score"] >= _FLOOR_DATA["pack_mix_balance_floor"]
    _run_bench()


def test_forged_report_restored_by_rerun() -> None:
    """A truncated forged report cannot satisfy the full profile contract."""
    profile_len = len(json.loads(PROFILE.read_text(encoding="utf-8"))["suites"])
    forged = {
        "suites": [
            {
                "name": "anchor_holdout",
                "total": 1,
                "drift_detected": 0,
                "subset_count": 0,
                "repaired_count": 0,
                "balance_score": 1.0,
                "val_accuracy": 1.0,
            }
        ],
        "summary": {
            "drift_recall": 1.0,
            "balance_score": 1.0,
            "val_accuracy": 1.0,
            "passes_gate": True,
        },
    }
    OUT.write_text(json.dumps(forged) + "\n", encoding="utf-8")
    assert len(_load_report()["suites"]) != profile_len
    _run_bench()
    restored = _load_report()
    assert len(restored["suites"]) == profile_len
    assert restored["summary"]["passes_gate"] is True
