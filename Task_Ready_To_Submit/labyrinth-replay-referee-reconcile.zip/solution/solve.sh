#!/usr/bin/env bash
set -euo pipefail

cd /app

cat > /app/ref/lib/parser/jsonl.rb <<'EOF'
# frozen_string_literal: true

require 'json'

module Parser
  module Jsonl
    module_function

    def parse(path)
      File.readlines(path, chomp: true).filter_map do |line|
        next if line.strip.empty?

        row = JSON.parse(line)
        kind = row['kind']
        turn = row['turn'].to_i
        target = row['to'] || row['item'] || row['target']
        { turn: turn, kind: normalize_kind(kind), target: target }
      end
    end

    def normalize_kind(raw)
      case raw
      when 'move', 'M' then 'move'
      when 'use', 'U' then 'use'
      else raw
      end
    end
  end
end
EOF

cat > /app/ref/lib/parser/tsv.rb <<'EOF'
# frozen_string_literal: true

module Parser
  module Tsv
    module_function

    def parse(path)
      lines = File.readlines(path, chomp: true)
      data = lines.drop(1)
      data.filter_map do |line|
        turn_s, action, target = line.split("\t")
        next if [turn_s, action, target].any?(&:nil?)

        turn = turn_s.to_i
        { turn: turn, kind: normalize_kind(action), target: target }
      end
    end

    def normalize_kind(raw)
      case raw
      when 'move' then 'move'
      when 'use' then 'use'
      else raw
      end
    end
  end
end
EOF

sed -i "s|http://127.0.0.1:8741/api/v1|http://127.0.0.1:8741/v1|" /app/ref/lib/client/rules_api.rb

python3 - <<'PY'
from pathlib import Path

move = Path("/app/ref/lib/validate/move.rb")
text = move.read_text()
old = """    def adjacent?(room, target)
      exits = room['exits'] || {}
      forward = exits.value?(target)
      reverse = reverse_lookup?(room, target)
      forward || reverse
    end

    def reverse_lookup?(room, target)
      exits = room['exits'] || {}
      exits.key?(target)
    end"""
new = """    def adjacent?(room, target)
      exits = room['exits'] || {}
      exits.value?(target)
    end"""
if old not in text:
    raise SystemExit("move adjacent block not found")
move.write_text(text.replace(old, new, 1))
PY

cat > /app/ref/lib/validate/item.rb <<'EOF'
# frozen_string_literal: true

module Validate
  module Item
    module_function

    def apply(api, state, item_id)
      meta = api.item(item_id)
      room = api.room(state[:room])
      items_here = room['items'] || []
      unless items_here.include?(item_id)
        state[:last_reason] = 'item_not_available'
        return false
      end
      pickup = meta['pickup_room']
      if pickup && pickup != state[:room]
        state[:last_reason] = 'item_not_available'
        return false
      end
      effect = meta['effect']
      state[:flags][effect] = true
      state[:inventory] << item_id unless meta['consumes']
      true
    end
  end
end
EOF

cat > /app/ref/lib/reconcile/status.rb <<'EOF'
# frozen_string_literal: true

require 'digest'

module Reconcile
  module Status
    module_function

    def archive_ok_for_turn?(archive, turn_no)
      flags = archive.fetch('turn_flags')
      flags[turn_no - 1]
    end

    def derive(state, constraints, first_illegal, archive_mismatch, _archive, _turns_played)
      return 'desynced' if archive_mismatch
      return 'forfeited' if first_illegal
      return 'forfeited' unless state[:finished]
      return 'forfeited' if state[:room] != constraints['finish_room']
      'valid'
    end

    def classify_mismatch(archive_ok, rules_ok, turn_no)
      return nil if archive_ok == rules_ok

      {
        'turn' => turn_no,
        'reason' => 'archive_rules_mismatch',
        'archive_ok' => archive_ok,
        'rules_ok' => rules_ok
      }
    end

    def illegal_from_state(state, turn_no)
      return nil if state[:last_reason].nil?

      {
        'turn' => turn_no,
        'reason' => state[:last_reason]
      }
    end
  end
end
EOF

bash /app/scripts/build.sh
bash /app/scripts/start_api.sh

rm -f /app/output/referee_report.json
mkdir -p /app/output
TB_LABYRINTH_FIXTURE=1 /app/bin/referee_run
test -s /app/output/referee_report.json
