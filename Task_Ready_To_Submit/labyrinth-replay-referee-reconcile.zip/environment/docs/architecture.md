# Labyrinth League architecture

The rules service (`/app/svc/cmd/rulesd`) exposes read-only HTTP routes on port 8741 under the `/v1` prefix. Room lookup paths follow `/rooms/<id>` (for example `/rooms/r_gallery` and `/rooms/r_vault`). Room records include outbound exits, on-room items, and entry requirement flags. Item records name an effect flag and pickup room. Match constraint records cap turns and name the finish room.

The Ruby referee loads a batch manifest, parses each replay format, walks turns while mutating player state, compares archive sidecar legality bits, and writes `/app/output/referee_report.json`. Offline replays may copy `/app/bin/referee_run` to `/tmp/referee_run_verify_bin` before driving batches. Go builds use `GOCACHE=/tmp/go-build` per the Dockerfile.

Replay formats live under `/app/archive` with matching `<match_id>.archive.json` sidecars.
