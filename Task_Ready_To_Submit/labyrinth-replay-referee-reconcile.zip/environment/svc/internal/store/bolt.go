package store

import (
	"encoding/json"
	"fmt"

	bolt "go.etcd.io/bbolt"
)

const (
	BucketRooms       = "rooms"
	BucketItems       = "items"
	BucketConstraints = "constraints"
)

type Room struct {
	ID         string            `json:"id"`
	Exits      map[string]string `json:"exits"`
	Items      []string          `json:"items"`
	Requires   []string          `json:"requires"`
	FinishRoom bool              `json:"finish_room"`
}

type Item struct {
	ID          string `json:"id"`
	Effect      string `json:"effect"`
	PickupRoom  string `json:"pickup_room"`
	Consumes    bool   `json:"consumes"`
}

type Constraints struct {
	MatchID    string `json:"match_id"`
	MaxTurns   int    `json:"max_turns"`
	FinishRoom string `json:"finish_room"`
}

type DB struct {
	path string
}

func Open(path string) (*DB, error) {
	return &DB{path: path}, nil
}

func (d *DB) View(fn func(*bolt.Tx) error) error {
	db, err := bolt.Open(d.path, 0o444, &bolt.Options{ReadOnly: true})
	if err != nil {
		return err
	}
	defer db.Close()
	return db.View(fn)
}

func (d *DB) Room(id string) (*Room, error) {
	var out Room
	err := d.View(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte(BucketRooms))
		if b == nil {
			return fmt.Errorf("rooms bucket missing")
		}
		raw := b.Get([]byte(id))
		if raw == nil {
			return fmt.Errorf("room not found")
		}
		return json.Unmarshal(raw, &out)
	})
	if err != nil {
		return nil, err
	}
	return &out, nil
}

func (d *DB) Item(id string) (*Item, error) {
	var out Item
	err := d.View(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte(BucketItems))
		if b == nil {
			return fmt.Errorf("items bucket missing")
		}
		raw := b.Get([]byte(id))
		if raw == nil {
			return fmt.Errorf("item not found")
		}
		return json.Unmarshal(raw, &out)
	})
	if err != nil {
		return nil, err
	}
	return &out, nil
}

func (d *DB) Constraints(matchID string) (*Constraints, error) {
	var out Constraints
	err := d.View(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte(BucketConstraints))
		if b == nil {
			return fmt.Errorf("constraints bucket missing")
		}
		raw := b.Get([]byte(matchID))
		if raw == nil {
			return fmt.Errorf("constraints not found")
		}
		return json.Unmarshal(raw, &out)
	})
	if err != nil {
		return nil, err
	}
	return &out, nil
}

func Seed(path string, rooms []Room, items []Item, constraints []Constraints) error {
	db, err := bolt.Open(path, 0o644, nil)
	if err != nil {
		return err
	}
	defer db.Close()
	return db.Update(func(tx *bolt.Tx) error {
		rb, err := tx.CreateBucketIfNotExists([]byte(BucketRooms))
		if err != nil {
			return err
		}
		ib, err := tx.CreateBucketIfNotExists([]byte(BucketItems))
		if err != nil {
			return err
		}
		cb, err := tx.CreateBucketIfNotExists([]byte(BucketConstraints))
		if err != nil {
			return err
		}
		for _, room := range rooms {
			raw, err := json.Marshal(room)
			if err != nil {
				return err
			}
			if err := rb.Put([]byte(room.ID), raw); err != nil {
				return err
			}
		}
		for _, item := range items {
			raw, err := json.Marshal(item)
			if err != nil {
				return err
			}
			if err := ib.Put([]byte(item.ID), raw); err != nil {
				return err
			}
		}
		for _, c := range constraints {
			raw, err := json.Marshal(c)
			if err != nil {
				return err
			}
			if err := cb.Put([]byte(c.MatchID), raw); err != nil {
				return err
			}
		}
		return nil
	})
}
