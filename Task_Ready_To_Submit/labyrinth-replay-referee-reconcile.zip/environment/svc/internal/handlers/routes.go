package handlers

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/labyrinth-league/rulesd/internal/store"
)

type API struct {
	DB *store.DB
}

func (a *API) Room(c *gin.Context) {
	id := c.Param("id")
	room, err := a.DB.Room(id)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "room_not_found"})
		return
	}
	c.JSON(http.StatusOK, room)
}

func (a *API) Item(c *gin.Context) {
	id := c.Param("id")
	item, err := a.DB.Item(id)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "item_not_found"})
		return
	}
	c.JSON(http.StatusOK, item)
}

func (a *API) Constraints(c *gin.Context) {
	id := c.Param("id")
	cons, err := a.DB.Constraints(id)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "constraints_not_found"})
		return
	}
	c.JSON(http.StatusOK, cons)
}

func Register(r *gin.Engine, db *store.DB) {
	api := &API{DB: db}
	v1 := r.Group("/v1")
	v1.GET("/rooms/:id", api.Room)
	v1.GET("/items/:id", api.Item)
	v1.GET("/matches/:id/constraints", api.Constraints)
}
