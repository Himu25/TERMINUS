package main

import (
	"flag"
	"log"
	"os"

	"github.com/gin-gonic/gin"
	"github.com/labyrinth-league/rulesd/internal/handlers"
	"github.com/labyrinth-league/rulesd/internal/store"
)

func main() {
	gin.SetMode(gin.ReleaseMode)
	addr := flag.String("addr", ":8741", "listen address")
	dbPath := flag.String("db", "/app/store/rules.bolt", "bbolt path")
	flag.Parse()

	if _, err := os.Stat(*dbPath); err != nil {
		log.Fatalf("rules db missing: %v", err)
	}
	db, err := store.Open(*dbPath)
	if err != nil {
		log.Fatalf("open db: %v", err)
	}
	r := gin.New()
	r.Use(gin.Recovery())
	handlers.Register(r, db)
	log.Printf("rulesd listening on %s", *addr)
	if err := r.Run(*addr); err != nil {
		log.Fatal(err)
	}
}
