#!/bin/bash
set -euo pipefail

export PATH="/usr/local/go/bin:/usr/bin:${PATH}"

python3 - <<'PY'
import hashlib
import json
from pathlib import Path

archive = Path("/app/archive")
match_ids = [
    "match_alpha",
    "match_beta",
    "match_gamma",
    "match_delta",
    "match_epsilon",
    "match_zeta",
]

for match_id in match_ids:
    max_turns = 14 if match_id == "match_zeta" else 12
    cons = {
        "match_id": match_id,
        "max_turns": max_turns,
        "finish_room": "r_finish",
    }
    digest = hashlib.sha256(json.dumps(cons, separators=(",", ":")).encode()).hexdigest()
    sidecar = archive / f"{match_id}.archive.json"
    data = json.loads(sidecar.read_text())
    data["digest"] = digest
    sidecar.write_text(json.dumps(data, indent=2) + "\n")
PY
