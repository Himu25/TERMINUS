#!/bin/bash
set -euo pipefail

if [ -f /tmp/rulesd.pid ]; then
  old_pid="$(cat /tmp/rulesd.pid)"
  kill "$old_pid" 2>/dev/null || true
  rm -f /tmp/rulesd.pid
fi

/app/bin/rulesd -addr :8741 -db /app/store/rules.bolt >/tmp/rulesd.log 2>&1 &
echo $! >/tmp/rulesd.pid
sleep 0.5

for _ in $(seq 1 30); do
  if curl -sf "http://127.0.0.1:8741/v1/rooms/r_start" >/dev/null; then
    exit 0
  fi
  sleep 0.2
done

echo "rulesd failed to start" >&2
cat /tmp/rulesd.log >&2 || true
exit 1
