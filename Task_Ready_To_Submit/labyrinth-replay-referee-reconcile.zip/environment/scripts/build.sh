#!/usr/bin/env bash
set -euo pipefail

mkdir -p /app/bin /app/output /app/store
export PATH="/usr/local/go/bin:/usr/bin:${PATH}"
export GOCACHE="${GOCACHE:-/tmp/go-build}"

cd /app/svc
go build -o /app/bin/rulesd ./cmd/rulesd
go build -o /app/bin/seed_rules ./cmd/seed

/app/bin/seed_rules /app/store/rules.bolt
bash /app/scripts/patch_archive_digests.sh

{
  echo '#!/usr/bin/env ruby'
  echo '# frozen_string_literal: true'
  echo '$LOAD_PATH.unshift("/app/ref/lib")'
  tail -n +3 /app/ref/entry/referee_run
} > /app/bin/referee_run
chmod +x /app/bin/referee_run
