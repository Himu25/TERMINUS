# frozen_string_literal: true

require 'json'

module Parser
  module Jsonl
    module_function

    def parse(path)
      File.readlines(path, chomp: true).filter_map do |line|
        next if line.strip.empty?

        row = JSON.parse(line)
        kind = row['action']
        turn = row['turn'].to_i
        target = row['to'] || row['item'] || row['target']
        { turn: turn, kind: normalize_kind(kind), target: target }
      end
    end

    def normalize_kind(raw)
      case raw
      when 'move', 'M' then 'move'
      when 'use', 'U' then 'use'
      else raw
      end
    end
  end
end
