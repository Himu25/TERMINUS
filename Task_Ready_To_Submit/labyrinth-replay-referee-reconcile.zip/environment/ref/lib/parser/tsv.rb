# frozen_string_literal: true

module Parser
  module Tsv
    module_function

    def parse(path)
      lines = File.readlines(path, chomp: true)
      data = lines.drop(1)
      data.filter_map do |line|
        turn_s, action, target = line.split("\t")
        next if [turn_s, action, target].any?(&:nil?)

        turn = turn_s.to_i - 1
        { turn: turn, kind: normalize_kind(action), target: target }
      end
    end

    def normalize_kind(raw)
      case raw
      when 'move' then 'move'
      when 'use' then 'use'
      else raw
      end
    end
  end
end
