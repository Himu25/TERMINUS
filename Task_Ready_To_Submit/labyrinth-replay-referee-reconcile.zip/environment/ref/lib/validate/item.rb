# frozen_string_literal: true

module Validate
  module Item
    module_function

    def apply(api, state, item_id)
      meta = api.item(item_id)
      effect = meta['effect']
      state[:flags][effect] = true
      state[:inventory] << item_id unless meta['consumes']
      true
    end

    def phantom_room?(state, item_id)
      state[:inventory].include?(item_id)
    end
  end
end
