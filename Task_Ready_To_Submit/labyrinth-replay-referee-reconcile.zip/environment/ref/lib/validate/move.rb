# frozen_string_literal: true

module Validate
  module Move
    module_function

    def apply(api, state, target)
      room = api.room(state[:room])
      allowed = adjacent?(room, target)
      unless allowed
        state[:last_reason] = 'non_adjacent_move'
        return false
      end
      dest = api.room(target)
      unless requirements_met?(state, dest)
        state[:last_reason] = 'room_requirement_missing'
        return false
      end
      state[:room] = target
      state[:finished] = dest['finish_room'] == true
      true
    end

    def adjacent?(room, target)
      exits = room['exits'] || {}
      forward = exits.value?(target)
      reverse = reverse_lookup?(room, target)
      forward || reverse
    end

    def reverse_lookup?(room, target)
      exits = room['exits'] || {}
      exits.key?(target)
    end

    def requirements_met?(state, dest)
      reqs = dest['requires'] || []
      reqs.all? { |flag| state[:flags][flag] }
    end
  end
end
