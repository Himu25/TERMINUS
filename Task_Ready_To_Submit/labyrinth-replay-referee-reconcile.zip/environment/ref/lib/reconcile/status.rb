# frozen_string_literal: true

require 'digest'

module Reconcile
  module Status
    module_function

    def archive_ok_for_turn?(archive, turn_no)
      flags = archive.fetch('turn_flags')
      flags[turn_no]
    end

    def derive(state, constraints, first_illegal, archive_mismatch, archive, _turns_played)
      archive_digest = archive['digest']
      rules_digest = Digest::SHA256.hexdigest(constraints.to_json)
      return 'desynced' if archive_digest != rules_digest
      return 'desynced' if archive_mismatch
      return 'forfeited' if first_illegal
      return 'forfeited' unless state[:finished]
      return 'forfeited' if state[:room] != constraints['finish_room']
      'valid'
    end

    def stale_digest?(archive, constraints)
      archive['digest'] != Digest::SHA256.hexdigest(constraints.to_json)
    end

    def classify_mismatch(archive_ok, rules_ok, turn_no)
      return nil if archive_ok == rules_ok

      {
        'turn' => turn_no,
        'reason' => 'archive_rules_mismatch',
        'archive_ok' => archive_ok,
        'rules_ok' => rules_ok
      }
    end

    def illegal_from_state(state, turn_no)
      return nil if state[:last_reason].nil?

      {
        'turn' => turn_no,
        'reason' => state[:last_reason]
      }
    end
  end
end
