# frozen_string_literal: true

require 'digest'

module Reconcile
  module Report
    module_function

    def build(batch_id, rows)
      valid = rows.count { |r| r['status'] == 'valid' }
      forfeited = rows.count { |r| r['status'] == 'forfeited' }
      desynced = rows.count { |r| r['status'] == 'desynced' }
      digest = digest_hex(rows)
      {
        'schema_version' => LabyrinthReferee::SCHEMA_VERSION,
        'batch_id' => batch_id,
        'matches_total' => rows.length,
        'valid_count' => valid,
        'forfeited_count' => forfeited,
        'desynced_count' => desynced,
        'digest_hex' => digest,
        'matches' => rows.sort_by { |r| r['match_id'] }
      }
    end

    def digest_hex(rows)
      lines = rows.sort_by { |r| r['match_id'] }.map do |r|
        "#{r['match_id']}:#{r['status']}:#{r['turns_played']}"
      end
      Digest::SHA256.hexdigest(lines.join("\n"))
    end
  end
end
