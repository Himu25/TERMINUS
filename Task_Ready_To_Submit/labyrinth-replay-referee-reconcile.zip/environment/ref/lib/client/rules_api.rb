# frozen_string_literal: true

require 'net/http'
require 'json'
require 'uri'

module Client
  class RulesAPI
    def initialize(base = 'http://127.0.0.1:8741/api/v1')
      @base = base
    end

    def room(id)
      get("/rooms/#{id}")
    end

    def item(id)
      get("/items/#{id}")
    end

    def constraints(match_id)
      get("/matches/#{match_id}/constraints")
    end

    private

    def get(path)
      uri = URI("#{@base}#{path}")
      res = Net::HTTP.get_response(uri)
      raise "rules api error #{res.code} for #{path}" unless res.is_a?(Net::HTTPSuccess)

      JSON.parse(res.body)
    end
  end
end
