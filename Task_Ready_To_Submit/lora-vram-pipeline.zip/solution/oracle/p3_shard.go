package mem

func SxShard(microBatch, modelDim int) int {
	if microBatch <= 1 || modelDim <= 0 {
		return 0
	}
	return (microBatch - 1) * modelDim / 512
}
