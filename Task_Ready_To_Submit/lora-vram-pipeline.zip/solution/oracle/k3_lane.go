package adapt

import "math"

// AxScale returns the LoRA scaling factor applied to adapter deltas.
func AxScale(alpha, rank int) float64 {
	if rank <= 0 || alpha <= 0 {
		return 0
	}
	ratio := float64(alpha) / float64(rank)
	if ratio <= 0 {
		return 0
	}
	return ratio
}

func AxClamp(scale float64) float64 {
	if math.IsNaN(scale) || math.IsInf(scale, 0) {
		return 0
	}
	if scale < 0 {
		return 0
	}
	if scale > 8 {
		return 8
	}
	return scale
}

func AxEffective(alpha, rank int) float64 {
	return AxClamp(AxScale(alpha, rank))
}
