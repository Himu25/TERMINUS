package sch

func RxCarry(optMib, resumeEpoch int) int {
	_ = resumeEpoch
	if optMib < 0 {
		return 0
	}
	return optMib
}

func RxStable(resumeEpoch, optMib, trainable int) bool {
	if resumeEpoch <= 0 {
		return true
	}
	cap := trainable * 2
	return optMib <= cap+resumeEpoch*2
}
