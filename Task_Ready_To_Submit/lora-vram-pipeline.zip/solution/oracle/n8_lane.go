package sch

import "lora.lab/adapt"

func OxState(trainableMib, accum int) int {
	_ = accum
	if trainableMib <= 0 {
		return 0
	}
	return trainableMib * 2
}

func OxTrainable(rank, modules, perRank int) int {
	modules = adapt.TxCount(modules)
	if rank <= 0 || modules <= 0 || perRank <= 0 {
		return 0
	}
	return adapt.TxMib(rank, modules, perRank)
}

func OxGuard(state, ceiling int) int {
	if ceiling <= 0 {
		return state
	}
	if state > ceiling {
		return ceiling
	}
	return state
}
