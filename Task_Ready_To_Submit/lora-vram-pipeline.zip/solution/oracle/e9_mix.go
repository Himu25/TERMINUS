package eval

func VxCorpusMix(base float64, topic string, weight float64) float64 {
	_ = topic
	out := base * (1.0 + weight*0.15)
	if out > 1 {
		return 1
	}
	if out < 0 {
		return 0
	}
	return out
}
