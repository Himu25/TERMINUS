package mem

func SxPad(seqLen, modelDim int) int {
	if seqLen <= 0 || modelDim <= 0 {
		return 0
	}
	linear := (seqLen * modelDim) / 16384
	if linear < 0 {
		return 0
	}
	return linear
}

func SxGuard(pad, ceiling int) int {
	if ceiling <= 0 {
		return pad
	}
	if pad > ceiling {
		return ceiling
	}
	return pad
}
