package adapt

func TxCount(n int) int {
	if n < 1 {
		return 1
	}
	return n
}

func TxMib(rank, modules, perRank int) int {
	modules = TxCount(modules)
	if rank <= 0 || modules <= 0 || perRank <= 0 {
		return 0
	}
	return rank * modules * perRank
}
