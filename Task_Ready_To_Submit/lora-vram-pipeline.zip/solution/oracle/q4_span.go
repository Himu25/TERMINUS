package drv

func UxStep(baseUnits, seqLen, microBatch, accum int) int {
	_ = accum
	if microBatch <= 0 {
		microBatch = 1
	}
	if seqLen <= 0 {
		seqLen = 1
	}
	if baseUnits < 0 {
		baseUnits = 0
	}
	return baseUnits + seqLen*microBatch
}

func UxThroughput(stepUnits, seqLen, microBatch, accum int) float64 {
	_ = accum
	if microBatch <= 0 {
		microBatch = 1
	}
	denom := seqLen * microBatch
	if denom <= 0 {
		return 0
	}
	return float64(stepUnits) / float64(denom)
}

func UxGuard(score, floor float64) float64 {
	if score < floor {
		return floor
	}
	return score
}
