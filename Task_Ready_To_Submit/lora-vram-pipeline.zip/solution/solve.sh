#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/pipeline.toml
require_file /app/data/batch_specs.jsonl
require_file /app/data/val_corpus.json
mkdir -p /app/bin /app/output

log "apply patched sources"
cp "${ROOT_DIR}/oracle/k3_lane.go" /app/adapt/k3_lane.go
cp "${ROOT_DIR}/oracle/a1_targets.go" /app/adapt/a1_targets.go
cp "${ROOT_DIR}/oracle/p1_slot.go" /app/mem/p1_slot.go
cp "${ROOT_DIR}/oracle/p2_slot.go" /app/mem/p2_slot.go
cp "${ROOT_DIR}/oracle/p3_shard.go" /app/mem/p3_shard.go
cp "${ROOT_DIR}/oracle/n7_lane.go" /app/sch/n7_lane.go
cp "${ROOT_DIR}/oracle/n8_lane.go" /app/sch/n8_lane.go
cp "${ROOT_DIR}/oracle/n9_carry.go" /app/sch/n9_carry.go
cp "${ROOT_DIR}/oracle/e9_mix.go" /app/eval/e9_mix.go
cp "${ROOT_DIR}/oracle/q4_span.go" /app/drv/q4_span.go

log "rebuild driver"
go build -o /app/bin/lorad ./cmd/lorad
go build -o /app/bin/prepdata ./cmd/prepdata

log "refresh default batch bundle"
/app/bin/prepdata /app/data/batch_specs.jsonl /app/data/batches_default.jsonl

log "emit default report"
/app/bin/lorad /app/data/batches_default.jsonl /app/output/lora_bench.json

log "post-run validation against pipeline.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/pipeline.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k.endswith("_floor") or k.endswith("_score") or k.startswith("accum_") or k.startswith("resume_") or k.startswith("corpus_mix"):
        cfg[k] = float(v)
    elif k.startswith("max_") or k.startswith("long_") or k.startswith("micro_"):
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/lora_bench.json").read_text())
assert report["status"] == "ok", report
assert report["mean_val_accuracy"] >= cfg["val_accuracy_floor"]
assert report["mean_vram_mib"] <= cfg["max_mean_vram_mib"]
assert report["p95_vram_mib"] <= cfg["max_p95_vram_mib"]
assert report["mean_throughput_score"] >= cfg["min_throughput_score"]
assert report["peak_optimizer_mib"] <= cfg["max_peak_optimizer_mib"]
assert report["mean_accum_stable"] >= cfg["accum_min_stable"]
assert report["mean_corpus_mix"] >= cfg["corpus_mix_floor"]
assert report["mean_resume_stable"] >= cfg["resume_min_stable"]
for row in report["batches"]:
    if row["batch_id"].startswith("b_long_"):
        assert row["vram_mib"] <= cfg["long_seq_vram_ceiling"], row
    if row["batch_id"].startswith("b_shard_"):
        assert row["vram_mib"] <= cfg["micro_shard_vram_ceiling"], row
    if row["batch_id"].startswith("b_resume_") and row["accum_steps"] > 1:
        assert row["resume_stable"] is True, row
print("ok", report["mean_val_accuracy"], report["p95_vram_mib"], report["peak_optimizer_mib"])
PY

log "oracle complete"
