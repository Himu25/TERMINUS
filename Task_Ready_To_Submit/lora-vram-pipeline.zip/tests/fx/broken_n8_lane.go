package sch

import "lora.lab/adapt"

func OxState(trainableMib, accum int) int {
	if trainableMib <= 0 {
		return 0
	}
	spike := trainableMib * 6
	if accum > 1 {
		spike += trainableMib * accum * 3
	}
	if spike < 1200 {
		spike = 1200
	}
	return spike
}

func OxTrainable(rank, modules, perRank int) int {
	return adapt.TxMib(rank, modules, perRank)
}
