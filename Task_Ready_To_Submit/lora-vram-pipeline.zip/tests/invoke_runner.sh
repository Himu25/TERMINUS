#!/bin/bash
set -euo pipefail
cd /app
mkdir -p /app/output
/app/bin/lorad /app/data/batches_default.jsonl /app/output/lora_bench.json
