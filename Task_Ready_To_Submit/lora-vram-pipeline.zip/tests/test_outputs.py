"""Validate /app/output/lora_bench.json against pipeline.toml guardrails.

Covers report schema, digest determinism, default-bundle quality floors,
long-sequence fixture packs, gradient-accumulation stability rows,
optimizer-state residency ceilings, corpus/resume/shard scenarios,
and ablations that reject partial fixes.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from contextlib import contextmanager
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "lora_bench.json"
CFG = APP / "config" / "pipeline.toml"
LORAD = "/app/bin/lorad"
INVOKER = Path(__file__).resolve().parent / "invoke_runner.sh"
FX = Path(__file__).resolve().parent / "fx"
MEAN_TOLERANCE = 2e-4
BUILD_TIMEOUT = 120
RUN_TIMEOUT = 60

REPORT_KEYS = frozenset(
    {
        "status",
        "model_dim",
        "lora_rank",
        "batches_total",
        "mean_val_accuracy",
        "mean_vram_mib",
        "mean_step_units",
        "mean_throughput_score",
        "p95_vram_mib",
        "peak_optimizer_mib",
        "mean_accum_stable",
        "mean_corpus_mix",
        "mean_resume_stable",
        "report_digest",
        "batches",
    }
)
ROW_KEYS = frozenset(
    {
        "batch_id",
        "seq_len",
        "val_accuracy",
        "vram_mib",
        "step_units",
        "throughput_score",
        "accum_steps",
        "optimizer_mib",
        "accum_stable",
        "corpus_mix",
        "resume_stable",
    }
)


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "model_dim": 768,
        "lora_rank": 16,
        "lora_alpha": 32,
        "base_mib": 380,
        "adapter_mib_per_rank": 2,
        "val_accuracy_floor": 0.65,
        "max_mean_vram_mib": 700,
        "max_p95_vram_mib": 950,
        "min_throughput_score": 1.0,
        "max_peak_optimizer_mib": 1100,
        "long_seq_vram_ceiling": 740,
        "accum_min_stable": 0.85,
        "corpus_mix_floor": 0.10,
        "resume_min_stable": 0.85,
        "micro_shard_vram_ceiling": 680,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in (
            "val_accuracy_floor",
            "min_throughput_score",
            "accum_min_stable",
            "corpus_mix_floor",
            "resume_min_stable",
        ):
            cfg[key] = float(val)
        elif key in (
            "model_dim",
            "lora_rank",
            "lora_alpha",
            "base_mib",
            "adapter_mib_per_rank",
            "max_mean_vram_mib",
            "max_p95_vram_mib",
            "max_peak_optimizer_mib",
            "long_seq_vram_ceiling",
            "micro_shard_vram_ceiling",
        ):
            cfg[key] = int(float(val))
    return cfg


def _round4(value: float) -> float:
    return round(value * 10000 + 0.5) / 10000


def _expected_means(rows: list[dict]) -> tuple[float, float, float, float, float, float, float]:
    if not rows:
        return 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
    total = len(rows)
    acc = sum(row["val_accuracy"] for row in rows) / total
    vram = sum(row["vram_mib"] for row in rows) / total
    units = sum(row["step_units"] for row in rows) / total
    tput = sum(row["throughput_score"] for row in rows) / total
    stable = sum(1 for row in rows if row["accum_stable"]) / total
    mix = sum(row["corpus_mix"] for row in rows) / total
    resume = sum(1 for row in rows if row["resume_stable"]) / total
    return (
        _round4(acc),
        _round4(vram),
        _round4(units),
        _round4(tput),
        _round4(stable),
        _round4(mix),
        _round4(resume),
    )


def _p95_vram(rows: list[dict]) -> int:
    vals = sorted(row["vram_mib"] for row in rows)
    if not vals:
        return 0
    idx = max(0, min(len(vals) - 1, int(0.95 * len(vals) + 0.999999) - 1))
    return vals[idx]


def _digest_payload(report: dict) -> dict:
    return {
        "status": report["status"],
        "model_dim": report["model_dim"],
        "lora_rank": report["lora_rank"],
        "batches_total": report["batches_total"],
        "mean_val_accuracy": report["mean_val_accuracy"],
        "mean_vram_mib": report["mean_vram_mib"],
        "mean_step_units": report["mean_step_units"],
        "mean_throughput_score": report["mean_throughput_score"],
        "p95_vram_mib": report["p95_vram_mib"],
        "peak_optimizer_mib": report["peak_optimizer_mib"],
        "mean_accum_stable": report["mean_accum_stable"],
        "mean_corpus_mix": report["mean_corpus_mix"],
        "mean_resume_stable": report["mean_resume_stable"],
        "report_digest": "",
        "batches": report["batches"],
    }


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
        timeout=10,
    )
    return proc.stdout.split()[0]


def _run_bench(batch_path: Path, out_path: Path) -> None:
    proc = subprocess.run(
        [LORAD, str(batch_path), str(out_path)],
        capture_output=True,
        text=True,
        check=False,
        timeout=RUN_TIMEOUT,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _invoke_default() -> None:
    proc = subprocess.run(
        ["bash", str(INVOKER)],
        capture_output=True,
        text=True,
        check=False,
        timeout=RUN_TIMEOUT,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "lora_bench.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


def _bench_fixture(name: str, batch_file: Path) -> dict:
    out = APP / "output" / name
    _run_bench(batch_file, out)
    return json.loads(out.read_text(encoding="utf-8"))


@contextmanager
def _swap_go(rel_path: str, fixture_name: str):
    target = APP / rel_path
    backup = target.read_text(encoding="utf-8")
    shutil.copy(FX / fixture_name, target)
    try:
        proc = subprocess.run(
            ["go", "build", "-o", str(APP / "bin" / "lorad"), "./cmd/lorad"],
            cwd=str(APP),
            capture_output=True,
            text=True,
            check=False,
            timeout=BUILD_TIMEOUT,
        )
        assert proc.returncode == 0, proc.stderr or proc.stdout
        yield
    finally:
        target.write_text(backup, encoding="utf-8")
        try:
            proc = subprocess.run(
                ["go", "build", "-o", str(APP / "bin" / "lorad"), "./cmd/lorad"],
                cwd=str(APP),
                capture_output=True,
                text=True,
                check=False,
                timeout=BUILD_TIMEOUT,
            )
            if proc.returncode == 0:
                _invoke_default()
        except (subprocess.TimeoutExpired, OSError):
            pass


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    """Run the default bench once before the module-scoped assertions."""
    assert INVOKER.is_file(), "runner script missing"
    _invoke_default()


def test_report_top_level_keys_exact() -> None:
    """Report must expose only the documented top-level keys."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS


def test_batch_row_schema() -> None:
    """Each batch row must match the documented per-batch schema."""
    report = _load_report()
    assert report["batches"]
    for row in report["batches"]:
        assert set(row.keys()) == ROW_KEYS
        assert isinstance(row["batch_id"], str) and row["batch_id"]
        assert isinstance(row["seq_len"], int) and row["seq_len"] > 0
        assert isinstance(row["accum_steps"], int) and row["accum_steps"] >= 1
        assert 0.0 <= float(row["val_accuracy"]) <= 1.0
        assert row["vram_mib"] >= 0
        assert row["step_units"] >= 0
        assert float(row["throughput_score"]) >= 0.0
        assert row["optimizer_mib"] >= 0
        assert isinstance(row["accum_stable"], bool)
        assert 0.0 <= float(row["corpus_mix"]) <= 1.0
        assert isinstance(row["resume_stable"], bool)


def test_passing_run_contract() -> None:
    """Default bundle must finish ok and meet pipeline.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["model_dim"] == cfg["model_dim"]
    assert report["lora_rank"] == cfg["lora_rank"]
    assert report["batches_total"] == len(report["batches"])
    assert report["mean_val_accuracy"] >= cfg["val_accuracy_floor"]
    assert report["mean_vram_mib"] <= cfg["max_mean_vram_mib"]
    assert report["p95_vram_mib"] <= cfg["max_p95_vram_mib"]
    assert report["mean_throughput_score"] >= cfg["min_throughput_score"]
    assert report["peak_optimizer_mib"] <= cfg["max_peak_optimizer_mib"]
    assert report["mean_accum_stable"] >= cfg["accum_min_stable"]
    assert report["mean_corpus_mix"] >= cfg["corpus_mix_floor"]
    assert report["mean_resume_stable"] >= cfg["resume_min_stable"]


def test_mean_fields_recomputed_from_batches() -> None:
    """Summary means must match per-batch rows within tolerance."""
    report = _load_report()
    (
        exp_acc,
        exp_vram,
        exp_units,
        exp_tput,
        exp_stable,
        exp_mix,
        exp_resume,
    ) = _expected_means(report["batches"])
    assert abs(report["mean_val_accuracy"] - exp_acc) <= MEAN_TOLERANCE
    assert abs(report["mean_vram_mib"] - exp_vram) <= MEAN_TOLERANCE
    assert abs(report["mean_step_units"] - exp_units) <= MEAN_TOLERANCE
    assert abs(report["mean_throughput_score"] - exp_tput) <= MEAN_TOLERANCE
    assert abs(report["mean_accum_stable"] - exp_stable) <= MEAN_TOLERANCE
    assert abs(report["mean_corpus_mix"] - exp_mix) <= MEAN_TOLERANCE
    assert abs(report["mean_resume_stable"] - exp_resume) <= MEAN_TOLERANCE
    assert report["p95_vram_mib"] == _p95_vram(report["batches"])
    peak = max(row["optimizer_mib"] for row in report["batches"])
    assert report["peak_optimizer_mib"] == peak


def test_report_digest_matches_payload() -> None:
    """report_digest must hash the compact pre-digest JSON payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_deterministic_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_long_context_rows_respect_ceiling() -> None:
    """Long-context default rows must stay at or below long_seq_vram_ceiling."""
    cfg = _parse_cfg()
    report = _load_report()
    long_rows = [row for row in report["batches"] if row["batch_id"].startswith("b_long_")]
    assert long_rows, "expected b_long_ rows in default bundle"
    for row in long_rows:
        assert row["vram_mib"] <= cfg["long_seq_vram_ceiling"], row


def test_shard_rows_respect_ceiling() -> None:
    """Micro-shard default rows must stay at or below micro_shard_vram_ceiling."""
    cfg = _parse_cfg()
    report = _load_report()
    shard_rows = [row for row in report["batches"] if row["batch_id"].startswith("b_shard_")]
    assert len(shard_rows) >= 2
    for row in shard_rows:
        assert row["vram_mib"] <= cfg["micro_shard_vram_ceiling"], row


def test_resume_rows_stable() -> None:
    """Default-bundle resume rows with multi-step accumulation must be resume_stable."""
    report = _load_report()
    resume_rows = [
        row
        for row in report["batches"]
        if row["batch_id"].startswith("b_resume_") and row["accum_steps"] > 1
    ]
    assert len(resume_rows) >= 2
    for row in resume_rows:
        assert row["resume_stable"] is True, row


def test_accumulation_rows_stable() -> None:
    """Default-bundle accumulation rows with multi-step schedules must be accum_stable."""
    report = _load_report()
    accum_rows = [
        row
        for row in report["batches"]
        if row["batch_id"].startswith("b_accum_") and row["accum_steps"] > 1
    ]
    assert len(accum_rows) >= 2
    for row in accum_rows:
        assert row["accum_stable"] is True, row


def test_accum_fixture_pack() -> None:
    """Gradient-accumulation fixture pack must keep accum_stable high."""
    cfg = _parse_cfg()
    report = _bench_fixture("bench_accum_pack.json", APP / "data" / "fixture_accum.jsonl")
    assert report["mean_accum_stable"] >= cfg["accum_min_stable"]
    for row in report["batches"]:
        if row["accum_steps"] > 1:
            assert row["accum_stable"] is True, row


def test_opt_spike_fixture_pack() -> None:
    """Optimizer-heavy fixture pack must stay within peak residency ceiling."""
    cfg = _parse_cfg()
    report = _bench_fixture("bench_opt_spike.json", APP / "data" / "fixture_opt.jsonl")
    assert report["peak_optimizer_mib"] <= cfg["max_peak_optimizer_mib"]
    assert report["mean_val_accuracy"] >= cfg["val_accuracy_floor"]
    opt_rows = [row for row in report["batches"] if row["batch_id"].startswith("b_opt_")]
    assert len(opt_rows) >= 2
    for row in opt_rows:
        assert row["optimizer_mib"] <= cfg["max_peak_optimizer_mib"], row


def test_corpus_fixture_pack() -> None:
    """Corpus-weighted fixture pack must keep mean accuracy above the floor."""
    cfg = _parse_cfg()
    report = _bench_fixture("bench_corpus_pack.json", APP / "data" / "fixture_corpus.jsonl")
    assert report["mean_val_accuracy"] >= cfg["val_accuracy_floor"]
    assert report["mean_corpus_mix"] >= cfg["corpus_mix_floor"]


def test_broken_scale_ablation_fails_accuracy() -> None:
    """Inverted LoRA scaling must drop validation accuracy below the floor."""
    cfg = _parse_cfg()
    with _swap_go("adapt/k3_lane.go", "broken_k3_lane.go"):
        report = _bench_fixture(
            "bench_ablation_scale.json",
            APP / "data" / "batches_default.jsonl",
        )
    assert report["mean_val_accuracy"] < cfg["val_accuracy_floor"]


def test_broken_seqpad_ablation_fails_long_seq() -> None:
    """Quadratic sequence padding must blow past the long-context VRAM ceiling."""
    cfg = _parse_cfg()
    with _swap_go("mem/p2_slot.go", "broken_p2_slot.go"):
        report = _bench_fixture(
            "bench_ablation_seqpad.json",
            APP / "data" / "fixture_long_seq.jsonl",
        )
    over = [row for row in report["batches"] if row["vram_mib"] > cfg["long_seq_vram_ceiling"]]
    assert over, "expected long-seq VRAM ceiling violation under broken padding"


def test_broken_accum_ablation_unstable() -> None:
    """Multiply-style accumulation normalization must mark rows unstable."""
    with _swap_go("sch/n7_lane.go", "broken_n7_lane.go"):
        report = _bench_fixture(
            "bench_ablation_accum.json",
            APP / "data" / "fixture_accum.jsonl",
        )
    unstable = [row for row in report["batches"] if row["accum_steps"] > 1 and not row["accum_stable"]]
    assert unstable, "expected unstable accum rows under broken normalization"


def test_broken_optstate_ablation_spikes() -> None:
    """Inflated optimizer residency model must exceed the peak ceiling."""
    cfg = _parse_cfg()
    with _swap_go("sch/n8_lane.go", "broken_n8_lane.go"):
        report = _bench_fixture(
            "bench_ablation_opt.json",
            APP / "data" / "fixture_opt.jsonl",
        )
    assert report["peak_optimizer_mib"] > cfg["max_peak_optimizer_mib"]

