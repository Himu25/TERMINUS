package probe

func Stub() int {
	return 0
}
