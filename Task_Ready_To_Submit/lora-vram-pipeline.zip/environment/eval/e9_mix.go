package eval

func VxCorpusMix(base float64, topic string, weight float64) float64 {
	_ = topic
	return base - weight*0.25
}
