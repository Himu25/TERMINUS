package eval

import (
	"hash/fnv"
	"math"
)

func VxBase(label float64, seqLen int) float64 {
	h := fnv.New64a()
	_, _ = h.Write([]byte{byte(seqLen & 0xff), byte((seqLen >> 8) & 0xff)})
	noise := float64(h.Sum64()%1000) / 10000.0
	return label*0.92 + noise*0.08
}

func VxScaled(base, scale float64) float64 {
	if scale <= 0 {
		return 0
	}
	weight := 0.3 + math.Tanh(scale)*0.7
	out := base * weight
	if out > 1 {
		return 1
	}
	if out < 0 {
		return 0
	}
	return out
}

func VxRound(v float64) float64 {
	return math.Round(v*10000) / 10000
}
