package eval

func ShadowMix(base float64) float64 {
	return base * 0.5
}
