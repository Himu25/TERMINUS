package types

type PipelineCfg struct {
	ModelDim               int
	LoraRank               int
	LoraAlpha              int
	BaseMib                int
	AdapterMibPerRank      int
	ValAccuracyFloor       float64
	MaxMeanVramMib         int
	MaxP95VramMib          int
	MinThroughputScore     float64
	MaxPeakOptimizerMib    int
	LongSeqVramCeiling     int
	AccumMinStable         float64
	CorpusMixFloor         float64
	ResumeMinStable        float64
	MicroShardVramCeiling  int
	CorpusPath             string
}

type BatchCase struct {
	BatchID       string  `json:"batch_id"`
	SeqLen        int     `json:"seq_len"`
	MicroBatch    int     `json:"micro_batch"`
	AccumSteps    int     `json:"accum_steps"`
	TargetModules int     `json:"target_modules"`
	ValLabel      float64 `json:"val_label"`
	Topic         string  `json:"topic"`
	ResumeEpoch   int     `json:"resume_epoch"`
}

type BatchRow struct {
	BatchID         string  `json:"batch_id"`
	SeqLen          int     `json:"seq_len"`
	ValAccuracy     float64 `json:"val_accuracy"`
	VramMib         int     `json:"vram_mib"`
	StepUnits       int     `json:"step_units"`
	ThroughputScore float64 `json:"throughput_score"`
	AccumSteps      int     `json:"accum_steps"`
	OptimizerMib    int     `json:"optimizer_mib"`
	AccumStable     bool    `json:"accum_stable"`
	CorpusMix       float64 `json:"corpus_mix"`
	ResumeStable    bool    `json:"resume_stable"`
}

type BenchReport struct {
	Status              string     `json:"status"`
	ModelDim            int        `json:"model_dim"`
	LoraRank            int        `json:"lora_rank"`
	BatchesTotal        int        `json:"batches_total"`
	MeanValAccuracy     float64    `json:"mean_val_accuracy"`
	MeanVramMib         float64    `json:"mean_vram_mib"`
	MeanStepUnits       float64    `json:"mean_step_units"`
	MeanThroughputScore float64    `json:"mean_throughput_score"`
	P95VramMib          int        `json:"p95_vram_mib"`
	PeakOptimizerMib    int        `json:"peak_optimizer_mib"`
	MeanAccumStable     float64    `json:"mean_accum_stable"`
	MeanCorpusMix       float64    `json:"mean_corpus_mix"`
	MeanResumeStable    float64    `json:"mean_resume_stable"`
	ReportDigest        string     `json:"report_digest"`
	Batches             []BatchRow `json:"batches"`
}
