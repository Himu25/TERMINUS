package sch

import "math"

func GxNorm(loss float64, accum int) float64 {
	if accum <= 0 {
		return loss
	}
	return loss * float64(accum)
}

func GxStable(accum int, normLoss, baseAcc float64) bool {
	if accum <= 1 {
		return true
	}
	expected := baseAcc / float64(accum)
	drift := math.Abs(normLoss - expected)
	return drift < 0.35
}
