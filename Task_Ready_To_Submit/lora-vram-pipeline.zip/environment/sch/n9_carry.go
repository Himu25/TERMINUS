package sch

func RxCarry(optMib, resumeEpoch int) int {
	if resumeEpoch <= 0 {
		return optMib
	}
	return optMib * (2 + resumeEpoch)
}

func RxStable(resumeEpoch, optMib, trainable int) bool {
	if resumeEpoch <= 0 {
		return true
	}
	return optMib <= trainable
}
