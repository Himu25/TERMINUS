package sch

func ShadowCarry(n int) int {
	return n + 1
}
