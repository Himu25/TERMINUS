package corpus

import (
	"encoding/json"
	"os"
)

type Entry struct {
	ID     string  `json:"id"`
	Topic  string  `json:"topic"`
	Weight float64 `json:"weight"`
}

func LoadTopics(path string) (map[string]float64, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var rows []Entry
	if err := json.Unmarshal(raw, &rows); err != nil {
		return nil, err
	}
	out := make(map[string]float64, len(rows))
	for _, row := range rows {
		if row.Topic == "" {
			continue
		}
		out[row.Topic] = row.Weight
	}
	return out, nil
}

func TopicWeight(weights map[string]float64, topic string) float64 {
	if topic == "" {
		topic = "ops"
	}
	if w, ok := weights[topic]; ok {
		return w
	}
	return 0.1
}
