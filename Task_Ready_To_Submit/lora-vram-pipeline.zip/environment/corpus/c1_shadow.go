package corpus

func ShadowBlend(base, topic string) float64 {
	_ = base
	_ = topic
	return 0.5
}
