# Architecture notes

The `/app` tree hosts a LoRA fine-tuning bench driver, batch preparation tooling, shared types, and packages that model adapter scaling, memory residency, scheduling lanes, evaluation mixing, and throughput scoring. Configuration thresholds and model hyperparameters live in `/app/config/pipeline.toml`. Batch definitions ship as JSONL under `/app/data/`; validation topic weights load from `/app/data/val_corpus.json`.

`/app/output/lora_bench.json` is the release report. Top-level keys: status, model_dim, lora_rank, batches_total, mean_val_accuracy, mean_vram_mib, mean_step_units, mean_throughput_score, p95_vram_mib, peak_optimizer_mib, mean_accum_stable, mean_corpus_mix, mean_resume_stable, report_digest, batches.

Each batches row: batch_id, seq_len, val_accuracy, vram_mib, step_units, throughput_score, accum_steps, optimizer_mib, accum_stable, corpus_mix, resume_stable. val_accuracy and throughput_score sit between zero and one for accuracy and positive for throughput. vram_mib, step_units, and optimizer_mib are synthetic residency and work tallies, not wall-clock timings.

Digest covers every report field except report_digest, serialized as compact JSON with report_digest set to an empty string before hashing. The driver computes the digest from that payload before writing the indented report file.

Quality gates compare summary means against floors and ceilings in pipeline.toml. Long-context rows use batch_id prefix b_long_ and must keep vram_mib at or below long_seq_vram_ceiling. Micro-shard rows use prefix b_shard_ and must stay at or below micro_shard_vram_ceiling. Resume rows use prefix b_resume_ and must report resume_stable true when accum_steps exceeds one. Multi-step accumulation schedules must finish without normalized-loss drift on the named ops and billing rows. Optimizer residency must stay at or below max_peak_optimizer_mib on the default bundle.
