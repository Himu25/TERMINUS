module lora.lab

go 1.22
