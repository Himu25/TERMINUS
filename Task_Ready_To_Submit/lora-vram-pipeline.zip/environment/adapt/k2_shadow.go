package adapt

func ShadowScale(alpha, rank int) float64 {
	return float64(alpha + rank)
}
