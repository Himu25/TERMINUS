See docs/architecture.md for report layout and runbook.md for rebuild steps.
