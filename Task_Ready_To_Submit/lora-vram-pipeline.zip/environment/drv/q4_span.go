package drv

func UxStep(baseUnits, seqLen, microBatch, accum int) int {
	if microBatch <= 0 {
		microBatch = 1
	}
	return baseUnits + seqLen*microBatch*accum
}

func UxThroughput(stepUnits, seqLen, microBatch, accum int) float64 {
	denom := seqLen * microBatch
	if accum > 1 {
		denom *= accum
	}
	if denom <= 0 {
		return 0
	}
	return float64(stepUnits) / float64(denom)
}
