package scheduler

import "lora.lab/pkg/types"

func Plan(cases []types.BatchCase) int {
	total := 0
	for _, bc := range cases {
		total += bc.SeqLen * bc.MicroBatch
	}
	return total
}
