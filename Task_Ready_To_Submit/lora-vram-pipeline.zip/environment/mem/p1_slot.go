package mem

import "lora.lab/adapt"

func BxBase(baseMib, modelDim int) int {
	return baseMib + modelDim*modelDim/512
}

func BxAdapter(rank, modules, perRank int) int {
	return adapt.TxMib(rank, modules, perRank)
}

func BxTotal(baseMib, modelDim, rank, modules, perRank int) int {
	return BxBase(baseMib, modelDim) + BxAdapter(rank, modules, perRank)
}
