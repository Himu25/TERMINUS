package mem

func ShadowShard(n int) int {
	return n * 2
}
