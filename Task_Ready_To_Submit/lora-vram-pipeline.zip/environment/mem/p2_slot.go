package mem

func SxPad(seqLen, modelDim int) int {
	if seqLen <= 0 {
		return 0
	}
	return (seqLen * seqLen * modelDim) / 65536
}
