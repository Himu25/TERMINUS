package mem

func SxShard(microBatch, modelDim int) int {
	if microBatch <= 1 {
		return 0
	}
	return microBatch * modelDim / 64
}
