"""Verifier for broken event lineage audit."""

import hashlib
import json
import os
import shutil
import subprocess

import pytest
from pathlib import Path

APP = Path("/app")
ACTIVE = APP / "data" / "active" / "run_alpha"
FIXTURES = APP / "data" / "replay"
OUT = APP / "output" / "lineage_audit.json"
GO_BIN = "/usr/local/go/bin/go"
VERIFY_BIN = "/app/tools/verify_bin"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)
    subprocess.run(["cp", "/app/bin/stream_audit", VERIFY_BIN], check=True)


def _digest_hex(
    run_id: str,
    event_count: int,
    unique_tx_count: int,
    duplicate_count: int,
    ordering_violation_count: int,
    checkpoint_gap_count: int,
    legacy_emit_count: int,
    retention_stale_count: int,
    amount_total_cents: int,
) -> str:
    fields = (
        str(event_count),
        str(unique_tx_count),
        str(duplicate_count),
        str(ordering_violation_count),
        str(checkpoint_gap_count),
        str(legacy_emit_count),
        str(retention_stale_count),
        str(amount_total_cents),
    )
    payload = run_id + "|" + "|".join(fields)
    return hashlib.sha256(payload.encode()).hexdigest()


def _op_f(key: str, wave: int) -> str:
    return f"{key}#{wave}"


def _op_g(stored_gen: int, live_gen: int) -> bool:
    return stored_gen >= live_gen


def _op_b(current_offset: int, last_offset: int) -> bool:
    return current_offset >= last_offset


def _op_w(seq: int, window: int) -> bool:
    return seq <= window


def _gen_for_part(part_id: int, bundle: dict) -> int:
    if 0 <= part_id < bundle["lag_partitions"]:
        return bundle["replay_gen"] - 1
    return bundle["replay_gen"]


def _legacy_emit(prefix: str, key: str, stored_gen: int, live_gen: int) -> bool:
    if not prefix or len(key) < len(prefix):
        return False
    if key[: len(prefix)] != prefix:
        return False
    return stored_gen >= live_gen


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = FIXTURES / pack_name
    bundle = json.loads((pack_dir / "event_bundle.json").read_text())
    rows = []
    for line in (pack_dir / "events.jsonl").read_text().splitlines():
        if line.strip():
            rows.append(json.loads(line))
    rows.sort(key=lambda r: r["seq"])

    seen: dict[str, dict] = {}
    last_offset: dict[int, int] = {}

    events = 0
    unique = 0
    dupes = 0
    ordering = 0
    checkpoint_gaps = 0
    legacy = 0
    retention_stale = 0
    amount_total = 0

    for row in rows:
        if row["seq"] <= 0:
            continue
        live = _gen_for_part(row["partition_id"], bundle)
        dedup_id = _op_f(row["tx_id"], bundle["replay_gen"])
        op = row["op_code"]

        if op == 1:
            if bundle["checkpoint_stride"] > 0 and row["offset"] % bundle["checkpoint_stride"] != 0:
                checkpoint_gaps += 1
        elif op == 2:
            stale_ids = [sid for sid, ent in seen.items() if ent["gen"] < live]
            for sid in stale_ids:
                seen.pop(sid, None)
        elif op == 3:
            ent = seen.get(dedup_id)
            if ent and _legacy_emit(
                bundle["legacy_prefix"], row["tx_id"], ent["gen"], live
            ):
                legacy += 1
        elif op == 0:
            events += 1
            if not _op_b(row["offset"], last_offset.get(row["partition_id"], 0)):
                ordering += 1
            last_offset[row["partition_id"]] = row["offset"]

            if not _op_w(row["seq"], bundle["retention_window"]):
                retention_stale += 1

            ent = seen.get(dedup_id)
            if ent and _op_g(ent["gen"], live):
                dupes += 1
                continue
            if not _op_w(row["seq"], bundle["retention_window"]):
                continue

            seen[dedup_id] = {"gen": row["commit_epoch"], "amount": row["amount_cents"]}
            unique += 1
            amount_total += row["amount_cents"]

    e_count = bundle["event_count"] if bundle["event_count"] > 0 else events
    digest = _digest_hex(
        bundle["run_id"],
        e_count,
        unique,
        dupes,
        ordering,
        checkpoint_gaps,
        legacy,
        retention_stale,
        amount_total,
    )
    return {
        "schema_version": "1",
        "run_id": bundle["run_id"],
        "event_count": e_count,
        "unique_tx_count": unique,
        "duplicate_count": dupes,
        "ordering_violation_count": ordering,
        "checkpoint_gap_count": checkpoint_gaps,
        "legacy_emit_count": legacy,
        "retention_stale_count": retention_stale,
        "amount_total_cents": amount_total,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    dest = ACTIVE
    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(src, dest)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_LINEAGE_AUDIT": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_alpha_report_matches_replay() -> None:
    """Active run_alpha pack should replay all audit counters including digest."""
    _swap("run_alpha")
    exp = _expected_from_fixture("run_alpha")
    got = _run_tool()
    assert got == exp


def test_alpha_report_matches_schema() -> None:
    """Report JSON should expose exactly the declared audit schema fields."""
    schema = json.loads((APP / "schemas" / "lineage_audit.schema.json").read_text())
    required = set(schema["required"])
    _swap("run_alpha")
    got = _run_tool()
    assert set(got.keys()) == required


def test_alpha_unique_tx_matches_replay() -> None:
    """Alpha pack should accept two distinct financial transactions."""
    _swap("run_alpha")
    exp = _expected_from_fixture("run_alpha")
    got = _run_tool()
    assert got["unique_tx_count"] == exp["unique_tx_count"]
    assert got["amount_total_cents"] == exp["amount_total_cents"]


def test_storm_dup_rejects_replay_duplicates() -> None:
    """Storm dup pack should count replay duplicates separately from unique accepts."""
    _swap("storm_dup_a")
    exp = _expected_from_fixture("storm_dup_a")
    got = _run_tool()
    assert got["duplicate_count"] == exp["duplicate_count"]
    assert got["unique_tx_count"] == exp["unique_tx_count"]


def test_storm_dup_checkpoint_gap_matches_replay() -> None:
    """Storm dup pack should flag misaligned checkpoint offsets."""
    _swap("storm_dup_a")
    exp = _expected_from_fixture("storm_dup_a")
    got = _run_tool()
    assert got["checkpoint_gap_count"] == exp["checkpoint_gap_count"]


def test_ooo_part_ordering_violation_matches_replay() -> None:
    """Out-of-order pack should count partition offset regressions."""
    _swap("ooo_part_b")
    exp = _expected_from_fixture("ooo_part_b")
    got = _run_tool()
    assert got["ordering_violation_count"] == exp["ordering_violation_count"]


def test_long_ret_stale_events_match_replay() -> None:
    """Long retention pack should count events outside the retention window."""
    _swap("long_ret_c")
    exp = _expected_from_fixture("long_ret_c")
    got = _run_tool()
    assert got["retention_stale_count"] == exp["retention_stale_count"]
    assert got["unique_tx_count"] == exp["unique_tx_count"]


def test_legacy_v1_emit_matches_replay() -> None:
    """Legacy v1 pack should emit on the backward-compatible consumer path."""
    _swap("legacy_v1_d")
    exp = _expected_from_fixture("legacy_v1_d")
    got = _run_tool()
    assert got["legacy_emit_count"] == exp["legacy_emit_count"]


def test_alpha_event_count_matches_replay() -> None:
    """Alpha pack event_count should match ingest rows."""
    _swap("run_alpha")
    exp = _expected_from_fixture("run_alpha")
    got = _run_tool()
    assert got["event_count"] == exp["event_count"]


def test_go_subsystem_tests_pass() -> None:
    """Go tests under /app must pass after the repair."""
    subprocess.run(
        [
            GO_BIN,
            "test",
            "./pkg/seqfold",
            "./pkg/keygate",
            "./pkg/bandorder",
            "./pkg/windowlane",
            "./pkg/v1wrap",
        ],
        cwd="/app",
        env={
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        },
        check=True,
    )
