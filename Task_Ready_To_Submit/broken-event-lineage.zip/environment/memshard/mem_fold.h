#ifndef MS_MEM_FOLD_H
#define MS_MEM_FOLD_H

int ms_mem_fold(int base, int delta);

#endif
