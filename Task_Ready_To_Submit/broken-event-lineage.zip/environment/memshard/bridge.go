package memshard

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libmemshard.a -ldl -lm
#include "mem_fold.h"
*/
import "C"

// Fold adjusts amount accounting through the native helper.
func Fold(base, delta int) int {
	return int(C.ms_mem_fold(C.int(base), C.int(delta)))
}
