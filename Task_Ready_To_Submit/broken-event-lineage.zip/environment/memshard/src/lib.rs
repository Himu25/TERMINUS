pub fn accFold(base: i32, delta: i32) -> i32 {
    base - delta
}

#[no_mangle]
pub extern "C" fn ms_mem_fold(base: i32, delta: i32) -> i32 {
    accFold(base, delta)
}
