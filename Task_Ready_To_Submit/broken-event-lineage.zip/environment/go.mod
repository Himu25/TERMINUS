module lab.local/broken_event_lineage

go 1.22
