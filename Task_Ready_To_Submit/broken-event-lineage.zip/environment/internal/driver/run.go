package driver

import (
	"encoding/json"
	"os"

	"lab.local/broken_event_lineage/internal/config"
	"lab.local/broken_event_lineage/internal/engine"
	"lab.local/broken_event_lineage/pkg/digest"
)

// Report is the JSON shape written to /app/output/lineage_audit.json.
type Report struct {
	SchemaVersion          string `json:"schema_version"`
	RunID                  string `json:"run_id"`
	EventCount             int    `json:"event_count"`
	UniqueTxCount          int    `json:"unique_tx_count"`
	DuplicateCount         int    `json:"duplicate_count"`
	OrderingViolationCount int    `json:"ordering_violation_count"`
	CheckpointGapCount     int    `json:"checkpoint_gap_count"`
	LegacyEmitCount        int    `json:"legacy_emit_count"`
	RetentionStaleCount    int    `json:"retention_stale_count"`
	AmountTotalCents       int    `json:"amount_total_cents"`
	DigestHex              string `json:"digest_hex"`
}

// RunActive loads the active pack and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	bundle, rows, err := config.LoadBundle(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.ExecRows(bundle, rows)
	digestHex := digest.FoldReport(
		bundle.RunID,
		itoa(out.EventCount),
		itoa(out.UniqueTxCount),
		itoa(out.DuplicateCount),
		itoa(out.OrderingViolationCount),
		itoa(out.CheckpointGapCount),
		itoa(out.LegacyEmitCount),
		itoa(out.RetentionStaleCount),
		itoa(out.AmountTotalCents),
	)
	return Report{
		SchemaVersion:          "1",
		RunID:                  bundle.RunID,
		EventCount:             out.EventCount,
		UniqueTxCount:          out.UniqueTxCount,
		DuplicateCount:         out.DuplicateCount,
		OrderingViolationCount: out.OrderingViolationCount,
		CheckpointGapCount:     out.CheckpointGapCount,
		LegacyEmitCount:        out.LegacyEmitCount,
		RetentionStaleCount:    out.RetentionStaleCount,
		AmountTotalCents:       out.AmountTotalCents,
		DigestHex:              digestHex,
	}, nil
}

// EmitReport writes rep to path as compact JSON.
func EmitReport(path string, rep Report) error {
	if err := os.MkdirAll("/app/output", 0o755); err != nil {
		return err
	}
	raw, err := json.Marshal(rep)
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func itoa(v int) string {
	if v == 0 {
		return "0"
	}
	var buf [16]byte
	i := len(buf)
	n := v
	neg := false
	if n < 0 {
		neg = true
		n = -n
	}
	for n > 0 {
		i--
		buf[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		buf[i] = '-'
	}
	return string(buf[i:])
}
