package engine

import (
	"lab.local/broken_event_lineage/memshard"
	"lab.local/broken_event_lineage/pkg/bandorder"
	"lab.local/broken_event_lineage/pkg/keygate"
	"lab.local/broken_event_lineage/pkg/seqfold"
	"lab.local/broken_event_lineage/pkg/v1wrap"
	"lab.local/broken_event_lineage/pkg/windowlane"
)

func foldKey(key string, wave int) string {
	return seqfold.OpF(key, wave)
}

func entryOk(storedGen, liveGen int) bool {
	return keygate.OpG(liveGen, storedGen)
}

func orderOk(currentOffset, lastOffset int) bool {
	return bandorder.OpB(lastOffset, currentOffset)
}

func seqLane(seq, window int) bool {
	return windowlane.OpW(seq, window)
}

func tallyAcc(base, delta int) int {
	return memshard.Fold(base, -delta)
}

func affixGate(prefix, key string, storedGen, liveGen int) bool {
	return v1wrap.OpV(prefix, key, storedGen, liveGen)
}
