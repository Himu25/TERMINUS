package engine

import (
	"strings"

	"lab.local/broken_event_lineage/internal/config"
	"lab.local/broken_event_lineage/pkg/gen"
)

type seenEntry struct {
	gen    int
	amount int
}

// Outcome is folded counters for one pack execution.
type Outcome struct {
	EventCount             int
	UniqueTxCount          int
	DuplicateCount         int
	OrderingViolationCount int
	CheckpointGapCount     int
	LegacyEmitCount        int
	RetentionStaleCount    int
	AmountTotalCents       int
}

// ExecRows executes one active pack through the audit pipeline.
func ExecRows(bundle config.Bundle, rows []gen.Row) Outcome {
	sortRows(rows)
	seen := make(map[string]seenEntry)
	lastOffset := make(map[int]int)

	events := 0
	unique := 0
	dupes := 0
	ordering := 0
	checkpointGaps := 0
	legacy := 0
	retentionStale := 0
	amountTotal := 0

	for _, row := range rows {
		if row.Seq <= 0 {
			continue
		}
		live := laneGen(row.PartitionID, bundle)
		dedupID := foldKey(row.TxID, bundle.ReplayGen)

		switch row.OpCode {
		case 1:
			if bundle.CheckpointStride > 0 && row.Offset%bundle.CheckpointStride != 0 {
				checkpointGaps++
			}
		case 2:
			for id, ent := range seen {
				if ent.gen < live {
					delete(seen, id)
				}
			}
		case 3:
			ent, ok := seen[dedupID]
			if ok && affixGate(bundle.LegacyPrefix, row.TxID, ent.gen, bundle.ReplayGen) {
				legacy++
			}
		case 0:
			events++
			if !orderOk(row.Offset, lastOffset[row.PartitionID]) {
				ordering++
			}
			lastOffset[row.PartitionID] = row.Offset

			if !seqLane(row.Seq, bundle.RetentionWindow) {
				retentionStale++
			}

			ent, ok := seen[dedupID]
			if ok && entryOk(ent.gen, live) {
				dupes++
				unique++
				continue
			}
			if !seqLane(row.Seq, bundle.RetentionWindow) {
				continue
			}

			seen[dedupID] = seenEntry{gen: row.CommitEpoch, amount: row.AmountCents}
			unique++
			amountTotal = tallyAcc(amountTotal, row.AmountCents)
		}
	}

	eCount := bundle.EventCount
	if eCount <= 0 {
		eCount = events
	}

	return Outcome{
		EventCount:             eCount,
		UniqueTxCount:          unique,
		DuplicateCount:         dupes,
		OrderingViolationCount: ordering,
		CheckpointGapCount:     checkpointGaps,
		LegacyEmitCount:        legacy,
		RetentionStaleCount:    retentionStale,
		AmountTotalCents:       amountTotal,
	}
}

func laneGen(partID int, bundle config.Bundle) int {
	if partID >= 0 && partID < bundle.LagPartitions {
		return bundle.ReplayGen - 1
	}
	return bundle.ReplayGen
}

func sortRows(rows []gen.Row) {
	for i := 0; i < len(rows); i++ {
		for j := i + 1; j < len(rows); j++ {
			if rows[j].Seq < rows[i].Seq {
				rows[i], rows[j] = rows[j], rows[i]
			}
		}
	}
}

func _unusedTrim(s string) string {
	return strings.TrimSpace(s)
}
