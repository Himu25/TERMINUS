package config

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"lab.local/broken_event_lineage/pkg/gen"
)

// Bundle describes one event replay pack.
type Bundle struct {
	RunID            string `json:"run_id"`
	EventCount       int    `json:"event_count"`
	ReplayGen        int    `json:"replay_gen"`
	PartitionCount   int    `json:"partition_count"`
	RetentionWindow  int    `json:"retention_window"`
	CheckpointStride int    `json:"checkpoint_stride"`
	LegacyPrefix     string `json:"legacy_prefix"`
	LagPartitions    int    `json:"lag_partitions"`
}

// ActivePaths returns the active pack directory under appRoot.
func ActivePaths(appRoot string) (string, error) {
	dir := filepath.Join(appRoot, "data", "active", "run_alpha")
	if st, err := os.Stat(dir); err != nil || !st.IsDir() {
		return "", fmt.Errorf("active pack missing: %s", dir)
	}
	return dir, nil
}

// LoadBundle reads event_bundle.json and events.jsonl from dir.
func LoadBundle(dir string) (Bundle, []gen.Row, error) {
	raw, err := os.ReadFile(filepath.Join(dir, "event_bundle.json"))
	if err != nil {
		return Bundle{}, nil, err
	}
	var bundle Bundle
	if err := json.Unmarshal(raw, &bundle); err != nil {
		return Bundle{}, nil, err
	}
	lines, err := os.ReadFile(filepath.Join(dir, "events.jsonl"))
	if err != nil {
		return Bundle{}, nil, err
	}
	var rows []gen.Row
	for _, line := range splitLines(string(lines)) {
		if line == "" {
			continue
		}
		var row gen.Row
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return Bundle{}, nil, err
		}
		rows = append(rows, row)
	}
	return bundle, rows, nil
}

func splitLines(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			out = append(out, s[start:i])
			start = i + 1
		}
	}
	if start < len(s) {
		out = append(out, s[start:])
	}
	return out
}
