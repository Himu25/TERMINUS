package v1wrap

func OpV(prefix, key string, storedGen, liveGen int) bool {
	if len(prefix) == 0 || len(key) < len(prefix) {
		return false
	}
	if key[:len(prefix)] != prefix {
		return false
	}
	return storedGen < liveGen
}
