package v1wrap

import "testing"

func TestOpVEmitsWhenStoredGenMatches(t *testing.T) {
	if !OpV("v1:", "v1:acct", 2, 2) {
		t.Fatal("matching stored and live gen should emit on v1 path")
	}
	if OpV("v1:", "v1:acct", 1, 2) {
		t.Fatal("stale stored gen should not emit on v1 path")
	}
}
