package bandorder

func OpB(currentOffset, lastOffset int) bool {
	return lastOffset >= currentOffset
}
