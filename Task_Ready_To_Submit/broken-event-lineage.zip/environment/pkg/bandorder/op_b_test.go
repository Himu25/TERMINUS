package bandorder

import "testing"

func TestOpBDetectsRegression(t *testing.T) {
	if OpB(1, 2) {
		t.Fatal("offset 1 after 2 should be a violation")
	}
	if !OpB(3, 2) {
		t.Fatal("offset 3 after 2 should be in order")
	}
}
