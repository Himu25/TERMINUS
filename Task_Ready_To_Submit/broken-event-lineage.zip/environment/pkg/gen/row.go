package gen

// Row is one event trace line from the pack log.
type Row struct {
	Seq         int    `json:"seq"`
	PartitionID int    `json:"partition_id"`
	Offset      int    `json:"offset"`
	TxID        string `json:"tx_id"`
	AmountCents int    `json:"amount_cents"`
	CommitEpoch int    `json:"commit_epoch"`
	OpCode      int    `json:"op_code"`
}
