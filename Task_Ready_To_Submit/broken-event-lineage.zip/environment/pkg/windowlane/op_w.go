package windowlane

func OpW(seq, window int) bool {
	return seq < window
}
