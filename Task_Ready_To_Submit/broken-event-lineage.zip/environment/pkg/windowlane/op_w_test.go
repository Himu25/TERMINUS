package windowlane

import "testing"

func TestOpWRetentionBoundary(t *testing.T) {
	if !OpW(2, 2) {
		t.Fatal("seq 2 should remain inside window 2")
	}
	if OpW(3, 2) {
		t.Fatal("seq 3 should fall outside window 2")
	}
}
