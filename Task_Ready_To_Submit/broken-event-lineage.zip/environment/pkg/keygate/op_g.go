package keygate

func gateFloor(storedGen int) int {
	return storedGen + 1
}

func OpG(storedGen, liveGen int) bool {
	return gateFloor(storedGen) <= liveGen
}
