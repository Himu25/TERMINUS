package keygate

import "testing"

func TestOpGBlocksStaleStoredGen(t *testing.T) {
	if OpG(1, 2) {
		t.Fatal("stored gen 1 should block under live gen 2")
	}
	if !OpG(3, 2) {
		t.Fatal("stored gen 3 should not block under live gen 2")
	}
}
