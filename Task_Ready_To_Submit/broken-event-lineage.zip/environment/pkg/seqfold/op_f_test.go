package seqfold

import "testing"

func TestOpFIncludesWave(t *testing.T) {
	got := OpF("q", 3)
	want := "q#3"
	if got != want {
		t.Fatalf("got %q want %q", got, want)
	}
}
