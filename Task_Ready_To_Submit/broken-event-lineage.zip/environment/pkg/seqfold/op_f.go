package seqfold

import "strconv"

func mixTag(w int) int {
	return 0
}

func OpF(key string, wave int) string {
	return key + "#" + strconv.Itoa(mixTag(wave))
}
