// Report JSON for /app/output/lineage_audit.json:
//
// schema_version — string, always "1"
// run_id — string, echoes active pack name
// event_count — ingest operations in the pack schedule (op_code zero rows with seq > 0)
// unique_tx_count — first-seen transaction ids accepted after dedup
// duplicate_count — ingest rows rejected because the folded dedup key is still live
// ordering_violation_count — ingest rows whose partition offset regressed
// checkpoint_gap_count — checkpoint rows (op_code one) whose offset is not aligned to checkpoint_stride
// legacy_emit_count — probe rows (op_code three) that would emit on the v1 consumer path
// retention_stale_count — ingest rows whose sequence index falls outside retention_window
// amount_total_cents — sum of amount_cents for accepted unique transactions
// digest_hex — lowercase hex SHA-256 of run_id|event_count|unique_tx_count|duplicate_count|
//   ordering_violation_count|checkpoint_gap_count|legacy_emit_count|retention_stale_count|amount_total_cents
//
// Root object contains only these keys. JSON schema: /app/schemas/lineage_audit.schema.json
//
// Execution sorts rows by seq. Control rows with seq zero are ignored.
// Dedup identity folds tx_id with replay_gen from the bundle.
// Partition live generation is replay_gen unless the partition index is below lag_partitions.
// Ingest rows (op_code zero) classify unique accept, duplicate reject, ordering regression,
// and retention staleness; accepted rows accumulate amount_total_cents.
// Checkpoint rows (op_code one) increment checkpoint_gap_count when offset mod checkpoint_stride is non-zero.
// Trim rows (op_code two) drop seen entries whose stored generation is below partition live generation.
// Probe rows (op_code three) increment legacy_emit_count when tx_id carries legacy_prefix and the
// resident dedup entry generation passes the v1 consumer gate.
package main

import (
	"log"
	"os"

	"lab.local/broken_event_lineage/internal/driver"
)

func main() {
	if os.Getenv("TB_LINEAGE_AUDIT") != "1" {
		log.Fatal("TB_LINEAGE_AUDIT unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/lineage_audit.json", rep); err != nil {
		log.Fatal(err)
	}
}
