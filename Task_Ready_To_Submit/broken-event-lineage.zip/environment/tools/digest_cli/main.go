package main

import (
	"fmt"
	"os"

	"lab.local/broken_event_lineage/pkg/digest"
)

func main() {
	if len(os.Args) != 10 {
		fmt.Fprintln(os.Stderr, "usage: digest_cli run_id event unique dup order checkpoint legacy retention amount")
		os.Exit(2)
	}
	fmt.Println(digest.FoldReport(os.Args[1], os.Args[2], os.Args[3], os.Args[4], os.Args[5], os.Args[6], os.Args[7], os.Args[8], os.Args[9]))
}
