"""Reference digest fold matching pkg/digest.FoldReport semantics."""

import hashlib


def fold_report(run_id: str, *fields: str) -> str:
    payload = run_id + "|" + "|".join(fields)
    return hashlib.sha256(payload.encode()).hexdigest()
