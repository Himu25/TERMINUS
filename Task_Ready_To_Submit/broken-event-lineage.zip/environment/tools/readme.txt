Verifier helpers include /tmp/cache_audit_verify_bin and /app/tools/digest_cli for digest recomputation.
Package tests invoke /usr/local/go/bin/go with PATH prefixed by /usr/local/cargo/bin for CGO builds.
