#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

write_op_f() {
  cat > /app/pkg/seqfold/op_f.go <<'EOF'
package seqfold

import "strconv"

func OpF(key string, wave int) string {
	return key + "#" + strconv.Itoa(wave)
}
EOF
}

write_op_g() {
  cat > /app/pkg/keygate/op_g.go <<'EOF'
package keygate

func OpG(storedGen, liveGen int) bool {
	return storedGen >= liveGen
}
EOF
}

write_op_b() {
  cat > /app/pkg/bandorder/op_b.go <<'EOF'
package bandorder

func OpB(currentOffset, lastOffset int) bool {
	return currentOffset >= lastOffset
}
EOF
}

write_op_w() {
  cat > /app/pkg/windowlane/op_w.go <<'EOF'
package windowlane

func OpW(seq, window int) bool {
	return seq <= window
}
EOF
}

write_op_v() {
  cat > /app/pkg/v1wrap/op_v.go <<'EOF'
package v1wrap

func OpV(prefix, key string, storedGen, liveGen int) bool {
	if len(prefix) == 0 || len(key) < len(prefix) {
		return false
	}
	if key[:len(prefix)] != prefix {
		return false
	}
	return storedGen >= liveGen
}
EOF
}

write_memshard() {
  cat > /app/memshard/src/lib.rs <<'EOF'
pub fn accFold(base: i32, delta: i32) -> i32 {
    base + delta
}

#[no_mangle]
pub extern "C" fn ms_mem_fold(base: i32, delta: i32) -> i32 {
    accFold(base, delta)
}
EOF
}

write_op_f
write_op_g
write_op_b
write_op_w
write_op_v
write_memshard

sed -i 's/keygate.OpG(liveGen, storedGen)/keygate.OpG(storedGen, liveGen)/' /app/internal/engine/fold_bridge.go
sed -i 's/bandorder.OpB(lastOffset, currentOffset)/bandorder.OpB(currentOffset, lastOffset)/' /app/internal/engine/fold_bridge.go
sed -i 's/memshard.Fold(base, -delta)/memshard.Fold(base, delta)/' /app/internal/engine/fold_bridge.go
sed -i 's/ent.gen, bundle.ReplayGen)/ent.gen, live)/' /app/internal/engine/pipeline.go
sed -i '/dupes++/{n;/unique++/d;}' /app/internal/engine/pipeline.go

bash /app/scripts/build.sh

GOFLAGS=-mod=mod CGO_ENABLED=1 go test \
  ./pkg/seqfold ./pkg/keygate ./pkg/bandorder ./pkg/windowlane ./pkg/v1wrap -count=1

rm -f /app/output/lineage_audit.json
TB_LINEAGE_AUDIT=1 /app/bin/stream_audit
test -s /app/output/lineage_audit.json
