"""Verifier for IVF retention regression bench."""

from __future__ import annotations

import json
import os
import subprocess
import tempfile
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "regression_bench.json"
CFG = APP / "config" / "regression.toml"
CORPUS = APP / "data" / "corpus.json"
QUERIES = APP / "data" / "queries_default.jsonl"
NEIGHBORS = APP / "data" / "neighbor_topk.json"
ROUNDTRIP_SNAP = APP / "output" / "roundtrip_snap.bin"
CORRUPT_SNAP = APP / "output" / "corrupt_snap.bin"
STRESS_SNAP = APP / "output" / "stress_snap.bin"

REPORT_KEYS = frozenset(
    {
        "status",
        "vector_dim",
        "corpus_vectors",
        "queries_total",
        "mean_recall_at_10",
        "roundtrip_recall_at_10",
        "concurrent_ghost_hits",
        "corrupt_load_rejects",
        "layout_tag_ok",
        "mean_ivf_probes",
        "max_heap_evictions",
        "snapshot_bytes",
        "report_digest",
        "queries",
    }
)
QUERY_KEYS = frozenset({"query_id", "recall_at_10", "ivf_probes", "neighbor_hits"})

RECALL_FLOOR = 0.85
ROUNDTRIP_FLOOR = 0.85
IVF_PROBES_MIN = 8.0
GHOST_MAX = 0
CORRUPT_MIN = 1
LAYOUT_OK = 1
HEAP_MAX = 32
SNAP_MAX = 120000

MAGIC = b"IVF2"
FOOTER = b"END!"
STRESS_ROUNDS = 8


class SnapshotError(Exception):
    """Independent snapshot loader failure."""


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "recall_floor": RECALL_FLOOR,
        "roundtrip_recall_floor": ROUNDTRIP_FLOOR,
        "mean_ivf_probes_min": int(IVF_PROBES_MIN),
        "max_concurrent_ghost_hits": GHOST_MAX,
        "min_corrupt_load_rejects": CORRUPT_MIN,
        "max_heap_evictions": HEAP_MAX,
        "max_snapshot_bytes": SNAP_MAX,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in (
            "recall_floor",
            "roundtrip_recall_floor",
            "mean_ivf_probes_min",
        ):
            cfg[key] = float(val)
        elif key in (
            "max_concurrent_ghost_hits",
            "min_corrupt_load_rejects",
            "max_heap_evictions",
            "max_snapshot_bytes",
        ):
            cfg[key] = int(float(val))
    return cfg


def _round4(value: float) -> float:
    return round(value * 10000 + 0.5) / 10000


def _squared_distance(a: list[float], b: list[float]) -> float:
    return sum((float(x) - float(y)) ** 2 for x, y in zip(a, b))


def _load_corpus_vectors() -> tuple[int, int, int, list[list[float]]]:
    doc = json.loads(CORPUS.read_text(encoding="utf-8"))
    dim = int(doc["dim"])
    nlist = int(doc["nlist"])
    nprobe = int(doc["nprobe"])
    vectors = [[float(x) for x in row] for row in doc["vectors"]]
    return dim, nlist, nprobe, vectors


def _nearest_centroid(row: list[float], centroids: list[list[float]]) -> int:
    best = 0
    best_d = float("inf")
    for idx, centroid in enumerate(centroids):
        dist = _squared_distance(row, centroid)
        if dist < best_d:
            best_d = dist
            best = idx
    return best


def _build_ivf_index(
    vectors: list[list[float]], nlist: int, nprobe: int
) -> tuple[list[list[float]], list[list[int]]]:
    if not vectors:
        dim = 0
        return [[] for _ in range(nlist)], [[] for _ in range(nlist)]
    dim = len(vectors[0])
    centroids = [[0.0] * dim for _ in range(nlist)]
    counts = [0] * nlist
    for idx, row in enumerate(vectors):
        lane = idx % nlist
        counts[lane] += 1
        for slot, value in enumerate(row):
            centroids[lane][slot] += value
    for lane in range(nlist):
        denom = max(counts[lane], 1)
        centroids[lane] = [value / denom for value in centroids[lane]]
    lists: list[list[int]] = [[] for _ in range(nlist)]
    for idx, row in enumerate(vectors):
        lane = _nearest_centroid(row, centroids)
        lists[lane].append(idx)
    _ = nprobe
    return centroids, lists


def _probe_lists(
    centroids: list[list[float]],
    lists: list[list[int]],
    query: list[float],
    nlist: int,
    nprobe: int,
) -> tuple[int, list[int]]:
    scored = [
        (idx, _squared_distance(query, centroid))
        for idx, centroid in enumerate(centroids)
    ]
    scored.sort(key=lambda pair: pair[1])
    take = min(nprobe, nlist)
    lanes = [lane for lane, _ in scored[:take]]
    ids: list[int] = []
    for lane in lanes:
        ids.extend(lists[lane])
    return take, ids


def _search_topk(
    vectors: list[list[float]],
    centroids: list[list[float]],
    lists: list[list[int]],
    query: list[float],
    nlist: int,
    nprobe: int,
    k: int = 10,
) -> tuple[int, list[int]]:
    probes, candidates = _probe_lists(centroids, lists, query, nlist, nprobe)
    scored = [
        (vid, _squared_distance(query, vectors[vid]))
        for vid in candidates
        if vid < len(vectors)
    ]
    scored.sort(key=lambda pair: pair[1])
    return probes, [vid for vid, _ in scored[:k]]


def _recall_at_k(
    vectors: list[list[float]],
    centroids: list[list[float]],
    lists: list[list[int]],
    query: list[float],
    want_ids: list[int],
    nlist: int,
    nprobe: int,
    k: int = 10,
) -> float:
    _, got = _search_topk(vectors, centroids, lists, query, nlist, nprobe, k)
    hits = len(set(want_ids).intersection(got))
    return hits / max(len(want_ids), 1)


def _snapshot_bundle(
    dim: int,
    nlist: int,
    nprobe: int,
    vectors: list[list[float]],
    centroids: list[list[float]],
    lists: list[list[int]],
) -> dict[str, object]:
    return {
        "dim": dim,
        "nlist": nlist,
        "nprobe": nprobe,
        "vector_count": len(vectors),
        "centroids": centroids,
        "lists": lists,
        "vectors": vectors,
    }


def _sha256_bytes(data: bytes) -> bytes:
    proc = subprocess.run(
        ["sha256sum"],
        input=data,
        capture_output=True,
        check=True,
    )
    return bytes.fromhex(proc.stdout.split()[0].decode("ascii"))


def _pack_u32(value: int) -> bytes:
    return int(value).to_bytes(4, "little", signed=False)


def _unpack_u32(data: bytes, offset: int) -> int:
    return int.from_bytes(data[offset : offset + 4], "little", signed=False)


def _pack_f32(value: float) -> bytes:
    struct = __import__("struct")
    return struct.pack("<f", float(value))


def _unpack_f32(data: bytes, offset: int) -> float:
    struct = __import__("struct")
    return struct.unpack("<f", data[offset : offset + 4])[0]


def _serialize_snapshot_bytes(bundle: dict[str, object]) -> bytes:
    dim = int(bundle["dim"])
    nlist = int(bundle["nlist"])
    nprobe = int(bundle["nprobe"])
    vector_count = int(bundle["vector_count"])
    centroids = bundle["centroids"]
    lists = bundle["lists"]
    vectors = bundle["vectors"]
    body = bytearray()
    body.extend(MAGIC)
    for word in (dim, nlist, nprobe, vector_count):
        body.extend(_pack_u32(word))
    for centroid in centroids:
        for value in centroid:
            body.extend(_pack_f32(float(value)))
    for lane in lists:
        body.extend(_pack_u32(len(lane)))
        for vid in lane:
            body.extend(_pack_u32(int(vid)))
    for row in vectors:
        for value in row:
            body.extend(_pack_f32(float(value)))
    digest = _sha256_bytes(bytes(body))
    body.extend(digest)
    body.extend(FOOTER)
    return bytes(body)


def _load_snapshot_bytes(data: bytes) -> dict[str, object]:
    if len(data) < 68:
        raise SnapshotError("truncated")
    if data[:4] != MAGIC:
        raise SnapshotError("bad magic")
    if data[-4:] != FOOTER:
        raise SnapshotError("bad footer")
    digest_off = len(data) - 36
    expect = _sha256_bytes(data[:digest_off])
    on_disk = data[digest_off : digest_off + 32]
    if on_disk != expect:
        raise SnapshotError("checksum")
    dim = _unpack_u32(data, 4)
    nlist = _unpack_u32(data, 8)
    nprobe = _unpack_u32(data, 12)
    vector_count = _unpack_u32(data, 16)
    offset = 20
    centroids: list[list[float]] = []
    for _ in range(nlist):
        row = [_unpack_f32(data, offset + slot * 4) for slot in range(dim)]
        offset += dim * 4
        centroids.append(row)
    lists: list[list[int]] = []
    for _ in range(nlist):
        length = _unpack_u32(data, offset)
        offset += 4
        ids = [_unpack_u32(data, offset + slot * 4) for slot in range(length)]
        offset += length * 4
        lists.append(ids)
    vectors: list[list[float]] = []
    for _ in range(vector_count):
        row = [_unpack_f32(data, offset + slot * 4) for slot in range(dim)]
        offset += dim * 4
        vectors.append(row)
    return _snapshot_bundle(dim, nlist, nprobe, vectors, centroids, lists)


def _load_snapshot_file(path: Path) -> dict[str, object]:
    return _load_snapshot_bytes(path.read_bytes())


def _first_query() -> tuple[str, list[float]]:
    for line in QUERIES.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        doc = json.loads(line)
        return doc["query_id"], [float(x) for x in doc["vector"]]
    pytest.fail("missing query rows")


def _independent_roundtrip_recall() -> float:
    """Serialize corpus state, reload, and measure recall without the report JSON."""
    dim, nlist, nprobe, vectors = _load_corpus_vectors()
    centroids, lists = _build_ivf_index(vectors, nlist, nprobe)
    bundle = _snapshot_bundle(dim, nlist, nprobe, vectors, centroids, lists)
    raw = _serialize_snapshot_bytes(bundle)
    with tempfile.NamedTemporaryFile(suffix=".bin", delete=False) as handle:
        temp_path = Path(handle.name)
        handle.write(raw)
    try:
        loaded = _load_snapshot_bytes(temp_path.read_bytes())
    finally:
        temp_path.unlink(missing_ok=True)
    qid, qvec = _first_query()
    labels = json.loads(NEIGHBORS.read_text(encoding="utf-8"))
    want_ids = [int(x) for x in labels[qid]]
    recall = _recall_at_k(
        loaded["vectors"],
        loaded["centroids"],
        loaded["lists"],
        qvec,
        want_ids,
        int(loaded["nlist"]),
        int(loaded["nprobe"]),
    )
    return _round4(recall)


def _corrupt_snapshot_bytes(good: bytes) -> bytes:
    corrupt = bytearray(good)
    if len(corrupt) > 40:
        corrupt[16] = (corrupt[16] + 3) & 0xFF
    return bytes(corrupt)


def _independent_corrupt_load_rejects() -> bool:
    """Tamper with serialized bytes and confirm the independent loader rejects them."""
    dim, nlist, nprobe, vectors = _load_corpus_vectors()
    centroids, lists = _build_ivf_index(vectors, nlist, nprobe)
    bundle = _snapshot_bundle(dim, nlist, nprobe, vectors, centroids, lists)
    good = _serialize_snapshot_bytes(bundle)
    corrupt = _corrupt_snapshot_bytes(good)
    try:
        _load_snapshot_bytes(corrupt)
    except SnapshotError:
        return True
    return False


def _ghost_ids_in_bundle(bundle: dict[str, object]) -> int:
    max_id = int(bundle["vector_count"])
    ghosts = 0
    for lane in bundle["lists"]:
        for vid in lane:
            if int(vid) >= max_id:
                ghosts += 1
    return ghosts


def _independent_concurrent_ghost_hits() -> int:
    """Replay ingest/probe stress rounds and count out-of-range neighbor ids."""
    dim, nlist, nprobe, seed_vectors = _load_corpus_vectors()
    vectors = [row[:] for row in seed_vectors]
    centroids, lists = _build_ivf_index(vectors, nlist, nprobe)
    query = [0.1] * dim
    ghosts = 0
    for tick in range(STRESS_ROUNDS):
        vectors.extend([[0.01 * tick] * dim])
        max_id = len(vectors)
        centroids, lists = _build_ivf_index(vectors, nlist, nprobe)
        _, ids = _probe_lists(centroids, lists, query, nlist, nprobe)
        for vid in ids:
            if vid >= max_id:
                ghosts += 1
    return ghosts


def _brute_mean_recall() -> float:
    """Independent recall estimate from corpus + neighbor labels (not the bench binary)."""
    corpus = json.loads(CORPUS.read_text(encoding="utf-8"))
    vectors = corpus["vectors"]
    labels = json.loads(NEIGHBORS.read_text(encoding="utf-8"))
    total = 0.0
    count = 0
    for line in QUERIES.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        doc = json.loads(line)
        qid = doc["query_id"]
        qvec = [float(x) for x in doc["vector"]]
        expected = set(labels[qid])
        scored = []
        for idx, row in enumerate(vectors):
            dist = sum((float(a) - float(b)) ** 2 for a, b in zip(qvec, row))
            scored.append((dist, idx))
        scored.sort(key=lambda pair: pair[0])
        got = {idx for _, idx in scored[:10]}
        hits = len(expected.intersection(got))
        total += hits / max(len(expected), 1)
        count += 1
    return _round4(total / max(count, 1))


def _digest_payload(report: dict) -> dict:
    clone = dict(report)
    clone["report_digest"] = ""
    return clone


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _load_report() -> dict:
    assert OUT.is_file(), "missing regression bench report"
    return json.loads(OUT.read_text(encoding="utf-8"))


@pytest.fixture(scope="module")
def cfg() -> dict[str, float | int]:
    return _parse_cfg()


def _rebuild_retain_bench() -> None:
    subprocess.run(
        ["cargo", "build", "--release", "--manifest-path", "/app/Cargo.toml"],
        cwd=APP,
        check=True,
        timeout=300,
        capture_output=True,
        text=True,
    )
    subprocess.run(
        ["install", "-m", "0755", "/app/target/release/retain-report", "/app/bin/retain-report"],
        check=True,
        capture_output=True,
        text=True,
    )


def _run_regression_bench() -> None:
    subprocess.run(
        ["/app/tools/emit_report.sh"],
        cwd=APP,
        check=True,
        timeout=120,
        capture_output=True,
        text=True,
        env=os.environ.copy(),
    )


@pytest.fixture(scope="session", autouse=True)
def _default_regression_bench() -> None:
    _rebuild_retain_bench()
    _run_regression_bench()


@pytest.fixture(scope="module")
def report() -> dict:
    return _load_report()


def test_report_schema(report: dict) -> None:
    """Report JSON must expose the documented top-level schema and types."""
    assert set(report) == REPORT_KEYS
    assert isinstance(report["status"], str) and report["status"]
    for key in ("vector_dim", "corpus_vectors", "queries_total", "snapshot_bytes"):
        assert isinstance(report[key], int)
        assert report[key] >= 0
    for key in (
        "mean_recall_at_10",
        "roundtrip_recall_at_10",
        "mean_ivf_probes",
    ):
        assert isinstance(report[key], (int, float))
        assert float(report[key]) >= 0.0
    assert isinstance(report["concurrent_ghost_hits"], int)
    assert isinstance(report["corrupt_load_rejects"], int)
    assert isinstance(report["layout_tag_ok"], int)
    assert isinstance(report["max_heap_evictions"], int)
    digest = report["report_digest"]
    assert isinstance(digest, str) and len(digest) == 64
    assert digest == digest.lower()


def test_queries_shape_and_line_count(report: dict) -> None:
    """Query rows must mirror the input JSONL line count and per-row keys."""
    lines = [ln for ln in QUERIES.read_text(encoding="utf-8").splitlines() if ln.strip()]
    assert report["queries_total"] == len(lines)
    assert len(report["queries"]) == len(lines)
    for row in report["queries"]:
        assert set(row) == QUERY_KEYS
        assert row["ivf_probes"] >= 0
        assert 0.0 <= float(row["recall_at_10"]) <= 1.0


def test_report_digest_matches_payload(report: dict) -> None:
    """Digest must be SHA-256 over the compact JSON payload with an empty digest field."""
    assert report["report_digest"] == _expected_digest(report)


def test_status_ok(report: dict) -> None:
    """Repaired bench runs must report status ok."""
    assert report["status"] == "ok"


def test_mean_recall_meets_floor(report: dict, cfg: dict[str, float | int]) -> None:
    """Mean recall@10 must clear regression.toml recall_floor."""
    floor = float(cfg["recall_floor"])
    assert float(report["mean_recall_at_10"]) >= floor
    assert float(report["mean_recall_at_10"]) >= RECALL_FLOOR
    brute = _brute_mean_recall()
    assert float(report["mean_recall_at_10"]) + 0.05 >= brute


def test_independent_roundtrip_serialize_reload_recall(cfg: dict[str, float | int]) -> None:
    """Verifier-owned serialize/load round-trip must preserve search recall."""
    floor = float(cfg["roundtrip_recall_floor"])
    independent = _independent_roundtrip_recall()
    assert independent >= floor
    assert independent >= ROUNDTRIP_FLOOR


def test_bench_roundtrip_snapshot_independently_loadable(cfg: dict[str, float | int]) -> None:
    """Bench-produced roundtrip bytes must reload under the independent snapshot parser."""
    assert ROUNDTRIP_SNAP.is_file(), "missing roundtrip snapshot from bench run"
    loaded = _load_snapshot_file(ROUNDTRIP_SNAP)
    assert len(loaded["vectors"]) == int(loaded["vector_count"])
    qid, qvec = _first_query()
    labels = json.loads(NEIGHBORS.read_text(encoding="utf-8"))
    want_ids = [int(x) for x in labels[qid]]
    recall = _recall_at_k(
        loaded["vectors"],
        loaded["centroids"],
        loaded["lists"],
        qvec,
        want_ids,
        int(loaded["nlist"]),
        int(loaded["nprobe"]),
    )
    floor = float(cfg["roundtrip_recall_floor"])
    assert _round4(recall) >= floor


def test_roundtrip_recall_matches_independent_measurement(
    report: dict, cfg: dict[str, float | int]
) -> None:
    """Reported round-trip recall must track the verifier-owned round-trip measurement."""
    independent = _independent_roundtrip_recall()
    floor = float(cfg["roundtrip_recall_floor"])
    reported = float(report["roundtrip_recall_at_10"])
    assert reported >= floor
    assert abs(reported - independent) <= 0.05


def test_ivf_probe_depth_preserved(report: dict, cfg: dict[str, float | int]) -> None:
    """IVF probe depth must stay at the configured nprobe budget on every query."""
    floor = float(cfg["mean_ivf_probes_min"])
    assert float(report["mean_ivf_probes"]) >= floor
    assert float(report["mean_ivf_probes"]) >= IVF_PROBES_MIN
    for row in report["queries"]:
        assert row["ivf_probes"] >= int(IVF_PROBES_MIN)


def test_independent_concurrent_stress_no_ghost_neighbors(cfg: dict[str, float | int]) -> None:
    """Concurrent ingest/probe stress must not observe out-of-range neighbor ids."""
    cap = int(cfg["max_concurrent_ghost_hits"])
    independent = _independent_concurrent_ghost_hits()
    assert independent <= cap


def test_stress_snapshot_lists_have_no_ghost_ids() -> None:
    """On-disk stress snapshots must not carry out-of-range IVF member ids."""
    assert STRESS_SNAP.is_file(), "missing stress snapshot from bench run"
    bundle = _load_snapshot_file(STRESS_SNAP)
    assert _ghost_ids_in_bundle(bundle) == 0


def test_concurrent_ghost_hits_consistent_with_independent_stress(
    report: dict, cfg: dict[str, float | int]
) -> None:
    """Reported ghost hits must agree with verifier-owned stress and snapshot integrity."""
    cap = int(cfg["max_concurrent_ghost_hits"])
    independent = _independent_concurrent_ghost_hits()
    snapshot_ghosts = _ghost_ids_in_bundle(_load_snapshot_file(STRESS_SNAP))
    reported = int(report["concurrent_ghost_hits"])
    assert independent <= cap
    assert reported <= cap
    assert snapshot_ghosts == 0
    if independent > 0 or snapshot_ghosts > 0:
        assert reported > 0
    else:
        assert reported == 0


def test_independent_corrupt_snapshot_bytes_rejected() -> None:
    """Purposefully corrupted snapshot bytes must fail the independent loader."""
    assert _independent_corrupt_load_rejects()


def test_bench_corrupt_snapshot_rejected_independently() -> None:
    """Bench-written corrupt fixture bytes must be rejected by the independent loader."""
    assert CORRUPT_SNAP.is_file(), "missing corrupt snapshot from bench run"
    with pytest.raises(SnapshotError):
        _load_snapshot_file(CORRUPT_SNAP)


def test_corrupt_load_rejects_match_independent_behavior(report: dict, cfg: dict[str, float | int]) -> None:
    """Reported corrupt rejections must reflect real loader failures, not a hardcoded counter."""
    need = int(cfg["min_corrupt_load_rejects"])
    assert _independent_corrupt_load_rejects()
    assert int(report["corrupt_load_rejects"]) >= need
    assert int(report["corrupt_load_rejects"]) >= CORRUPT_MIN


def test_layout_tag_ok(report: dict) -> None:
    """Report must acknowledge the le32 layout tag documented for nodes."""
    assert report["layout_tag_ok"] >= 1


def test_heap_evictions_within_cap(report: dict, cfg: dict[str, float | int]) -> None:
    """Candidate scan truncations must stay within the heap eviction ceiling."""
    cap = int(cfg["max_heap_evictions"])
    assert report["max_heap_evictions"] <= cap


def test_snapshot_size_within_cap(report: dict, cfg: dict[str, float | int]) -> None:
    """Serialized index footprint must fit under max_snapshot_bytes."""
    cap = int(cfg["max_snapshot_bytes"])
    assert report["snapshot_bytes"] <= cap
    assert report["snapshot_bytes"] > 0


def test_mean_recall_matches_rows(report: dict) -> None:
    """Root mean_recall_at_10 must equal the rounded mean of per-query recalls."""
    rows = report["queries"]
    if not rows:
        pytest.fail("empty query rows")
    mean = sum(float(r["recall_at_10"]) for r in rows) / len(rows)
    assert _round4(mean) == _round4(float(report["mean_recall_at_10"]))


def test_per_query_neighbor_hits_consistent(report: dict) -> None:
    """Per-query neighbor_hits cannot exceed the label list cardinality."""
    neighbor_map = json.loads(NEIGHBORS.read_text(encoding="utf-8"))
    for row in report["queries"]:
        labels = neighbor_map[row["query_id"]]
        assert row["neighbor_hits"] <= len(labels)
        assert row["neighbor_hits"] <= 10


def test_corpus_vector_dim_matches(report: dict) -> None:
    """Report vector_dim and corpus_vectors must match the bundled corpus.json."""
    doc = json.loads(CORPUS.read_text(encoding="utf-8"))
    assert report["vector_dim"] == int(doc["dim"])
    assert report["corpus_vectors"] == len(doc["vectors"])


def test_repeat_run_byte_identical() -> None:
    """Two consecutive bench runs on unchanged inputs must be byte-identical."""
    _run_regression_bench()
    first = OUT.read_bytes()
    _run_regression_bench()
    second = OUT.read_bytes()
    assert first == second


def test_runner_and_binary_exist() -> None:
    """Report wrapper and retain-report binary must exist after the agent rebuild."""
    assert Path("/app/tools/emit_report.sh").is_file()
    assert Path("/app/bin/retain-report").is_file()


def test_env_layout_tag_documented() -> None:
    """Layout registry and deploy notes must document ANN_SNAPSHOT_LAYOUT=le32."""
    layout = (APP / "registry" / "index_layout.json").read_text(encoding="utf-8")
    assert "le32" in layout
    hooks = (APP / "hooks" / "deploy_notes.txt").read_text(encoding="utf-8")
    assert "ANN_SNAPSHOT_LAYOUT" in hooks
