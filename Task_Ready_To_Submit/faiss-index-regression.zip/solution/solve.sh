#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight: IVF regression workspace"
require_file /app/Cargo.toml
require_file /app/src/retain_core/ivf.rs
require_file /app/src/persist/frame.rs
require_file /app/src/search/runner.rs
require_file /app/src/retain_core/store.rs
require_file /app/src/bench.rs
require_file /app/src/math/l2.rs
require_file /app/config/regression.toml
require_file "${ROOT_DIR}/patches/all.patch"
mkdir -p /app/bin /app/output

log "survey: guardrails and retention sources"
grep -nE 'recall|nprobe|ghost|roundtrip|snapshot' /app/config/regression.toml | head -n 14
wc -l /app/src/retain_core/ivf.rs /app/src/retain_core/store.rs /app/src/persist/frame.rs /app/src/search/runner.rs /app/src/bench.rs /app/src/math/l2.rs

log "apply consolidated regression repair patch"
patch -p0 -f < "${ROOT_DIR}/patches/all.patch"

log "rebuild retain-report and emit quality report"
cargo build --release --manifest-path /app/Cargo.toml
install -m 0755 /app/target/release/retain-report /app/bin/retain-report
bash /app/tools/emit_report.sh

log "sanity: repaired status and quality floors"
python3 - <<'PY'
import json
r = json.load(open("/app/output/regression_bench.json"))
assert r["status"] == "ok", r
assert r["mean_ivf_probes"] >= 8.0, r
assert r["roundtrip_recall_at_10"] >= 0.85, r
assert r["concurrent_ghost_hits"] == 0, r
assert r["corrupt_load_rejects"] >= 1, r
print("ok", r["mean_recall_at_10"], r["roundtrip_recall_at_10"], r["mean_ivf_probes"])
PY

log "done"
