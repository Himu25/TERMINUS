# Runbook

Rebuild after source edits:

```
cargo build --release --manifest-path /app/Cargo.toml
install -m 0755 /app/target/release/retain-report /app/bin/retain-report
```

Emit the default regression report:

```
/app/tools/emit_report.sh
```
