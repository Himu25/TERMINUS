# Historical regression notes

2024-03: recall drift reported after concurrent snapshot refresh in production search.

2024-06: snapshot reload failures on le32 deployment hosts after a layout rollout.

2024-09: intermittent acceptance of incomplete snapshot files following truncated writes.
