# IVF retain service

Rust IVF flat-index stack under `/app`. The quality driver is `/app/bin/retain-report` (subcommand `bench`). Wrapper `/app/tools/emit_report.sh` writes `/app/output/regression_bench.json`.

## Report schema

Top-level fields: `status`, `vector_dim`, `corpus_vectors`, `queries_total`, `mean_recall_at_10`, `roundtrip_recall_at_10`, `concurrent_ghost_hits`, `corrupt_load_rejects`, `layout_tag_ok`, `mean_ivf_probes`, `max_heap_evictions`, `snapshot_bytes`, `report_digest`, `queries`.

Each `queries` row: `query_id`, `recall_at_10`, `ivf_probes`, `neighbor_hits`.

`queries_total` equals non-empty lines in the query JSONL. `report_digest` is 64-char lowercase hex over compact JSON of all other fields with `report_digest` empty. Compute that digest from the same serialization you write to disk: serialize the report struct with `report_digest` cleared (for example via `serde_json::to_string` on the report type). Do not hash a `serde_json::Value` built from the struct, because that path reorders top-level keys alphabetically and produces a different digest than the on-disk report.

## Guardrails

Floors and ceilings are in `/app/config/regression.toml`. A passing default run has `status` `ok`, `mean_recall_at_10` at or above `recall_floor`, `roundtrip_recall_at_10` at or above `roundtrip_recall_floor`, `mean_ivf_probes` at or above `mean_ivf_probes_min`, `concurrent_ghost_hits` at or below `max_concurrent_ghost_hits`, `corrupt_load_rejects` at or above `min_corrupt_load_rejects`, `layout_tag_ok` equal to 1, `max_heap_evictions` at or below `max_heap_evictions`, and `snapshot_bytes` at or below `max_snapshot_bytes`.

Identical inputs must yield byte-identical output.

## Snapshot layout

Serialized indices use magic `IVF2` and footer `END!`. Container env `ANN_SNAPSHOT_LAYOUT=le32` documents the on-wire integer endianness for list metadata.

After the magic and header words, the body holds centroids, inverted lists, and vectors in le32 wire order. The file ends with a 32-byte SHA-256 digest of every byte from file start through the end of the vector payload (the digest and footer are excluded from the hash input), followed by the four-byte footer.

## Bench snapshot outputs

A default bench run writes three on-disk snapshot artifacts under `/app/output/` in addition to the JSON report:

- `roundtrip_snap.bin` — serialized corpus index used to measure `roundtrip_recall_at_10`; must reload cleanly.
- `stress_snap.bin` — snapshot captured during concurrent ingest stress; IVF member ids must stay in range.
- `corrupt_snap.bin` — intentionally damaged bytes derived from the round-trip snapshot; loaders must reject it.
