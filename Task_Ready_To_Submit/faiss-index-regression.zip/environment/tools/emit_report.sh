#!/bin/bash
set -euo pipefail
mkdir -p /app/output
exec /app/bin/retain-report bench \
  /app/data/corpus.json \
  /app/data/queries_default.jsonl \
  /app/data/neighbor_topk.json \
  /app/output/regression_bench.json
