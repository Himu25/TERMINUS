Helper scripts for local engineers; the bench driver is the supported entrypoint.
