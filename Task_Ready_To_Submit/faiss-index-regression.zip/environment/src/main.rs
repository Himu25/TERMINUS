use std::env;
use std::path::PathBuf;

use ivf_retain::run_bench;

fn main() {
    let mut args = env::args().skip(1);
    let mode = args.next().unwrap_or_else(|| "bench".into());
    match mode.as_str() {
        "bench" => {
            let corpus = PathBuf::from(args.next().unwrap_or_else(|| "/app/data/corpus.json".into()));
            let queries = PathBuf::from(args.next().unwrap_or_else(|| "/app/data/queries_default.jsonl".into()));
            let neighbors = PathBuf::from(args.next().unwrap_or_else(|| "/app/data/neighbor_topk.json".into()));
            let out = PathBuf::from(args.next().unwrap_or_else(|| "/app/output/regression_bench.json".into()));
            let report = run_bench(&corpus, &queries, &neighbors, &out);
            println!("{}", serde_json::to_string(&report).expect("json"));
        }
        _ => {
            eprintln!("usage: retain-report bench [corpus queries neighbors out]");
            std::process::exit(2);
        }
    }
}
