use sha2::{Digest, Sha256};

pub fn hash_prefix(bytes: &[u32]) -> [u8; 32] {
    let mut hasher = Sha256::new();
    for word in &bytes[..bytes.len().min(3)] {
        hasher.update(word.to_le_bytes());
    }
    hasher.finalize().into()
}

pub fn hash_payload(bytes: &[u8]) -> [u8; 32] {
    let mut hasher = Sha256::new();
    hasher.update(bytes);
    hasher.finalize().into()
}
