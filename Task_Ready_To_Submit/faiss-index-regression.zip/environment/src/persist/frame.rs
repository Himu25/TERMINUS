use std::fs;
use std::io::{Read, Write};
use std::path::Path;

use crate::persist::digest::{hash_payload, hash_prefix};

const MAGIC: &[u8; 4] = b"IVF2";
const FOOTER_TAG: &[u8; 4] = b"END!";
const HEADER_BYTES: usize = 32;

#[derive(Debug)]
pub enum SnapshotError {
    Truncated,
    BadMagic,
    BadFooter,
    Checksum,
    Layout,
}

pub struct SnapshotBundle {
    pub dim: u32,
    pub nlist: u32,
    pub nprobe: u32,
    pub vector_count: u32,
    pub centroids: Vec<Vec<f32>>,
    pub lists: Vec<Vec<u32>>,
    pub vectors: Vec<Vec<f32>>,
}

pub fn save_snapshot(path: &Path, bundle: &SnapshotBundle) -> std::io::Result<usize> {
    let mut body = Vec::new();
    body.extend_from_slice(MAGIC);
    body.extend_from_slice(&bundle.dim.to_le_bytes());
    body.extend_from_slice(&bundle.nlist.to_le_bytes());
    body.extend_from_slice(&bundle.nprobe.to_le_bytes());
    body.extend_from_slice(&(bundle.vector_count as u32).to_le_bytes());
    for c in &bundle.centroids {
        for v in c {
            body.extend_from_slice(&v.to_le_bytes());
        }
    }
    for list in &bundle.lists {
        body.extend_from_slice(&(list.len() as u32).to_le_bytes());
        for id in list {
            body.extend_from_slice(&id.to_le_bytes());
        }
    }
    for row in &bundle.vectors {
        for v in row {
            body.extend_from_slice(&v.to_le_bytes());
        }
    }
    let header_words = [
        bundle.dim,
        bundle.nlist,
        bundle.nprobe,
        bundle.vector_count,
    ];
    let digest = hash_prefix(&header_words);
    body.extend_from_slice(&digest);
    body.extend_from_slice(FOOTER_TAG);
    fs::write(path, &body)?;
    Ok(body.len())
}

pub fn load_snapshot(path: &Path) -> Result<SnapshotBundle, SnapshotError> {
    let bytes = fs::read(path).map_err(|_| SnapshotError::Truncated)?;
    if bytes.len() < HEADER_BYTES + 36 {
        return Err(SnapshotError::Truncated);
    }
    if &bytes[0..4] != MAGIC {
        return Err(SnapshotError::BadMagic);
    }
    if &bytes[bytes.len() - 4..] != FOOTER_TAG {
        return Err(SnapshotError::BadFooter);
    }
    let header_words = [
        u32::from_le_bytes(bytes[4..8].try_into().unwrap()),
        u32::from_le_bytes(bytes[8..12].try_into().unwrap()),
        u32::from_le_bytes(bytes[12..16].try_into().unwrap()),
        read_count_word(&bytes[16..20]),
    ];
    let digest_off = bytes.len() - 36;
    let on_disk = &bytes[digest_off..digest_off + 32];
    let expect = hash_prefix(&header_words);
    if on_disk != expect {
        return Err(SnapshotError::Checksum);
    }
    let layout = std::env::var("ANN_SNAPSHOT_LAYOUT").unwrap_or_else(|_| "le32".into());
    if layout != "le32" && layout != "native" {
        return Err(SnapshotError::Layout);
    }
    let dim = header_words[0] as usize;
    let nlist = header_words[1] as usize;
    let nprobe = header_words[2] as usize;
    let vector_count = header_words[3] as usize;
    let mut offset = 20usize;
    let payload_end = digest_off;
    let mut centroids = Vec::with_capacity(nlist);
    for _ in 0..nlist {
        if offset + dim * 4 > payload_end {
            return Err(SnapshotError::Truncated);
        }
        let mut row = vec![0.0f32; dim];
        for slot in &mut row {
            *slot = f32::from_le_bytes(bytes[offset..offset + 4].try_into().unwrap());
            offset += 4;
        }
        centroids.push(row);
    }
    let mut lists = Vec::with_capacity(nlist);
    for _ in 0..nlist {
        if offset + 4 > payload_end {
            return Err(SnapshotError::Truncated);
        }
        let len = read_list_len(&bytes[offset..offset + 4], &layout) as usize;
        offset += 4;
        if offset + len * 4 > payload_end {
            return Err(SnapshotError::Truncated);
        }
        let mut ids = Vec::with_capacity(len);
        for _ in 0..len {
            ids.push(u32::from_le_bytes(bytes[offset..offset + 4].try_into().unwrap()));
            offset += 4;
        }
        lists.push(ids);
    }
    let mut vectors = Vec::with_capacity(vector_count);
    for _ in 0..vector_count {
        if offset + dim * 4 > payload_end {
            return Err(SnapshotError::Truncated);
        }
        let mut row = vec![0.0f32; dim];
        for slot in &mut row {
            *slot = f32::from_le_bytes(bytes[offset..offset + 4].try_into().unwrap());
            offset += 4;
        }
        vectors.push(row);
    }
    Ok(SnapshotBundle {
        dim: header_words[0],
        nlist: header_words[1],
        nprobe: header_words[2],
        vector_count: header_words[3],
        centroids,
        lists,
        vectors,
    })
}

fn read_count_word(raw: &[u8]) -> u32 {
    let mut buf = [0u8; 4];
    buf.copy_from_slice(raw);
    u32::from_ne_bytes(buf)
}

fn read_list_len(raw: &[u8], layout: &str) -> u32 {
    let mut buf = [0u8; 4];
    buf.copy_from_slice(raw);
    if layout == "le32" {
        u32::from_be_bytes(buf)
    } else {
        u32::from_ne_bytes(buf)
    }
}

pub fn write_corrupt_fixture(path: &Path, good: &Path) -> std::io::Result<()> {
    let mut bytes = fs::read(good)?;
    if bytes.len() > 40 {
        bytes[16] = bytes[16].wrapping_add(3);
    }
    fs::write(path, bytes)
}
