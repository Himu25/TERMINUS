use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::thread;
use std::time::Duration;

use crate::retain_core::{IvfIndex, VectorStore};
use crate::math::squared_distance;

const SCAN_CAP: usize = 24;
const STRESS_ROUNDS: u32 = 8;

pub struct SearchEngine {
    pub store: Arc<VectorStore>,
    pub ivf: Arc<IvfIndex>,
    pub heap_evictions: AtomicU64,
}

impl SearchEngine {
    pub fn new(store: Arc<VectorStore>, ivf: Arc<IvfIndex>) -> Self {
        Self {
            store,
            ivf,
            heap_evictions: AtomicU64::new(0),
        }
    }

    pub fn search_topk(&self, query: &[f32], k: usize) -> (usize, Vec<u32>) {
        let (probes, mut candidates) = self.ivf.probe_lists(query);
        if candidates.len() > SCAN_CAP {
            candidates.truncate(SCAN_CAP);
            self.heap_evictions.fetch_add(1, Ordering::Relaxed);
        }
        let vectors = self.store.snapshot_vectors();
        let mut scored: Vec<(u32, f32)> = candidates
            .into_iter()
            .filter_map(|id| {
                let idx = id as usize;
                vectors.get(idx).map(|row| (id, squared_distance(query, row)))
            })
            .collect();
        scored.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal));
        scored.truncate(k);
        (probes, scored.into_iter().map(|(id, _)| id).collect())
    }

    pub fn recall_at_k(&self, query: &[f32], want_ids: &[u32], k: usize) -> f32 {
        let (_, got) = self.search_topk(query, k);
        let hit = got.iter().filter(|id| want_ids.contains(id)).count();
        hit as f32 / want_ids.len().max(1) as f32
    }
}

#[derive(Debug, Default, Clone, Copy)]
pub struct ConcurrentStats {
    pub ghost_hits: u64,
    pub snapshot_bytes: usize,
}

pub fn stress_concurrent(_engine: Arc<SearchEngine>, ivf: Arc<IvfIndex>, store: Arc<VectorStore>, dim: usize) -> ConcurrentStats {
    let ghosts = Arc::new(AtomicU64::new(0));
    let snap_bytes = Arc::new(AtomicU64::new(0));
    let query = vec![0.1f32; dim];
    let stop = Arc::new(std::sync::atomic::AtomicBool::new(false));

    let writer = {
        let ivf_c = ivf.clone();
        let store_c = store.clone();
        let stop_c = stop.clone();
        thread::spawn(move || {
            let mut tick = 0u32;
            while !stop_c.load(Ordering::Relaxed) && tick < STRESS_ROUNDS {
                let batch = vec![vec![0.01 * tick as f32; dim]];
                store_c.ingest_batch(batch);
                store_c.publish();
                let vecs = store_c.snapshot_vectors();
                ivf_c.rebuild_lists(&vecs);
                tick = tick.wrapping_add(1);
                thread::sleep(Duration::from_millis(1));
            }
        })
    };

    let snapper = {
        let ivf_c = ivf.clone();
        let store_c = store.clone();
        let stop_c = stop.clone();
        let ghosts_c = ghosts.clone();
        let snap_bytes_c = snap_bytes.clone();
        thread::spawn(move || {
            let path = std::path::Path::new("/app/output/stress_snap.bin");
            let mut rounds = 0u32;
            while !stop_c.load(Ordering::Relaxed) && rounds < STRESS_ROUNDS {
                let max_id = store_c.len() as u32;
                for ids in ivf_c.lists_snapshot() {
                    for id in ids {
                        if id >= max_id {
                            ghosts_c.fetch_add(1, Ordering::Relaxed);
                        }
                    }
                }
                let bundle = crate::persist::frame::SnapshotBundle {
                    dim: dim as u32,
                    nlist: ivf_c.nlist() as u32,
                    nprobe: ivf_c.nprobe() as u32,
                    vector_count: store_c.len() as u32,
                    centroids: ivf_c.centroids_snapshot(),
                    lists: ivf_c.lists_snapshot(),
                    vectors: store_c.snapshot_vectors(),
                };
                let _ = crate::persist::frame::save_snapshot(path, &bundle);
                let len = std::fs::metadata(path).map(|m| m.len() as u64).unwrap_or(0);
                snap_bytes_c.store(len, Ordering::Relaxed);
                rounds += 1;
                thread::sleep(Duration::from_millis(2));
            }
        })
    };

    thread::sleep(Duration::from_millis(40));
    stop.store(true, Ordering::Relaxed);
    let _ = writer.join();
    let _ = snapper.join();
    ConcurrentStats {
        ghost_hits: ghosts.load(Ordering::Relaxed),
        snapshot_bytes: snap_bytes.load(Ordering::Relaxed) as usize,
    }
}
