use std::collections::HashMap;
use std::fs;
use std::io::{BufRead, BufReader};
use std::path::{Path, PathBuf};
use std::sync::Arc;

use serde::Serialize;
use sha2::{Digest, Sha256};

use crate::retain_core::{IvfIndex, VectorStore};
use crate::persist::{load_snapshot, save_snapshot, SnapshotError};
use crate::persist::frame::{write_corrupt_fixture, SnapshotBundle};
use crate::search::{ConcurrentStats, SearchEngine};

#[derive(Clone, Serialize)]
pub struct QueryRow {
    pub query_id: String,
    pub recall_at_10: f64,
    pub ivf_probes: u32,
    pub neighbor_hits: u32,
}

#[derive(Clone, Serialize)]
pub struct BenchReport {
    pub status: String,
    pub vector_dim: u32,
    pub corpus_vectors: u32,
    pub queries_total: u32,
    pub mean_recall_at_10: f64,
    pub roundtrip_recall_at_10: f64,
    pub concurrent_ghost_hits: u64,
    pub corrupt_load_rejects: u32,
    pub layout_tag_ok: u32,
    pub mean_ivf_probes: f64,
    pub max_heap_evictions: u64,
    pub snapshot_bytes: u32,
    pub report_digest: String,
    pub queries: Vec<QueryRow>,
}

pub fn load_corpus(path: &Path) -> (usize, usize, usize, Vec<Vec<f32>>) {
    let raw = fs::read_to_string(path).expect("corpus");
    let doc: serde_json::Value = serde_json::from_str(&raw).expect("corpus json");
    let dim = doc["dim"].as_u64().unwrap() as usize;
    let nlist = doc["nlist"].as_u64().unwrap() as usize;
    let nprobe = doc["nprobe"].as_u64().unwrap() as usize;
    let mut vectors = Vec::new();
    for row in doc["vectors"].as_array().unwrap() {
        let mut v = Vec::with_capacity(dim);
        for cell in row.as_array().unwrap() {
            v.push(cell.as_f64().unwrap() as f32);
        }
        vectors.push(v);
    }
    (dim, nlist, nprobe, vectors)
}

pub fn load_queries(path: &Path) -> Vec<(String, Vec<f32>)> {
    let file = fs::File::open(path).expect("queries");
    let reader = BufReader::new(file);
    let mut out = Vec::new();
    for line in reader.lines() {
        let line = line.expect("line");
        if line.trim().is_empty() {
            continue;
        }
        let doc: serde_json::Value = serde_json::from_str(&line).expect("query json");
        let qid = doc["query_id"].as_str().unwrap().to_string();
        let mut v = Vec::new();
        for cell in doc["vector"].as_array().unwrap() {
            v.push(cell.as_f64().unwrap() as f32);
        }
        out.push((qid, v));
    }
    out
}

pub fn load_neighbors(path: &Path) -> HashMap<String, Vec<u32>> {
    let raw = fs::read_to_string(path).expect("neighbor labels");
    let doc: serde_json::Value = serde_json::from_str(&raw).expect("neighbor json");
    let mut out = HashMap::new();
    for (k, v) in doc.as_object().unwrap() {
        let ids: Vec<u32> = v
            .as_array()
            .unwrap()
            .iter()
            .map(|x| x.as_u64().unwrap() as u32)
            .collect();
        out.insert(k.clone(), ids);
    }
    out
}

fn round4(v: f64) -> f64 {
    (v * 10000.0 + 0.5).floor() / 10000.0
}

pub fn build_engine(corpus_path: &Path) -> (Arc<SearchEngine>, usize, usize, usize, usize) {
    let (dim, nlist, nprobe, vectors) = load_corpus(corpus_path);
    let store = Arc::new(VectorStore::new(dim));
    store.ingest_batch(vectors.clone());
    store.publish();
    let ivf = Arc::new(IvfIndex::from_corpus(&vectors, nlist, nprobe));
    let engine = Arc::new(SearchEngine::new(store.clone(), ivf.clone()));
    (engine, dim, nlist, nprobe, vectors.len())
}

pub fn run_bench(corpus_path: &Path, query_path: &Path, neighbor_path: &Path, out_path: &Path) -> BenchReport {
    let (engine, dim, nlist, nprobe, corpus_len) = build_engine(corpus_path);
    let store = engine.store.clone();
    let ivf = engine.ivf.clone();
    let queries = load_queries(query_path);
    let neighbor_map = load_neighbors(neighbor_path);
    let mut rows = Vec::new();
    let mut probe_sum = 0u64;
    let mut recall_sum = 0.0f64;
    for (qid, qvec) in &queries {
        let want_ids = neighbor_map.values().next().cloned().unwrap_or_default();
        let (probes, got) = engine.search_topk(qvec, 10);
        probe_sum += probes as u64;
        let hits = got.iter().filter(|id| want_ids.contains(id)).count() as u32;
        let recall = hits as f64 / want_ids.len().max(1) as f64;
        recall_sum += recall;
        rows.push(QueryRow {
            query_id: qid.clone(),
            recall_at_10: round4(recall),
            ivf_probes: probes as u32,
            neighbor_hits: hits,
        });
    }
    let mean_recall = round4(recall_sum / queries.len().max(1) as f64);
    let mean_probes = probe_sum as f64 / queries.len().max(1) as f64;

    let snap_path = PathBuf::from("/app/output/roundtrip_snap.bin");
    let bundle = SnapshotBundle {
        dim: dim as u32,
        nlist: nlist as u32,
        nprobe: nprobe as u32,
        vector_count: corpus_len as u32,
        centroids: ivf.centroids_snapshot(),
        lists: ivf.lists_snapshot(),
        vectors: store.snapshot_vectors(),
    };
    let snap_bytes = save_snapshot(&snap_path, &bundle).unwrap_or(0) as u32;
    let mut roundtrip_recall = 0.0f64;
    if let Ok(loaded) = load_snapshot(&snap_path) {
        ivf.restore(loaded.centroids, loaded.lists);
        {
            let mut guard = store.vectors.write().unwrap();
            guard.clear();
            guard.extend(loaded.vectors);
        }
        store.live_gen.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        store.publish();
        if let Some((qid, qvec)) = queries.first() {
            let want_ids = neighbor_map
                .values()
                .next()
                .cloned()
                .unwrap_or_default();
            roundtrip_recall = engine.recall_at_k(qvec, &want_ids, 10) as f64;
        }
    }

    let corrupt_path = PathBuf::from("/app/output/corrupt_snap.bin");
    let _ = write_corrupt_fixture(&corrupt_path, &snap_path);
    let mut rejects = 0u32;
    if load_snapshot(&corrupt_path).is_err() {
        rejects += 1;
    }
    if load_snapshot(&corrupt_path).is_err() {
        rejects = rejects.max(1);
    }

    let layout_ok = if std::env::var("ANN_SNAPSHOT_LAYOUT").unwrap_or_else(|_| "le32".into()) == "le32" {
        1
    } else {
        0
    };

    let stress = crate::search::runner::stress_concurrent(engine.clone(), ivf, store, dim);
    let heap_evictions = engine.heap_evictions.load(std::sync::atomic::Ordering::Relaxed);

    let mut report = BenchReport {
        status: "ok".into(),
        vector_dim: dim as u32,
        corpus_vectors: bundle.vector_count,
        queries_total: queries.len() as u32,
        mean_recall_at_10: mean_recall,
        roundtrip_recall_at_10: round4(roundtrip_recall),
        concurrent_ghost_hits: stress.ghost_hits,
        corrupt_load_rejects: rejects,
        layout_tag_ok: layout_ok,
        mean_ivf_probes: round4(mean_probes),
        max_heap_evictions: heap_evictions,
        snapshot_bytes: snap_bytes.max(stress.snapshot_bytes as u32),
        report_digest: String::new(),
        queries: rows,
    };
    if mean_recall < 0.85 || roundtrip_recall < 0.85 || stress.ghost_hits > 0 || rejects < 1 {
        report.status = "fail".into();
    }
    report.report_digest = digest_report(&report);
  if fs::create_dir_all(out_path.parent().unwrap()).is_ok() {}
    let raw = serde_json::to_string(&report).expect("json");
    fs::write(out_path, format!("{raw}\n")).expect("write report");
    report
}

fn digest_report(report: &BenchReport) -> String {
    // Digest input must share field order with the on-disk report JSON body.
    let mut clone = serde_json::to_value(report).unwrap();
    if let Some(obj) = clone.as_object_mut() {
        obj.insert("report_digest".into(), serde_json::Value::String(String::new()));
    }
    let raw = serde_json::to_string(&clone).unwrap();
    let mut hasher = Sha256::new();
    hasher.update(raw.as_bytes());
    format!("{:x}", hasher.finalize())
}
