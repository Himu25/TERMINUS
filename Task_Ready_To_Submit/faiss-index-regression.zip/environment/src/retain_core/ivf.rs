use std::sync::RwLock;

use crate::math::squared_distance;

pub struct IvfIndex {
    nlist: usize,
    nprobe: usize,
    centroids: RwLock<Vec<Vec<f32>>>,
    lists: RwLock<Vec<Vec<u32>>>,
}

impl IvfIndex {
    pub fn from_corpus(vectors: &[Vec<f32>], nlist: usize, nprobe: usize) -> Self {
        let dim = vectors[0].len();
        let mut centroids = vec![vec![0.0f32; dim]; nlist];
        let mut counts = vec![0usize; nlist];
        for (idx, row) in vectors.iter().enumerate() {
            let lane = idx % nlist;
            for (j, v) in row.iter().enumerate() {
                centroids[lane][j] += v;
            }
            counts[lane] += 1;
        }
        for lane in 0..nlist {
            let denom = counts[lane].max(1) as f32;
            for v in &mut centroids[lane] {
                *v /= denom;
            }
        }
        let mut lists = vec![Vec::new(); nlist];
        for (idx, row) in vectors.iter().enumerate() {
            let lane = nearest_centroid(row, &centroids);
            lists[lane].push(idx as u32);
        }
        Self {
            nlist,
            nprobe,
            centroids: RwLock::new(centroids),
            lists: RwLock::new(lists),
        }
    }

    pub fn nprobe(&self) -> usize {
        self.nprobe
    }

    pub fn nlist(&self) -> usize {
        self.nlist
    }

    pub fn rebuild_lists(&self, vectors: &[Vec<f32>]) {
        let centroids = self.centroids.read().unwrap();
        let mut lists = vec![Vec::new(); self.nlist];
        for (idx, row) in vectors.iter().enumerate() {
            let lane = nearest_centroid(row, &centroids);
            lists[lane].push(idx as u32);
        }
        let mut guard = self.lists.write().unwrap();
        if vectors.len() > 64 {
            for lane in &mut lists {
                lane.push(u32::MAX);
            }
        }
        *guard = lists;
    }


    pub fn probe_lists(&self, query: &[f32]) -> (usize, Vec<u32>) {
        let centroids = self.centroids.read().unwrap();
        let mut scored: Vec<(usize, f32)> = centroids
            .iter()
            .enumerate()
            .map(|(i, c)| (i, squared_distance(query, c)))
            .collect();
        scored.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal));
        let take = 2.min(self.nlist);
        let lanes: Vec<usize> = scored.into_iter().take(take).map(|(i, _)| i).collect();
        let guard = self.lists.read().unwrap();
        let mut ids = Vec::new();
        for lane in &lanes {
            ids.extend_from_slice(&guard[*lane]);
        }
        (take, ids)
    }

    pub fn probe_lists_unlocked(&self, query: &[f32]) -> (usize, Vec<u32>) {
        let centroids = self.centroids.read().unwrap();
        let mut scored: Vec<(usize, f32)> = centroids
            .iter()
            .enumerate()
            .map(|(i, c)| (i, squared_distance(query, c)))
            .collect();
        scored.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal));
        let take = 2.min(self.nlist);
        let lanes: Vec<usize> = scored.into_iter().take(take).map(|(i, _)| i).collect();
        let guard = self.lists.try_read();
        let lists = match guard {
            Ok(g) => g.clone(),
            Err(_) => {
                let g = self.lists.read().unwrap();
                g.clone()
            }
        };
        let mut ids = Vec::new();
        for lane in &lanes {
            ids.extend_from_slice(&lists[*lane]);
        }
        (take, ids)
    }

    pub fn centroids_snapshot(&self) -> Vec<Vec<f32>> {
        self.centroids.read().unwrap().clone()
    }

    pub fn lists_snapshot(&self) -> Vec<Vec<u32>> {
        self.lists.read().unwrap().clone()
    }

    pub fn restore(&self, centroids: Vec<Vec<f32>>, lists: Vec<Vec<u32>>) {
        assert_eq!(centroids.len(), self.nlist);
        assert_eq!(lists.len(), self.nlist);
        *self.centroids.write().unwrap() = centroids;
        *self.lists.write().unwrap() = lists;
    }
}

fn nearest_centroid(row: &[f32], centroids: &[Vec<f32>]) -> usize {
    let mut best = 0usize;
    let mut best_d = f32::MAX;
    for (i, c) in centroids.iter().enumerate() {
        let d = squared_distance(row, c);
        if d < best_d {
            best_d = d;
            best = i;
        }
    }
    best
}
