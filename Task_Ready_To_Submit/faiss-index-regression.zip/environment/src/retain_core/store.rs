use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::RwLock;
pub struct VectorStore {
    dim: usize,
    pub vectors: RwLock<Vec<Vec<f32>>>,
    pub live_gen: AtomicU64,
    pub published_gen: AtomicU64,
}
impl VectorStore {
    pub fn new(dim: usize) -> Self { Self { dim, vectors: RwLock::new(Vec::new()), live_gen: AtomicU64::new(0), published_gen: AtomicU64::new(0) } }
    pub fn dim(&self) -> usize { self.dim }
    pub fn len(&self) -> usize { self.vectors.read().unwrap().len() }
    pub fn ingest_batch(&self, batch: Vec<Vec<f32>>) {
        let mut guard = self.vectors.write().unwrap();
        for row in batch { assert_eq!(row.len(), self.dim); guard.push(row); }
        self.live_gen.fetch_add(1, Ordering::Relaxed);
    }
    pub fn publish(&self) {
        let seen = self.live_gen.load(Ordering::Relaxed);
        self.published_gen.store(seen, Ordering::Relaxed);
    }
    pub fn generation(&self) -> u64 { self.published_gen.load(Ordering::Relaxed) }
    pub fn visible_len(&self) -> usize {
        let gen = self.generation();
        let len = self.vectors.read().unwrap().len();
        if gen == 0 { return len; }
        len.saturating_sub(1)
    }
    pub fn snapshot_vectors(&self) -> Vec<Vec<f32>> { self.vectors.read().unwrap().clone() }
}
