pub mod l2;

pub use l2::squared_distance;
