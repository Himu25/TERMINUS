# Matrix loader layout

Go `matrix` under `/app/cmd/matrix` replays JSON scenarios from `/app/fixtures/scenarios`, invokes the Rust `slot` worker for shared-module attach and byte routing, then assembles `/app/output/plugin_matrix.json`.

Each `scenarios` element includes:

- `name` — fixture basename (matches the JSON file stem under `/app/fixtures/scenarios`)
- `finish_reason` — `complete` when attach and routing succeed; `reject` when attach aborts before routing
- `loaded_count` — modules successfully attached before routing runs or attach rejection stops the sequence
- `route_reply` — bytes returned from the step hook when `fork` is false; empty when `fork` is true
- `leak_bytes` — bytes still owned by the module allocator after the step hook; settled repaired runs report 0
- `fork_child_ok` — for `fork` true fixtures, true when the forked worker finishes routing; false when `fork` is false
- `reject_code` — empty on success; attach failures use stable loader tokens
- `sla_ok` — per `/app/metrics/sla.txt`; false while allocator debt remains after routing

## Reply prefixes

Inspect each module under `/app/mods/*/src` to see how its step hook formats replies:

- `echo_lane` — prefix `PONG:` then the fixture `input` string unchanged
- `heap_lane` — prefix `HEAP:` then the fixture `input` string unchanged

Combine prefix plus `input` for routed fixtures with `fork` false that load only that module (e.g. input wideping99 → PONG:wideping99).

## Attach rejection tokens

- Wire revision mismatch (e.g. `old_lane` at revision 1 vs host expectation) — `reject_code` `abi_mismatch`, `loaded_count` 0, `finish_reason` `reject`
- Second attach with colliding entry symbols (`dup_alpha` then `dup_beta`) — `reject_code` `symbol_conflict`, `loaded_count` 1 after the first module attaches, `finish_reason` `reject`

## Fork fixtures

When `fork` is true, routing runs in a forked worker: `route_reply` stays empty and `fork_child_ok` carries whether the worker completed routing. Repaired runs set `fork_child_ok` true for `fork_lane` and `fork_heap` while parent teardown no longer kills the worker.

## Paired attach

Paired attach fixtures list two module names. The broken loader loads both; the repaired loader attaches the first module, aborts the second with `symbol_conflict`, and leaves `loaded_count` at 1.

## Chain attach

Chain fixtures list two modules where the first attaches cleanly and the second collides on the shared entry symbol. Repaired runs reject with `symbol_conflict`, keep `loaded_count` at 1, and leave `route_reply` empty.

## Attach budget

Single-module attach policy in `/app/policies/attach_budget.txt` must gate each load attempt. Repaired runs reject a second module when the occupancy counter reports an open attach.

## SLA settlement

Each row exports `sla_ok` per `/app/metrics/sla.txt` and `/app/policies/attach_budget.txt`. Repaired complete rows set `sla_ok` true once `leak_bytes` is zero. Repaired reject rows set `sla_ok` true when partial attach settles with zero allocator debt. The Go report and anchor replay must agree on `sla_ok`, `loaded_count`, and `leak_bytes`.
