Each replay pack is a directory with sample_bundle.json and draws.jsonl.
Swap packs into /app/data/active before running sample_bench with TB_SAMPLE_FIXTURE=1.
