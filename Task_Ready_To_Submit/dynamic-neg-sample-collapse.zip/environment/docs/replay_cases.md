Build the sampler with `/app/scripts/build.sh` (Go plus Rust staticlib via `/usr/local/go/bin/go` and cargo). Verifier helpers include `/tmp/sample_bench_verify_bin` and `/app/tools/digest_cli` for digest recomputation.

sample_head stresses catalog head ranks in negative draws.
sample_stale spans four epochs with pool_ttl_epochs two.
sample_repeat schedules three draws for one item in epoch zero with dup_limit two.
sample_spread runs three epochs of four unique negatives each.
sample_alpha is the default active pack.
