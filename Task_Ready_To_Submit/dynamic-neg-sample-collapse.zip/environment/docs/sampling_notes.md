Negative pools refresh when the epoch gap since last refresh reaches pool_ttl_epochs.
Per-epoch dup_limit caps how many times the same catalog id may appear as a negative.
Head-cap debias scales weight for low freq_rank draws.
