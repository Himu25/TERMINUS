module lab.local/dynamic_neg_sample_collapse

go 1.22
