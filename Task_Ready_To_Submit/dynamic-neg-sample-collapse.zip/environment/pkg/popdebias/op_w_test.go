package popdebias

import "testing"

func TestOpWCapScale(t *testing.T) {
	w := OpW(5, 20)
	if w >= 1.0 {
		t.Fatalf("expected downweight below cap, got %v", w)
	}
}
