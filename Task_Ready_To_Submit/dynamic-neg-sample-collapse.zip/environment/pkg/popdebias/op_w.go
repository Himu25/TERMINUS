package popdebias

// OpW returns the negative draw weight for a catalog frequency rank.
func OpW(freqRank int, cap int) float64 {
	if cap <= 0 {
		return 1.0
	}
	if freqRank <= cap {
		return float64(cap) / float64(freqRank)
	}
	return 1.0
}
