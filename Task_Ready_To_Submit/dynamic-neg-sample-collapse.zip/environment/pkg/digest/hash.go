package digest

import (
	"crypto/sha256"
	"encoding/hex"
	"strings"
)

// FoldReport hashes the audit counters in field order.
func FoldReport(parts ...string) string {
	h := sha256.Sum256([]byte(strings.Join(parts, "|")))
	return hex.EncodeToString(h[:])
}
