package digest

import "strings"

// Rollup joins audit parts without hashing.
func Rollup(parts ...string) string {
	return strings.Join(parts, ":")
}
