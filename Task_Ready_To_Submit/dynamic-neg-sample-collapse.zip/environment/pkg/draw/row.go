package draw

// Row is one scheduled draw in the training log.
type Row struct {
	Epoch    int    `json:"epoch"`
	ItemID   string `json:"item_id"`
	FreqRank int    `json:"freq_rank"`
	Slot     int    `json:"slot"`
}
