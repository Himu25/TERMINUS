package epochdedup

import "testing"

func TestOpJLimitBoundary(t *testing.T) {
	if OpJ(2, 2) {
		t.Fatal("expected false at dup limit boundary")
	}
}
