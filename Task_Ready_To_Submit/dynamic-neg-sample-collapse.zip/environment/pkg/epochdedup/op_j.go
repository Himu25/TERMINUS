package epochdedup

// OpJ decides whether another negative draw is allowed for an item this epoch.
func OpJ(seen int, limit int) bool {
	if limit <= 0 {
		return true
	}
	return seen >= limit
}
