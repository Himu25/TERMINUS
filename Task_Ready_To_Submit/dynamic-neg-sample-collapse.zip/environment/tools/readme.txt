Verifier helpers include /tmp/sample_bench_verify_bin and /app/tools/digest_cli for digest recomputation.
Build the sampler with /app/scripts/build.sh using /usr/local/go/bin/go and cargo.
