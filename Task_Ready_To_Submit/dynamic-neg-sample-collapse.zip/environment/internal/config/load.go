package config

import (
	"encoding/json"
	"os"
	"path/filepath"

	"lab.local/dynamic_neg_sample_collapse/pkg/draw"
)

// Bundle holds replay knobs for one pack.
type Bundle struct {
	RunID              string `json:"run_id"`
	EpochCount         int    `json:"epoch_count"`
	PoolTTLEpochs      int    `json:"pool_ttl_epochs"`
	DupLimit           int    `json:"dup_limit"`
	HeadCapRank        int    `json:"head_cap_rank"`
	SpreadFloorX100    int    `json:"spread_floor_x100"`
	PopBiasThresholdX100 int `json:"pop_bias_threshold_x100"`
}

// ActivePaths resolves the active pack directory under appRoot.
func ActivePaths(appRoot string) (string, error) {
	return filepath.Join(appRoot, "data", "active"), nil
}

// LoadBundle reads sample_bundle.json and draws.jsonl from dir.
func LoadBundle(dir string) (Bundle, []draw.Row, error) {
	raw, err := os.ReadFile(filepath.Join(dir, "sample_bundle.json"))
	if err != nil {
		return Bundle{}, nil, err
	}
	var bundle Bundle
	if err := json.Unmarshal(raw, &bundle); err != nil {
		return Bundle{}, nil, err
	}
	lines, err := os.ReadFile(filepath.Join(dir, "draws.jsonl"))
	if err != nil {
		return Bundle{}, nil, err
	}
	var rows []draw.Row
	for _, line := range stringsSplitLines(string(lines)) {
		if line == "" {
			continue
		}
		var row draw.Row
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return Bundle{}, nil, err
		}
		rows = append(rows, row)
	}
	return bundle, rows, nil
}

func stringsSplitLines(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			out = append(out, s[start:i])
			start = i + 1
		}
	}
	if start < len(s) {
		out = append(out, s[start:])
	}
	return out
}
