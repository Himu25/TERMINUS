package engine

import (
	"lab.local/dynamic_neg_sample_collapse/internal/config"
	"lab.local/dynamic_neg_sample_collapse/pkg/draw"
)

// Outcome is the folded counters for one pack replay.
type Outcome struct {
	EpochCount            int
	UniqueNegRatePct      int
	HeadAmplificationHits int
	PoolRefreshCount      int
	RepeatViolationCount  int
	DiversityScoreX100    int
	CollapseBand          string
}

// Replay executes one sample bundle through the audit pipeline.
func Replay(bundle config.Bundle, rows []draw.Row) Outcome {
	sortRows(rows)
	lastRefresh := 0
	poolRefreshes := 0
	headHits := 0
	repeatViolations := 0
	totalNeg := 0
	globalUnique := map[string]struct{}{}
	diversity := 50.0

	curEpoch := -1
	epochSeen := map[string]int{}

	for _, row := range rows {
		if row.Epoch != curEpoch {
			if curEpoch >= 0 {
				diversity = foldEpochSpread(diversity, len(epochSeen))
			}
			curEpoch = row.Epoch
			epochSeen = map[string]int{}
			maybeRefreshPool(curEpoch, lastRefresh, bundle.PoolTTLEpochs, &poolRefreshes, &lastRefresh)
		}
		if row.Slot <= 0 {
			continue
		}
		totalNeg++
		globalUnique[row.ItemID] = struct{}{}
		auditNegativeDraw(
			row,
			bundle.DupLimit,
			bundle.HeadCapRank,
			bundle.PopBiasThresholdX100,
			epochSeen,
			&repeatViolations,
			&headHits,
		)
	}
	if curEpoch >= 0 {
		diversity = foldEpochSpread(diversity, len(epochSeen))
	}

	uniqueRate := 0
	if totalNeg > 0 {
		uniqueRate = (len(globalUnique) * 100) / totalNeg
	}
	scoreX100 := int(diversity * 100)
	if scoreX100 < 0 {
		scoreX100 = 0
	}
	band := "spread"
	if scoreX100 < bundle.SpreadFloorX100 {
		band = "collapsed"
	}
	epochs := bundle.EpochCount
	if epochs <= 0 {
		epochs = curEpoch + 1
	}
	return Outcome{
		EpochCount:            epochs,
		UniqueNegRatePct:      uniqueRate,
		HeadAmplificationHits: headHits,
		PoolRefreshCount:      poolRefreshes,
		RepeatViolationCount:  repeatViolations,
		DiversityScoreX100:    scoreX100,
		CollapseBand:          band,
	}
}

func sortRows(rows []draw.Row) {
	for i := 0; i < len(rows); i++ {
		for j := i + 1; j < len(rows); j++ {
			if rows[j].Epoch < rows[i].Epoch || (rows[j].Epoch == rows[i].Epoch && rows[j].Slot < rows[i].Slot) {
				rows[i], rows[j] = rows[j], rows[i]
			}
		}
	}
}
