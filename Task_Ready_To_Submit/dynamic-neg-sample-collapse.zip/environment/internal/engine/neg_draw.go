package engine

import (
	"lab.local/dynamic_neg_sample_collapse/pkg/draw"
	"lab.local/dynamic_neg_sample_collapse/pkg/epochdedup"
	"lab.local/dynamic_neg_sample_collapse/pkg/popdebias"
)

// auditNegativeDraw updates per-epoch counters for one negative slot.
func auditNegativeDraw(
	row draw.Row,
	dupLimit int,
	headCap int,
	biasThresholdX100 int,
	epochSeen map[string]int,
	repeatViolations *int,
	headHits *int,
) {
	seen := epochSeen[row.ItemID]
	if !epochdedup.OpJ(seen, dupLimit) {
		*repeatViolations++
		return
	}
	epochSeen[row.ItemID] = seen + 1
	w := popdebias.OpW(row.FreqRank, headCap)
	if row.FreqRank <= headCap && w*100 >= float64(biasThresholdX100) {
		*headHits++
	}
}
