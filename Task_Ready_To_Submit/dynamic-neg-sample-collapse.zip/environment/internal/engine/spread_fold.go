package engine

import "lab.local/dynamic_neg_sample_collapse/mixgate"

// foldEpochSpread applies unique-negative spread for a closed epoch.
func foldEpochSpread(diversity float64, uniqueNeg int) float64 {
	spread := float64(uniqueNeg) * 3.0
	return mixgate.SpreadDelta(diversity, spread)
}
