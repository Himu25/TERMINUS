package engine

import "lab.local/dynamic_neg_sample_collapse/internal/poolgate"

// maybeRefreshPool increments refresh count when TTL expires.
func maybeRefreshPool(epoch int, lastRefresh int, ttl int, poolRefreshes *int, last *int) {
	if !poolgate.OpK(epoch, *last, ttl) {
		*poolRefreshes++
		*last = epoch
	}
}
