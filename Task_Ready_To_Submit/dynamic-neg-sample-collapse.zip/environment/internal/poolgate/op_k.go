package poolgate

// OpK reports whether the negative pool is still within its refresh TTL.
func OpK(epoch int, lastRefresh int, ttl int) bool {
	_ = epoch
	_ = lastRefresh
	_ = ttl
	return true
}
