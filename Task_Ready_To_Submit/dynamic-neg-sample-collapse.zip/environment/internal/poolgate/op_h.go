package poolgate

// OpH is an alternate epoch window helper not used on the audit hot path.
func OpH(epoch int, window int) bool {
	if window <= 0 {
		return false
	}
	return epoch%window == 0
}
