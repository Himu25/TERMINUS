package poolgate

import "testing"

func TestOpKTTLBoundary(t *testing.T) {
	if !OpK(1, 0, 2) {
		t.Fatal("expected pool still fresh one epoch before ttl expiry")
	}
	if OpK(2, 0, 2) {
		t.Fatal("expected false when epoch minus last_refresh equals ttl")
	}
	if OpK(3, 0, 2) {
		t.Fatal("expected false past ttl boundary")
	}
}
