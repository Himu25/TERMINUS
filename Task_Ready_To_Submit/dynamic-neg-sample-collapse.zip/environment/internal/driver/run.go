package driver

import (
	"encoding/json"
	"os"

	"lab.local/dynamic_neg_sample_collapse/internal/config"
	"lab.local/dynamic_neg_sample_collapse/internal/engine"
	"lab.local/dynamic_neg_sample_collapse/pkg/digest"
)

// Report is the JSON shape written to /app/output/sample_audit.json.
type Report struct {
	SchemaVersion         string `json:"schema_version"`
	RunID                 string `json:"run_id"`
	EpochCount            int    `json:"epoch_count"`
	UniqueNegRatePct      int    `json:"unique_neg_rate_pct"`
	HeadAmplificationHits int    `json:"head_amplification_hits"`
	PoolRefreshCount      int    `json:"pool_refresh_count"`
	RepeatViolationCount  int    `json:"repeat_violation_count"`
	DiversityScoreX100    int    `json:"diversity_score_x100"`
	CollapseBand          string `json:"collapse_band"`
	DigestHex             string `json:"digest_hex"`
}

// RunActive loads the active pack and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	bundle, rows, err := config.LoadBundle(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(bundle, rows)
	digestHex := digest.FoldReport(
		bundle.RunID,
		itoa(out.EpochCount),
		itoa(out.UniqueNegRatePct),
		itoa(out.HeadAmplificationHits),
		itoa(out.PoolRefreshCount),
		itoa(out.RepeatViolationCount),
		itoa(out.DiversityScoreX100),
		out.CollapseBand,
	)
	return Report{
		SchemaVersion:         "1",
		RunID:                 bundle.RunID,
		EpochCount:            out.EpochCount,
		UniqueNegRatePct:      out.UniqueNegRatePct,
		HeadAmplificationHits: out.HeadAmplificationHits,
		PoolRefreshCount:      out.PoolRefreshCount,
		RepeatViolationCount:  out.RepeatViolationCount,
		DiversityScoreX100:    out.DiversityScoreX100,
		CollapseBand:          out.CollapseBand,
		DigestHex:             digestHex,
	}, nil
}

// EmitReport writes rep to path as compact JSON.
func EmitReport(path string, rep Report) error {
	if err := os.MkdirAll("/app/output", 0o755); err != nil {
		return err
	}
	raw, err := json.Marshal(rep)
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func itoa(v int) string {
	if v == 0 {
		return "0"
	}
	var buf [16]byte
	i := len(buf)
	n := v
	neg := false
	if n < 0 {
		neg = true
		n = -n
	}
	for n > 0 {
		i--
		buf[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		buf[i] = '-'
	}
	return string(buf[i:])
}
