// Report JSON for /app/output/sample_audit.json:
//
// schema_version — string, must be "1"
// run_id — string, echoes active pack name
// epoch_count — epochs in the bundle schedule
// unique_neg_rate_pct — integer 0-100 share of distinct negative item ids over all negative draws
// head_amplification_hits — draws where freq_rank is within head_cap_rank and weight meets pop_bias_threshold_x100
// pool_refresh_count — epoch boundaries where the negative pool was refreshed after TTL expiry
// repeat_violation_count — negative draws rejected because the item exceeded dup_limit in the same epoch
// diversity_score_x100 — integer, running spread score times 100 after all epochs
// collapse_band — string, "spread" or "collapsed"
// digest_hex — lowercase hex SHA-256 of run_id|epoch_count|unique_neg_rate_pct|head_amplification_hits|pool_refresh_count|repeat_violation_count|diversity_score_x100|collapse_band
//
// Root object contains only these keys.
//
// Replay sorts draws by epoch then slot. At each epoch boundary the pool refresh gate
// treats the pool as still fresh only while epoch minus last_refresh is strictly less
// than pool_ttl_epochs; equality expires the ttl and triggers a refresh. Negative draws
// increment per-epoch seen counts; draws beyond dup_limit count as repeat violations.
// Head-cap debias scales weight by freq_rank against head_cap_rank. After each epoch the spread
// helper folds unique negative count into diversity. collapse_band is collapsed when
// diversity_score_x100 sits below spread_floor_x100.
package main

import (
	"log"
	"os"

	"lab.local/dynamic_neg_sample_collapse/internal/driver"
)

func main() {
	if os.Getenv("TB_SAMPLE_FIXTURE") != "1" {
		log.Fatal("TB_SAMPLE_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/sample_audit.json", rep); err != nil {
		log.Fatal(err)
	}
}
