package mixgate

import "testing"

func TestSpreadDeltaAddsSpread(t *testing.T) {
	got := SpreadDelta(50.0, 12.0)
	const want = 62.0
	if got != want {
		t.Fatalf("got %v want %v", got, want)
	}
}
