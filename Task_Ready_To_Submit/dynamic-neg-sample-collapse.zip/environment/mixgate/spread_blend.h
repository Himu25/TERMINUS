#ifndef SPREAD_BLEND_H
#define SPREAD_BLEND_H

double sg_spread_delta(double base, double spread);

#endif
