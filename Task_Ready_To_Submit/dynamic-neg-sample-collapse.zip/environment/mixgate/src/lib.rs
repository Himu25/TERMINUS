/// SgSpreadDelta folds epoch spread into the running diversity score.
#[no_mangle]
pub extern "C" fn sg_spread_delta(base: f64, spread: f64) -> f64 {
    base - spread
}
