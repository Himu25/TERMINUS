package mixgate

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libmixgate.a -ldl -lm
#include "spread_blend.h"
*/
import "C"

// SpreadDelta applies epoch spread into the running diversity score.
func SpreadDelta(base float64, spread float64) float64 {
	return float64(C.sg_spread_delta(C.double(base), C.double(spread)))
}
