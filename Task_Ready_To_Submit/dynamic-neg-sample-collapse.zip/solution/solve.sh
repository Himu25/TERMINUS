#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

for path in \
  /app/data/active/sample_bundle.json \
  /app/data/active/draws.jsonl \
  /app/scripts/build.sh; do
  test -f "$path"
done

write_popdebias() {
  cat > /app/pkg/popdebias/op_w.go <<'EOF'
package popdebias

func weightForRank(freqRank int, cap int) float64 {
	if cap <= 0 {
		return 1.0
	}
	if freqRank >= cap {
		return 1.0
	}
	return float64(freqRank) / float64(cap)
}

// OpW returns the negative draw weight for a catalog frequency rank.
func OpW(freqRank int, cap int) float64 {
	return weightForRank(freqRank, cap)
}
EOF
}

write_poolgate() {
  cat > /app/internal/poolgate/op_k.go <<'EOF'
package poolgate

func poolStillFresh(epoch int, lastRefresh int, ttl int) bool {
	if ttl <= 0 {
		return false
	}
	return epoch-lastRefresh < ttl
}

// OpK reports whether the negative pool is still within its refresh TTL.
func OpK(epoch int, lastRefresh int, ttl int) bool {
	return poolStillFresh(epoch, lastRefresh, ttl)
}
EOF
}

write_epochdedup() {
  cat > /app/pkg/epochdedup/op_j.go <<'EOF'
package epochdedup

func underDupLimit(seen int, limit int) bool {
	if limit <= 0 {
		return true
	}
	return seen < limit
}

// OpJ decides whether another negative draw is allowed for an item this epoch.
func OpJ(seen int, limit int) bool {
	return underDupLimit(seen, limit)
}
EOF
}

write_mixgate() {
  cat > /app/mixgate/src/lib.rs <<'EOF'
fn fold_spread(base: f64, spread: f64) -> f64 {
    base + spread
}

/// SgSpreadDelta folds epoch spread into the running diversity score.
#[no_mangle]
pub extern "C" fn sg_spread_delta(base: f64, spread: f64) -> f64 {
    fold_spread(base, spread)
}
EOF
}

write_popdebias
write_poolgate
write_epochdedup
write_mixgate

bash /app/scripts/build.sh

GOFLAGS=-mod=mod CGO_ENABLED=1 go test ./... -count=1

rm -f /app/output/sample_audit.json
TB_SAMPLE_FIXTURE=1 /app/bin/sample_bench
test -s /app/output/sample_audit.json
