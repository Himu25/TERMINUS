"""Verifier for dynamic negative sampling collapse audit."""

import json
import os
import shutil
import subprocess

import pytest
from pathlib import Path

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = APP / "data" / "replay"
OUT = APP / "output" / "sample_audit.json"
GO_BIN = "/usr/local/go/bin/go"
VERIFY_BIN = "/tmp/sample_bench_verify_bin"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)
    subprocess.run(["cp", "/app/bin/sample_bench", VERIFY_BIN], check=True)


def _digest_hex(
    run_id: str,
    epoch_count: int,
    unique_neg_rate_pct: int,
    head_amplification_hits: int,
    pool_refresh_count: int,
    repeat_violation_count: int,
    diversity_score_x100: int,
    collapse_band: str,
) -> str:
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            run_id,
            str(epoch_count),
            str(unique_neg_rate_pct),
            str(head_amplification_hits),
            str(pool_refresh_count),
            str(repeat_violation_count),
            str(diversity_score_x100),
            collapse_band,
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _op_w(freq_rank: int, cap: int) -> float:
    if cap <= 0 or freq_rank >= cap:
        return 1.0
    return freq_rank / cap


def _op_k(epoch: int, last_refresh: int, ttl: int) -> bool:
    if ttl <= 0:
        return False
    return epoch - last_refresh < ttl


def _op_j(seen: int, limit: int) -> bool:
    if limit <= 0:
        return True
    return seen < limit


def _spread_delta(base: float, spread: float) -> float:
    return base + spread


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = FIXTURES / pack_name
    bundle = json.loads((pack_dir / "sample_bundle.json").read_text())
    rows = []
    for line in (pack_dir / "draws.jsonl").read_text().splitlines():
        if line.strip():
            rows.append(json.loads(line))
    rows.sort(key=lambda r: (r["epoch"], r["slot"]))

    last_refresh = 0
    pool_refreshes = 0
    head_hits = 0
    repeat_violations = 0
    total_neg = 0
    global_unique: set[str] = set()
    diversity = 50.0
    cur_epoch = -1
    epoch_seen: dict[str, int] = {}

    for row in rows:
        if row["epoch"] != cur_epoch:
            if cur_epoch >= 0:
                uniq = len(epoch_seen)
                diversity = _spread_delta(diversity, float(uniq) * 3.0)
            cur_epoch = row["epoch"]
            epoch_seen = {}
            if not _op_k(cur_epoch, last_refresh, bundle["pool_ttl_epochs"]):
                pool_refreshes += 1
                last_refresh = cur_epoch
        if row["slot"] <= 0:
            continue
        total_neg += 1
        global_unique.add(row["item_id"])
        seen = epoch_seen.get(row["item_id"], 0)
        if not _op_j(seen, bundle["dup_limit"]):
            repeat_violations += 1
        else:
            epoch_seen[row["item_id"]] = seen + 1
        w = _op_w(row["freq_rank"], bundle["head_cap_rank"])
        if (
            row["freq_rank"] <= bundle["head_cap_rank"]
            and w * 100 >= bundle["pop_bias_threshold_x100"]
        ):
            head_hits += 1
    if cur_epoch >= 0:
        uniq = len(epoch_seen)
        diversity = _spread_delta(diversity, float(uniq) * 3.0)

    unique_rate = (len(global_unique) * 100) // total_neg if total_neg else 0
    score_x100 = max(0, int(diversity * 100))
    band = (
        "spread"
        if score_x100 >= bundle["spread_floor_x100"]
        else "collapsed"
    )
    epochs = bundle["epoch_count"]
    digest = _digest_hex(
        bundle["run_id"],
        epochs,
        unique_rate,
        head_hits,
        pool_refreshes,
        repeat_violations,
        score_x100,
        band,
    )
    return {
        "schema_version": "1",
        "run_id": bundle["run_id"],
        "epoch_count": epochs,
        "unique_neg_rate_pct": unique_rate,
        "head_amplification_hits": head_hits,
        "pool_refresh_count": pool_refreshes,
        "repeat_violation_count": repeat_violations,
        "diversity_score_x100": score_x100,
        "collapse_band": band,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_SAMPLE_FIXTURE": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_alpha_report_matches_replay() -> None:
    """Alpha pack should replay all audit counters including digest."""
    _swap("sample_alpha")
    exp = _expected_from_fixture("sample_alpha")
    got = _run_tool()
    assert got == exp


def test_alpha_unique_neg_rate_matches_replay() -> None:
    """Alpha pack should match replay unique-negative rate percentage."""
    _swap("sample_alpha")
    exp = _expected_from_fixture("sample_alpha")
    got = _run_tool()
    assert got["unique_neg_rate_pct"] == exp["unique_neg_rate_pct"]


def test_head_report_matches_replay() -> None:
    """Head pack should replay the full audit report."""
    _swap("sample_head")
    exp = _expected_from_fixture("sample_head")
    got = _run_tool()
    assert got == exp


def test_stale_report_matches_replay() -> None:
    """Stale pack should replay the full audit report."""
    _swap("sample_stale")
    exp = _expected_from_fixture("sample_stale")
    got = _run_tool()
    assert got == exp


def test_repeat_report_matches_replay() -> None:
    """Repeat pack should replay the full audit report."""
    _swap("sample_repeat")
    exp = _expected_from_fixture("sample_repeat")
    got = _run_tool()
    assert got == exp


def test_spread_report_matches_replay() -> None:
    """Spread pack should replay the full audit report including Rust fold metrics."""
    _swap("sample_spread")
    exp = _expected_from_fixture("sample_spread")
    got = _run_tool()
    assert got == exp


def test_alpha_pool_refresh_matches_replay() -> None:
    """Alpha should refresh the pool once across three epochs with ttl two."""
    _swap("sample_alpha")
    exp = _expected_from_fixture("sample_alpha")
    got = _run_tool()
    assert got["pool_refresh_count"] == exp["pool_refresh_count"]


def test_go_subsystem_tests_pass() -> None:
    """Go tests under /app must pass after the repair."""
    subprocess.run(
        [GO_BIN, "test", "./..."],
        cwd="/app",
        env={
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        },
        check=True,
    )
