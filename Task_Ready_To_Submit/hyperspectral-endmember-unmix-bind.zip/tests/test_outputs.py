"""Validate /app/output/unmix_report.json against lab.toml guardrails."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "unmix_report.json"
TILES = APP / "data" / "tiles_default.jsonl"
CFG = APP / "config" / "lab.toml"
LEGEND = APP / "data" / "tile_legend.txt"
RUN_TOOL = "/app/tools/run_replay"

_DEFAULT_TILES_TEXT = TILES.read_text(encoding="utf-8") if TILES.is_file() else ""

# contract.md: abundance fractions must sum to unity within two hundredths.
ABUNDANCE_SUM_TOLERANCE = 0.02

REPORT_KEYS = frozenset(
    {
        "status",
        "tiles_total",
        "tiles_passed",
        "max_recon_rmse",
        "abundance_violations",
        "binding_mismatches",
        "band_drop_errors",
        "saturation_clips",
        "report_digest",
        "tiles",
    }
)
ROW_KEYS = frozenset(
    {
        "tile_id",
        "scenario",
        "abundance_sum",
        "binding_row",
        "recon_rmse",
        "passed",
        "endmember_ids",
        "abundances",
        "tile_rank",
    }
)

ANCHOR_IDS = (
    "t_base_a",
    "t_base_b",
    "t_drop_a",
    "t_drop_b",
    "t_sat_a",
    "t_sat_b",
    "t_lane_c",
)


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "max_recon_rmse": 0.08,
        "max_abundance_violations": 0,
        "max_binding_mismatches": 0,
        "max_band_drop_errors": 0,
        "min_tiles_passed": 7,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key == "max_recon_rmse":
            cfg[key] = float(val)
        elif key in (
            "max_abundance_violations",
            "max_binding_mismatches",
            "max_band_drop_errors",
            "min_tiles_passed",
        ):
            cfg[key] = int(float(val))
    return cfg


def _tile_rows_from_text(text: str) -> list[dict]:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def _tile_ids_from_text(text: str) -> list[str]:
    return [row["tile_id"] for row in _tile_rows_from_text(text)]


def _tile_map_from_text(text: str) -> dict[str, dict]:
    return {row["tile_id"]: row for row in _tile_rows_from_text(text)}


def _expected_binding(row: dict) -> int:
    bind = int(row["bind_hint"])
    pack = row["pack"]
    if pack == "beta":
        bind += 1
    elif pack == "gamma":
        bind += 2
    if int(row["lane"]) > 3:
        bind += 1
    return bind


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _run_replay() -> None:
    subprocess.run(
        [RUN_TOOL],
        check=True,
        cwd=str(APP),
    )


def _load_report() -> dict:
    assert OUT.is_file(), "missing unmix report"
    return json.loads(OUT.read_text(encoding="utf-8"))


def _expected_digest(report: dict) -> str:
    payload = dict(report)
    payload["report_digest"] = ""
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


@pytest.fixture(autouse=True)
def restore_default_tiles() -> None:
    yield
    if _DEFAULT_TILES_TEXT:
        _atomic_write_text(TILES, _DEFAULT_TILES_TEXT)


@pytest.fixture(scope="session", autouse=True)
def ensure_report() -> None:
    if not OUT.is_file():
        _run_replay()


def test_report_top_level_keys() -> None:
    """Unmix report must expose the full top-level schema."""
    report = _load_report()
    assert REPORT_KEYS == set(report.keys())


def test_tiles_match_input_cardinality() -> None:
    """tiles_total and tile_id sets must match the active bundle."""
    report = _load_report()
    tiles_text = TILES.read_text(encoding="utf-8")
    expected_ids = _tile_ids_from_text(tiles_text)
    report_ids = [row["tile_id"] for row in report["tiles"]]
    assert report["tiles_total"] == len(expected_ids)
    assert len(report_ids) == len(expected_ids)
    assert set(report_ids) == set(expected_ids)


def test_baseline_abundance_sums() -> None:
    """Baseline rows must sum abundances to unity and pass."""
    report = _load_report()
    for row in report["tiles"]:
        if row["scenario"] != "baseline":
            continue
        assert abs(row["abundance_sum"] - 1.0) <= ABUNDANCE_SUM_TOLERANCE, row
        assert row["passed"], row


def test_scenario_band_drop_binding() -> None:
    """Band-drop rows must bind the correct table slice and pass RMSE gate."""
    cfg = _parse_cfg()
    report = _load_report()
    tiles = _tile_map_from_text(TILES.read_text(encoding="utf-8"))
    for row in report["tiles"]:
        if row["scenario"] != "band_drop":
            continue
        src = tiles[row["tile_id"]]
        assert row["binding_row"] == _expected_binding(src), row
        assert row["passed"], row
        assert row["recon_rmse"] <= cfg["max_recon_rmse"], row


def test_scenario_saturation_rmse() -> None:
    """Saturation rows must restore dynamic range and stay within RMSE gate."""
    cfg = _parse_cfg()
    report = _load_report()
    for row in report["tiles"]:
        if row["scenario"] != "saturation":
            continue
        assert row["passed"], row
        assert row["recon_rmse"] <= cfg["max_recon_rmse"], row
        assert row["abundance_sum"] >= 1.0 - ABUNDANCE_SUM_TOLERANCE, row


def test_binding_rows_match_hints() -> None:
    """binding_row must follow pack and bind_hint contract for every tile."""
    report = _load_report()
    tiles = _tile_map_from_text(TILES.read_text(encoding="utf-8"))
    for row in report["tiles"]:
        src = tiles[row["tile_id"]]
        assert row["binding_row"] == _expected_binding(src), row


def test_band_drop_mask_honored() -> None:
    """band_drop_errors must stay zero when masks are honored."""
    report = _load_report()
    assert report["band_drop_errors"] == 0


def test_saturation_clip_accounted() -> None:
    """Saturation scenarios must record clips and pass every row."""
    report = _load_report()
    assert report["saturation_clips"] >= 2
    sat_rows = [r for r in report["tiles"] if r["scenario"] == "saturation"]
    assert len(sat_rows) >= 2
    assert all(r["passed"] for r in sat_rows)


def test_report_digest_matches_payload() -> None:
    """report_digest must hash the compact pre-digest JSON payload."""
    report = _load_report()
    assert len(report["report_digest"]) == 64
    assert report["report_digest"] == _expected_digest(report)


def test_passing_run_contract() -> None:
    """A passing run must meet lab.toml floors with complete tile rows."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["tiles_passed"] >= cfg["min_tiles_passed"]
    assert report["max_recon_rmse"] <= cfg["max_recon_rmse"]
    assert report["abundance_violations"] <= cfg["max_abundance_violations"]
    assert report["binding_mismatches"] <= cfg["max_binding_mismatches"]
    assert report["band_drop_errors"] <= cfg["max_band_drop_errors"]
    for row in report["tiles"]:
        assert set(row.keys()) == ROW_KEYS


def test_deterministic_rerun() -> None:
    """Two back-to-back replays must emit byte-identical reports."""
    first = OUT.read_bytes()
    _run_replay()
    second = OUT.read_bytes()
    assert first == second


def test_tile_legend_anchors() -> None:
    """Named tile anchors from tile_legend.txt must appear in the bundle."""
    legend = LEGEND.read_text(encoding="utf-8")
    bundle_ids = set(_tile_ids_from_text(TILES.read_text(encoding="utf-8")))
    for tile_id in ANCHOR_IDS:
        assert tile_id in legend
        assert tile_id in bundle_ids
