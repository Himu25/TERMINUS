package j4

// N6Scale applies a saturation ceiling to reflectance values.
func N6Scale(vals []float64, ceil float64) []float64 {
	if ceil <= 0 || len(vals) == 0 {
		return append([]float64(nil), vals...)
	}
	maxV := vals[0]
	for _, v := range vals[1:] {
		if v > maxV {
			maxV = v
		}
	}
	out := make([]float64, len(vals))
	if maxV <= ceil {
		copy(out, vals)
		return out
	}
	scale := ceil / maxV
	for i, v := range vals {
		out[i] = v * scale
	}
	return out
}
