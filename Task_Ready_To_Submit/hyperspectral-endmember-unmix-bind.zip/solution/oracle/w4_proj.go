package f2

// F2Proj projects a spectrum through an active band mask.
func F2Proj(mask []int, vals []float64) []float64 {
	if len(mask) != len(vals) {
		return append([]float64(nil), vals...)
	}
	out := make([]float64, 0, len(vals))
	for i, v := range vals {
		if mask[i] != 0 {
			out = append(out, v)
		}
	}
	return out
}
