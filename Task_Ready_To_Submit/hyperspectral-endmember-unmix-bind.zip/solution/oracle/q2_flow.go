package m7

import (
	"sort"

	"hsx.remote/pkg/types"
)

// M7Flow orders tile cases before spectral replay.
func M7Flow(cases []types.TileCase) []types.TileCase {
	out := make([]types.TileCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		a, b := out[i], out[j]
		if a.Lane != b.Lane {
			return a.Lane < b.Lane
		}
		if a.BindHint != b.BindHint {
			return a.BindHint < b.BindHint
		}
		return a.TileID < b.TileID
	})
	return out
}
