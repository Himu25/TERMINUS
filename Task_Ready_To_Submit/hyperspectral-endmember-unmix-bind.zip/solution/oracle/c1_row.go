package h3

// H3Row selects the endmember binding row for a tile.
func H3Row(hint int, pack string, lane int) int {
	row := hint
	switch pack {
	case "beta":
		row = hint + 1
	case "gamma":
		row = hint + 2
	default:
		row = hint
	}
	if lane > 3 {
		row++
	}
	if row < 0 {
		return 0
	}
	return row
}
