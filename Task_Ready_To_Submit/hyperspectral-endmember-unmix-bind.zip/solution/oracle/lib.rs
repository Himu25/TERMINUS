use std::os::raw::{c_double, c_int};

#[repr(C)]
pub struct K9Out {
    pub v_err: c_double,
    pub v_sum: c_double,
    pub ok: c_int,
}

fn a9_step(em: &[Vec<f64>], obs: &[f64]) -> Vec<f64> {
    let k = em.len();
    if k == 0 || obs.is_empty() {
        return vec![0.0; k];
    }
    let n = obs.len();
    let mut ata = vec![vec![0.0f64; k]; k];
    let mut atb = vec![0.0f64; k];
    for j in 0..k {
        for i in 0..n {
            atb[j] += em[j][i] * obs[i];
        }
        for l in 0..k {
            let mut s = 0.0;
            for i in 0..n {
                s += em[j][i] * em[l][i];
            }
            ata[j][l] = s;
        }
    }
    let mut a = vec![0.0f64; k];
    for _ in 0..12 {
        for j in 0..k {
            let mut num = atb[j];
            for l in 0..k {
                if l != j {
                    num -= ata[j][l] * a[l];
                }
            }
            let den = ata[j][j].max(1e-9);
            a[j] = (num / den).max(0.0);
        }
    }
    let sum: f64 = a.iter().sum();
    if sum > 1e-12 {
        for v in &mut a {
            *v /= sum;
        }
    } else {
        a.fill(1.0 / k as f64);
    }
    a
}

fn e4_step(em: &[Vec<f64>], obs: &[f64], abund: &[f64]) -> f64 {
    if obs.is_empty() {
        return 0.0;
    }
    let mut err = 0.0;
    for i in 0..obs.len() {
        let mut recon = 0.0;
        for (j, row) in em.iter().enumerate() {
            recon += abund[j] * row[i];
        }
        let d = recon - obs[i];
        err += d * d;
    }
    (err / obs.len() as f64).sqrt()
}

#[no_mangle]
pub extern "C" fn k9_fold(
    spectrum: *const c_double,
    endmembers_flat: *const c_double,
    n_bands: c_int,
    n_em: c_int,
    abundances_out: *mut c_double,
) -> K9Out {
    let nb = n_bands.max(0) as usize;
    let ne = n_em.max(0) as usize;
    if spectrum.is_null() || endmembers_flat.is_null() || nb == 0 || ne == 0 {
        return K9Out {
            v_err: 0.0,
            v_sum: 0.0,
            ok: 0,
        };
    }
    let spec = unsafe { std::slice::from_raw_parts(spectrum, nb) };
    let flat = unsafe { std::slice::from_raw_parts(endmembers_flat, ne * nb) };
    let mut em = vec![vec![0.0f64; nb]; ne];
    for j in 0..ne {
        for i in 0..nb {
            em[j][i] = flat[j * nb + i];
        }
    }
    let abund = a9_step(&em, spec);
    let sum_ab: f64 = abund.iter().sum();
    if !abundances_out.is_null() {
        let out = unsafe { std::slice::from_raw_parts_mut(abundances_out, ne) };
        for (i, v) in abund.iter().enumerate() {
            out[i] = *v;
        }
    }
    let r = e4_step(&em, spec, &abund);
    let ok = if (sum_ab - 1.0).abs() <= 0.02 && r < 0.08 { 1 } else { 0 };
    K9Out {
        v_err: r,
        v_sum: sum_ab,
        ok,
    }
}
