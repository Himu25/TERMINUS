#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/lab.toml
require_file /app/data/tile_manifest.jsonl
require_file /app/data/endmember_table.csv
mkdir -p /app/bin /app/output

log "apply patched sources"
cp "${ROOT_DIR}/oracle/q2_flow.go" /app/m7/q2_flow.go
cp "${ROOT_DIR}/oracle/n6_scale.go" /app/j4/n6_scale.go
cp "${ROOT_DIR}/oracle/w4_proj.go" /app/f2/w4_proj.go
cp "${ROOT_DIR}/oracle/c1_row.go" /app/h3/c1_row.go
cp "${ROOT_DIR}/oracle/lib.rs" /app/r5/src/lib.rs

log "rebuild tilelab"
bash /app/scripts/build.sh

log "refresh default tile bundle"
/app/bin/tilepack /app/data/tile_manifest.jsonl /app/data/tiles_default.jsonl

log "emit unmix report"
/app/tools/run_replay

log "post-run validation against lab.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/lab.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k == "max_recon_rmse":
        cfg[k] = float(v)
    elif k.startswith("max_") or k.startswith("min_"):
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/unmix_report.json").read_text())
assert report["status"] == "ok", report
assert report["tiles_passed"] >= cfg["min_tiles_passed"]
assert report["max_recon_rmse"] <= cfg["max_recon_rmse"]
assert report["abundance_violations"] <= cfg["max_abundance_violations"]
assert report["binding_mismatches"] <= cfg["max_binding_mismatches"]
assert report["band_drop_errors"] <= cfg["max_band_drop_errors"]
for row in report["tiles"]:
    assert abs(row["abundance_sum"] - 1.0) <= 0.02, row
print("ok", report["tiles_passed"], report["max_recon_rmse"])
PY

log "oracle complete"
