package u5

// A2Fit rounds buffer capacity for manifest IO.
func A2Fit(n int) int {
	if n <= 0 {
		return 0
	}
	return ((n + 7) / 8) * 8
}
