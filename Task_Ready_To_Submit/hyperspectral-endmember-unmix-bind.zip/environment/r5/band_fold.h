#ifndef BAND_FOLD_H
#define BAND_FOLD_H

typedef struct {
    double v_err;
    double v_sum;
    int ok;
} K9Out;

K9Out k9_fold(
    const double* spectrum,
    const double* endmembers_flat,
    int n_bands,
    int n_em,
    double* abundances_out
);

#endif
