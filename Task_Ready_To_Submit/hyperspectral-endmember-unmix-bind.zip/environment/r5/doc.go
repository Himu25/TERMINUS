// Package r5 exposes the Rust spectral core via CGO.
package r5
