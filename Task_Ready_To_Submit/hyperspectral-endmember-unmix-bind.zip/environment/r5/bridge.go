package r5

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libr5_band.a -ldl -lm
#include "band_fold.h"
*/
import "C"

// Fold holds unmixing output for one tile row.
type Fold struct {
	RMSE         float64
	SumAbundance float64
	OK           bool
}

// K9Fold solves abundances and reconstruction error for one spectrum.
func K9Fold(spectrum []float64, endmembers []float64, nEM int) (Fold, []float64) {
	nb := len(spectrum)
	if nb == 0 || nEM <= 0 || len(endmembers) < nb*nEM {
		return Fold{}, nil
	}
	abund := make([]float64, nEM)
	cs := make([]C.double, nb)
	ce := make([]C.double, nb*nEM)
	for i, v := range spectrum {
		cs[i] = C.double(v)
	}
	for i, v := range endmembers[:nb*nEM] {
		ce[i] = C.double(v)
	}
	out := C.k9_fold(
		&cs[0],
		&ce[0],
		C.int(nb),
		C.int(nEM),
		(*C.double)(&abund[0]),
	)
	return Fold{
		RMSE:         float64(out.v_err),
		SumAbundance: float64(out.v_sum),
		OK:           out.ok != 0,
	}, abund
}
