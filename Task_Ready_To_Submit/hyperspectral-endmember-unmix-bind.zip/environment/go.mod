module hsx.remote

go 1.22
