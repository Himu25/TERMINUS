# Retention

Tile packs rotate weekly.
