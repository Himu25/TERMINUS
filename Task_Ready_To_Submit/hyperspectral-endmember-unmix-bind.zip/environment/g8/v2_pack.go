package g8

// V2PackRef resolves the table row index for a pack/lane wave.
func V2PackRef(hint int, pack string, lane int) int {
	row := hint
	switch pack {
	case "beta":
		row = hint + 1
	case "gamma":
		row = hint + 2
	}
	if lane > 3 {
		row++
	}
	if row < 0 {
		return 0
	}
	return row
}
