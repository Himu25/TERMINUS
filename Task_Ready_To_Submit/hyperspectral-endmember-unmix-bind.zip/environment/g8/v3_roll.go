package g8

// VxRoll totals slack reflectance for one lane wave.
func VxRoll(reserved, used float64) float64 {
	if used > reserved {
		return 0
	}
	return reserved - used
}
