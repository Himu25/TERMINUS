package h3

// H3Row selects the endmember binding row for a tile.
func H3Row(hint int, pack string, lane int) int {
	_ = hint
	_ = pack
	_ = lane
	return 0
}
