package h3

// Q0Shadow binding probe for telemetry.
func Q0Shadow(hint int) int {
	return hint % 3
}
