package f2

// F2Proj projects a spectrum through an active band mask.
func F2Proj(mask []int, vals []float64) []float64 {
	out := make([]float64, len(vals))
	copy(out, vals)
	return out
}
