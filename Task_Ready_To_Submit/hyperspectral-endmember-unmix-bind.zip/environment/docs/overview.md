# Hyperspectral tile lab

Rust spectral core (`r5`) linked through CGO into the Go driver. Tile packs live under `/app/data`; guardrails in `/app/config/lab.toml`.
