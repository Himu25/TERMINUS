# Tile replay contract

Each tile row in `/app/output/unmix_report.json` carries tile_id, scenario, abundance_sum, binding_row, recon_rmse, passed, endmember_ids, abundances, and tile_rank.

Abundance fractions for a passing row must sum to unity within two hundredths. binding_row must match the pack and bind_hint contract: alpha uses bind_hint, beta adds one, gamma adds two, and lane above three adds another increment.

Band-drop scenarios honor drop_mask: only bands with mask one enter the solver. Saturation scenarios apply sat_ceil with dynamic-range restore before unmixing.

report_digest is 64-character lowercase hex from compact pre-digest JSON with report_digest empty. Identical inputs must yield byte-identical output.
