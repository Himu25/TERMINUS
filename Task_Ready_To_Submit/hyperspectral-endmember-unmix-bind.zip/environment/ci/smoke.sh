#!/bin/bash
set -euo pipefail
test -x /app/bin/tilelab
test -f /app/config/lab.toml
