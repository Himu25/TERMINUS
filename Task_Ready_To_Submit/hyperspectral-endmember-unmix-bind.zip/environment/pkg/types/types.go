package types

type LabCfg struct {
	MaxReconRMSE        float64
	MaxAbundanceViolations int
	MaxBindingMismatches  int
	MaxBandDropErrors     int
	MinTilesPassed        int
	PackWeights           map[string]float64
}

type TileCase struct {
	TileID    string    `json:"tile_id"`
	Scenario  string    `json:"scenario"`
	Pack      string    `json:"pack"`
	Lane      int       `json:"lane"`
	BindHint  int       `json:"bind_hint"`
	Spectrum  []float64 `json:"spectrum"`
	DropMask  []int     `json:"drop_mask"`
	SatCeil   float64   `json:"sat_ceil"`
}

type TileRow struct {
	TileID        string    `json:"tile_id"`
	Scenario      string    `json:"scenario"`
	AbundanceSum  float64   `json:"abundance_sum"`
	BindingRow    int       `json:"binding_row"`
	ReconRMSE     float64   `json:"recon_rmse"`
	Passed        bool      `json:"passed"`
	EndmemberIDs  []int     `json:"endmember_ids"`
	Abundances    []float64 `json:"abundances"`
	TileRank      int       `json:"tile_rank"`
}

type UnmixReport struct {
	Status               string    `json:"status"`
	TilesTotal           int       `json:"tiles_total"`
	TilesPassed          int       `json:"tiles_passed"`
	MaxReconRMSE         float64   `json:"max_recon_rmse"`
	AbundanceViolations  int       `json:"abundance_violations"`
	BindingMismatches    int       `json:"binding_mismatches"`
	BandDropErrors       int       `json:"band_drop_errors"`
	SaturationClips      int       `json:"saturation_clips"`
	ReportDigest         string    `json:"report_digest"`
	Tiles                []TileRow `json:"tiles"`
}
