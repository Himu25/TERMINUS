package j4

// Q0Shadow peak probe for CI smoke.
func Q0Shadow(vals []float64) float64 {
	if len(vals) == 0 {
		return 0
	}
	return vals[0]
}
