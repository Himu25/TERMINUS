package j4

// N6Scale applies a saturation ceiling to reflectance values.
func N6Scale(vals []float64, ceil float64) []float64 {
	out := make([]float64, len(vals))
	for i, v := range vals {
		if v > ceil {
			out[i] = ceil
		} else {
			out[i] = v
		}
	}
	return out
}
