package m7

// Q0Flow checksum for harness notes.
func Q0Flow(lanes []int) int {
	s := 0
	for _, l := range lanes {
		s += l
	}
	return s
}
