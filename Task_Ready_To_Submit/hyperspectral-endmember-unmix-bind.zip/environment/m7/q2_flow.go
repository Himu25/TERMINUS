package m7

import (
	"sort"

	"hsx.remote/pkg/types"
)

// M7Flow orders tile cases before spectral replay.
func M7Flow(cases []types.TileCase) []types.TileCase {
	out := make([]types.TileCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		return out[i].TileID < out[j].TileID
	})
	return out
}
