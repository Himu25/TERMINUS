package summ

import "hsx.remote/pkg/types"

// SxFold folds tile rows for digest preface checksum.
func SxFold(rows []types.TileRow) int {
	sum := 0
	for _, r := range rows {
		sum += r.BindingRow + r.TileRank
	}
	return sum
}
