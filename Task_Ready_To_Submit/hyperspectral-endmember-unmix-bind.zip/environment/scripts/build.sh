#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1

mkdir -p /app/bin
cd /app/r5
cargo build --release --locked
cd /app
GOFLAGS=-mod=mod go build -o /app/bin/tilelab ./cmd/tilelab
GOFLAGS=-mod=mod go build -o /app/bin/tilepack ./cmd/tilepack
