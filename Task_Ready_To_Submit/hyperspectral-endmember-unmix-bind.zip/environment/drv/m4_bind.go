package drv

import (
	"hsx.remote/h3"
	"hsx.remote/pkg/types"
)

func pickBinding(tc types.TileCase) int {
	return h3.H3Row(tc.BindHint, tc.Pack, tc.Lane)
}
