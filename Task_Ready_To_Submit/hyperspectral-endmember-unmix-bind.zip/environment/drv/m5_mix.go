package drv

import (
	"hsx.remote/r5"
)

const nEM = 3

func solveTile(spec []float64, flat []float64) (r5.Fold, []float64) {
	return r5.K9Fold(spec, flat, nEM)
}
