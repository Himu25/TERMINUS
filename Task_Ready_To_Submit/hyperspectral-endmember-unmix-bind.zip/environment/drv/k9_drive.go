package drv

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"strings"

	"hsx.remote/g8"
	"hsx.remote/pkg/types"
	"hsx.remote/summ"
)

type EndmemberBank map[int][][]float64

func LoadCfg(path string) (types.LabCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.LabCfg{}, err
	}
	cfg := types.LabCfg{
		MaxReconRMSE:           0.08,
		MaxAbundanceViolations: 0,
		MaxBindingMismatches:   0,
		MaxBandDropErrors:      0,
		MinTilesPassed:         5,
		PackWeights:            map[string]float64{"alpha": 1.0, "beta": 1.0, "gamma": 1.0},
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "max_recon_rmse":
			fmt.Sscanf(val, "%f", &cfg.MaxReconRMSE)
		case "max_abundance_violations":
			fmt.Sscanf(val, "%d", &cfg.MaxAbundanceViolations)
		case "max_binding_mismatches":
			fmt.Sscanf(val, "%d", &cfg.MaxBindingMismatches)
		case "max_band_drop_errors":
			fmt.Sscanf(val, "%d", &cfg.MaxBandDropErrors)
		case "min_tiles_passed":
			fmt.Sscanf(val, "%d", &cfg.MinTilesPassed)
		case "pack_weight_alpha":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.PackWeights["alpha"] = w
		case "pack_weight_beta":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.PackWeights["beta"] = w
		case "pack_weight_gamma":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.PackWeights["gamma"] = w
		}
	}
	return cfg, nil
}

func LoadEndmemberBank(path string) (EndmemberBank, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	bank := make(EndmemberBank)
	for i, row := range rows {
		if i == 0 || len(row) < 7 {
			continue
		}
		var bindRow, emIdx int
		fmt.Sscanf(strings.TrimSpace(row[0]), "%d", &bindRow)
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &emIdx)
		bands := make([]float64, 5)
		for b := 0; b < 5; b++ {
			fmt.Sscanf(strings.TrimSpace(row[2+b]), "%f", &bands[b])
		}
		if emIdx == 0 {
			bank[bindRow] = make([][]float64, 0, nEM)
		}
		bank[bindRow] = append(bank[bindRow], bands)
	}
	return bank, nil
}

func LoadTileCases(path string) ([]types.TileCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.TileCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var tc types.TileCase
		if err := json.Unmarshal([]byte(line), &tc); err != nil {
			return nil, err
		}
		if tc.SatCeil <= 0 {
			tc.SatCeil = 1.0
		}
		if len(tc.DropMask) == 0 {
			tc.DropMask = []int{1, 1, 1, 1, 1}
		}
		out = append(out, tc)
	}
	return out, sc.Err()
}

func maskEndmembers(em [][]float64, mask []int) [][]float64 {
	out := make([][]float64, len(em))
	for j, row := range em {
		cur := make([]float64, 0, len(row))
		for i, v := range row {
			if i < len(mask) && mask[i] != 0 {
				cur = append(cur, v)
			}
		}
		out[j] = cur
	}
	return out
}

func flattenEndmembers(em [][]float64) []float64 {
	if len(em) == 0 {
		return nil
	}
	nb := len(em[0])
	flat := make([]float64, len(em)*nb)
	for j, row := range em {
		for i, v := range row {
			flat[j*nb+i] = v
		}
	}
	return flat
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

func Run(cfg types.LabCfg, cases []types.TileCase, bank EndmemberBank) (types.UnmixReport, error) {
	ordered := orderCases(cases)
	report := types.UnmixReport{
		Status:     "ok",
		TilesTotal: len(ordered),
	}
	report.Tiles = make([]types.TileRow, 0, len(ordered))
	var passed, abundViol, bindMiss, dropErr, satClips int
	maxRMSE := 0.0

	for idx, tc := range ordered {
		spec := append([]float64(nil), tc.Spectrum...)
		spec, satScale, clipped := applySaturation(tc, spec)
		if clipped {
			satClips++
		}
		maskedSpec := projectBands(tc.DropMask, spec)
		if satScale != 1.0 {
			for i := range maskedSpec {
				maskedSpec[i] /= satScale
			}
		}
		bindRow := pickBinding(tc)
		expectBind := g8.V2PackRef(tc.BindHint, tc.Pack, tc.Lane)
		if bindRow != expectBind {
			bindMiss++
		}
		emFull, ok := bank[bindRow]
		if !ok || len(emFull) < nEM {
			bindMiss++
			emFull = bank[0]
		}
		emUse := maskEndmembers(emFull, tc.DropMask)
		if len(maskedSpec) != len(emUse[0]) {
			dropErr++
		}
		flat := flattenEndmembers(emUse)
		fold, abund := solveTile(maskedSpec, flat)
		sumAb := fold.SumAbundance
		if math.Abs(sumAb-1.0) > 0.02 {
			abundViol++
		}
		rowOK := fold.OK && math.Abs(sumAb-1.0) <= 0.02 && bindRow == expectBind && len(maskedSpec) == len(emUse[0])
		if fold.RMSE > maxRMSE {
			maxRMSE = fold.RMSE
		}
		_ = g8.VxRoll(1.0, sumAb)
		emIDs := make([]int, nEM)
		for i := range emIDs {
			emIDs[i] = i
		}
		if rowOK {
			passed++
		}
		report.Tiles = append(report.Tiles, types.TileRow{
			TileID:       tc.TileID,
			Scenario:     tc.Scenario,
			AbundanceSum: round4(sumAb),
			BindingRow:   bindRow,
			ReconRMSE:    round4(fold.RMSE),
			Passed:       rowOK,
			EndmemberIDs: emIDs,
			Abundances:   roundSlice(abund),
			TileRank:     idx + 1,
		})
	}

	report.TilesPassed = passed
	report.MaxReconRMSE = round4(maxRMSE)
	report.AbundanceViolations = abundViol
	report.BindingMismatches = bindMiss
	report.BandDropErrors = dropErr
	report.SaturationClips = satClips
	if !meetsFloors(cfg, report) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func roundSlice(vals []float64) []float64 {
	out := make([]float64, len(vals))
	for i, v := range vals {
		out[i] = round4(v)
	}
	return out
}

func meetsFloors(cfg types.LabCfg, report types.UnmixReport) bool {
	if report.TilesPassed < cfg.MinTilesPassed {
		return false
	}
	if report.MaxReconRMSE > cfg.MaxReconRMSE {
		return false
	}
	if report.AbundanceViolations > cfg.MaxAbundanceViolations {
		return false
	}
	if report.BindingMismatches > cfg.MaxBindingMismatches {
		return false
	}
	if report.BandDropErrors > cfg.MaxBandDropErrors {
		return false
	}
	for _, row := range report.Tiles {
		if strings.HasPrefix(row.TileID, "t_drop_") && row.Passed && row.ReconRMSE > cfg.MaxReconRMSE {
			return false
		}
		if strings.HasPrefix(row.TileID, "t_sat_") && row.Passed && row.AbundanceSum < 0.98 {
			return false
		}
	}
	_ = summ.SxFold(report.Tiles)
	return true
}

type digestPayload struct {
	Status              string          `json:"status"`
	TilesTotal          int             `json:"tiles_total"`
	TilesPassed         int             `json:"tiles_passed"`
	MaxReconRMSE        float64         `json:"max_recon_rmse"`
	AbundanceViolations int             `json:"abundance_violations"`
	BindingMismatches   int             `json:"binding_mismatches"`
	BandDropErrors      int             `json:"band_drop_errors"`
	SaturationClips     int             `json:"saturation_clips"`
	ReportDigest        string          `json:"report_digest"`
	Tiles               []types.TileRow `json:"tiles"`
}

func digestBody(report types.UnmixReport) string {
	payload := digestPayload{
		Status:              report.Status,
		TilesTotal:          report.TilesTotal,
		TilesPassed:         report.TilesPassed,
		MaxReconRMSE:        report.MaxReconRMSE,
		AbundanceViolations: report.AbundanceViolations,
		BindingMismatches:   report.BindingMismatches,
		BandDropErrors:      report.BandDropErrors,
		SaturationClips:     report.SaturationClips,
		ReportDigest:        "",
		Tiles:               report.Tiles,
	}
	raw, err := marshalDigestJSON(payload)
	if err != nil {
		return ""
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func marshalDigestJSON(payload digestPayload) ([]byte, error) {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return nil, err
	}
	b := buf.Bytes()
	if n := len(b); n > 0 && b[n-1] == '\n' {
		b = b[:n-1]
	}
	return b, nil
}

func WriteReport(path string, report types.UnmixReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}
