package drv

import (
	"hsx.remote/f2"
)

func projectBands(mask []int, spec []float64) []float64 {
	return f2.F2Proj(mask, spec)
}
