package drv

import (
	"hsx.remote/j4"
	"hsx.remote/pkg/types"
)

func applySaturation(tc types.TileCase, spec []float64) ([]float64, float64, bool) {
	if tc.Scenario != "saturation" {
		return spec, 1.0, false
	}
	beforeMax := spec[0]
	for _, v := range spec[1:] {
		if v > beforeMax {
			beforeMax = v
		}
	}
	out := j4.N6Scale(spec, tc.SatCeil)
	scale := 1.0
	if beforeMax > tc.SatCeil {
		scale = tc.SatCeil / beforeMax
	}
	return out, scale, beforeMax > tc.SatCeil
}
