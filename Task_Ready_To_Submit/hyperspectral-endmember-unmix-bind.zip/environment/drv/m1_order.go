package drv

import (
	"hsx.remote/m7"
	"hsx.remote/pkg/types"
)

func orderCases(cases []types.TileCase) []types.TileCase {
	return m7.M7Flow(cases)
}
