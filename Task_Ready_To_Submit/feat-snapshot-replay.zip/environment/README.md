Offline catalog snapshot replay workspace.

Build: `/app/scripts/build.sh`
Run: `tb_pack=<stem> /app/bin/featrebuild`
