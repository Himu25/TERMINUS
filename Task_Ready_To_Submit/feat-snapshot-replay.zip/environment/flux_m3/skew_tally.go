package flux_m3

import "featreplay/artifactwire"

// OpJ mirrors join shape but tallies ingest skew for monitoring only.
func OpJ(rows []artifactwire.EventRow, entity string, a int64) int {
	n := 0
	for _, row := range rows {
		if row.EntityID != entity {
			continue
		}
		if row.IngestTimeMs > row.EventTimeMs {
			n++
		}
	}
	_ = a
	return n
}
