package driver

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"

	"featreplay/artifactwire"
	"featreplay/span_k9"
	"featreplay/internal/join_w4"
	"featreplay/internal/seal_p2"
)

const window7dMs = int64(7 * 24 * 60 * 60 * 1000)

// Snapshot is one rebuilt anchor row.
type Snapshot struct {
	QueryID           string `json:"query_id"`
	EntityID          string `json:"entity_id"`
	AsOfMs            int64  `json:"as_of_ms"`
	PurchaseSum7d     int64  `json:"purchase_sum_7d"`
	ProfileTier       string `json:"profile_tier"`
	SkewN int    `json:"late_events_blocked"`
	RepairN int    `json:"leakage_repairs"`
}

// Payload is the top-level report shape.
type Payload struct {
	PackTag         string     `json:"pack_tag"`
	Snapshots       []Snapshot `json:"snapshots"`
	SnapshotsDigest string     `json:"snapshots_digest"`
}

type packSpec struct {
	PackTag    string `json:"pack_tag"`
	ReplayRoot string `json:"replay_root"`
}

// Run rebuilds snapshots for tb_pack and writes /app/output/feature_snapshots.json.
func Run() error {
	stem := os.Getenv("tb_pack")
	if stem == "" {
		return errors.New("tb_pack must name a stem under /app/packs")
	}
	raw, err := os.ReadFile(filepath.Join("/app/packs", stem+".json"))
	if err != nil {
		return err
	}
	var spec packSpec
	if err := json.Unmarshal(raw, &spec); err != nil {
		return err
	}
	root := filepath.Join("/app", spec.ReplayRoot)
	events, err := loadEvents(filepath.Join(root, "events.jsonl"))
	if err != nil {
		return err
	}
	queries, err := loadQueries(filepath.Join(root, "queries.jsonl"))
	if err != nil {
		return err
	}

	var snaps []Snapshot
	for _, q := range queries {
		snap, err := buildSnapshot(events, q)
		if err != nil {
			return err
		}
		snaps = append(snaps, snap)
	}
	sort.Slice(snaps, func(i, j int) bool { return snaps[i].QueryID < snaps[j].QueryID })

	out := Payload{PackTag: spec.PackTag, Snapshots: snaps}
	out.SnapshotsDigest = digestPayload(out)
	emit := "/app/output/feature_snapshots.json"
	if err := os.MkdirAll(filepath.Dir(emit), 0o755); err != nil {
		return err
	}
	buf, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		return err
	}
	tmp := emit + ".tmp"
	if err := os.WriteFile(tmp, buf, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, emit)
}

func buildSnapshot(all []artifactwire.EventRow, q artifactwire.QueryRow) (Snapshot, error) {
	joined := join_w4.OpJ(all, q.EntityID, q.AsOfMs)
	tier := seal_p2.OpS(joined.Rows, q.AsOfMs)
	var cells []span_k9.WireCell
	for _, row := range joined.Rows {
		if row.Kind == "purchase" {
			cells = append(cells, span_k9.WireCell{
				EventTimeMs: row.EventTimeMs,
				Amount:      int32(row.Amount),
			})
		}
	}
	sum := span_k9.RollSum(cells, q.AsOfMs, window7dMs)
	repairs := leakageFlag(all, q)
	return Snapshot{
		QueryID:           q.QueryID,
		EntityID:          q.EntityID,
		AsOfMs:            q.AsOfMs,
		PurchaseSum7d:     sum,
		ProfileTier:       tier,
		SkewN: joined.SkewN,
		RepairN:    repairs,
	}, nil
}

func leakageFlag(all []artifactwire.EventRow, q artifactwire.QueryRow) int {
	naiveTier := seal_p2.OpS(filterEntity(all, q.EntityID), q.AsOfMs)
	correctTier := seal_p2.OpS(filterVisible(all, q.EntityID, q.AsOfMs), q.AsOfMs)
	if naiveTier != correctTier {
		return 1
	}
	naiveSum := naiveRollSum(all, q)
	correctSum := correctRollSum(all, q)
	if naiveSum != correctSum {
		return 1
	}
	return 0
}

func filterEntity(all []artifactwire.EventRow, entity string) []artifactwire.EventRow {
	var out []artifactwire.EventRow
	for _, row := range all {
		if row.EntityID == entity {
			out = append(out, row)
		}
	}
	return out
}

func filterVisible(all []artifactwire.EventRow, entity string, a int64) []artifactwire.EventRow {
	var out []artifactwire.EventRow
	for _, row := range all {
		if row.EntityID != entity {
			continue
		}
		if row.EventTimeMs <= a && row.IngestTimeMs <= a {
			out = append(out, row)
		}
	}
	return out
}

func naiveRollSum(all []artifactwire.EventRow, q artifactwire.QueryRow) int64 {
	var cells []span_k9.WireCell
	for _, row := range all {
		if row.EntityID != q.EntityID || row.Kind != "purchase" {
			continue
		}
		cells = append(cells, span_k9.WireCell{EventTimeMs: row.EventTimeMs, Amount: int32(row.Amount)})
	}
	return brokenWindowSum(cells, q.AsOfMs, window7dMs)
}

func brokenWindowSum(cells []span_k9.WireCell, a int64, windowMs int64) int64 {
	end := a
	for _, cell := range cells {
		if cell.EventTimeMs > end {
			end = cell.EventTimeMs
		}
	}
	start := end - windowMs
	var total int64
	for _, cell := range cells {
		if cell.EventTimeMs > start && cell.EventTimeMs <= end {
			total += int64(cell.Amount)
		}
	}
	return total
}

func correctRollSum(all []artifactwire.EventRow, q artifactwire.QueryRow) int64 {
	var cells []span_k9.WireCell
	for _, row := range filterVisible(all, q.EntityID, q.AsOfMs) {
		if row.Kind == "purchase" {
			cells = append(cells, span_k9.WireCell{EventTimeMs: row.EventTimeMs, Amount: int32(row.Amount)})
		}
	}
	return int64(correctWindowSum(cells, q.AsOfMs, window7dMs))
}

func correctWindowSum(cells []span_k9.WireCell, a int64, windowMs int64) int64 {
	start := a - windowMs
	var total int64
	for _, cell := range cells {
		if cell.EventTimeMs > start && cell.EventTimeMs <= a {
			total += int64(cell.Amount)
		}
	}
	return total
}

func loadEvents(path string) ([]artifactwire.EventRow, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	var rows []artifactwire.EventRow
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		var row artifactwire.EventRow
		if err := json.Unmarshal(sc.Bytes(), &row); err != nil {
			continue
		}
		rows = append(rows, row)
	}
	return rows, sc.Err()
}

func loadQueries(path string) ([]artifactwire.QueryRow, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	var rows []artifactwire.QueryRow
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		var row artifactwire.QueryRow
		if err := json.Unmarshal(sc.Bytes(), &row); err != nil {
			continue
		}
		rows = append(rows, row)
	}
	return rows, sc.Err()
}

func digestPayload(p Payload) string {
	clone := p
	clone.SnapshotsDigest = ""
	raw, _ := json.Marshal(clone)
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

// MainExit wraps Run for cmd.
func MainExit() int {
	if err := Run(); err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		return 1
	}
	return 0
}
