package ridge_w2

import "featreplay/artifactwire"

func mergeStep(left string, right string) string {
	if right == "" {
		return left
	}
	if left == "" {
		return right
	}
	if right > left {
		return right
	}
	return left
}

// PickStable chooses one profile label among rows sharing the same event timestamp.
func PickStable(rows []artifactwire.EventRow) string {
	var tier string
	for _, row := range rows {
		tier = mergeStep(tier, row.Tier)
	}
	return tier
}
