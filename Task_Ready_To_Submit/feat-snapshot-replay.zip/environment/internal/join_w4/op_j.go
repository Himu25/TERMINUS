package join_w4

import "featreplay/artifactwire"

// JoinResult holds rows visible at an anchor plus a skew tally.
type JoinResult struct {
	Rows  []artifactwire.EventRow
	SkewN int
}

func idScope(all []artifactwire.EventRow, entity string) []artifactwire.EventRow {
	var scoped []artifactwire.EventRow
	for _, row := range all {
		if row.EntityID == entity {
			scoped = append(scoped, row)
		}
	}
	return scoped
}

func gateA(row artifactwire.EventRow, a int64) bool {
	return row.EventTimeMs <= a
}

func gateB(row artifactwire.EventRow, a int64) bool {
	return row.IngestTimeMs <= a
}

func skewFlag(row artifactwire.EventRow, a int64) bool {
	return row.EventTimeMs <= a && row.IngestTimeMs > a
}

func appendVisible(out []artifactwire.EventRow, row artifactwire.EventRow) []artifactwire.EventRow {
	return append(out, row)
}

// OpJ selects entity rows for replay at anchor a.
func OpJ(all []artifactwire.EventRow, entity string, a int64) JoinResult {
	scoped := idScope(all, entity)
	var out []artifactwire.EventRow
	for _, row := range scoped {
		if !gateA(row, a) {
			continue
		}
		out = appendVisible(out, row)
	}
	return JoinResult{Rows: out}
}
