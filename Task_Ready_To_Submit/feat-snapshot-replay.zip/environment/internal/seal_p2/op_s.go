package seal_p2

import "featreplay/artifactwire"

func rowKind(rows []artifactwire.EventRow) []artifactwire.EventRow {
	var out []artifactwire.EventRow
	for _, row := range rows {
		if row.Kind == "profile" {
			out = append(out, row)
		}
	}
	return out
}

func cmpRank(left string, right string) string {
	if right == "" {
		return left
	}
	if left == "" {
		return right
	}
	if right > left {
		return right
	}
	return left
}

func scanHead(rows []artifactwire.EventRow, a int64) int64 {
	var head int64 = -1
	for _, row := range rows {
		if row.EventTimeMs > a {
			continue
		}
		if row.EventTimeMs > head {
			head = row.EventTimeMs
		}
	}
	return head
}

func pickMax(rows []artifactwire.EventRow, a int64) string {
	head := scanHead(rows, a)
	var tier string
	for _, row := range rows {
		if row.EventTimeMs > a {
			continue
		}
		if row.EventTimeMs < head {
			continue
		}
		tier = cmpRank(tier, row.Tier)
	}
	return tier
}

// OpS resolves the profile label visible at anchor a.
func OpS(rows []artifactwire.EventRow, a int64) string {
	profiles := rowKind(rows)
	return pickMax(profiles, a)
}
