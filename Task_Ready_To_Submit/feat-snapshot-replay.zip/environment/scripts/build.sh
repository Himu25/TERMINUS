#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/app/output/cargo-target}"

mkdir -p /app/bin /app/output/cargo-target
cd /app/span_k9
ln -sfn "${CARGO_TARGET_DIR}" target
cargo build --release
test -f target/release/libspan_k9.a
cd /app
GOFLAGS=-mod=mod go build -o /app/bin/featrebuild ./cmd/featrebuild
test -x /app/bin/featrebuild
