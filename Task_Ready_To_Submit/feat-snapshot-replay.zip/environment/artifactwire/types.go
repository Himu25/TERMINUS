package artifactwire

// EventRow is one raw catalog event.
type EventRow struct {
	EntityID     string `json:"entity_id"`
	EventTimeMs  int64  `json:"event_time_ms"`
	IngestTimeMs int64  `json:"ingest_time_ms"`
	Kind         string `json:"kind"`
	Amount       int    `json:"amount,omitempty"`
	Tier         string `json:"tier,omitempty"`
}

// QueryRow is one anchor request.
type QueryRow struct {
	QueryID  string `json:"query_id"`
	EntityID string `json:"entity_id"`
	AsOfMs   int64  `json:"as_of_ms"`
}
