package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
)

func main() {
	var payload map[string]any
	if err := json.NewDecoder(os.Stdin).Decode(&payload); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	delete(payload, "snapshots_digest")
	raw, _ := json.Marshal(payload)
	sum := sha256.Sum256(raw)
	fmt.Println(hex.EncodeToString(sum[:]))
}
