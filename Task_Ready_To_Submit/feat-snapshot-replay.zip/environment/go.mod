module featreplay

go 1.22
