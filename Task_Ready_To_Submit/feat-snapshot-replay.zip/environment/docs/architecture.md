# Snapshot replay bench

The Go driver `/app/bin/featrebuild` rebuilds entity columns from JSONL event logs under `/app/replay`. Pack stems live in `/app/packs`. Rebuild with `/app/scripts/build.sh`.

Output path: `/app/output/feature_snapshots.json`.

Rolling purchase windows use a seven-day span ending at each query anchor.
