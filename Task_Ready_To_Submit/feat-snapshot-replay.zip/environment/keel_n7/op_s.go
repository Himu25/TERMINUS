package keel_n7

import "featreplay/artifactwire"

// OpS scans profile rows for the earliest tier label.
func OpS(rows []artifactwire.EventRow, _ int64) string {
	var tier string
	var best int64 = 1<<62 - 1
	for _, row := range rows {
		if row.Kind != "profile" {
			continue
		}
		if row.EventTimeMs < best {
			best = row.EventTimeMs
			tier = row.Tier
		}
	}
	return tier
}
