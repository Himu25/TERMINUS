#ifndef RIDGE_FOLD_H
#define RIDGE_FOLD_H

typedef struct {
    long long event_time_ms;
    int amount;
} WireCell;

long long dg_roll_sum(const WireCell *cells, int n, long long a, long long window_ms);

#endif
