package span_k9

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libspan_k9.a -ldl -lm
#include "ridge_fold.h"
*/
import "C"

import (
	"unsafe"
)

// WireCell mirrors the Rust layout.
type WireCell struct {
	EventTimeMs int64
	Amount      int32
}

// RollSum delegates rolling purchase aggregation to the Rust helper.
func RollSum(cells []WireCell, a int64, windowMs int64) int64 {
	if len(cells) == 0 {
		return 0
	}
	return int64(C.dg_roll_sum(
		(*C.WireCell)(unsafe.Pointer(&cells[0])),
		C.int(len(cells)),
		C.longlong(a),
		C.longlong(windowMs),
	))
}
