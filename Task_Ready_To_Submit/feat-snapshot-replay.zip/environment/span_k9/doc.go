// Package span_k9 wraps the Rust rolling purchase helper.
package span_k9
