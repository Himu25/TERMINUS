use std::slice;

#[repr(C)]
pub struct WireCell {
    pub event_time_ms: i64,
    pub amount: i32,
}

fn scanTail(cells: &[WireCell], anchor: i64) -> i64 {
    let mut end = anchor;
    for cell in cells {
        if cell.event_time_ms > end {
            end = cell.event_time_ms;
        }
    }
    end
}

fn boundHi(cells: &[WireCell], anchor: i64) -> i64 {
    scanTail(cells, anchor)
}

fn boundLo(end: i64, window_ms: i64) -> i64 {
    end - window_ms
}

fn cellIn(cell: &WireCell, start: i64, end: i64) -> bool {
    cell.event_time_ms > start && cell.event_time_ms <= end
}

fn tally(cells: &[WireCell], start: i64, end: i64) -> i64 {
    let mut total: i64 = 0;
    for cell in cells {
        if cellIn(cell, start, end) {
            total += cell.amount as i64;
        }
    }
    total
}

/// Rolling purchase sum over window_ms ending at anchor a.
#[no_mangle]
pub extern "C" fn dg_roll_sum(cells: *const WireCell, n: i32, a: i64, window_ms: i64) -> i64 {
    if cells.is_null() || n <= 0 {
        return 0;
    }
    let slice = unsafe { slice::from_raw_parts(cells, n as usize) };
    let end = boundHi(slice, a);
    let start = boundLo(end, window_ms);
    tally(slice, start, end)
}
