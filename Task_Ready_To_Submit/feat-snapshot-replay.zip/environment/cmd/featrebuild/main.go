// featrebuild reconstructs entity snapshot columns from raw replay logs.
//
// Invoke with tb_pack set to a stem under /app/packs.
// Output /app/output/feature_snapshots.json carries pack_tag, snapshots sorted
// by query_id, and snapshots_digest.
//
// Each snapshot object includes query_id, entity_id, as_of_ms, purchase_sum_7d,
// profile_tier, late_events_blocked, and leakage_repairs.
//
// Identical tb_pack replays emit byte-identical reports.
package main

import (
	"os"

	"featreplay/internal/driver"
)

func main() {
	os.Exit(driver.MainExit())
}
