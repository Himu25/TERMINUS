#!/bin/bash
set -euo pipefail
tb_pack=pack_alpha /app/bin/featrebuild
test -s /app/output/feature_snapshots.json
