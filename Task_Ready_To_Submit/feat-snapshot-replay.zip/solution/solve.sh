#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/internal/join_w4/op_j.go <<'EOF'
package join_w4

import "featreplay/artifactwire"

// JoinResult holds rows visible at an anchor plus a skew tally.
type JoinResult struct {
	Rows  []artifactwire.EventRow
	SkewN int
}

func idScope(all []artifactwire.EventRow, entity string) []artifactwire.EventRow {
	var scoped []artifactwire.EventRow
	for _, row := range all {
		if row.EntityID == entity {
			scoped = append(scoped, row)
		}
	}
	return scoped
}

func gateA(row artifactwire.EventRow, a int64) bool {
	return row.EventTimeMs <= a
}

func gateB(row artifactwire.EventRow, a int64) bool {
	return row.IngestTimeMs <= a
}

func skewFlag(row artifactwire.EventRow, a int64) bool {
	return row.EventTimeMs <= a && row.IngestTimeMs > a
}

func appendVisible(out []artifactwire.EventRow, row artifactwire.EventRow) []artifactwire.EventRow {
	return append(out, row)
}

// OpJ selects entity rows for replay at anchor a.
func OpJ(all []artifactwire.EventRow, entity string, a int64) JoinResult {
	scoped := idScope(all, entity)
	var out []artifactwire.EventRow
	skew := 0
	for _, row := range scoped {
		if !gateA(row, a) {
			continue
		}
		if !gateB(row, a) {
			if skewFlag(row, a) {
				skew++
			}
			continue
		}
		out = appendVisible(out, row)
	}
	return JoinResult{Rows: out, SkewN: skew}
}
EOF

cat > /app/internal/seal_p2/op_s.go <<'EOF'
package seal_p2

import (
	"featreplay/artifactwire"
	"featreplay/internal/ridge_w2"
)

func rowKind(rows []artifactwire.EventRow) []artifactwire.EventRow {
	var out []artifactwire.EventRow
	for _, row := range rows {
		if row.Kind == "profile" {
			out = append(out, row)
		}
	}
	return out
}

func cmpRank(left string, right string) string {
	if right == "" {
		return left
	}
	if left == "" {
		return right
	}
	if right > left {
		return right
	}
	return left
}

func scanHead(rows []artifactwire.EventRow, a int64) int64 {
	var head int64 = -1
	for _, row := range rows {
		if row.EventTimeMs > a {
			continue
		}
		if row.EventTimeMs > head {
			head = row.EventTimeMs
		}
	}
	return head
}

func collectTied(rows []artifactwire.EventRow, a int64, head int64) []artifactwire.EventRow {
	var tied []artifactwire.EventRow
	for _, row := range rows {
		if row.EventTimeMs > a {
			continue
		}
		if row.EventTimeMs < head {
			continue
		}
		tied = append(tied, row)
	}
	return tied
}

func pickMax(rows []artifactwire.EventRow, a int64) string {
	head := scanHead(rows, a)
	return ridge_w2.PickStable(collectTied(rows, a, head))
}

// OpS resolves the profile label visible at anchor a.
func OpS(rows []artifactwire.EventRow, a int64) string {
	profiles := rowKind(rows)
	return pickMax(profiles, a)
}
EOF

cat > /app/internal/ridge_w2/tie_q.go <<'EOF'
package ridge_w2

import "featreplay/artifactwire"

// PickStable chooses one profile label among rows sharing the same event timestamp.
func PickStable(rows []artifactwire.EventRow) string {
	var tier string
	var best int64 = -1
	for _, row := range rows {
		if row.IngestTimeMs > best {
			best = row.IngestTimeMs
			tier = row.Tier
		}
	}
	return tier
}
EOF

cat > /app/span_k9/src/lib.rs <<'EOF'
use std::slice;

#[repr(C)]
pub struct WireCell {
    pub event_time_ms: i64,
    pub amount: i32,
}

fn scanTail(_cells: &[WireCell], anchor: i64) -> i64 {
    anchor
}

fn boundHi(cells: &[WireCell], anchor: i64) -> i64 {
    scanTail(cells, anchor)
}

fn boundLo(end: i64, window_ms: i64) -> i64 {
    end - window_ms
}

fn cellIn(cell: &WireCell, start: i64, end: i64) -> bool {
    cell.event_time_ms > start && cell.event_time_ms <= end
}

fn addAmount(total: i64, cell: &WireCell) -> i64 {
    total + cell.amount as i64
}

fn tally(cells: &[WireCell], start: i64, end: i64) -> i64 {
    let mut total: i64 = 0;
    for cell in cells {
        if cellIn(cell, start, end) {
            total = addAmount(total, cell);
        }
    }
    total
}

/// Rolling purchase sum over window_ms ending at anchor a.
#[no_mangle]
pub extern "C" fn dg_roll_sum(cells: *const WireCell, n: i32, a: i64, window_ms: i64) -> i64 {
    if cells.is_null() || n <= 0 {
        return 0;
    }
    let slice = unsafe { slice::from_raw_parts(cells, n as usize) };
    let end = boundHi(slice, a);
    let start = boundLo(end, window_ms);
    tally(slice, start, end)
}
EOF

bash /app/scripts/build.sh
tb_pack=pack_alpha /app/bin/featrebuild
test -s /app/output/feature_snapshots.json
