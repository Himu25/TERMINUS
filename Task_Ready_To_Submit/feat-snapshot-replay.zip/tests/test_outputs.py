"""Verifier for feature snapshot replay reports."""

from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

APP = Path("/app")
REPORT = APP / "output" / "feature_snapshots.json"
FIXTURES = Path(__file__).resolve().parent / "fixtures"

WINDOW_7D_MS = 7 * 24 * 60 * 60 * 1000

_PACK_ROOT = {
    "pack_alpha": "pack_alpha",
    "pack_beta": "pack_beta",
    "pack_gamma": "pack_gamma",
    "pack_delta": "pack_delta",
    "pack_peak": "pack_peak",
    "pack_frost": "pack_frost",
    "pack_canyon": "pack_canyon",
}


def _fixture_root(stem: str) -> Path:
    return FIXTURES / "replay" / _PACK_ROOT[stem]


def _pack_tag(stem: str) -> str:
    spec = json.loads((FIXTURES / "packs" / f"{stem}.json").read_text(encoding="utf-8"))
    return str(spec["pack_tag"])


def _load_jsonl(path: Path) -> list[dict]:
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return rows


def _visible(events: list[dict], entity: str, as_of: int) -> list[dict]:
    out = []
    for row in events:
        if row["entity_id"] != entity:
            continue
        if row["event_time_ms"] <= as_of and row["ingest_time_ms"] <= as_of:
            out.append(row)
    return out


def _late_blocked(events: list[dict], entity: str, as_of: int) -> int:
    n = 0
    for row in events:
        if row["entity_id"] != entity:
            continue
        if row["event_time_ms"] <= as_of and row["ingest_time_ms"] > as_of:
            n += 1
    return n


def _profile_tier(rows: list[dict], as_of: int) -> str:
    head = -1
    for row in rows:
        if row.get("kind") != "profile":
            continue
        if row["event_time_ms"] <= as_of and row["event_time_ms"] > head:
            head = row["event_time_ms"]
    tier = ""
    best_ingest = -1
    for row in rows:
        if row.get("kind") != "profile":
            continue
        if row["event_time_ms"] <= as_of and row["event_time_ms"] == head:
            if row["ingest_time_ms"] > best_ingest:
                best_ingest = row["ingest_time_ms"]
                tier = str(row.get("tier", ""))
    return tier


def _purchase_sum(rows: list[dict], as_of: int) -> int:
    start = as_of - WINDOW_7D_MS
    total = 0
    for row in rows:
        if row.get("kind") != "purchase":
            continue
        t = row["event_time_ms"]
        if start < t <= as_of:
            total += int(row.get("amount", 0))
    return total


def _naive_tier(events: list[dict], entity: str, as_of: int) -> str:
    joined = [r for r in events if r["entity_id"] == entity and r["event_time_ms"] <= as_of]
    head = -1
    for row in joined:
        if row.get("kind") != "profile":
            continue
        if row["event_time_ms"] > head:
            head = row["event_time_ms"]
    tier = ""
    for row in joined:
        if row.get("kind") != "profile":
            continue
        if row["event_time_ms"] < head:
            continue
        label = str(row.get("tier", ""))
        if label > tier:
            tier = label
    return tier


def _naive_sum(events: list[dict], entity: str, as_of: int) -> int:
    purchases = [
        r for r in events if r["entity_id"] == entity and r.get("kind") == "purchase"
    ]
    end = max((r["event_time_ms"] for r in purchases), default=as_of)
    start = end - WINDOW_7D_MS
    total = 0
    for row in purchases:
        t = row["event_time_ms"]
        if start < t <= end:
            total += int(row.get("amount", 0))
    return total


def _leakage_repairs(events: list[dict], entity: str, as_of: int) -> int:
    vis = _visible(events, entity, as_of)
    if _naive_tier(events, entity, as_of) != _profile_tier(vis, as_of):
        return 1
    if _naive_sum(events, entity, as_of) != _purchase_sum(vis, as_of):
        return 1
    return 0


def _expected_snapshot(events: list[dict], query: dict) -> dict:
    entity = query["entity_id"]
    as_of = int(query["as_of_ms"])
    vis = _visible(events, entity, as_of)
    return {
        "query_id": query["query_id"],
        "entity_id": entity,
        "as_of_ms": as_of,
        "purchase_sum_7d": _purchase_sum(vis, as_of),
        "profile_tier": _profile_tier(vis, as_of),
        "late_events_blocked": _late_blocked(events, entity, as_of),
        "leakage_repairs": _leakage_repairs(events, entity, as_of),
    }


def _drive(stem: str) -> dict:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    if REPORT.exists():
        REPORT.unlink()
    subprocess.run(
        ["/app/bin/featrebuild"],
        cwd=str(APP),
        env={**os.environ, "tb_pack": stem},
        check=True,
    )
    payload = json.loads(REPORT.read_text(encoding="utf-8"))
    assert payload["pack_tag"] == _pack_tag(stem)
    digest = payload["snapshots_digest"]
    assert isinstance(digest, str) and re.fullmatch(r"[0-9a-f]{64}", digest)
    return payload


def _snap(payload: dict, query_id: str) -> dict:
    for row in payload["snapshots"]:
        if row["query_id"] == query_id:
            return row
    raise AssertionError(query_id)


def test_alpha_anchor_profile_and_tie():
    """Late-ingested profiles stay out; equal event times rank by ingest order."""
    events = _load_jsonl(_fixture_root("pack_alpha") / "events.jsonl")
    queries = _load_jsonl(_fixture_root("pack_alpha") / "queries.jsonl")
    payload = _drive("pack_alpha")
    exp = _expected_snapshot(events, queries[0])
    got = _snap(payload, "q_alpha")
    assert got == exp
    assert got["profile_tier"] != "gold"


def test_beta_late_purchase_blocked():
    """Purchase totals must exclude rows ingested after the anchor."""
    events = _load_jsonl(_fixture_root("pack_beta") / "events.jsonl")
    queries = _load_jsonl(_fixture_root("pack_beta") / "queries.jsonl")
    payload = _drive("pack_beta")
    exp = _expected_snapshot(events, queries[0])
    got = _snap(payload, "q_beta")
    assert got["purchase_sum_7d"] == exp["purchase_sum_7d"]
    assert got["late_events_blocked"] == exp["late_events_blocked"]


def test_gamma_future_purchase_leakage():
    """Rolling purchase sum must not grow from future-dated rows in the log."""
    events = _load_jsonl(_fixture_root("pack_gamma") / "events.jsonl")
    queries = _load_jsonl(_fixture_root("pack_gamma") / "queries.jsonl")
    payload = _drive("pack_gamma")
    exp = _expected_snapshot(events, queries[0])
    got = _snap(payload, "q_gamma")
    assert got["purchase_sum_7d"] == exp["purchase_sum_7d"]
    assert got["leakage_repairs"] == exp["leakage_repairs"]


def test_delta_combined_temporal_bounds():
    """Combined late ingest and future movement stay out of anchor totals."""
    events = _load_jsonl(_fixture_root("pack_delta") / "events.jsonl")
    queries = _load_jsonl(_fixture_root("pack_delta") / "queries.jsonl")
    payload = _drive("pack_delta")
    exp = _expected_snapshot(events, queries[0])
    got = _snap(payload, "q_delta")
    assert got == exp


def test_peak_multi_query_regression():
    """Regression pack replays multiple anchors cleanly."""
    events = _load_jsonl(_fixture_root("pack_peak") / "events.jsonl")
    queries = _load_jsonl(_fixture_root("pack_peak") / "queries.jsonl")
    payload = _drive("pack_peak")
    for query in queries:
        exp = _expected_snapshot(events, query)
        got = _snap(payload, query["query_id"])
        assert got == exp


def test_snapshots_sorted_by_query_id():
    """Snapshot rows must be sorted by query_id."""
    payload = _drive("pack_peak")
    ids = [row["query_id"] for row in payload["snapshots"]]
    assert ids == sorted(ids)


def test_digest_matches_payload():
    """snapshots_digest must seal the payload with the digest field blanked."""
    payload = _drive("pack_alpha")
    clone = dict(payload)
    clone["snapshots_digest"] = ""
    raw = json.dumps(clone, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        check=True,
        capture_output=True,
    )
    assert payload["snapshots_digest"] == proc.stdout.split()[0]


def test_byte_identical_replay():
    """Two consecutive replays for the same pack must be byte-identical."""
    _drive("pack_gamma")
    first = REPORT.read_bytes()
    _drive("pack_gamma")
    second = REPORT.read_bytes()
    assert first == second


def test_frost_window_lower_bound_exclusive():
    """Seven-day rollup must exclude purchases exactly on the window opening edge."""
    events = _load_jsonl(_fixture_root("pack_frost") / "events.jsonl")
    queries = _load_jsonl(_fixture_root("pack_frost") / "queries.jsonl")
    payload = _drive("pack_frost")
    exp = _expected_snapshot(events, queries[0])
    got = _snap(payload, "q_frost")
    assert got["purchase_sum_7d"] == exp["purchase_sum_7d"]


def test_canyon_entity_isolation():
    """Another entity's purchases must not inflate the queried entity rollup."""
    events = _load_jsonl(_fixture_root("pack_canyon") / "events.jsonl")
    queries = _load_jsonl(_fixture_root("pack_canyon") / "queries.jsonl")
    payload = _drive("pack_canyon")
    exp = _expected_snapshot(events, queries[0])
    got = _snap(payload, "q_canyon")
    assert got["purchase_sum_7d"] == exp["purchase_sum_7d"]


def test_fixture_index_stems():
    """Every stem listed in fixture_index.txt must replay without error."""
    index = (APP / "docs" / "fixture_index.txt").read_text(encoding="utf-8").splitlines()
    stems = [line.strip() for line in index if line.strip()]
    assert stems == [
        "pack_alpha",
        "pack_beta",
        "pack_gamma",
        "pack_delta",
        "pack_peak",
        "pack_frost",
        "pack_canyon",
    ]
    for stem in stems:
        payload = _drive(stem)
        assert payload["snapshots"]
