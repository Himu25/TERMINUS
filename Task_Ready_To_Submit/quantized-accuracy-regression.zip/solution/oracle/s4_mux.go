package serve

import "quantgate.lab/pkg/types"

func AssignLanes(seqs []types.Seq) []types.Seq {
	out := make([]types.Seq, len(seqs))
	copy(out, seqs)
	return out
}

func LaneMismatch(orig []types.Seq, ordered []types.Seq) int {
	m := 0
	for i := range orig {
		if orig[i].Lane != ordered[i].Lane {
			m++
		}
	}
	return m
}

func SortKey(seq types.Seq) int {
	return len(seq.ID)
}

func StableOrder(seqs []types.Seq) []types.Seq {
	return AssignLanes(seqs)
}
