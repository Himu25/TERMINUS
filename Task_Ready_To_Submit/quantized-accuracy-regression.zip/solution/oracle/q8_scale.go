package quant

import "math"

func DequantRow(row []int8, scale float64, zp int) []float64 {
	out := make([]float64, len(row))
	for i, v := range row {
		out[i] = float64(int(v)-zp) * scale
	}
	return out
}

func ScaleFromRow(row []int8) float64 {
	var max float64
	for _, v := range row {
		av := math.Abs(float64(int(v)))
		if av > max {
			max = av
		}
	}
	if max < 1e-9 {
		return 1.0
	}
	return max / 127.0
}

func ClampedDequant(row []int8, scale float64, zp int) []float64 {
	out := DequantRow(row, scale, zp)
	for i := range out {
		if out[i] > 1.0 {
			out[i] = 1.0
		}
		if out[i] < -1.0 {
			out[i] = -1.0
		}
	}
	return out
}

func RowEnergy(row []int8) float64 {
	var sum float64
	for _, v := range row {
		q := float64(int(v))
		sum += q * q
	}
	return math.Sqrt(sum)
}
