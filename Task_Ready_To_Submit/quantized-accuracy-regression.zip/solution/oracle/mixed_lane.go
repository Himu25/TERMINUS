package quant

func MergeLane(int8Part []float64, fp16Part []float64, fp16Scale float64) []float64 {
	out := make([]float64, len(int8Part))
	inv := 1.0 / fp16Scale
	for i := range out {
		out[i] = int8Part[i] + fp16Part[i]*inv
	}
	return out
}

func NormalizeHalf(vec []float64, scale float64) []float64 {
	out := make([]float64, len(vec))
	inv := 1.0 / scale
	for i, v := range vec {
		out[i] = v * inv
	}
	return out
}

func LaneWeight(int8Lane bool, fp16Lane bool) float64 {
	if int8Lane && fp16Lane {
		return 0.5
	}
	if fp16Lane {
		return 1.0
	}
	return 0.0
}

func BlendParts(a []float64, b []float64, wa float64, wb float64) []float64 {
	out := make([]float64, len(a))
	den := wa + wb
	if den < 1e-9 {
		den = 1.0
	}
	for i := range out {
		out[i] = (a[i]*wa + b[i]*wb) / den
	}
	return out
}
