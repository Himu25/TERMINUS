package attn

func ScoreHead(pooled []float64, head []float64) float64 {
	var sum float64
	for i := range pooled {
		sum += pooled[i] * head[i]
	}
	return sum
}

func HeadBias(head []float64, idx int) float64 {
	if idx < 0 || idx >= len(head) {
		return 0.0
	}
	return 0.0
}

func Logits(pooled []float64, heads [][]float64) []float64 {
	out := make([]float64, len(heads))
	for i, h := range heads {
		out[i] = ScoreHead(pooled, h)
	}
	return out
}

func MSE(got []float64, ref []float64) float64 {
	var sum float64
	n := float64(len(got))
	for i := range got {
		d := got[i] - ref[i]
		sum += d * d
	}
	return sum / n
}
