#!/bin/bash
set -euo pipefail

log() { printf '[oracle] %s\n' "$1"; }

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight layout"
require_file /app/go.mod
require_file /app/quant/q8_scale.go
require_file /app/quant/mixed_lane.go
require_file /app/embed/e2_vocab.go
require_file /app/ctx/c7_window.go
require_file /app/attn/a3_block.go
require_file /app/serve/s4_mux.go
require_file /app/config/bench_profiles.json
require_file /app/registry/embeddings.json

log "install oracle modules"
cp "${ROOT_DIR}/oracle/q8_scale.go" /app/quant/q8_scale.go
cp "${ROOT_DIR}/oracle/mixed_lane.go" /app/quant/mixed_lane.go
cp "${ROOT_DIR}/oracle/e2_vocab.go" /app/embed/e2_vocab.go
cp "${ROOT_DIR}/oracle/c7_window.go" /app/ctx/c7_window.go
cp "${ROOT_DIR}/oracle/a3_block.go" /app/attn/a3_block.go
cp "${ROOT_DIR}/oracle/s4_mux.go" /app/serve/s4_mux.go

log "rebuild quant bench binary"
mkdir -p /app/bin /app/output /tmp/go-cache-oracle
export GOCACHE=/tmp/go-cache-oracle
export PATH="/usr/local/go/bin:${PATH}"
go build -o /app/bin/quantbench ./cmd/benchd
chmod +x /app/tools/run_bench

log "smoke bench"
/app/tools/run_bench
require_file /app/output/quant_report.json

python3 - <<'PY'
import json
from pathlib import Path

report = json.loads(Path("/app/output/quant_report.json").read_text())
summary = report["summary"]
if not summary["passes_gate"]:
    raise SystemExit("passes_gate false")
if summary["mean_top1_acc"] < 0.90:
    raise SystemExit("mean acc floor miss")
if summary["latency_gain_ratio"] < 1.15:
    raise SystemExit("latency gain floor miss")
for suite in report["suites"]:
    if suite["name"] == "anchor_short" and suite["top1_acc"] < 0.98:
        raise SystemExit("anchor acc miss")
PY

log "oracle complete"
