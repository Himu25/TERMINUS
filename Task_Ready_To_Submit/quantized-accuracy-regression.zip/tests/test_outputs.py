"""Validate quant_report.json against quantized inference gates and independent replay."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "quant_report.json"
BENCH = APP / "tools" / "run_bench"
PROFILE = APP / "config" / "bench_profiles.json"
STRESS_PROFILE = APP / "config" / "stress_profiles.json"
THRESHOLDS = APP / "config" / "thresholds.toml"
EMB = APP / "registry" / "embeddings.json"
META = APP / "registry" / "model_meta.json"
HEADS = APP / "registry" / "heads.json"
FIXTURES = Path(__file__).resolve().parent / "fixtures"

LONG_SUITES = frozenset({"long_ctx_suite", "long_ctx_hidden"})
RARE_SUITES = frozenset({"rare_token_suite", "rare_spike_hidden"})
MIXED_SUITES = frozenset({"mixed_batch_suite", "mixed_lane_hidden"})


def _parse_thresholds(path: Path) -> dict[str, float]:
    floors: dict[str, float] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.split("#", 1)[0].strip()
        if not stripped or "=" not in stripped:
            continue
        key, raw = stripped.split("=", 1)
        floors[key.strip()] = float(raw.strip())
    return floors


_FLOOR_DATA = _parse_thresholds(THRESHOLDS)


def _load_registry() -> tuple[dict, dict, dict]:
    emb = json.loads(EMB.read_text(encoding="utf-8"))
    meta = json.loads(META.read_text(encoding="utf-8"))
    heads = json.loads(HEADS.read_text(encoding="utf-8"))
    return emb, meta, heads


def _dequant(row: list[int], scale: float, zp: int) -> list[float]:
    return [(int(v) - zp) * scale for v in row]


def _pos_scale(pos: int, soft: int) -> float:
    if pos < soft:
        return 1.0
    return soft / float(pos)


def _pool(vecs: list[list[float]]) -> list[float]:
    if not vecs:
        return []
    dim = len(vecs[0])
    acc = [0.0] * dim
    for vec in vecs:
        for i in range(dim):
            acc[i] += vec[i]
    inv = 1.0 / len(vecs)
    return [x * inv for x in acc]


def _logits(pooled: list[float], heads: list[list[float]]) -> list[float]:
    return [sum(pooled[i] * h[i] for i in range(len(pooled))) for h in heads]


def _load_seqs(path: Path) -> list[dict]:
    rows: list[dict] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return rows


def _round4(v: float) -> float:
    return round(v, 4)


def _independent_suite_metrics(path: Path) -> dict[str, float | int]:
    emb, meta, heads = _load_registry()
    soft = meta["ctx_soft_cap"]
    half_scale = meta["fp16_lane_scale"]
    scales = emb["scales"]
    zps = emb["zero_points"]
    rows = emb["rows"]
    fp_rows = emb["full_rows"]
    hw = heads["weights"]
    seqs = _load_seqs(path)
    acc_sum = 0.0
    mse_sum = 0.0
    tokens = 0
    lane_miss = 0
    for seq in seqs:
        vecs: list[list[float]] = []
        ref_parts: list[list[float]] = []
        for pos, tok in enumerate(seq["tokens"]):
            ps = _pos_scale(pos, soft)
            if seq.get("lane") == "fp16":
                v = [x * ps for x in fp_rows[tok]]
            else:
                v = _dequant(rows[tok], scales[tok], zps[tok])
                v = [x * ps for x in v]
            vecs.append(v)
            ref = [x * ps for x in fp_rows[tok]]
            ref_parts.append(ref)
        pooled = _pool(vecs)
        if seq.get("lane") == "fp16":
            int8_parts = [
                _dequant(rows[t], scales[t], zps[t]) for t in seq["tokens"]
            ]
            int8_pool = _pool(int8_parts)
            inv = 1.0 / half_scale
            pooled = [int8_pool[i] + pooled[i] * inv for i in range(len(pooled))]
        got = _logits(pooled, hw)
        ref_logits = _logits(_pool(ref_parts), hw)
        label = seq["label"]
        best = max(range(len(got)), key=lambda i: got[i])
        acc_sum += 1.0 if best == label else 0.0
        mse_sum += sum((got[i] - ref_logits[i]) ** 2 for i in range(len(got))) / len(got)
        tokens += len(seq["tokens"])
    n = max(len(seqs), 1)
    return {
        "tokens": tokens,
        "top1_acc": _round4(acc_sum / n),
        "logit_mse": _round4(mse_sum / n),
        "lane_mismatch": lane_miss,
    }


def _run_bench(profile: Path | None = None) -> None:
    cmd = [str(BENCH)]
    if profile is not None:
        cmd.append(str(profile))
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "quant_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


def _suite(report: dict, name: str) -> dict:
    return next(s for s in report["suites"] if s["name"] == name)


@pytest.fixture(autouse=True)
def _ensure_default_report() -> None:
    _run_bench()


def test_report_schema_and_suite_order() -> None:
    """Report lists suites in bench profile order with required fields."""
    report = _load_report()
    profile = json.loads(PROFILE.read_text(encoding="utf-8"))
    expected_names = [s["name"] for s in profile["suites"]]
    assert [s["name"] for s in report["suites"]] == expected_names
    for suite in report["suites"]:
        for key in (
            "tokens",
            "top1_acc",
            "logit_mse",
            "lane_mismatch",
            "latency_units",
        ):
            assert key in suite


def test_anchor_short_accuracy() -> None:
    """anchor_short meets anchor accuracy floor."""
    suite = _suite(_load_report(), "anchor_short")
    assert suite["top1_acc"] >= _FLOOR_DATA["anchor_acc_floor"]
    assert suite["lane_mismatch"] == 0


def test_long_context_suite_floors() -> None:
    """Long-context suite meets accuracy and logit_mse ceilings."""
    suite = _suite(_load_report(), "long_ctx_suite")
    assert suite["top1_acc"] >= _FLOOR_DATA["long_acc_floor"]
    assert suite["logit_mse"] <= _FLOOR_DATA["long_mse_ceiling"]


def test_rare_token_suite_floors() -> None:
    """Rare vocabulary suite meets accuracy and logit_mse ceilings."""
    suite = _suite(_load_report(), "rare_token_suite")
    assert suite["top1_acc"] >= _FLOOR_DATA["rare_acc_floor"]
    assert suite["logit_mse"] <= _FLOOR_DATA["rare_mse_ceiling"]


def test_mixed_batch_suite_floors() -> None:
    """Mixed fp16/int8 batch suite meets accuracy and lane mismatch ceiling."""
    suite = _suite(_load_report(), "mixed_batch_suite")
    assert suite["top1_acc"] >= _FLOOR_DATA["mixed_acc_floor"]
    assert suite["lane_mismatch"] <= _FLOOR_DATA["mixed_lane_ceiling"]


def test_combined_stress_suite_floors() -> None:
    """Combined stress suite meets accuracy and logit_mse ceilings."""
    suite = _suite(_load_report(), "combined_stress")
    assert suite["top1_acc"] >= _FLOOR_DATA["combined_acc_floor"]
    assert suite["logit_mse"] <= _FLOOR_DATA["combined_mse_ceiling"]


def test_summary_schema_and_passes_gate() -> None:
    """Summary exposes mean_top1_acc, latency_gain_ratio, passes_gate and meets floors."""
    report = _load_report()
    summary = report["summary"]
    for key in ("mean_top1_acc", "latency_gain_ratio", "passes_gate"):
        assert key in summary
    assert summary["mean_top1_acc"] >= _FLOOR_DATA["mean_acc_floor"]
    assert summary["latency_gain_ratio"] >= _FLOOR_DATA["latency_gain_floor"]
    assert summary["passes_gate"] is True


# Per-suite replay bands: tight enough that unfixed bench output fails, wide
# enough that a mostly-correct rebuild can land within ~1-3/10 agent trials.
_REPLAY_LOGIT_MSE_TOL: dict[str, float] = {
    "anchor_short": 0.006,
    "long_ctx_suite": 0.01,
    "mixed_batch_suite": 0.10,
    "combined_stress": 0.15,
}

_REPLAY_ACC_TOL: dict[str, float] = {
    "anchor_short": 0.0,
    "long_ctx_suite": 0.05,
    "mixed_batch_suite": 0.05,
    "combined_stress": 0.15,
}


def _assert_suite_metrics_match_independent_replay(
    suite_names: frozenset[str],
    *,
    logit_mse_tol: float | None = None,
    require_all: bool = True,
) -> None:
    report = _load_report()
    profile = json.loads(PROFILE.read_text(encoding="utf-8"))
    matched = 0
    checked = 0
    for entry, suite in zip(profile["suites"], report["suites"], strict=True):
        if suite["name"] not in suite_names:
            continue
        checked += 1
        replay = _independent_suite_metrics(Path(entry["path"]))
        mse_tol = (
            logit_mse_tol
            if logit_mse_tol is not None
            else _REPLAY_LOGIT_MSE_TOL.get(suite["name"], 0.006)
        )
        acc_tol = _REPLAY_ACC_TOL.get(suite["name"], 0.0)
        if (
            suite["tokens"] == replay["tokens"]
            and abs(suite["top1_acc"] - replay["top1_acc"]) <= acc_tol
            and abs(suite["logit_mse"] - replay["logit_mse"]) <= mse_tol
        ):
            matched += 1
    if require_all:
        assert matched == checked, f"Only {matched}/{checked} suites matched replay"
    else:
        assert matched >= 1, f"No suites matched replay ({checked} checked)"


def test_anchor_metrics_match_independent_replay() -> None:
    """anchor_short row matches independent full-precision replay."""
    _assert_suite_metrics_match_independent_replay(frozenset({"anchor_short"}))


def test_profile_suites_metrics_match_independent_replay() -> None:
    """Default profile long and mixed suites match independent replay."""
    _assert_suite_metrics_match_independent_replay(
        frozenset({"long_ctx_suite", "mixed_batch_suite"}),
        require_all=False,
    )


def test_combined_stress_metrics_match_independent_replay() -> None:
    """combined_stress row matches independent full-precision replay."""
    _assert_suite_metrics_match_independent_replay(frozenset({"combined_stress"}))


def test_stress_profile_floors() -> None:
    """Stress profile applies default and pack-specific floors on hidden suites."""
    try:
        _run_bench(STRESS_PROFILE)
        report = _load_report()
        for suite in report["suites"]:
            if suite["name"] in LONG_SUITES:
                assert suite["top1_acc"] >= _FLOOR_DATA["long_acc_floor"]
            if suite["name"] in RARE_SUITES:
                assert suite["top1_acc"] >= _FLOOR_DATA["rare_acc_floor"]
            if suite["name"] in MIXED_SUITES:
                assert suite["lane_mismatch"] <= _FLOOR_DATA["mixed_lane_ceiling"]
        long_h = _suite(report, "long_ctx_hidden")
        assert long_h["top1_acc"] >= _FLOOR_DATA["pack_long_acc_floor"]
        rare_h = _suite(report, "rare_spike_hidden")
        assert rare_h["top1_acc"] >= _FLOOR_DATA["pack_rare_acc_floor"]
        mixed_h = _suite(report, "mixed_lane_hidden")
        assert mixed_h["lane_mismatch"] <= _FLOOR_DATA["pack_mixed_lane_ceiling"]
        assert mixed_h["top1_acc"] >= _FLOOR_DATA["pack_mixed_acc_floor"]
    finally:
        _run_bench()


def test_repeat_run_byte_identical() -> None:
    """Back-to-back bench runs emit identical report bytes."""
    _run_bench()
    first = OUT.read_bytes()
    _run_bench()
    second = OUT.read_bytes()
    assert first == second


def test_metrics_four_decimal_places() -> None:
    """top1_acc and logit_mse are rounded to four decimal places."""
    report = _load_report()
    for suite in report["suites"]:
        for key in ("top1_acc", "logit_mse"):
            val = suite[key]
            assert val == round(val, 4)
    assert report["summary"]["mean_top1_acc"] == round(
        report["summary"]["mean_top1_acc"], 4
    )


def test_hidden_long_context_profile() -> None:
    """Verifier-only long-context pack meets pack_long_acc_floor."""
    profile_path = APP / "output" / "profile_long_hidden.json"
    try:
        profile_path.write_text(
            (FIXTURES / "profile_long_hidden.json").read_text(encoding="utf-8"),
            encoding="utf-8",
        )
        _run_bench(profile_path)
        suite = _suite(_load_report(), "long_ctx_hidden")
        assert suite["top1_acc"] >= _FLOOR_DATA["pack_long_acc_floor"]
    finally:
        _run_bench()


def test_hidden_rare_token_profile() -> None:
    """Verifier-only rare-token pack meets pack_rare_acc_floor."""
    profile_path = APP / "output" / "profile_rare_hidden.json"
    try:
        profile_path.write_text(
            (FIXTURES / "profile_rare_hidden.json").read_text(encoding="utf-8"),
            encoding="utf-8",
        )
        _run_bench(profile_path)
        suite = _suite(_load_report(), "rare_spike_hidden")
        assert suite["top1_acc"] >= _FLOOR_DATA["pack_rare_acc_floor"]
    finally:
        _run_bench()


def test_hidden_mixed_lane_profile() -> None:
    """Verifier-only mixed-lane pack meets pack floors."""
    profile_path = APP / "output" / "profile_mixed_hidden.json"
    try:
        profile_path.write_text(
            (FIXTURES / "profile_mixed_hidden.json").read_text(encoding="utf-8"),
            encoding="utf-8",
        )
        _run_bench(profile_path)
        suite = _suite(_load_report(), "mixed_lane_hidden")
        assert suite["lane_mismatch"] <= _FLOOR_DATA["pack_mixed_lane_ceiling"]
        assert suite["top1_acc"] >= _FLOOR_DATA["pack_mixed_acc_floor"]
    finally:
        _run_bench()


def test_forged_report_restored_by_rerun() -> None:
    """A truncated forged report cannot satisfy the full profile contract."""
    profile_len = len(json.loads(PROFILE.read_text(encoding="utf-8"))["suites"])
    forged = {
        "suites": [
            {
                "name": "anchor_short",
                "tokens": 1,
                "top1_acc": 1.0,
                "logit_mse": 0.0,
                "lane_mismatch": 0,
                "latency_units": 1,
            }
        ],
        "summary": {
            "mean_top1_acc": 1.0,
            "latency_gain_ratio": 2.0,
            "passes_gate": True,
        },
    }
    OUT.write_text(json.dumps(forged) + "\n", encoding="utf-8")
    assert len(_load_report()["suites"]) != profile_len
    _run_bench()
    restored = _load_report()
    assert len(restored["suites"]) == profile_len
    assert restored["summary"]["passes_gate"] is True
