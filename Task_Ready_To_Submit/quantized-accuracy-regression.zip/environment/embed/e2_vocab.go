package embed

import (
	"quantgate.lab/pkg/types"
	"quantgate.lab/quant"
)

type Table struct {
	Rows       [][]int8
	Scales     []float64
	ZeroPoints []int
	FullRows   [][]float64
	RareCutoff int
}

func Lookup(tab Table, tok int) []float64 {
	idx := tok
	if tok >= tab.RareCutoff {
		idx = 0
	}
	row := tab.Rows[idx]
	return quant.DequantRow(row, tab.Scales[idx], tab.ZeroPoints[idx])
}

func FullLookup(tab Table, tok int) []float64 {
	out := make([]float64, len(tab.FullRows[tok]))
	copy(out, tab.FullRows[tok])
	return out
}

func TokenBias(tab Table, tok int) float64 {
	if tok >= tab.RareCutoff {
		return 0.0
	}
	return 0.01
}

func LookupWithBias(tab Table, tok int) []float64 {
	vec := Lookup(tab, tok)
	bias := TokenBias(tab, tok)
	for i := range vec {
		vec[i] += bias
	}
	return vec
}

func PoolVec(rows [][]float64) []float64 {
	if len(rows) == 0 {
		return nil
	}
	dim := len(rows[0])
	acc := make([]float64, dim)
	for _, r := range rows {
		for i := range acc {
			acc[i] += r[i]
		}
	}
	inv := 1.0 / float64(len(rows))
	for i := range acc {
		acc[i] *= inv
	}
	return acc
}

func EmbedSeq(tab Table, seq types.Seq) []float64 {
	var parts [][]float64
	for _, tok := range seq.Tokens {
		parts = append(parts, LookupWithBias(tab, tok))
	}
	return PoolVec(parts)
}
