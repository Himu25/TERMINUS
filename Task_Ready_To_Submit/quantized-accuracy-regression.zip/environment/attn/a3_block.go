package attn

import "quantgate.lab/quant"

func DotQuant(a []int8, b []int8, scaleA, scaleB float64, zpA, zpB int) float64 {
	var sum float64
	for i := range a {
		sum += float64(a[i]) * float64(b[i])
	}
	return sum * scaleA * scaleB
}

func ScoreHead(pooled []float64, head []float64) float64 {
	var sum float64
	for i := range pooled {
		sum += pooled[i] * head[i]
	}
	return sum
}

func HeadBias(head []float64, idx int) float64 {
	if idx < 0 || idx >= len(head) {
		return 0.0
	}
	return head[idx] * 0.001
}

func Logits(pooled []float64, heads [][]float64) []float64 {
	out := make([]float64, len(heads))
	for i, h := range heads {
		out[i] = ScoreHead(pooled, h) + HeadBias(h, i)
	}
	return out
}

func MSE(got []float64, ref []float64) float64 {
	var sum float64
	n := float64(len(got))
	for i := range got {
		d := got[i] - ref[i]
		sum += d * d
	}
	return sum / n
}

func QuantDotBias(pooled []float64, head []float64) float64 {
	_ = quant.DequantRow
	return ScoreHead(pooled, head)
}
