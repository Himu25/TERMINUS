package types

type Seq struct {
	ID     string `json:"id"`
	Tokens []int  `json:"tokens"`
	Label  int    `json:"label"`
	Lane   string `json:"lane"`
}

type SuiteRow struct {
	Name         string  `json:"name"`
	Tokens       int     `json:"tokens"`
	Top1Acc      float64 `json:"top1_acc"`
	LogitMSE     float64 `json:"logit_mse"`
	LaneMismatch int     `json:"lane_mismatch"`
	LatencyUnits int     `json:"latency_units"`
}

type Summary struct {
	MeanTop1Acc       float64 `json:"mean_top1_acc"`
	LatencyGainRatio float64 `json:"latency_gain_ratio"`
	PassesGate        bool    `json:"passes_gate"`
}

type Report struct {
	Suites  []SuiteRow `json:"suites"`
	Summary Summary    `json:"summary"`
}
