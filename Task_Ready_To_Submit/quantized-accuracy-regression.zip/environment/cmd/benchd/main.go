package main

import (
	"fmt"
	"os"

	"quantgate.lab/bench"
)

func main() {
	profile := "/app/config/bench_profiles.json"
	if len(os.Args) > 1 {
		profile = os.Args[1]
	}
	rep, err := bench.Run(profile)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if err := bench.WriteReport("/app/output/quant_report.json", rep); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
