Report contract for `/app/output/quant_report.json`:

- suites[] in profile order with name, tokens, top1_acc, logit_mse, lane_mismatch, latency_units (top1_acc and logit_mse to four decimals).
- summary with mean_top1_acc, latency_gain_ratio, passes_gate.

Gate floors live in `/app/config/thresholds.toml`. anchor_short is the anchor suite. Long, rare-token, mixed-batch, and combined suites must meet their named floors. passes_gate requires every applicable floor plus summary mean_top1_acc and latency_gain_ratio.

Identical inputs must yield byte-identical reports.
