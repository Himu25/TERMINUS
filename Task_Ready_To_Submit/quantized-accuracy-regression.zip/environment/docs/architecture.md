# Architecture

Entry: `/app/cmd/benchd` built to `/app/bin/quantbench`.

Data flow: JSONL sequences -> serve mux -> per-token embed lookup -> ctx position scale -> mean pool -> optional mixed-lane merge -> attn head logits. Full-precision logits for logit_mse use full_rows from embeddings.json with the same position scaling.

latency_gain_ratio compares a synthetic full-precision unit estimate to quantized latency_units accumulated per suite.
