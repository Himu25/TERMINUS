# Quantized inference bench

Modules under `/app` implement a compact transformer-style scoring path used for regression after an INT8 optimization pass. The bench walks suite JSONL packs, scores sequences through quantized embeddings, position scaling, optional FP16 lanes, and head logits.

Run `/app/tools/run_bench` with an optional profile path (default `/app/config/bench_profiles.json`). Stress profiles live in `/app/config/stress_profiles.json`. Output is written to `/app/output/quant_report.json`.

Registry tensors are under `/app/registry/`. Gate floors are in `/app/config/thresholds.toml`. Verifier-only packs are listed in `/app/docs/pack_manifest.txt`.
