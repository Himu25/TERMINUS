Bench output directory: /app/output
