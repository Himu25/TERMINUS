module quantgate.lab

go 1.22
