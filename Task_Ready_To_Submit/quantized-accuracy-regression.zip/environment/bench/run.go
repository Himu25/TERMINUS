package bench

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
	"strings"

	"quantgate.lab/attn"
	"quantgate.lab/ctx"
	"quantgate.lab/embed"
	"quantgate.lab/pkg/types"
	"quantgate.lab/quant"
	"quantgate.lab/serve"
)

type Floors struct {
	AnchorAcc       float64
	LongAcc         float64
	LongMSE         float64
	RareAcc         float64
	RareMSE         float64
	MixedAcc        float64
	MixedLane       float64
	CombinedAcc     float64
	CombinedMSE     float64
	MeanAcc         float64
	LatencyGain    float64
	PackLongAcc     float64
	PackRareAcc     float64
	PackMixedLane   float64
	PackMixedAcc    float64
}

type Registry struct {
	Tab      embed.Table
	Heads    [][]float64
	SoftCap int
	FP16    float64
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

func loadFloors(path string) (Floors, error) {
	body, err := os.ReadFile(path)
	if err != nil {
		return Floors{}, err
	}
	var f Floors
	for _, line := range strings.Split(string(body), "\n") {
		line = strings.Split(line, "#")[0]
		line = strings.TrimSpace(line)
		if line == "" || !strings.Contains(line, "=") {
			continue
		}
		key := strings.TrimSpace(line[:strings.Index(line, "=")])
		val := strings.TrimSpace(line[strings.Index(line, "=")+1:])
		var x float64
		if _, err := fmt.Sscanf(val, "%f", &x); err != nil {
			return Floors{}, err
		}
		switch key {
		case "anchor_acc_floor":
			f.AnchorAcc = x
		case "long_acc_floor":
			f.LongAcc = x
		case "long_mse_ceiling":
			f.LongMSE = x
		case "rare_acc_floor":
			f.RareAcc = x
		case "rare_mse_ceiling":
			f.RareMSE = x
		case "mixed_acc_floor":
			f.MixedAcc = x
		case "mixed_lane_ceiling":
			f.MixedLane = x
		case "combined_acc_floor":
			f.CombinedAcc = x
		case "combined_mse_ceiling":
			f.CombinedMSE = x
		case "mean_acc_floor":
			f.MeanAcc = x
		case "latency_gain_floor":
			f.LatencyGain = x
		case "pack_long_acc_floor":
			f.PackLongAcc = x
		case "pack_rare_acc_floor":
			f.PackRareAcc = x
		case "pack_mixed_lane_ceiling":
			f.PackMixedLane = x
		case "pack_mixed_acc_floor":
			f.PackMixedAcc = x
		}
	}
	return f, nil
}

func loadRegistry() (Registry, error) {
	embBody, err := os.ReadFile("/app/registry/embeddings.json")
	if err != nil {
		return Registry{}, err
	}
	var emb struct {
		Rows       [][]int8    `json:"rows"`
		Scales     []float64   `json:"scales"`
		ZeroPoints []int       `json:"zero_points"`
		FullRows     [][]float64 `json:"full_rows"`
	}
	if err := json.Unmarshal(embBody, &emb); err != nil {
		return Registry{}, err
	}
	metaBody, err := os.ReadFile("/app/registry/model_meta.json")
	if err != nil {
		return Registry{}, err
	}
	var meta struct {
		RareCutoff     int     `json:"rare_cutoff"`
		CtxSoftCap     int     `json:"ctx_soft_cap"`
		FP16LaneScale  float64 `json:"fp16_lane_scale"`
	}
	if err := json.Unmarshal(metaBody, &meta); err != nil {
		return Registry{}, err
	}
	headBody, err := os.ReadFile("/app/registry/heads.json")
	if err != nil {
		return Registry{}, err
	}
	var heads struct {
		Weights [][]float64 `json:"weights"`
	}
	if err := json.Unmarshal(headBody, &heads); err != nil {
		return Registry{}, err
	}
	return Registry{
		Tab: embed.Table{
			Rows: emb.Rows, Scales: emb.Scales, ZeroPoints: emb.ZeroPoints,
			FullRows: emb.FullRows, RareCutoff: meta.RareCutoff,
		},
		Heads: heads.Weights, SoftCap: meta.CtxSoftCap, FP16: meta.FP16LaneScale,
	}, nil
}

func loadSeqs(path string) ([]types.Seq, error) {
	body, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var out []types.Seq
	for _, line := range strings.Split(string(body), "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		var s types.Seq
		if err := json.Unmarshal([]byte(line), &s); err != nil {
			return nil, err
		}
		out = append(out, s)
	}
	return out, nil
}

func inferOne(reg Registry, seq types.Seq) ([]float64, []float64, int, int) {
	ordered := serve.AssignLanes([]types.Seq{seq})
	laneMiss := serve.LaneMismatch([]types.Seq{seq}, ordered)
	seq = ordered[0]
	var vecs [][]float64
	units := 0
	for pos, tok := range seq.Tokens {
		ps := ctx.PosScale(pos, reg.SoftCap)
		var v []float64
		if seq.Lane == "fp16" {
			v = embed.FullLookup(reg.Tab, tok)
		} else {
			v = embed.Lookup(reg.Tab, tok)
		}
		for i := range v {
			v[i] *= ps
		}
		vecs = append(vecs, v)
		units += len(v) + 2
	}
	pooled := embed.PoolVec(vecs)
	if seq.Lane == "fp16" && len(vecs) > 0 {
		int8Pool := embed.PoolVec(func() [][]float64 {
			var p [][]float64
			for _, tok := range seq.Tokens {
				p = append(p, embed.Lookup(reg.Tab, tok))
			}
			return p
		}())
		pooled = quant.MergeLane(int8Pool, pooled, reg.FP16)
	}
	got := attn.Logits(pooled, reg.Heads)
	var refParts [][]float64
	for pos, tok := range seq.Tokens {
		ps := ctx.PosScale(pos, reg.SoftCap)
		v := embed.FullLookup(reg.Tab, tok)
		for i := range v {
			v[i] *= ps
		}
		refParts = append(refParts, v)
	}
	refPool := embed.PoolVec(refParts)
	ref := attn.Logits(refPool, reg.Heads)
	return got, ref, units, laneMiss
}

func top1(got []float64, label int) float64 {
	best := 0
	for i := 1; i < len(got); i++ {
		if got[i] > got[best] {
			best = i
		}
	}
	if best == label {
		return 1.0
	}
	return 0.0
}

func evalSuite(reg Registry, name string, path string) (types.SuiteRow, int, error) {
	seqs, err := loadSeqs(path)
	if err != nil {
		return types.SuiteRow{}, 0, err
	}
	var accSum, mseSum float64
	var tokens, laneMiss, units int
	for _, seq := range seqs {
		got, ref, u, lm := inferOne(reg, seq)
		accSum += top1(got, seq.Label)
		mseSum += attn.MSE(got, ref)
		tokens += len(seq.Tokens)
		laneMiss += lm
		units += u
	}
	n := float64(len(seqs))
	return types.SuiteRow{
		Name: name, Tokens: tokens,
		Top1Acc: round4(accSum / n), LogitMSE: round4(mseSum / n),
		LaneMismatch: laneMiss, LatencyUnits: units,
	}, units, nil
}

func fullUnits(reg Registry, suites []struct {
	Name string `json:"name"`
	Path string `json:"path"`
}) int {
	total := 0
	for _, s := range suites {
		seqs, _ := loadSeqs(s.Path)
		for _, seq := range seqs {
			dim := len(reg.Heads[0])
			classes := len(reg.Heads)
			total += len(seq.Tokens)*dim*classes*3 + dim*classes*2
		}
	}
	return total
}

func Run(profilePath string) (types.Report, error) {
	body, err := os.ReadFile(profilePath)
	if err != nil {
		return types.Report{}, err
	}
	var prof struct {
		Suites []struct {
			Name string `json:"name"`
			Path string `json:"path"`
		} `json:"suites"`
	}
	if err := json.Unmarshal(body, &prof); err != nil {
		return types.Report{}, err
	}
	reg, err := loadRegistry()
	if err != nil {
		return types.Report{}, err
	}
	floors, err := loadFloors("/app/config/thresholds.toml")
	if err != nil {
		return types.Report{}, err
	}
	var rows []types.SuiteRow
	var qUnits int
	for _, suite := range prof.Suites {
		row, u, err := evalSuite(reg, suite.Name, suite.Path)
		if err != nil {
			return types.Report{}, err
		}
		rows = append(rows, row)
		qUnits += u
	}
	fpUnits := fullUnits(reg, prof.Suites)
	gain := round4(float64(fpUnits) / float64(max(qUnits, 1)))
	var meanAcc float64
	for _, r := range rows {
		meanAcc += r.Top1Acc
	}
	meanAcc = round4(meanAcc / float64(len(rows)))
	pass := true
	for _, r := range rows {
		switch r.Name {
		case "anchor_short":
			if r.Top1Acc < floors.AnchorAcc {
				pass = false
			}
		case "long_ctx_suite", "long_ctx_hidden":
			if r.Top1Acc < floors.LongAcc || r.LogitMSE > floors.LongMSE {
				pass = false
			}
		case "rare_token_suite", "rare_spike_hidden":
			if r.Top1Acc < floors.RareAcc || r.LogitMSE > floors.RareMSE {
				pass = false
			}
		case "mixed_batch_suite", "mixed_lane_hidden":
			if r.Top1Acc < floors.MixedAcc || float64(r.LaneMismatch) > floors.MixedLane {
				pass = false
			}
		case "combined_stress":
			if r.Top1Acc < floors.CombinedAcc || r.LogitMSE > floors.CombinedMSE {
				pass = false
			}
		}
	}
	if meanAcc < floors.MeanAcc || gain < floors.LatencyGain {
		pass = false
	}
	for _, r := range rows {
		if r.Name == "long_ctx_hidden" && r.Top1Acc < floors.PackLongAcc {
			pass = false
		}
		if r.Name == "rare_spike_hidden" && r.Top1Acc < floors.PackRareAcc {
			pass = false
		}
		if r.Name == "mixed_lane_hidden" {
			if float64(r.LaneMismatch) > floors.PackMixedLane || r.Top1Acc < floors.PackMixedAcc {
				pass = false
			}
		}
	}
	return types.Report{
		Suites: rows,
		Summary: types.Summary{
			MeanTop1Acc: meanAcc, LatencyGainRatio: gain, PassesGate: pass,
		},
	}, nil
}

func WriteReport(path string, rep types.Report) error {
	body, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, append(body, '\n'), 0o644)
}
