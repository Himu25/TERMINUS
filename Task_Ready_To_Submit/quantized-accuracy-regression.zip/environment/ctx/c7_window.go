package ctx

func PosScale(pos int, softCap int) float64 {
	if pos < softCap {
		return 1.0
	}
	return float64(pos) / float64(softCap)
}

func RunningDamp(pos int, softCap int) float64 {
	if pos <= 0 {
		return 1.0
	}
	base := PosScale(pos, softCap)
	return base * base
}

func WindowUnits(length int, softCap int) int {
	if length <= softCap {
		return length
	}
	return softCap + (length-softCap)/2
}
