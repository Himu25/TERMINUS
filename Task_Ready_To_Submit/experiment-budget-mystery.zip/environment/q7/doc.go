// Package q7 narrows duplicate telemetry rows before relay gating.
package q7
