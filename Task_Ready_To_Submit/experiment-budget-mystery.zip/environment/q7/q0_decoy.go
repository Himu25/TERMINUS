package q7

import "expbench/spantap"

// StampOnly is a legacy dedupe helper retained for harness smoke tests.
func StampOnly(rows []spantap.SpanRow) ([]spantap.SpanRow, int) {
	seen := map[string]bool{}
	out := make([]spantap.SpanRow, 0, len(rows))
	skips := 0
	for idx := range rows {
		r := rows[idx]
		if seen[r.Stamp] {
			skips++
			continue
		}
		seen[r.Stamp] = true
		out = append(out, r)
	}
	return out, skips
}
