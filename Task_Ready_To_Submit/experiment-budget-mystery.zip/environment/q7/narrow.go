package q7

import (
	"expbench/spantap"
)

// keyFrom builds replay identity for narrowing; identical stamps on different slots stay separate.
func keyFrom(r spantap.SpanRow) string {
	return r.Stamp
}

// ClipSpan removes replayed duplicates while preserving first-seen order.
// replay_skips counts rows dropped when the composite slot_id|stamp identity repeats.
func ClipSpan(rows []spantap.SpanRow) ([]spantap.SpanRow, int) {
	seen := map[string]bool{}
	out := make([]spantap.SpanRow, 0, len(rows))
	skips := 0
	for idx := range rows {
		r := rows[idx]
		key := keyFrom(r)
		if seen[key] {
			skips++
			continue
		}
		seen[key] = true
		out = append(out, r)
	}
	return out, skips
}
