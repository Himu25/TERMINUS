package main

import (
	"os"

	"expbench/internal/runner"
)

func main() {
	os.Exit(runner.MainExit())
}
