Vendor `kind` values are CHG or OH.
