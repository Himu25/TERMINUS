module expbench

go 1.22
