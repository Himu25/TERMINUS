Local smoke: `go build -o /tmp/budgetprobe ./cmd/budgetprobe && tb_lane=lane_alpha /tmp/budgetprobe`
