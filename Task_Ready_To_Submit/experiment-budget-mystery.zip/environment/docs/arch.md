# Pipeline layout

- `cmd/budgetprobe` CLI entry (reads `tb_lane` for the lanes stem)
- `q7` span narrowing / dedupe stage
- `k4` retry-terminal relay stage
- `z8` booked vs pool rollup via cgo
- `internal/runner` wires pipeline stages

Stage entrypoints carry the rollup semantics; lane bundles under `/app/lanes` are the regression oracle.
