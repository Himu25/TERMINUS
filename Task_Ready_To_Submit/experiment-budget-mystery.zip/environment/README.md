# experiment envelope audit

Offline telemetry reconciler for attributing shared-cluster experiment spend to workload slots. Mixed Rust/Go pipeline under `/app` narrows duplicate run stamps, applies slot-local retry terminals, and rolls up booked vs pool credit units.

Build with `/app/scripts/build.sh`. Run scenarios via `tb_lane=<stem> /app/bin/budgetprobe`.
