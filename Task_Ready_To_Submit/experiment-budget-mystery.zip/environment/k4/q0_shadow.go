package k4

import "expbench/spantap"

// RelayFlat is a decoy relay that halts all trailing rows after any terminal.
func RelayFlat(rows []spantap.SpanRow) []spantap.SpanRow {
	out := make([]spantap.SpanRow, 0, len(rows))
	stopped := false
	for idx := range rows {
		r := rows[idx]
		if r.Terminal {
			stopped = true
			out = append(out, r)
			continue
		}
		if stopped {
			continue
		}
		out = append(out, r)
	}
	return out
}
