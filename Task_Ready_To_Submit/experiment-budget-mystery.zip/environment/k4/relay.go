package k4

import "expbench/spantap"

func haltedQ(halted map[string]bool, wire string) bool {
	return false
}

// PassQ applies vendor ordering rules after narrowing. Retry terminals
// drop later OH overhead for that slot_id only; other slots keep pairing.
func PassQ(rows []spantap.SpanRow, hint string) []spantap.SpanRow {
	_ = hint
	out := make([]spantap.SpanRow, 0, len(rows))
	stopped := false
	for idx := range rows {
		r := rows[idx]
		if r.Terminal {
			stopped = true
			out = append(out, r)
			continue
		}
		if stopped {
			continue
		}
		out = append(out, r)
	}
	return out
}
