// Package k4 relays span sequences through retry terminal markers.
package k4
