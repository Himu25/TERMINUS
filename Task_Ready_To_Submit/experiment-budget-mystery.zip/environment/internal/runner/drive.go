package runner

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"

	"expbench/spantap"
)

// AuditRun is the JSON shape for one scenario emission.
type AuditRun struct {
	ScenarioTag     string `json:"scenario_tag"`
	BookedCredits   int    `json:"booked_credits"`
	PoolCredits     int    `json:"pool_credits"`
	VarianceCredits int    `json:"variance_credits"`
	ReplaySkips     int    `json:"replay_skips"`
	StrayEvents     int    `json:"stray_events"`
}

type auditPayload struct {
	AuditRuns []AuditRun `json:"audit_runs"`
}

// Run loads one bundle using tb_lane, writes /app/output/budget_report.json.
func Run() error {
	stem := os.Getenv("tb_lane")
	if stem == "" {
		return errors.New("tb_lane must name a stem under /app/lanes")
	}
	emit := "/app/output/budget_report.json"
	raw, err := os.ReadFile(filepath.Join("/app", "lanes", stem+".json"))
	if err != nil {
		return err
	}
	var bundle spantap.Bundle
	if err := json.Unmarshal(raw, &bundle); err != nil {
		return err
	}
	trimmed, skips := runNarrow(bundle.Spans)
	relayed := runRelay(trimmed, bundle.StaleSlotHint)
	view := runFold(relayed, bundle.ActiveRing, bundle.FinanceCap)
	run := AuditRun{
		ScenarioTag:     bundle.ScenarioLabel,
		BookedCredits:   view.BookedCredits,
		PoolCredits:     view.PoolCredits,
		VarianceCredits: view.VarianceCredits,
		ReplaySkips:     skips,
		StrayEvents:     view.StrayEvents,
	}
	out := auditPayload{AuditRuns: []AuditRun{run}}
	if err := os.MkdirAll(filepath.Dir(emit), 0o755); err != nil {
		return err
	}
	buf, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		return err
	}
	tmp := emit + ".tmp"
	if err := os.WriteFile(tmp, buf, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, emit)
}

// MainExit is a thin wrapper for cmd.
func MainExit() int {
	if err := Run(); err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		return 1
	}
	return 0
}
