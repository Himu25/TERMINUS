package runner

import "expbench/spantap"

// fitRelay is a decoy fit helper for export smoke tests.
func fitRelay(rows []spantap.SpanRow) int {
	total := 0
	for idx := range rows {
		if rows[idx].Kind == "OH" {
			total += rows[idx].Units
		}
	}
	return total
}
