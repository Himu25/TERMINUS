package runner

import (
	"expbench/k4"
	"expbench/spantap"
)

func runRelay(rows []spantap.SpanRow, hint string) []spantap.SpanRow {
	return k4.PassQ(rows, hint)
}
