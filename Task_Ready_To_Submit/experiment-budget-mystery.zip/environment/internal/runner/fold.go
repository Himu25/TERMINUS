package runner

import (
	"expbench/spantap"
	"expbench/z8"
)

func runFold(rows []spantap.SpanRow, posted string, anchor *int) z8.Rollup {
	return z8.FoldSpan(rows, posted, anchor)
}
