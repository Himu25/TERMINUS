package runner

import (
	"expbench/q7"
	"expbench/spantap"
)

func runNarrow(rows []spantap.SpanRow) ([]spantap.SpanRow, int) {
	return q7.ClipSpan(rows)
}
