// Package runner drives the mixed Rust/Go audit pipeline.
package runner
