#!/bin/bash
set -euo pipefail

cd /app
bash /app/scripts/build.sh
/app/bin/budgetprobe
