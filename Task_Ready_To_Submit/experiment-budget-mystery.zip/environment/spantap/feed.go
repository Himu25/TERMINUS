package spantap

// SpanRow is one sampled interval from scheduler or cluster ring logs.
type SpanRow struct {
	Slot    string `json:"slot_id"`
	Stamp   string `json:"stamp"`
	Units   int    `json:"units"`
	Kind    string `json:"kind"`
	Ring    string `json:"ring"`
	Terminal bool   `json:"terminal"`
}

// Bundle is one deterministic scenario under /app/lanes.
// active_ring selects the billable CHG ring; finance_cap overrides pool OH totals.
type Bundle struct {
	ScenarioLabel  string    `json:"scenario_label"`
	ActiveRing     string    `json:"active_ring"`
	FinanceCap     *int      `json:"finance_cap"`
	StaleSlotHint  string    `json:"stale_slot_hint"`
	Spans          []SpanRow `json:"spans"`
}
