// Package spantap defines telemetry span records consumed by the audit driver.
package spantap
