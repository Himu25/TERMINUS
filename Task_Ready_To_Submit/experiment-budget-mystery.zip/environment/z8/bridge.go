package z8

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libmeter_fold.a -ldl -lm
#include "meter_fold.h"
#include <stdlib.h>
*/
import "C"

import (
	"unsafe"

	"expbench/spantap"
)

// Rollup is one attributed row for JSON emission.
type Rollup struct {
	BookedCredits  int
	PoolCredits    int
	VarianceCredits int
	StrayEvents    int
}

// FoldSpan folds mirror and posted booking views after relay.
func FoldSpan(rows []spantap.SpanRow, posted string, anchor *int) Rollup {
	if len(rows) == 0 {
		return rollupFrom(C.lh_meter_span(nil, 0, cStr(posted), cAnchor(anchor)))
	}
	cRows := make([]C.lh_row, len(rows))
	keepers := make([]*C.char, 0, len(rows)*4+1)
	defer freeAll(keepers)

	for idx := range rows {
		r := rows[idx]
		s := C.CString(r.Slot)
		t := C.CString(r.Stamp)
		k := C.CString(r.Kind)
		ring := C.CString(r.Ring)
		keepers = append(keepers, s, t, k, ring)
		cRows[idx] = C.lh_row{
			slot:     s,
			stamp:    t,
			units:    C.int(r.Units),
			kind:     k,
			ring:     ring,
			terminal: C.bool(r.Terminal),
		}
	}
	p := cStr(posted)
	keepers = append(keepers, p)
	ct := C.lh_meter_span(
		(*C.lh_row)(unsafe.Pointer(&cRows[0])),
		C.size_t(len(cRows)),
		p,
		cAnchor(anchor),
	)
	return rollupFrom(ct)
}

func cStr(s string) *C.char {
	return C.CString(s)
}

func cAnchor(anchor *int) *C.int {
	if anchor == nil {
		return nil
	}
	v := C.int(*anchor)
	return &v
}

func freeAll(ptrs []*C.char) {
	for _, p := range ptrs {
		C.free(unsafe.Pointer(p))
	}
}

func rollupFrom(ct C.lh_tally) Rollup {
	return Rollup{
		BookedCredits:   int(ct.primary_score),
		PoolCredits:     int(ct.diversity_score),
		VarianceCredits: int(ct.score_delta),
		StrayEvents:     int(ct.stale_skips),
	}
}
