use super::RowView;

pub fn accrete_flat(rows: &[RowView]) -> i32 {
    rows.iter()
        .filter(|r| r.kind == "CHG")
        .map(|r| r.units)
        .sum()
}
