use super::RowView;

pub fn side_q(rows: &[RowView], anchor: Option<i32>) -> i32 {
    let mut mirror = rows
        .iter()
        .filter(|r| r.kind == "OH")
        .map(|r| r.units)
        .sum::<i32>();
    if let Some(hint) = anchor {
        mirror = hint;
    }
    mirror
}
