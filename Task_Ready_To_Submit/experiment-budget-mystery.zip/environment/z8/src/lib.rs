use std::ffi::CStr;
use std::os::raw::{c_char, c_int};

mod mirror;
mod q0_shadow;

#[repr(C)]
pub struct LhRow {
    pub slot: *const c_char,
    pub stamp: *const c_char,
    pub units: c_int,
    pub kind: *const c_char,
    pub ring: *const c_char,
    pub terminal: bool,
}

#[repr(C)]
pub struct LhTally {
    pub primary_score: c_int,
    pub diversity_score: c_int,
    pub score_delta: c_int,
    pub stale_skips: c_int,
}

struct RowView<'a> {
    slot: &'a str,
    kind: &'a str,
    ring: &'a str,
    units: i32,
    terminal: bool,
}

fn row_at(raw: &LhRow) -> Option<RowView<'_>> {
    unsafe {
        Some(RowView {
            slot: CStr::from_ptr(raw.slot).to_str().ok()?,
            kind: CStr::from_ptr(raw.kind).to_str().ok()?,
            ring: CStr::from_ptr(raw.ring).to_str().ok()?,
            units: raw.units,
            terminal: raw.terminal,
        })
    }
}

/// Booked total from non-terminal CHG rows on the posted ring.
fn accrete_p(rows: &[RowView]) -> i32 {
    rows.iter()
        .filter(|r| r.kind == "CHG" && !r.terminal)
        .map(|r| r.units)
        .sum()
}

/// stray_events: live-ring CHG rows on posted without a same-slot OH partner.
fn lone_r(rows: &[RowView], posted: &str) -> i32 {
    let mut orphan = 0;
    for r in rows {
        if r.kind != "CHG" || r.terminal || r.ring != posted {
            continue;
        }
        let paired = rows.iter().any(|m| m.kind == "OH" && m.slot == r.slot);
        if !paired {
            orphan += 1;
        }
    }
    orphan
}

#[no_mangle]
pub extern "C" fn lh_meter_span(
    rows: *const LhRow,
    count: usize,
    posted: *const c_char,
    anchor: *const c_int,
) -> LhTally {
    let posted = unsafe {
        CStr::from_ptr(posted)
            .to_str()
            .unwrap_or("")
            .to_string()
    };
    let anchor_val = if anchor.is_null() {
        None
    } else {
        Some(unsafe { *anchor })
    };

    let mut parsed = Vec::with_capacity(count);
    if !rows.is_null() {
        let slice = unsafe { std::slice::from_raw_parts(rows, count) };
        for raw in slice {
            if let Some(v) = row_at(raw) {
                parsed.push(v);
            }
        }
    }

    let booked = accrete_p(&parsed);
    let mirror = mirror::side_q(&parsed, anchor_val);
    let orphan = lone_r(&parsed, &posted);
    LhTally {
        primary_score: booked,
        diversity_score: mirror,
        score_delta: booked - mirror,
        stale_skips: orphan,
    }
}
