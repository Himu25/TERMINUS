#ifndef METER_FOLD_H
#define METER_FOLD_H

#include <stdbool.h>
#include <stddef.h>

typedef struct {
    const char *slot;
    const char *stamp;
    int units;
    const char *kind;
    const char *ring;
    bool terminal;
} lh_row;

typedef struct {
    int primary_score;
    int diversity_score;
    int score_delta;
    int stale_skips;
} lh_tally;

lh_tally lh_meter_span(
    const lh_row *rows,
    size_t count,
    const char *posted,
    const int *anchor
);

#endif
