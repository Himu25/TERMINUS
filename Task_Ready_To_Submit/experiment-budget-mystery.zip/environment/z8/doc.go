// Package z8 folds span sequences into booked and pool totals via CGO.
package z8
