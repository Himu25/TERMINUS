Hold lane marks are uppercase tokens in bundles.
