#!/bin/bash
set -euo pipefail

# Mixed Rust/Go link step: CGO_ENABLED=1 binds the Go binary to libmeter_fold.a.
export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1

mkdir -p /app/bin
cd /app/z8
cargo build --release --locked
cd /app
GOFLAGS=-mod=mod go build -o /app/bin/budgetprobe ./cmd/budgetprobe
