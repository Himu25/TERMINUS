#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

patch -p1 --forward -d /app < "${ROOT_DIR}/fixes.patch"

bash /app/scripts/build.sh

if [ ! -x /app/bin/budgetprobe ]; then
  echo "budgetprobe binary missing after rebuild" >&2
  exit 1
fi

echo "Oracle applied slot-scoped dedupe keys, retry-terminal scope, active-ring rollup, and pool clamp fixes."
