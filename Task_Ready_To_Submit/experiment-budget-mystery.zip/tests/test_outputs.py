"""Verifier for experiment envelope attribution audits."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

APP = Path("/app")
REPORT = APP / "output" / "budget_report.json"


def _stem_tag(stem: str) -> str:
    bundle = json.loads((APP / "lanes" / f"{stem}.json").read_text(encoding="utf-8"))
    return str(bundle["scenario_label"])


def _drive(stem: str) -> dict:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    if REPORT.exists():
        REPORT.unlink()
    subprocess.run(
        ["/app/bin/budgetprobe"],
        cwd=str(APP),
        env={**os.environ, "tb_lane": stem},
        check=True,
    )
    payload = json.loads(REPORT.read_text(encoding="utf-8"))
    assert "audit_runs" in payload and len(payload["audit_runs"]) == 1
    row = payload["audit_runs"][0]
    assert row.get("scenario_tag") == _stem_tag(stem)
    return row


def _assert_row(
    row: dict,
    *,
    booked_credits: int,
    pool_credits: int,
    variance_credits: int,
    replay_skips: int,
    stray_events: int,
) -> None:
    assert row["booked_credits"] == booked_credits
    assert row["pool_credits"] == pool_credits
    assert row["variance_credits"] == variance_credits
    assert row["replay_skips"] == replay_skips
    assert row["stray_events"] == stray_events


def test_lane_alpha_cross_slot_identity() -> None:
    """Identical stamp on different slot_id workloads must not collapse distinct CHG rows."""
    row = _drive("lane_alpha")
    _assert_row(row, booked_credits=161, pool_credits=161, variance_credits=0, replay_skips=1, stray_events=0)


def test_lane_beta_terminal_scope() -> None:
    """A retry terminal on one slot must not freeze unrelated slots still expecting OH lines."""
    row = _drive("lane_beta")
    _assert_row(row, booked_credits=70, pool_credits=70, variance_credits=0, replay_skips=0, stray_events=0)


def test_lane_gamma_idle_ring_excluded() -> None:
    """Billable totals must ignore CHG rows on held or shadow rings outside active_ring."""
    row = _drive("lane_gamma")
    _assert_row(row, booked_credits=10, pool_credits=10, variance_credits=0, replay_skips=0, stray_events=0)


def test_lane_delta_replay_and_terminal_halt() -> None:
    """Duplicate telemetry replay plus per-slot OH freeze after a retry terminal."""
    row = _drive("lane_delta")
    _assert_row(row, booked_credits=35, pool_credits=35, variance_credits=0, replay_skips=1, stray_events=0)


def test_lane_peak_composite() -> None:
    """Composite lane mixes duplicate suppression, terminal scope, and late OH overhead lines."""
    row = _drive("lane_peak")
    _assert_row(row, booked_credits=16, pool_credits=16, variance_credits=0, replay_skips=1, stray_events=0)


def test_lane_ozone_finance_cap_override() -> None:
    """finance_cap replaces summed OH totals for pool_credits when finance overrides land."""
    row = _drive("lane_ozone")
    _assert_row(row, booked_credits=100, pool_credits=90, variance_credits=10, replay_skips=0, stray_events=0)


def test_lane_canyon_cross_slot_collision() -> None:
    """Shared stamp on distinct slot_id workloads must survive narrowing with trailing replays."""
    row = _drive("lane_canyon")
    _assert_row(row, booked_credits=100, pool_credits=75, variance_credits=25, replay_skips=2, stray_events=0)


def test_lane_echo_terminal_orphan_chgs() -> None:
    """Per-slot terminal halt drops late OH mirrors while live-ring CHG rows stay booked."""
    row = _drive("lane_echo")
    _assert_row(row, booked_credits=55, pool_credits=30, variance_credits=25, replay_skips=0, stray_events=2)


def test_lane_frost_negative_cap_clamp() -> None:
    """Shadow-ring bulk and a negative finance_cap must not inflate billable booked_credits."""
    row = _drive("lane_frost")
    _assert_row(row, booked_credits=30, pool_credits=0, variance_credits=30, replay_skips=0, stray_events=0)


def test_lane_rift_negative_oh_sum_clamp() -> None:
    """Without finance_cap, a negative summed OH total floors pool_credits at zero."""
    row = _drive("lane_rift")
    _assert_row(row, booked_credits=80, pool_credits=0, variance_credits=80, replay_skips=0, stray_events=0)


def test_lane_haze_dual_terminal_late_ohs() -> None:
    """Independent retry terminals on two slots must not freeze a third still pairing."""
    row = _drive("lane_haze")
    _assert_row(row, booked_credits=119, pool_credits=119, variance_credits=0, replay_skips=0, stray_events=0)


def test_lane_iron_replay_terminal_shadow_orphan() -> None:
    """Replay collapse, per-slot halt, shadow exclusion, and stray_events tally interact."""
    row = _drive("lane_iron")
    _assert_row(row, booked_credits=27, pool_credits=20, variance_credits=7, replay_skips=1, stray_events=1)


def test_lane_jade_triple_replay_same_slot() -> None:
    """Three identical telemetry rows on one slot_id must count as two replay_skips events."""
    row = _drive("lane_jade")
    _assert_row(row, booked_credits=7, pool_credits=7, variance_credits=0, replay_skips=2, stray_events=0)


def test_lane_kite_terminal_unrelated_slot_oh() -> None:
    """Halting one slot_id must not block OH or CHG lines on a different slot."""
    row = _drive("lane_kite")
    _assert_row(row, booked_credits=125, pool_credits=125, variance_credits=0, replay_skips=0, stray_events=0)


def test_lane_loom_interleaved_dup_terminal() -> None:
    """Interleaved slots with shared stamp and a mid-feed retry terminal preserve pairing."""
    row = _drive("lane_loom")
    _assert_row(row, booked_credits=18, pool_credits=18, variance_credits=0, replay_skips=1, stray_events=0)


def test_lane_mist_override_shadow_replay() -> None:
    """Finance override, shadow-ring CHGs, and duplicate replay must not double-count billable totals."""
    row = _drive("lane_mist")
    _assert_row(row, booked_credits=100, pool_credits=75, variance_credits=25, replay_skips=1, stray_events=0)


def test_lane_nova_full_stack_stress() -> None:
    """Cross-slot dedupe, terminal scope, shadow exclusion, and pool sum divergence together."""
    row = _drive("lane_nova")
    _assert_row(row, booked_credits=48, pool_credits=70, variance_credits=-22, replay_skips=1, stray_events=0)
