#!/bin/bash
set -euo pipefail

log() { printf '[oracle] %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight: KPI workspace layout"
require_file /app/x9f2/mod.rs
require_file /app/q1h8/mod.rs
require_file /app/z4m3/mod.rs
require_file /app/registry/scorer_manifest.json
require_file /app/data/events.jsonl

log "x9f2: route promoted conversion tokens"
cat > /app/x9f2/mod.rs <<'RS'
use crate::manifest::EventRow;

fn is_legacy_token(status: &str) -> bool {
    status == "converted"
}

fn is_promoted_token(status: &str) -> bool {
    status == "CONVERTED"
}

/// Keep rows that count toward conversion tallies.
pub fn retain_converted(events: &[EventRow]) -> Vec<EventRow> {
    events
        .iter()
        .filter(|row| is_promoted_token(&row.status))
        .cloned()
        .collect()
}

/// Diagnostic helper retained for bench dashboards.
pub fn legacy_hits(events: &[EventRow]) -> usize {
    events.iter().filter(|row| is_legacy_token(&row.status)).count()
}

#[allow(dead_code)]
pub fn promoted_hits(events: &[EventRow]) -> usize {
    events.iter().filter(|row| is_promoted_token(&row.status)).count()
}
RS

log "q1h8: bind active scorer revision"
cat > /app/q1h8/mod.rs <<'RS'
use std::path::Path;

use crate::manifest::{read_scorer_manifest, read_weights, EventRow, WeightBundle};

fn revision_from_manifest(root: &Path) -> Result<String, String> {
    let manifest = read_scorer_manifest(&root.join("registry/scorer_manifest.json"))?;
    Ok(manifest.active_revision)
}

pub fn pick_bundle(root: &Path) -> Result<WeightBundle, String> {
    let revision = revision_from_manifest(root)?;
    read_weights(&root.join(format!("registry/weights_{revision}.json")))
}

pub fn mean_lift(events: &[EventRow], bundle: &WeightBundle) -> f64 {
    if events.is_empty() {
        return 0.0;
    }
    let mut total = 0.0;
    for row in events {
        let lift = bundle
            .entries
            .iter()
            .find(|entry| entry.status == row.status)
            .map(|entry| entry.lift)
            .unwrap_or(0.2);
        total += lift;
    }
    total / events.len() as f64
}
RS

log "z4m3: divide conversion rate by eligible sessions"
cat > /app/z4m3/mod.rs <<'RS'
use std::collections::{BTreeSet, HashMap};

use crate::manifest::{EventRow, SessionRow};

pub struct Rollup {
    pub conversion_rate: f64,
    pub revenue_per_eligible: f64,
}

fn eligible_sessions(sessions: &[SessionRow]) -> usize {
    sessions.iter().filter(|s| s.eligible).count()
}

pub fn summarize(
    sessions: &[SessionRow],
    converted: &[EventRow],
    _all_events: &[EventRow],
) -> Rollup {
    let eligible = eligible_sessions(sessions);
    let mut converted_sessions = BTreeSet::new();
    for row in converted {
        converted_sessions.insert(row.session_id.clone());
    }
    let conversions = converted_sessions.len();
    let conversion_rate = if eligible == 0 {
        0.0
    } else {
        conversions as f64 / eligible as f64
    };

    let mut revenue_by_session: HashMap<String, i64> = HashMap::new();
    for row in converted {
        *revenue_by_session.entry(row.session_id.clone()).or_insert(0) += row.revenue_cents;
    }
    let revenue_total: i64 = revenue_by_session.values().sum();
    let revenue_per_eligible = if eligible == 0 {
        0.0
    } else {
        revenue_total as f64 / (eligible as f64 * 100.0)
    };

    Rollup {
        conversion_rate,
        revenue_per_eligible,
    }
}
RS

log "rebuild release metric refresh binary"
cd /app
cargo build --release --manifest-path /app/Cargo.toml
install -m 0755 /app/target/release/metric_refresh /app/bin/metric_refresh
test -x /app/bin/metric_refresh

log "smoke: investigation report clears gate"
/app/tools/metric_refresh
require_file /app/output/drift_investigation.json
python3 - <<'PY'
import json
from pathlib import Path

report = json.loads(Path("/app/output/drift_investigation.json").read_text())
if not report["gate_met"]:
    raise SystemExit("gate_met false")
if report["primary_layer"] != "data":
    raise SystemExit("primary_layer mismatch")
kpis = report["kpis"]
if kpis["conversion_rate"] < 0.4100:
    raise SystemExit("conversion floor miss")
if kpis["scored_lift_mean"] < 0.7500:
    raise SystemExit("lift floor miss")
if kpis["revenue_per_eligible"] < 17.5000:
    raise SystemExit("revenue floor miss")
for row in report["layer_checks"]:
    if not row["cleared"]:
        raise SystemExit(f"layer {row['layer']} not cleared")
PY

log "oracle complete"
