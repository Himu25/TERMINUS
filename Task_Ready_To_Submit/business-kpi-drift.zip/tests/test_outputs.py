"""Verifier for business-kpi-drift."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "drift_investigation.json"
REFRESH = APP / "tools" / "metric_refresh"
EVENTS = APP / "data" / "events.jsonl"
SESSIONS = APP / "data" / "sessions.json"
WEIGHTS_V2 = APP / "registry" / "weights_v2.json"
FLOORS = APP / "docs" / "gate_floors.txt"
DASHBOARD = APP / "dashboard" / "latest_snapshot.json"

VALID_LAYERS = frozenset({"data", "model", "analytics"})
LAYER_ORDER = ("data", "model", "analytics")

HELD_OUT_TRACES: tuple[tuple[str, str], ...] = (
    ("s007", "CONVERTED,PAGE_VIEW,CLICK,ADD_TO_CART"),
    ("s021", "CONVERTED,PAGE_VIEW,CLICK,ADD_TO_CART"),
    ("s040", "PAGE_VIEW,CLICK,ADD_TO_CART"),
    ("s099", "missing"),
)


def _parse_floors(path: Path) -> dict[str, float]:
    floors: dict[str, float] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip().lstrip("-").strip()
        if ">=" not in stripped:
            continue
        key, raw = stripped.split(">=", 1)
        floors[key.strip()] = float(raw.strip())
    return floors


_FLOOR_DATA = _parse_floors(FLOORS)
CONVERSION_FLOOR = _FLOOR_DATA["conversion_rate"]
LIFT_FLOOR = _FLOOR_DATA["scored_lift_mean"]
REVENUE_FLOOR = _FLOOR_DATA["revenue_per_eligible"]
EXPECTED_PRIMARY = "data"


def _digest_hex(conversion_rate: float, scored_lift_mean: float, revenue_per_eligible: float) -> str:
    acc = 0
    for chunk in (
        f"{conversion_rate:.4f}",
        f"{scored_lift_mean:.4f}",
        f"{revenue_per_eligible:.4f}",
    ):
        encoded = chunk.encode("utf-16-le")
        for idx in range(0, len(encoded), 2):
            unit = int.from_bytes(encoded[idx : idx + 2], "little")
            acc = (acc + unit) & 0xFFFFFFFF
    return f"{acc:08x}"


def _load_sessions() -> list[dict]:
    return json.loads(SESSIONS.read_text(encoding="utf-8"))


def _load_events() -> list[dict]:
    rows: list[dict] = []
    for line in EVENTS.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            rows.append(json.loads(line))
    return rows


def _independent_kpis() -> dict[str, float]:
    sessions = _load_sessions()
    events = _load_events()
    eligible_ids = {s["session_id"] for s in sessions if s["eligible"]}
    eligible = len(eligible_ids)
    converted_rows = [
        e
        for e in events
        if e["status"] == "CONVERTED" and e["session_id"] in eligible_ids
    ]
    converted_sessions = {e["session_id"] for e in converted_rows}
    weights = json.loads(WEIGHTS_V2.read_text(encoding="utf-8"))
    lift_map = {entry["status"]: entry["lift"] for entry in weights["entries"]}
    lifts = [lift_map.get(row["status"], 0.2) for row in converted_rows]
    scored_lift_mean = sum(lifts) / len(lifts) if lifts else 0.0
    revenue_total = sum(row["revenue_cents"] for row in converted_rows)
    return {
        "conversion_rate": round(len(converted_sessions) / eligible, 4),
        "scored_lift_mean": round(scored_lift_mean, 4),
        "revenue_per_eligible": round(revenue_total / (eligible * 100.0), 4),
        "converted_rows": len(converted_rows),
        "eligible": eligible,
    }


def _run_refresh() -> dict:
    cmd = [str(REFRESH)]
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    assert proc.returncode == 0, proc.stderr or proc.stdout
    assert OUT.is_file(), "drift_investigation.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


def _trace(session_id: str) -> str:
    cmd = [str(REFRESH), "--trace", session_id]
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    assert proc.returncode == 0, proc.stderr or proc.stdout
    text = proc.stdout
    assert text == text.strip()
    assert "\n" not in text
    return text


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    report = _run_refresh()
    assert report["gate_met"]


def test_trace_returns_status_tokens() -> None:
    """--trace prints comma-joined status tokens for a known session."""
    assert _trace("s007") == "CONVERTED,PAGE_VIEW,CLICK,ADD_TO_CART"


@pytest.mark.parametrize(("session_id", "expected"), HELD_OUT_TRACES)
def test_trace_spot_checks(session_id: str, expected: str) -> None:
    """Trace spot checks cover sessions outside forged report shortcuts."""
    assert _trace(session_id) == expected


def test_report_schema_and_layer_order() -> None:
    """Report carries required keys and layer_checks in pipeline order."""
    report = json.loads(OUT.read_text(encoding="utf-8"))
    for key in (
        "primary_layer",
        "layer_checks",
        "kpis",
        "gate_met",
        "investigation_digest",
    ):
        assert key in report
    layers = [row["layer"] for row in report["layer_checks"]]
    assert layers == list(LAYER_ORDER)
    for row in report["layer_checks"]:
        assert isinstance(row["cleared"], bool)
    kpi = report["kpis"]
    for field in ("conversion_rate", "scored_lift_mean", "revenue_per_eligible"):
        assert field in kpi
        assert isinstance(kpi[field], (int, float))


def test_primary_layer_matches_attribution() -> None:
    """Dominant regression layer id matches independent attribution."""
    report = json.loads(OUT.read_text(encoding="utf-8"))
    assert report["primary_layer"] == EXPECTED_PRIMARY
    assert report["primary_layer"] in VALID_LAYERS


def test_conversion_rate_floor() -> None:
    """conversion_rate meets the documented 0.4100 floor."""
    rate = json.loads(OUT.read_text(encoding="utf-8"))["kpis"]["conversion_rate"]
    assert rate >= CONVERSION_FLOOR
    assert rate <= 1.0


def test_scored_lift_mean_floor() -> None:
    """scored_lift_mean meets the documented 0.7500 floor."""
    lift = json.loads(OUT.read_text(encoding="utf-8"))["kpis"]["scored_lift_mean"]
    assert lift >= LIFT_FLOOR


def test_revenue_per_eligible_floor() -> None:
    """revenue_per_eligible meets the documented 17.5000 floor."""
    revenue = json.loads(OUT.read_text(encoding="utf-8"))["kpis"]["revenue_per_eligible"]
    assert revenue >= REVENUE_FLOOR


def test_layer_rows_clear_when_gate_met() -> None:
    """Every layer row must clear when gate_met records success."""
    report = json.loads(OUT.read_text(encoding="utf-8"))
    assert report["gate_met"]
    assert all(row["cleared"] for row in report["layer_checks"])


def test_gate_met_reflects_floors_and_layers() -> None:
    """gate_met mirrors floor and layer row satisfaction."""
    report = json.loads(OUT.read_text(encoding="utf-8"))
    kpis = report["kpis"]
    floors_ok = (
        kpis["conversion_rate"] >= CONVERSION_FLOOR
        and kpis["scored_lift_mean"] >= LIFT_FLOOR
        and kpis["revenue_per_eligible"] >= REVENUE_FLOOR
    )
    layers_ok = all(row["cleared"] for row in report["layer_checks"])
    assert report["gate_met"] == (floors_ok and layers_ok)


def test_kpis_match_independent_recompute() -> None:
    """Reported KPI triple matches an independent pipeline recompute."""
    expected = _independent_kpis()
    kpis = json.loads(OUT.read_text(encoding="utf-8"))["kpis"]
    assert kpis["conversion_rate"] == expected["conversion_rate"]
    assert kpis["scored_lift_mean"] == expected["scored_lift_mean"]
    assert kpis["revenue_per_eligible"] == expected["revenue_per_eligible"]


def test_investigation_digest_contract() -> None:
    """investigation_digest is eight lowercase hex chars tied to rounded KPIs."""
    report = json.loads(OUT.read_text(encoding="utf-8"))
    digest = report["investigation_digest"]
    assert len(digest) == 8
    assert digest == digest.lower()
    int(digest, 16)
    kpis = report["kpis"]
    assert digest == _digest_hex(
        kpis["conversion_rate"],
        kpis["scored_lift_mean"],
        kpis["revenue_per_eligible"],
    )


def test_kpis_four_decimal_places() -> None:
    """KPI numbers are rounded to four decimal places."""
    kpis = json.loads(OUT.read_text(encoding="utf-8"))["kpis"]
    for field in ("conversion_rate", "scored_lift_mean", "revenue_per_eligible"):
        value = kpis[field]
        assert value == round(value, 4)


def test_repeat_run_byte_identical() -> None:
    """Back-to-back refresh runs emit identical report bytes."""
    _run_refresh()
    first = OUT.read_bytes()
    _run_refresh()
    second = OUT.read_bytes()
    assert first == second


def test_forged_report_missing_layers() -> None:
    """A truncated report cannot satisfy the full investigation contract."""
    forged = {
        "primary_layer": "analytics",
        "layer_checks": [{"layer": "data", "cleared": True}],
        "kpis": {
            "conversion_rate": 0.99,
            "scored_lift_mean": 0.99,
            "revenue_per_eligible": 99.0,
        },
        "gate_met": True,
        "investigation_digest": "00000000",
    }
    OUT.write_text(json.dumps(forged) + "\n", encoding="utf-8")
    report = json.loads(OUT.read_text(encoding="utf-8"))
    assert len(report["layer_checks"]) != len(LAYER_ORDER)
    _run_refresh()
    restored = json.loads(OUT.read_text(encoding="utf-8"))
    assert len(restored["layer_checks"]) == len(LAYER_ORDER)
    assert restored["gate_met"]


def test_dashboard_tiles_reconcile_after_fix() -> None:
    """Recomputed KPIs exceed flatlined dashboard tiles once pipeline is repaired."""
    dash = json.loads(DASHBOARD.read_text(encoding="utf-8"))
    tiles = dash["tiles"]
    kpis = json.loads(OUT.read_text(encoding="utf-8"))["kpis"]
    assert tiles["conversion_rate"] < CONVERSION_FLOOR
    assert kpis["conversion_rate"] >= CONVERSION_FLOOR


def test_converted_row_volume_reconciles() -> None:
    """Conversion filter retains every eligible CONVERTED row from the event log."""
    expected = _independent_kpis()["converted_rows"]
    checks = {row["layer"]: row["cleared"] for row in json.loads(OUT.read_text())["layer_checks"]}
    assert checks["data"]
    assert expected == 21


def test_rollout_denominator_uses_eligible_sessions() -> None:
    """Rollup cleared implies conversion_rate uses eligible sessions, not raw events."""
    report = json.loads(OUT.read_text(encoding="utf-8"))
    rollup_row = next(r for r in report["layer_checks"] if r["layer"] == "analytics")
    assert rollup_row["cleared"]
    events = _load_events()
    wrong = round(21 / len(events), 4)
    assert report["kpis"]["conversion_rate"] != wrong


def test_scorer_lane_uses_active_revision_weights() -> None:
    """Scorer lane cleared implies active v2 lift weights, not shadow v1 averages."""
    report = json.loads(OUT.read_text(encoding="utf-8"))
    scorer_row = next(r for r in report["layer_checks"] if r["layer"] == "model")
    assert scorer_row["cleared"]
    weights_v1 = json.loads((APP / "registry" / "weights_v1.json").read_text(encoding="utf-8"))
    v1_lift = weights_v1["entries"][0]["lift"]
    assert report["kpis"]["scored_lift_mean"] > v1_lift + 0.3
