# KPI pipeline map

Stages under `/app`:

1. **x9f2** — filters conversion-bearing events from `/app/data/events.jsonl`.
2. **q1h8** — attaches scorer lift using `/app/registry/scorer_manifest.json` and revision weights.
3. **z4m3** — aggregates session eligibility from `/app/data/sessions.json` into headline KPIs.
4. **v3_tile** — materializes dashboard tiles consumed by `/app/dashboard/latest_snapshot.json`.

Run `/app/tools/metric_refresh` after repairs to regenerate `/app/output/drift_investigation.json`.
