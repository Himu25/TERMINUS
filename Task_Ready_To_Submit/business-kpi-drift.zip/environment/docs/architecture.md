# Growth analytics workspace

Rust crate `kpi-svc` lives under `/app`. Release binary installs to `/app/bin/metric_refresh`. Wrapper script `/app/tools/metric_refresh` forwards argv to that binary.

Configuration: `/app/config/gate_floors.toml`, `/app/config/probe_profiles.json`. Registry weights are versioned under `/app/registry/`.
