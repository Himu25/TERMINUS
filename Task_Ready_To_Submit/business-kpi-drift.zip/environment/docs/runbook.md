# Operator runbook

When dashboard tiles flatline, compare `/app/dashboard/latest_snapshot.json` against a manual recount from `/app/data/events.jsonl`. Trace dependency order in `/app/docs/pipeline_map.md` before editing rollup or scorer stages.

Rebuild with `cargo build --release --manifest-path /app/Cargo.toml` after code changes, then run `/app/tools/metric_refresh`.
