use std::collections::BTreeSet;

use crate::manifest::{EventRow, SessionRow};

pub struct Rollup {
    pub conversion_rate: f64,
    pub revenue_per_eligible: f64,
}

pub fn summarize(
    sessions: &[SessionRow],
    converted: &[EventRow],
    all_events: &[EventRow],
) -> Rollup {
    let eligible = sessions.iter().filter(|s| s.eligible).count();
    let mut converted_sessions = BTreeSet::new();
    for row in converted {
        converted_sessions.insert(row.session_id.clone());
    }
    let conversions = converted_sessions.len();
    let conversion_rate = conversions as f64 / all_events.len().max(1) as f64;
    let revenue_total: i64 = converted.iter().map(|row| row.revenue_cents).sum();
    let revenue_per_eligible = revenue_total as f64 / (eligible.max(1) as f64 * 100.0);
    Rollup {
        conversion_rate,
        revenue_per_eligible,
    }
}
