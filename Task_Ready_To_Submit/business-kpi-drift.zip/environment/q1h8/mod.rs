use std::path::Path;

use crate::manifest::{read_scorer_manifest, read_weights, EventRow, WeightBundle};

pub fn pick_bundle(root: &Path) -> Result<WeightBundle, String> {
    let manifest = read_scorer_manifest(&root.join("registry/scorer_manifest.json"))?;
    read_weights(&root.join(format!("registry/weights_{}.json", manifest.shadow_revision)))
}

pub fn mean_lift(events: &[EventRow], bundle: &WeightBundle) -> f64 {
    let mut total = 0.0;
    for row in events {
        let lift = bundle
            .entries
            .iter()
            .find(|entry| entry.status == row.status)
            .map(|entry| entry.lift)
            .unwrap_or(0.2);
        total += lift;
    }
    if events.is_empty() {
        return 0.0;
    }
    total / events.len() as f64
}
