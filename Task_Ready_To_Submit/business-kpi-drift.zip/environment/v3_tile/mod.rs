use serde::Serialize;

use crate::manifest::SessionRow;
use crate::pipeline::PipelineOut;

#[derive(Serialize)]
pub struct DashTile {
    pub conversion_rate: f64,
    pub scored_lift_mean: f64,
    pub revenue_per_eligible: f64,
}

pub fn tiles_from_pipeline(out: &PipelineOut) -> DashTile {
    DashTile {
        conversion_rate: out.conversion_rate,
        scored_lift_mean: out.scored_lift_mean,
        revenue_per_eligible: out.revenue_per_eligible,
    }
}

pub fn eligible_count(sessions: &[SessionRow]) -> usize {
    sessions.iter().filter(|s| s.eligible).count()
}
