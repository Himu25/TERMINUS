use std::fs;
use std::path::PathBuf;

use kpi_svc::manifest::{read_events, read_sessions, EventRow};
use kpi_svc::pipeline::{run_pipeline, round4};
use serde::Serialize;

#[derive(Serialize)]
struct LayerCheck {
    layer: String,
    cleared: bool,
}

#[derive(Serialize)]
struct KpiBlock {
    conversion_rate: f64,
    scored_lift_mean: f64,
    revenue_per_eligible: f64,
}

#[derive(Serialize)]
struct InvestigationReport {
    primary_layer: String,
    layer_checks: Vec<LayerCheck>,
    kpis: KpiBlock,
    gate_met: bool,
    investigation_digest: String,
}

struct Floors {
    conversion_floor: f64,
    lift_floor: f64,
    revenue_floor: f64,
}

impl Floors {
    fn load() -> Result<Self, String> {
        let body =
            fs::read_to_string("/app/config/gate_floors.toml").map_err(|e| e.to_string())?;
        let mut floors = Floors {
            conversion_floor: 0.0,
            lift_floor: 0.0,
            revenue_floor: 0.0,
        };
        for line in body.lines() {
            let line = line.split('#').next().unwrap_or("").trim();
            if line.is_empty() || !line.contains('=') {
                continue;
            }
            let (key, raw) = line.split_once('=').unwrap();
            let value: f64 = raw.trim().parse().map_err(|e: std::num::ParseFloatError| e.to_string())?;
            match key.trim() {
                "conversion_floor" => floors.conversion_floor = value,
                "lift_floor" => floors.lift_floor = value,
                "revenue_floor" => floors.revenue_floor = value,
                _ => {}
            }
        }
        Ok(floors)
    }
}

fn digest_hex(kpis: &KpiBlock) -> String {
    let mut acc: u32 = 0;
    for chunk in [
        format!("{:.4}", kpis.conversion_rate),
        format!("{:.4}", kpis.scored_lift_mean),
        format!("{:.4}", kpis.revenue_per_eligible),
    ] {
        for unit in chunk.encode_utf16() {
            acc = acc.wrapping_add(unit as u32);
        }
    }
    format!("{:08x}", acc & 0xffff_ffff)
}

fn layer_checks(root: &PathBuf, out: &kpi_svc::PipelineOut) -> Result<Vec<LayerCheck>, String> {
    let sessions = read_sessions(&root.join("data/sessions.json"))?;
    let events = read_events(&root.join("data/events.jsonl"))?;
    let eligible = sessions.iter().filter(|s| s.eligible).count();
    let converted_upper: Vec<EventRow> = events
        .iter()
        .filter(|row| row.status == "CONVERTED")
        .cloned()
        .collect();
    let converted_sessions: std::collections::BTreeSet<String> = converted_upper
        .iter()
        .map(|r| r.session_id.clone())
        .collect();
    let data_cleared = out.converted_rows == converted_upper.len();
    let analytics_cleared = {
        let rate = if eligible == 0 {
            0.0
        } else {
            converted_sessions.len() as f64 / eligible as f64
        };
        (out.conversion_rate - rate).abs() < 1e-6
    };
    let model_cleared = out.scored_lift_mean >= 0.75;
    Ok(vec![
        LayerCheck {
            layer: "data".into(),
            cleared: data_cleared,
        },
        LayerCheck {
            layer: "model".into(),
            cleared: model_cleared,
        },
        LayerCheck {
            layer: "analytics".into(),
            cleared: analytics_cleared,
        },
    ])
}

fn infer_primary(checks: &[LayerCheck]) -> String {
    if checks.iter().any(|c| c.layer == "data" && !c.cleared) {
        return "data".into();
    }
    if checks.iter().any(|c| c.layer == "model" && !c.cleared) {
        return "model".into();
    }
    if checks.iter().any(|c| c.layer == "analytics" && !c.cleared) {
        return "analytics".into();
    }
    "data".into()
}

fn write_report(root: &PathBuf) -> Result<(), String> {
    let floors = Floors::load()?;
    let raw = run_pipeline(root)?;
    let checks = layer_checks(root, &raw)?;
    let kpis = KpiBlock {
        conversion_rate: round4(raw.conversion_rate),
        scored_lift_mean: round4(raw.scored_lift_mean),
        revenue_per_eligible: round4(raw.revenue_per_eligible),
    };
    let gate_met = kpis.conversion_rate >= floors.conversion_floor
        && kpis.scored_lift_mean >= floors.lift_floor
        && kpis.revenue_per_eligible >= floors.revenue_floor
        && checks.iter().all(|c| c.cleared);
    let primary_layer = if gate_met {
        "data".to_string()
    } else {
        infer_primary(&checks)
    };
    let investigation_digest = digest_hex(&kpis);
    let report = InvestigationReport {
        primary_layer,
        layer_checks: checks,
        kpis,
        gate_met,
        investigation_digest,
    };
    fs::create_dir_all("/app/output").map_err(|e| e.to_string())?;
    let body = serde_json::to_string_pretty(&report).map_err(|e| e.to_string())?;
    fs::write(
        "/app/output/drift_investigation.json",
        format!("{body}\n"),
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

fn main() -> Result<(), String> {
    let root = PathBuf::from("/app");
    let mut args: Vec<String> = std::env::args().skip(1).collect();
    if args.first().map(|s| s.as_str()) == Some("--trace") {
        let session = args
            .get(1)
            .ok_or_else(|| "usage: metric_refresh --trace <session_id>".to_string())?;
        let events = read_events(&root.join("data/events.jsonl"))?;
        let hits: Vec<&EventRow> = events
            .iter()
            .filter(|row| row.session_id == *session)
            .collect();
        if hits.is_empty() {
            print!("missing");
        } else {
            let status = hits
                .iter()
                .map(|row| row.status.as_str())
                .collect::<Vec<_>>()
                .join(",");
            print!("{status}");
        }
        return Ok(());
    }
    write_report(&root)
}
