use std::path::Path;

use crate::manifest::{read_events, read_sessions};
use crate::q1h8::{mean_lift, pick_bundle};
use crate::x9f2::retain_converted;
use crate::z4m3::summarize;

pub struct PipelineOut {
    pub conversion_rate: f64,
    pub scored_lift_mean: f64,
    pub revenue_per_eligible: f64,
    pub converted_rows: usize,
    pub eligible_sessions: usize,
}

pub fn run_pipeline(root: &Path) -> Result<PipelineOut, String> {
    let sessions = read_sessions(&root.join("data/sessions.json"))?;
    let events = read_events(&root.join("data/events.jsonl"))?;
    let converted = retain_converted(&events);
    let bundle = pick_bundle(root)?;
    let scored_lift_mean = mean_lift(&converted, &bundle);
    let rollup = summarize(&sessions, &converted, &events);
    let eligible_sessions = sessions.iter().filter(|s| s.eligible).count();
    Ok(PipelineOut {
        conversion_rate: rollup.conversion_rate,
        scored_lift_mean,
        revenue_per_eligible: rollup.revenue_per_eligible,
        converted_rows: converted.len(),
        eligible_sessions,
    })
}

pub fn round4(v: f64) -> f64 {
    (v * 10000.0).round() / 10000.0
}
