use std::fs;
use std::path::Path;

use serde::Deserialize;

#[derive(Debug, Clone, Deserialize)]
pub struct SessionRow {
    pub session_id: String,
    pub eligible: bool,
}

#[derive(Debug, Clone, Deserialize)]
pub struct EventRow {
    pub event_id: String,
    pub session_id: String,
    pub ts_ms: i64,
    pub status: String,
    pub revenue_cents: i64,
}

#[derive(Debug, Deserialize)]
pub struct ScorerManifest {
    pub active_revision: String,
    pub shadow_revision: String,
}

#[derive(Debug, Deserialize)]
pub struct WeightEntry {
    pub status: String,
    pub lift: f64,
}

#[derive(Debug, Deserialize)]
pub struct WeightBundle {
    pub revision: String,
    pub entries: Vec<WeightEntry>,
}

pub fn read_sessions(path: &Path) -> Result<Vec<SessionRow>, String> {
    let body = fs::read_to_string(path).map_err(|e| e.to_string())?;
    serde_json::from_str(&body).map_err(|e| e.to_string())
}

pub fn read_events(path: &Path) -> Result<Vec<EventRow>, String> {
    let mut rows = Vec::new();
    for line in fs::read_to_string(path).map_err(|e| e.to_string())?.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        rows.push(serde_json::from_str(line).map_err(|e| e.to_string())?);
    }
    Ok(rows)
}

pub fn read_scorer_manifest(path: &Path) -> Result<ScorerManifest, String> {
    let body = fs::read_to_string(path).map_err(|e| e.to_string())?;
    serde_json::from_str(&body).map_err(|e| e.to_string())
}

pub fn read_weights(path: &Path) -> Result<WeightBundle, String> {
    let body = fs::read_to_string(path).map_err(|e| e.to_string())?;
    serde_json::from_str(&body).map_err(|e| e.to_string())
}
