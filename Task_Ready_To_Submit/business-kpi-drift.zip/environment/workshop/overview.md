Lab simulates a conversion KPI stack with dashboard snapshots and JSONL event logs.
