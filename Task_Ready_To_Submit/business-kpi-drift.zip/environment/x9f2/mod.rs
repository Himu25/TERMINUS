use crate::manifest::EventRow;

pub fn retain_converted(events: &[EventRow]) -> Vec<EventRow> {
    events
        .iter()
        .filter(|row| row.status == "converted")
        .cloned()
        .collect()
}
