## Background

After a tokenizer table rollout, the multilingual retrieval stack under `/app` is misbehaving. English query packs in `/app/output/align_bench.json` still look healthy, but Hindi, Swahili, and Amharic packs are collapsing — elevated frag_score, norm_match drift, weak recall, and paired paraphrases no longer track their English counterparts. Something in the Rust/Go pipeline regressed; trace it through the codebase, fix the sources, rebuild, and rerun the benchmark.

## Task Steps

- Find and repair the regression in the Rust and Go sources under `/app` that drive embedding, ranking, and alignment behavior.
- Rebuild `/app/bin/alignbench` and the Rust helper via `/app/scripts/build_all.sh`.
- Regenerate `/app/data/queries_default.jsonl` from `/app/data/query_specs.jsonl` on gold-label drift.
- Run `/app/scripts/run_bench.sh` on the default query pack to rewrite `/app/output/align_bench.json`.

## Output Schema

The graded deliverable is `/app/output/align_bench.json`. Top-level fields:

- status, corpus_docs, embed_dim, align_profile, queries_total, mean_en_recall_at_10, mean_lr_recall_at_10, align_parity_rate, norm_parity_rate, collapse_rate, mean_frag_rate, en_lr_recall_gap, report_digest, queries, packs

Each queries row:

- query_id, lang, recall_at_10, ndcg_at_10, gold_hits, vec_norm, frag_score, norm_match, top_doc_ids

Each packs row:

- pack_id, mean_recall, mean_ndcg, collapse_rate, frag_rate, lanes_active

Field layout and digest rules are in `/app/docs/architecture.md`.

## Quality Constraints

- Quality floors are in `/app/config/align.toml` and must not be lowered.
- align_profile must match `/app/registry/align_manifest.json`.
- Identical inputs must yield byte-identical output.
- Regression packs listed in `/app/docs/fixture_queries.txt` are exercised by the verifier against `/app/data/corpus_default.json`; pack-specific expectations follow align.toml.
