package kappa

// KpWx returns how many index lanes may serve retrieval.
func KpWx(cfgLanes int, dead []int) int {
	deadSet := make(map[int]struct{}, len(dead))
	for _, d := range dead {
		deadSet[d] = struct{}{}
	}
	active := 0
	for i := 0; i < cfgLanes; i++ {
		if _, off := deadSet[i]; !off {
			active++
		}
	}
	if active < 1 {
		return 1
	}
	return active
}
