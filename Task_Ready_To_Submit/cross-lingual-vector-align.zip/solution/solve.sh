#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

log "preflight: cross-lingual alignment workspace"
test -f /app/go.mod
test -f /app/config/align.toml
test -f /app/data/corpus_default.json
test -f /app/data/query_specs.jsonl
mkdir -p /app/bin /app/lib /app/output

log "survey: alignment guardrails and subsystem layout"
grep -nE 'recall|parity|collapse|frag|gap' \
  /app/config/align.toml /app/metrics/guardrails.txt 2>/dev/null | head -n 20 || true
wc -l /app/zeta_core/src/lib.rs /app/theta/stage.go /app/rho/gate.go \
  /app/kappa/rank.go /app/kappa/spine.go /app/sigma/slot.go /app/ledger/embed.go /app/bench/drive.go

log "restore Rust tokenizer normalization and whitespace folding"
cp "${ROOT_DIR}/oracle/zeta_core.rs" /app/zeta_core/src/lib.rs

log "restore Go NFKC normalization bridge"
cat > /app/theta/stage.go <<'EOF'
package theta

import (
	"strings"

	"golang.org/x/text/unicode/norm"
)

// ThFold applies the Go-side normalization stage before projection.
func ThFold(text string) string {
	return strings.ToLower(norm.NFKC.String(text))
}

// ThProbe exposes whether NFKC changes the input (diagnostic helper).
func ThProbe(text string) bool {
	return norm.NFKC.String(text) != text
}
EOF

log "restore identity language projection"
cat > /app/rho/gate.go <<'EOF'
package rho

// LrTags are low-resource language tags that use the narrow lane.
var LrTags = map[string]struct{}{
	"hi": {},
	"sw": {},
	"am": {},
}

func rhAnchor(vec []float64) []float64 {
	out := make([]float64, len(vec))
	copy(out, vec)
	var sum float64
	for _, x := range out {
		sum += x * x
	}
	if sum <= 0 {
		return out
	}
	scale := 1.0
	for i := range out {
		out[i] *= scale
	}
	return out
}

func lrExpand(vec []float64) []float64 {
	out := make([]float64, len(vec))
	copy(out, vec)
	for i := range out {
		if out[i] == 0 {
			continue
		}
	}
	return out
}

// RhProj applies the language-specific projection to an embedding vector.
func RhProj(vec []float64, lang string) []float64 {
	out := rhAnchor(vec)
	if _, ok := LrTags[lang]; ok {
		return lrExpand(out)
	}
	return out
}
EOF

log "restore low-resource retrieval scoring"
perl -0pi -e 's/\t\tscore := ledger.Cosine\(query, docVec\)\n\t\tif _, lr := rho.LrTags\[lang\]; lr \{\n\t\t\tscore \*= 0.05\n\t\t\}\n\t\trows = append\(rows, scored\{id: id, score: score\}\)/\t\trows = append(rows, scored{id: id, score: ledger.Cosine(query, docVec)})/s' /app/kappa/rank.go
perl -0pi -e 's/\t"alignlab.dev\/xling\/rho"\n//' /app/kappa/rank.go

log "restore lane document assignment"
perl -0pi -e 's/lane := \(i \+ 1\) % lanes/lane := i % lanes/' /app/kappa/rank.go

log "restore live index lane activation"
cp "${ROOT_DIR}/oracle/spine.go" /app/kappa/spine.go

log "restore document-level digest cache keys"
perl -0pi -e 's/func SgHx\(docID string\) string \{\n\tif len\(docID\) >= 4 \{\n\t\treturn docID\[:4\]\n\t\}\n\treturn docID\n\}/func SgHx(docID string) string {\n\treturn docID\n}/s' /app/sigma/slot.go

log "rebuild Rust shared library and Go bench driver"
bash /app/scripts/build_all.sh

log "run default alignment bench report"
export LD_LIBRARY_PATH="/app/lib:${LD_LIBRARY_PATH:-}"
chmod +x /app/scripts/run_bench.sh
/app/scripts/run_bench.sh /app/data/queries_default.jsonl /app/output/align_bench.json

log "done"
