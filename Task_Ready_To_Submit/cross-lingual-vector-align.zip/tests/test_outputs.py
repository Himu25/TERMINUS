"""Validate /app/output/align_bench.json against align.toml guardrails."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "align_bench.json"
CFG = APP / "config" / "align.toml"
MANIFEST = APP / "registry" / "align_manifest.json"
QUERIES = APP / "data" / "queries_default.jsonl"
FIXTURES = Path(__file__).resolve().parent / "fixtures"

REPORT_KEYS = frozenset(
    {
        "status",
        "corpus_docs",
        "embed_dim",
        "align_profile",
        "queries_total",
        "mean_en_recall_at_10",
        "mean_lr_recall_at_10",
        "align_parity_rate",
        "norm_parity_rate",
        "collapse_rate",
        "mean_frag_rate",
        "en_lr_recall_gap",
        "report_digest",
        "queries",
        "packs",
    }
)
QUERY_KEYS = frozenset(
    {
        "query_id",
        "lang",
        "recall_at_10",
        "ndcg_at_10",
        "gold_hits",
        "vec_norm",
        "frag_score",
        "norm_match",
        "top_doc_ids",
    }
)
PACK_KEYS = frozenset(
    {"pack_id", "mean_recall", "mean_ndcg", "collapse_rate", "frag_rate", "lanes_active"}
)

_SUBPROC_ENV = os.environ.copy()
_SUBPROC_ENV["PATH"] = "/usr/local/go/bin:/app/bin:" + _SUBPROC_ENV.get("PATH", "")
_SUBPROC_ENV["LD_LIBRARY_PATH"] = "/app/lib:" + _SUBPROC_ENV.get("LD_LIBRARY_PATH", "")
_BUILD_TIMEOUT = 300
_RUN_TIMEOUT = 120

# Shipped align.toml defaults; enforced in tests so lowering align.toml cannot pass.
ENFORCED_FLOORS: dict[str, float | int] = {
    "embed_dim": 128,
    "en_recall_floor": 0.85,
    "lr_recall_floor": 0.80,
    "align_parity_floor": 0.75,
    "norm_parity_floor": 0.95,
    "failover_recall_floor": 0.70,
    "unicode_recall_floor": 0.80,
}
ENFORCED_CEILINGS: dict[str, float] = {
    "max_collapse_rate": 0.05,
    "max_frag_rate": 0.10,
    "max_en_lr_gap": 0.15,
}


def _effective_floor(cfg: dict, key: str) -> float | int:
    """Max of align.toml value and shipped minimum (anti-tamper)."""
    return max(cfg[key], ENFORCED_FLOORS[key])


def _effective_ceiling(cfg: dict, key: str) -> float:
    """Min of align.toml value and shipped maximum (anti-tamper)."""
    return min(cfg[key], ENFORCED_CEILINGS[key])


def _parse_cfg() -> dict:
    cfg: dict = {
        "embed_dim": 128,
        "align_profile": "v3",
        "en_recall_floor": 0.85,
        "lr_recall_floor": 0.80,
        "align_parity_floor": 0.75,
        "norm_parity_floor": 0.95,
        "max_collapse_rate": 0.05,
        "max_frag_rate": 0.10,
        "max_en_lr_gap": 0.15,
        "failover_recall_floor": 0.70,
        "unicode_recall_floor": 0.80,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key == "embed_dim":
            cfg[key] = int(float(val))
        elif key == "align_profile":
            cfg[key] = val
        elif key.endswith("_floor") or key.startswith("max_"):
            cfg[key] = float(val)
    return cfg


def _digest_payload(report: dict) -> dict:
    return {
        "status": report["status"],
        "corpus_docs": report["corpus_docs"],
        "embed_dim": report["embed_dim"],
        "align_profile": report["align_profile"],
        "queries_total": report["queries_total"],
        "mean_en_recall_at_10": report["mean_en_recall_at_10"],
        "mean_lr_recall_at_10": report["mean_lr_recall_at_10"],
        "align_parity_rate": report["align_parity_rate"],
        "norm_parity_rate": report["norm_parity_rate"],
        "collapse_rate": report["collapse_rate"],
        "mean_frag_rate": report["mean_frag_rate"],
        "en_lr_recall_gap": report["en_lr_recall_gap"],
        "report_digest": "",
        "queries": report["queries"],
        "packs": report["packs"],
    }


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _rebuild_and_run(out_path: Path | None = None, *, force_rust: bool = False) -> dict:
    out_path = out_path or OUT
    out_path.unlink(missing_ok=True)
    if force_rust:
        libz = APP / "lib" / "libzeta_core.so"
        if libz.is_file():
            libz.unlink()
        subprocess.run(
            ["cargo", "clean", "--release"],
            cwd=APP / "zeta_core",
            check=True,
            timeout=_BUILD_TIMEOUT,
            env=_SUBPROC_ENV,
        )
    subprocess.run(
        ["bash", "/app/scripts/build_all.sh"],
        cwd=APP,
        check=True,
        timeout=_BUILD_TIMEOUT,
        env=_SUBPROC_ENV,
    )
    subprocess.run(
        [
            "/app/scripts/run_bench.sh",
            QUERIES.as_posix(),
            out_path.as_posix(),
        ],
        cwd=APP,
        check=True,
        timeout=_RUN_TIMEOUT,
        env=_SUBPROC_ENV,
    )
    return json.loads(out_path.read_text(encoding="utf-8"))


def _query_rows(report: dict) -> dict[str, dict]:
    return {row["query_id"]: row for row in report["queries"]}


def _pack_rows(report: dict) -> dict[str, dict]:
    return {row["pack_id"]: row for row in report["packs"]}


@pytest.fixture(scope="module")
def cfg() -> dict:
    return _parse_cfg()


@pytest.fixture(scope="module")
def default_report() -> dict:
    if not OUT.is_file():
        pytest.fail(f"missing agent output at {OUT}")
    return json.loads(OUT.read_text(encoding="utf-8"))


def test_report_schema_and_digest(default_report: dict) -> None:
    """Top-level schema and report_digest must match compact pre-digest JSON."""
    assert set(default_report.keys()) == REPORT_KEYS
    assert re.fullmatch(r"[0-9a-f]{64}", default_report["report_digest"])
    assert default_report["report_digest"] == _expected_digest(default_report)
    for row in default_report["queries"]:
        assert set(row.keys()) == QUERY_KEYS
    for row in default_report["packs"]:
        assert set(row.keys()) == PACK_KEYS


def test_align_guardrails_not_neutered(cfg: dict) -> None:
    """align.toml quality floors remain at shipped thresholds."""
    for key, minimum in ENFORCED_FLOORS.items():
        if key in cfg:
            assert cfg[key] >= minimum, f"{key} lowered below shipped floor"
    for key, maximum in ENFORCED_CEILINGS.items():
        if key in cfg:
            assert cfg[key] <= maximum, f"{key} raised above shipped ceiling"


def test_default_quality_floors(default_report: dict, cfg: dict) -> None:
    """Default query pack must meet align.toml recall, parity, and collapse ceilings."""
    assert default_report["status"] == "ok"
    assert default_report["mean_en_recall_at_10"] >= _effective_floor(cfg, "en_recall_floor")
    assert default_report["mean_lr_recall_at_10"] >= _effective_floor(cfg, "lr_recall_floor")
    assert default_report["align_parity_rate"] >= _effective_floor(cfg, "align_parity_floor")
    assert default_report["norm_parity_rate"] >= _effective_floor(cfg, "norm_parity_floor")
    assert default_report["collapse_rate"] <= _effective_ceiling(cfg, "max_collapse_rate")
    assert default_report["mean_frag_rate"] <= _effective_ceiling(cfg, "max_frag_rate")
    assert default_report["en_lr_recall_gap"] <= _effective_ceiling(cfg, "max_en_lr_gap")


def test_english_queries_recall(default_report: dict, cfg: dict) -> None:
    """English rows must individually meet the English recall floor."""
    rows = _query_rows(default_report)
    for qid, row in rows.items():
        if row["lang"] != "en":
            continue
        assert row["recall_at_10"] >= _effective_floor(cfg, "en_recall_floor"), qid


def test_low_resource_recall(default_report: dict, cfg: dict) -> None:
    """hi, sw, and am query rows must meet the low-resource recall floor."""
    rows = _query_rows(default_report)
    for qid, row in rows.items():
        if row["lang"] not in {"hi", "sw", "am"}:
            continue
        assert row["recall_at_10"] >= _effective_floor(cfg, "lr_recall_floor"), qid


def test_alignment_pair_parity(default_report: dict, cfg: dict) -> None:
    """Paired refund queries must meet the align_parity_rate floor in the report."""
    floor = _effective_floor(cfg, "align_parity_floor")
    assert default_report["align_parity_rate"] >= floor
    rows = _query_rows(default_report)
    for qid in ("q_en_refund", "q_hi_refund"):
        assert rows[qid]["recall_at_10"] >= floor


def test_unicode_pack_row(default_report: dict, cfg: dict) -> None:
    """pack_unicode_mix must clear the unicode recall floor."""
    pack = _pack_rows(default_report)["pack_unicode_mix"]
    assert pack["mean_recall"] >= _effective_floor(cfg, "unicode_recall_floor")


def test_failover_pack_lanes(default_report: dict, cfg: dict) -> None:
    """Failover pack keeps recall above failover floor with reduced lanes_active."""
    pack = _pack_rows(default_report)["pack_failover_lane"]
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    assert pack["lanes_active"] == manifest["index_lanes"] - 1
    assert pack["mean_recall"] >= _effective_floor(cfg, "failover_recall_floor")


def test_align_profile_matches_manifest(default_report: dict) -> None:
    """align_profile and embed_dim must match registry align_manifest.json."""
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    assert default_report["align_profile"] == manifest["align_profile"]
    assert default_report["embed_dim"] == manifest["embed_dim"]


def test_determinism_repeat_run(default_report: dict) -> None:
    """Identical inputs must yield byte-identical align_bench.json."""
    first = OUT.read_bytes()
    OUT.unlink(missing_ok=True)
    subprocess.run(
        [
            "/app/scripts/run_bench.sh",
            QUERIES.as_posix(),
            OUT.as_posix(),
        ],
        cwd=APP,
        check=True,
        timeout=_RUN_TIMEOUT,
        env=_SUBPROC_ENV,
    )
    assert first == OUT.read_bytes()


def test_z_ablation_zeta_fails_norm_parity() -> None:
    """Broken Rust tokenizer must drop norm_parity_rate below the floor."""
    shutil.copy2(FIXTURES / "z_zeta_core.rs", APP / "zeta_core" / "src" / "lib.rs")
    report = _rebuild_and_run(
        out_path=APP / "output" / "align_ablation_zeta.json",
        force_rust=True,
    )
    cfg = _parse_cfg()
    assert report["norm_parity_rate"] < _effective_floor(cfg, "norm_parity_floor")


def test_z_ablation_project_fails_lr_recall() -> None:
    """Collapsed low-resource projection must spike collapse_rate above ceiling."""
    shutil.copy2(FIXTURES / "z_gate.go", APP / "rho" / "gate.go")
    report = _rebuild_and_run(out_path=APP / "output" / "align_ablation_project.json")
    cfg = _parse_cfg()
    assert report["collapse_rate"] > _effective_ceiling(cfg, "max_collapse_rate")


def test_z_ablation_lane_prefix_fails_en_cache() -> None:
    """Prefix-only digest cache keys must break recall on the cache probe query."""
    shutil.copy2(FIXTURES / "z_lane.go", APP / "sigma" / "slot.go")
    report = _rebuild_and_run(out_path=APP / "output" / "align_ablation_lane.json")
    row = _query_rows(report)["q_en_cache"]
    assert row["recall_at_10"] < 1.0


def test_z_ablation_lanes_serial_fails_failover() -> None:
    """Single-lane activation must leave failover pack below English recall floor."""
    shutil.copy2(FIXTURES / "z_lanes.go", APP / "kappa" / "spine.go")
    report = _rebuild_and_run(out_path=APP / "output" / "align_ablation_lanes.json")
    cfg = _parse_cfg()
    pack = _pack_rows(report)["pack_failover_lane"]
    assert pack["lanes_active"] == 1
    assert pack["mean_recall"] < _effective_floor(cfg, "en_recall_floor")
