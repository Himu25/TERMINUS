package rho

import "math"

var LrTags = map[string]struct{}{
	"hi": {},
	"sw": {},
	"am": {},
}

func RhProj(vec []float64, lang string) []float64 {
	out := make([]float64, len(vec))
	copy(out, vec)
	if _, ok := LrTags[lang]; !ok {
		return out
	}
	var energy float64
	for i := range out {
		energy += out[i] * out[i]
	}
	if energy <= 0 {
		return out
	}
	w := 1.0 / math.Sqrt(float64(len(out)))
	for i := range out {
		out[i] *= w
	}
	return out
}
