package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"

	"alignlab.dev/xling/bench"
	"alignlab.dev/xling/corpus"
	"alignlab.dev/xling/pkg/types"
)

func main() {
	if len(os.Args) < 4 {
		fmt.Fprintln(os.Stderr, "usage: refgen <corpus.json> <query_specs.jsonl> <out.jsonl>")
		os.Exit(2)
	}
	cfg, err := bench.LoadCfg("/app/config/align.toml")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	docs, err := corpus.Load(os.Args[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	specs, err := bench.LoadQueries(os.Args[2])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	out, err := os.Create(os.Args[3])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer out.Close()
	w := bufio.NewWriter(out)
	for _, spec := range specs {
		gold := bench.GoldFromRanked(docs, spec, cfg.EmbedDim)
		row := types.QuerySpec{
			QueryID:    spec.QueryID,
			Lang:       spec.Lang,
			Text:       spec.Text,
			GoldDocIDs: gold,
			PairQuery:  spec.PairQuery,
		}
		raw, err := json.Marshal(row)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		if _, err := w.Write(raw); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		if err := w.WriteByte('\n'); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	}
	if err := w.Flush(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
