#!/bin/bash
set -euo pipefail

if [[ $# -lt 2 ]]; then
  echo "usage: run_bench.sh <queries.jsonl> <out.json>" >&2
  exit 2
fi

export LD_LIBRARY_PATH="/app/lib:${LD_LIBRARY_PATH:-}"
exec /app/bin/alignbench /app/data/pack_specs.jsonl "$1" "$2"
