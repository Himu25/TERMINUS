#!/bin/bash
set -euo pipefail

ROOT="/app"
mkdir -p "${ROOT}/bin" "${ROOT}/lib" "${ROOT}/output" "${ROOT}/output/cargo-target"

export CARGO_TARGET_DIR="${ROOT}/output/cargo-target"
export CARGO_HOME="${CARGO_HOME:-/usr/local/cargo}"
export CGO_LDFLAGS="-L${ROOT}/lib -lzeta_core"
export LD_LIBRARY_PATH="${ROOT}/lib:${LD_LIBRARY_PATH:-}"

rm -f "${ROOT}/lib/libzeta_core.so"
cd "${ROOT}/zeta_core"
cargo build --release --locked
install -m 0644 "${CARGO_TARGET_DIR}/release/libzeta_core.so" "${ROOT}/lib/libzeta_core.so"

cd "${ROOT}"
go build -o "${ROOT}/bin/alignbench" ./cmd/alignbench
go build -o "${ROOT}/bin/refgen" ./cmd/refgen

export LD_LIBRARY_PATH="${ROOT}/lib:${LD_LIBRARY_PATH:-}"

"${ROOT}/bin/refgen" \
  "${ROOT}/data/corpus_default.json" \
  "${ROOT}/data/query_specs.jsonl" \
  "${ROOT}/data/queries_default.jsonl"
