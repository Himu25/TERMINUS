# Multilingual retrieval alignment service

The stack couples a Rust tokenizer (`zeta_core`), Go normalization and projection stages (`theta`, `rho`), and a retrieval scanner (`kappa`) behind `/app/bin/alignbench`. English packs should retain strong recall while low-resource language packs depend on consistent normalization and full-width embeddings.
