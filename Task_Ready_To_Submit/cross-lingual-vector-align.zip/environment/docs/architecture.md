# Architecture notes

Corpus JSON lives at `/app/data/corpus_default.json`. Query packs are defined in `/app/data/pack_specs.jsonl`; graded queries ship in `/app/data/queries_default.jsonl` with gold_doc_ids. The Go driver `/app/bin/alignbench` loads `/app/config/align.toml`, indexes corpus rows through the Rust helper in `/app/zeta_core`, and writes `/app/output/align_bench.json`. Rebuild with `/app/scripts/build_all.sh` and run `/app/scripts/run_bench.sh`.

Top-level report keys: status, corpus_docs, embed_dim, align_profile, queries_total, mean_en_recall_at_10, mean_lr_recall_at_10, align_parity_rate, norm_parity_rate, collapse_rate, mean_frag_rate, en_lr_recall_gap, report_digest, queries, packs.

Each queries row: query_id, lang, recall_at_10, ndcg_at_10, gold_hits, vec_norm, frag_score, norm_match, top_doc_ids. recall_at_10 and ndcg_at_10 are computed against gold_doc_ids for that query. frag_score rises when the Rust tokenizer over-splits text relative to the canonical fold in `ledger/digest.go`. norm_match is true when the runtime tokenizer digest equals the canonical fold. vec_norm is the L2 norm of the projected query embedding.

Each packs row: pack_id, mean_recall, mean_ndcg, collapse_rate, frag_rate, lanes_active. collapse_rate is the fraction of queries in that pack whose projected query vector norm falls below the internal collapse cutoff. lanes_active counts live index lanes after dead_lanes are applied.

Digest covers every report field except report_digest, serialized as compact JSON with report_digest set to an empty string. alignbench computes the digest from that payload before writing the indented report file.

align_parity_rate is the fraction of paired queries (pair_query links) where both rows reach recall_at_10 at or above align_parity_floor. mean_en_recall_at_10 averages recall for lang en queries; mean_lr_recall_at_10 averages recall for hi, sw, and am. en_lr_recall_gap is mean_en_recall_at_10 minus mean_lr_recall_at_10.

Quality gates compare report means against floors and ceilings in align.toml. Regenerate `/app/data/queries_default.jsonl` with `/app/bin/refgen` after corpus edits.

Grading prepends `/usr/local/go/bin:/app/bin:` to PATH when invoking alignbench.
