package corpus

import (
	"encoding/json"
	"os"

	"alignlab.dev/xling/pkg/types"
)

// Load reads corpus JSON from disk.
func Load(path string) ([]types.Doc, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var docs []types.Doc
	if err := json.Unmarshal(raw, &docs); err != nil {
		return nil, err
	}
	return docs, nil
}

// ByID indexes documents by id.
func ByID(docs []types.Doc) map[string]types.Doc {
	out := make(map[string]types.Doc, len(docs))
	for _, d := range docs {
		out[d.ID] = d
	}
	return out
}
