package ledger

import (
	"crypto/sha256"
	"encoding/binary"
	"math"
	"strings"

	"golang.org/x/text/unicode/norm"
)

// VecFromText builds a deterministic unit vector from normalized text tokens.
func VecFromText(text string, dim int) []float64 {
	if dim < 1 {
		dim = 1
	}
	normed := strings.ToLower(norm.NFKC.String(text))
	parts := strings.Fields(normed)
	vec := make([]float64, dim)
	if len(parts) == 0 {
		parts = []string{normed}
	}
	for i, part := range parts {
		payload := append([]byte(part), byte(i))
		h := sha256.Sum256(payload)
		idx := binary.LittleEndian.Uint32(h[:4]) % uint32(dim)
		sign := 1.0
		if h[5]&1 == 1 {
			sign = -1.0
		}
		vec[idx] += sign
	}
	return l2Unit(vec)
}

func l2Unit(v []float64) []float64 {
	var sum float64
	for _, x := range v {
		sum += x * x
	}
	if sum <= 0 {
		v[0] = 1.0
		return v
	}
	scale := 1.0 / math.Sqrt(sum)
	for i := range v {
		v[i] *= scale
	}
	return v
}

// VecNorm returns L2 norm.
func VecNorm(v []float64) float64 {
	var sum float64
	for _, x := range v {
		sum += x * x
	}
	return math.Sqrt(sum)
}

// Cosine returns dot product for unit vectors.
func Cosine(a, b []float64) float64 {
	n := len(a)
	if len(b) < n {
		n = len(b)
	}
	var dot float64
	for i := 0; i < n; i++ {
		dot += a[i] * b[i]
	}
	return dot
}
