Helper scripts live under /app/scripts. Do not commit build artifacts.
