package kappa

import (
	"sort"

	"alignlab.dev/xling/ledger"
	"alignlab.dev/xling/pkg/types"
	"alignlab.dev/xling/rho"
)

type scored struct {
	id    string
	score float64
}

// KpTopK ranks corpus docs by similarity to the query vector.
func KpTopK(index map[string][]float64, query []float64, lang string, k int) []string {
	rows := make([]scored, 0, len(index))
	for id, docVec := range index {
		score := ledger.Cosine(query, docVec)
		if _, lr := rho.LrTags[lang]; lr {
			score *= 0.05
		}
		rows = append(rows, scored{id: id, score: score})
	}
	sort.Slice(rows, func(i, j int) bool {
		if rows[i].score == rows[j].score {
			return rows[i].id < rows[j].id
		}
		return rows[i].score > rows[j].score
	})
	if k > len(rows) {
		k = len(rows)
	}
	out := make([]string, k)
	for i := 0; i < k; i++ {
		out[i] = rows[i].id
	}
	return out
}

// KpRecallAt10 measures overlap between ranked ids and gold neighbors.
func KpRecallAt10(ranked, gold []string) float64 {
	if len(gold) == 0 {
		return 0
	}
	limit := 10
	if len(ranked) < limit {
		limit = len(ranked)
	}
	hits := 0
	gset := make(map[string]struct{}, len(gold))
	for _, g := range gold {
		gset[g] = struct{}{}
	}
	for i := 0; i < limit; i++ {
		if _, ok := gset[ranked[i]]; ok {
			hits++
		}
	}
	return float64(hits) / float64(len(gold))
}

// KpNdcgAt10 computes a simple NDCG@10 for binary relevance.
func KpNdcgAt10(ranked, gold []string) float64 {
	if len(gold) == 0 {
		return 0
	}
	gset := make(map[string]struct{}, len(gold))
	for _, g := range gold {
		gset[g] = struct{}{}
	}
	limit := 10
	if len(ranked) < limit {
		limit = len(ranked)
	}
	var dcg float64
	for i := 0; i < limit; i++ {
		if _, ok := gset[ranked[i]]; ok {
			if i == 0 {
				dcg += 1.0
			} else {
				dcg += 1.0 / float64(log2Int(i+1))
			}
		}
	}
	idcg := 0.0
	for i := 0; i < len(gold) && i < 10; i++ {
		if i == 0 {
			idcg += 1.0
		} else {
			idcg += 1.0 / float64(log2Int(i+1))
		}
	}
	if idcg <= 0 {
		return 0
	}
	return dcg / idcg
}

func log2Int(x int) int {
	n := 0
	for (1 << n) < x {
		n++
	}
	if n < 1 {
		return 1
	}
	return n
}

// Collapsed reports whether a vector norm is below the collapse threshold.
func Collapsed(vec []float64, threshold float64) bool {
	return ledger.VecNorm(vec) < threshold
}

// LaneDocs filters documents assigned to live index lanes.
func LaneDocs(docs []types.Doc, lanes int, dead []int) []types.Doc {
	deadSet := make(map[int]struct{}, len(dead))
	for _, d := range dead {
		deadSet[d] = struct{}{}
	}
	out := make([]types.Doc, 0, len(docs))
	for i, doc := range docs {
		lane := (i + 1) % lanes
		if _, off := deadSet[lane]; off {
			continue
		}
		out = append(out, doc)
	}
	return out
}
