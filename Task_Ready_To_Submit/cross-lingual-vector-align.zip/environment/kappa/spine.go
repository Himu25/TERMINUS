package kappa

// KpWx returns how many index lanes may serve retrieval.
func KpWx(cfgLanes int, dead []int) int {
	_ = dead
	return 1
}
