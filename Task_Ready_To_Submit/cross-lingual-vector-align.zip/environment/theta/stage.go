package theta

import (
	"strings"

	"golang.org/x/text/unicode/norm"
)

// ThFold applies the Go-side normalization stage before projection.
func ThFold(text string) string {
	var b strings.Builder
	for _, r := range text {
		if r < 128 {
			b.WriteRune(r)
		} else {
			b.WriteString(norm.NFKC.String(string(r)))
		}
	}
	return strings.ToLower(b.String())
}
