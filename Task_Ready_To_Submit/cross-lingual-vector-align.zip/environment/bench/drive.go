package bench

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"

	"alignlab.dev/xling/corpus"
	"alignlab.dev/xling/kappa"
	"alignlab.dev/xling/ledger"
	"alignlab.dev/xling/pipeline"
	"alignlab.dev/xling/pkg/types"
	"alignlab.dev/xling/rho"
	"alignlab.dev/xling/sigma"
	"alignlab.dev/xling/theta"
)

const topK = 10
const collapseThreshold = 0.35
const indexLanes = 4

func Run(cfg types.AlignCfg, packs []types.PackCase, queries []types.QuerySpec) (types.AlignReport, error) {
	if override := os.Getenv("TB_CORPUS_PATH"); override != "" {
		cfg.CorpusPath = override
	}
	docs, err := corpus.Load(cfg.CorpusPath)
	if err != nil {
		return types.AlignReport{}, err
	}
	qByID := make(map[string]types.QuerySpec, len(queries))
	for _, q := range queries {
		qByID[q.QueryID] = q
	}

	report := types.AlignReport{
		Status:       "ok",
		CorpusDocs:   len(docs),
		EmbedDim:     cfg.EmbedDim,
		AlignProfile: cfg.AlignProfile,
		QueriesTotal: len(queries),
	}

	var enRecall, lrRecall []float64
	var parityHits, parityTotal int
	var normHits, normTotal int
	var collapseHits, collapseTotal int
	var fragSum float64
	var fragCount int

	fullIndex := buildIndex(docs, cfg.EmbedDim)
	queryRows := make([]types.QueryRow, 0, len(queries))
	vecByQuery := make(map[string][]float64)
	for _, q := range queries {
		row := evalQuery(q, fullIndex, cfg.EmbedDim)
		queryRows = append(queryRows, row)
		vecByQuery[q.QueryID] = rowVec(q, cfg.EmbedDim)

		if q.Lang == "en" {
			enRecall = append(enRecall, row.RecallAt10)
		}
		if _, lr := rho.LrTags[q.Lang]; lr {
			lrRecall = append(lrRecall, row.RecallAt10)
		}
		normTotal++
		if row.NormMatch {
			normHits++
		}
		collapseTotal++
		if kappa.Collapsed(vecByQuery[q.QueryID], collapseThreshold) {
			collapseHits++
		}
		fragCount++
		fragSum += row.FragScore
	}

	for _, pack := range packs {
		active := kappa.KpWx(indexLanes, pack.DeadLanes)
		liveDocs := kappa.LaneDocs(docs, indexLanes, pack.DeadLanes)
		index := buildIndex(liveDocs, cfg.EmbedDim)

		var packRecall, packNdcg []float64
		var packCollapse int
		var packFragSum float64

		for _, qid := range pack.QueryIDs {
			q, ok := qByID[qid]
			if !ok {
				return types.AlignReport{}, fmt.Errorf("unknown query_id %s", qid)
			}
			row := evalQuery(q, index, cfg.EmbedDim)
			packRecall = append(packRecall, row.RecallAt10)
			packNdcg = append(packNdcg, row.NdcgAt10)
			if kappa.Collapsed(rowVec(q, cfg.EmbedDim), collapseThreshold) {
				packCollapse++
			}
			packFragSum += row.FragScore
		}

		packRow := types.PackRow{
			PackID:      pack.PackID,
			LanesActive: active,
		}
		nPack := len(pack.QueryIDs)
		if nPack > 0 {
			packRow.MeanRecall = round4(mean(packRecall))
			packRow.MeanNdcg = round4(mean(packNdcg))
			packRow.CollapseRate = round4(float64(packCollapse) / float64(nPack))
			packRow.FragRate = round4(packFragSum / float64(nPack))
		}
		report.Packs = append(report.Packs, packRow)
	}

	queryRowMap := make(map[string]types.QueryRow, len(queryRows))
	for _, row := range queryRows {
		queryRowMap[row.QueryID] = row
	}
	for _, q := range queries {
		if q.PairQuery == "" {
			continue
		}
		other, ok := qByID[q.PairQuery]
		if !ok {
			continue
		}
		rowA, okA := queryRowMap[q.QueryID]
		rowB, okB := queryRowMap[other.QueryID]
		if !okA || !okB {
			continue
		}
		parityTotal++
		if rowA.RecallAt10 >= cfg.AlignParityFloor && rowB.RecallAt10 >= cfg.AlignParityFloor {
			parityHits++
		}
	}

	report.Queries = queryRows
	if len(enRecall) > 0 {
		report.MeanEnRecall = round4(mean(enRecall))
	}
	if len(lrRecall) > 0 {
		report.MeanLrRecall = round4(mean(lrRecall))
	}
	report.EnLrRecallGap = round4(report.MeanEnRecall - report.MeanLrRecall)
	if parityTotal > 0 {
		report.AlignParityRate = round4(float64(parityHits) / float64(parityTotal))
	}
	if normTotal > 0 {
		report.NormParityRate = round4(float64(normHits) / float64(normTotal))
	}
	if collapseTotal > 0 {
		report.CollapseRate = round4(float64(collapseHits) / float64(collapseTotal))
	}
	if fragCount > 0 {
		report.MeanFragRate = round4(fragSum / float64(fragCount))
	}

	if report.MeanEnRecall < cfg.EnRecallFloor ||
		report.MeanLrRecall < cfg.LrRecallFloor ||
		report.AlignParityRate < cfg.AlignParityFloor ||
		report.NormParityRate < cfg.NormParityFloor ||
		report.CollapseRate > cfg.MaxCollapseRate ||
		report.MeanFragRate > cfg.MaxFragRate ||
		report.EnLrRecallGap > cfg.MaxEnLrGap {
		report.Status = "fail"
	}

	sort.Slice(report.Queries, func(i, j int) bool {
		return report.Queries[i].QueryID < report.Queries[j].QueryID
	})
	sort.Slice(report.Packs, func(i, j int) bool {
		return report.Packs[i].PackID < report.Packs[j].PackID
	})
	report.ReportDigest = digestBody(report)
	return report, nil
}

func buildIndex(docs []types.Doc, dim int) map[string][]float64 {
	index := make(map[string][]float64, len(docs))
	for _, doc := range docs {
		vec := embedDoc(doc, dim)
		index[doc.ID] = vec
	}
	return index
}

func embedDoc(doc types.Doc, dim int) []float64 {
	key := sigma.SgHx(doc.ID)
	var foldSrc string
	if cached, ok := sigma.SgRd(key); ok {
		foldSrc = cached.Digest
	} else {
		dg, tok, _, _, err := sigma.SgZc(doc.Text)
		if err != nil {
			dg = ""
		}
		sigma.SgWr(key, dg, tok)
		foldSrc = theta.ThFold(doc.Text)
	}
	vec := ledger.VecFromText(foldSrc, dim)
	return rho.RhProj(vec, doc.Lang)
}

func rowVec(q types.QuerySpec, dim int) []float64 {
	folded := theta.ThFold(q.Text)
	vec := ledger.VecFromText(folded, dim)
	return rho.RhProj(vec, q.Lang)
}

func evalQuery(q types.QuerySpec, index map[string][]float64, dim int) types.QueryRow {
	digest, _, frag, _, _ := pipeline.ZtEncode(q.Text)
	canon := ledger.DgFold(q.Text)
	vec := rowVec(q, dim)
	ranked := kappa.KpTopK(index, vec, q.Lang, topK)
	recall := kappa.KpRecallAt10(ranked, q.GoldDocIDs)
	ndcg := kappa.KpNdcgAt10(ranked, q.GoldDocIDs)
	hits := 0
	gset := make(map[string]struct{}, len(q.GoldDocIDs))
	for _, g := range q.GoldDocIDs {
		gset[g] = struct{}{}
	}
	limit := topK
	if len(ranked) < limit {
		limit = len(ranked)
	}
	for i := 0; i < limit; i++ {
		if _, ok := gset[ranked[i]]; ok {
			hits++
		}
	}
	fragScore := 0.0
	if frag > 0 {
		fragScore = float64(frag) / float64(frag+4)
	}
	return types.QueryRow{
		QueryID:    q.QueryID,
		Lang:       q.Lang,
		RecallAt10: round4(recall),
		NdcgAt10:   round4(ndcg),
		GoldHits:   hits,
		VecNorm:    round4(ledger.VecNorm(vec)),
		FragScore:  round4(fragScore),
		NormMatch:  digest == canon,
		TopDocIDs:  ranked,
	}
}

func mean(vals []float64) float64 {
	if len(vals) == 0 {
		return 0
	}
	var s float64
	for _, v := range vals {
		s += v
	}
	return s / float64(len(vals))
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

type digestPayload struct {
	Status          string            `json:"status"`
	CorpusDocs      int               `json:"corpus_docs"`
	EmbedDim        int               `json:"embed_dim"`
	AlignProfile    string            `json:"align_profile"`
	QueriesTotal    int               `json:"queries_total"`
	MeanEnRecall    float64           `json:"mean_en_recall_at_10"`
	MeanLrRecall    float64           `json:"mean_lr_recall_at_10"`
	AlignParityRate float64           `json:"align_parity_rate"`
	NormParityRate  float64           `json:"norm_parity_rate"`
	CollapseRate    float64           `json:"collapse_rate"`
	MeanFragRate    float64           `json:"mean_frag_rate"`
	EnLrRecallGap   float64           `json:"en_lr_recall_gap"`
	ReportDigest    string            `json:"report_digest"`
	Queries         []types.QueryRow  `json:"queries"`
	Packs           []types.PackRow   `json:"packs"`
}

func digestBody(report types.AlignReport) string {
	payload := digestPayload{
		Status:          report.Status,
		CorpusDocs:      report.CorpusDocs,
		EmbedDim:        report.EmbedDim,
		AlignProfile:    report.AlignProfile,
		QueriesTotal:    report.QueriesTotal,
		MeanEnRecall:    report.MeanEnRecall,
		MeanLrRecall:    report.MeanLrRecall,
		AlignParityRate: report.AlignParityRate,
		NormParityRate:  report.NormParityRate,
		CollapseRate:    report.CollapseRate,
		MeanFragRate:    report.MeanFragRate,
		EnLrRecallGap:   report.EnLrRecallGap,
		ReportDigest:    "",
		Queries:         report.Queries,
		Packs:           report.Packs,
	}
	raw, _ := json.Marshal(payload)
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

// WriteReport writes the JSON report with stable query ordering.
func WriteReport(path string, report types.AlignReport) error {
	out, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	out = append(out, '\n')
	return os.WriteFile(path, out, 0o644)
}

// CanonicalTopK recomputes gold neighbors with the ledger-only path.
func CanonicalTopK(docs []types.Doc, q types.QuerySpec, dim int) []string {
	index := make(map[string][]float64, len(docs))
	for _, doc := range docs {
		index[doc.ID] = ledger.VecFromText(doc.Text, dim)
	}
	qvec := ledger.VecFromText(q.Text, dim)
	type scored struct {
		id    string
		score float64
	}
	rows := make([]scored, 0, len(index))
	for id, vec := range index {
		rows = append(rows, scored{id: id, score: ledger.Cosine(qvec, vec)})
	}
	sort.Slice(rows, func(i, j int) bool {
		if rows[i].score == rows[j].score {
			return rows[i].id < rows[j].id
		}
		return rows[i].score > rows[j].score
	})
	k := topK
	if k > len(rows) {
		k = len(rows)
	}
	out := make([]string, k)
	for i := 0; i < k; i++ {
		out[i] = rows[i].id
	}
	return out
}

// GoldFromRanked builds gold_doc_ids as top matches sharing query language first.
func GoldFromRanked(docs []types.Doc, q types.QuerySpec, dim int) []string {
	ranked := CanonicalTopK(docs, q, dim)
	var sameLang []string
	var other []string
	byID := corpus.ByID(docs)
	for _, id := range ranked {
		if doc, ok := byID[id]; ok && doc.Lang == q.Lang {
			sameLang = append(sameLang, id)
		} else {
			other = append(other, id)
		}
	}
	out := append(sameLang, other...)
	if len(out) > topK {
		out = out[:topK]
	}
	return out
}

// PackQueryIDs returns query ids for a pack id from specs.
func PackQueryIDs(packID string, packs []types.PackCase) []string {
	for _, p := range packs {
		if p.PackID == packID {
			return p.QueryIDs
		}
	}
	return nil
}

// QueryLang returns whether a tag is low-resource.
func QueryLang(lang string) bool {
	_, ok := rho.LrTags[lang]
	return ok
}

// FormatPairKey sorts pair ids for stable parity bookkeeping.
func FormatPairKey(a, b string) string {
	if strings.Compare(a, b) > 0 {
		a, b = b, a
	}
	return a + "|" + b
}
