package bench

import (
	"bufio"
	"encoding/json"
	"os"
	"strconv"
	"strings"

	"alignlab.dev/xling/pkg/types"
)

// LoadCfg reads align.toml into AlignCfg.
func LoadCfg(path string) (types.AlignCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.AlignCfg{}, err
	}
	cfg := types.AlignCfg{
		CorpusPath:          "/app/data/corpus_default.json",
		EmbedDim:            128,
		AlignProfile:        "v3",
		EnRecallFloor:       0.85,
		LrRecallFloor:       0.80,
		AlignParityFloor:    0.75,
		NormParityFloor:     0.95,
		MaxCollapseRate:     0.05,
		MaxFragRate:         0.10,
		MaxEnLrGap:          0.15,
		FailoverRecallFloor: 0.70,
		UnicodeRecallFloor:  0.80,
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") || !strings.Contains(line, "=") {
			continue
		}
		parts := strings.SplitN(line, "=", 2)
		key := strings.TrimSpace(parts[0])
		val := strings.TrimSpace(parts[1])
		switch key {
		case "corpus_path":
			cfg.CorpusPath = val
		case "embed_dim":
			cfg.EmbedDim, _ = strconv.Atoi(val)
		case "align_profile":
			cfg.AlignProfile = val
		case "en_recall_floor", "lr_recall_floor", "align_parity_floor", "norm_parity_floor",
			"max_collapse_rate", "max_frag_rate", "max_en_lr_gap", "failover_recall_floor", "unicode_recall_floor":
			if f, err := strconv.ParseFloat(val, 64); err == nil {
				switch key {
				case "en_recall_floor":
					cfg.EnRecallFloor = f
				case "lr_recall_floor":
					cfg.LrRecallFloor = f
				case "align_parity_floor":
					cfg.AlignParityFloor = f
				case "norm_parity_floor":
					cfg.NormParityFloor = f
				case "max_collapse_rate":
					cfg.MaxCollapseRate = f
				case "max_frag_rate":
					cfg.MaxFragRate = f
				case "max_en_lr_gap":
					cfg.MaxEnLrGap = f
				case "failover_recall_floor":
					cfg.FailoverRecallFloor = f
				case "unicode_recall_floor":
					cfg.UnicodeRecallFloor = f
				}
			}
		}
	}
	return cfg, nil
}

// LoadQueries reads JSONL query rows.
func LoadQueries(path string) ([]types.QuerySpec, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	var out []types.QuerySpec
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var row types.QuerySpec
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return nil, err
		}
		out = append(out, row)
	}
	return out, sc.Err()
}

// LoadPacks reads JSONL pack definitions.
func LoadPacks(path string) ([]types.PackCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	var out []types.PackCase
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var row types.PackCase
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return nil, err
		}
		out = append(out, row)
	}
	return out, sc.Err()
}
