package types

type AlignCfg struct {
	CorpusPath           string
	EmbedDim             int
	AlignProfile         string
	EnRecallFloor        float64
	LrRecallFloor        float64
	AlignParityFloor     float64
	NormParityFloor      float64
	MaxCollapseRate      float64
	MaxFragRate          float64
	MaxEnLrGap           float64
	FailoverRecallFloor  float64
	UnicodeRecallFloor   float64
}

type Doc struct {
	ID   string `json:"id"`
	Text string `json:"text"`
	Lang string `json:"lang"`
}

type QuerySpec struct {
	QueryID    string   `json:"query_id"`
	Lang       string   `json:"lang"`
	Text       string   `json:"text"`
	GoldDocIDs []string `json:"gold_doc_ids"`
	PairQuery  string   `json:"pair_query,omitempty"`
}

type PackCase struct {
	PackID  string   `json:"pack_id"`
	QueryIDs []string `json:"query_ids"`
	DeadLanes []int   `json:"dead_lanes,omitempty"`
}

type QueryRow struct {
	QueryID    string   `json:"query_id"`
	Lang       string   `json:"lang"`
	RecallAt10 float64  `json:"recall_at_10"`
	NdcgAt10   float64  `json:"ndcg_at_10"`
	GoldHits   int      `json:"gold_hits"`
	VecNorm    float64  `json:"vec_norm"`
	FragScore  float64  `json:"frag_score"`
	NormMatch  bool     `json:"norm_match"`
	TopDocIDs  []string `json:"top_doc_ids"`
}

type PackRow struct {
	PackID       string  `json:"pack_id"`
	MeanRecall   float64 `json:"mean_recall"`
	MeanNdcg     float64 `json:"mean_ndcg"`
	CollapseRate float64 `json:"collapse_rate"`
	FragRate     float64 `json:"frag_rate"`
	LanesActive  int     `json:"lanes_active"`
}

type AlignReport struct {
	Status           string     `json:"status"`
	CorpusDocs       int        `json:"corpus_docs"`
	EmbedDim         int        `json:"embed_dim"`
	AlignProfile     string     `json:"align_profile"`
	QueriesTotal     int        `json:"queries_total"`
	MeanEnRecall     float64    `json:"mean_en_recall_at_10"`
	MeanLrRecall     float64    `json:"mean_lr_recall_at_10"`
	AlignParityRate  float64    `json:"align_parity_rate"`
	NormParityRate   float64    `json:"norm_parity_rate"`
	CollapseRate     float64    `json:"collapse_rate"`
	MeanFragRate     float64    `json:"mean_frag_rate"`
	EnLrRecallGap    float64    `json:"en_lr_recall_gap"`
	ReportDigest     string     `json:"report_digest"`
	Queries          []QueryRow `json:"queries"`
	Packs            []PackRow  `json:"packs"`
}
