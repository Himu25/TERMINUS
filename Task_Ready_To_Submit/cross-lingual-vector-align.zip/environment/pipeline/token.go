package pipeline

/*
#cgo LDFLAGS: -L${SRCDIR}/../lib -lzeta_core
#include <stdlib.h>
#include <stdint.h>
char *ztEnc(const char *text, uint32_t *out_count, uint32_t *out_frag, uint32_t *out_alloc);
void ztFree(char *ptr);
*/
import "C"
import (
	"fmt"
	"unsafe"
)

// ZtEncode tokenizes text through the Rust helper.
func ZtEncode(text string) (digest string, tokens uint32, frag uint32, alloc int, err error) {
	cstr := C.CString(text)
	defer C.free(unsafe.Pointer(cstr))
	var count C.uint32_t
	var fragU C.uint32_t
	var allocU C.uint32_t
	ptr := C.ztEnc(cstr, &count, &fragU, &allocU)
	if ptr == nil {
		return "", 0, 0, 0, fmt.Errorf("ztEnc failed")
	}
	defer C.ztFree(ptr)
	return C.GoString(ptr), uint32(count), uint32(fragU), int(allocU), nil
}

// HasUnicodeRunes reports whether text contains non-ASCII runes.
func HasUnicodeRunes(text string) bool {
	for _, r := range text {
		if r > 127 {
			return true
		}
	}
	return false
}
