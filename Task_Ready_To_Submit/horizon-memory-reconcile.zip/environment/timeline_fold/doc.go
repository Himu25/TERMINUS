// Package timeline_fold orders inbound correction events for merge.
package timeline_fold
