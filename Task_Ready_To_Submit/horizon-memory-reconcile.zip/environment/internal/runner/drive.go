package runner

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"

	"membench/eventwire"
)

// PackRun is one scenario row in the manifest JSON.
type PackRun struct {
	ScenarioTag     string `json:"scenario_tag"`
	DurableWrites   int    `json:"durable_writes"`
	SummaryMerged   int    `json:"summary_merged"`
	StaleBlocked    int    `json:"stale_blocked"`
	CheckpointClean int    `json:"checkpoint_clean"`
	ContextDrift    int    `json:"context_drift"`
	ReplayCollapsed int    `json:"replay_collapsed"`
	CycleBlocked    int    `json:"cycle_blocked"`
}

type packPayload struct {
	ScenarioRuns []PackRun `json:"scenario_runs"`
}

// Run loads one pack via tb_mem_pack and writes /app/output/memory_manifest.json.
func Run() error {
	stem := os.Getenv("tb_mem_pack")
	if stem == "" {
		return errors.New("tb_mem_pack must name a stem under /app/cases")
	}
	emit := "/app/output/memory_manifest.json"
	raw, err := os.ReadFile(filepath.Join("/app", "cases", stem+".json"))
	if err != nil {
		return err
	}
	var bundle eventwire.Bundle
	if err := json.Unmarshal(raw, &bundle); err != nil {
		return err
	}
	trimmed, dup := runClip(bundle.Stream)
	filtered := runGate(trimmed)
	ordered := runOrder(filtered)
	linked, cycleBlocked := runLink(ordered)
	swept := runSweep(linked, bundle.Snapshots)
	view := runSeal(swept, bundle.Canonical, bundle.Snapshots)
	run := PackRun{
		ScenarioTag:     bundle.ScenarioLabel,
		DurableWrites:   view.DurableWrites,
		SummaryMerged:   view.SummaryMerged,
		StaleBlocked:    view.StaleBlocked,
		CheckpointClean: view.CheckpointClean,
		ContextDrift:    view.ContextDrift,
		ReplayCollapsed: dup,
		CycleBlocked:    cycleBlocked,
	}
	out := packPayload{ScenarioRuns: []PackRun{run}}
	if err := os.MkdirAll(filepath.Dir(emit), 0o755); err != nil {
		return err
	}
	buf, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		return err
	}
	tmp := emit + ".tmp"
	if err := os.WriteFile(tmp, buf, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, emit)
}

// MainExit is the cmd entry wrapper.
func MainExit() int {
	if err := Run(); err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		return 1
	}
	return 0
}
