package runner

import (
	"membench/eventwire"
	"membench/dedupe_lane"
)

func runClip(rows []eventwire.StreamRow) ([]eventwire.StreamRow, int) {
	return dedupe_lane.ClipSpan(rows)
}
