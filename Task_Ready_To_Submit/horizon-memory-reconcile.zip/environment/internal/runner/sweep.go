package runner

import (
	"membench/eventwire"
	"membench/checkpoint_trim"
)

func runSweep(rows []eventwire.StreamRow, snaps map[string]map[string]eventwire.SnapCell) []eventwire.StreamRow {
	return checkpoint_trim.SweepSpan(rows, snaps)
}
