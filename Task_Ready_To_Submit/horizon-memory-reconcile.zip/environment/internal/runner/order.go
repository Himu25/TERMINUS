package runner

import (
	"membench/eventwire"
	"membench/timeline_fold"
)

func runOrder(rows []eventwire.StreamRow) []eventwire.StreamRow {
	return timeline_fold.OrderSpan(rows)
}
