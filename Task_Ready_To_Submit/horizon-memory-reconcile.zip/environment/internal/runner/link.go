package runner

import (
	"membench/eventwire"
	"membench/link_ref"
)

func runLink(rows []eventwire.StreamRow) ([]eventwire.StreamRow, int) {
	return link_ref.SpinSpan(rows)
}
