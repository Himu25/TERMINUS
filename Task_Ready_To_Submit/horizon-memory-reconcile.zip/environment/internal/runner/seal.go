package runner

import (
	"membench/eventwire"
	"membench/memory_meter"
)

func runSeal(rows []eventwire.StreamRow, canonical map[string]string, snaps map[string]map[string]eventwire.SnapCell) memory_meter.Manifest {
	return memory_meter.MeterSpan(rows, canonical, snaps)
}
