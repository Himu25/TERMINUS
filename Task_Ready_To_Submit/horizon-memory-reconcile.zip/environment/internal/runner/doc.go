// Package runner drives one scenario pack through the memory reconcile pipeline.
package runner
