package runner

import (
	"membench/eventwire"
	"membench/fence_gate"
)

func runGate(rows []eventwire.StreamRow) []eventwire.StreamRow {
	return fence_gate.FilterSpan(rows)
}
