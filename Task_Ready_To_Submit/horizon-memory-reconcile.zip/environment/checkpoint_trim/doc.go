// Package checkpoint_trim prepares checkpoint rows for the meter pass.
package checkpoint_trim
