Offline tools ship outside the container image.
