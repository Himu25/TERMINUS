Station workers connect through the eventwire bundle format.
