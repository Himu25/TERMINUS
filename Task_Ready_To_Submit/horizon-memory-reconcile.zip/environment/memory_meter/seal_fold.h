#pragma once

#include <stdbool.h>
#include <stddef.h>

typedef struct lf_row {
  const char *slot_id;
  int epoch;
  const char *lane;
  const char *mark;
  int seq_no;
  bool sentinel;
} lf_row;

typedef struct lf_roll {
  int durable_writes;
  int summary_merged;
  int stale_blocked;
  int checkpoint_clean;
  int context_drift;
} lf_roll;

struct lf_roll lf_meter_span(const struct lf_row *rows, size_t count,
                             const char *canon_blob, const char *snap_blob);
