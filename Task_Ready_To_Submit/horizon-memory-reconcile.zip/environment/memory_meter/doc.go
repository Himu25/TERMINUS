// Package memory_meter binds the Rust memory fold static library.
package memory_meter
