# Pipeline layout

Memory packs flow through replay dedupe, timeline ordering, per-slot memory fences, link-cycle filtering, checkpoint trimming, and the Rust meter pass. Each stage mutates the in-memory stream before manifest emission.
