# Manifest contract

Each `/app/bin/memreconcile` invocation writes one manifest with `scenario_runs` holding exactly 1 row.

- `scenario_tag` — pack label from the case bundle.
- `durable_writes` — memory slots with a committed WRITE summary after merge.
- `summary_merged` — contradictory WRITE summaries on the same epoch where the higher sequence wins.
- `stale_blocked` — WRITE rows rejected because sequence does not advance the head, including below a checkpoint restore head.
- `checkpoint_clean` — `1` when checkpoint restore leaves no epoch head above the restored snapshot, else `0`.
- `context_drift` — slots whose final summary differs from the pack canonical table.
- WRITE rows apply in non-decreasing `seq_no` order; `recv_ms` is ingest telemetry and must not reorder merge precedence.
- `replay_collapsed` — duplicate deliveries removed before ordering.
- `cycle_blocked` — LINK parent edges rejected because they would close a cyclic reference chain.
- `MEMORY_FENCE` halts later WRITE rows for the same `slot_id` only; sibling slots keep merging.
