// Package link_ref validates parent pointers between memory slots before merge.
package link_ref
