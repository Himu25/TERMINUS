package main

import (
	"os"

	"membench/internal/runner"
)

func main() {
	os.Exit(runner.MainExit())
}
