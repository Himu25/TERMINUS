Hull package reserved for future shard routing.
