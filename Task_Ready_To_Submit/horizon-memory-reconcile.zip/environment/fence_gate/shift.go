package fence_gate

import "membench/eventwire"

// FilterSpan applies MEMORY_FENCE rows before WRITE summaries merge.
func FilterSpan(rows []eventwire.StreamRow) []eventwire.StreamRow {
	out := make([]eventwire.StreamRow, 0, len(rows))
	frozen := false
	for idx := range rows {
		r := rows[idx]
		if r.Lane == "MEMORY_FENCE" && r.Sentinel {
			frozen = true
			out = append(out, r)
			continue
		}
		if frozen && r.Lane == "WRITE" {
			continue
		}
		out = append(out, r)
	}
	return out
}
