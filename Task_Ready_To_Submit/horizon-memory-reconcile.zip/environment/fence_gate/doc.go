// Package fence_gate applies reviewer hold rows before human merge.
package fence_gate
