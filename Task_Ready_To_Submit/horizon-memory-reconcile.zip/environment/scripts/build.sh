#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1
export GOCACHE="${GOCACHE:-/app/output/go-build}"

mkdir -p /app/bin "${GOCACHE}"
cd /app/memory_meter
cargo build --release --locked
cd /app
GOFLAGS=-mod=mod go build -trimpath -buildvcs=false -o /app/bin/memreconcile ./cmd/memreconcile
