module membench

go 1.22
