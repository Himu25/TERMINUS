package eventwire

// StreamRow is one memory event in arrival order.
type StreamRow struct {
	SlotID    string `json:"slot_id"`
	Epoch     int    `json:"epoch"`
	Lane      string `json:"lane"`
	Summary   string `json:"summary"`
	SeqNo     int    `json:"seq_no"`
	RecvMS    int    `json:"recv_ms"`
	Sentinel  bool   `json:"sentinel"`
	ParentRef string `json:"parent_ref,omitempty"`
}

// SnapCell is a frozen epoch snapshot for checkpoint restore.
type SnapCell struct {
	Epoch   int    `json:"epoch"`
	Summary string `json:"summary"`
	SeqNo   int    `json:"seq_no"`
}

// Bundle is one scenario pack under /app/cases.
type Bundle struct {
	ScenarioLabel string                         `json:"scenario_label"`
	Stream        []StreamRow                    `json:"stream"`
	Snapshots     map[string]map[string]SnapCell `json:"snapshots,omitempty"`
	Canonical     map[string]string              `json:"canonical"`
}
