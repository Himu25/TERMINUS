# Memory reconcile worker

Mixed Go and Rust pipeline that replays long-horizon agent memory packs from `/app/cases` and emits reconcile manifests under `/app/output`.
