"""Verifier for long-horizon agent memory reconcile manifest emission."""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

APP = Path("/app")
REPORT = APP / "output" / "memory_manifest.json"


def _stem_tag(stem: str) -> str:
    bundle = json.loads((APP / "cases" / f"{stem}.json").read_text(encoding="utf-8"))
    return str(bundle["scenario_label"])


def _drive(stem: str) -> dict:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    if REPORT.exists():
        REPORT.unlink()
    subprocess.run(
        ["/app/bin/memreconcile"],
        cwd=str(APP),
        env={**os.environ, "tb_mem_pack": stem},
        check=True,
    )
    payload = json.loads(REPORT.read_text(encoding="utf-8"))
    assert "scenario_runs" in payload and len(payload["scenario_runs"]) == 1
    row = payload["scenario_runs"][0]
    assert row.get("scenario_tag") == _stem_tag(stem)
    return row


def _assert_row(
    row: dict,
    *,
    durable_writes: int,
    summary_merged: int,
    stale_blocked: int,
    checkpoint_clean: int,
    context_drift: int,
    replay_collapsed: int,
    cycle_blocked: int = 0,
) -> None:
    assert row["durable_writes"] == durable_writes
    assert row["summary_merged"] == summary_merged
    assert row["stale_blocked"] == stale_blocked
    assert row["checkpoint_clean"] == checkpoint_clean
    assert row["context_drift"] == context_drift
    assert row["replay_collapsed"] == replay_collapsed
    assert row["cycle_blocked"] == cycle_blocked


# Per-pack replay bands: tight enough that unfixed bench output fails, wide
# enough that a mostly-correct rebuild can land within ~1-3/10 agent trials.
def _assert_row_banded(
    row: dict,
    *,
    durable_writes: int | None = None,
    durable_writes_min: int | None = None,
    durable_writes_max: int | None = None,
    summary_merged_min: int,
    summary_merged_max: int | None = None,
    stale_blocked: int = 0,
    checkpoint_clean: int = 1,
    context_drift_min: int | None = None,
    context_drift_max: int = 0,
    replay_collapsed_min: int = 0,
    replay_collapsed_max: int | None = None,
    cycle_blocked: int = 0,
) -> None:
    if durable_writes is not None:
        assert row["durable_writes"] == durable_writes
    else:
        lo = 0 if durable_writes_min is None else durable_writes_min
        hi = row["durable_writes"] if durable_writes_max is None else durable_writes_max
        assert lo <= row["durable_writes"] <= hi
    assert row["summary_merged"] >= summary_merged_min
    if summary_merged_max is not None:
        assert row["summary_merged"] <= summary_merged_max
    assert row["stale_blocked"] == stale_blocked
    assert row["checkpoint_clean"] == checkpoint_clean
    if context_drift_min is not None:
        assert row["context_drift"] >= context_drift_min
    assert row["context_drift"] <= context_drift_max
    assert row["replay_collapsed"] >= replay_collapsed_min
    if replay_collapsed_max is not None:
        assert row["replay_collapsed"] <= replay_collapsed_max
    assert row["cycle_blocked"] == cycle_blocked



def test_mem_alpha() -> None:
    """Delayed WRITE rows on the same epoch must follow sequence order, not ingest time."""
    row = _drive("mem_alpha")
    _assert_row(
        row,
        durable_writes=2,
        summary_merged=1,
        stale_blocked=0,
        checkpoint_clean=1,
        context_drift=0,
        replay_collapsed=0,
    )


def test_mem_beta() -> None:
    """Contradictory summaries on one epoch resolve to the higher sequence winner."""
    row = _drive("mem_beta")
    _assert_row_banded(
        row,
        durable_writes=2,
        summary_merged_min=2,
        context_drift_max=1,
    )


def test_mem_canyon() -> None:
    """MEMORY_FENCE on one slot leaves a sibling slot free to reach its canonical summary."""
    row = _drive("mem_canyon")
    _assert_row_banded(
        row,
        durable_writes_min=1,
        summary_merged_min=0,
        context_drift_min=1,
        context_drift_max=2,
    )


def test_mem_delta() -> None:
    """A MEMORY_FENCE row for one slot must not block WRITE rows on another slot."""
    row = _drive("mem_delta")
    _assert_row_banded(
        row,
        durable_writes_min=1,
        summary_merged_min=0,
        context_drift_min=1,
        context_drift_max=2,
    )


def test_mem_echo() -> None:
    """Duplicate deliveries with the same sequence on different keys must not collapse."""
    row = _drive("mem_echo")
    _assert_row(
        row,
        durable_writes=2,
        summary_merged=0,
        stale_blocked=0,
        checkpoint_clean=1,
        context_drift=0,
        replay_collapsed=1,
    )


def test_mem_frost() -> None:
    """CHECKPOINT must restore the snapshot epoch without drift from the canonical summary."""
    row = _drive("mem_frost")
    _assert_row(
        row,
        durable_writes=1,
        summary_merged=0,
        stale_blocked=0,
        checkpoint_clean=1,
        context_drift=0,
        replay_collapsed=0,
    )


def test_mem_gamma() -> None:
    """Two WRITE rows on one epoch keep the later sequence value."""
    row = _drive("mem_gamma")
    _assert_row(
        row,
        durable_writes=1,
        summary_merged=1,
        stale_blocked=0,
        checkpoint_clean=1,
        context_drift=0,
        replay_collapsed=0,
    )


def test_mem_haze() -> None:
    """Out-of-order ingest timestamps still merge to sequence-ordered heads."""
    row = _drive("mem_haze")
    _assert_row_banded(
        row,
        durable_writes=3,
        summary_merged_min=1,
        context_drift_max=1,
    )


def test_mem_iron() -> None:
    """Multiple conflicting summaries resolve through sequence precedence without drift."""
    row = _drive("mem_iron")
    _assert_row_banded(
        row,
        durable_writes=2,
        summary_merged_min=3,
        context_drift_max=1,
    )


def test_mem_jade() -> None:
    """Shared sequence numbers across keys remain independent after replay dedupe."""
    row = _drive("mem_jade")
    _assert_row(
        row,
        durable_writes=2,
        summary_merged=2,
        stale_blocked=0,
        checkpoint_clean=1,
        context_drift=0,
        replay_collapsed=0,
    )


def test_mem_kite() -> None:
    """Per-slot MEMORY_FENCE rows block only the disputed slot."""
    row = _drive("mem_kite")
    _assert_row_banded(
        row,
        durable_writes_min=1,
        summary_merged_min=0,
        context_drift_min=1,
        context_drift_max=2,
    )


def test_mem_loom() -> None:
    """Late high-sequence WRITE rows win over early low-sequence summaries on one epoch."""
    row = _drive("mem_loom")
    _assert_row_banded(
        row,
        durable_writes=2,
        summary_merged_min=2,
        context_drift_max=1,
    )


def test_mem_mist() -> None:
    """Replay dedupe must not drop independent keys sharing a sequence number."""
    row = _drive("mem_mist")
    _assert_row(
        row,
        durable_writes=2,
        summary_merged=1,
        stale_blocked=0,
        checkpoint_clean=1,
        context_drift=0,
        replay_collapsed=1,
    )


def test_mem_nova() -> None:
    """CHECKPOINT on one slot while another slot keeps its WRITE summary."""
    row = _drive("mem_nova")
    _assert_row(
        row,
        durable_writes=2,
        summary_merged=1,
        stale_blocked=0,
        checkpoint_clean=1,
        context_drift=0,
        replay_collapsed=0,
    )


def test_mem_ozone() -> None:
    """Lower-sequence shadow summaries cannot replace a higher-sequence prime summary."""
    row = _drive("mem_ozone")
    _assert_row_banded(
        row,
        durable_writes=2,
        summary_merged_min=2,
        context_drift_max=1,
    )


def test_mem_peak() -> None:
    """Composite pack mixes dedupe, conflict resolution, and canonical alignment."""
    row = _drive("mem_peak")
    _assert_row_banded(
        row,
        durable_writes=2,
        summary_merged_min=2,
        context_drift_max=1,
        replay_collapsed_min=0,
        replay_collapsed_max=1,
    )


def test_mem_stale() -> None:
    """After checkpoint restore, sub-head sequence writes count as stale blocks."""
    row = _drive("mem_stale")
    _assert_row(
        row,
        durable_writes=1,
        summary_merged=1,
        stale_blocked=1,
        checkpoint_clean=1,
        context_drift=0,
        replay_collapsed=0,
    )


def test_mem_ring() -> None:
    """A LINK row that closes a parent cycle must be rejected and counted in cycle_blocked."""
    row = _drive("mem_ring")
    _assert_row(
        row,
        durable_writes=1,
        summary_merged=0,
        stale_blocked=0,
        checkpoint_clean=1,
        context_drift=0,
        replay_collapsed=0,
        cycle_blocked=1,
    )
