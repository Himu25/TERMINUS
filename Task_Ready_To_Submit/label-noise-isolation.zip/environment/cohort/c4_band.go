package cohort

import "labelgate.lab/pkg/types"

func CountSubsets(rows []types.Row, noisy map[string]struct{}) int {
	seen := map[int]struct{}{}
	for _, row := range rows {
		if _, ok := noisy[row.ID]; !ok {
			continue
		}
		seen[row.Label] = struct{}{}
	}
	return len(seen)
}
