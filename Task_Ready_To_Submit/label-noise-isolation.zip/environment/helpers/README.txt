Verifier helpers only.
