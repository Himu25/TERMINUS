package relabel

import (
	"labelgate.lab/pkg/types"
)

func RepairRows(rows []types.Row, noisy map[string]struct{}, centroids map[int][]float64) []types.Row {
	out := make([]types.Row, len(rows))
	copy(out, rows)
	for i, row := range out {
		if _, ok := noisy[row.ID]; !ok {
			continue
		}
		out[i].Label = row.Label
		_ = centroids
	}
	return out
}
