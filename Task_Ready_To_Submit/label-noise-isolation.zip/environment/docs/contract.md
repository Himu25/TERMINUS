Report contract for `/app/output/noise_report.json`:

- suites[] rows in profile order with name, total, noisy_detected, subset_count, repaired_count, balance_score, val_accuracy (four decimal places).
- summary with noise_recall, balance_score, val_accuracy, passes_gate.

Gate floors live in `/app/config/thresholds.toml`. anchor_holdout must keep noisy_detected at zero. Hardened suites must meet per-suite noisy and subset floors where listed. passes_gate requires every floor plus summary noise_recall, balance_score, and val_accuracy.

Identical inputs must yield byte-identical reports.
