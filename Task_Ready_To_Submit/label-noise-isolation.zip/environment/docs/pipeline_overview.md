# Label audit pipeline

The Go stack under `/app` ingests JSONL label rows, scores feature-label mismatches, groups annotator batches, rewrites flagged labels from centroid geometry, and caps class counts before scoring.

Packages: `ingest` (JSONL load), `probe` (nearest-centroid gate), `cohort` (annotator batch bands), `relabel` (label rewrite), `quota` (balance trim and val accuracy), `bench` (profile sweep and report write). Entry binary: `/app/cmd/auditd` → `/app/bin/labelaudit`.

Run `/app/tools/label_audit` (optional profile path; default `/app/config/bench_profiles.json`). Stress uses `/app/config/stress_profiles.json`. Output lands at `/app/output/noise_report.json`.
