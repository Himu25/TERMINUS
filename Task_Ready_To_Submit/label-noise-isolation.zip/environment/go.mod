module labelgate.lab

go 1.22
