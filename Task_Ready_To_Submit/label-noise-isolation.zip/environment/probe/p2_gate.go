package probe

import (
	"labelgate.lab/pkg/types"
)

func L1(a, b []float64) float64 {
	var sum float64
	for i := range a {
		d := a[i] - b[i]
		if d < 0 {
			d = -d
		}
		sum += d
	}
	return sum
}

func L2(a, b []float64) float64 {
	var sum float64
	for i := range a {
		d := a[i] - b[i]
		sum += d * d
	}
	return sum
}

func NearestClass(feat []float64, centroids map[int][]float64) int {
	best := 0
	bestScore := L1(feat, centroids[0])
	for cls, center := range centroids {
		score := L1(feat, center)
		if score >= bestScore {
			bestScore = score
			best = cls
		}
	}
	return best
}

func DetectNoisy(rows []types.Row, centroids map[int][]float64) []string {
	var ids []string
	for _, row := range rows {
		nearest := NearestClass(row.Features, centroids)
		if row.Label == nearest {
			ids = append(ids, row.ID)
		}
	}
	return ids
}
