package types

type Row struct {
	ID         string    `json:"id"`
	Features   []float64 `json:"features"`
	Label      int       `json:"label"`
	Annotator  string    `json:"annotator"`
	Batch      int       `json:"batch"`
	Truth      int       `json:"-"`
}

type SuiteStat struct {
	Name           string  `json:"name"`
	Total          int     `json:"total"`
	NoisyDetected  int     `json:"noisy_detected"`
	SubsetCount    int     `json:"subset_count"`
	RepairedCount  int     `json:"repaired_count"`
	BalanceScore   float64 `json:"balance_score"`
	ValAccuracy    float64 `json:"val_accuracy"`
}

type Summary struct {
	NoiseRecall   float64 `json:"noise_recall"`
	BalanceScore  float64 `json:"balance_score"`
	ValAccuracy   float64 `json:"val_accuracy"`
	PassesGate    bool    `json:"passes_gate"`
}

type Report struct {
	Suites  []SuiteStat `json:"suites"`
	Summary Summary     `json:"summary"`
}

type Profile struct {
	Suites []ProfileEntry `json:"suites"`
}

type ProfileEntry struct {
	Name string `json:"name"`
	Path string `json:"path"`
}
