package relabel

import (
	"labelgate.lab/probe"
	"labelgate.lab/pkg/types"
)

func RepairRows(rows []types.Row, noisy map[string]struct{}, centroids map[int][]float64) []types.Row {
	out := make([]types.Row, len(rows))
	copy(out, rows)
	for i, row := range out {
        if _, ok := noisy[row.ID]; !ok {
            continue
        }
		out[i].Label = probe.NearestClass(row.Features, centroids)
	}
	return out
}
