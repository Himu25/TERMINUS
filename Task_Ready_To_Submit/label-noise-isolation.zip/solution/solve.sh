#!/bin/bash
set -euo pipefail

log() { printf '[oracle] %s\n' "$1"; }

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight layout"
require_file /app/go.mod
require_file /app/probe/p2_gate.go
require_file /app/cohort/c4_band.go
require_file /app/relabel/r5_fix.go
require_file /app/quota/q6_trim.go
require_file /app/config/bench_profiles.json
require_file /app/registry/centroids.json

log "install oracle modules"
cp "${ROOT_DIR}/oracle/p2_gate.go" /app/probe/p2_gate.go
cp "${ROOT_DIR}/oracle/c4_band.go" /app/cohort/c4_band.go
cp "${ROOT_DIR}/oracle/r5_fix.go" /app/relabel/r5_fix.go
cp "${ROOT_DIR}/oracle/q6_trim.go" /app/quota/q6_trim.go

log "rebuild label audit binary"
mkdir -p /app/bin /app/output
go build -o /app/bin/labelaudit ./cmd/auditd
chmod +x /app/tools/label_audit

log "smoke bench"
/app/tools/label_audit
require_file /app/output/noise_report.json

python3 - <<'PY'
import json
from pathlib import Path

report = json.loads(Path("/app/output/noise_report.json").read_text())
summary = report["summary"]
if not summary["passes_gate"]:
    raise SystemExit("passes_gate false")
if summary["noise_recall"] < 0.95:
    raise SystemExit("noise recall floor miss")
if summary["balance_score"] < 0.90:
    raise SystemExit("balance floor miss")
if summary["val_accuracy"] < 0.95:
    raise SystemExit("val accuracy floor miss")
for suite in report["suites"]:
    if suite["name"] == "anchor_holdout" and suite["noisy_detected"] != 0:
        raise SystemExit("anchor noisy count")
PY

log "oracle complete"
