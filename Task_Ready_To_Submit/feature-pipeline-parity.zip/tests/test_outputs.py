"""Verifier for feature-pipeline-parity."""

from __future__ import annotations

import json
import os
import re
import subprocess
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

import pytest

APP = Path("/app")
OUT = APP / "output" / "parity_report.json"
BATCH = APP / "data" / "scoring_batch.json"
OFFLINE = APP / "data" / "offline_feature_table.tsv"
VOCAB = APP / "data" / "category_vocab.tsv"
LIVE = APP / "cache" / "live_feature_store.json"
ANCHOR = APP / "config" / "clock.anchor"
SCALES = APP / "registry" / "category_scales.json"
PROBE = APP / "tools" / "parity_probe"
FIXTURES = Path(__file__).resolve().parent / "fixtures"

EPS = 1e-6

FIXTURE_NAMES = [
    "scenario_midnight_utc",
    "scenario_stale_fallback",
    "scenario_extra_entity",
    "scenario_full_corpus",
    "scenario_dst_boundary",
    "scenario_double_day_entity",
    "scenario_category_sweep",
    "scenario_interleaved_replay",
    "scenario_negative_numeric",
    "scenario_unknown_bucket",
    "scenario_cross_midnight_ny",
    "scenario_heavy_mixed",
    "scenario_fresh_live_slice",
    "scenario_dec31_cluster",
    "scenario_live_mismatch_gamma",
    "scenario_reversed_corpus",
    "scenario_triple_stale_wave",
    "scenario_high_numeric_ladder",
    "scenario_subscription_pair",
    "scenario_dense_same_instant",
    "scenario_epsilon_theta_cross",
    "scenario_marketplace_scale",
]

BUNDLED_ROWS = [
    ("ent_alpha", "2025-01-01T14:22:00Z"),
    ("ent_beta", "2025-01-01T08:15:00Z"),
    ("ent_gamma", "2024-12-31T23:50:00Z"),
    ("ent_delta", "2025-01-02T01:05:00Z"),
    ("ent_epsilon", "2025-01-02T16:40:00Z"),
    ("ent_zeta", "2025-01-01T19:30:00Z"),
    ("ent_eta", "2024-12-31T22:10:00Z"),
    ("ent_theta", "2025-01-02T11:00:00Z"),
    ("ent_iota", "2025-01-01T06:00:00Z"),
    ("ent_kappa", "2025-01-02T03:45:00Z"),
]


def _offline_key(entity_id: str, event_ts: str) -> str:
    return f"{entity_id}|{_day_key_utc(event_ts)}"


def _offline_row(entity_id: str, event_ts: str) -> tuple[float, str]:
    return _load_offline()[_offline_key(entity_id, event_ts)]


def _props_float(path: Path, key: str) -> float:
    prefix = f"{key}="
    for line in path.read_text(encoding="utf-8").splitlines():
        st = line.strip()
        if st.startswith(prefix):
            return float(st.split("=", 1)[1].strip())
    msg = f"{key} missing from {path}"
    raise AssertionError(msg)


def _rewrite_props_key(path: Path, key: str, new_val: float) -> str:
    backup = path.read_text(encoding="utf-8")
    prefix = f"{key}="
    out_lines: list[str] = []
    for line in backup.splitlines():
        st = line.strip()
        if st.startswith(prefix):
            out_lines.append(f"{key}={new_val}")
        else:
            out_lines.append(line)
    body = "\n".join(out_lines)
    if backup.endswith("\n"):
        body += "\n"
    _atomic_write_text(path, body)
    return backup


def _load_score_cfg() -> tuple[float, float, float, float]:
    cfg: dict[str, str] = {}
    for path in (APP / "config/training.properties", APP / "config/serving.properties"):
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, val = line.split("=", 1)
            cfg[key.strip()] = val.strip()
    return (
        float(cfg["score.bias"]),
        float(cfg["score.numeric.weight"]),
        float(cfg["score.category.weight"]),
        float(cfg["score.euler"]),
    )


def _day_ms() -> int:
    props = (APP / "config/serving.properties").read_text(encoding="utf-8")
    return int(
        next(
            line.split("=", 1)[1].strip()
            for line in props.splitlines()
            if line.strip().startswith("clock.day_ms=")
        )
    )


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)
    if hasattr(os, "sync"):
        os.sync()


def _load_category_scales() -> dict[str, float]:
    body = json.loads(SCALES.read_text(encoding="utf-8"))
    return {str(k): float(v) for k, v in body.items()}


def _scaled_numeric(numeric: float, category: str) -> float:
    scales = _load_category_scales()
    return numeric * scales.get(category, scales["default"])


def _load_vocab() -> dict[str, int]:
    vocab: dict[str, int] = {}
    for line in VOCAB.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("category"):
            continue
        cat, idx = line.split("\t", 1)
        vocab[cat.strip()] = int(idx.strip())
    return vocab


def _load_offline() -> dict[str, tuple[float, str]]:
    rows: dict[str, tuple[float, str]] = {}
    for line in OFFLINE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("entity_id"):
            continue
        entity, day, numeric, category = line.split("\t")
        rows[f"{entity}|{day}"] = (float(numeric), category.strip())
    return rows


def _load_live() -> dict[str, tuple[float, str, int]]:
    body = LIVE.read_text(encoding="utf-8")
    out: dict[str, tuple[float, str, int]] = {}
    pat = re.compile(
        r'"([a-z_]+)"\s*:\s*\{\s*"numeric"\s*:\s*([-\d.]+),'
        r'\s*"category"\s*:\s*"([^"]+)",\s*"expires_at"\s*:\s*(\d+)'
    )
    for entity, num, cat, exp in pat.findall(body):
        out[entity] = (float(num), cat, int(exp))
    return out


def _day_key_utc(event_ts: str) -> str:
    dt = datetime.fromisoformat(event_ts.replace("Z", "+00:00"))
    return dt.astimezone(timezone.utc).strftime("%Y%m%d")


def _sigmoid(logit: float, euler: float) -> float:
    if logit >= 0:
        z = pow(euler, -logit)
        return 1.0 / (1.0 + z)
    z = pow(euler, logit)
    return z / (1.0 + z)


def _score(numeric: float, cat_idx: int, cfg: tuple[float, float, float, float]) -> float:
    bias, num_w, cat_w, euler = cfg
    logit = bias + num_w * numeric + cat_w * cat_idx
    return round(_sigmoid(logit, euler), 6)


def _parse_batch(path: Path) -> list[tuple[str, str]]:
    doc = json.loads(path.read_text(encoding="utf-8"))
    return [(row["entity_id"], row["event_ts"]) for row in doc["rows"]]


def _reference_rows(batch_path: Path) -> list[dict]:
    vocab = _load_vocab()
    offline = _load_offline()
    live = _load_live()
    cfg = _load_score_cfg()
    anchor = int(ANCHOR.read_text(encoding="utf-8").strip())
    entities: list[dict] = []
    for entity_id, event_ts in _parse_batch(batch_path):
        day = _day_key_utc(event_ts)
        off_row = offline[f"{entity_id}|{day}"]
        off_score = _score(
            _scaled_numeric(off_row[0], off_row[1]), vocab[off_row[1]], cfg
        )

        on_row = off_row
        live_row = live.get(entity_id)
        if (
            live_row is not None
            and live_row[2] > anchor
            and (live_row[0], live_row[1]) == off_row
        ):
            on_row = (live_row[0], live_row[1])
        on_score = _score(
            _scaled_numeric(on_row[0], on_row[1]), vocab[on_row[1]], cfg
        )

        delta = abs(off_score - on_score)
        entities.append(
            {
                "entity_id": entity_id,
                "offline_score": off_score,
                "online_score": on_score,
                "aligned": delta <= EPS,
            }
        )
    return entities


def _summary(entities: list[dict]) -> dict:
    max_delta = 0.0
    aligned_count = 0
    for row in entities:
        delta = abs(row["offline_score"] - row["online_score"])
        max_delta = max(max_delta, delta)
        if row["aligned"]:
            aligned_count += 1
    return {
        "total": len(entities),
        "aligned_count": aligned_count,
        "max_abs_delta": round(max_delta, 6),
    }


def _reference_report(batch_path: Path) -> dict:
    entities = _reference_rows(batch_path)
    return {"entities": entities, "summary": _summary(entities)}


def _run_probe_fixture(fixture_name: str) -> dict:
    """Run probe against a fixture file via explicit batch path argument."""
    fixture_path = FIXTURES / f"{fixture_name}.json"
    return _run_probe(fixture_path)


def _run_probe(batch_path: Path | None = None) -> dict:
    cmd = [str(PROBE)]
    if batch_path is not None:
        cmd.append(str(batch_path))
    subprocess.run(cmd, check=True, cwd="/app", timeout=180)
    return json.loads(OUT.read_text(encoding="utf-8"))


def _assert_full_alignment(report: dict) -> None:
    assert set(report.keys()) == {"entities", "summary"}
    entities = report["entities"]
    assert isinstance(entities, list) and entities
    for row in entities:
        assert set(row.keys()) == {
            "entity_id",
            "offline_score",
            "online_score",
            "aligned",
        }
        assert row["aligned"] is True
        assert abs(row["offline_score"] - row["online_score"]) <= EPS
    summary = report["summary"]
    assert summary["total"] == len(entities)
    assert summary["aligned_count"] == len(entities)
    assert summary["max_abs_delta"] <= EPS


def _assert_report_equals(got: dict, want: dict) -> None:
    assert got["summary"] == want["summary"]
    assert got["entities"] == want["entities"]


@contextmanager
def _swap_batch(fixture_name: str) -> Iterator[Path]:
    backup = BATCH.read_text(encoding="utf-8")
    fixture = FIXTURES / f"{fixture_name}.json"
    try:
        _atomic_write_text(BATCH, fixture.read_text(encoding="utf-8"))
        yield BATCH
    finally:
        _atomic_write_text(BATCH, backup)


@pytest.fixture(scope="module")
def bundled_reference() -> dict:
    return _reference_report(BATCH)


@pytest.fixture(scope="module")
def bundled_report(bundled_reference: dict) -> dict:
    got = _run_probe()
    _assert_report_equals(got, bundled_reference)
    return got


class TestParityBundled:
    def test_probe_produces_report(self, bundled_report: dict) -> None:
        """parity_probe must emit a fully aligned parity_report.json on the bundled batch."""
        _assert_full_alignment(bundled_report)

    def test_report_matches_reference(self, bundled_report: dict, bundled_reference: dict) -> None:
        """Report scores must match the reference offline/online replay semantics."""
        _assert_report_equals(bundled_report, bundled_reference)

    def test_entity_order_follows_batch_sequence(self, bundled_report: dict) -> None:
        """entities array order must mirror scoring_batch.json row order."""
        batch_order = [e for e, _ in _parse_batch(BATCH)]
        report_order = [row["entity_id"] for row in bundled_report["entities"]]
        assert report_order == batch_order

    def test_scores_are_six_decimal_json_numbers(self, bundled_report: dict) -> None:
        """offline_score and online_score must be JSON numbers rounded to six decimals."""
        raw = OUT.read_text(encoding="utf-8")
        for row in bundled_report["entities"]:
            off = row["offline_score"]
            on = row["online_score"]
            assert isinstance(off, (int, float))
            assert isinstance(on, (int, float))
            assert f'"offline_score":{off}' in raw or f'"offline_score": {off}' in raw

    def test_summary_recomputed_from_rows(self, bundled_report: dict) -> None:
        """summary must be consistent with per-row alignment, not hardcoded."""
        entities = bundled_report["entities"]
        want = _summary(entities)
        assert bundled_report["summary"] == want

    def test_probe_determinism_byte_identical(self) -> None:
        """Two consecutive probes on the same batch must emit identical JSON bytes."""
        _run_probe()
        first = OUT.read_text(encoding="utf-8")
        _run_probe()
        second = OUT.read_text(encoding="utf-8")
        assert first == second

    def test_bundled_ten_row_score_vector_matches_reference(
        self, bundled_report: dict, bundled_reference: dict
    ) -> None:
        """Full bundled score vector must equal the reference replay row-for-row."""
        got_scores = [(r["offline_score"], r["online_score"]) for r in bundled_report["entities"]]
        want_scores = [
            (r["offline_score"], r["online_score"]) for r in bundled_reference["entities"]
        ]
        assert got_scores == want_scores


class TestParityFixtures:
    @pytest.mark.parametrize("fixture_name", FIXTURE_NAMES)
    def test_fixture_batches_align(self, fixture_name: str) -> None:
        """Substituted scoring batches must stay aligned after a durable fix."""
        with _swap_batch(fixture_name) as batch_path:
            want = _reference_report(batch_path)
            got = _run_probe(batch_path)
            _assert_full_alignment(got)
            _assert_report_equals(got, want)


class TestParityHardScenarios:
    def test_stale_pair_scores_match_offline_not_live_stale_values(self) -> None:
        """ent_beta and ent_zeta must use offline fallback rows, not stale live numerics."""
        with _swap_batch("scenario_stale_fallback"):
            got = _run_probe(BATCH)
            cfg = _load_score_cfg()
            vocab = _load_vocab()
            offline = _load_offline()
            for entity_id, event_ts in _parse_batch(BATCH):
                day = _day_key_utc(event_ts)
                num, cat = offline[f"{entity_id}|{day}"]
                want = _score(_scaled_numeric(num, cat), vocab[cat], cfg)
                row = next(r for r in got["entities"] if r["entity_id"] == entity_id)
                assert row["offline_score"] == want
                assert row["online_score"] == want

    def test_dst_boundary_delta_row_uses_utc_day_not_previous_evening(self) -> None:
        """ent_delta at 2025-01-02T05:00:00Z must join 20250102 offline subscription row."""
        with _swap_batch("scenario_dst_boundary"):
            got = _run_probe(BATCH)
            cfg = _load_score_cfg()
            vocab = _load_vocab()
            delta_ts = next(ts for ent, ts in _parse_batch(BATCH) if ent == "ent_delta")
            num, cat = _offline_row("ent_delta", delta_ts)
            want = _score(_scaled_numeric(num, cat), vocab[cat], cfg)
            delta_rows = [r for r in got["entities"] if r["entity_id"] == "ent_delta"]
            assert len(delta_rows) == 2
            assert any(r["offline_score"] == want and r["online_score"] == want for r in delta_rows)

    def test_double_day_entity_emits_two_distinct_scores(self) -> None:
        """Same entity on consecutive UTC days must produce two different score rows."""
        with _swap_batch("scenario_double_day_entity"):
            got = _run_probe(BATCH)
            alpha_rows = [r for r in got["entities"] if r["entity_id"] == "ent_alpha"]
            assert len(alpha_rows) == 2
            assert alpha_rows[0]["offline_score"] != alpha_rows[1]["offline_score"]

    def test_category_sweep_covers_all_vocab_indices(self) -> None:
        """Category sweep must exercise retail, wholesale, marketplace, subscription, unknown."""
        with _swap_batch("scenario_category_sweep"):
            got = _run_probe(BATCH)
            cfg = _load_score_cfg()
            vocab = _load_vocab()
            offline = _load_offline()
            seen_idx: set[int] = set()
            for entity_id, event_ts in _parse_batch(BATCH):
                day = _day_key_utc(event_ts)
                cat = offline[f"{entity_id}|{day}"][1]
                seen_idx.add(vocab[cat])
                row = next(r for r in got["entities"] if r["entity_id"] == entity_id)
                num, _ = offline[f"{entity_id}|{day}"]
                want = _score(_scaled_numeric(num, cat), vocab[cat], cfg)
                assert row["offline_score"] == want
            assert seen_idx == set(_load_vocab().values())

    def test_negative_numeric_epsilon_day_crossing(self) -> None:
        """ent_epsilon negative then positive numeric features must both align across paths."""
        with _swap_batch("scenario_negative_numeric"):
            got = _run_probe(BATCH)
            rows = [r for r in got["entities"] if r["entity_id"] == "ent_epsilon"]
            assert len(rows) == 2
            assert rows[0]["offline_score"] < rows[1]["offline_score"]

    def test_unknown_bucket_maps_vocab_unknown_index(self) -> None:
        """ent_kappa must index through the unknown row in category_vocab.tsv."""
        with _swap_batch("scenario_unknown_bucket"):
            got = _run_probe(BATCH)
            vocab = _load_vocab()
            assert vocab["unknown"] == 4
            cfg = _load_score_cfg()
            offline = _load_offline()
            for idx, (entity_id, event_ts) in enumerate(_parse_batch(BATCH)):
                day = _day_key_utc(event_ts)
                num, cat = offline[f"{entity_id}|{day}"]
                assert cat == "unknown"
                want = _score(_scaled_numeric(num, cat), vocab[cat], cfg)
                row = got["entities"][idx]
                assert row["entity_id"] == entity_id
                assert row["offline_score"] == want
                assert row["online_score"] == want

    def test_cross_midnight_ny_boundary_pairs_differ(self) -> None:
        """UTC day boundaries must yield distinct offline rows for the same entity."""
        with _swap_batch("scenario_cross_midnight_ny"):
            got = _run_probe(BATCH)
            delta_rows = [r for r in got["entities"] if r["entity_id"] == "ent_delta"]
            assert len(delta_rows) == 2
            assert delta_rows[0]["offline_score"] != delta_rows[1]["offline_score"]
            assert delta_rows[0]["aligned"] and delta_rows[1]["aligned"]

    def test_heavy_mixed_ten_row_matrix_fully_aligned(self) -> None:
        """Heavy mixed fixture must align ten rows with independent reference replay."""
        with _swap_batch("scenario_heavy_mixed") as batch_path:
            want = _reference_report(batch_path)
            got = _run_probe(batch_path)
            _assert_report_equals(got, want)

    def test_fresh_live_slice_uses_live_when_unexpired(self) -> None:
        """Fresh live entries must match offline table values for the aligned slice."""
        with _swap_batch("scenario_fresh_live_slice"):
            got = _run_probe(BATCH)
            live = _load_live()
            offline = _load_offline()
            anchor = int(ANCHOR.read_text(encoding="utf-8").strip())
            for entity_id, event_ts in _parse_batch(BATCH):
                day = _day_key_utc(event_ts)
                off = offline[f"{entity_id}|{day}"]
                live_row = live[entity_id]
                assert live_row[2] > anchor
                assert (live_row[0], live_row[1]) == off
                row = next(r for r in got["entities"] if r["entity_id"] == entity_id)
                assert row["aligned"] is True


class TestParityRegressionMatrix:
    def test_anchor_advance_one_day_still_aligns(self) -> None:
        """Advancing clock.anchor by one day must not reintroduce stale-cache skew."""
        backup_anchor = ANCHOR.read_text(encoding="utf-8")
        try:
            anchor_ms = str(int(backup_anchor.strip()) + _day_ms())
            _atomic_write_text(ANCHOR, f"{anchor_ms}\n")
            got = _run_probe()
            _assert_full_alignment(got)
        finally:
            _atomic_write_text(ANCHOR, backup_anchor)
            _run_probe()

    def test_anchor_advance_expires_all_live_still_aligns(self) -> None:
        """When every live entry expires, online must fall back to offline for all rows."""
        backup_anchor = ANCHOR.read_text(encoding="utf-8")
        live = _load_live()
        try:
            max_exp = max(exp for _, _, exp in live.values())
            _atomic_write_text(ANCHOR, f"{max_exp + 1}\n")
            with _swap_batch("scenario_full_corpus"):
                got = _run_probe(BATCH)
                _assert_full_alignment(got)
        finally:
            _atomic_write_text(ANCHOR, backup_anchor)
            _run_probe()

    def test_serving_bias_drift_breaks_alignment(self) -> None:
        """Drifting only serving score.bias must desynchronize online from offline replay."""
        path = APP / "config/serving.properties"
        key = "score.bias"
        try:
            base = _props_float(path, key)
            backup = _rewrite_props_key(path, key, base - 1.0)
            got = _run_probe()
            assert got["summary"]["aligned_count"] < got["summary"]["total"]
        finally:
            _atomic_write_text(path, backup)
            _run_probe()

    def test_training_bias_drift_breaks_alignment(self) -> None:
        """Drifting only training score.bias must desynchronize offline from online replay."""
        path = APP / "config/training.properties"
        key = "score.bias"
        try:
            base = _props_float(path, key)
            backup = _rewrite_props_key(path, key, base - 1.0)
            got = _run_probe()
            assert got["summary"]["aligned_count"] < got["summary"]["total"]
        finally:
            _atomic_write_text(path, backup)
            _run_probe()

    def test_training_numeric_weight_drift_breaks_alignment(self) -> None:
        """Drifting only training numeric weight must change offline scores but not online."""
        path = APP / "config/training.properties"
        key = "score.numeric.weight"
        try:
            base = _props_float(path, key)
            backup = _rewrite_props_key(path, key, base + 0.5)
            got = _run_probe()
            assert got["summary"]["max_abs_delta"] > EPS
        finally:
            _atomic_write_text(path, backup)
            _run_probe()

    def test_double_probe_after_anchor_restore_matches_reference(self) -> None:
        """Restoring anchor then probing twice must reproduce the bundled reference report."""
        backup_anchor = ANCHOR.read_text(encoding="utf-8")
        try:
            _atomic_write_text(ANCHOR, f"{int(backup_anchor.strip()) + _day_ms()}\n")
            _run_probe()
        finally:
            _atomic_write_text(ANCHOR, backup_anchor)
        first = _run_probe()
        second = _run_probe()
        want = _reference_report(BATCH)
        _assert_report_equals(first, want)
        _assert_report_equals(second, want)

    def test_serving_category_weight_drift_breaks_alignment(self) -> None:
        """Drifting only serving category weight must desynchronize paths."""
        path = APP / "config/serving.properties"
        key = "score.category.weight"
        try:
            base = _props_float(path, key)
            backup = _rewrite_props_key(path, key, base + 0.7)
            got = _run_probe()
            assert got["summary"]["aligned_count"] < got["summary"]["total"]
        finally:
            _atomic_write_text(path, backup)
            _run_probe()


class TestParityExactContract:
    @pytest.mark.parametrize("fixture_name", FIXTURE_NAMES)
    def test_fixture_via_direct_path_argument(self, fixture_name: str) -> None:
        """parity_probe must accept an explicit fixture path and stay aligned."""
        want = _reference_report(FIXTURES / f"{fixture_name}.json")
        got = _run_probe_fixture(fixture_name)
        _assert_report_equals(got, want)


class TestParityInvariants:
    def test_all_scores_within_unit_interval(self, bundled_report: dict) -> None:
        """Every probability must land in [0, 1] after the logistic head."""
        for row in bundled_report["entities"]:
            for key in ("offline_score", "online_score"):
                val = row[key]
                assert 0.0 <= val <= 1.0

    def test_aligned_rows_have_zero_delta(self, bundled_report: dict) -> None:
        """aligned true must imply offline_score equals online_score within epsilon."""
        for row in bundled_report["entities"]:
            if row["aligned"]:
                assert abs(row["offline_score"] - row["online_score"]) <= EPS

    def test_summary_max_delta_is_max_row_delta(self, bundled_report: dict) -> None:
        """summary.max_abs_delta must equal the maximum per-row absolute delta."""
        deltas = [
            abs(r["offline_score"] - r["online_score"]) for r in bundled_report["entities"]
        ]
        assert bundled_report["summary"]["max_abs_delta"] == round(max(deltas), 6)


class TestParityChainedStress:
    def test_three_fixture_chain_without_rebuild(self) -> None:
        """Probe must survive rotating through three fixtures back-to-back."""
        chain = [
            "scenario_stale_fallback",
            "scenario_live_mismatch_gamma",
            "scenario_reversed_corpus",
        ]
        for name in chain:
            with _swap_batch(name) as batch_path:
                want = _reference_report(batch_path)
                got = _run_probe(batch_path)
                _assert_report_equals(got, want)
        final = _reference_report(BATCH)
        got = _run_probe()
        _assert_report_equals(got, final)

    def test_anchor_shift_then_heavy_mixed_then_restore(self) -> None:
        """Anchor shift plus heavy fixture must restore to bundled reference."""
        backup_anchor = ANCHOR.read_text(encoding="utf-8")
        try:
            _atomic_write_text(ANCHOR, f"{int(backup_anchor.strip()) + _day_ms()}\n")
            with _swap_batch("scenario_heavy_mixed") as batch_path:
                got = _run_probe(batch_path)
                _assert_full_alignment(got)
        finally:
            _atomic_write_text(ANCHOR, backup_anchor)
        want = _reference_report(BATCH)
        got = _run_probe()
        _assert_report_equals(got, want)


class TestParityAdvancedScenarios:
    def test_live_mismatch_gamma_uses_offline_for_jan_first(self) -> None:
        """Fresh live cache must not override offline join when numerics disagree."""
        with _swap_batch("scenario_live_mismatch_gamma"):
            got = _run_probe(BATCH)
            cfg = _load_score_cfg()
            vocab = _load_vocab()
            event_ts = _parse_batch(BATCH)[0][1]
            num, cat = _offline_row("ent_gamma", event_ts)
            want = _score(_scaled_numeric(num, cat), vocab[cat], cfg)
            row = got["entities"][0]
            assert row["entity_id"] == "ent_gamma"
            assert row["offline_score"] == want
            assert row["online_score"] == want
            live_num = _load_live()["ent_gamma"][0]
            assert live_num != num

    def test_dec31_cluster_four_rows_distinct_scores(self) -> None:
        """Dec-31 cluster must emit four aligned rows with two distinct entity families."""
        with _swap_batch("scenario_dec31_cluster"):
            got = _run_probe(BATCH)
            assert len(got["entities"]) == 4
            _assert_full_alignment(got)
            gamma_scores = {r["offline_score"] for r in got["entities"] if r["entity_id"] == "ent_gamma"}
            eta_scores = {r["offline_score"] for r in got["entities"] if r["entity_id"] == "ent_eta"}
            assert len(gamma_scores) == 1
            assert len(eta_scores) == 1
            assert gamma_scores != eta_scores

    def test_triple_stale_wave_beta_zeta_multi_day(self) -> None:
        """Stale wave must align four rows across two days for beta and zeta."""
        with _swap_batch("scenario_triple_stale_wave") as batch_path:
            want = _reference_report(batch_path)
            got = _run_probe(batch_path)
            _assert_report_equals(got, want)
            beta = [r for r in got["entities"] if r["entity_id"] == "ent_beta"]
            assert len(beta) == 2
            assert beta[0]["offline_score"] != beta[1]["offline_score"]

    def test_dense_same_instant_eight_entity_matrix(self) -> None:
        """Eight entities at the same instant must each align with distinct scores."""
        with _swap_batch("scenario_dense_same_instant") as batch_path:
            got = _run_probe(batch_path)
            want = _reference_report(batch_path)
            _assert_report_equals(got, want)
            scores = {r["offline_score"] for r in got["entities"]}
            assert len(scores) >= 6

    def test_high_numeric_ladder_monotonic_iota(self) -> None:
        """ent_iota day-1 to day-2 scores must rise along the numeric ladder."""
        with _swap_batch("scenario_high_numeric_ladder"):
            got = _run_probe(BATCH)
            iota = [r for r in got["entities"] if r["entity_id"] == "ent_iota"]
            assert len(iota) == 2
            assert iota[0]["offline_score"] > iota[1]["offline_score"]
            assert iota[0]["aligned"] and iota[1]["aligned"]

    def test_subscription_pair_delta_eta_day_flip(self) -> None:
        """Subscription entities must switch day keys across the paired fixture rows."""
        with _swap_batch("scenario_subscription_pair"):
            got = _run_probe(BATCH)
            delta = [r for r in got["entities"] if r["entity_id"] == "ent_delta"]
            eta = [r for r in got["entities"] if r["entity_id"] == "ent_eta"]
            assert delta[0]["offline_score"] != delta[1]["offline_score"]
            assert eta[0]["offline_score"] != eta[1]["offline_score"]
            _assert_full_alignment(got)

    def test_marketplace_scale_changes_theta_gamma_scores(self) -> None:
        """Marketplace calibration must move gamma and theta away from unscaled baselines."""
        with _swap_batch("scenario_marketplace_scale"):
            got = _run_probe(BATCH)
            cfg = _load_score_cfg()
            vocab = _load_vocab()
            scales = _load_category_scales()
            for entity_id in ("ent_gamma", "ent_theta"):
                event_ts = next(ts for ent, ts in _parse_batch(BATCH) if ent == entity_id)
                num, cat = _offline_row(entity_id, event_ts)
                assert cat == "marketplace"
                assert scales[cat] > 1.0
                want = _score(_scaled_numeric(num, cat), vocab[cat], cfg)
                unscaled = _score(num, vocab[cat], cfg)
                row = next(r for r in got["entities"] if r["entity_id"] == entity_id)
                assert want != unscaled
                assert row["offline_score"] == want
                assert row["online_score"] == want
            _assert_full_alignment(got)

    def test_reversed_corpus_order_differs_from_bundled_order(self) -> None:
        """Reversed corpus fixture must not preserve the bundled entity order."""
        with _swap_batch("scenario_reversed_corpus"):
            got = _run_probe(BATCH)
            bundled_order = [e for e, _ in _parse_batch(BATCH)]
            report_order = [r["entity_id"] for r in got["entities"]]
            assert report_order == bundled_order
            assert report_order != [e for e, _ in BUNDLED_ROWS]
