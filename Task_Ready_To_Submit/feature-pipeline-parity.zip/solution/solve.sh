#!/bin/bash
set -euo pipefail

log() { printf '[oracle] %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

assert_grep() {
  local path="$1"
  local pattern="$2"
  if ! grep -qE "$pattern" "$path"; then
    log "expected pattern in $path: $pattern"
    exit 1
  fi
}

log "preflight: parity pipeline layout"
require_file /app/fsvc/src/main/java/com/ml/fs/TimeBucket.java
require_file /app/fsvc/src/main/java/com/ml/fs/LiveStore.java
require_file /app/fsvc/src/main/java/com/ml/fs/CatIndex.java
require_file /app/fsvc/src/main/java/com/ml/fs/OnlineServing.java
require_file /app/config/clock.anchor
require_file /app/cache/live_feature_store.json
require_file /app/data/offline_feature_table.tsv
require_file /app/data/category_vocab.tsv

TB="/app/fsvc/src/main/java/com/ml/fs/TimeBucket.java"
LS="/app/fsvc/src/main/java/com/ml/fs/LiveStore.java"
CI="/app/fsvc/src/main/java/com/ml/fs/CatIndex.java"
OS="/app/fsvc/src/main/java/com/ml/fs/OnlineServing.java"

log "install cache policy helper used by live store expiry checks"
cat > /app/fsvc/src/main/java/com/ml/fs/CachePolicy.java <<'JAVA'
package com.ml.fs;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class CachePolicy {
    private static final Pattern STALE =
            Pattern.compile("\"stale_read_policy\"\\s*:\\s*\"([^\"]+)\"");
    private static final Pattern TTL =
            Pattern.compile("\"default_ttl_sec\"\\s*:\\s*(\\d+)");

    private final String staleReadPolicy;
    private final long defaultTtlSec;

    private CachePolicy(String staleReadPolicy, long defaultTtlSec) {
        this.staleReadPolicy = staleReadPolicy;
        this.defaultTtlSec = defaultTtlSec;
    }

    public static CachePolicy load(Path policyPath) throws IOException {
        String body = Files.readString(policyPath);
        Matcher stale = STALE.matcher(body);
        Matcher ttl = TTL.matcher(body);
        String policy = stale.find() ? stale.group(1) : "reject";
        long ttlSec = ttl.find() ? Long.parseLong(ttl.group(1)) : 86400L;
        return new CachePolicy(policy, ttlSec);
    }

    public boolean allowEntry(long expiresAt, long nowMillis) {
        if (expiresAt <= nowMillis) {
            return false;
        }
        return !"reject".equalsIgnoreCase(staleReadPolicy) || expiresAt > nowMillis;
    }

    public long defaultTtlSec() {
        return defaultTtlSec;
    }
}
JAVA

log "tighten live cache policy to reject stale entries"
sed -i 's/"stale_read_policy": "serve_anyway"/"stale_read_policy": "reject"/' /app/config/live_cache_policy.json
assert_grep /app/config/live_cache_policy.json '"stale_read_policy": "reject"'

log "patch online day folding to UTC to match offline replay"
sed -i 's/ZoneId.of("America\/New_York")/ZoneId.of("UTC")/' "$TB"
assert_grep "$TB" 'ONLINE_ZONE = ZoneId.of\("UTC"\)'

log "enforce live cache expiry against clock.anchor via CachePolicy"
perl -0pi -e 's/public final class LiveStore \{/public final class LiveStore {\n    private final CachePolicy policy;\n/s' "$LS"
perl -0pi -e 's/public LiveStore\(Path jsonPath\) throws IOException \{/public LiveStore(Path jsonPath, Path policyPath) throws IOException {\n        this.policy = CachePolicy.load(policyPath);\n/s' "$LS"
perl -0pi -e 's/if \(entry == null\) \{\n            return null;\n        \}\n        return new FeatureRow/if (entry == null) {\n            return null;\n        }\n        if (!policy.allowEntry(entry.expiresAt(), nowMillis)) {\n            return null;\n        }\n        return new FeatureRow/s' "$LS"
sed -i 's/new LiveStore(liveJson);/new LiveStore(liveJson, Path.of("\/app\/config\/live_cache_policy.json"));/' "$OS"
assert_grep "$LS" 'policy.allowEntry'
assert_grep "$OS" 'live_cache_policy.json'

log "route online categorical indices through the vocab table"
perl -0pi -e 's/public int onlineIndex\(String category\) \{\n        int size = Math.max\(1, category.length\(\)\);\n        return Math.floorMod\(category.hashCode\(\), size \+ 4\);\n    \}/public int onlineIndex(String category) {\n        return vocab.indexFor(category);\n    }/s' "$CI"
assert_grep "$CI" 'vocab.indexFor\(category\)'

MS="/app/fsvc/src/main/java/com/ml/fs/ManifestScaler.java"
SM="/app/fsvc/src/main/java/com/ml/fs/ScoreModel.java"
log "apply registry category scales on the online serving path"
perl -0pi -e 's/public double forOnline\(double numeric, String category\) \{\n        return numeric;\n    \}/public double forOnline(double numeric, String category) {\n        return forOffline(numeric, category);\n    }/s' "$MS"
assert_grep "$MS" 'return forOffline'

log "use the stable euler logistic head for serving scores"
perl -0pi -e 's/this\.model = ScoreModel\.servingHead\(cfg\);/this.model = ScoreModel.fromConfig(cfg);/s' "$OS"
assert_grep "$OS" 'ScoreModel.fromConfig'
assert_grep "$SM" 'stableHead'

log "use offline day key and reject live rows that disagree with the offline join"
perl -0pi -e 's/public double scoreEntity\(String entityId, String eventTs\) \{\n        FeatureRow row = liveStore\.fetch\(entityId, anchorMillis\);\n        if \(row == null\) \{\n            String dayKey = TimeBucket\.onlineDayKey\(eventTs\);\n            row = join\.offlineLookup\(entityId, dayKey\);\n        \}\n        if \(row == null\) \{\n            throw new IllegalStateException\("missing online features for " \+ entityId\);\n        \}\n        double numeric = scaler\.forOnline\(row\.numeric\(\), row\.category\(\)\);\n        int catIdx = catIndex\.onlineIndex\(row\.category\(\)\);\n        return model\.score\(numeric, catIdx\);\n    \}/public double scoreEntity(String entityId, String eventTs) {\n        String dayKey = TimeBucket.offlineDayKey(eventTs);\n        FeatureRow offlineRow = join.offlineLookup(entityId, dayKey);\n        FeatureRow liveRow = liveStore.fetch(entityId, anchorMillis);\n        FeatureRow row = offlineRow;\n        if (liveRow != null && offlineRow != null\n                && liveRow.numeric() == offlineRow.numeric()\n                && liveRow.category().equals(offlineRow.category())) {\n            row = liveRow;\n        }\n        if (row == null) {\n            throw new IllegalStateException("missing online features for " + entityId);\n        }\n        double numeric = scaler.forOnline(row.numeric(), row.category());\n        int catIdx = catIndex.onlineIndex(row.category());\n        return model.score(numeric, catIdx);\n    }/s' "$OS"
assert_grep "$OS" 'liveRow.numeric\(\) == offlineRow.numeric\(\)'

log "rebuild jar and refresh bin symlink"
cd /app
mvn -q -f /app/pom.xml -DskipTests package
install -m 0644 /app/target/fsvc.jar /app/bin/fsvc.jar
test -s /app/bin/fsvc.jar

log "smoke: probe writes non-empty parity report"
/app/tools/parity_probe
require_file /app/output/parity_report.json
python3 - <<'PY'
import json
from pathlib import Path

report = json.loads(Path("/app/output/parity_report.json").read_text())
entities = report["entities"]
summary = report["summary"]
if not entities:
    raise SystemExit("empty entities")
if summary["aligned_count"] != summary["total"]:
    raise SystemExit("not fully aligned")
if summary["max_abs_delta"] > 1e-6:
    raise SystemExit("delta too large")
for row in entities:
    if row["offline_score"] != row["online_score"]:
        raise SystemExit(f"mismatch on {row['entity_id']}")
PY

log "regression: stale entities fall back to offline table rows"
python3 - <<'PY'
import json
import re
from pathlib import Path

anchor = int(Path("/app/config/clock.anchor").read_text().strip())
live = Path("/app/cache/live_feature_store.json").read_text()
for entity in ("ent_beta", "ent_zeta"):
    m = re.search(
        rf'"{entity}"\s*:\s*\{{[^}}]*"expires_at"\s*:\s*(\d+)',
        live,
    )
    if not m:
        raise SystemExit(f"missing live entry for {entity}")
    if int(m.group(1)) > anchor:
        raise SystemExit(f"{entity} should be expired in lab cache")
PY

log "oracle complete"
