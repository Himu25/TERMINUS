CREATE TABLE entity_day_features (
  entity_id TEXT NOT NULL,
  day_key TEXT NOT NULL,
  numeric_value DOUBLE PRECISION,
  category_label TEXT,
  PRIMARY KEY (entity_id, day_key)
);
