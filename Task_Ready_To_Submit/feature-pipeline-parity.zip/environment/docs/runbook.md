# Runbook

## Symptom

Offline replay and online serving disagree on fraud scores for the same entity and event time.

## Checks

1. Compare day keys produced for the same ISO timestamp on both paths.
2. Inspect whether expired live entries are still returned.
3. Confirm categorical indices match the vocab table, not ad-hoc hashing.
4. When live is still fresh, confirm its numeric and category match the warehouse join for the scored entity-day before the overlay can drive online scoring.

## Probe

```
/app/tools/parity_probe
cat /app/output/parity_report.json
```

Passing runs show `aligned` true for every entity and `max_abs_delta` at zero.
