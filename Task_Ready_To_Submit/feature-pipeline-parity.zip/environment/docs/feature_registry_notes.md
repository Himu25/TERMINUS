Entity-day features are authoritative in the offline table. Live cache is a latency overlay with TTL governed by `live_cache_policy.json`; an overlay that disagrees with the warehouse join on numeric or category for that entity-day must not change online scores.

Per-category numeric multipliers live beside the join manifest under `/app/registry/`. Both replay and serving are expected to apply them before the logistic head configured in the training and serving property files.
