# Feature serving layout

Batch replay materializes entity-day rows from the warehouse export at `/app/data/offline_feature_table.tsv`. Event timestamps are folded into a day key before the join.

Live serving reads `/app/cache/live_feature_store.json` as a stand-in for Redis. Each entry carries `expires_at` compared to `/app/config/clock.anchor`. Overlay selection keeps the warehouse join unless a fresh entry matches it on numeric and category for the entity-day under score.

Scoring uses a shared logistic head configured in `/app/config/training.properties` and `/app/config/serving.properties`. Category indices come from `/app/data/category_vocab.tsv`. Numeric calibration multipliers are loaded from the registry manifest pair referenced by `join_manifest.json`.

The parity harness is `/app/tools/parity_probe`, backed by `/app/bin/fsvc.jar`.
