package com.ml.fs;

public record FeatureRow(String entityId, double numeric, String category) {}
