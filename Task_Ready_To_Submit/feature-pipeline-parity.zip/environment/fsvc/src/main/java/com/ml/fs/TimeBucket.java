package com.ml.fs;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public final class TimeBucket {
    private static final ZoneId OFFLINE_ZONE = ZoneId.of("UTC");
    private static final ZoneId ONLINE_ZONE = ZoneId.of("America/New_York");
    private static final DateTimeFormatter KEY_FMT = DateTimeFormatter.ofPattern("yyyyMMdd");

    private TimeBucket() {}

    public static String offlineDayKey(String eventTs) {
        Instant instant = Instant.parse(eventTs);
        ZonedDateTime zdt = instant.atZone(OFFLINE_ZONE);
        return zdt.format(KEY_FMT);
    }

    public static String onlineDayKey(String eventTs) {
        Instant instant = Instant.parse(eventTs);
        ZonedDateTime zdt = instant.atZone(ONLINE_ZONE);
        return zdt.format(KEY_FMT);
    }
}
