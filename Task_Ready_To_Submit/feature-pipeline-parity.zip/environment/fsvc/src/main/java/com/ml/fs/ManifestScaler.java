package com.ml.fs;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ManifestScaler {
    private static final Pattern ENTRY =
            Pattern.compile("\"([^\"]+)\"\\s*:\\s*([0-9.]+)");

    private final Map<String, Double> scales;
    private final double defaultScale;

    private ManifestScaler(Map<String, Double> scales, double defaultScale) {
        this.scales = scales;
        this.defaultScale = defaultScale;
    }

    public static ManifestScaler load(Path path) throws IOException {
        String body = Files.readString(path);
        Map<String, Double> map = new HashMap<>();
        Matcher matcher = ENTRY.matcher(body);
        while (matcher.find()) {
            map.put(matcher.group(1), Double.parseDouble(matcher.group(2)));
        }
        double fallback = map.getOrDefault("default", 1.0);
        return new ManifestScaler(map, fallback);
    }

    public double scaleFor(String category) {
        return scales.getOrDefault(category, defaultScale);
    }

    public double forOffline(double numeric, String category) {
        return numeric * scaleFor(category);
    }

    public double forOnline(double numeric, String category) {
        return numeric;
    }
}
