package com.ml.fs;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public final class JsonSink {
    private JsonSink() {}

    public record EntityScore(
            String entityId, double offlineScore, double onlineScore, boolean aligned) {}

    public record Summary(int total, int alignedCount, double maxAbsDelta) {}

    public static void writeReport(Path out, List<EntityScore> rows, Summary summary) throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append("{\"entities\":[");
        for (int i = 0; i < rows.size(); i++) {
            EntityScore row = rows.get(i);
            if (i > 0) {
                sb.append(',');
            }
            sb.append("{\"entity_id\":\"")
                    .append(escape(row.entityId()))
                    .append("\",\"offline_score\":")
                    .append(format(row.offlineScore()))
                    .append(",\"online_score\":")
                    .append(format(row.onlineScore()))
                    .append(",\"aligned\":")
                    .append(row.aligned() ? "true" : "false")
                    .append('}');
        }
        sb.append("],\"summary\":{\"total\":")
                .append(summary.total())
                .append(",\"aligned_count\":")
                .append(summary.alignedCount())
                .append(",\"max_abs_delta\":")
                .append(format(summary.maxAbsDelta()))
                .append("}}");
        Files.writeString(out, sb.toString());
    }

    private static String format(double value) {
        return String.format(java.util.Locale.US, "%.6f", value);
    }

    private static String escape(String text) {
        return text.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
