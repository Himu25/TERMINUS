package com.ml.fs;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public final class ConfigLoader {
    private ConfigLoader() {}

    public static Map<String, String> loadProps(Path path) throws IOException {
        Properties props = new Properties();
        try (var in = Files.newInputStream(path)) {
            props.load(in);
        }
        Map<String, String> out = new HashMap<>();
        for (String name : props.stringPropertyNames()) {
            out.put(name, props.getProperty(name));
        }
        return out;
    }

    public static long readAnchorMillis(Path path) throws IOException {
        String raw = Files.readString(path).trim();
        return Long.parseLong(raw);
    }
}
