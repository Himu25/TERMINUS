package com.ml.fs;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public final class VocabTable {
    private final Map<String, Integer> categoryToIndex;

    private VocabTable(Map<String, Integer> categoryToIndex) {
        this.categoryToIndex = categoryToIndex;
    }

    public static VocabTable load(Path path) throws IOException {
        Map<String, Integer> map = new HashMap<>();
        for (String line : Files.readAllLines(path)) {
            String trimmed = line.trim();
            if (trimmed.isEmpty() || trimmed.startsWith("#") || trimmed.startsWith("category")) {
                continue;
            }
            String[] parts = trimmed.split("\t");
            if (parts.length >= 2) {
                map.put(parts[0].trim(), Integer.parseInt(parts[1].trim()));
            }
        }
        return new VocabTable(map);
    }

    public int indexFor(String category) {
        return categoryToIndex.getOrDefault(category, categoryToIndex.getOrDefault("unknown", 0));
    }
}
