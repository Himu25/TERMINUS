package com.ml.fs;

public final class ScoreModel {
    private final double bias;
    private final double numericWeight;
    private final double categoryWeight;
    private final double euler;
    private final boolean stableHead;

    public ScoreModel(
            double bias,
            double numericWeight,
            double categoryWeight,
            double euler,
            boolean stableHead) {
        this.bias = bias;
        this.numericWeight = numericWeight;
        this.categoryWeight = categoryWeight;
        this.euler = euler;
        this.stableHead = stableHead;
    }

    public static ScoreModel fromConfig(java.util.Map<String, String> cfg) {
        return new ScoreModel(
                Double.parseDouble(cfg.get("score.bias")),
                Double.parseDouble(cfg.get("score.numeric.weight")),
                Double.parseDouble(cfg.get("score.category.weight")),
                Double.parseDouble(cfg.get("score.euler")),
                true);
    }

    public static ScoreModel servingHead(java.util.Map<String, String> cfg) {
        return new ScoreModel(
                Double.parseDouble(cfg.get("score.bias")),
                Double.parseDouble(cfg.get("score.numeric.weight")),
                Double.parseDouble(cfg.get("score.category.weight")),
                Math.E,
                false);
    }

    public double score(double numeric, int categoryIndex) {
        double logit = bias + numericWeight * numeric + categoryWeight * categoryIndex;
        double raw;
        if (stableHead) {
            if (logit >= 0.0) {
                double z = Math.pow(euler, -logit);
                raw = 1.0 / (1.0 + z);
            } else {
                double z = Math.pow(euler, logit);
                raw = z / (1.0 + z);
            }
        } else {
            raw = 1.0 / (1.0 + Math.exp(-logit));
        }
        return Math.round(raw * 1_000_000.0) / 1_000_000.0;
    }
}
