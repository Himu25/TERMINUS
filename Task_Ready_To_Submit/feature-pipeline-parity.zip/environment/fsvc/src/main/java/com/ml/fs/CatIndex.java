package com.ml.fs;

public final class CatIndex {
    private final VocabTable vocab;

    public CatIndex(VocabTable vocab) {
        this.vocab = vocab;
    }

    public int offlineIndex(String category) {
        return vocab.indexFor(category);
    }

    public int onlineIndex(String category) {
        int size = Math.max(1, category.length());
        return Math.floorMod(category.hashCode(), size + 4);
    }
}
