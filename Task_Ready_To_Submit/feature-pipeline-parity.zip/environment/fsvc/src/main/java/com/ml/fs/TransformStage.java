package com.ml.fs;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public final class TransformStage {
    private TransformStage() {}

    public static double applyChain(double numeric, List<String> chain) {
        double out = numeric;
        for (String stage : chain) {
            out = switch (stage) {
                case "day_bucket" -> out;
                case "category_index" -> out;
                case "logistic_score" -> out;
                default -> out;
            };
        }
        return out;
    }

    public static List<String> readChain(Path registryPath) throws IOException {
        String body = Files.readString(registryPath).trim();
        if (body.startsWith("[")) {
            return List.of(body.replace("[", "").replace("]", "").replace("\"", "").split(",\\s*"));
        }
        return List.of();
    }
}
