package com.ml.fs;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public final class FeatureJoin {
    private final Map<String, FeatureRow> offlineByKey = new HashMap<>();

    public FeatureJoin(Path tablePath) throws IOException {
        for (String line : Files.readAllLines(tablePath)) {
            String trimmed = line.trim();
            if (trimmed.isEmpty() || trimmed.startsWith("#") || trimmed.startsWith("entity_id")) {
                continue;
            }
            String[] parts = trimmed.split("\t");
            if (parts.length < 4) {
                continue;
            }
            String entity = parts[0].trim();
            String day = parts[1].trim();
            double numeric = Double.parseDouble(parts[2].trim());
            String category = parts[3].trim();
            offlineByKey.put(entity + "|" + day, new FeatureRow(entity, numeric, category));
        }
    }

    public FeatureRow offlineLookup(String entityId, String dayKey) {
        return offlineByKey.get(entityId + "|" + dayKey);
    }
}
