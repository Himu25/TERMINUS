package com.ml.fs;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Map;

public final class OnlineServing {
    private final LiveStore liveStore;
    private final FeatureJoin join;
    private final CatIndex catIndex;
    private final ScoreModel model;
    private final ManifestScaler scaler;
    private final long anchorMillis;

    public OnlineServing(
            Path servingProps,
            Path liveJson,
            Path tablePath,
            Path vocabPath,
            Path anchorPath,
            Path scaleManifest)
            throws IOException {
        Map<String, String> cfg = ConfigLoader.loadProps(servingProps);
        this.liveStore = new LiveStore(liveJson);
        this.join = new FeatureJoin(tablePath);
        this.catIndex = new CatIndex(VocabTable.load(vocabPath));
        this.model = ScoreModel.servingHead(cfg);
        this.scaler = ManifestScaler.load(scaleManifest);
        this.anchorMillis = ConfigLoader.readAnchorMillis(anchorPath);
    }

    public double scoreEntity(String entityId, String eventTs) {
        FeatureRow row = liveStore.fetch(entityId, anchorMillis);
        if (row == null) {
            String dayKey = TimeBucket.onlineDayKey(eventTs);
            row = join.offlineLookup(entityId, dayKey);
        }
        if (row == null) {
            throw new IllegalStateException("missing online features for " + entityId);
        }
        double numeric = scaler.forOnline(row.numeric(), row.category());
        int catIdx = catIndex.onlineIndex(row.category());
        return model.score(numeric, catIdx);
    }
}
