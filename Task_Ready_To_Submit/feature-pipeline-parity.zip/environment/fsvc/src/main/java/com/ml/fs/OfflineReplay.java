package com.ml.fs;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Map;

public final class OfflineReplay {
    private final FeatureJoin join;
    private final CatIndex catIndex;
    private final ScoreModel model;
    private final ManifestScaler scaler;

    public OfflineReplay(
            Path trainingProps,
            Path tablePath,
            Path vocabPath,
            Path scaleManifest)
            throws IOException {
        Map<String, String> cfg = ConfigLoader.loadProps(trainingProps);
        this.join = new FeatureJoin(tablePath);
        this.catIndex = new CatIndex(VocabTable.load(vocabPath));
        this.model = ScoreModel.fromConfig(cfg);
        this.scaler = ManifestScaler.load(scaleManifest);
    }

    public double scoreEntity(String entityId, String eventTs) {
        String dayKey = TimeBucket.offlineDayKey(eventTs);
        FeatureRow row = join.offlineLookup(entityId, dayKey);
        if (row == null) {
            throw new IllegalStateException("missing offline row for " + entityId + " day " + dayKey);
        }
        double numeric = scaler.forOffline(row.numeric(), row.category());
        int catIdx = catIndex.offlineIndex(row.category());
        return model.score(numeric, catIdx);
    }
}
