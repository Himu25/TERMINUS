package com.ml.fs;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class LiveStore {
    private static final Pattern ENTRY =
            Pattern.compile(
                    "\"([a-z_]+)\"\\s*:\\s*\\{\\s*\"numeric\"\\s*:\\s*([-\\d.]+),\\s*\"category\"\\s*:\\s*\"([^\"]+)\",\\s*\"expires_at\"\\s*:\\s*(\\d+)");

    private final Map<String, LiveEntry> entries = new HashMap<>();

    public record LiveEntry(double numeric, String category, long expiresAt) {}

    public LiveStore(Path jsonPath) throws IOException {
        String body = Files.readString(jsonPath);
        Matcher matcher = ENTRY.matcher(body);
        while (matcher.find()) {
            entries.put(
                    matcher.group(1),
                    new LiveEntry(
                            Double.parseDouble(matcher.group(2)),
                            matcher.group(3),
                            Long.parseLong(matcher.group(4))));
        }
    }

    public FeatureRow fetch(String entityId, long nowMillis) {
        LiveEntry entry = entries.get(entityId);
        if (entry == null) {
            return null;
        }
        return new FeatureRow(entityId, entry.numeric(), entry.category());
    }
}
