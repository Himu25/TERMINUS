package com.ml.fs;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ParityProbe {
    private static final Pattern ROW =
            Pattern.compile(
                    "\\{\\s*\"entity_id\"\\s*:\\s*\"([^\"]+)\"\\s*,\\s*\"event_ts\"\\s*:\\s*\"([^\"]+)\"\\s*\\}");

    public static void main(String[] args) throws Exception {
        Path batch = Path.of("/app/data/scoring_batch.json");
        if (args.length > 0) {
            batch = Path.of(args[0]);
        }
        Path out = Path.of("/app/output/parity_report.json");
        run(batch, out);
    }

    static void run(Path batchPath, Path outPath) throws IOException {
        Path scaleManifest = Path.of("/app/registry/category_scales.json");
        OfflineReplay offline =
                new OfflineReplay(
                        Path.of("/app/config/training.properties"),
                        Path.of("/app/data/offline_feature_table.tsv"),
                        Path.of("/app/data/category_vocab.tsv"),
                        scaleManifest);
        OnlineServing online =
                new OnlineServing(
                        Path.of("/app/config/serving.properties"),
                        Path.of("/app/cache/live_feature_store.json"),
                        Path.of("/app/data/offline_feature_table.tsv"),
                        Path.of("/app/data/category_vocab.tsv"),
                        Path.of("/app/config/clock.anchor"),
                        scaleManifest);

        String batchBody = java.nio.file.Files.readString(batchPath);
        Matcher matcher = ROW.matcher(batchBody);
        List<JsonSink.EntityScore> rows = new ArrayList<>();
        double maxDelta = 0.0;
        int alignedCount = 0;
        while (matcher.find()) {
            String entityId = matcher.group(1);
            String eventTs = matcher.group(2);
            double off = offline.scoreEntity(entityId, eventTs);
            double on = online.scoreEntity(entityId, eventTs);
            double delta = Math.abs(off - on);
            boolean aligned = delta <= 1e-6;
            if (aligned) {
                alignedCount++;
            }
            maxDelta = Math.max(maxDelta, delta);
            rows.add(new JsonSink.EntityScore(entityId, off, on, aligned));
        }
        if (rows.isEmpty()) {
            throw new IllegalStateException("no scoring rows in " + batchPath);
        }
        JsonSink.writeReport(
                outPath,
                rows,
                new JsonSink.Summary(rows.size(), alignedCount, maxDelta));
    }
}
