Maven project root is /app. Sources live under /app/fsvc/src/main/java.
