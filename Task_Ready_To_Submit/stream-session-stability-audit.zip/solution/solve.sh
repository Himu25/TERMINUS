#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/usr/bin:${PATH}"
cd /app

python3 <<'PY'
from pathlib import Path

op_w = Path("/app/internal/cable/op_w.go")
text = op_w.read_text()
old = (
    "func OpW(t *TapeM, a string, b string) int {\n"
    "\tt.seq++\n"
    "\tline := fmt.Sprintf(\"%d:%s:%s\", t.seq, a, b)\n"
    "\tt.lines = append(t.lines, line)\n"
    "\treturn t.seq\n"
    "}"
)
new = (
    "func OpW(t *TapeM, a string, b string) int {\n"
    "\tt.mu.Lock()\n"
    "\tdefer t.mu.Unlock()\n"
    "\tt.seq++\n"
    "\tline := fmt.Sprintf(\"%d:%s:%s\", t.seq, a, b)\n"
    "\tt.lines = append(t.lines, line)\n"
    "\treturn t.seq\n"
    "}"
)
if old not in text:
    raise SystemExit("op_w anchor missing")
op_w.write_text(text.replace(old, new, 1))
PY

cat > /app/internal/cable/open.go <<'EOF'
package cable

import "sessiond/pkg/api"

func BootHk(t *TapeM, sc *api.ScenarioFile) {
	OpW(t, tagHk, sc.Name)
	if sc.PulseEvery > 0 {
		OpK(t, "init")
	}
}
EOF

cat > /app/internal/cable/op_k.go <<'EOF'
package cable

func OpK(t *TapeM, a string) {
	OpW(t, tagKa, a)
}
EOF

cat > /app/internal/cable/op_p.go <<'EOF'
package cable

func OpP(t *TapeM, a string) {
	OpW(t, tagPo, a)
}
EOF

cat > /app/shard/src/seal.rs <<'EOF'
use sha2::{Digest, Sha256};

fn seq_key(line: &str) -> u64 {
    line.split(':')
        .next()
        .and_then(|s| s.parse::<u64>().ok())
        .unwrap_or(u64::MAX)
}

fn normalize_line(line: &str) -> String {
    let parts: Vec<&str> = line.splitn(3, ':').collect();
    if parts.len() != 3 {
        return String::new();
    }
    format!("{}:{}:{}", parts[0], parts[1], parts[2])
}

fn non_empty(line: &str) -> bool {
    !line.trim().is_empty()
}

fn ordered_body(lines: &[String]) -> String {
    let mut ordered: Vec<String> = lines
        .iter()
        .map(|line| normalize_line(line))
        .filter(|line| non_empty(line))
        .collect();
    ordered.sort_by_key(|line| seq_key(line));
    ordered.join("\n")
}

pub fn fold_b(lines: &[String]) -> String {
    let body = ordered_body(lines);
    let mut hasher = Sha256::new();
    hasher.update(body.as_bytes());
    format!("{:x}", hasher.finalize())
}
EOF

bash /app/scripts/build.sh
bash /app/ops/preflight.sh
bash /app/ops/run_stability_audit.sh

test -s /app/output/session_stability.json
