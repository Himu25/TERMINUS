"""Verifier for /app/output/session_stability.json."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
REPORT = APP / "output" / "session_stability.json"
SCENARIOS = APP / "fixtures" / "scenarios"
STEADY = APP / "data" / "steady" / "steady_counts.json"


def _env() -> dict[str, str]:
    return os.environ.copy()


def rebuild_binaries() -> None:
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", check=True, env=_env())


def run_audit(extra: dict[str, str] | None = None) -> None:
    env = _env()
    if extra:
        env.update(extra)
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ["bash", "/app/ops/run_stability_audit.sh"],
        cwd="/app",
        check=True,
        env=env,
    )


def _scenario(report: dict, name: str) -> dict:
    for row in report["scenarios"]:
        if row["name"] == name:
            return row
    raise AssertionError(f"missing scenario {name!r}")


def _load_scenario(name: str) -> dict:
    return json.loads((SCENARIOS / f"{name}.json").read_text())


def _reference_counts(scenario: dict) -> dict:
    ticks = sorted(scenario["ticks"], key=lambda t: t["at_ms"])
    pulse = 2 if scenario["pulse_every_ms"] > 0 else 0
    payload = sum(1 for t in ticks if t["kind"] == "data")
    return {
        "pulse_count": pulse,
        "payload_count": payload,
        "torn_frame_proxy": 0,
        "init_pulse_ok": scenario["pulse_every_ms"] > 0,
        "finish_reason": "complete",
    }


def _reference_digest(scenario: dict) -> str:
    sc = scenario
    lines: list[str] = []
    seq = 0

    def emit(tag: str, body: str) -> None:
        nonlocal seq
        seq += 1
        lines.append(f"{seq}:{tag}:{body}")

    emit("hk", sc["name"])
    if sc["pulse_every_ms"] > 0:
        emit("ka", "init")
    for tick in sorted(sc["ticks"], key=lambda t: t["at_ms"]):
        if tick["kind"] == "pulse":
            emit("ka", tick["id"])
        elif tick["kind"] == "pong":
            emit("po", tick["id"])
        elif tick["kind"] == "data":
            emit("pl", json.dumps(tick["payload"], separators=(",", ":"), sort_keys=True))
        elif tick["kind"] == "close":
            emit("x", tick["id"])

    def seq_key(line: str) -> int:
        head = line.split(":", 1)[0]
        return int(head) if head.isdigit() else 10**9

    ordered = sorted(lines, key=seq_key)
    body = "\n".join(ordered)
    proc = subprocess.run(
        ["openssl", "dgst", "-sha256", "-hex"],
        input=body,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.strip().split()[-1].lower()


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    rebuild_binaries()


@pytest.fixture()
def report() -> dict:
    run_audit()
    return json.loads(REPORT.read_text())


def test_report_schema(report: dict) -> None:
    """session_stability.json matches the published contract."""
    assert isinstance(report, dict)
    assert isinstance(report["scenarios"], list)
    assert len(report["scenarios"]) == 3
    for row in report["scenarios"]:
        for key in (
            "name",
            "finish_reason",
            "pulse_count",
            "payload_count",
            "torn_frame_proxy",
            "transcript_digest_hex",
            "init_pulse_ok",
        ):
            assert key in row


def test_burst_ping_stable(report: dict) -> None:
    """burst_ping finishes complete with steady counts."""
    row = _scenario(report, "burst_ping")
    exp = _reference_counts(_load_scenario("burst_ping"))
    assert row["finish_reason"] == exp["finish_reason"]
    assert row["pulse_count"] == exp["pulse_count"]
    assert row["payload_count"] == exp["payload_count"]
    assert row["torn_frame_proxy"] == exp["torn_frame_proxy"]
    assert row["init_pulse_ok"] is exp["init_pulse_ok"]
    assert row["transcript_digest_hex"] == _reference_digest(_load_scenario("burst_ping"))


def test_dual_lane_order(report: dict) -> None:
    """dual_lane keeps pulse and payload counts aligned with steady pack."""
    row = _scenario(report, "dual_lane")
    exp = _reference_counts(_load_scenario("dual_lane"))
    assert row["finish_reason"] == exp["finish_reason"]
    assert row["pulse_count"] == exp["pulse_count"]
    assert row["payload_count"] == exp["payload_count"]
    assert row["init_pulse_ok"] is True
    assert row["transcript_digest_hex"] == _reference_digest(_load_scenario("dual_lane"))


def test_slow_drain_complete(report: dict) -> None:
    """slow_drain reaches complete with one payload and two pulses."""
    row = _scenario(report, "slow_drain")
    exp = _reference_counts(_load_scenario("slow_drain"))
    assert row["finish_reason"] == exp["finish_reason"]
    assert row["payload_count"] == exp["payload_count"]
    assert row["pulse_count"] == exp["pulse_count"]


def test_init_pulse_present(report: dict) -> None:
    """Every fixture records init_pulse_ok true when pulse interval is configured."""
    for name in ("burst_ping", "dual_lane", "slow_drain"):
        assert _scenario(report, name)["init_pulse_ok"] is True


def test_torn_frames_zero(report: dict) -> None:
    """torn_frame_proxy stays zero on all fixtures."""
    for row in report["scenarios"]:
        assert row["torn_frame_proxy"] == 0


def test_race_detector_clean() -> None:
    """preflight script passes race-detector unit tests for the lane driver."""
    proc = subprocess.run(
        ["bash", "/app/ops/preflight.sh"],
        cwd="/app",
        env=_env(),
        capture_output=True,
        text=True,
    )
    assert proc.returncode == 0, proc.stdout + proc.stderr


def test_unsafe_fastpath_invariant() -> None:
    """SESSION_UNSAFE_FASTPATH=1 leaves transcript_digest_hex unchanged."""
    run_audit()
    base = json.loads(REPORT.read_text())
    run_audit({"SESSION_UNSAFE_FASTPATH": "1"})
    fast = json.loads(REPORT.read_text())
    for name in ("burst_ping", "dual_lane", "slow_drain"):
        b = _scenario(base, name)["transcript_digest_hex"]
        f = _scenario(fast, name)["transcript_digest_hex"]
        assert b == f


def test_steady_baseline_alignment(report: dict) -> None:
    """Counts and digests stay aligned with steady steady_counts expectations."""
    steady = json.loads(STEADY.read_text())
    for name, exp in steady.items():
        row = _scenario(report, name)
        assert row["pulse_count"] == exp["pulse_count"]
        assert row["payload_count"] == exp["payload_count"]
        assert row["torn_frame_proxy"] == exp["torn_frame_proxy"]
        assert row["transcript_digest_hex"] == _reference_digest(_load_scenario(name))
