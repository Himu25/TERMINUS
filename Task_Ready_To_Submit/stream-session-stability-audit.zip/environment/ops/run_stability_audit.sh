#!/usr/bin/env bash
set -euo pipefail
export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
cd /app
bash /app/scripts/build.sh
/app/sessiond -scenarios /app/fixtures/scenarios -out /app/output/session_stability.json
