package config

import (
	"os"

	"gopkg.in/yaml.v3"
)

type Defaults struct {
	ShardBin string `yaml:"shard_bin"`
	MaxSkew     int    `yaml:"max_skew"`
}

func Load(path string) (*Defaults, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	cfg := &Defaults{
		ShardBin: "/app/bin/shard",
		MaxSkew:     0,
	}
	if err := yaml.Unmarshal(raw, cfg); err != nil {
		return nil, err
	}
	return cfg, nil
}
