package driver

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"sessiond/internal/config"
	"sessiond/internal/obs"
	"sessiond/internal/cable"
	"sessiond/pkg/api"
	"sessiond/spanfold"
)

type Orchestrator struct {
	cfg *config.Defaults
}

func NewOrchestrator(cfg *config.Defaults) *Orchestrator {
	return &Orchestrator{cfg: cfg}
}

func (o *Orchestrator) RunDir(dir string) (*api.AuditReport, error) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}
	names := make([]string, 0, len(entries))
	for _, e := range entries {
		if e.IsDir() || !strings.HasSuffix(e.Name(), ".json") {
			continue
		}
		names = append(names, e.Name())
	}
	sort.Strings(names)

	out := &api.AuditReport{Scenarios: make([]api.ScenarioOutcome, 0, len(names))}
	for _, name := range names {
		sc, err := loadScenario(filepath.Join(dir, name))
		if err != nil {
			return nil, err
		}
		row, err := o.RunScenario(sc)
		if err != nil {
			return nil, err
		}
		out.Scenarios = append(out.Scenarios, *row)
	}
	return out, nil
}

func loadScenario(path string) (*api.ScenarioFile, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var sc api.ScenarioFile
	if err := json.Unmarshal(raw, &sc); err != nil {
		return nil, err
	}
	return &sc, nil
}

func (o *Orchestrator) RunScenario(sc *api.ScenarioFile) (*api.ScenarioOutcome, error) {
	tape := cable.NewTapeM()
	lane := cable.NewLane(tape)
	obs.Note("replay " + sc.Name)
	lane.Replay(sc)

	digest, err := spanfold.Seal(o.cfg.ShardBin, tape.Lines())
	if err != nil {
		return &api.ScenarioOutcome{
			Name:         sc.Name,
			FinishReason: "seal_failed",
		}, err
	}

	skew := tape.SkewN()
	reason := "complete"
	if skew > o.cfg.MaxSkew {
		reason = "torn_lane"
	}
	if !tape.LeadOK() && sc.PulseEvery > 0 {
		reason = "handshake_gap"
	}

	return &api.ScenarioOutcome{
		Name:                sc.Name,
		FinishReason:        reason,
		PulseCount:          tape.TallyN(cable.TagKa()),
		PayloadCount:        tape.TallyN(cable.TagPl()),
		TornFrameProxy:      skew,
		TranscriptDigestHex: digest,
		InitPulseOK:         tape.LeadOK(),
	}, nil
}

func WriteReport(path string, report *api.AuditReport) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, raw, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}
