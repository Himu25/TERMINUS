package driver

import "sessiond/pkg/api"

func FinishReason(row *api.ScenarioOutcome) string {
	if row.TornFrameProxy > 0 {
		return "torn_lane"
	}
	if !row.InitPulseOK {
		return "handshake_gap"
	}
	return row.FinishReason
}
