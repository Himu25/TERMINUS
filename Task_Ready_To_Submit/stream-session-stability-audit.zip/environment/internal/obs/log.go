package obs

import "log"

func Note(msg string) {
	log.Printf("cable: %s", msg)
}
