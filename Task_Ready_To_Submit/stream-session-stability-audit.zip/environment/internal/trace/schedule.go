package trace

import "sessiond/pkg/api"

func OrderedTicks(sc *api.ScenarioFile) []api.Tick {
	out := make([]api.Tick, len(sc.Ticks))
	copy(out, sc.Ticks)
	for i := 0; i < len(out); i++ {
		for j := i + 1; j < len(out); j++ {
			if out[j].AtMS < out[i].AtMS {
				out[i], out[j] = out[j], out[i]
			}
		}
	}
	return out
}
