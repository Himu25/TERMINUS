package cable

import (
	"encoding/json"

	"sessiond/pkg/api"
)

func RunPl(t *TapeM, tick api.Tick) {
	raw, err := json.Marshal(tick.Payload)
	if err != nil {
		raw = []byte("{}")
	}
	OpW(t, tagPl, string(raw))
}
