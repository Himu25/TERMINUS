package cable

import "sessiond/pkg/api"

func RunKa(t *TapeM, tick api.Tick) {
	OpK(t, tick.ID)
}
