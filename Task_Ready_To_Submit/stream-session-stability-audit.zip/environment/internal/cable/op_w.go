package cable

import (
	"encoding/json"
	"fmt"
	"strings"
	"sync"
)

const (
	tagHk = "hk"
	tagKa = "ka"
	tagPo = "po"
	tagPl = "pl"
	tagX  = "x"
)

type TapeM struct {
	mu    sync.Mutex
	seq   int
	lines []string
}

func NewTapeM() *TapeM {
	return &TapeM{lines: make([]string, 0, 32)}
}

func (t *TapeM) Lines() []string {
	t.mu.Lock()
	defer t.mu.Unlock()
	out := make([]string, len(t.lines))
	copy(out, t.lines)
	return out
}

func (t *TapeM) SkewN() int {
	lines := t.Lines()
	skew := 0
	for _, line := range lines {
		parts := strings.SplitN(line, ":", 3)
		if len(parts) != 3 {
			skew++
			continue
		}
		if parts[1] == tagPl {
			var payload map[string]int
			if err := json.Unmarshal([]byte(parts[2]), &payload); err != nil {
				skew++
			}
		}
	}
	return skew
}

func (t *TapeM) TallyN(tag string) int {
	n := 0
	for _, line := range t.Lines() {
		parts := strings.SplitN(line, ":", 3)
		if len(parts) >= 2 && parts[1] == tag {
			n++
		}
	}
	return n
}

func (t *TapeM) LeadOK() bool {
	lines := t.Lines()
	if len(lines) < 2 {
		return false
	}
	parts := strings.SplitN(lines[1], ":", 3)
	return len(parts) >= 2 && parts[1] == tagKa
}

func TagKa() string { return tagKa }
func TagPl() string { return tagPl }
func TagPo() string { return tagPo }

func OpW(t *TapeM, a string, b string) int {
	t.seq++
	line := fmt.Sprintf("%d:%s:%s", t.seq, a, b)
	t.lines = append(t.lines, line)
	return t.seq
}
