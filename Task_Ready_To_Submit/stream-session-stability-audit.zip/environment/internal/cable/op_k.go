package cable

func OpK(t *TapeM, a string) {
	t.lines = append(t.lines, "ka:"+a)
}
