package cable

import "sync"

type Gate struct {
	mu     sync.Mutex
	closed bool
}

func NewGate() *Gate {
	return &Gate{}
}

func (g *Gate) Close() {
	g.mu.Lock()
	g.closed = true
	g.mu.Unlock()
}

func (g *Gate) IsClosed() bool {
	g.mu.Lock()
	defer g.mu.Unlock()
	return g.closed
}
