package cable

func OpP(t *TapeM, a string) {
	t.lines = append(t.lines, "po:"+a)
}
