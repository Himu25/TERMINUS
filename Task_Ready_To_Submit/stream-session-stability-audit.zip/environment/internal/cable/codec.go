package cable

import (
	"fmt"
	"strings"
)

func NormalizeTag(line string) (seq int, tag string, body string, ok bool) {
	parts := strings.SplitN(line, ":", 3)
	if len(parts) != 3 {
		return 0, "", "", false
	}
	var n int
	if _, err := fmt.Sscanf(parts[0], "%d", &n); err != nil {
		return 0, "", "", false
	}
	return n, parts[1], parts[2], true
}
