package cable

import "sessiond/pkg/api"

func RunPo(t *TapeM, tick api.Tick) {
	OpP(t, tick.ID)
}
