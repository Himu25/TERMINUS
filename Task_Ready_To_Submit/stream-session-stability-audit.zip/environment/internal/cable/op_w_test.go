package cable_test

import (
	"fmt"
	"sync"
	"testing"

	"sessiond/internal/cable"
)

func TestConcurrentEmit(t *testing.T) {
	tape := cable.NewTapeM()
	var wg sync.WaitGroup
	for i := 0; i < 32; i++ {
		wg.Add(2)
		n := i
		go func() {
			defer wg.Done()
			cable.OpK(tape, fmt.Sprintf("k%d", n))
		}()
		go func() {
			defer wg.Done()
			cable.OpW(tape, "pl", fmt.Sprintf(`{"n":%d}`, n))
		}()
	}
	wg.Wait()
	if tape.SkewN() > 0 {
		t.Fatalf("skew detected: %d", tape.SkewN())
	}
}
