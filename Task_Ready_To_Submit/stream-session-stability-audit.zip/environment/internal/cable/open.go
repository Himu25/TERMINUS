package cable

import (
	"os"

	"sessiond/pkg/api"
)

func BootHk(t *TapeM, sc *api.ScenarioFile) {
	OpW(t, tagHk, sc.Name)
	if sc.PulseEvery > 0 {
		if os.Getenv("SESSION_UNSAFE_FASTPATH") == "1" {
			OpK(t, "init")
			return
		}
		go func() {
			OpK(t, "init")
		}()
	}
}
