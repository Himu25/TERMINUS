package cable

import (
	"sessiond/internal/trace"
	"sessiond/pkg/api"
)

type Lane struct {
	tape *TapeM
	gate *Gate
}

func NewLane(tape *TapeM) *Lane {
	return &Lane{tape: tape, gate: NewGate()}
}

func (l *Lane) Replay(sc *api.ScenarioFile) {
	BootHk(l.tape, sc)

	for _, tick := range trace.OrderedTicks(sc) {
		switch tick.Kind {
		case "pulse":
			RunKa(l.tape, tick)
		case "pong":
			RunPo(l.tape, tick)
		case "data":
			RunPl(l.tape, tick)
		case "close":
			l.gate.Close()
			OpW(l.tape, tagX, tick.ID)
		}
	}
}
