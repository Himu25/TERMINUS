mod lane;
mod seal;

use serde::{Deserialize, Serialize};
use std::io::{self, Read};

#[derive(Debug, Deserialize)]
struct SealRequest {
    lines: Vec<String>,
}

#[derive(Debug, Serialize)]
struct SealResponse {
    digest_hex: String,
}

fn main() {
    let mut args = std::env::args();
    let _ = args.next();
    let cmd = args.next().unwrap_or_default();
    match cmd.as_str() {
        "seal" => run_seal(),
        _ => {
            eprintln!("usage: shard seal");
            std::process::exit(2);
        }
    }
}

fn run_seal() {
    let mut buf = String::new();
    if io::stdin().read_to_string(&mut buf).is_err() {
        std::process::exit(1);
    }
    let req: SealRequest = match serde_json::from_str(&buf) {
        Ok(v) => v,
        Err(_) => std::process::exit(1),
    };
    let digest = seal::fold_b(&req.lines);
    let resp = SealResponse { digest_hex: digest };
    println!("{}", serde_json::to_string(&resp).unwrap_or_default());
}
