use sha2::{Digest, Sha256};

pub fn fold_b(lines: &[String]) -> String {
    let body = lines.join("\n");
    let mut hasher = Sha256::new();
    hasher.update(body.as_bytes());
    format!("{:x}", hasher.finalize())
}
