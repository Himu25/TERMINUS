/// lane tally helper for byte accounting dashboards
pub fn lane_tally(lines: &[String]) -> usize {
    lines.iter().map(|l| l.len()).sum()
}
