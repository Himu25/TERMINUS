package api

type Tick struct {
	AtMS    int               `json:"at_ms"`
	Kind    string            `json:"kind"`
	ID      string            `json:"id,omitempty"`
	Payload map[string]int    `json:"payload,omitempty"`
}

type ScenarioFile struct {
	Name        string `json:"name"`
	PulseEvery  int    `json:"pulse_every_ms"`
	ExpectPong  bool   `json:"expect_pong"`
	Ticks       []Tick `json:"ticks"`
}

type ScenarioOutcome struct {
	Name                 string `json:"name"`
	FinishReason         string `json:"finish_reason"`
	PulseCount           int    `json:"pulse_count"`
	PayloadCount         int    `json:"payload_count"`
	TornFrameProxy       int    `json:"torn_frame_proxy"`
	TranscriptDigestHex  string `json:"transcript_digest_hex"`
	InitPulseOK          bool   `json:"init_pulse_ok"`
}

type AuditReport struct {
	Scenarios []ScenarioOutcome `json:"scenarios"`
}

type SealRequest struct {
	Lines []string `json:"lines"`
}

type SealResponse struct {
	DigestHex string `json:"digest_hex"`
}
