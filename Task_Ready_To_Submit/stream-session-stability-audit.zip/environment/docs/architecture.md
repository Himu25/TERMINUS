# Lane policy

shard_bin: /app/bin/shard
max_skew: 0

Outbound lane tags: hk, ka, po, pl, x.

Each transcript line uses seq:tag:body. Monotonic seq is assigned at emit time.
The first ka after hk must appear as the second transcript line when pulse_every_ms is set.

finish_reason values:
- complete — torn_frame_proxy is zero and init_pulse_ok is true
- torn_lane — torn_frame_proxy exceeds max_skew
- handshake_gap — init_pulse_ok is false while pulse_every_ms is configured
- seal_failed — shard subprocess failed

Report path: /app/output/session_stability.json
Scenario array keys: name, finish_reason, pulse_count, payload_count, torn_frame_proxy, transcript_digest_hex, init_pulse_ok.

Digest: shard seal sorts lines by numeric seq prefix then sha256 hex of newline-joined body.

Steady counts for burst_ping, dual_lane, and slow_drain live in /app/data/steady/steady_counts.json.

Preflight: /app/ops/preflight.sh runs race-detector unit tests for the lane driver.

SESSION_UNSAFE_FASTPATH=1 selects an alternate init-ka replay path. Default replay may defer init ka. After repairs, transcript_digest_hex must match the default path for every fixture.
