#!/usr/bin/env bash
set -euo pipefail
export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
cd /app
go build -o /app/sessiond ./cmd/sessiond
cd /app/shard && cargo build --release --bin shard
install -d -m 0755 /app/bin
install -m 0755 /app/shard/target/release/shard /app/bin/shard
