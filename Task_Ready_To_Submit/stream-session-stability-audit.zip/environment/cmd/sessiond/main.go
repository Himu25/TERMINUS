package main

import (
	"flag"
	"log"

	"sessiond/internal/config"
	"sessiond/internal/driver"
)

func main() {
	scenarios := flag.String("scenarios", "/app/fixtures/scenarios", "scenario directory")
	out := flag.String("out", "/app/output/session_stability.json", "audit output path")
	cfgPath := flag.String("config", "/app/config/lane.yaml", "lane policy")
	flag.Parse()

	cfg, err := config.Load(*cfgPath)
	if err != nil {
		log.Fatal(err)
	}
	orch := driver.NewOrchestrator(cfg)
	report, err := orch.RunDir(*scenarios)
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.WriteReport(*out, report); err != nil {
		log.Fatal(err)
	}
}
