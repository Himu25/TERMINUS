package spanfold

import (
	"bytes"
	"encoding/json"
	"os/exec"

	"sessiond/pkg/api"
)

func Seal(bin string, lines []string) (string, error) {
	req := api.SealRequest{Lines: lines}
	raw, err := json.Marshal(req)
	if err != nil {
		return "", err
	}
	cmd := exec.Command(bin, "seal")
	cmd.Stdin = bytes.NewReader(raw)
	out, err := cmd.Output()
	if err != nil {
		return "", err
	}
	var resp api.SealResponse
	if err := json.Unmarshal(out, &resp); err != nil {
		return "", err
	}
	return resp.DigestHex, nil
}
