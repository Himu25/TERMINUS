package wirefold

// LaneScore ranks outbound lane pressure for dashboards.
func LaneScore(pulseN int, payloadN int) int {
	return pulseN*3 + payloadN*7
}
