#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

write_op_t() {
  cat > /app/pkg/canon/op_t.go <<'EOF'
package canon

import (
	"regexp"
	"strings"
)

var (
	rePod = regexp.MustCompile(`pod-[a-z0-9]+`)
	reHex = regexp.MustCompile(`[0-9a-f]{8,}`)
	reReq = regexp.MustCompile(`req-[a-z0-9]+`)
)

// OpT canonicalizes a raw template line for rank grouping.
func OpT(raw string) string {
	s := strings.ToLower(strings.Join(strings.Fields(raw), " "))
	s = rePod.ReplaceAllString(s, "pod-*")
	s = reReq.ReplaceAllString(s, "req-*")
	s = reHex.ReplaceAllString(s, "hex-*")
	return s
}
EOF
}

write_op_a() {
  cat > /app/pkg/lanegate/op_a.go <<'EOF'
package lanegate

// OpA reports whether a collector lane may contribute to the active board.
func OpA(collectorLane, activeLane string) bool {
	return collectorLane == activeLane
}
EOF
}

write_op_w() {
  cat > /app/pkg/tickalign/op_w.go <<'EOF'
package tickalign

// OpW reports whether a window tick is aligned for merge.
func OpW(tick, windowCount, tickMod int) bool {
	if tick < 1 || tick > windowCount {
		return false
	}
	if tickMod < 1 {
		tickMod = 1
	}
	return tick%tickMod == 0
}
EOF
}

write_op_h() {
  cat > /app/pkg/standby/op_h.go <<'EOF'
package standby

// OpH folds overlapping standby counts for the same template window.
func OpH(existing, incoming int) int {
	if incoming > existing {
		return incoming
	}
	return existing
}
EOF
}

write_sketchfold() {
  cat > /app/sketchfold/src/lib.rs <<'EOF'
pub fn scaleFold(count: i32, depth: i32, ref_depth: i32) -> i32 {
    if depth <= 0 {
        return count;
    }
    count * ref_depth / depth
}

#[no_mangle]
pub extern "C" fn sf_scale_fold(count: i32, depth: i32, ref_depth: i32) -> i32 {
    scaleFold(count, depth, ref_depth)
}
EOF
}

write_fold_bridge() {
  cat > /app/internal/merge/fold_bridge.go <<'EOF'
package merge

import (
	"lab.local/hetero_sketch_rank_reconcile/pkg/canon"
	"lab.local/hetero_sketch_rank_reconcile/pkg/lanegate"
	"lab.local/hetero_sketch_rank_reconcile/pkg/standby"
	"lab.local/hetero_sketch_rank_reconcile/pkg/tickalign"
	"lab.local/hetero_sketch_rank_reconcile/sketchfold"
)

func canonLine(raw string) string {
	return canon.OpT(raw)
}

func laneOk(collectorLane, activeLane string) bool {
	return lanegate.OpA(collectorLane, activeLane)
}

func tickOk(tick, windowCount, tickMod int) bool {
	return tickalign.OpW(tick, windowCount, tickMod)
}

func scaleHit(count, depth, refDepth int) int {
	return sketchfold.Scale(count, depth, refDepth)
}

func foldOverlap(existing, incoming int) int {
	return standby.OpH(existing, incoming)
}
EOF
}

write_op_t
write_op_a
write_op_w
write_op_h
write_sketchfold
write_fold_bridge

python3 <<'PY'
from pathlib import Path
path = Path("/app/internal/merge/fuse.go")
text = path.read_text()
text = text.replace("carry := prev\n", "carry := prev // 2\n")
text = text.replace("carry := prev // 2\n", "carry := prev / 2\n")
path.write_text(text)
PY

bash /app/scripts/build.sh

GOFLAGS=-mod=mod CGO_ENABLED=1 go test \
  ./pkg/canon ./pkg/lanegate ./pkg/tickalign ./pkg/standby -count=1

rm -f /app/output/rank_reconcile_report.json
TB_RANK_FIXTURE=1 /app/bin/rank_replay
test -s /app/output/rank_reconcile_report.json
