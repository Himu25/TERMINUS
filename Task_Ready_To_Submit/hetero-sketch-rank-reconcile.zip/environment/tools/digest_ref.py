#!/usr/bin/env python3
"""Reference digest helper for rank reconcile reports."""

from __future__ import annotations

import hashlib
import json
import sys


def fold_report(run_id: str, rep: dict) -> str:
    rows = rep.get("top_templates", [])
    template_part = ",".join(
        f"{row['template_id']}:{row['estimated_count']}" for row in rows
    )
    fields = [
        str(rep["collectors_live"]),
        str(rep["windows_merged"]),
        str(rep["templates_total"]),
        str(rep["top_k"]),
        str(rep["overlap_folded"]),
        str(rep["gap_windows_filled"]),
        str(rep["admission_drops"]),
        str(rep["rank_inversions"]),
        str(rep["mean_sketch_fold_units"]),
        str(rep["rank_stability_band"]),
        template_part,
    ]
    payload = run_id + "|" + "|".join(fields)
    return hashlib.sha256(payload.encode()).hexdigest()


def main() -> None:
    run_id = sys.argv[1]
    rep = json.loads(sys.argv[2])
    print(fold_report(run_id, rep))


if __name__ == "__main__":
    main()
