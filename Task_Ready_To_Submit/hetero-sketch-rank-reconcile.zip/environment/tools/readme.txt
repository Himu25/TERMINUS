Verifier copies /app/bin/rank_replay to /app/tools/verify_bin for isolated replay runs.
Digest helper for report hashing lives at /app/tools/digest_ref.py.
Go unit tests invoke /usr/local/go/bin/go test under /app.
