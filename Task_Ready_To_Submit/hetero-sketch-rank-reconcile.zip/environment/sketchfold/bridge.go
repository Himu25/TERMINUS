package sketchfold

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libsketchfold.a -ldl -lm
#include "sketch_fold.h"
*/
import "C"

// Scale adjusts a collector hit through the native sketch helper.
func Scale(count, depth, refDepth int) int {
	return int(C.sf_scale_fold(C.int(count), C.int(depth), C.int(refDepth)))
}
