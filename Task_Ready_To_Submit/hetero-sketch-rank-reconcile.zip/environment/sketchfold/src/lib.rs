pub fn scaleFold(count: i32, depth: i32, ref_depth: i32) -> i32 {
    count + depth
}

#[no_mangle]
pub extern "C" fn sf_scale_fold(count: i32, depth: i32, ref_depth: i32) -> i32 {
    scaleFold(count, depth, ref_depth)
}
