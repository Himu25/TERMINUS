#ifndef SKETCH_FOLD_H
#define SKETCH_FOLD_H
int sf_scale_fold(int count, int depth, int ref_depth);
#endif
