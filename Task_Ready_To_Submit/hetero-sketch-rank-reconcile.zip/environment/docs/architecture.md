# Rank reconciler architecture

Replay packs under `/app/data/replay/` supply offline rank audits. Each pack directory contains:

- `rank_bundle.json` — run metadata (`run_id`, `active_lane`, `window_count`, `tick_mod`, `ref_depth`, `top_k`)
- `topology.json` — maps collector ids to `lane_id` and sketch `depth`
- per-collector `windows.jsonl` — epoch/tick window rows with hit payloads and optional `handoff_flag`

The active pack symlinked under `/app/data/active/` is what `/app/bin/rank_replay` replays when `TB_RANK_FIXTURE=1`. The driver admits collector rows, scales sketch hits, folds standby overlap windows, carries decayed mass across partition gaps (half the last scaled hit per template for each silent tick), and writes `/app/output/rank_reconcile_report.json`.

## Template canonicalization (`pkg/canon`)

Each hit `raw` line is normalized before board merge:

1. Lowercase and collapse internal whitespace to single spaces.
2. Replace every `pod-[a-z0-9]+` token with `pod-*`.
3. Replace every `req-[a-z0-9]+` token with `req-*`.
4. Replace every contiguous lowercase hex run of eight or more characters with `hex-*`.
5. Short stable service tokens (for example `srv-01`) stay distinct aside from case folding.

`pkg/canon/op_t_test.go` exercises pod, req, long-hex, and srv token cases.

Pipeline layout:

- `pkg/canon` — template line folding before board merge
- `pkg/lanegate` — collector lane admission against the pack active lane
- `pkg/tickalign` — window tick alignment against pack cadence
- `pkg/standby` — standby handoff overlap fold
- `sketchfold` — native depth scaling bridge used by Go merge code
- `internal/merge` — board fuse and rank emission

Report field definitions and digest composition are documented in `/app/cmd/rank_replay/main.go`. JSON shape is enforced by `/app/schemas/rank_report.schema.json`.
