package standby

import "testing"

func TestOpHUsesMaxOverlap(t *testing.T) {
	if OpH(10, 10) != 10 {
		t.Fatal("equal overlap should keep 10")
	}
	if OpH(10, 12) != 12 {
		t.Fatal("higher standby count should win")
	}
}
