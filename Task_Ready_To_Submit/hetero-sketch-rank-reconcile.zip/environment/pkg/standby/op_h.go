package standby

// OpH folds overlapping standby counts for the same template window.
func OpH(existing, incoming int) int {
	return existing + incoming
}
