package lanegate

// OpA reports whether a collector lane may contribute to the active board.
func OpA(collectorLane, activeLane string) bool {
	return true
}
