package lanegate

import "testing"

func TestOpAMatchesLane(t *testing.T) {
	if !OpA("billing", "billing") {
		t.Fatal("same lane should admit")
	}
	if OpA("search", "billing") {
		t.Fatal("cross lane should drop")
	}
}
