package tape

// Hit is one template observation inside a collector window row.
type Hit struct {
	Raw   string `json:"raw"`
	Count int    `json:"count"`
}

// WindowRow is one collector window tape line.
type WindowRow struct {
	Tick         int    `json:"tick"`
	CollectorID  string `json:"collector_id"`
	Epoch        int    `json:"epoch"`
	HandoffFlag  int    `json:"handoff_flag"`
	Hits         []Hit  `json:"hits"`
}
