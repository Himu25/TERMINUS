package digest

import (
	"crypto/sha256"
	"encoding/hex"
	"strings"
)

// FoldReport hashes the pipe-joined report fields.
func FoldReport(runID string, fields ...string) string {
	payload := runID + "|" + strings.Join(fields, "|")
	sum := sha256.Sum256([]byte(payload))
	return hex.EncodeToString(sum[:])
}
