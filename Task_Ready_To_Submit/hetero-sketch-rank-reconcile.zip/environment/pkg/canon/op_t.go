package canon

import "strings"

// OpT canonicalizes a raw template line for rank grouping.
//
// Normalization steps (applied in order on the lowercased, whitespace-collapsed line):
//   - replace each pod-[a-z0-9]+ token with pod-*
//   - replace each req-[a-z0-9]+ token with req-*
//   - replace each contiguous [0-9a-f]{8,} hex run with hex-*
//
// Short stable service tokens such as srv-01 are unchanged aside from case folding.
// See /app/docs/architecture.md and op_t_test.go for examples.
func OpT(raw string) string {
	return strings.ToLower(strings.Join(strings.Fields(raw), " "))
}
