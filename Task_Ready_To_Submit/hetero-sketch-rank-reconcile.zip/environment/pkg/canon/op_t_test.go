package canon

import "testing"

func TestOpTFoldsVolatilePodToken(t *testing.T) {
	got := OpT("Timeout Pod-ABC123")
	want := "timeout pod-*"
	if got != want {
		t.Fatalf("got %q want %q", got, want)
	}
}

func TestOpTFoldsReqToken(t *testing.T) {
	got := OpT("crash req-deadbeef")
	want := "crash req-*"
	if got != want {
		t.Fatalf("got %q want %q", got, want)
	}
}

func TestOpTFoldsLongHexRun(t *testing.T) {
	got := OpT("trace aabbccddeeff")
	want := "trace hex-*"
	if got != want {
		t.Fatalf("got %q want %q", got, want)
	}
}

func TestOpTKeepsShortSrvToken(t *testing.T) {
	got := OpT("Disk Full SRV-01")
	want := "disk full srv-01"
	if got != want {
		t.Fatalf("got %q want %q", got, want)
	}
}
