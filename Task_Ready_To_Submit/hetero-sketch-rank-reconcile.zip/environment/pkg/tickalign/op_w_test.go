package tickalign

import "testing"

func TestOpWAcceptsAlignedTicks(t *testing.T) {
	if !OpW(2, 4, 2) {
		t.Fatal("even tick should align when mod is 2")
	}
	if OpW(1, 4, 2) {
		t.Fatal("odd tick should not align when mod is 2")
	}
}
