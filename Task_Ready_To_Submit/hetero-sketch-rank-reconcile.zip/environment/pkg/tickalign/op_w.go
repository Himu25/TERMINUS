package tickalign

// OpW reports whether a window tick is aligned for merge.
func OpW(tick, windowCount, tickMod int) bool {
	if tick < 1 || tick > windowCount {
		return false
	}
	return tick > 1
}
