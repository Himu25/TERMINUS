package config

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"lab.local/hetero_sketch_rank_reconcile/pkg/tape"
)

// Bundle describes one rank replay pack.
type Bundle struct {
	RunID       string `json:"run_id"`
	TopK        int    `json:"top_k"`
	RefDepth    int    `json:"ref_depth"`
	TickMod     int    `json:"tick_mod"`
	ActiveLane  string `json:"active_lane"`
	WindowCount int    `json:"window_count"`
}

// CollectorMeta binds a collector to a lane and sketch depth.
type CollectorMeta struct {
	LaneID string `json:"lane_id"`
	Depth  int    `json:"depth"`
}

// Topology maps collector ids to lane metadata.
type Topology map[string]CollectorMeta

// ActivePaths returns the active pack directory under appRoot.
func ActivePaths(appRoot string) (string, error) {
	dir := filepath.Join(appRoot, "data", "active", "pack_quiet")
	if st, err := os.Stat(dir); err != nil || !st.IsDir() {
		return "", fmt.Errorf("active pack missing: %s", dir)
	}
	return dir, nil
}

// LoadPack reads rank_bundle.json, topology.json, and collector window tapes.
func LoadPack(dir string) (Bundle, Topology, map[string][]tape.WindowRow, error) {
	raw, err := os.ReadFile(filepath.Join(dir, "rank_bundle.json"))
	if err != nil {
		return Bundle{}, nil, nil, err
	}
	var bundle Bundle
	if err := json.Unmarshal(raw, &bundle); err != nil {
		return Bundle{}, nil, nil, err
	}
	topoRaw, err := os.ReadFile(filepath.Join(dir, "topology.json"))
	if err != nil {
		return Bundle{}, nil, nil, err
	}
	var topo Topology
	if err := json.Unmarshal(topoRaw, &topo); err != nil {
		return Bundle{}, nil, nil, err
	}
	tapes := make(map[string][]tape.WindowRow)
	for collectorID := range topo {
		path := filepath.Join(dir, collectorID, "windows.jsonl")
		lines, err := os.ReadFile(path)
		if err != nil {
			if os.IsNotExist(err) {
				continue
			}
			return Bundle{}, nil, nil, err
		}
		for _, line := range splitLines(string(lines)) {
			if line == "" {
				continue
			}
			var row tape.WindowRow
			if err := json.Unmarshal([]byte(line), &row); err != nil {
				return Bundle{}, nil, nil, err
			}
			tapes[collectorID] = append(tapes[collectorID], row)
		}
	}
	return bundle, topo, tapes, nil
}

func splitLines(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			out = append(out, s[start:i])
			start = i + 1
		}
	}
	if start < len(s) {
		out = append(out, s[start:])
	}
	return out
}
