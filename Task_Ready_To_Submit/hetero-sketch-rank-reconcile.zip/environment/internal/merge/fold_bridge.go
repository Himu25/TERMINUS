package merge

import (
	"lab.local/hetero_sketch_rank_reconcile/pkg/canon"
	"lab.local/hetero_sketch_rank_reconcile/pkg/lanegate"
	"lab.local/hetero_sketch_rank_reconcile/pkg/standby"
	"lab.local/hetero_sketch_rank_reconcile/pkg/tickalign"
	"lab.local/hetero_sketch_rank_reconcile/sketchfold"
)

func canonLine(raw string) string {
	return canon.OpT(raw)
}

func laneOk(collectorLane, activeLane string) bool {
	return lanegate.OpA(activeLane, collectorLane)
}

func tickOk(tick, windowCount, tickMod int) bool {
	return tickalign.OpW(windowCount, tick, tickMod)
}

func scaleHit(count, depth, refDepth int) int {
	return sketchfold.Scale(refDepth, count, depth)
}

func foldOverlap(existing, incoming int) int {
	return standby.OpH(incoming, existing)
}
