package merge

import (
	"lab.local/hetero_sketch_rank_reconcile/internal/config"
	"lab.local/hetero_sketch_rank_reconcile/pkg/tape"
)

// TemplateRow is one ranked template emitted in the report.
type TemplateRow struct {
	TemplateID        string `json:"template_id"`
	EstimatedCount    int    `json:"estimated_count"`
	CollectorCoverage int    `json:"collector_coverage"`
	LaneID            string `json:"lane_id"`
}

// Outcome is folded counters and ranked templates for one pack.
type Outcome struct {
	CollectorsLive      int
	WindowsMerged       int
	TemplatesTotal      int
	OverlapFolded       int
	GapWindowsFilled    int
	AdmissionDrops      int
	RankInversions      int
	MeanSketchFoldUnits int
	RankStabilityBand   int
	TopTemplates        []TemplateRow
}

type boardEntry struct {
	total    int
	naive    int
	byColl   map[string]int
	coverage map[string]struct{}
}

// ExecPack replays collector tapes into a reconciled rank board.
func ExecPack(bundle config.Bundle, topo config.Topology, tapes map[string][]tape.WindowRow) Outcome {
	liveCollectors := 0
	for collectorID, meta := range topo {
		if len(tapes[collectorID]) > 0 && laneOk(meta.LaneID, bundle.ActiveLane) {
			liveCollectors++
		}
	}

	board := make(map[string]*boardEntry)
	naiveBoard := make(map[string]int)
	overlapFolded := 0
	admissionDrops := 0
	windowsMerged := 0
	foldUnits := 0
	gapFilled := 0

	type slotKey struct {
		tick        int
		collectorID string
		templateID  string
	}
	slotTotals := make(map[slotKey]int)

	for collectorID, rows := range tapes {
		meta, ok := topo[collectorID]
		if !ok {
			continue
		}
		sortRows(rows)
		lastTickHits := make(map[string]int)
		seenTicks := make(map[int]struct{})
		for _, row := range rows {
			if !laneOk(meta.LaneID, bundle.ActiveLane) {
				admissionDrops++
				continue
			}
			if !tickOk(row.Tick, bundle.WindowCount, bundle.TickMod) {
				admissionDrops++
				continue
			}
			seenTicks[row.Tick] = struct{}{}
			windowsMerged++
			for _, hit := range row.Hits {
				templateID := canonLine(hit.Raw)
				scaled := scaleHit(hit.Count, meta.Depth, bundle.RefDepth)
				foldUnits++
				naiveBoard[templateID] += hit.Count

				ent := board[templateID]
				if ent == nil {
					ent = &boardEntry{byColl: make(map[string]int), coverage: make(map[string]struct{})}
					board[templateID] = ent
				}
				ent.coverage[collectorID] = struct{}{}
				ent.naive += hit.Count

				slot := slotKey{tick: row.Tick, collectorID: collectorID, templateID: templateID}
				prev := slotTotals[slot]
				var merged int
				if row.HandoffFlag == 1 && prev > 0 {
					merged = foldOverlap(prev, scaled)
					if merged != prev+scaled {
						overlapFolded++
					}
					ent.total = ent.total - prev + merged
					ent.byColl[collectorID] = ent.byColl[collectorID] - prev + merged
				} else {
					merged = prev + scaled
					ent.total += scaled
					ent.byColl[collectorID] += scaled
				}
				slotTotals[slot] = merged
				lastTickHits[templateID] = scaled
			}
		}

		for tick := 1; tick <= bundle.WindowCount; tick++ {
			if _, ok := seenTicks[tick]; ok {
				continue
			}
			if len(lastTickHits) == 0 {
				continue
			}
			gapFilled++
			for templateID, prev := range lastTickHits {
				carry := prev
				if carry <= 0 {
					continue
				}
				ent := board[templateID]
				if ent == nil {
					ent = &boardEntry{byColl: make(map[string]int), coverage: make(map[string]struct{})}
					board[templateID] = ent
				}
				ent.coverage[collectorID] = struct{}{}
				ent.byColl[collectorID] += carry
				ent.total += carry
				foldUnits++
			}
		}
	}

	naiveOrder := orderByTotals(naiveBoard)
	finalTotals := make(map[string]int)
	for id, ent := range board {
		finalTotals[id] = ent.total
	}
	finalOrder := orderByTotals(finalTotals)
	rankInversions := 0
	for i := 0; i < len(naiveOrder) && i < len(finalOrder); i++ {
		if naiveOrder[i] != finalOrder[i] {
			rankInversions++
		}
	}

	stability := 0
	for _, ent := range board {
		minV, maxV := 0, 0
		first := true
		for _, v := range ent.byColl {
			if first {
				minV, maxV = v, v
				first = false
				continue
			}
			if v < minV {
				minV = v
			}
			if v > maxV {
				maxV = v
			}
		}
		if maxV-minV > stability {
			stability = maxV - minV
		}
	}

	topK := bundle.TopK
	if topK <= 0 {
		topK = len(board)
	}
	top := buildTop(board, topK, bundle.ActiveLane)

	return Outcome{
		CollectorsLive:      liveCollectors,
		WindowsMerged:       windowsMerged,
		TemplatesTotal:      len(board),
		OverlapFolded:       overlapFolded,
		GapWindowsFilled:    gapFilled,
		AdmissionDrops:      admissionDrops,
		RankInversions:      rankInversions,
		MeanSketchFoldUnits: foldUnits,
		RankStabilityBand:   stability,
		TopTemplates:        top,
	}
}

func buildTop(board map[string]*boardEntry, topK int, lane string) []TemplateRow {
	type pair struct {
		id    string
		total int
		cov   int
	}
	var rows []pair
	for id, ent := range board {
		rows = append(rows, pair{id: id, total: ent.total, cov: len(ent.coverage)})
	}
	for i := 0; i < len(rows); i++ {
		for j := i + 1; j < len(rows); j++ {
			if rows[j].total > rows[i].total || (rows[j].total == rows[i].total && rows[j].id < rows[i].id) {
				rows[i], rows[j] = rows[j], rows[i]
			}
		}
	}
	if topK > 0 && topK < len(rows) {
		rows = rows[:topK]
	}
	out := make([]TemplateRow, 0, len(rows))
	for _, row := range rows {
		out = append(out, TemplateRow{
			TemplateID:        row.id,
			EstimatedCount:    row.total,
			CollectorCoverage: row.cov,
			LaneID:            lane,
		})
	}
	return out
}

func orderByTotals(m map[string]int) []string {
	type pair struct {
		id string
		v  int
	}
	var rows []pair
	for id, v := range m {
		rows = append(rows, pair{id: id, v: v})
	}
	for i := 0; i < len(rows); i++ {
		for j := i + 1; j < len(rows); j++ {
			if rows[j].v > rows[i].v || (rows[j].v == rows[i].v && rows[j].id < rows[i].id) {
				rows[i], rows[j] = rows[j], rows[i]
			}
		}
	}
	out := make([]string, len(rows))
	for i, row := range rows {
		out[i] = row.id
	}
	return out
}

func sortRows(rows []tape.WindowRow) {
	for i := 0; i < len(rows); i++ {
		for j := i + 1; j < len(rows); j++ {
			if rows[j].Epoch < rows[i].Epoch || (rows[j].Epoch == rows[i].Epoch && rows[j].Tick < rows[i].Tick) {
				rows[i], rows[j] = rows[j], rows[i]
			}
		}
	}
}
