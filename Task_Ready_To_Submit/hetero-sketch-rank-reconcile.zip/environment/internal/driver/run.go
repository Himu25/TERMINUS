package driver

import (
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"strings"

	"lab.local/hetero_sketch_rank_reconcile/internal/config"
	"lab.local/hetero_sketch_rank_reconcile/internal/merge"
	"lab.local/hetero_sketch_rank_reconcile/pkg/digest"
)

// Report is the JSON shape written to /app/output/rank_reconcile_report.json.
type Report struct {
	SchemaVersion       string              `json:"schema_version"`
	RunID               string              `json:"run_id"`
	CollectorsLive      int                 `json:"collectors_live"`
	WindowsMerged       int                 `json:"windows_merged"`
	TemplatesTotal      int                 `json:"templates_total"`
	TopK                int                 `json:"top_k"`
	OverlapFolded       int                 `json:"overlap_folded"`
	GapWindowsFilled    int                 `json:"gap_windows_filled"`
	AdmissionDrops      int                 `json:"admission_drops"`
	RankInversions      int                 `json:"rank_inversions"`
	MeanSketchFoldUnits int                 `json:"mean_sketch_fold_units"`
	RankStabilityBand   int                 `json:"rank_stability_band"`
	TopTemplates        []merge.TemplateRow `json:"top_templates"`
	ReportDigest        string              `json:"report_digest"`
}

// RunActive loads the active pack and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	bundle, topo, tapes, err := config.LoadPack(dir)
	if err != nil {
		return Report{}, err
	}
	out := merge.ExecPack(bundle, topo, tapes)
	digestHex := digest.FoldReport(
		bundle.RunID,
		itoa(out.CollectorsLive),
		itoa(out.WindowsMerged),
		itoa(out.TemplatesTotal),
		itoa(bundle.TopK),
		itoa(out.OverlapFolded),
		itoa(out.GapWindowsFilled),
		itoa(out.AdmissionDrops),
		itoa(out.RankInversions),
		itoa(out.MeanSketchFoldUnits),
		itoa(out.RankStabilityBand),
		templateDigest(out.TopTemplates),
	)
	return Report{
		SchemaVersion:       "1",
		RunID:               bundle.RunID,
		CollectorsLive:      out.CollectorsLive,
		WindowsMerged:       out.WindowsMerged,
		TemplatesTotal:      out.TemplatesTotal,
		TopK:                bundle.TopK,
		OverlapFolded:       out.OverlapFolded,
		GapWindowsFilled:    out.GapWindowsFilled,
		AdmissionDrops:      out.AdmissionDrops,
		RankInversions:      out.RankInversions,
		MeanSketchFoldUnits: out.MeanSketchFoldUnits,
		RankStabilityBand:   out.RankStabilityBand,
		TopTemplates:        out.TopTemplates,
		ReportDigest:        digestHex,
	}, nil
}

// EmitReport writes rep to path as compact JSON.
func EmitReport(path string, rep Report) error {
	if err := os.MkdirAll("/app/output", 0o755); err != nil {
		return err
	}
	raw, err := json.Marshal(rep)
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func templateDigest(rows []merge.TemplateRow) string {
	parts := make([]string, 0, len(rows))
	for _, row := range rows {
		parts = append(parts, fmt.Sprintf("%s:%d", row.TemplateID, row.EstimatedCount))
	}
	return strings.Join(parts, ",")
}

func itoa(v int) string {
	return strconv.Itoa(v)
}
