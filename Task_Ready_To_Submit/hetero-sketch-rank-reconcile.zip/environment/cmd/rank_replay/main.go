// Report JSON for /app/output/rank_reconcile_report.json:
//
// schema_version — string, always "1"
// run_id — string, echoes active pack name
// collectors_live — collectors with at least one admitted window row on the active lane
// windows_merged — admitted collector window rows after lane and tick gates
// templates_total — distinct canonical template ids on the reconciled board
// top_k — rank board width from the pack bundle
// overlap_folded — standby handoff rows folded instead of summed
// gap_windows_filled — collector ticks filled by carry-forward after partition silence;
//   each silent tick per template receives half the last scaled hit (integer division toward zero)
// admission_drops — rows rejected by lane or tick alignment gates
// rank_inversions — template ids whose final rank index differs from naive unscaled ordering
// mean_sketch_fold_units — sketch fold operations performed during replay
// rank_stability_band — max per-template spread between collector contributions
// top_templates — array of template_id, estimated_count, collector_coverage, lane_id
// report_digest — lowercase hex SHA-256 of run_id|collectors_live|windows_merged|templates_total|
//   top_k|overlap_folded|gap_windows_filled|admission_drops|rank_inversions|mean_sketch_fold_units|
//   rank_stability_band|comma-separated template_id:estimated_count pairs in rank order
//
// Root object contains only these keys. JSON schema: /app/schemas/rank_report.schema.json
package main

import (
	"log"
	"os"

	"lab.local/hetero_sketch_rank_reconcile/internal/driver"
)

func main() {
	if os.Getenv("TB_RANK_FIXTURE") != "1" {
		log.Fatal("TB_RANK_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/rank_reconcile_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
