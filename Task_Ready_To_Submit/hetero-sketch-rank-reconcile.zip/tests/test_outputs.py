"""Verifier for hetero sketch rank reconcile."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
ACTIVE = APP / "data" / "active" / "pack_quiet"
FIXTURES = APP / "data" / "replay"
OUT = APP / "output" / "rank_reconcile_report.json"
GO_BIN = "/usr/local/go/bin/go"
VERIFY_BIN = "/app/tools/verify_bin"

# Mirror pkg/canon folding documented in /app/docs/architecture.md and op_t_test.go.
RE_POD = re.compile(r"pod-[a-z0-9]+")
RE_HEX = re.compile(r"[0-9a-f]{8,}")
RE_REQ = re.compile(r"req-[a-z0-9]+")


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)
    subprocess.run(["cp", "/app/bin/rank_replay", VERIFY_BIN], check=True)


def _op_t(raw: str) -> str:
    """Apply the same canonical template folding as pkg/canon OpT."""
    s = " ".join(raw.lower().split())
    s = RE_POD.sub("pod-*", s)
    s = RE_REQ.sub("req-*", s)
    s = RE_HEX.sub("hex-*", s)
    return s


def _op_a(collector_lane: str, active_lane: str) -> bool:
    return collector_lane == active_lane


def _op_w(tick: int, window_count: int, tick_mod: int) -> bool:
    if tick < 1 or tick > window_count:
        return False
    if tick_mod < 1:
        tick_mod = 1
    return tick % tick_mod == 0


def _scale(count: int, depth: int, ref_depth: int) -> int:
    if depth <= 0:
        return count
    return count * ref_depth // depth


def _op_h(existing: int, incoming: int) -> int:
    return incoming if incoming > existing else existing


def _template_digest(rows: list[dict]) -> str:
    return ",".join(f"{r['template_id']}:{r['estimated_count']}" for r in rows)


def _digest_hex(run_id: str, rep: dict) -> str:
    payload = {k: v for k, v in rep.items() if k != "report_digest"}
    proc = subprocess.run(
        [
            "python3",
            "/app/tools/digest_ref.py",
            run_id,
            json.dumps(payload, separators=(",", ":")),
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    return proc.stdout.strip()


def _load_pack(pack_dir: Path) -> tuple[dict, dict, dict[str, list[dict]]]:
    bundle = json.loads((pack_dir / "rank_bundle.json").read_text())
    topo = json.loads((pack_dir / "topology.json").read_text())
    tapes: dict[str, list[dict]] = {}
    for collector_id in topo:
        path = pack_dir / collector_id / "windows.jsonl"
        if not path.exists():
            continue
        rows = []
        for line in path.read_text().splitlines():
            if line.strip():
                rows.append(json.loads(line))
        tapes[collector_id] = rows
    return bundle, topo, tapes


def _expected_from_pack(pack_dir: Path) -> dict:
    bundle, topo, tapes = _load_pack(pack_dir)

    live_collectors = 0
    for collector_id, meta in topo.items():
        if tapes.get(collector_id) and _op_a(meta["lane_id"], bundle["active_lane"]):
            live_collectors += 1

    board: dict[str, dict] = {}
    naive_board: dict[str, int] = {}
    overlap_folded = 0
    admission_drops = 0
    windows_merged = 0
    fold_units = 0
    gap_filled = 0
    slot_totals: dict[tuple[int, str, str], int] = {}

    for collector_id, rows in tapes.items():
        meta = topo[collector_id]
        rows = sorted(rows, key=lambda r: (r["epoch"], r["tick"]))
        last_tick_hits: dict[str, int] = {}
        seen_ticks: set[int] = set()
        for row in rows:
            if not _op_a(meta["lane_id"], bundle["active_lane"]):
                admission_drops += 1
                continue
            if not _op_w(row["tick"], bundle["window_count"], bundle["tick_mod"]):
                admission_drops += 1
                continue
            seen_ticks.add(row["tick"])
            windows_merged += 1
            for hit in row["hits"]:
                template_id = _op_t(hit["raw"])
                scaled = _scale(hit["count"], meta["depth"], bundle["ref_depth"])
                fold_units += 1
                naive_board[template_id] = naive_board.get(template_id, 0) + hit["count"]

                ent = board.setdefault(
                    template_id,
                    {"total": 0, "by_coll": {}, "coverage": set()},
                )
                ent["coverage"].add(collector_id)
                slot = (row["tick"], collector_id, template_id)
                prev = slot_totals.get(slot, 0)
                if row["handoff_flag"] == 1 and prev > 0:
                    merged = _op_h(prev, scaled)
                    if merged != prev + scaled:
                        overlap_folded += 1
                    ent["total"] = ent["total"] - prev + merged
                    ent["by_coll"][collector_id] = ent["by_coll"].get(collector_id, 0) - prev + merged
                else:
                    merged = prev + scaled
                    ent["total"] += scaled
                    ent["by_coll"][collector_id] = ent["by_coll"].get(collector_id, 0) + scaled
                slot_totals[slot] = merged
                last_tick_hits[template_id] = scaled

        for tick in range(1, bundle["window_count"] + 1):
            if tick in seen_ticks:
                continue
            if not last_tick_hits:
                continue
            gap_filled += 1
            for template_id, prev in last_tick_hits.items():
                carry = prev // 2
                if carry <= 0:
                    continue
                ent = board.setdefault(
                    template_id,
                    {"total": 0, "by_coll": {}, "coverage": set()},
                )
                ent["coverage"].add(collector_id)
                ent["by_coll"][collector_id] = ent["by_coll"].get(collector_id, 0) + carry
                ent["total"] += carry
                fold_units += 1

    def _order_keys(totals: dict[str, int]) -> list[str]:
        return [
            k
            for k, _ in sorted(
                totals.items(),
                key=lambda item: (-item[1], item[0]),
            )
        ]

    naive_order = _order_keys(naive_board)
    final_totals = {tid: ent["total"] for tid, ent in board.items()}
    final_order = _order_keys(final_totals)
    rank_inversions = sum(
        1
        for i in range(min(len(naive_order), len(final_order)))
        if naive_order[i] != final_order[i]
    )

    stability = 0
    for ent in board.values():
        vals = list(ent["by_coll"].values())
        if not vals:
            continue
        spread = max(vals) - min(vals)
        if spread > stability:
            stability = spread

    top_k = bundle["top_k"] if bundle["top_k"] > 0 else len(board)
    ranked = sorted(
        board.items(),
        key=lambda item: (-item[1]["total"], item[0]),
    )[:top_k]
    top_templates = [
        {
            "template_id": tid,
            "estimated_count": ent["total"],
            "collector_coverage": len(ent["coverage"]),
            "lane_id": bundle["active_lane"],
        }
        for tid, ent in ranked
    ]

    rep = {
        "schema_version": "1",
        "run_id": bundle["run_id"],
        "collectors_live": live_collectors,
        "windows_merged": windows_merged,
        "templates_total": len(board),
        "top_k": bundle["top_k"],
        "overlap_folded": overlap_folded,
        "gap_windows_filled": gap_filled,
        "admission_drops": admission_drops,
        "rank_inversions": rank_inversions,
        "mean_sketch_fold_units": fold_units,
        "rank_stability_band": stability,
        "top_templates": top_templates,
    }
    rep["report_digest"] = _digest_hex(bundle["run_id"], rep)
    return rep


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    dest = ACTIVE
    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(src, dest)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_RANK_FIXTURE": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    return json.loads(OUT.read_text())


def test_quiet_report_matches_replay() -> None:
    """Active pack_quiet should replay the full rank reconcile report."""
    _swap("pack_quiet")
    assert _run_tool() == _expected_from_pack(FIXTURES / "pack_quiet")


def test_quiet_report_matches_schema() -> None:
    """Report JSON should expose exactly the declared schema fields."""
    schema = json.loads((APP / "schemas" / "rank_report.schema.json").read_text())
    _swap("pack_quiet")
    got = _run_tool()
    assert set(got.keys()) == set(schema["required"])


def test_template_drift_folds_volatile_tokens() -> None:
    """Template drift pack should merge req tokens into one ranked template."""
    _swap("pack_template_drift")
    exp = _expected_from_pack(FIXTURES / "pack_template_drift")
    got = _run_tool()
    assert got["templates_total"] == exp["templates_total"]
    assert got["top_templates"] == exp["top_templates"]


def test_hetero_depth_scales_sketch_geometry() -> None:
    """Heterogeneous depth pack should normalize counts before ranking."""
    _swap("pack_hetero_depth")
    exp = _expected_from_pack(FIXTURES / "pack_hetero_depth")
    got = _run_tool()
    assert got["top_templates"] == exp["top_templates"]


def test_failover_overlap_folds_standby_window() -> None:
    """Failover overlap pack should fold duplicate standby mass."""
    _swap("pack_failover_overlap")
    exp = _expected_from_pack(FIXTURES / "pack_failover_overlap")
    got = _run_tool()
    assert got["overlap_folded"] == exp["overlap_folded"]
    assert got["top_templates"] == exp["top_templates"]


def test_partition_gap_carries_forward_mass() -> None:
    """Partition gap pack should fill silent collector ticks."""
    _swap("pack_partition_gap")
    exp = _expected_from_pack(FIXTURES / "pack_partition_gap")
    got = _run_tool()
    assert got["gap_windows_filled"] == exp["gap_windows_filled"]
    assert got["top_templates"] == exp["top_templates"]


def test_lane_cross_drops_foreign_collectors() -> None:
    """Lane cross pack should reject collectors outside the active lane."""
    _swap("pack_lane_cross")
    exp = _expected_from_pack(FIXTURES / "pack_lane_cross")
    got = _run_tool()
    assert got["admission_drops"] == exp["admission_drops"]
    assert got["templates_total"] == exp["templates_total"]
    assert got["top_templates"] == exp["top_templates"]


def test_go_subsystem_tests_pass() -> None:
    """Go tests under /app must pass after the repair."""
    subprocess.run(
        [
            GO_BIN,
            "test",
            "./pkg/canon",
            "./pkg/lanegate",
            "./pkg/tickalign",
            "./pkg/standby",
        ],
        cwd="/app",
        env={
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        },
        check=True,
    )
