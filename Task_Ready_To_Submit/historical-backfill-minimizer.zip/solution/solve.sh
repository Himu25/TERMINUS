#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/pkg/graphexp/op_r.go <<'EOF'
package graphexp

import "lab.local/hist_backfill_min/pkg/partpkg"

type Edge struct {
	From string `json:"from"`
	To   string `json:"to"`
}

func OpR(direct []Edge, view []Edge, start partpkg.Key) ([]partpkg.Key, uint32) {
	adjD := map[string][]string{}
	adjV := map[string][]string{}
	for _, e := range direct {
		adjD[e.From] = append(adjD[e.From], e.To)
	}
	for _, e := range view {
		adjV[e.From] = append(adjV[e.From], e.To)
	}
	seen := map[string]bool{start.Table: true}
	var out []partpkg.Key
	var hops uint32
	queue := []string{start.Table}
	for len(queue) > 0 {
		cur := queue[0]
		queue = queue[1:]
		for _, nxt := range adjD[cur] {
			if seen[nxt] {
				continue
			}
			seen[nxt] = true
			out = append(out, partpkg.Key{Table: nxt, PartID: start.PartID})
			queue = append(queue, nxt)
		}
		for _, nxt := range adjV[cur] {
			if seen[nxt] {
				continue
			}
			seen[nxt] = true
			out = append(out, partpkg.Key{Table: nxt, PartID: start.PartID})
			hops++
			queue = append(queue, nxt)
		}
	}
	return out, hops
}
EOF

cat > /app/pkg/wmfold/op_t.go <<'EOF'
package wmfold

func OpT(watermarkMS int64, upstreamMS int64, rowsValid bool) bool {
	if !rowsValid {
		return true
	}
	return false
}
EOF

cat > /app/internal/tokfold/op_g.go <<'EOF'
package tokfold

func OpG(watermarkMS int64, lateMS int64) bool {
	if lateMS == 0 {
		return false
	}
	return lateMS > watermarkMS
}
EOF

cat > /app/rowcheck/src/lib.rs <<'EOF'
#[no_mangle]
pub extern "C" fn rc_fold_u16(seq: u32, ptr: *const u8, len: usize) -> u16 {
    if ptr.is_null() || len == 0 {
        return 0;
    }
    let slice = unsafe { std::slice::from_raw_parts(ptr, len) };
    let mut s: u32 = 0;
    for &b in slice {
        s = s.wrapping_add(b as u32);
    }
    s ^= seq;
    (s & 0xFFFF) as u16
}
EOF

cat > /app/rowcheck/row_check.h <<'EOF'
#ifndef RC_ROW_CHECK_H
#define RC_ROW_CHECK_H

#include <stdint.h>

uint16_t rc_fold_u16(uint32_t seq, const uint8_t *ptr, size_t len);

#endif
EOF

cat > /app/rowcheck/bridge.go <<'EOF'
package rowcheck

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/librowcheck.a -ldl -lm
#include "row_check.h"
#include <stdlib.h>
*/
import "C"
import (
	"lab.local/hist_backfill_min/pkg/frame"
	"unsafe"
)

func RowMiss(rows []frame.Row) int {
	bad := 0
	for _, r := range rows {
		payload := []byte(r.Payload)
		var ptr *C.uint8_t
		if len(payload) > 0 {
			ptr = (*C.uint8_t)(unsafe.Pointer(&payload[0]))
		}
		want := uint16(C.rc_fold_u16(C.uint(r.Seq), ptr, C.size_t(len(payload))))
		if want != r.Tag {
			bad++
		}
	}
	return bad
}
EOF

bash /app/scripts/build.sh

rm -f /app/output/repair_plan.json
mkdir -p /app/output
TB_HIST_FIXTURE=1 /app/bin/scope_min
test -s /app/output/repair_plan.json

GOFLAGS=-mod=mod go test ./...
