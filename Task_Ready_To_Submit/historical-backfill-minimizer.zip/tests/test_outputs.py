"""Verifier for historical repair scope plans."""

import json
import os
import shutil
import subprocess
from collections import deque
from pathlib import Path

import pytest

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = Path("/tests") / "fixtures"
OUT = APP / "output" / "repair_plan.json"
BIN = "/app/bin/scope_min"
DIGEST_CLI = "/app/tools/digest_cli"
GO_BIN = "go"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _wire_crc(seq: int, payload: str) -> int:
    s = sum(payload.encode()) & 0xFFFFFFFF
    s ^= seq
    return s & 0xFFFF


def _partial_bad(rows: list[dict]) -> int:
    return sum(1 for r in rows if _wire_crc(r["seq"], r["payload"]) != r["tag"])


def _rows_valid(rows: list[dict]) -> bool:
    return all(_wire_crc(r["seq"], r["payload"]) == r["tag"] for r in rows)


def _op_l(direct: list[dict], view: list[dict], start: tuple[str, str]) -> tuple[list[tuple[str, str]], int]:
    adj_d: dict[str, list[str]] = {}
    adj_v: dict[str, list[str]] = {}
    for e in direct:
        adj_d.setdefault(e["from"], []).append(e["to"])
    for e in view:
        adj_v.setdefault(e["from"], []).append(e["to"])
    seen = {start[0]}
    out: list[tuple[str, str]] = []
    hops = 0
    queue = deque([start[0]])
    while queue:
        cur = queue.popleft()
        for nxt in adj_d.get(cur, []):
            if nxt not in seen:
                seen.add(nxt)
                out.append((nxt, start[1]))
                queue.append(nxt)
        for nxt in adj_v.get(cur, []):
            if nxt not in seen:
                seen.add(nxt)
                out.append((nxt, start[1]))
                hops += 1
                queue.append(nxt)
    return out, hops


def _digest_hex(
    corpus_id: str,
    origin_count: int,
    blast_count: int,
    touch_count: int,
    hold_count: int,
    indirect_hops: int,
    row_faults: int,
    tardy_count: int,
) -> str:
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            DIGEST_CLI,
            corpus_id,
            str(origin_count),
            str(blast_count),
            str(touch_count),
            str(hold_count),
            str(indirect_hops),
            str(row_faults),
            str(tardy_count),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _load_pack(pack_dir: Path) -> tuple[dict, dict[tuple[str, str], dict]]:
    plan = json.loads((pack_dir / "corpus_plan.json").read_text())
    slices: dict[tuple[str, str], dict] = {}
    for tbl in plan["tables"]:
        tbl_dir = pack_dir / "tables" / tbl
        for path in sorted(tbl_dir.glob("*.json")):
            rec = json.loads(path.read_text())
            slices[(rec["table"], rec["part_id"])] = rec
    return plan, slices


def _expected(plan: dict, slices: dict[tuple[str, str], dict]) -> dict:
    scope: dict[tuple[str, str], bool] = {}
    row_faults = 0
    tardy_count = 0
    indirect_hops = 0

    def expand(start: tuple[str, str]) -> None:
        nonlocal indirect_hops
        down, hops = _op_l(plan["direct_edges"], plan["view_edges"], start)
        indirect_hops += hops
        for dk in down:
            scope[dk] = True

    for key, rec in slices.items():
        bad = _partial_bad(rec["rows"])
        row_faults += bad
        if bad > 0:
            scope[key] = True
        if rec["late_ms"] > rec["watermark_ms"]:
            scope[key] = True
            tardy_count += 1
            expand(key)

    origin_count = 0
    for seed in plan["seed_parts"]:
        sk = (seed["table"], seed["part_id"])
        if _partial_bad(slices[sk]["rows"]) == 0:
            continue
        origin_count += 1
        scope[sk] = True
        expand(sk)

    refresh: dict[tuple[str, str], bool] = {}
    for key, rec in slices.items():
        if key in scope:
            continue
        if _rows_valid(rec["rows"]) and rec["upstream_wm_ms"] > rec["watermark_ms"]:
            refresh[key] = True

    blast_count = len(scope)
    touch_count = len(refresh)
    hold_count = len(slices) - blast_count - touch_count
    digest = _digest_hex(
        plan["corpus_id"],
        origin_count,
        blast_count,
        touch_count,
        hold_count,
        indirect_hops,
        row_faults,
        tardy_count,
    )
    return {
        "schema_version": "1",
        "corpus_id": plan["corpus_id"],
        "origin_count": origin_count,
        "blast_count": blast_count,
        "touch_count": touch_count,
        "hold_count": hold_count,
        "indirect_hops": indirect_hops,
        "row_faults": row_faults,
        "tardy_count": tardy_count,
        "plan_seal": digest,
    }


def _run_driver() -> dict:
    env = {**os.environ, "TB_HIST_FIXTURE": "1"}
    subprocess.run([BIN], cwd="/app", env=env, check=True)
    return json.loads(OUT.read_text())


def _swap_active(pack_name: str) -> None:
    src = FIXTURES / pack_name
    backup = APP / "data" / "_active_backup"
    if backup.exists():
        shutil.rmtree(backup)
    shutil.move(str(ACTIVE), str(backup))
    shutil.copytree(src, ACTIVE)


def _restore_active() -> None:
    backup = APP / "data" / "_active_backup"
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    if backup.exists():
        shutil.move(str(backup), str(ACTIVE))


class TestRepairPlan:
    def test_active_plan_matches_contract(self) -> None:
        """Active corpus plan emits expected repair scope counters."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got == expected

    def test_plan_seal_is_deterministic(self) -> None:
        """Two consecutive replays produce identical plan_seal."""
        first = _run_driver()
        second = _run_driver()
        assert first["plan_seal"] == second["plan_seal"]
        assert first == second

    def test_row_faults_detect_row_drift(self) -> None:
        """row_faults reflects row-level tag failures on corrupted seeds."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got["row_faults"] == expected["row_faults"]
        assert got["origin_count"] == expected["origin_count"]

    def test_indirect_hops_include_materialized_layer(self) -> None:
        """indirect_hops counts view-layer hops during scope expansion."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got["indirect_hops"] == expected["indirect_hops"]

    def test_refresh_excludes_stale_valid_slices(self) -> None:
        """touch_count covers valid slices whose watermark trails upstream."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got["touch_count"] == expected["touch_count"]
        assert got["blast_count"] == expected["blast_count"]

    def test_late_updates_enter_scope(self) -> None:
        """tardy_count counts slices with late_ms above watermark_ms."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got["tardy_count"] == expected["tardy_count"]

    def test_go_unit_tests_pass(self) -> None:
        """Go unit tests under /app pass after repair."""
        env = {
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        }
        subprocess.run([GO_BIN, "test", "./..."], cwd="/app", env=env, check=True)

    def test_stem_alpha_replays_clean(self) -> None:
        """stem_alpha regression stem replays to an equivalent plan."""
        _swap_active("stem_alpha")
        try:
            plan, slices = _load_pack(ACTIVE)
            expected = _expected(plan, slices)
            got = _run_driver()
            assert got == expected
        finally:
            _restore_active()

    def test_stem_beta_replays_clean(self) -> None:
        """stem_beta regression stem replays to an equivalent plan."""
        _swap_active("stem_beta")
        try:
            plan, slices = _load_pack(ACTIVE)
            expected = _expected(plan, slices)
            got = _run_driver()
            assert got == expected
        finally:
            _restore_active()

    def test_hold_count_excludes_clean_slices(self) -> None:
        """hold_count leaves verified-clean slices out of scope and refresh."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got["hold_count"] == expected["hold_count"]

    def test_schema_version_and_corpus_id(self) -> None:
        """Report carries schema_version and active corpus_id from the plan."""
        plan, slices = _load_pack(ACTIVE)
        expected = _expected(plan, slices)
        got = _run_driver()
        assert got["corpus_id"] == plan["corpus_id"]
        assert got["schema_version"] == expected["schema_version"]
