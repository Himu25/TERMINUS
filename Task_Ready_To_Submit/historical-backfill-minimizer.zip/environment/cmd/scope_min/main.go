// Plan JSON for /app/output/repair_plan.json:
//
// schema_version — string, always "1"
// corpus_id — string, echoes active corpus plan name
// origin_count — uint32, corruption seeds from the plan that show row-level tag drift
// blast_count — uint32, distinct table/part pairs in minimal rebuild scope
// touch_count — uint32, slices with valid row tags but watermark behind upstream
// hold_count — uint32, clean slices excluded from scope and refresh
// indirect_hops — uint32, view-layer edge traversals applied during scope expansion
// row_faults — uint32, row-level tag failures detected across all slices
// tardy_count — uint32, slices where late_ms strictly exceeds watermark_ms and enter scope
// plan_seal — lowercase hex SHA-256 of corpus_id|origin_count|blast_count|touch_count|hold_count|indirect_hops|row_faults|tardy_count
//
// Root object contains only these keys.
package main

import (
	"log"
	"os"

	"lab.local/hist_backfill_min/internal/driver"
)

func main() {
	if os.Getenv("TB_HIST_FIXTURE") != "1" {
		log.Fatal("TB_HIST_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/repair_plan.json", rep); err != nil {
		log.Fatal(err)
	}
}
