#!/bin/bash
set -euo pipefail
cd /app && bash /app/scripts/build.sh && TB_HIST_FIXTURE=1 /app/bin/scope_min
