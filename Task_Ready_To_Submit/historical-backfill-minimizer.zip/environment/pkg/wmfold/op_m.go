package wmfold

import "fmt"

// OpM formats a watermark pair for logs.
func OpM(watermarkMS int64, upstreamMS int64) string {
	return fmt.Sprintf("%d/%d", watermarkMS, upstreamMS)
}
