package wmfold

func OpT(watermarkMS int64, upstreamMS int64, rowsValid bool) bool {
	if !rowsValid {
		return true
	}
	if upstreamMS <= watermarkMS {
		return false
	}
	return true
}
