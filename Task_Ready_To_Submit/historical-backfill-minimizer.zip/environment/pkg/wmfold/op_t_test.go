package wmfold

import "testing"

func TestOpTStaleIsRefresh(t *testing.T) {
	if OpT(100, 200, true) {
		t.Fatal("valid stale slice should not enter rebuild scope")
	}
	if !OpT(100, 200, false) {
		t.Fatal("invalid rows must enter rebuild scope")
	}
}
