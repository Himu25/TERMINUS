package graphexp

import (
	"testing"

	"lab.local/hist_backfill_min/pkg/partpkg"
)

func TestOpRIncludesViewHop(t *testing.T) {
	direct := []Edge{{From: "a", To: "b"}}
	view := []Edge{{From: "b", To: "c"}}
	got, hops := OpR(direct, view, partpkg.Key{Table: "a", PartID: "p1"})
	if hops != 1 {
		t.Fatalf("expected one view hop, got %d", hops)
	}
	if len(got) != 2 {
		t.Fatalf("expected two downstream tables, got %+v", got)
	}
}
