package graphexp

// OpS lists direct edges for display only.
func OpS(edges []Edge) []string {
	out := make([]string, 0, len(edges))
	for _, e := range edges {
		out = append(out, e.From+"->"+e.To)
	}
	return out
}
