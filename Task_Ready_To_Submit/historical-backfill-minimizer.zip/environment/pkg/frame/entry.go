package frame

// Row is one partition slice row with an integrity tag.
type Row struct {
	Seq     uint32 `json:"seq"`
	Payload string `json:"payload"`
	Tag     uint16 `json:"tag"`
}
