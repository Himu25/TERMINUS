# Historical backfill minimizer stack

Go driver under `cmd/scope_min` coordinates slice scans, dependency expansion, and plan emission. Rust helpers live in `rowcheck/`. Active fixtures sit under `data/active/`.

Build: `/app/scripts/build.sh`
Run: `TB_HIST_FIXTURE=1 /app/bin/scope_min`
