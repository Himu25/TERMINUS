#ifndef SG_ROW_FOLD_H
#define SG_ROW_FOLD_H

#include <stdint.h>

int32_t rc_fold_u16(uint32_t row_sum, uint16_t stored_tag);

#endif
