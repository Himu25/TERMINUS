package rowcheck

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/librowcheck.a -ldl -lm
#include "row_check.h"
*/
import "C"

import "lab.local/hist_backfill_min/pkg/frame"

func RowMiss(rows []frame.Row) int {
	if len(rows) == 0 {
		return 0
	}
	var sum uint32
	for _, r := range rows {
		sum += r.Seq
	}
	stored := rows[0].Tag
	if C.rc_fold_u16(C.uint(sum), C.ushort(stored)) != 0 {
		return 1
	}
	return 0
}
