# Corpus layout

Tables are keyed by name with slice manifests under `data/active/tables/<table>/<part_id>.json`.
Direct edges model ETL hops; view edges model materialized view layers that do not appear in direct-only walks.

The active plan file names seed slices where corruption was first reported. Row tags use the shared WireCRC helper in `pkg/frame`. Digest replay helper lives at `/app/tools/digest_cli`.
