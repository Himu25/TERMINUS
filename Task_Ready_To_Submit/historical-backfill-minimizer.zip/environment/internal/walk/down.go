package walk

import (
	"lab.local/hist_backfill_min/pkg/graphexp"
	"lab.local/hist_backfill_min/pkg/partpkg"
)

// Downstream returns expanded keys and view-layer hop count.
func Downstream(direct, view []graphexp.Edge, start partpkg.Key) ([]partpkg.Key, uint32) {
	return graphexp.OpR(direct, view, start)
}
