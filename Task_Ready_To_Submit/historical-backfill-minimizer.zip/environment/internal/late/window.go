package late

import (
	"lab.local/hist_backfill_min/internal/config"
	"lab.local/hist_backfill_min/internal/tokfold"
	"lab.local/hist_backfill_min/pkg/partpkg"
)

// WindowOpen reports whether a delayed update window forces scope inclusion.
func WindowOpen(rec config.SliceRecord) bool {
	return tokfold.OpG(rec.WatermarkMS, rec.LateMS)
}

// KeyFromRecord returns the table/part key for a slice record.
func KeyFromRecord(rec config.SliceRecord) partpkg.Key {
	return partpkg.Key{Table: rec.Table, PartID: rec.PartID}
}
