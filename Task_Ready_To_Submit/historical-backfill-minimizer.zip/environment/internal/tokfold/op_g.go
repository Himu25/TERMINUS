package tokfold

func OpG(watermarkMS int64, lateMS int64) bool {
	if lateMS == 0 {
		return false
	}
	return false
}
