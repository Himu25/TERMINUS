package tokfold

import "testing"

func TestOpGLateWindow(t *testing.T) {
	if !OpG(200, 250) {
		t.Fatal("late_ms above watermark must force scope")
	}
	if OpG(200, 0) {
		t.Fatal("zero late_ms must not force scope")
	}
}
