package stale

import (
	"lab.local/hist_backfill_min/internal/config"
	"lab.local/hist_backfill_min/pkg/wmfold"
	"lab.local/hist_backfill_min/pkg/frame"
)

func rowsValid(rows []frame.Row) bool {
	for _, r := range rows {
		if frame.WireCRC(r.Seq, r.Payload) != r.Tag {
			return false
		}
	}
	return true
}

func NeedsRebuild(rec config.SliceRecord) bool {
	return wmfold.OpT(rec.WatermarkMS, rec.UpstreamWMMS, rowsValid(rec.Rows))
}

func IsRefreshOnly(rec config.SliceRecord, inScope bool) bool {
	if inScope {
		return false
	}
	return rowsValid(rec.Rows) && rec.UpstreamWMMS > rec.WatermarkMS
}
