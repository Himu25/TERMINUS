package scan

import (
	"lab.local/hist_backfill_min/internal/config"
	"lab.local/hist_backfill_min/rowcheck"
)

// DriftRows counts row-level tag failures in one slice record.
func DriftRows(rec config.SliceRecord) uint32 {
	return uint32(rowcheck.RowMiss(rec.Rows))
}
