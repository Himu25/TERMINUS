module lab.local/hist_backfill_min

go 1.22
