#!/bin/bash
set -euo pipefail

log() { printf '[oracle] %s\n' "$1"; }

cd /app

log "patch lane paging to honor configured cursor marker and offsets"
cat > /app/src/lane/w1_slice.rs <<'RS'
use crate::axis::v0_tags::ItemView;
use crate::policy::limit::clamp_limit;

#[derive(Clone, Debug)]
pub struct PageSlice {
    pub items: Vec<ItemView>,
    pub next_cursor: Option<String>,
}

/// Apply cursor window on an in-memory catalog vector.
pub fn slice_page(all: &[ItemView], cursor: Option<&str>, limit: u32, marker: &str) -> PageSlice {
    let cap = clamp_limit(limit) as usize;
    let start = (decode_cursor(cursor, marker) as usize).min(all.len());
    let end = (start + cap).min(all.len());
    let items = all[start..end].to_vec();
    let next = if end < all.len() {
        Some(encode_cursor(end as u32, marker))
    } else {
        None
    };
    PageSlice { items, next_cursor: next }
}

pub fn decode_cursor(cursor: Option<&str>, marker: &str) -> u32 {
    let Some(raw) = cursor else {
        return 0;
    };
    let lead = format!("{marker}:");
    if let Some(rest) = raw.strip_prefix(lead.as_str()) {
        return rest.parse().unwrap_or(0);
    }
    0
}

pub fn encode_cursor(offset: u32, marker: &str) -> String {
    format!("{marker}:{offset}")
}
RS

log "add ranged store read beside the full-catalog read"
cat > /app/src/berth/c4_fetch.rs <<'RS'
use rusqlite::{Connection, Result, Row};
use serde::{Deserialize, Serialize};

use crate::io::metrics;

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct RowCore {
    pub id: i64,
    pub sku: String,
    pub tier: i32,
}

fn map_row(row: &Row<'_>) -> Result<RowCore> {
    Ok(RowCore {
        id: row.get(0)?,
        sku: row.get(1)?,
        tier: row.get(2)?,
    })
}

/// Materialize the full catalog slice for downstream paging.
pub fn materialize_catalog(conn: &Connection) -> Result<Vec<RowCore>> {
    metrics::note_db_trip();
    let mut stmt = conn.prepare("SELECT id, sku, tier FROM items ORDER BY id ASC")?;
    let rows = stmt
        .query_map([], map_row)?
        .collect::<Result<Vec<_>>>()?;
    metrics::note_rows(rows.len() as u32);
    Ok(rows)
}

/// Ranged read covering exactly one cursor window.
pub fn materialize_range(conn: &Connection, start: i64, cap: u32) -> Result<Vec<RowCore>> {
    metrics::note_db_trip();
    let mut stmt = conn.prepare(
        "SELECT id, sku, tier FROM items ORDER BY id ASC LIMIT ?1 OFFSET ?2",
    )?;
    let rows = stmt
        .query_map((cap, start), map_row)?
        .collect::<Result<Vec<_>>>()?;
    metrics::note_rows(rows.len() as u32);
    Ok(rows)
}
RS

log "group tag enrichment into one store read per window"
cat > /app/src/axis/v0_tags.rs <<'RS'
use rusqlite::Connection;
use serde::{Deserialize, Serialize};

use crate::berth::c4_fetch::RowCore;
use crate::io::metrics;

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ItemView {
    pub id: i64,
    pub sku: String,
    pub tier: i32,
    pub tags: Vec<String>,
}

pub fn enrich_rows(conn: &Connection, cores: &[RowCore]) -> Vec<ItemView> {
    let mut out = Vec::with_capacity(cores.len());
    for core in cores {
        metrics::note_db_trip();
        let tags = fetch_tags_for_one(conn, core.id);
        out.push(ItemView {
            id: core.id,
            sku: core.sku.clone(),
            tier: core.tier,
            tags,
        });
    }
    out
}

fn fetch_tags_for_one(conn: &Connection, item_id: i64) -> Vec<String> {
    let mut stmt = conn
        .prepare("SELECT tag FROM item_tags WHERE item_id = ?1 ORDER BY tag ASC")
        .expect("tag query");
    let tags = stmt
        .query_map([item_id], |row| row.get::<_, String>(0))
        .expect("tag map")
        .filter_map(Result::ok)
        .collect();
    tags
}

pub fn enrich_rows_grouped(conn: &Connection, cores: &[RowCore]) -> Vec<ItemView> {
    if cores.is_empty() {
        return Vec::new();
    }
    metrics::note_db_trip();
    let ids: Vec<i64> = cores.iter().map(|c| c.id).collect();
    let holes = ids.iter().map(|_| "?").collect::<Vec<_>>().join(",");
    let sql = format!(
        "SELECT item_id, tag FROM item_tags WHERE item_id IN ({}) ORDER BY item_id, tag",
        holes
    );
    let mut stmt = conn.prepare(&sql).expect("grouped tag query");
    let mut by_item: std::collections::BTreeMap<i64, Vec<String>> = std::collections::BTreeMap::new();
    let params: Vec<Box<dyn rusqlite::types::ToSql>> =
        ids.iter().map(|id| Box::new(*id) as Box<dyn rusqlite::types::ToSql>).collect();
    let param_refs: Vec<&dyn rusqlite::types::ToSql> = params.iter().map(|p| p.as_ref()).collect();
    let rows = stmt
        .query_map(param_refs.as_slice(), |row| {
            Ok((row.get::<_, i64>(0)?, row.get::<_, String>(1)?))
        })
        .expect("grouped tag map");
    for row in rows.flatten() {
        by_item.entry(row.0).or_default().push(row.1);
    }
    cores
        .iter()
        .map(|core| ItemView {
            id: core.id,
            sku: core.sku.clone(),
            tier: core.tier,
            tags: by_item.get(&core.id).cloned().unwrap_or_default(),
        })
        .collect()
}
RS

log "bound the memo table with deterministic eviction"
cat > /app/src/pier/b3_cache.rs <<'RS'
use std::collections::{HashMap, VecDeque};

use crate::axis::v0_tags::ItemView;
use crate::io::metrics;

#[derive(Clone)]
pub struct MemoTable {
    slots: HashMap<String, Vec<ItemView>>,
}

impl MemoTable {
    pub fn new() -> Self {
        Self {
            slots: HashMap::new(),
        }
    }

    pub fn lookup(&self, key: &str) -> Option<Vec<ItemView>> {
        self.slots.get(key).cloned()
    }

    pub fn store(&mut self, key: String, rows: Vec<ItemView>) {
        self.slots.insert(key, rows);
        metrics::set_cache_entries(self.slots.len() as u32);
    }

    pub fn len(&self) -> usize {
        self.slots.len()
    }
}

pub struct SlotMemo {
    slots: HashMap<String, Vec<ItemView>>,
    arrival: VecDeque<String>,
    cap: usize,
}

impl SlotMemo {
    pub fn new(cap: usize) -> Self {
        Self {
            slots: HashMap::new(),
            arrival: VecDeque::new(),
            cap,
        }
    }

    pub fn lookup(&self, key: &str) -> Option<Vec<ItemView>> {
        self.slots.get(key).cloned()
    }

    pub fn store(&mut self, key: String, rows: Vec<ItemView>) {
        if !self.slots.contains_key(&key) {
            if self.slots.len() >= self.cap {
                if let Some(oldest) = self.arrival.pop_front() {
                    self.slots.remove(&oldest);
                }
            }
            self.arrival.push_back(key.clone());
        }
        self.slots.insert(key, rows);
        metrics::set_cache_entries(self.slots.len() as u32);
    }
}
RS

log "rewire surge replay for windowed reads, grouped tags, bounded memo"
cat > /app/src/deck/h5_relay.rs <<'RS'
use std::fs;
use std::path::Path;

use serde::{Deserialize, Serialize};

use crate::axis::v0_tags::{enrich_rows_grouped, ItemView};
use crate::berth::c4_fetch::materialize_range;
use crate::io::metrics;
use crate::lane::w1_slice::decode_cursor;
use crate::pier::b3_cache::SlotMemo;
use crate::pier::b3_coalesce::{build_plan, TrafficStep};
use crate::policy::limit::clamp_limit;
use crate::quay::s2_boot::{open_store, seed_from_rows};

#[derive(Debug, Clone, Deserialize)]
pub struct SeedDoc {
    pub rows: Vec<SeedRow>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct SeedRow {
    pub id: i64,
    pub sku: String,
    pub tier: i32,
    pub tags: Vec<String>,
}

#[derive(Debug, Serialize)]
pub struct SurgeAudit {
    pub throughput_band: String,
    pub latency_band: String,
    pub page_fidelity: String,
    pub query_amplification: u32,
    pub batch_efficiency: u32,
    pub row_materialization: u32,
    pub cache_pressure: String,
    pub mix_digest: String,
}

#[derive(Debug)]
struct CatalogProps {
    mix: u32,
    marker: String,
}

fn load_props(path: &str) -> CatalogProps {
    let mut mix = 0u32;
    let mut marker = String::new();
    for line in fs::read_to_string(path).unwrap_or_default().lines() {
        let t = line.trim();
        if t.starts_with('#') || !t.contains('=') {
            continue;
        }
        let (k, v) = t.split_once('=').unwrap();
        match k.trim() {
            "MIX" => mix = v.trim().parse().unwrap_or(0),
            "CURSOR_CORD" => marker = v.trim().to_string(),
            _ => {}
        }
    }
    CatalogProps { mix, marker }
}

fn mix_walk(ids: &[String], seed: u32) -> String {
    let mut acc = seed;
    for id in ids {
        for unit in id.bytes() {
            acc = acc.wrapping_add(u32::from(unit));
            acc = acc.wrapping_mul(16777619);
        }
    }
    format!("{:08x}", acc & 0xffff_ffff)
}

fn throughput_band(db_trips: u32, list_ops: u32) -> String {
    let ratio = if list_ops == 0 {
        999
    } else {
        db_trips / list_ops.max(1)
    };
    if ratio <= 4 {
        "green".into()
    } else if ratio <= 12 {
        "amber".into()
    } else {
        "red".into()
    }
}

fn latency_band(cost: u32) -> String {
    if cost <= 120 {
        "snappy".into()
    } else if cost <= 400 {
        "sluggish".into()
    } else {
        "stalled".into()
    }
}

fn page_fidelity(pages: &[Vec<ItemView>]) -> String {
    if pages.len() < 2 {
        return "steady".into();
    }
    let mut distinct_heads = std::collections::BTreeSet::new();
    for page in pages {
        if let Some(head) = page.first() {
            distinct_heads.insert(head.id);
        }
    }
    if distinct_heads.len() >= 2 {
        "steady".into()
    } else {
        "drifted".into()
    }
}

fn cache_pressure(entries: u32) -> String {
    if entries <= 24 {
        "lean".into()
    } else {
        "heavy".into()
    }
}

pub fn run_surge(
    db_path: &str,
    seed_path: &str,
    traffic_path: &str,
    props_path: &str,
) -> SurgeAudit {
    metrics::reset_counters();
    let props = load_props(props_path);
    let seed: SeedDoc = serde_json::from_str(&fs::read_to_string(seed_path).expect("seed")).expect("seed json");
    let steps: Vec<TrafficStep> =
        serde_json::from_str(&fs::read_to_string(traffic_path).expect("traffic")).expect("traffic json");

    let seed_rows: Vec<(i64, String, i32, Vec<String>)> = seed
        .rows
        .iter()
        .map(|r| (r.id, r.sku.clone(), r.tier, r.tags.clone()))
        .collect();

    let conn = open_store(db_path).expect("open db");
    seed_from_rows(&conn, &seed_rows).expect("seed db");

    let plan = build_plan(&steps);
    let mut memo = SlotMemo::new(24);
    let mut seen_skus: Vec<String> = Vec::new();
    let mut page_snapshots: Vec<Vec<ItemView>> = Vec::new();

    for step in &plan {
        metrics::note_list_op();
        let cap = clamp_limit(step.limit);
        let start = decode_cursor(step.cursor.as_deref(), &props.marker);
        let memo_key = format!("{start}:{cap}");
        let page_items = if let Some(hit) = memo.lookup(&memo_key) {
            hit
        } else {
            let cores = materialize_range(&conn, i64::from(start), cap).expect("ranged read");
            let enriched = enrich_rows_grouped(&conn, &cores);
            memo.store(memo_key, enriched.clone());
            enriched
        };
        for item in &page_items {
            seen_skus.push(item.sku.clone());
        }
        page_snapshots.push(page_items);
    }

    let db_trips = metrics::db_round_trips();
    let rows_mat = metrics::rows_materialized();
    let list_ops = metrics::list_ops().max(1);
    let cost = db_trips.saturating_mul(5).saturating_add(rows_mat / 8);
    let query_amp = db_trips / list_ops;
    let batch_eff = if plan.len() >= 2 && page_fidelity(&page_snapshots) == "steady" {
        2
    } else {
        1
    };

    SurgeAudit {
        throughput_band: throughput_band(db_trips, list_ops),
        latency_band: latency_band(cost),
        page_fidelity: page_fidelity(&page_snapshots),
        query_amplification: query_amp,
        batch_efficiency: batch_eff,
        row_materialization: rows_mat,
        cache_pressure: cache_pressure(metrics::cache_entries()),
        mix_digest: mix_walk(&seen_skus, props.mix),
    }
}

pub fn write_audit(path: &Path, audit: &SurgeAudit) {
    fs::create_dir_all(path.parent().unwrap()).ok();
    let body = serde_json::to_string_pretty(audit).expect("audit json");
    fs::write(path, body).expect("write audit");
}
RS

log "rebuild yard_span witness"
rm -f /app/bin/.yard_span_build_stamp
cargo build --release --manifest-path /app/Cargo.toml
install -d /app/bin /app/output
install -m 0755 /app/target/release/yard_span /app/bin/yard_span
touch -r /app/bin/yard_span /app/bin/.yard_span_build_stamp
chmod +x /app/tools/yard_span /app/bin/yard_span

log "smoke: bundled surge audit"
/app/tools/yard_span
python3 - <<'PY'
import json
from pathlib import Path
audit = json.loads(Path("/app/output/surge_audit.json").read_text())
assert audit["throughput_band"] == "green", audit
assert audit["latency_band"] == "snappy", audit
assert audit["page_fidelity"] == "steady", audit
assert audit["query_amplification"] >= 2, audit
assert audit["batch_efficiency"] >= 2, audit
assert audit["cache_pressure"] == "lean", audit
PY

log "oracle complete"
