#!/bin/bash
set -euo pipefail
cd /app

needs_rebuild() {
  if [[ ! -x /app/bin/yard_span ]]; then
    return 0
  fi
  if [[ ! -f /app/bin/.yard_span_build_stamp ]]; then
    return 0
  fi
  if find /app/src /app/Cargo.toml -newer /app/bin/.yard_span_build_stamp -print -quit 2>/dev/null | grep -q .; then
    return 0
  fi
  if [[ /app/bin/yard_span -nt /app/bin/.yard_span_build_stamp ]]; then
    return 0
  fi
  return 1
}

if needs_rebuild; then
  cargo build --release --manifest-path /app/Cargo.toml
  install -m 0755 /app/target/release/yard_span /app/bin/yard_span
  touch -r /app/bin/yard_span /app/bin/.yard_span_build_stamp
fi

exec /app/bin/yard_span
