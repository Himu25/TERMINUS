"""Verifier for catalog-surge-gate surge_audit contract."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Any

import pytest

APP = Path("/app")
OUT = APP / "output" / "surge_audit.json"
TRAFFIC = APP / "data" / "traffic.json"
SEED = APP / "data" / "seed_rows.json"
STEADY = APP / "docs" / "steady_tokens.txt"
OPENAPI_STUB = APP / "docs" / "openapi_stub.json"
OPENAPI_STUB_SHIPPED = APP / "registry" / "openapi_stub_shipped.json"
FIXTURES = Path("/tests/fixtures")
INVOKER = Path("/tests/invoke_runner.sh")
YARD_BIN = APP / "bin" / "yard_span"

BUNDLED_TRAFFIC = TRAFFIC.read_text(encoding="utf-8")
BUNDLED_SEED = SEED.read_text(encoding="utf-8")


@pytest.fixture(autouse=True)
def restore_lab_bundle() -> None:
    yield
    _atomic_write_text(TRAFFIC, BUNDLED_TRAFFIC)
    _atomic_write_text(SEED, BUNDLED_SEED)


def _steady_token(key: str) -> str:
    for line in STEADY.read_text(encoding="utf-8").splitlines():
        parts = line.strip().split()
        if len(parts) >= 2 and parts[0] == key:
            return parts[-1]
    raise KeyError(key)


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _invoke_yard_span() -> None:
    proc = subprocess.run(
        ["bash", str(INVOKER)],
        capture_output=True,
        text=True,
        check=False,
        cwd="/app",
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _run_probe() -> dict[str, Any]:
    _invoke_yard_span()
    assert OUT.exists(), "expected surge audit at /app/output/surge_audit.json"
    return json.loads(OUT.read_text(encoding="utf-8"))


def _swap_fixture(stem: str) -> None:
    churn = (FIXTURES / f"{stem}.json").read_text(encoding="utf-8")
    users = (FIXTURES / f"{stem}_rows.json").read_text(encoding="utf-8")
    _atomic_write_text(TRAFFIC, churn)
    _atomic_write_text(SEED, users)


def _load_audit_expectation(stem: str) -> dict[str, Any]:
    return json.loads((FIXTURES / f"{stem}_audit.json").read_text(encoding="utf-8"))



def _latency_allowed(want_lat: str) -> tuple[str, ...]:
    if want_lat == "snappy":
        return ("snappy", "sluggish")
    if want_lat == "sluggish":
        return ("sluggish", "stalled")
    return ("stalled", "sluggish")


def _assert_audit_scenario_target(got: dict[str, Any], want: dict[str, Any]) -> None:
    assert got["throughput_band"] == want["throughput_band"]
    assert got["page_fidelity"] == want["page_fidelity"]
    assert got["latency_band"] in _latency_allowed(want["latency_band"])
    q_want = int(want["query_amplification"])
    assert int(got["query_amplification"]) >= max(1, (q_want * 75) // 100)
    assert int(got["batch_efficiency"]) >= int(want.get("batch_efficiency", 1))
    assert abs(int(got["row_materialization"]) - int(want["row_materialization"])) <= 40
    assert len(got["mix_digest"]) == 8
    assert got["mix_digest"][:4] == want["mix_digest"][:4]


def _assert_refresh_storm_target(got: dict[str, Any], want: dict[str, Any]) -> None:
    assert got["throughput_band"] in ("green", "amber", "red")
    assert got["page_fidelity"] == want["page_fidelity"]
    assert got["latency_band"] in _latency_allowed(want["latency_band"])
    q_want = int(want["query_amplification"])
    assert int(got["query_amplification"]) >= max(1, (q_want * 75) // 100)
    assert int(got["batch_efficiency"]) >= 1
    assert abs(int(got["row_materialization"]) - int(want["row_materialization"])) <= 60
    assert len(got["mix_digest"]) == 8
    assert got["mix_digest"][:4] == want["mix_digest"][:4]


def _assert_cross_burst_ping_target(got: dict[str, Any], want: dict[str, Any]) -> None:
    assert got["throughput_band"] in ("green", "amber", "red")
    assert got["page_fidelity"] == want["page_fidelity"]
    assert got["latency_band"] in _latency_allowed(want["latency_band"])
    q_want = int(want["query_amplification"])
    assert int(got["query_amplification"]) >= max(1, (q_want * 60) // 100)
    assert int(got["batch_efficiency"]) >= 1
    assert abs(int(got["row_materialization"]) - int(want["row_materialization"])) <= 80
    assert len(got["mix_digest"]) == 8
    assert got["mix_digest"][:4] == want["mix_digest"][:4]


HARD_BAND_STEMS = [
    "scenario_interleaved_refresh",
    "scenario_limit_ladder",
    "scenario_near_tie_blend",
    "scenario_seven_mark_spiral",
    "scenario_dual_limit_matrix",
    "scenario_cohort_isolation",
    "scenario_heavy_cold_warm",
    "scenario_mixed_refresh_tail",
]


def test_yard_span_rebuilt_from_workspace() -> None:
    """Installed yard_span must not be older than workspace sources after /app/src edits."""
    assert INVOKER.is_file(), "invoke_runner.sh missing"
    assert YARD_BIN.is_file() and os.access(YARD_BIN, os.X_OK), "yard_span binary missing"
    src_newer = subprocess.run(
        [
            "find",
            "/app/src",
            "/app/Cargo.toml",
            "-newer",
            str(YARD_BIN),
            "-print",
            "-quit",
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    assert src_newer.returncode == 0
    assert not src_newer.stdout.strip(), (
        "yard_span at /app/bin/yard_span is older than workspace sources; "
        "rebuild and reinstall after editing /app/src"
    )


def test_bundled_throughput_green() -> None:
    """throughput_band settles to green on the bundled surge replay."""
    data = _run_probe()
    assert data["throughput_band"] == "green"


def test_bundled_latency_snappy() -> None:
    """latency_band reads snappy when store round-trips stay bounded."""
    data = _run_probe()
    assert data["latency_band"] == "snappy"


def test_bundled_page_fidelity_steady() -> None:
    """page_fidelity is steady when cursor windows advance across the catalog."""
    data = _run_probe()
    assert data["page_fidelity"] == "steady"


def test_bundled_query_amplification_floor() -> None:
    """query_amplification meets the bundled floor from steady_tokens.txt."""
    data = _run_probe()
    assert data["query_amplification"] >= 2


def test_bundled_batch_efficiency_floor() -> None:
    """batch_efficiency reflects healthy multi-page replay on bundled traffic."""
    data = _run_probe()
    assert data["batch_efficiency"] >= 2


def test_bundled_row_materialization_window() -> None:
    """row_materialization stays inside the bundled ceiling from steady_tokens.txt."""
    data = _run_probe()
    assert 80 <= data["row_materialization"] <= 160


def test_bundled_cache_pressure_lean() -> None:
    """cache_pressure reads lean when memo growth stays bounded."""
    data = _run_probe()
    assert data["cache_pressure"] == "lean"


def test_bundled_mix_digest_exact() -> None:
    """mix_digest on bundled traffic matches the lab MIX walk (not shape-only)."""
    data = _run_probe()
    assert data["mix_digest"] == _steady_token("bundled_mix_digest")


def test_memo_overflow_cache_pressure_bounded() -> None:
    """35 unique list keys exceed the lean ceiling unless memo eviction is bounded."""
    _swap_fixture("scenario_memo_overflow")
    data = _run_probe()
    assert data["cache_pressure"] == "lean"


def test_openapi_stub_unchanged() -> None:
    """openapi_stub.json must match the shipped copy under registry/."""
    current = json.loads(OPENAPI_STUB.read_text(encoding="utf-8"))
    shipped = json.loads(OPENAPI_STUB_SHIPPED.read_text(encoding="utf-8"))
    assert current == shipped


@pytest.mark.parametrize(
    "stem",
    [
        "scenario_warm_repeat",
        "scenario_cohort_flip",
        "scenario_refresh_tail",
        "scenario_triple_burst",
        "scenario_sparse_catalog",
        "scenario_dual_cohort",
    ],
)
def test_fixture_scenarios(stem: str) -> None:
    """Verifier fixtures keep healthy audit bands after traffic substitution."""
    _swap_fixture(stem)
    data = _run_probe()
    assert data["throughput_band"] in ("green", "amber")
    assert data["latency_band"] in ("snappy", "sluggish")
    assert data["page_fidelity"] == "steady"
    assert data["query_amplification"] >= 2
    assert data["batch_efficiency"] >= 1
    assert len(data["mix_digest"]) == 8


def test_refresh_storm_target_bands() -> None:
    """scenario_refresh_storm follows refresh_storm_* slack in steady_tokens.txt."""
    stem = "scenario_refresh_storm"
    _swap_fixture(stem)
    got = _run_probe()
    want = _load_audit_expectation(stem)
    _assert_refresh_storm_target(got, want)


def test_cross_burst_ping_target_bands() -> None:
    """scenario_cross_burst_ping follows cross_burst_* slack in steady_tokens.txt."""
    stem = "scenario_cross_burst_ping"
    _swap_fixture(stem)
    got = _run_probe()
    want = _load_audit_expectation(stem)
    _assert_cross_burst_ping_target(got, want)


@pytest.mark.parametrize("stem", HARD_BAND_STEMS)
def test_hard_scenario_target_bands(stem: str) -> None:
    """Indexed hard stems must hit oracle replay bands with bounded numeric slack."""
    _swap_fixture(stem)
    got = _run_probe()
    want = _load_audit_expectation(stem)
    _assert_audit_scenario_target(got, want)
