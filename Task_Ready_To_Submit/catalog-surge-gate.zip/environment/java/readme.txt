legacy java client stubs
