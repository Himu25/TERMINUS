Helper scripts for local replays live outside the container image.
