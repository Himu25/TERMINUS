The catalog service exposes list pages over sqlite. Clients pass `limit` and optional `cursor` query parameters. List responses must preserve the JSON field names in `openapi_stub.json`.
