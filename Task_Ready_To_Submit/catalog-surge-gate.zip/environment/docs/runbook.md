# Catalog surge lab

After editing anything under `/app/src`, run `cargo build --release --manifest-path /app/Cargo.toml` and `install -m 0755 /app/target/release/yard_span /app/bin/yard_span`. If any source under `/app/src` is newer than `/app/bin/yard_span`, rebuild and reinstall before replay. Replay bundled traffic with `/app/tools/yard_span`, inspect `/app/output/surge_audit.json`, and compare bands to `steady_tokens.txt`.
