/// Mixer for unrelated batch reports.
pub fn flat_mix(ids: &[u32], seed: u32) -> u32 {
    let mut acc = seed;
    for id in ids {
        acc = acc.wrapping_add(*id);
    }
    acc
}
