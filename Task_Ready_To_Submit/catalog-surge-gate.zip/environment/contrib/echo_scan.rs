/// Token scanner used by offline diagnostics only.
pub fn scan_echo(tokens: &[&str]) -> usize {
    tokens.iter().filter(|t| t.contains("echo")).count()
}
