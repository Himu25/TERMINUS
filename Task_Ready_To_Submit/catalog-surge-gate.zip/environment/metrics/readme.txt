metrics sink placeholder
