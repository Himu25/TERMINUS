use rusqlite::{Connection, Result, Row};
use serde::{Deserialize, Serialize};

use crate::io::metrics;

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct RowCore {
    pub id: i64,
    pub sku: String,
    pub tier: i32,
}

fn map_row(row: &Row<'_>) -> Result<RowCore> {
    Ok(RowCore {
        id: row.get(0)?,
        sku: row.get(1)?,
        tier: row.get(2)?,
    })
}

/// Materialize the full catalog slice for downstream paging.
pub fn materialize_catalog(conn: &Connection) -> Result<Vec<RowCore>> {
    metrics::note_db_trip();
    let mut stmt = conn.prepare("SELECT id, sku, tier FROM items ORDER BY id ASC")?;
    let rows = stmt
        .query_map([], map_row)?
        .collect::<Result<Vec<_>>>()?;
    metrics::note_rows(rows.len() as u32);
    Ok(rows)
}
