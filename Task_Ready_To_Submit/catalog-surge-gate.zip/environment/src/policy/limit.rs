/// Published page cap for list responses.
pub fn max_page_cap() -> u32 {
    50
}

pub fn default_page_cap() -> u32 {
    20
}

pub fn clamp_limit(raw: u32) -> u32 {
    if raw == 0 {
        return default_page_cap();
    }
    raw.min(max_page_cap())
}
