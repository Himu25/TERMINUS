use std::fs;
use std::path::Path;

use serde::{Deserialize, Serialize};

use crate::axis::v0_tags::{enrich_rows, ItemView};
use crate::berth::c4_fetch::materialize_catalog;
use crate::io::metrics;
use crate::lane::w1_slice::slice_page;
use crate::pier::b3_cache::MemoTable;
use crate::pier::b3_coalesce::{build_plan, TrafficStep};
use crate::quay::s2_boot::{open_store, seed_from_rows};

#[derive(Debug, Clone, Deserialize)]
pub struct SeedDoc {
    pub rows: Vec<SeedRow>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct SeedRow {
    pub id: i64,
    pub sku: String,
    pub tier: i32,
    pub tags: Vec<String>,
}

#[derive(Debug, Serialize)]
pub struct SurgeAudit {
    pub throughput_band: String,
    pub latency_band: String,
    pub page_fidelity: String,
    pub query_amplification: u32,
    pub batch_efficiency: u32,
    pub row_materialization: u32,
    pub cache_pressure: String,
    pub mix_digest: String,
}

#[derive(Debug, Deserialize)]
struct CatalogProps {
    mix: u32,
}

fn load_props(path: &str) -> CatalogProps {
    let mut mix = 0u32;
    for line in fs::read_to_string(path).unwrap_or_default().lines() {
        let t = line.trim();
        if t.starts_with('#') || !t.contains('=') {
            continue;
        }
        let (k, v) = t.split_once('=').unwrap();
        if k.trim() == "MIX" {
            mix = v.trim().parse().unwrap_or(0);
        }
    }
    CatalogProps { mix }
}

fn mix_walk(ids: &[String], seed: u32) -> String {
    let mut acc = seed;
    for id in ids {
        for unit in id.bytes() {
            acc = acc.wrapping_add(u32::from(unit));
            acc = acc.wrapping_mul(16777619);
        }
    }
    format!("{:08x}", acc & 0xffff_ffff)
}

fn throughput_band(db_trips: u32, list_ops: u32) -> String {
    let ratio = if list_ops == 0 {
        999
    } else {
        db_trips / list_ops.max(1)
    };
    if ratio <= 4 {
        "green".into()
    } else if ratio <= 12 {
        "amber".into()
    } else {
        "red".into()
    }
}

fn latency_band(cost: u32) -> String {
    if cost <= 120 {
        "snappy".into()
    } else if cost <= 400 {
        "sluggish".into()
    } else {
        "stalled".into()
    }
}

fn page_fidelity(pages: &[Vec<ItemView>]) -> String {
    if pages.len() < 2 {
        return "steady".into();
    }
    let first_head = pages[0].first().map(|v| v.id);
    let mut distinct_heads = std::collections::BTreeSet::new();
    for page in pages {
        if let Some(head) = page.first() {
            distinct_heads.insert(head.id);
        }
    }
    if distinct_heads.len() >= 2 && first_head != pages[1].first().map(|v| v.id) {
        "steady".into()
    } else {
        "drifted".into()
    }
}

fn cache_pressure(entries: u32) -> String {
    if entries <= 24 {
        "lean".into()
    } else {
        "heavy".into()
    }
}

pub fn run_surge(
    db_path: &str,
    seed_path: &str,
    traffic_path: &str,
    props_path: &str,
) -> SurgeAudit {
    metrics::reset_counters();
    let props = load_props(props_path);
    let seed: SeedDoc = serde_json::from_str(&fs::read_to_string(seed_path).expect("seed")).expect("seed json");
    let steps: Vec<TrafficStep> =
        serde_json::from_str(&fs::read_to_string(traffic_path).expect("traffic")).expect("traffic json");

    let seed_rows: Vec<(i64, String, i32, Vec<String>)> = seed
        .rows
        .iter()
        .map(|r| (r.id, r.sku.clone(), r.tier, r.tags.clone()))
        .collect();

    let conn = open_store(db_path).expect("open db");
    seed_from_rows(&conn, &seed_rows).expect("seed db");

    let plan = build_plan(&steps);
    let mut memo = MemoTable::new();
    let mut seen_skus: Vec<String> = Vec::new();
    let mut page_snapshots: Vec<Vec<ItemView>> = Vec::new();

    for step in &plan {
        metrics::note_list_op();
        let cache_key = format!("{:?}:{}", step.cursor, step.limit);
        let page_items = if let Some(hit) = memo.lookup(&cache_key) {
            hit
        } else {
            let cores = materialize_catalog(&conn).expect("catalog");
            let enriched = enrich_rows(&conn, &cores);
            let page = slice_page(&enriched, step.cursor.as_deref(), step.limit);
            memo.store(cache_key, page.items.clone());
            page.items
        };
        for item in &page_items {
            seen_skus.push(item.sku.clone());
        }
        page_snapshots.push(page_items);
    }

    let db_trips = metrics::db_round_trips();
    let rows_mat = metrics::rows_materialized();
    let list_ops = metrics::list_ops().max(1);
    let cost = db_trips.saturating_mul(5).saturating_add(rows_mat / 8);
    let query_amp = db_trips / list_ops;
    let batch_eff = if plan.len() >= 2 && page_fidelity(&page_snapshots) == "steady" {
        2
    } else {
        1
    };

    SurgeAudit {
        throughput_band: throughput_band(db_trips, list_ops),
        latency_band: latency_band(cost),
        page_fidelity: page_fidelity(&page_snapshots),
        query_amplification: query_amp,
        batch_efficiency: batch_eff,
        row_materialization: rows_mat,
        cache_pressure: cache_pressure(metrics::cache_entries()),
        mix_digest: mix_walk(&seen_skus, props.mix),
    }
}

pub fn write_audit(path: &Path, audit: &SurgeAudit) {
    fs::create_dir_all(path.parent().unwrap()).ok();
    let body = serde_json::to_string_pretty(audit).expect("audit json");
    fs::write(path, body).expect("write audit");
}
