use rusqlite::Connection;
use serde::{Deserialize, Serialize};

use crate::berth::c4_fetch::RowCore;
use crate::io::metrics;

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ItemView {
    pub id: i64,
    pub sku: String,
    pub tier: i32,
    pub tags: Vec<String>,
}

pub fn enrich_rows(conn: &Connection, cores: &[RowCore]) -> Vec<ItemView> {
    let mut out = Vec::with_capacity(cores.len());
    for core in cores {
        metrics::note_db_trip();
        let tags = fetch_tags_for_one(conn, core.id);
        out.push(ItemView {
            id: core.id,
            sku: core.sku.clone(),
            tier: core.tier,
            tags,
        });
    }
    out
}

fn fetch_tags_for_one(conn: &Connection, item_id: i64) -> Vec<String> {
    let mut stmt = conn
        .prepare("SELECT tag FROM item_tags WHERE item_id = ?1 ORDER BY tag ASC")
        .expect("tag query");
    let tags = stmt
        .query_map([item_id], |row| row.get::<_, String>(0))
        .expect("tag map")
        .filter_map(Result::ok)
        .collect();
    tags
}
