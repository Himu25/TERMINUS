use rusqlite::{Connection, Result};

use crate::io::metrics;

pub fn open_store(path: &str) -> Result<Connection> {
    let conn = Connection::open(path)?;
    conn.execute_batch(
        "PRAGMA journal_mode=WAL;
         CREATE TABLE IF NOT EXISTS items (
           id INTEGER PRIMARY KEY,
           sku TEXT NOT NULL,
           tier INTEGER NOT NULL
         );
         CREATE TABLE IF NOT EXISTS item_tags (
           item_id INTEGER NOT NULL,
           tag TEXT NOT NULL
         );",
    )?;
    metrics::note_db_trip();
    Ok(conn)
}

pub fn seed_from_rows(conn: &Connection, rows: &[(i64, String, i32, Vec<String>)]) -> Result<()> {
    conn.execute("DELETE FROM item_tags", [])?;
    conn.execute("DELETE FROM items", [])?;
    for (id, sku, tier, tags) in rows {
        conn.execute(
            "INSERT INTO items (id, sku, tier) VALUES (?1, ?2, ?3)",
            (*id, sku, tier),
        )?;
        for tag in tags {
            conn.execute(
                "INSERT INTO item_tags (item_id, tag) VALUES (?1, ?2)",
                (*id, tag),
            )?;
        }
    }
    metrics::note_db_trip();
    Ok(())
}
