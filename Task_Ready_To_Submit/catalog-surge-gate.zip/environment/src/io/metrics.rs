use std::sync::atomic::{AtomicU32, Ordering};

static DB_ROUND_TRIPS: AtomicU32 = AtomicU32::new(0);
static ROWS_MATERIALIZED: AtomicU32 = AtomicU32::new(0);
static CACHE_ENTRIES: AtomicU32 = AtomicU32::new(0);
static LIST_OPS: AtomicU32 = AtomicU32::new(0);

pub fn reset_counters() {
    DB_ROUND_TRIPS.store(0, Ordering::SeqCst);
    ROWS_MATERIALIZED.store(0, Ordering::SeqCst);
    CACHE_ENTRIES.store(0, Ordering::SeqCst);
    LIST_OPS.store(0, Ordering::SeqCst);
}

pub fn note_db_trip() {
    DB_ROUND_TRIPS.fetch_add(1, Ordering::SeqCst);
}

pub fn note_rows(n: u32) {
    ROWS_MATERIALIZED.fetch_add(n, Ordering::SeqCst);
}

pub fn set_cache_entries(n: u32) {
    CACHE_ENTRIES.store(n, Ordering::SeqCst);
}

pub fn note_list_op() {
    LIST_OPS.fetch_add(1, Ordering::SeqCst);
}

pub fn db_round_trips() -> u32 {
    DB_ROUND_TRIPS.load(Ordering::SeqCst)
}

pub fn rows_materialized() -> u32 {
    ROWS_MATERIALIZED.load(Ordering::SeqCst)
}

pub fn cache_entries() -> u32 {
    CACHE_ENTRIES.load(Ordering::SeqCst)
}

pub fn list_ops() -> u32 {
    LIST_OPS.load(Ordering::SeqCst)
}
