use std::collections::HashMap;

use crate::axis::v0_tags::ItemView;
use crate::io::metrics;

#[derive(Clone)]
pub struct MemoTable {
    slots: HashMap<String, Vec<ItemView>>,
}

impl MemoTable {
    pub fn new() -> Self {
        Self {
            slots: HashMap::new(),
        }
    }

    pub fn lookup(&self, key: &str) -> Option<Vec<ItemView>> {
        self.slots.get(key).cloned()
    }

    pub fn store(&mut self, key: String, rows: Vec<ItemView>) {
        self.slots.insert(key, rows);
        metrics::set_cache_entries(self.slots.len() as u32);
    }

    pub fn len(&self) -> usize {
        self.slots.len()
    }
}
