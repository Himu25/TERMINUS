use serde::Deserialize;

#[derive(Debug, Clone, Deserialize)]
pub struct TrafficStep {
    pub op: String,
    #[serde(default)]
    pub limit: u32,
    pub cursor: Option<String>,
}

pub fn build_plan(steps: &[TrafficStep]) -> Vec<TrafficStep> {
    let mut plan = Vec::new();
    for step in steps {
        if step.op == "list" {
            plan.push(step.clone());
        }
    }
    plan
}

/// Merge consecutive list steps that share the same limit into one tick.
pub fn build_plan_coalesced(steps: &[TrafficStep]) -> Vec<Vec<TrafficStep>> {
    let mut plan: Vec<Vec<TrafficStep>> = Vec::new();
    let mut pending: Vec<TrafficStep> = Vec::new();
    for step in steps {
        if step.op == "list" {
            pending.push(step.clone());
        } else if !pending.is_empty() {
            plan.push(pending);
            pending = Vec::new();
        }
    }
    if !pending.is_empty() {
        plan.push(pending);
    }
    plan
}
