use std::path::PathBuf;

use catalog_svc::deck::h5_relay::{run_surge, write_audit};

fn main() {
    let props = "/app/config/catalog.props";
    let traffic = "/app/data/traffic.json";
    let seed = "/app/data/seed_rows.json";
    let db = "/tmp/catalog_surge.db";
    let out = PathBuf::from("/app/output/surge_audit.json");

    let _ = std::fs::remove_file(db);
    let audit = run_surge(db, seed, traffic, props);
    write_audit(&out, &audit);
}
