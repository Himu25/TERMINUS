use crate::axis::v0_tags::ItemView;
use crate::policy::limit::clamp_limit;

#[derive(Clone, Debug)]
pub struct PageSlice {
    pub items: Vec<ItemView>,
    pub next_cursor: Option<String>,
}

/// Apply cursor window on an in-memory catalog vector.
pub fn slice_page(all: &[ItemView], cursor: Option<&str>, limit: u32) -> PageSlice {
    let cap = clamp_limit(limit) as usize;
    let _offset = decode_cursor(cursor);
    let end = cap.min(all.len());
    let items = all[..end].to_vec();
    let next = if end < all.len() {
        Some(encode_cursor(0))
    } else {
        None
    };
    PageSlice { items, next_cursor: next }
}

fn decode_cursor(cursor: Option<&str>) -> u32 {
    let Some(raw) = cursor else {
        return 0;
    };
    if let Some(rest) = raw.strip_prefix("off:") {
        return rest.parse().unwrap_or(0);
    }
    0
}

fn encode_cursor(offset: u32) -> String {
    format!("off:{offset}")
}
