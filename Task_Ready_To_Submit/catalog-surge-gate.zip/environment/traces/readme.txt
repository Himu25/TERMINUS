trace dumps archived offline
