use std::collections::HashMap;
use std::sync::Mutex;

use crate::bench_stats;
use crate::io::{TomlConfig, WeightStore};
use crate::ops::{apply_rotary, gemm, rowwise_softmax};

/// Multi-head attention mix for one block.
pub struct MixAttn {
    ws: WeightStore,
    cfg: TomlConfig,
    kv_cache: Mutex<HashMap<String, Vec<f32>>>,
}

impl MixAttn {
    pub fn new(ws: WeightStore, cfg: TomlConfig) -> Self {
        Self {
            ws,
            cfg,
            kv_cache: Mutex::new(HashMap::new()),
        }
    }

    pub fn mix_heads(
        &self,
        layer: i32,
        session: &str,
        x: &mut [f32],
        seq: usize,
        d_model: usize,
        heads: usize,
        d_head: usize,
    ) -> std::io::Result<()> {
        let layer_s = layer.to_string();
        let d = d_model;
        let wq = self.ws.load_f32(&format!("L{layer_s}_wq.f32.bin"), d, d)?;
        let wk = self.ws.load_f32(&format!("L{layer_s}_wk.f32.bin"), d, d)?;
        let wv = self.ws.load_f32(&format!("L{layer_s}_wv.f32.bin"), d, d)?;
        let wo = self.ws.load_f32(&format!("L{layer_s}_wo.f32.bin"), d, d)?;
        let mut q = vec![0.0f32; seq * d];
        let mut k = vec![0.0f32; seq * d];
        let mut v = vec![0.0f32; seq * d];
        gemm(x, seq, d, &wq, d, &mut q);
        let ck = format!("{session}:{layer}:{seq}");
        let mut cache = self.kv_cache.lock().unwrap();
        if self.cfg.bool("compute.kv_retain") {
            if let Some(packed) = cache.get(&ck) {
                bench_stats::record_kv_cache_hit();
                let klen = k.len();
                k.copy_from_slice(&packed[..klen]);
                v.copy_from_slice(&packed[klen..]);
            } else {
                gemm(x, seq, d, &wk, d, &mut k);
                gemm(x, seq, d, &wv, d, &mut v);
                let mut packed = vec![0.0f32; k.len() + v.len()];
                packed[..k.len()].copy_from_slice(&k);
                packed[k.len()..].copy_from_slice(&v);
                cache.insert(ck, packed);
            }
        } else {
            gemm(x, seq, d, &wk, d, &mut k);
            gemm(x, seq, d, &wv, d, &mut v);
        }
        drop(cache);
        apply_rotary(&mut q, seq, heads, d_head);
        apply_rotary(&mut k, seq, heads, d_head);
        let mut ctx = vec![0.0f32; seq * d];
        let mut scores = vec![0.0f32; seq * heads * seq];
        for t in 0..seq {
            for h in 0..heads {
                let base = (t * heads + h) * seq;
                for s2 in 0..seq {
                    let mut dot = 0.0f32;
                    for dh in 0..d_head {
                        dot += q[(t * heads + h) * d_head + dh] * k[(s2 * heads + h) * d_head + dh];
                    }
                    scores[base + s2] = dot / (d_head as f32).sqrt();
                }
            }
        }
        rowwise_softmax(&mut scores, seq * heads, seq);
        for t in 0..seq {
            for h in 0..heads {
                for dh in 0..d_head {
                    let mut acc = 0.0f32;
                    for s2 in 0..seq {
                        acc += scores[(t * heads + h) * seq + s2] * v[(s2 * heads + h) * d_head + dh];
                    }
                    ctx[(t * heads + h) * d_head + dh] = acc;
                }
            }
        }
        let mut out = vec![0.0f32; seq * d];
        gemm(&ctx, seq, d, &wo, d, &mut out);
        for i in 0..seq * d {
            x[i] += out[i];
        }
        Ok(())
    }
}
