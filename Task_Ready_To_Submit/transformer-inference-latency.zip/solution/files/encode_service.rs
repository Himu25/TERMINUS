use std::collections::VecDeque;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Mutex;

use crate::api::{RequestFrame, ResponseFrame};
use crate::io::{TomlConfig, WeightStore};
use crate::runtime::block::{KernelStage, MixAttn};
use crate::runtime::pending::LaneMux;
use crate::runtime::tensor::ArenaPool;

use super::session_pool::SessionPool;

const D: usize = 32;
const VOCAB: usize = 128;
const LAYERS: i32 = 2;

struct Inflight {
    pending: VecDeque<RequestFrame>,
    waiters: Vec<(u64, std::sync::mpsc::Sender<ResponseFrame>)>,
}

pub struct EncodeService {
    ws: WeightStore,
    mux: LaneMux,
    arena: Mutex<ArenaPool>,
    stage: KernelStage,
    sessions: SessionPool,
    gate: Mutex<Inflight>,
    seq_ids: AtomicU64,
}

impl EncodeService {
    pub fn new(ws: WeightStore, cfg: TomlConfig) -> std::io::Result<Self> {
        let mux = LaneMux::new(cfg.clone());
        let arena = Mutex::new(ArenaPool::new(cfg.clone()));
        let mix = MixAttn::new(ws.clone(), cfg.clone());
        let stage = KernelStage::new(ws.clone(), cfg, mix);
        Ok(Self {
            ws,
            mux,
            arena,
            stage,
            sessions: SessionPool::new(),
            gate: Mutex::new(Inflight {
                pending: VecDeque::new(),
                waiters: Vec::new(),
            }),
            seq_ids: AtomicU64::new(0),
        })
    }

    pub fn encode_one(&self, req: RequestFrame) -> Result<ResponseFrame, String> {
        let id = self.seq_ids.fetch_add(1, Ordering::SeqCst) + 1;
        let (tx, rx) = std::sync::mpsc::channel();
        {
            let mut g = self.gate.lock().map_err(|_| "lock")?;
            g.pending.push_back(req.with_id(id));
            g.waiters.push((id, tx));
            self.drain_unlocked(&mut g)?;
        }
        rx.recv().map_err(|_| "encode failed".to_string())
    }

    fn drain_unlocked(&self, g: &mut Inflight) -> Result<(), String> {
        let batch = self.mux.coalesce_window(&mut g.pending);
        for frame in batch {
            let resp = self.step_emit(&frame).map_err(|e| e.to_string())?;
            if let Some(pos) = g.waiters.iter().position(|(wid, _)| *wid == frame.id) {
                let (_, sender) = g.waiters.remove(pos);
                let _ = sender.send(resp);
            }
        }
        Ok(())
    }

    fn step_emit(&self, req: &RequestFrame) -> std::io::Result<ResponseFrame> {
        self.sessions.bump(&req.session);
        let seq_len = req.tokens.len();
        let mut x = {
            let mut arena = self.arena.lock().unwrap();
            arena.acquire_block(seq_len * D)
        };
        let embed = self.ws.load_f32("embed.f32.bin", VOCAB, D)?;
        for t in 0..seq_len {
            let tok = (req.tokens[t].rem_euclid(VOCAB as i32)) as usize;
            x[t * D..(t + 1) * D].copy_from_slice(&embed[tok * D..(tok + 1) * D]);
        }
        for layer in 0..LAYERS {
            self.stage
                .apply_layer(layer, &req.session, &mut x, seq_len)?;
        }
        let mut logits = self.arena.lock().unwrap().acquire_block(VOCAB);
        let last = seq_len.saturating_sub(1);
        logits[..D].copy_from_slice(&x[last * D..(last + 1) * D]);
        for v in 0..VOCAB {
            let mut sum = 0.0f32;
            for j in 0..D {
                sum += logits[j] * embed[v * D + j];
            }
            logits[v] = sum;
        }
        {
            let mut arena = self.arena.lock().unwrap();
            arena.release_block(x);
        }
        Ok(ResponseFrame::new(logits))
    }
}
