use crate::api::RequestFrame;
use crate::io::TomlConfig;

/// Coalesces pending frames for the worker loop.
pub struct LaneMux {
    cfg: TomlConfig,
}

impl LaneMux {
    pub fn new(cfg: TomlConfig) -> Self {
        Self { cfg }
    }

    pub fn coalesce_window(&self, pending: &mut std::collections::VecDeque<RequestFrame>) -> Vec<RequestFrame> {
        let cap = std::cmp::max(1, self.cfg.integer("batch.max_batch") as usize);
        let mut out = Vec::new();
        let n = cap.min(pending.len());
        for _ in 0..n {
            if let Some(frame) = pending.pop_front() {
                out.push(frame);
            }
        }
        out
    }
}
