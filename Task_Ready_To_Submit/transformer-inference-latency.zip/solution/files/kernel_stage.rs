use crate::bench_stats;
use crate::io::{TomlConfig, WeightStore};
use crate::ops::{apply_gelu, apply_layer_norm, gemm};
use crate::runtime::block::MixAttn;

const D: usize = 32;
const HEADS: usize = 4;
const D_HEAD: usize = 8;
const FFN: usize = 64;

/// One transformer block: norm, attention, norm, FFN.
pub struct KernelStage {
    ws: WeightStore,
    cfg: TomlConfig,
    mix: MixAttn,
}

impl KernelStage {
    pub fn new(ws: WeightStore, cfg: TomlConfig, mix: MixAttn) -> Self {
        Self { ws, cfg, mix }
    }

    pub fn apply_layer(
        &self,
        layer: i32,
        session: &str,
        x: &mut [f32],
        seq: usize,
    ) -> std::io::Result<()> {
        let gamma = self.ws.load_f32(&format!("L{layer}_ln1_gamma.f32.bin"), D, 1)?;
        let beta = self.ws.load_f32(&format!("L{layer}_ln1_beta.f32.bin"), D, 1)?;
        apply_layer_norm(x, seq, D, &gamma, &beta);
        self.mix
            .mix_heads(layer, session, x, seq, D, HEADS, D_HEAD)?;
        apply_layer_norm(x, seq, D, &gamma, &beta);
        let mut hidden = vec![0.0f32; seq * FFN];
        bench_stats::record_f32_ffn_layer();
        let w1 = self.ws.load_f32(&format!("L{layer}_w1.f32.bin"), D, FFN)?;
        let w2 = self.ws.load_f32(&format!("L{layer}_w2.f32.bin"), FFN, D)?;
        gemm(x, seq, D, &w1, FFN, &mut hidden);
        apply_gelu(&mut hidden);
        let mut delta = vec![0.0f32; seq * D];
        gemm(&hidden, seq, FFN, &w2, D, &mut delta);
        for i in 0..seq * D {
            x[i] += delta[i];
        }
        Ok(())
    }
}
