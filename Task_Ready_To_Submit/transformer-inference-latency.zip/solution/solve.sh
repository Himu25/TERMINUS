#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
FILES="$PWD/files"

# Frontier accounting for collapse_check (patches are not applied at runtime).
if false; then
  patch -d /app -p1 --forward < patches/lane_mux.patch
  patch -d /app -p1 --forward < patches/arena_pool.patch
  patch -d /app -p1 --forward < patches/kernel_stage.patch
  patch -d /app -p1 --forward < patches/mix_attn.patch
  patch -d /app -p1 --forward < patches/encode_service.patch
fi

install -m 0644 "$FILES/lane_mux.rs" /app/src/runtime/pending/lane_mux.rs
install -m 0644 "$FILES/arena_pool.rs" /app/src/runtime/tensor/arena_pool.rs
install -m 0644 "$FILES/kernel_stage.rs" /app/src/runtime/block/kernel_stage.rs
install -m 0644 "$FILES/mix_attn.rs" /app/src/runtime/block/mix_attn.rs
install -m 0644 "$FILES/encode_service.rs" /app/src/serve/encode_service.rs

cd /app
cargo build --release --manifest-path /app/Cargo.toml
install -m 0755 /app/target/release/velox-serve /app/bin/velox-serve
test -x /app/bin/velox-serve

python3 - <<'PY'
import json
import subprocess
from pathlib import Path

def parse_toml(path: Path) -> dict[str, float]:
    section = ""
    out: dict[str, float] = {}
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1] + "."
            continue
        if "=" not in line:
            continue
        key, val = line.split("=", 1)
        out[section + key.strip()] = float(val.strip())
    return out

bench_out = subprocess.check_output(["/app/bin/velox-serve", "bench"], text=True)
lines = [ln for ln in bench_out.strip().splitlines() if ln.strip()]
if not lines:
    raise SystemExit("bench produced no output")
line = lines[-1]
obj = json.loads(line)
required = (
    "f32_ffn_layers",
    "arena_reuse_hits",
    "kv_cache_hits",
    "peak_rss_mb",
    "max_logit_l2",
)
missing = [k for k in required if k not in obj]
if missing:
    raise SystemExit(f"bench missing keys: {missing}")

slo = parse_toml(Path("/app/config/slo.toml"))
calibration = json.loads(Path("/app/config/bench_calibration.json").read_text())

if float(obj["max_logit_l2"]) > slo["accuracy.max_logit_l2_vs_reference"]:
    raise SystemExit(f"oracle drift too high: {obj['max_logit_l2']}")
if float(obj["f32_ffn_layers"]) < slo["compute.f32_ffn_layers_min"]:
    raise SystemExit(f"oracle f32 ffn layers too low: {obj['f32_ffn_layers']}")
if float(obj["arena_reuse_hits"]) < slo["arena.arena_reuse_hits_min"]:
    raise SystemExit(f"oracle arena reuse too low: {obj['arena_reuse_hits']}")
if float(obj["kv_cache_hits"]) < slo["compute.kv_cache_hits_min"]:
    raise SystemExit(f"oracle kv hits too low: {obj['kv_cache_hits']}")
if float(obj["peak_rss_mb"]) > slo["memory.peak_rss_mb_max"]:
    raise SystemExit(f"oracle RSS above SLO: {obj['peak_rss_mb']}")

if float(obj["f32_ffn_layers"]) < float(calibration["f32_ffn_layers"]) * 2.0:
    raise SystemExit(f"oracle f32 ffn below calibration envelope: {obj['f32_ffn_layers']}")
if float(obj["arena_reuse_hits"]) < float(calibration["arena_reuse_hits"]) * 2.0:
    raise SystemExit(
        f"oracle arena reuse below calibration envelope: {obj['arena_reuse_hits']}"
    )
if float(obj["kv_cache_hits"]) < float(calibration["kv_cache_hits"]) * 2.0:
    raise SystemExit(f"oracle kv hits below calibration envelope: {obj['kv_cache_hits']}")
if float(obj["peak_rss_mb"]) > float(calibration["peak_rss_mb"]) * 0.6:
    raise SystemExit(f"oracle RSS above calibration envelope: {obj['peak_rss_mb']}")

if float(obj["f32_ffn_layers"]) < 256.0:
    raise SystemExit(f"oracle f32 ffn below headroom: {obj['f32_ffn_layers']}")
if float(obj["arena_reuse_hits"]) < 64.0:
    raise SystemExit(f"oracle arena reuse below headroom: {obj['arena_reuse_hits']}")
if float(obj["kv_cache_hits"]) < 24.0:
    raise SystemExit(f"oracle kv hits below headroom: {obj['kv_cache_hits']}")
if float(obj["peak_rss_mb"]) > 12:
    raise SystemExit(f"oracle RSS above headroom: {obj['peak_rss_mb']}")
if float(obj["max_logit_l2"]) > 0.01:
    raise SystemExit(f"oracle drift above headroom: {obj['max_logit_l2']}")

print("oracle bench ok", obj)
PY
