"""Outcome verifier for velox encoder serve SLO compliance."""

from __future__ import annotations

import json
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import pytest

APP = Path("/app")
SLO = APP / "config" / "slo.toml"
CALIBRATION = APP / "config" / "bench_calibration.json"
SERVE_BIN = APP / "bin" / "velox-serve"
RUN_BENCH = APP / "tools" / "run_bench.sh"
SAMPLES = APP / "samples"

# Published SLO caps (must match /app/config/slo.toml; instruction names these keys).
SLO_F32_FFN_MIN = 64
SLO_ARENA_REUSE_MIN = 32
SLO_KV_HITS_MIN = 8
SLO_RSS_MAX = 15
SLO_L2_MAX = 0.015
VOCAB = 128

# Broken-build calibration envelope; tests require clear separation before SLO caps.
BASELINE_MIN_PROXY_RATIO = 2.0
BASELINE_MAX_RSS_RATIO = 0.6
BASELINE_MAX_DRIFT = 0.05

# Headroom beyond published SLO caps (instruction names these floors/ceilings).
HEADROOM_F32_FFN_MIN = 256
HEADROOM_ARENA_REUSE_MIN = 64
HEADROOM_KV_HITS_MIN = 24
HEADROOM_RSS_MAX = 12
HEADROOM_L2_MAX = 0.01
MAX_ABS_LOGIT_ERR = 0.002
MIN_LOGIT_COSINE = 0.999

PROBE_FILES = sorted(SAMPLES.glob("trace_probe_*.json"))


def _parse_toml(path: Path) -> dict[str, float]:
    section = ""
    out: dict[str, float] = {}
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1] + "."
            continue
        if "=" not in line:
            continue
        key, val = line.split("=", 1)
        out[section + key.strip()] = float(val.strip())
    return out


def _run_bin(mode: str, probe: Path | None = None) -> str:
    cmd = ["/app/bin/velox-serve", mode]
    if probe is not None:
        cmd.append(str(probe))
    proc = subprocess.run(
        cmd,
        cwd=APP,
        check=True,
        capture_output=True,
        text=True,
        timeout=120,
    )
    return proc.stdout.strip()


def _logits_from_encode(probe: Path) -> list[float]:
    body = _run_bin("infer", probe)
    return [float(x) for x in json.loads(body)["logits"]]


def _logits_from_f32ref(probe: Path) -> list[float]:
    body = _run_bin("f32ref", probe)
    return [float(x) for x in json.loads(body)["logits"]]


def _l2(a: list[float], b: list[float]) -> float:
    return sum((x - y) ** 2 for x, y in zip(a, b)) ** 0.5


def _max_abs(a: list[float], b: list[float]) -> float:
    return max(abs(x - y) for x, y in zip(a, b))


def _cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = sum(x * x for x in a) ** 0.5
    nb = sum(y * y for y in b) ** 0.5
    if na == 0.0 or nb == 0.0:
        return 0.0
    return dot / (na * nb)


def _argmax(values: list[float]) -> int:
    best = 0
    for i, v in enumerate(values):
        if v > values[best]:
            best = i
    return best


def _probe_json(probe: Path, session: str | None = None) -> Path:
    if session is None:
        return probe
    raw = json.loads(probe.read_text())
    raw["session"] = session
    tmp = APP / "samples" / f".tmp_{probe.stem}_{session}.json"
    tmp.write_text(json.dumps(raw))
    return tmp


def _is_finite(value: float) -> bool:
    return value == value and -1e100 < value < 1e100


@pytest.fixture(scope="module")
def built_bin() -> None:
    subprocess.run(
        ["cargo", "build", "--release", "--manifest-path", "/app/Cargo.toml"],
        cwd=APP,
        check=True,
        timeout=300,
    )
    subprocess.run(
        ["install", "-m", "0755", "/app/target/release/velox-serve", "/app/bin/velox-serve"],
        check=True,
    )
    assert SERVE_BIN.is_file()


@pytest.fixture(scope="module")
def slo() -> dict[str, float]:
    return _parse_toml(SLO)


@pytest.fixture(scope="module")
def calibration() -> dict[str, float]:
    raw = json.loads(CALIBRATION.read_text())
    return {k: float(v) for k, v in raw.items()}


@pytest.fixture(scope="module")
def bench_metrics(built_bin: None) -> dict[str, float]:
    line = _run_bin("bench").splitlines()[-1]
    return json.loads(line)


@pytest.fixture(scope="module")
def script_bench_metrics(built_bin: None) -> dict[str, float]:
    """Same entrypoint documented for /app/tools/run_bench.sh."""
    proc = subprocess.run(
        ["/app/tools/run_bench.sh"],
        cwd=APP,
        check=True,
        capture_output=True,
        text=True,
        timeout=120,
    )
    line = proc.stdout.strip().splitlines()[-1]
    return json.loads(line)


def test_slo_thresholds_are_published_values(slo: dict[str, float]) -> None:
    """SLO file must keep the published numeric caps the instruction references."""
    assert slo["compute.f32_ffn_layers_min"] == SLO_F32_FFN_MIN
    assert slo["arena.arena_reuse_hits_min"] == SLO_ARENA_REUSE_MIN
    assert slo["compute.kv_cache_hits_min"] == SLO_KV_HITS_MIN
    assert slo["memory.peak_rss_mb_max"] == SLO_RSS_MAX
    assert slo["accuracy.max_logit_l2_vs_reference"] == SLO_L2_MAX


def test_f32_ffn_layers_meets_floor(
    bench_metrics: dict[str, float], slo: dict[str, float], calibration: dict[str, float]
) -> None:
    """FFN layers on the f32 matmul path must meet the SLO floor and beat the broken envelope."""
    floor = slo["compute.f32_ffn_layers_min"]
    envelope_floor = calibration["f32_ffn_layers"] * BASELINE_MIN_PROXY_RATIO
    assert bench_metrics["f32_ffn_layers"] >= SLO_F32_FFN_MIN
    assert bench_metrics["f32_ffn_layers"] >= floor
    assert bench_metrics["f32_ffn_layers"] >= envelope_floor


def test_arena_reuse_hits_meets_floor(
    bench_metrics: dict[str, float], slo: dict[str, float], calibration: dict[str, float]
) -> None:
    """Arena scratch reuse count must meet the SLO floor and beat the broken envelope."""
    floor = slo["arena.arena_reuse_hits_min"]
    envelope_floor = calibration["arena_reuse_hits"] * BASELINE_MIN_PROXY_RATIO
    assert bench_metrics["arena_reuse_hits"] >= SLO_ARENA_REUSE_MIN
    assert bench_metrics["arena_reuse_hits"] >= floor
    assert bench_metrics["arena_reuse_hits"] >= envelope_floor


def test_kv_cache_hits_meets_floor(
    bench_metrics: dict[str, float], slo: dict[str, float], calibration: dict[str, float]
) -> None:
    """KV retention hits must meet the SLO floor and beat the broken envelope."""
    floor = slo["compute.kv_cache_hits_min"]
    envelope_floor = calibration["kv_cache_hits"] * BASELINE_MIN_PROXY_RATIO
    assert bench_metrics["kv_cache_hits"] >= SLO_KV_HITS_MIN
    assert bench_metrics["kv_cache_hits"] >= floor
    assert bench_metrics["kv_cache_hits"] >= envelope_floor


def test_peak_rss_within_cap(
    bench_metrics: dict[str, float], slo: dict[str, float], calibration: dict[str, float]
) -> None:
    """Peak process RSS must stay within the SLO cap and below the broken envelope."""
    cap = slo["memory.peak_rss_mb_max"]
    envelope_cap = calibration["peak_rss_mb"] * BASELINE_MAX_RSS_RATIO
    assert bench_metrics["peak_rss_mb"] <= SLO_RSS_MAX
    assert bench_metrics["peak_rss_mb"] <= cap
    assert bench_metrics["peak_rss_mb"] <= envelope_cap
    assert bench_metrics["peak_rss_mb"] <= 150


def test_logit_drift_within_bound(
    bench_metrics: dict[str, float], slo: dict[str, float], calibration: dict[str, float]
) -> None:
    """Probe-set logit L2 drift must stay within accuracy bounds and below the broken envelope."""
    bound = slo["accuracy.max_logit_l2_vs_reference"]
    envelope_bound = min(calibration["max_logit_l2"], BASELINE_MAX_DRIFT)
    assert bench_metrics["max_logit_l2"] <= SLO_L2_MAX
    assert bench_metrics["max_logit_l2"] <= bound
    assert bench_metrics["max_logit_l2"] <= envelope_bound
    assert bench_metrics["max_logit_l2"] <= 0.05


def test_run_bench_script_meets_slo_caps(
    script_bench_metrics: dict[str, float], calibration: dict[str, float]
) -> None:
    """The run_bench.sh path must satisfy the SLO bundle."""
    assert script_bench_metrics["f32_ffn_layers"] >= SLO_F32_FFN_MIN
    assert (
        script_bench_metrics["f32_ffn_layers"]
        >= calibration["f32_ffn_layers"] * BASELINE_MIN_PROXY_RATIO
    )
    assert script_bench_metrics["arena_reuse_hits"] >= SLO_ARENA_REUSE_MIN
    assert script_bench_metrics["kv_cache_hits"] >= SLO_KV_HITS_MIN
    assert script_bench_metrics["peak_rss_mb"] <= SLO_RSS_MAX
    assert script_bench_metrics["max_logit_l2"] <= SLO_L2_MAX


def test_run_bench_script_exists_and_invokes_bench() -> None:
    """The documented wrapper script must exist and delegate to the packaged bench mode."""
    text = RUN_BENCH.read_text()
    assert "velox-serve" in text
    assert "bench" in text


def test_bench_entrypoints_agree_on_drift(
    bench_metrics: dict[str, float], script_bench_metrics: dict[str, float]
) -> None:
    """Direct binary and run_bench.sh entrypoints must agree on worst-case probe drift."""
    delta = abs(bench_metrics["max_logit_l2"] - script_bench_metrics["max_logit_l2"])
    assert delta <= 0.002


@pytest.mark.parametrize("probe", PROBE_FILES, ids=lambda p: p.stem)
def test_each_probe_logit_l2_vs_f32(probe: Path, built_bin: None) -> None:
    """Every bundled probe must be within the accuracy L2 bound versus the f32 reference path."""
    got = _logits_from_encode(probe)
    ref = _logits_from_f32ref(probe)
    assert len(got) == 128
    assert len(ref) == 128
    drift = _l2(got, ref)
    assert drift <= SLO_L2_MAX
    assert drift <= 0.05


def test_probe_a_logit_l2_vs_f32(built_bin: None) -> None:
    """Primary probe drift must stay within the published accuracy bound."""
    probe = SAMPLES / "trace_probe_a.json"
    assert _l2(_logits_from_encode(probe), _logits_from_f32ref(probe)) <= SLO_L2_MAX


def test_probe_b_logit_l2_vs_f32(built_bin: None) -> None:
    """Secondary probe drift must stay within the published accuracy bound."""
    probe = SAMPLES / "trace_probe_b.json"
    assert _l2(_logits_from_encode(probe), _logits_from_f32ref(probe)) <= SLO_L2_MAX


def test_probe_c_logit_l2_vs_f32(built_bin: None) -> None:
    """Longer-sequence probe drift must stay within the published accuracy bound."""
    probe = SAMPLES / "trace_probe_c.json"
    assert _l2(_logits_from_encode(probe), _logits_from_f32ref(probe)) <= SLO_L2_MAX


def test_encode_is_deterministic_for_probe_a(built_bin: None) -> None:
    """Repeated encodes of the same probe must yield identical logits."""
    probe = SAMPLES / "trace_probe_a.json"
    first = _logits_from_encode(probe)
    second = _logits_from_encode(probe)
    assert len(first) == 128
    assert len(second) == 128
    for a, b in zip(first, second):
        assert abs(a - b) <= 1e-9


def test_encode_logits_are_finite(built_bin: None) -> None:
    """Serve logits must be finite floats, not NaN or infinity."""
    probe = SAMPLES / "trace_probe_a.json"
    for value in _logits_from_encode(probe):
        assert _is_finite(value)


def test_distinct_sessions_keep_probe_accuracy(built_bin: None) -> None:
    """Different session ids on the probe set must each stay within the L2 accuracy bound."""
    drifts = []
    for probe in PROBE_FILES:
        drifts.append(_l2(_logits_from_encode(probe), _logits_from_f32ref(probe)))
    assert max(drifts) <= SLO_L2_MAX
    assert max(drifts) <= 0.05


def test_logits_are_not_all_zero(built_bin: None) -> None:
    """A healthy encode must emit a non-degenerate logit vector."""
    probe = SAMPLES / "trace_probe_a.json"
    logits = _logits_from_encode(probe)
    assert sum(abs(v) for v in logits) > 1.0


def test_bench_reports_f32_ffn_activity(bench_metrics: dict[str, float]) -> None:
    """Bench must record FFN layers executed on the f32 matmul path."""
    assert bench_metrics["f32_ffn_layers"] >= 2.0


def test_bench_reports_arena_reuse_activity(bench_metrics: dict[str, float]) -> None:
    """Bench must record non-zero arena block reuse after warmup."""
    assert bench_metrics["arena_reuse_hits"] >= 1.0


def test_calibration_envelope_is_below_slo(
    bench_metrics: dict[str, float], calibration: dict[str, float]
) -> None:
    """Repaired build must clear both calibration separation and published SLO caps."""
    assert (
        bench_metrics["f32_ffn_layers"]
        >= calibration["f32_ffn_layers"] * BASELINE_MIN_PROXY_RATIO
    )
    assert (
        bench_metrics["arena_reuse_hits"]
        >= calibration["arena_reuse_hits"] * BASELINE_MIN_PROXY_RATIO
    )
    assert (
        bench_metrics["kv_cache_hits"]
        >= calibration["kv_cache_hits"] * BASELINE_MIN_PROXY_RATIO
    )
    assert bench_metrics["peak_rss_mb"] <= calibration["peak_rss_mb"] * BASELINE_MAX_RSS_RATIO


def test_bench_metrics_clear_slo_headroom(bench_metrics: dict[str, float]) -> None:
    """Repaired bench should exceed the instruction headroom floors, not only graze SLO caps."""
    assert bench_metrics["f32_ffn_layers"] >= HEADROOM_F32_FFN_MIN
    assert bench_metrics["arena_reuse_hits"] >= HEADROOM_ARENA_REUSE_MIN
    assert bench_metrics["kv_cache_hits"] >= HEADROOM_KV_HITS_MIN
    assert bench_metrics["peak_rss_mb"] <= HEADROOM_RSS_MAX
    assert bench_metrics["max_logit_l2"] <= HEADROOM_L2_MAX


def test_probe_d_logit_l2_vs_f32(built_bin: None) -> None:
    """Sixteen-token probe drift must stay within the published accuracy bound."""
    probe = SAMPLES / "trace_probe_d.json"
    assert _l2(_logits_from_encode(probe), _logits_from_f32ref(probe)) <= SLO_L2_MAX


def test_session_invariant_logits_for_same_tokens(built_bin: None) -> None:
    """The same token sequence must yield identical logits across different session ids."""
    probe = SAMPLES / "trace_probe_a.json"
    sess_a = _probe_json(probe, "lane-alpha")
    sess_b = _probe_json(probe, "lane-beta")
    try:
        logits_a = _logits_from_encode(sess_a)
        logits_b = _logits_from_encode(sess_b)
        ref = _logits_from_f32ref(probe)
    finally:
        sess_a.unlink(missing_ok=True)
        sess_b.unlink(missing_ok=True)
    assert len(logits_a) == 128
    assert logits_a == logits_b
    assert _l2(logits_a, ref) <= SLO_L2_MAX


def test_concurrent_encodes_meet_accuracy(built_bin: None) -> None:
    """Concurrent encodes on the probe set must each stay within the accuracy bound."""
    drifts: list[float] = []

    def _one_probe(probe: Path) -> float:
        return _l2(_logits_from_encode(probe), _logits_from_f32ref(probe))

    with ThreadPoolExecutor(max_workers=4) as pool:
        futs = [pool.submit(_one_probe, p) for p in PROBE_FILES for _ in range(2)]
        for fut in as_completed(futs):
            drifts.append(fut.result())
    assert max(drifts) <= SLO_L2_MAX
    assert max(drifts) <= HEADROOM_L2_MAX


@pytest.mark.parametrize("probe", PROBE_FILES, ids=lambda p: p.stem)
def test_each_probe_argmax_matches_f32(probe: Path, built_bin: None) -> None:
    """Argmax token on every bundled probe must match the f32 reference forward."""
    got = _logits_from_encode(probe)
    ref = _logits_from_f32ref(probe)
    assert _argmax(got) == _argmax(ref)


@pytest.mark.parametrize("probe", PROBE_FILES, ids=lambda p: p.stem)
def test_each_probe_max_abs_error_vs_f32(probe: Path, built_bin: None) -> None:
    """Maximum absolute logit error versus f32 reference must stay within 0.002."""
    got = _logits_from_encode(probe)
    ref = _logits_from_f32ref(probe)
    assert _max_abs(got, ref) <= MAX_ABS_LOGIT_ERR


@pytest.mark.parametrize("probe", PROBE_FILES, ids=lambda p: p.stem)
def test_each_probe_cosine_similarity_vs_f32(probe: Path, built_bin: None) -> None:
    """Encode logits must be highly aligned with the f32 reference vector."""
    got = _logits_from_encode(probe)
    ref = _logits_from_f32ref(probe)
    assert _cosine(got, ref) >= MIN_LOGIT_COSINE


def test_longest_probe_tighter_drift(built_bin: None) -> None:
    """The longest bundled probe must stay within the tighter 0.01 L2 headroom."""
    probe = SAMPLES / "trace_probe_d.json"
    drift = _l2(_logits_from_encode(probe), _logits_from_f32ref(probe))
    assert drift <= HEADROOM_L2_MAX


def test_all_probes_deterministic_under_load(built_bin: None) -> None:
    """Repeated encodes after a warm-up burst must remain bitwise-stable on probe_a."""
    probe = SAMPLES / "trace_probe_a.json"
    for _ in range(8):
        _logits_from_encode(probe)
    first = _logits_from_encode(probe)
    second = _logits_from_encode(probe)
    assert first == second


def test_script_bench_meets_headroom(script_bench_metrics: dict[str, float]) -> None:
    """The run_bench.sh path must meet the instruction headroom floors and ceilings."""
    assert script_bench_metrics["f32_ffn_layers"] >= HEADROOM_F32_FFN_MIN
    assert script_bench_metrics["arena_reuse_hits"] >= HEADROOM_ARENA_REUSE_MIN
    assert script_bench_metrics["kv_cache_hits"] >= HEADROOM_KV_HITS_MIN
    assert script_bench_metrics["max_logit_l2"] <= HEADROOM_L2_MAX
    assert script_bench_metrics["peak_rss_mb"] <= HEADROOM_RSS_MAX
