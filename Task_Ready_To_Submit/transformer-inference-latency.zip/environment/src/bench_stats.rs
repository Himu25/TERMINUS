use std::sync::atomic::{AtomicU64, Ordering};

static ARENA_REUSE: AtomicU64 = AtomicU64::new(0);
static KV_CACHE_HITS: AtomicU64 = AtomicU64::new(0);
static F32_FFN_LAYERS: AtomicU64 = AtomicU64::new(0);

pub fn reset() {
    ARENA_REUSE.store(0, Ordering::Relaxed);
    KV_CACHE_HITS.store(0, Ordering::Relaxed);
    F32_FFN_LAYERS.store(0, Ordering::Relaxed);
}

pub fn record_f32_ffn_layer() {
    F32_FFN_LAYERS.fetch_add(1, Ordering::Relaxed);
}

pub fn record_arena_reuse() {
    ARENA_REUSE.fetch_add(1, Ordering::Relaxed);
}

pub fn record_kv_cache_hit() {
    KV_CACHE_HITS.fetch_add(1, Ordering::Relaxed);
}

pub fn snapshot() -> (u64, u64, u64) {
    (
        F32_FFN_LAYERS.load(Ordering::Relaxed),
        ARENA_REUSE.load(Ordering::Relaxed),
        KV_CACHE_HITS.load(Ordering::Relaxed),
    )
}
