use crate::io::TomlConfig;

/// Decoy: scheduling helper for offline export tooling, not on the encode hot path.
pub struct BatchPlanner {
    cfg: TomlConfig,
}

impl BatchPlanner {
    pub fn new(cfg: TomlConfig) -> Self {
        Self { cfg }
    }

    pub fn window_ms(&self) -> i32 {
        self.cfg.integer("batch.window_ms")
    }
}
