use std::sync::atomic::{AtomicU64, Ordering};

/// Decoy: counters for offline trace export, not used by encode.
pub struct TraceSampler {
    ticks: AtomicU64,
}

impl TraceSampler {
    pub fn new() -> Self {
        Self {
            ticks: AtomicU64::new(0),
        }
    }

    pub fn mark(&self) {
        self.ticks.fetch_add(1, Ordering::Relaxed);
    }

    pub fn snapshot(&self) -> u64 {
        self.ticks.load(Ordering::Relaxed)
    }
}
