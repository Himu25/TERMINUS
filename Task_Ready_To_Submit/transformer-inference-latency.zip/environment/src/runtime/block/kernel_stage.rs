use crate::bench_stats;
use crate::io::{TomlConfig, WeightStore};
use crate::ops::{apply_gelu, apply_layer_norm, gemm, gemm_i8};
use crate::runtime::block::MixAttn;

const D: usize = 32;
const HEADS: usize = 4;
const D_HEAD: usize = 8;
const FFN: usize = 64;

/// One transformer block: norm, attention, norm, FFN.
pub struct KernelStage {
    ws: WeightStore,
    cfg: TomlConfig,
    mix: MixAttn,
}

impl KernelStage {
    pub fn new(ws: WeightStore, cfg: TomlConfig, mix: MixAttn) -> Self {
        Self { ws, cfg, mix }
    }

    pub fn apply_layer(
        &self,
        layer: i32,
        session: &str,
        x: &mut [f32],
        seq: usize,
    ) -> std::io::Result<()> {
        let gamma = self.ws.load_f32(&format!("L{layer}_ln1_gamma.f32.bin"), D, 1)?;
        let beta = self.ws.load_f32(&format!("L{layer}_ln1_beta.f32.bin"), D, 1)?;
        apply_layer_norm(x, seq, D, &gamma, &beta);
        self.mix
            .mix_heads(layer, session, x, seq, D, HEADS, D_HEAD)?;
        apply_layer_norm(x, seq, D, &gamma, &beta);
        let mut hidden = vec![0.0f32; seq * FFN];
        if self.cfg.bool("compute.prefer_quantized") {
            let b1_raw = self
                .ws
                .load_i8(&format!("L{layer}_w1.i8.bin"), D, FFN)?;
            let b2_raw = self
                .ws
                .load_i8(&format!("L{layer}_w2.i8.bin"), FFN, D)?;
            let b1: Vec<i8> = b1_raw.iter().map(|b| *b as i8).collect();
            let b2: Vec<i8> = b2_raw.iter().map(|b| *b as i8).collect();
            let s1 = self.ws.scale(&format!("L{layer}_w1.scale.f32"))? * 2.0;
            let s2 = self.ws.scale(&format!("L{layer}_w2.scale.f32"))? * 2.0;
            let a_i8 = to_i8_row(x);
            gemm_i8(&a_i8, seq, D, &b1, FFN, s1, 1.0, &mut hidden);
            apply_gelu(&mut hidden);
            let mut delta = vec![0.0f32; seq * D];
            let h_i8 = to_i8_row(&hidden);
            gemm_i8(&h_i8, seq, FFN, &b2, D, s2, 1.0, &mut delta);
            for i in 0..x.len() {
                x[i] += delta[i];
            }
            return Ok(());
        }
        bench_stats::record_f32_ffn_layer();
        let w1 = self.ws.load_f32(&format!("L{layer}_w1.f32.bin"), D, FFN)?;
        let w2 = self.ws.load_f32(&format!("L{layer}_w2.f32.bin"), FFN, D)?;
        gemm(x, seq, D, &w1, FFN, &mut hidden);
        apply_gelu(&mut hidden);
        let mut delta = vec![0.0f32; seq * D];
        gemm(&hidden, seq, FFN, &w2, D, &mut delta);
        for i in 0..x.len() {
            x[i] += delta[i];
        }
        Ok(())
    }
}

fn to_i8_row(x: &[f32]) -> Vec<i8> {
    x.iter()
        .map(|v| {
            let q = (v / 0.08).round() as i32;
            q.clamp(-127, 127) as i8
        })
        .collect()
}
