/// Decoy: experimental block variant retained for ABI compatibility.
pub fn noop_blend(_x: &mut [f32]) {}
