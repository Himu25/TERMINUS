/// Decoy: gating helper used by export tooling, not on the hot encode path.
pub fn blend_gate(a: f32, b: f32, t: f32) -> f32 {
    a * (1.0 - t) + b * t
}
