use std::collections::VecDeque;

use crate::bench_stats;
use crate::io::TomlConfig;

/// Scratch tensor block allocator.
pub struct ArenaPool {
    cfg: TomlConfig,
    free: VecDeque<Vec<f32>>,
}

impl ArenaPool {
    pub fn new(cfg: TomlConfig) -> Self {
        Self {
            cfg,
            free: VecDeque::new(),
        }
    }

    pub fn acquire_block(&mut self, n: usize) -> Vec<f32> {
        if self.cfg.bool("arena.reuse_blocks") {
            if let Some(pos) = self.free.iter().position(|blk| blk.len() >= n) {
                let blk = self.free.remove(pos).unwrap();
                bench_stats::record_arena_reuse();
                let mut exact = vec![0.0f32; n];
                exact.copy_from_slice(&blk[..n]);
                return exact;
            }
        }
        vec![0.0f32; n]
    }

    pub fn release_block(&mut self, block: Vec<f32>) {
        if self.cfg.bool("arena.reuse_blocks") {
            self.free.push_back(block);
        }
    }
}
