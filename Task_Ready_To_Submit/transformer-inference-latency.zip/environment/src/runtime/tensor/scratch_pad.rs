/// Decoy: alternate scratch layout used by export tooling only.
pub fn pad_len(n: usize) -> usize {
    n.next_power_of_two()
}
