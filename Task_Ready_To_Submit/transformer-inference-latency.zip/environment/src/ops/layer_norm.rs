pub fn apply_layer_norm(x: &mut [f32], rows: usize, cols: usize, gamma: &[f32], beta: &[f32]) {
    for r in 0..rows {
        let off = r * cols;
        let mean: f32 = (0..cols).map(|c| x[off + c]).sum::<f32>() / cols as f32;
        let var: f32 =
            (0..cols).map(|c| (x[off + c] - mean).powi(2)).sum::<f32>() / cols as f32;
        let inv = 1.0 / (var + 1e-5f32).sqrt();
        for c in 0..cols {
            let n = (x[off + c] - mean) * inv;
            x[off + c] = n * gamma[c] + beta[c];
        }
    }
}
