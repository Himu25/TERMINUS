pub fn rowwise_softmax(scores: &mut [f32], rows: usize, cols: usize) {
    for r in 0..rows {
        let off = r * cols;
        let max = (0..cols).map(|c| scores[off + c]).fold(f32::NEG_INFINITY, f32::max);
        let mut sum = 0.0f32;
        for c in 0..cols {
            scores[off + c] = (scores[off + c] - max).exp();
            sum += scores[off + c];
        }
        for c in 0..cols {
            scores[off + c] /= sum;
        }
    }
}
