pub fn apply_gelu(x: &mut [f32]) {
    for v in x.iter_mut() {
        let t = (*v as f64 * 0.7978845608) + (0.0356774081 * (*v as f64).powi(3));
        *v = (0.5 * *v as f64 * (1.0 + t.tanh())) as f32;
    }
}
