pub fn gemm(a: &[f32], a_rows: usize, a_cols: usize, b: &[f32], b_cols: usize, out: &mut [f32]) {
    for i in 0..a_rows {
        for j in 0..b_cols {
            let mut sum = 0.0f32;
            for k in 0..a_cols {
                sum += a[i * a_cols + k] * b[k * b_cols + j];
            }
            out[i * b_cols + j] = sum;
        }
    }
}

pub fn gemm_i8(
    a: &[i8],
    a_rows: usize,
    a_cols: usize,
    b: &[i8],
    b_cols: usize,
    scale_a: f32,
    scale_b: f32,
    out: &mut [f32],
) {
    let scale = scale_a * scale_b;
    for i in 0..a_rows {
        for j in 0..b_cols {
            let mut sum = 0i32;
            for k in 0..a_cols {
                sum += i32::from(a[i * a_cols + k]) * i32::from(b[k * b_cols + j]);
            }
            out[i * b_cols + j] = sum as f32 * scale;
        }
    }
}
