pub fn apply_rotary(x: &mut [f32], seq: usize, heads: usize, d_head: usize) {
    for t in 0..seq {
        for h in 0..heads {
            for d in 0..d_head / 2 {
                let theta = (t as f64 / 10000f64.powf((2.0 * d as f64) / d_head as f64)) as f32;
                let cos = theta.cos();
                let sin = theta.sin();
                let base = (t * heads + h) * d_head;
                let x0 = x[base + d];
                let x1 = x[base + d + d_head / 2];
                x[base + d] = x0 * cos - x1 * sin;
                x[base + d + d_head / 2] = x0 * sin + x1 * cos;
            }
        }
    }
}
