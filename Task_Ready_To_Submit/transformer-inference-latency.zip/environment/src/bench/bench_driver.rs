use std::sync::Arc;
use std::thread;

use crate::api::RequestFrame;
use crate::bench::f32_probe;
use crate::bench_stats;
use crate::serve::EncodeService;

pub fn run(svc: Arc<EncodeService>) -> std::io::Result<String> {
    bench_stats::reset();
    let frames = load_probes()?;
    for i in 0..24 {
        let fr = frames[i % frames.len()].clone();
        svc.encode_one(fr).map_err(std::io::Error::other)?;
    }
    let workers = std::cmp::max(
        1,
        std::cmp::min(
            4,
            thread::available_parallelism()
                .map(|n| n.get())
                .unwrap_or(2),
        ),
    );
    let rounds = std::cmp::max(40, 320 / workers);
    let mem0 = used_mb();
    let mut handles = Vec::new();
    for i in 0..workers * rounds {
        let fr = frames[i % frames.len()].clone();
        let worker_svc = Arc::clone(&svc);
        handles.push(thread::spawn(move || {
            worker_svc.encode_one(fr).map_err(std::io::Error::other)
        }));
    }
    for h in handles {
        h.join().unwrap().unwrap();
    }
    let peak = mem0.max(used_mb());
    let max_l2 = probe_drift(svc.as_ref(), &frames)?;
    let (f32_ffn_layers, arena_reuse, kv_hits) = bench_stats::snapshot();
    Ok(format!(
        "{{\"f32_ffn_layers\":{f32_ffn_layers},\"arena_reuse_hits\":{arena_reuse},\"kv_cache_hits\":{kv_hits},\"peak_rss_mb\":{peak},\"max_logit_l2\":{max_l2:.6}}}"
    ))
}

fn load_probes() -> std::io::Result<Vec<RequestFrame>> {
    let mut out = Vec::new();
    let mut paths: Vec<_> = std::fs::read_dir("/app/samples")?
        .filter_map(|e| e.ok())
        .map(|e| e.path())
        .filter(|p| {
            p.file_name()
                .and_then(|n| n.to_str())
                .map(|n| n.starts_with("trace_probe_"))
                .unwrap_or(false)
        })
        .collect();
    paths.sort();
    for p in paths {
        let json = std::fs::read_to_string(p)?;
        out.push(RequestFrame::from_json(&json, 0).map_err(std::io::Error::other)?);
    }
    Ok(out)
}

fn probe_drift(svc: &EncodeService, frames: &[RequestFrame]) -> std::io::Result<f64> {
    let mut worst = 0.0f64;
    for fr in frames {
        let got = svc.encode_one(fr.clone()).map_err(std::io::Error::other)?;
        let reference = f32_probe::run(fr)?;
        worst = worst.max(l2(&got.logits, &reference));
    }
    Ok(worst)
}

fn l2(a: &[f32], b: &[f32]) -> f64 {
    a.iter()
        .zip(b.iter())
        .map(|(x, y)| {
            let d = f64::from(*x) - f64::from(*y);
            d * d
        })
        .sum::<f64>()
        .sqrt()
}

fn used_mb() -> u64 {
    let page = 4096u64;
    if let Ok(s) = std::fs::read_to_string("/proc/self/statm") {
        if let Some(pages) = s.split_whitespace().nth(1) {
            if let Ok(n) = pages.parse::<u64>() {
                return n * page / (1024 * 1024);
            }
        }
    }
    0
}
