use std::path::Path;

use crate::api::RequestFrame;
use crate::io::{TomlConfig, WeightStore};
use crate::runtime::block::{KernelStage, MixAttn};
use crate::runtime::tensor::ArenaPool;

const D: usize = 32;
const VOCAB: usize = 128;
const LAYERS: i32 = 2;

/// F32-only probe path for drift measurement (ignores fast numeric paths).
pub fn run(req: &RequestFrame) -> std::io::Result<Vec<f32>> {
    let mut ref_cfg = TomlConfig::load(Path::new("/app/config/runtime.toml"))?;
    ref_cfg.set("compute.prefer_quantized", "false");
    let ws = WeightStore::open(Path::new("/app/weights"));
    let mut arena = ArenaPool::new(ref_cfg.clone());
    let mix = MixAttn::new(ws.clone(), ref_cfg.clone());
    let stage = KernelStage::new(ws.clone(), ref_cfg, mix);
    let seq = req.tokens.len();
    let mut x = arena.acquire_block(seq * D);
    let embed = ws.load_f32("embed.f32.bin", VOCAB, D)?;
    for t in 0..seq {
        let tok = (req.tokens[t].rem_euclid(VOCAB as i32)) as usize;
        x[t * D..(t + 1) * D].copy_from_slice(&embed[tok * D..(tok + 1) * D]);
    }
    for layer in 0..LAYERS {
        stage.apply_layer(layer, &req.session, &mut x, seq)?;
    }
    let mut logits = vec![0.0f32; VOCAB];
    let last = seq.saturating_sub(1);
    logits[..D].copy_from_slice(&x[last * D..(last + 1) * D]);
    for v in 0..VOCAB {
        let mut sum = 0.0f32;
        for j in 0..D {
            sum += logits[j] * embed[v * D + j];
        }
        logits[v] = sum;
    }
    Ok(logits)
}
