mod api;
mod bench;
mod bench_stats;
mod bootstrap;
mod io;
mod ops;
mod runtime;
mod serve;

fn main() {
    if let Err(code) = bootstrap::run() {
        std::process::exit(code);
    }
}
