use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};

#[derive(Clone)]
pub struct WeightStore {
    inner: Arc<WeightStoreInner>,
}

struct WeightStoreInner {
    root: PathBuf,
    f32_cache: Mutex<HashMap<String, Vec<f32>>>,
    i8_cache: Mutex<HashMap<String, Vec<u8>>>,
    scale_cache: Mutex<HashMap<String, f32>>,
}

impl WeightStore {
    pub fn open(root: &Path) -> Self {
        Self {
            inner: Arc::new(WeightStoreInner {
                root: root.to_path_buf(),
                f32_cache: Mutex::new(HashMap::new()),
                i8_cache: Mutex::new(HashMap::new()),
                scale_cache: Mutex::new(HashMap::new()),
            }),
        }
    }

    pub fn load_f32(&self, name: &str, rows: usize, cols: usize) -> std::io::Result<Vec<f32>> {
        let key = format!("{name}:{rows}x{cols}");
        let mut cache = self.inner.f32_cache.lock().unwrap();
        if let Some(hit) = cache.get(&key) {
            return Ok(hit.clone());
        }
        let loaded = read_f32(&self.inner.root.join(name), rows * cols)?;
        cache.insert(key, loaded.clone());
        Ok(loaded)
    }

    pub fn load_i8(&self, name: &str, rows: usize, cols: usize) -> std::io::Result<Vec<u8>> {
        let key = format!("{name}:{rows}x{cols}");
        let mut cache = self.inner.i8_cache.lock().unwrap();
        if let Some(hit) = cache.get(&key) {
            return Ok(hit.clone());
        }
        let loaded = std::fs::read(self.inner.root.join(name))?;
        let _ = (rows, cols);
        cache.insert(key, loaded.clone());
        Ok(loaded)
    }

    pub fn scale(&self, name: &str) -> std::io::Result<f32> {
        let mut cache = self.inner.scale_cache.lock().unwrap();
        if let Some(hit) = cache.get(name) {
            return Ok(*hit);
        }
        let raw = std::fs::read(self.inner.root.join(name))?;
        let val = f32::from_le_bytes(raw[..4].try_into().unwrap());
        cache.insert(name.to_string(), val);
        Ok(val)
    }
}

fn read_f32(path: &Path, n: usize) -> std::io::Result<Vec<f32>> {
    let raw = std::fs::read(path)?;
    let mut out = Vec::with_capacity(n);
    for chunk in raw.chunks_exact(4).take(n) {
        out.push(f32::from_le_bytes(chunk.try_into().unwrap()));
    }
    Ok(out)
}
