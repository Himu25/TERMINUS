use std::collections::HashMap;
use std::path::Path;

#[derive(Clone)]
pub struct TomlConfig {
    flat: HashMap<String, String>,
}

impl TomlConfig {
    pub fn load(path: &Path) -> std::io::Result<Self> {
        let text = std::fs::read_to_string(path)?;
        let mut flat = HashMap::new();
        let mut section = String::new();
        for line in text.lines() {
            let line = line.trim();
            if line.is_empty() || line.starts_with('#') {
                continue;
            }
            if line.starts_with('[') && line.ends_with(']') {
                section = format!("{}.", &line[1..line.len() - 1]);
                continue;
            }
            let Some((k, v)) = line.split_once('=') else {
                continue;
            };
            flat.insert(format!("{}{}", section, k.trim()), v.trim().to_string());
        }
        Ok(Self { flat })
    }

    pub fn bool(&self, key: &str) -> bool {
        self.flat
            .get(key)
            .map(|v| v == "true")
            .unwrap_or(false)
    }

    pub fn integer(&self, key: &str) -> i32 {
        self.flat
            .get(key)
            .and_then(|v| v.parse().ok())
            .unwrap_or(0)
    }

    pub fn fork(&self) -> Self {
        Self {
            flat: self.flat.clone(),
        }
    }

    pub fn set(&mut self, key: &str, value: &str) {
        self.flat.insert(key.to_string(), value.to_string());
    }
}
