use std::path::Path;
use std::sync::Arc;

use crate::api::{RequestFrame, ResponseFrame};
use crate::bench::run as bench_run;
use crate::bench::f32_probe;
use crate::io::{TomlConfig, WeightStore};
use crate::serve::EncodeService;

pub fn run() -> Result<(), i32> {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 2 {
        eprintln!("usage: bench | infer <tokens.json> | f32ref <tokens.json>");
        return Err(2);
    }
    let runtime = TomlConfig::load(Path::new("/app/config/runtime.toml"))
        .map_err(|_| 2)?;
    let store = WeightStore::open(Path::new("/app/weights"));
    let svc = Arc::new(
        EncodeService::new(store, runtime).map_err(|_| 2)?,
    );
    match args[1].as_str() {
        "bench" => {
            let _slo = TomlConfig::load(Path::new("/app/config/slo.toml")).map_err(|_| 2)?;
            let line = bench_run(svc).map_err(|_| 2)?;
            println!("{line}");
            Ok(())
        }
        "infer" if args.len() == 3 => {
            let json = std::fs::read_to_string(&args[2]).map_err(|_| 2)?;
            let req = RequestFrame::from_json(&json, 0).map_err(|_| 2)?;
            let resp = svc.encode_one(req).map_err(|_| 2)?;
            println!("{}", resp.to_json());
            Ok(())
        }
        "f32ref" if args.len() == 3 => {
            let json = std::fs::read_to_string(&args[2]).map_err(|_| 2)?;
            let req = RequestFrame::from_json(&json, 0).map_err(|_| 2)?;
            let logits = f32_probe::run(&req).map_err(|_| 2)?;
            println!("{}", ResponseFrame::new(logits).to_json());
            Ok(())
        }
        _ => {
            eprintln!("unknown mode");
            Err(2)
        }
    }
}
