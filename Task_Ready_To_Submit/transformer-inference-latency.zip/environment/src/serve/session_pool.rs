use std::collections::HashMap;
use std::sync::Mutex;

pub struct SessionPool {
    versions: Mutex<HashMap<String, i32>>,
}

impl SessionPool {
    pub fn new() -> Self {
        Self {
            versions: Mutex::new(HashMap::new()),
        }
    }

    pub fn bump(&self, session: &str) -> i32 {
        let mut v = self.versions.lock().unwrap();
        let next = v.get(session).copied().unwrap_or(0) + 1;
        v.insert(session.to_string(), next);
        next
    }
}
