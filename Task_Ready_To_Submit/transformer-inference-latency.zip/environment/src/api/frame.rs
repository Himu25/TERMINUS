use std::fmt::Write as _;

#[derive(Clone)]
pub struct RequestFrame {
    pub id: u64,
    pub session: String,
    pub tokens: Vec<i32>,
}

impl RequestFrame {
    pub fn with_id(&self, new_id: u64) -> Self {
        Self {
            id: new_id,
            session: self.session.clone(),
            tokens: self.tokens.clone(),
        }
    }

    pub fn from_json(json: &str, id: u64) -> Result<Self, String> {
        let session = extract_quoted(json, "session").unwrap_or_else(|| "default".to_string());
        let tokens = extract_tokens(json)?;
        Ok(Self { id, session, tokens })
    }
}

pub struct ResponseFrame {
    pub logits: Vec<f32>,
}

impl ResponseFrame {
    pub fn new(logits: Vec<f32>) -> Self {
        Self { logits }
    }

    pub fn to_json(&self) -> String {
        let mut sb = String::from("{\"logits\":[");
        for (i, v) in self.logits.iter().enumerate() {
            if i > 0 {
                sb.push(',');
            }
            let _ = write!(sb, "{v:.8}");
        }
        sb.push_str("]}");
        sb
    }
}

fn extract_quoted(json: &str, key: &str) -> Option<String> {
    let needle = format!("\"{key}\"");
    let start = json.find(&needle)?;
    let after = &json[start + needle.len()..];
    let colon = after.find(':')?;
    let rest = after[colon + 1..].trim_start();
    if !rest.starts_with('"') {
        return None;
    }
    let inner = &rest[1..];
    let end = inner.find('"')?;
    Some(inner[..end].to_string())
}

fn extract_tokens(json: &str) -> Result<Vec<i32>, String> {
    let key = "\"tokens\"";
    let start = json.find(key).ok_or_else(|| "missing tokens".to_string())?;
    let after = &json[start + key.len()..];
    let bracket = after.find('[').ok_or_else(|| "missing tokens".to_string())?;
    let inner = &after[bracket + 1..];
    let close = inner.find(']').ok_or_else(|| "missing tokens".to_string())?;
    let body = inner[..close].trim();
    if body.is_empty() {
        return Ok(Vec::new());
    }
    body.split(',')
        .map(|p| p.trim().parse::<i32>().map_err(|_| "bad token".to_string()))
        .collect()
}
