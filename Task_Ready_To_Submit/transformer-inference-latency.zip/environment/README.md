Velox encoder serve prototype. Build with `cargo build --release` from `/app`. See `docs/architecture.md`.
