#!/usr/bin/env bash
set -euo pipefail
cd /app
BIN="/app/bin/velox-serve"
if [[ ! -x "$BIN" ]]; then
  cargo build --release --manifest-path /app/Cargo.toml
  install -m 0755 /app/target/release/velox-serve "$BIN"
fi
exec "$BIN" bench
