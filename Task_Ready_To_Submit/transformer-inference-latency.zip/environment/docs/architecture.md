# Velox serve stack

Rust crate rooted at `/app`. Sources live under `src/` with modules for API frames, weight I/O, math ops, runtime paths, serve loop, and bench harness.

- Serve loop — request lifecycle and session routing
- Scratch allocator — activation block lifecycle under `runtime/tensor`
- Block math — attention and FFN stages under `runtime/forward`
- Weight I/O — tensor blobs under `/app/weights`
- Bench harness — load generator used by `bench` CLI mode

Configs: `/app/config/runtime.toml` (runtime knobs), `/app/config/slo.toml` (external targets with keys `compute.f32_ffn_layers_min`, `compute.kv_cache_hits_min`, `arena.arena_reuse_hits_min`, `memory.peak_rss_mb_max`, `accuracy.max_logit_l2_vs_reference`).

Probe traces live under `/app/samples/trace_probe_*.json`.
