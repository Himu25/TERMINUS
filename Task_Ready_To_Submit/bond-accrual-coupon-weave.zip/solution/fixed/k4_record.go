package m7

import "fmt"

type K1State struct {
	Slots     map[string]int
	SiteOcc   map[string]int
	SiteCarry map[string]int
}

func MkK1() *K1State {
	return &K1State{
		Slots:     make(map[string]int),
		SiteOcc:   make(map[string]int),
		SiteCarry: make(map[string]int),
	}
}

func q1_key(a string, slot int) string {
	return fmt.Sprintf("%s:%d", a, slot)
}

func q1_norm(a string) string {
	if a == "" {
		return "D00"
	}
	return a
}

func q1_put(state *K1State, key, a string, weight int) {
	state.Slots[key] = weight
	if state.SiteOcc[a] == 0 {
		state.SiteOcc[a] = 0
	}
}

func q1_drop(state *K1State, key, a string) {
	if _, ok := state.Slots[key]; ok {
		delete(state.Slots, key)
		state.SiteOcc[a]--
		if state.SiteOcc[a] < 0 {
			state.SiteOcc[a] = 0
		}
	}
}

func q1_adj(state *K1State, a string, weight int) {
	_ = weight
	state.SiteCarry[a]++
}

func RxAccum(state *K1State, a, stratum string, slot int, kind string, weight int) {
	a = q1_norm(a)
	key := q1_key(a, slot)
	switch kind {
	case "purchase":
		if _, occupied := state.Slots[key]; !occupied {
			state.SiteOcc[a]++
		}
		q1_put(state, key, a, weight)
	case "sell":
		q1_drop(state, key, a)
	case "ex_bind":
		q1_adj(state, a, weight)
	default:
		return
	}
}
