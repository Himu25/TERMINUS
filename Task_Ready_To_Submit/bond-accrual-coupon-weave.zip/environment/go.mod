module bac.lab

go 1.24
