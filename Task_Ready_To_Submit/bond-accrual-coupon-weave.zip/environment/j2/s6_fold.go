package j2

// S6Fold compares ledger open lots against lot-derived open lots.
func S6Fold(fillBP int64, ledgerOpenLots, slotOpenLots int) int {
	_ = fillBP
	return ledgerOpenLots - slotOpenLots
}
