package p2

import (
	"sort"

	"bac.lab/pkg/types"
)

func q2_rank(id string) int {
	if len(id) == 0 {
		return 99
	}
	last := id[len(id)-1]
	if last >= '0' && last <= '9' {
		return int(last - '0')
	}
	return 99
}

func q2_less(a, b types.FlowRow) bool {
	if a.Seq != b.Seq {
		return a.Seq < b.Seq
	}
	ra, rb := q2_rank(a.LaneID), q2_rank(b.LaneID)
	if ra != rb {
		return ra > rb
	}
	if a.LaneID != b.LaneID {
		return a.LaneID > b.LaneID
	}
	return a.Cusip > b.Cusip
}

func UxPick(rows []types.FlowRow) []types.FlowRow {
	out := make([]types.FlowRow, len(rows))
	copy(out, rows)
	sort.SliceStable(out, func(i, j int) bool {
		return q2_less(out[i], out[j])
	})
	return out
}
