Bond desk ladder replay semantics

Accrued cents per desk use trade notional_cents times the cusip coupon arm from /app/data/rungs_layout.json (cusip_coupon_centi_pct: centi-percent units, not standard basis points). Scale with divisor 100: accrued_cents = notional_cents * arm / 100 (e.g. US912828Y2 arm 120 on a 12000-cent purchase accrues 14400 cents). Purchase events add accrued cents; sell events subtract the same coupon arm used at placement.

Coupon window peak per desk is the maximum open ex-date window load: notional_cents times the lot coupon-window scale from /app/config/desk.toml divided by 1000.

Open lots counts distinct occupied lots per desk after replay. Ex-bind miss increments per desk on ex_bind events and feeds ex_bind_miss_total. Drift units compare ledger open lots against lot-derived open lots for each desk.

Lane tie-break: when seq values match, lower lane_id runs first when lane_priority_asc is true in /app/config/desk.toml.

Report JSON top-level fields: status, events_processed, report_ok, max_drift_units, accrued_total_cents, coupon_window_peak, ex_bind_miss_total, open_lots_total, report_digest, desks, rungs. Each desk row carries desk_id, accrued_cents, coupon_window_peak, open_lots, drift_units. Each rung row carries cusip, filled, accrual_ratio_bp, drift_units. Report digest is 64 lowercase hex from compact JSON with report_digest blanked.
