package summ

import "bac.lab/pkg/types"

// S8Fold totals fill basis points across site snapshots.
func S8Fold(desks []types.DeskSnapshot) int64 {
	var sum int64
	for _, site := range desks {
		sum += site.AccruedCents
	}
	return sum
}
