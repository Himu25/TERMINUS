// LadderReport is written to /app/output/ladder_report.json by bondladder.
// Top-level keys: status, events_processed, report_ok, max_drift_units,
// accrued_total_cents, coupon_window_peak, ex_bind_miss_total, open_lots_total,
// report_digest, desks, rungs.
package types

type DeskCfg struct {
	MaxDriftUnits          int
	MaxCouponWindowPeak    int
	MinOpenLotsTotal       int
	LanePriorityAsc        bool
	CouponWindowScaleMilli map[int]int
}

type RungsLayout struct {
	CusipCouponCentiPct map[string]int `json:"cusip_coupon_centi_pct"`
}

type FlowRow struct {
	EventID       string `json:"event_id"`
	Seq           int    `json:"seq"`
	LaneID        string `json:"lane_id"`
	DeskID        string `json:"desk_id"`
	Cusip         string `json:"cusip"`
	Lot           int    `json:"lot"`
	EventType     string `json:"event_type"`
	NotionalCents int    `json:"notional_cents"`
}

type DeskSnapshot struct {
	DeskID           string `json:"desk_id"`
	AccruedCents     int64  `json:"accrued_cents"`
	CouponWindowPeak int    `json:"coupon_window_peak"`
	OpenLots         int    `json:"open_lots"`
	DriftUnits       int    `json:"drift_units"`
}

type RungSnapshot struct {
	Cusip          string `json:"cusip"`
	Filled         int    `json:"filled"`
	AccrualRatioBP int    `json:"accrual_ratio_bp"`
	DriftUnits     int    `json:"drift_units"`
}

type LadderReport struct {
	Status              string           `json:"status"`
	EventsProcessed     int              `json:"events_processed"`
	ReportOK            bool             `json:"report_ok"`
	MaxDriftUnits       int              `json:"max_drift_units"`
	AccruedTotalCents   int64            `json:"accrued_total_cents"`
	CouponWindowPeak    int              `json:"coupon_window_peak"`
	ExBindMissTotal     int              `json:"ex_bind_miss_total"`
	OpenLotsTotal       int              `json:"open_lots_total"`
	ReportDigest        string           `json:"report_digest"`
	Desks               []DeskSnapshot   `json:"desks"`
	Rungs               []RungSnapshot   `json:"rungs"`
}
