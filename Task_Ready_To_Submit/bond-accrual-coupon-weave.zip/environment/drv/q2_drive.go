package drv

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"sort"
	"strings"

	"bac.lab/j2"
	"bac.lab/m7"
	"bac.lab/p2"
	"bac.lab/pkg/types"
	"bac.lab/s4"
)

func LoadCfg(path string) (types.DeskCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.DeskCfg{}, err
	}
	cfg := types.DeskCfg{
		MaxDriftUnits:      0,
		MaxCouponWindowPeak:     50000,
		MinOpenLotsTotal:   1,
		LanePriorityAsc: true,
		CouponWindowScaleMilli: map[int]int{
			1: 120,
			2: 240,
			3: 360,
		},
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "max_drift_units":
			fmt.Sscanf(val, "%d", &cfg.MaxDriftUnits)
		case "max_coupon_window_peak":
			fmt.Sscanf(val, "%d", &cfg.MaxCouponWindowPeak)
		case "min_open_lots_total":
			fmt.Sscanf(val, "%d", &cfg.MinOpenLotsTotal)
		case "lane_priority_asc":
			cfg.LanePriorityAsc = val == "true" || val == "1"
		case "coupon_window_scale_lot1":
			var v int
			fmt.Sscanf(val, "%d", &v)
			cfg.CouponWindowScaleMilli[1] = v
		case "coupon_window_scale_lot2":
			var v int
			fmt.Sscanf(val, "%d", &v)
			cfg.CouponWindowScaleMilli[2] = v
		case "coupon_window_scale_lot3":
			var v int
			fmt.Sscanf(val, "%d", &v)
			cfg.CouponWindowScaleMilli[3] = v
		}
	}
	return cfg, nil
}

func LoadLayout(path string) (types.RungsLayout, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.RungsLayout{}, err
	}
	var layout struct {
		CusipCouponCentiPct map[string]int `json:"cusip_coupon_centi_pct"`
	}
	if err := json.Unmarshal(raw, &layout); err != nil {
		return types.RungsLayout{}, err
	}
	return types.RungsLayout{CusipCouponCentiPct: layout.CusipCouponCentiPct}, nil
}

func LoadEvents(path string) ([]types.FlowRow, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.FlowRow, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var row types.FlowRow
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return nil, err
		}
		out = append(out, row)
	}
	return out, sc.Err()
}

func opCode(kind string) int {
	if kind == "sell" {
		return 1
	}
	return 0
}

func pendingFor(weight, slot int, cfg types.DeskCfg) int {
	scale, ok := cfg.CouponWindowScaleMilli[slot]
	if !ok {
		scale = 100
	}
	return weight * scale / 1000
}

func sitePeakPending(site string, slots map[string]slotInfo, cfg types.DeskCfg) int {
	peak := 0
	for key, info := range slots {
		if !strings.HasPrefix(key, site+":") {
			continue
		}
		val := pendingFor(info.weight, info.slot, cfg)
		if val > peak {
			peak = val
		}
	}
	return peak
}

type slotInfo struct {
	slot   int
	weight int
}

func replaySiteState(slots map[string]slotInfo, site string) (fillBP int64, peak int, open_lots int) {
	prefix := site + ":"
	for key := range slots {
		if !strings.HasPrefix(key, prefix) {
			continue
		}
		open_lots++
	}
	return 0, 0, open_lots
}

func Run(cfg types.DeskCfg, layout types.RungsLayout, events []types.FlowRow) (types.LadderReport, error) {
	ordered := p2.UxPick(events)
	state := m7.MkK1()
	siteFill := make(map[string]int64)
	stratumFill := make(map[string]int64)
	stratumCount := make(map[string]int)
	slotMeta := make(map[string]slotInfo)

	for _, ev := range ordered {
		arm := layout.CusipCouponCentiPct[ev.Cusip]
		if ev.EventType == "purchase" || ev.EventType == "sell" {
			delta := s4.Q0Span(opCode(ev.EventType), ev.NotionalCents, arm)
			siteFill[ev.DeskID] += delta
			stratumFill[ev.Cusip] += delta
			if ev.EventType == "purchase" {
				stratumCount[ev.Cusip]++
			} else if ev.EventType == "sell" {
				stratumCount[ev.Cusip]--
			}
		}
		m7.RxAccum(state, ev.DeskID, ev.Cusip, ev.Lot, ev.EventType, ev.NotionalCents)
		key := fmt.Sprintf("%s:%d", ev.DeskID, ev.Lot)
		switch ev.EventType {
		case "purchase":
			slotMeta[key] = slotInfo{slot: ev.Lot, weight: ev.NotionalCents}
		case "sell":
			delete(slotMeta, key)
		}
	}

	siteIDs := make([]string, 0)
	seen := make(map[string]bool)
	for _, ev := range events {
		if !seen[ev.DeskID] {
			seen[ev.DeskID] = true
			siteIDs = append(siteIDs, ev.DeskID)
		}
	}
	sort.Strings(siteIDs)

	stratumIDs := make([]string, 0)
	seenRungs := make(map[string]bool)
	for _, ev := range events {
		if !seenRungs[ev.Cusip] {
			seenRungs[ev.Cusip] = true
			stratumIDs = append(stratumIDs, ev.Cusip)
		}
	}
	sort.Strings(stratumIDs)

	report := types.LadderReport{
		Status:          "ok",
		EventsProcessed: len(ordered),
		Desks:           make([]types.DeskSnapshot, 0, len(siteIDs)),
		Rungs:          make([]types.RungSnapshot, 0, len(stratumIDs)),
	}
	var totalFill int64
	maxDrift := 0
	globalCouponWindowPeak := 0
	totalOpenLots := 0
	totalCarry := 0

	for _, site := range siteIDs {
		open_lots := state.SiteOcc[site]
		fill := siteFill[site]
		peak := sitePeakPending(site, slotMeta, cfg)
		_, _, open_lotsCheck := replaySiteState(slotMeta, site)
		drift := j2.S6Fold(fill, open_lots, open_lotsCheck)
		if drift < 0 {
			drift = -drift
		}
		if drift > maxDrift {
			maxDrift = drift
		}
		if peak > globalCouponWindowPeak {
			globalCouponWindowPeak = peak
		}
		totalFill += fill
		totalOpenLots += open_lots
		totalCarry += state.SiteCarry[site]
		report.Desks = append(report.Desks, types.DeskSnapshot{
			DeskID:      site,
			AccruedCents:      fill,
			CouponWindowPeak: peak,
			OpenLots:    open_lots,
			DriftUnits:  drift,
		})
	}

	for _, stratum := range stratumIDs {
		filled := stratumCount[stratum]
		if filled < 0 {
			filled = 0
		}
		fill := stratumFill[stratum]
		ratio := 0
		if filled > 0 {
			ratio = int(fill) / filled
		}
		report.Rungs = append(report.Rungs, types.RungSnapshot{
			Cusip:   stratum,
			Filled:      filled,
			AccrualRatioBP: ratio,
			DriftUnits:  0,
		})
	}

	report.AccruedTotalCents = totalFill
	report.CouponWindowPeak = globalCouponWindowPeak
	report.OpenLotsTotal = totalOpenLots
	report.ExBindMissTotal = totalCarry
	report.MaxDriftUnits = maxDrift
	report.ReportOK = maxDrift <= cfg.MaxDriftUnits &&
		globalCouponWindowPeak <= cfg.MaxCouponWindowPeak &&
		totalOpenLots >= cfg.MinOpenLotsTotal
	if !report.ReportOK {
		report.Status = "drift"
	}

	digest, err := digestFor(report)
	if err != nil {
		return types.LadderReport{}, err
	}
	report.ReportDigest = digest
	return report, nil
}

func digestFor(report types.LadderReport) (string, error) {
	payload := report
	payload.ReportDigest = ""
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return "", err
	}
	raw := bytes.TrimSpace(buf.Bytes())
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:]), nil
}

func WriteReport(path string, report types.LadderReport) error {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	enc.SetIndent("", "  ")
	if err := enc.Encode(report); err != nil {
		return err
	}
	return os.WriteFile(path, bytes.TrimSpace(buf.Bytes()), 0o644)
}
