"""Validate /app/output/ladder_report.json against desk.toml guardrails."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "ladder_report.json"
FLOWS = APP / "data" / "flows_default.jsonl"
LAYOUT = APP / "data" / "rungs_layout.json"
CFG = APP / "config" / "desk.toml"
CASES = Path(__file__).resolve().parent / "data"

_DEFAULT_FLOWS_TEXT = FLOWS.read_text(encoding="utf-8") if FLOWS.is_file() else ""

REPORT_KEYS = frozenset(
    {
        "status",
        "events_processed",
        "report_ok",
        "max_drift_units",
        "accrued_total_cents",
        "coupon_window_peak",
        "ex_bind_miss_total",
        "open_lots_total",
        "report_digest",
        "desks",
        "rungs",
    }
)
DESK_KEYS = frozenset(
    {
        "desk_id",
        "accrued_cents",
        "coupon_window_peak",
        "open_lots",
        "drift_units",
    }
)
RUNG_KEYS = frozenset(
    {
        "cusip",
        "filled",
        "accrual_ratio_bp",
        "drift_units",
    }
)


def _parse_cfg() -> dict[str, int]:
    cfg: dict[str, int] = {
        "max_drift_units": 0,
        "max_coupon_window_peak": 50000,
        "min_open_lots_total": 1,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in cfg:
            cfg[key] = int(float(val))
    return cfg


def _load_layout() -> dict[str, dict]:
    raw = json.loads(LAYOUT.read_text(encoding="utf-8"))
    cusip_coupon = {k: v for k, v in raw["cusip_coupon_centi_pct"].items()}
    window_scale = {1: 120, 2: 240, 3: 360}
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key == "coupon_window_scale_lot1":
            window_scale[1] = int(float(val))
        elif key == "coupon_window_scale_lot2":
            window_scale[2] = int(float(val))
        elif key == "coupon_window_scale_lot3":
            window_scale[3] = int(float(val))
    return {"cusip_coupon": cusip_coupon, "window_scale": window_scale}


def _parse_flows(text: str) -> list[dict]:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if line:
            rows.append(json.loads(line))
    return rows


def _lane_rank(lane_id: str) -> int:
    if not lane_id:
        return 99
    last = lane_id[-1]
    if last.isdigit():
        return int(last)
    return 99


def _sort_flows(rows: list[dict]) -> list[dict]:
    return sorted(
        rows,
        key=lambda row: (row["seq"], _lane_rank(row["lane_id"]), row["lane_id"], row["cusip"]),
    )


def _lot_key(desk: str, lot: int) -> str:
    return f"{desk}:{lot}"


def _expected_from_flows(flows_text: str) -> dict[str, dict]:
    layout = _load_layout()
    cusip_coupon = layout["cusip_coupon"]
    window_scale = layout["window_scale"]
    ordered = _sort_flows(_parse_flows(flows_text))
    lots: dict[str, dict] = {}
    desk_accrued: dict[str, int] = {}
    desk_occ: dict[str, int] = {}
    desk_carry: dict[str, int] = {}
    rung_accrued: dict[str, int] = {}
    rung_count: dict[str, int] = {}

    for ev in ordered:
        desk = ev["desk_id"]
        key = _lot_key(desk, ev["lot"])
        coupon = cusip_coupon[ev["cusip"]]
        notional = ev["notional_cents"]
        if ev["event_type"] in ("purchase", "sell"):
            delta = notional * coupon // 100
            if ev["event_type"] == "sell":
                delta = -delta
            desk_accrued[desk] = desk_accrued.get(desk, 0) + delta
            rung_accrued[ev["cusip"]] = rung_accrued.get(ev["cusip"], 0) + delta
            if ev["event_type"] == "purchase":
                rung_count[ev["cusip"]] = rung_count.get(ev["cusip"], 0) + 1
            else:
                rung_count[ev["cusip"]] = rung_count.get(ev["cusip"], 0) - 1
        if ev["event_type"] == "purchase":
            if key not in lots:
                desk_occ[desk] = desk_occ.get(desk, 0) + 1
            lots[key] = {"lot": ev["lot"], "notional_cents": notional}
        elif ev["event_type"] == "sell" and key in lots:
            del lots[key]
            desk_occ[desk] = desk_occ.get(desk, 0) - 1
        elif ev["event_type"] == "ex_bind":
            desk_carry[desk] = desk_carry.get(desk, 0) + 1

    desks: dict[str, dict] = {}
    for desk in sorted({ev["desk_id"] for ev in ordered}):
        prefix = f"{desk}:"
        lot_open = sum(1 for k in lots if k.startswith(prefix))
        peak = 0
        for k, info in lots.items():
            if not k.startswith(prefix):
                continue
            window = info["notional_cents"] * window_scale[info["lot"]] // 1000
            peak = max(peak, window)
        desks[desk] = {
            "accrued_cents": desk_accrued.get(desk, 0),
            "open_lots": desk_occ.get(desk, 0),
            "coupon_window_peak": peak,
            "drift_units": abs(desk_occ.get(desk, 0) - lot_open),
        }

    rungs: dict[str, dict] = {}
    for cusip in sorted({ev["cusip"] for ev in ordered}):
        filled = max(rung_count.get(cusip, 0), 0)
        accrued = rung_accrued.get(cusip, 0)
        ratio = accrued // filled if filled > 0 else 0
        rungs[cusip] = {
            "filled": filled,
            "accrual_ratio_bp": ratio,
            "drift_units": 0,
        }

    total_accrued = sum(v["accrued_cents"] for v in desks.values())
    total_open = sum(v["open_lots"] for v in desks.values())
    global_window = max((v["coupon_window_peak"] for v in desks.values()), default=0)
    max_drift = max((v["drift_units"] for v in desks.values()), default=0)
    total_carry = sum(desk_carry.values())
    return {
        "desks": desks,
        "rungs": rungs,
        "accrued_total_cents": total_accrued,
        "open_lots_total": total_open,
        "coupon_window_peak": global_window,
        "ex_bind_miss_total": total_carry,
        "max_drift_units": max_drift,
        "events_processed": len(ordered),
    }


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _swap_fixture(stem: str) -> str:
    src = CASES / f"{stem}.jsonl"
    text = src.read_text(encoding="utf-8")
    _atomic_write_text(FLOWS, text)
    return text


def _expected_digest(report: dict) -> str:
    payload = dict(report)
    payload["report_digest"] = ""
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _invoke_default() -> None:
    proc = subprocess.run(
        ["/app/tools/run_replay"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "ladder_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


def _desk_map(report: dict) -> dict[str, dict]:
    return {row["desk_id"]: row for row in report["desks"]}


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    _invoke_default()


@pytest.fixture(autouse=True)
def restore_default_flows() -> None:
    yield
    if _DEFAULT_FLOWS_TEXT:
        _atomic_write_text(FLOWS, _DEFAULT_FLOWS_TEXT)


def test_h1_schema() -> None:
    """Report must expose only the documented top-level keys."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS


def test_h8_row_shape() -> None:
    """Each desk and rung row must match the documented schemas."""
    report = _load_report()
    assert report["desks"]
    assert report["rungs"]
    for row in report["desks"]:
        assert set(row.keys()) == DESK_KEYS
        assert isinstance(row["desk_id"], str) and row["desk_id"]
        assert isinstance(row["accrued_cents"], int)
        assert isinstance(row["coupon_window_peak"], int)
        assert isinstance(row["open_lots"], int)
        assert isinstance(row["drift_units"], int)
    for row in report["rungs"]:
        assert set(row.keys()) == RUNG_KEYS
        assert isinstance(row["cusip"], str) and row["cusip"]
        assert isinstance(row["filled"], int)
        assert isinstance(row["accrual_ratio_bp"], int)
        assert isinstance(row["drift_units"], int)


def test_h2_guardrails() -> None:
    """Default bundle must finish ok and meet desk.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["report_ok"]
    assert report["max_drift_units"] <= cfg["max_drift_units"]
    assert report["open_lots_total"] >= cfg["min_open_lots_total"]
    assert report["coupon_window_peak"] <= cfg["max_coupon_window_peak"]


def test_h3_total_a() -> None:
    """Default replay accrued_total_cents must match layout-derived replay."""
    expected = _expected_from_flows(_DEFAULT_FLOWS_TEXT)
    report = _load_report()
    assert report["accrued_total_cents"] == expected["accrued_total_cents"]


def test_h4_total_b() -> None:
    """Default replay open_lots_total must match lot-derived open lots."""
    expected = _expected_from_flows(_DEFAULT_FLOWS_TEXT)
    report = _load_report()
    assert report["open_lots_total"] == expected["open_lots_total"]


def test_h5_row_a() -> None:
    """D01 accrued after US912828Y2 sell must match layout-derived replay."""
    expected = _expected_from_flows(_DEFAULT_FLOWS_TEXT)
    report = _load_report()
    d01 = _desk_map(report)["D01"]
    assert d01["accrued_cents"] == expected["desks"]["D01"]["accrued_cents"]


def test_h6_row_b() -> None:
    """D01 open lots after US912828Y2 sell must match lot ledger."""
    cfg = _parse_cfg()
    expected = _expected_from_flows(_DEFAULT_FLOWS_TEXT)
    report = _load_report()
    d01 = _desk_map(report)["D01"]
    assert d01["open_lots"] == expected["desks"]["D01"]["open_lots"]
    assert d01["drift_units"] <= cfg["max_drift_units"]


def test_h7_row_c() -> None:
    """D04 lot clash must reflect L1-first tie resolution."""
    expected = _expected_from_flows(_DEFAULT_FLOWS_TEXT)
    report = _load_report()
    d04 = _desk_map(report)["D04"]
    assert d04["accrued_cents"] == expected["desks"]["D04"]["accrued_cents"]
    assert d04["open_lots"] == expected["desks"]["D04"]["open_lots"]


def test_h16_row_d() -> None:
    """D03 seq-50 lane tie must reflect L1-first ordering on default bundle."""
    expected = _expected_from_flows(_DEFAULT_FLOWS_TEXT)
    report = _load_report()
    d03 = _desk_map(report)["D03"]
    assert d03["accrued_cents"] == expected["desks"]["D03"]["accrued_cents"]
    assert d03["open_lots"] == expected["desks"]["D03"]["open_lots"]


def test_h17_row_e() -> None:
    """D02 stacked triple on default bundle must reconcile accrued and window peak."""
    expected = _expected_from_flows(_DEFAULT_FLOWS_TEXT)
    report = _load_report()
    d02 = _desk_map(report)["D02"]
    assert d02["accrued_cents"] == expected["desks"]["D02"]["accrued_cents"]
    assert d02["coupon_window_peak"] == expected["desks"]["D02"]["coupon_window_peak"]


def test_h9_count() -> None:
    """events_processed must equal non-empty rows in the active bundle."""
    expected = _expected_from_flows(_DEFAULT_FLOWS_TEXT)
    report = _load_report()
    assert report["events_processed"] == expected["events_processed"]


def test_h15_digest() -> None:
    """report_digest must hash the compact pre-digest JSON payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_h10_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_h11_case_a() -> None:
    """Dual-lane open scenario must reconcile D01 accrued and open lots."""
    flows_text = _swap_fixture("dual_lane_open")
    _invoke_default()
    expected = _expected_from_flows(flows_text)
    report = _load_report()
    d01 = _desk_map(report)["D01"]
    assert report["status"] == "ok"
    assert d01["accrued_cents"] == expected["desks"]["D01"]["accrued_cents"]
    assert d01["open_lots"] == expected["desks"]["D01"]["open_lots"]


def test_h12_case_b() -> None:
    """Stacked triple scenario must reconcile D02 accrued and coupon window."""
    flows_text = _swap_fixture("stacked_triple")
    _invoke_default()
    expected = _expected_from_flows(flows_text)
    report = _load_report()
    d02 = _desk_map(report)["D02"]
    assert report["status"] == "ok"
    assert d02["accrued_cents"] == expected["desks"]["D02"]["accrued_cents"]
    assert d02["open_lots"] == expected["desks"]["D02"]["open_lots"]
    assert d02["coupon_window_peak"] == expected["desks"]["D02"]["coupon_window_peak"]


def test_h13_case_c() -> None:
    """Lot clash scenario must keep L1-first notional on D04."""
    flows_text = _swap_fixture("lot_clash")
    _invoke_default()
    expected = _expected_from_flows(flows_text)
    report = _load_report()
    d04 = _desk_map(report)["D04"]
    assert report["status"] == "ok"
    assert d04["accrued_cents"] == expected["desks"]["D04"]["accrued_cents"]
    assert d04["coupon_window_peak"] == expected["desks"]["D04"]["coupon_window_peak"]


def test_h14_case_d() -> None:
    """Sell-after-peer scenario must reconcile D01 ledger drift and ex-bind miss."""
    flows_text = _swap_fixture("clear_after_peer")
    _invoke_default()
    expected = _expected_from_flows(flows_text)
    cfg = _parse_cfg()
    report = _load_report()
    d01 = _desk_map(report)["D01"]
    assert report["report_ok"]
    assert d01["drift_units"] <= cfg["max_drift_units"]
    assert d01["open_lots"] == expected["desks"]["D01"]["open_lots"]
    assert report["ex_bind_miss_total"] == expected["ex_bind_miss_total"]
