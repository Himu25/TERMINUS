#!/bin/bash
set -euo pipefail
cd /app
bash /app/scripts/build.sh
/app/bin/jobpack /app/data/job_specs.jsonl /app/data/jobs_default.jsonl
/app/tools/run_dispatch
