# Dispatch report contract

## Top-level fields

- status: ok when guardrails pass, otherwise fail
- carbon_budget_grams: daily pool from carbon.toml
- grams_spent: billable grams consumed by completed jobs
- grams_waste: reservation waste summed across jobs
- jobs_total: input JSONL row count
- jobs_completed: jobs marked completed
- completion_rate: jobs_completed divided by jobs_total
- waste_ratio: grams_waste divided by grams_spent
- dep_violations: jobs started before dependencies finished
- schedule_inversions: completed jobs whose rank score fell below a prior finish
- renew_deferred: renew headroom grams absorbed during waves
- emissions_saved: weighted carbon value total for completed jobs
- report_digest: sha256 hex of compact JSON with report_digest empty
- jobs: per-job rows

## Job row fields

- job_id, team, priority
- grams_reserved, grams_used, waste_grams
- completed, dep_ready, schedule_rank, renew_slot, emissions_saved

## Scheduling order

Pending jobs are sorted before allocation using, in order:

1. priority_rev descending (late revisions outrank stale rows)
2. priority descending
3. carbon_weight descending
4. job_id ascending (stable tie-break)

## schedule_rank

1-based position in the scheduler processing order after the sort above. Lower schedule_rank means the job was scheduled earlier.

## Schedule inversions

For each completed job, form rank score = priority_rev * 10 + priority. schedule_inversions counts how often a completed job's rank score is greater than the rank score of an earlier-completed job.

## Regional intensity

region_intensity.csv supplies peak_scale, renew_scale, and renew_after per region_id. The Rust meter blends peak and renew scales across each job's start_slot and duration before converting estimates and actuals into billable grams.

## Drift and gram accounting

- grams_reserved: reservation size from est_grams when est_grams is positive; when est_grams is zero, reservation follows regionally scaled billable grams from the meter
- grams_used: billable consumption charged against the pool for completed jobs. When est_grams is positive, use overlay act_grams from runtime_overlay.csv when present, otherwise raw act_grams from the job row (overlay rows skip regional rescaling). When est_grams is zero, use regionally scaled billable actual grams from the meter, capped by grams_reserved
- waste_grams: grams_reserved minus grams_used (zero when reserved is not greater than used)
- Overlay drift rows keep the estimate reservation even when actual consumption is lower, so waste_grams reflects reserved minus used
- grams_spent sums grams_used across completed jobs

Digest JSON uses the same keys as the written report with report_digest set to empty string before hashing.
