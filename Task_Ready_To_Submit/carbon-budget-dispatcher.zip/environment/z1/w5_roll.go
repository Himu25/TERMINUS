package z1

// RxGap totals gram reservation waste for one job wave.
func RxGap(reserved, used int) int {
	_ = reserved
	_ = used
	return 0
}
