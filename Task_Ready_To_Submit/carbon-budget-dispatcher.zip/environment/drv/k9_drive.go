package drv

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"

	"cbd.disp/k2"
	"cbd.disp/pkg/types"
	"cbd.disp/q9"
	"cbd.disp/summ"
	"cbd.disp/u3"
)

func LoadCfg(path string) (types.CarbonCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.CarbonCfg{}, err
	}
	cfg := types.CarbonCfg{
		CarbonBudgetGrams:     15000,
		MinCompletionRate:     0.75,
		MaxWasteRatio:         0.35,
		MaxDepViolations:      0,
		MaxScheduleInversions: 1,
		MinRenewDeferred:      3,
		MinEmissionsSaved:     2.0,
		TeamWeights:           map[string]float64{"team_a": 1.0, "team_b": 1.0, "team_c": 1.0},
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "carbon_budget_grams":
			fmt.Sscanf(val, "%d", &cfg.CarbonBudgetGrams)
		case "min_completion_rate":
			fmt.Sscanf(val, "%f", &cfg.MinCompletionRate)
		case "max_waste_ratio":
			fmt.Sscanf(val, "%f", &cfg.MaxWasteRatio)
		case "max_dep_violations":
			fmt.Sscanf(val, "%d", &cfg.MaxDepViolations)
		case "max_schedule_inversions":
			fmt.Sscanf(val, "%d", &cfg.MaxScheduleInversions)
		case "min_renew_deferred":
			fmt.Sscanf(val, "%d", &cfg.MinRenewDeferred)
		case "min_emissions_saved":
			fmt.Sscanf(val, "%f", &cfg.MinEmissionsSaved)
		case "team_weight_team_a":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.TeamWeights["team_a"] = w
		case "team_weight_team_b":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.TeamWeights["team_b"] = w
		case "team_weight_team_c":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.TeamWeights["team_c"] = w
		}
	}
	return cfg, nil
}

func LoadRegions(path string) (map[string]types.RegionProfile, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]types.RegionProfile)
	for i, row := range rows {
		if i == 0 || len(row) < 4 {
			continue
		}
		var peak, renew, after int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &peak)
		fmt.Sscanf(strings.TrimSpace(row[2]), "%d", &renew)
		fmt.Sscanf(strings.TrimSpace(row[3]), "%d", &after)
		id := strings.TrimSpace(row[0])
		out[id] = types.RegionProfile{
			RegionID:   id,
			PeakScale:  peak,
			RenewScale: renew,
			RenewAfter: after,
		}
	}
	return out, nil
}

func LoadJobs(path string) ([]types.JobCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.JobCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var jc types.JobCase
		if err := json.Unmarshal([]byte(line), &jc); err != nil {
			return nil, err
		}
		if jc.RegionID == "" {
			jc.RegionID = "us-east"
		}
		out = append(out, jc)
	}
	return out, sc.Err()
}

func LoadOverlay(path string) (map[string]int, error) {
	f, err := os.Open(path)
	if err != nil {
		return map[string]int{}, nil
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]int)
	for i, row := range rows {
		if i == 0 || len(row) < 2 {
			continue
		}
		var grams int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &grams)
		out[strings.TrimSpace(row[0])] = grams
	}
	return out, nil
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

func regionFor(jc types.JobCase, regions map[string]types.RegionProfile) types.RegionProfile {
	if rp, ok := regions[jc.RegionID]; ok {
		return rp
	}
	return types.RegionProfile{RegionID: jc.RegionID, PeakScale: 100, RenewScale: 100, RenewAfter: 0}
}

func Run(cfg types.CarbonCfg, cases []types.JobCase, overlay map[string]int, regions map[string]types.RegionProfile) (types.DispatchReport, error) {
	ordered := q9.PxSeq(cases)
	report := types.DispatchReport{
		Status:            "ok",
		CarbonBudgetGrams: cfg.CarbonBudgetGrams,
		JobsTotal:         len(ordered),
	}
	done := make(map[string]bool)
	budgetLeft := cfg.CarbonBudgetGrams
	var spent, totalWaste, completed, depViol, inversions, renewTotal int
	var valueTotal float64
	prevRank := -1
	report.Jobs = make([]types.JobRow, 0, len(ordered))

	for idx, jc := range ordered {
		actualReady := true
		for _, depID := range jc.DepOn {
			if !done[depID] {
				actualReady = false
				break
			}
		}
		depReady := k2.DxGate(jc.DepOn, done)
		if len(jc.DepOn) > 0 && !actualReady && depReady {
			depViol++
		}
		overlayVal := 0
		if act, ok := overlay[jc.JobID]; ok && act > 0 {
			overlayVal = act
			jc.ActGrams = act
		}
		rp := regionFor(jc, regions)
		billable := meterBillable(jc, overlayVal, rp)
		if billable <= 0 {
			billable = jc.EstGrams
		}
		reserveNeed := u3.AxNeed(jc.EstGrams, billable)
		reserved, ok := u3.BxReserve(budgetLeft, reserveNeed)
		headroom := budgetLeft - reserved
		renewTotal += waveRenewTotal(jc.RenewWave, jc.EstGrams, headroom)
		used := 0
		finished := false
		if ok && depReady {
			used = jc.ActGrams
			if used <= 0 {
				used = billable
			}
			if used > reserved {
				used = reserved
			}
			budgetLeft -= reserved
			spent += used
			finished = true
			completed++
			done[jc.JobID] = true
			valueTotal += u3.VxValue(jc.CarbonWeight, used)
		}
		wasteAmt := jobWaste(reserved, used)
		totalWaste += wasteAmt
		rankScore := jc.PriorityRev*10 + jc.Priority
		if finished {
			if prevRank >= 0 && rankScore > prevRank {
				inversions++
			}
			prevRank = rankScore
		}
		row := types.JobRow{
			JobID:          jc.JobID,
			Team:           jc.Team,
			Priority:       jc.Priority,
			GramsReserved:  reserved,
			GramsUsed:      used,
			Completed:      finished,
			DepReady:       depReady,
			ScheduleRank:   idx + 1,
			WasteGrams:     wasteAmt,
			RenewSlot:      jc.RenewWave,
			EmissionsSaved: round4(u3.VxValue(jc.CarbonWeight, used)),
		}
		report.Jobs = append(report.Jobs, row)
	}

	report.GramsSpent = spent
	report.GramsWaste = totalWaste
	report.JobsCompleted = completed
	if report.JobsTotal > 0 {
		report.CompletionRate = round4(float64(completed) / float64(report.JobsTotal))
	}
	if spent > 0 {
		report.WasteRatio = round4(float64(totalWaste) / float64(spent))
	}
	report.DepViolations = depViol
	report.ScheduleInversions = inversions
	report.RenewDeferred = renewTotal
	report.EmissionsSaved = round4(valueTotal)
	hasRenew := false
	for _, jc := range ordered {
		if jc.RenewWave > 0 {
			hasRenew = true
			break
		}
	}
	if !meetsFloors(cfg, report, hasRenew) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func meetsFloors(cfg types.CarbonCfg, report types.DispatchReport, hasRenew bool) bool {
	if report.CompletionRate < cfg.MinCompletionRate {
		return false
	}
	if report.WasteRatio > cfg.MaxWasteRatio {
		return false
	}
	if report.DepViolations > cfg.MaxDepViolations {
		return false
	}
	if report.ScheduleInversions > cfg.MaxScheduleInversions {
		return false
	}
	if report.RenewDeferred < cfg.MinRenewDeferred {
		if hasRenew {
			return false
		}
	}
	if report.EmissionsSaved < cfg.MinEmissionsSaved {
		return false
	}
	for _, row := range report.Jobs {
		if strings.HasPrefix(row.JobID, "j_dep_") && !row.DepReady && row.Completed {
			return false
		}
		if strings.HasPrefix(row.JobID, "j_burst_") && row.RenewSlot > 0 && !row.Completed {
			return false
		}
		if strings.HasPrefix(row.JobID, "j_drift_") && row.WasteGrams == 0 && row.GramsReserved > row.GramsUsed+50 {
			return false
		}
		if strings.HasPrefix(row.JobID, "j_region_") && row.Completed && row.GramsUsed > row.GramsReserved+200 {
			return false
		}
	}
	_ = summ.SxFold(report.Jobs)
	return true
}

type digestPayload struct {
	Status              string         `json:"status"`
	CarbonBudgetGrams   int            `json:"carbon_budget_grams"`
	GramsSpent          int            `json:"grams_spent"`
	GramsWaste          int            `json:"grams_waste"`
	JobsTotal           int            `json:"jobs_total"`
	JobsCompleted       int            `json:"jobs_completed"`
	CompletionRate      float64        `json:"completion_rate"`
	WasteRatio          float64        `json:"waste_ratio"`
	DepViolations       int            `json:"dep_violations"`
	ScheduleInversions  int            `json:"schedule_inversions"`
	RenewDeferred       int            `json:"renew_deferred"`
	EmissionsSaved      float64        `json:"emissions_saved"`
	ReportDigest        string         `json:"report_digest"`
	Jobs                []types.JobRow `json:"jobs"`
}

func digestBody(report types.DispatchReport) string {
	payload := digestPayload{
		Status:             report.Status,
		CarbonBudgetGrams:  report.CarbonBudgetGrams,
		GramsSpent:         report.GramsSpent,
		GramsWaste:         report.GramsWaste,
		JobsTotal:          report.JobsTotal,
		JobsCompleted:      report.JobsCompleted,
		CompletionRate:     report.CompletionRate,
		WasteRatio:         report.WasteRatio,
		DepViolations:      report.DepViolations,
		ScheduleInversions: report.ScheduleInversions,
		RenewDeferred:      report.RenewDeferred,
		EmissionsSaved:     report.EmissionsSaved,
		ReportDigest:       "",
		Jobs:               report.Jobs,
	}
	raw, err := marshalDigestJSON(payload)
	if err != nil {
		return ""
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func marshalDigestJSON(payload digestPayload) ([]byte, error) {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return nil, err
	}
	b := buf.Bytes()
	if n := len(b); n > 0 && b[n-1] == '\n' {
		b = b[:n-1]
	}
	return b, nil
}

func WriteReport(path string, report types.DispatchReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func p95(values []int) int {
	if len(values) == 0 {
		return 0
	}
	cp := append([]int(nil), values...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}
