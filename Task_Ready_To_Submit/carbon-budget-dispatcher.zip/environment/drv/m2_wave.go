package drv

import "cbd.disp/h4"

func waveRenewTotal(renewWave, estGrams, headroom int) int {
	if renewWave <= 0 {
		return 0
	}
	return h4.WxAbsorb(estGrams/4, headroom)
}
