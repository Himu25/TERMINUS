package drv

import (
	"cbd.disp/n8"
	"cbd.disp/pkg/types"
	"cbd.disp/z1"
)

func meterBillable(jc types.JobCase, overlayVal int, rp types.RegionProfile) int {
	peakScale := rp.PeakScale
	renewScale := rp.RenewScale
	renewAfter := rp.RenewAfter
	if overlayVal > 0 {
		peakScale, renewScale, renewAfter = 100, 100, 0
	}
	roll := n8.MeterSpan(
		jc.EstGrams, jc.ActGrams, overlayVal,
		peakScale, renewScale, renewAfter, jc.StartSlot,
	)
	if roll.Billable > 0 {
		return roll.Billable
	}
	return jc.EstGrams
}

func jobWaste(reserved, used int) int {
	return z1.RxGap(reserved, used)
}
