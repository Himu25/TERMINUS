package q9

import (
	"sort"

	"cbd.disp/pkg/types"
)

// PxSeq ranks pending jobs for carbon-aware dispatch.
func PxSeq(cases []types.JobCase) []types.JobCase {
	out := make([]types.JobCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		return out[i].EstGrams < out[j].EstGrams
	})
	return out
}
