package h4

// WxAbsorb counts renewable deferral headroom absorbed from spare headroom.
func WxAbsorb(burstNeed, headroom int) int {
	if burstNeed <= 0 || headroom <= 0 {
		return 0
	}
	if burstNeed > headroom {
		return headroom
	}
	return burstNeed
}
