package types

type CarbonCfg struct {
	CarbonBudgetGrams     int
	MinCompletionRate     float64
	MaxWasteRatio         float64
	MaxDepViolations      int
	MaxScheduleInversions int
	MinRenewDeferred      int
	MinEmissionsSaved     float64
	TeamWeights           map[string]float64
}

type RegionProfile struct {
	RegionID   string
	PeakScale  int
	RenewScale int
	RenewAfter int
}

type JobCase struct {
	JobID        string   `json:"job_id"`
	Team         string   `json:"team"`
	Priority     int      `json:"priority"`
	PriorityRev  int      `json:"priority_rev"`
	EstGrams     int      `json:"est_grams"`
	ActGrams     int      `json:"act_grams"`
	DepOn        []string `json:"dep_on"`
	RenewWave    int      `json:"renew_wave"`
	CarbonWeight float64  `json:"carbon_weight"`
	RegionID     string   `json:"region_id"`
	StartSlot    int      `json:"start_slot"`
	DeadlineSlot int      `json:"deadline_slot"`
}

type JobRow struct {
	JobID          string  `json:"job_id"`
	Team           string  `json:"team"`
	Priority       int     `json:"priority"`
	GramsReserved  int     `json:"grams_reserved"`
	GramsUsed      int     `json:"grams_used"`
	Completed      bool    `json:"completed"`
	DepReady       bool    `json:"dep_ready"`
	ScheduleRank   int     `json:"schedule_rank"`
	WasteGrams     int     `json:"waste_grams"`
	RenewSlot      int     `json:"renew_slot"`
	EmissionsSaved float64 `json:"emissions_saved"`
}

type DispatchReport struct {
	Status              string   `json:"status"`
	CarbonBudgetGrams   int      `json:"carbon_budget_grams"`
	GramsSpent          int      `json:"grams_spent"`
	GramsWaste          int      `json:"grams_waste"`
	JobsTotal           int      `json:"jobs_total"`
	JobsCompleted       int      `json:"jobs_completed"`
	CompletionRate      float64  `json:"completion_rate"`
	WasteRatio          float64  `json:"waste_ratio"`
	DepViolations       int      `json:"dep_violations"`
	ScheduleInversions  int      `json:"schedule_inversions"`
	RenewDeferred       int      `json:"renew_deferred"`
	EmissionsSaved      float64  `json:"emissions_saved"`
	ReportDigest        string   `json:"report_digest"`
	Jobs                []JobRow `json:"jobs"`
}
