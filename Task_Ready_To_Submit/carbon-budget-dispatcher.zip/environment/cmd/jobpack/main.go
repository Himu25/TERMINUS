package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
)

func aliasRow(raw map[string]any) {
	if _, ok := raw["est_grams"]; !ok {
		if v, ok := raw["est_credits"]; ok {
			raw["est_grams"] = v
			delete(raw, "est_credits")
		}
	}
	if _, ok := raw["act_grams"]; !ok {
		if v, ok := raw["act_credits"]; ok {
			raw["act_grams"] = v
			delete(raw, "act_credits")
		}
	}
	if _, ok := raw["renew_wave"]; !ok {
		if v, ok := raw["burst_wave"]; ok {
			raw["renew_wave"] = v
			delete(raw, "burst_wave")
		}
	}
	if _, ok := raw["carbon_weight"]; !ok {
		if v, ok := raw["value_weight"]; ok {
			raw["carbon_weight"] = v
			delete(raw, "value_weight")
		}
	}
	if _, ok := raw["act_grams"]; !ok {
		if v, ok := raw["est_grams"]; ok {
			raw["act_grams"] = v
		}
	}
}

func main() {
	if len(os.Args) < 3 {
		fmt.Fprintln(os.Stderr, "usage: jobpack <spec.jsonl> <out.jsonl>")
		os.Exit(2)
	}
	in, err := os.Open(os.Args[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer in.Close()
	out, err := os.Create(os.Args[2])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer out.Close()
	w := bufio.NewWriter(out)
	sc := bufio.NewScanner(in)
	for sc.Scan() {
		line := sc.Text()
		if line == "" {
			continue
		}
		var raw map[string]any
		if err := json.Unmarshal([]byte(line), &raw); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		aliasRow(raw)
		b, err := json.Marshal(raw)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		if _, err := w.Write(b); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		if _, err := w.WriteString("\n"); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	}
	if err := sc.Err(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if err := w.Flush(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
