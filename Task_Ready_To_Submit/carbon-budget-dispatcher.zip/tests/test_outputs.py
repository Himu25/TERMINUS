"""Validate /app/output/dispatch_report.json against carbon.toml guardrails."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "dispatch_report.json"
JOBS = APP / "data" / "jobs_default.jsonl"
CFG = APP / "config" / "carbon.toml"
OVERLAY = APP / "data" / "runtime_overlay.csv"
CASES = Path(__file__).resolve().parent / "data"

_DEFAULT_JOBS_TEXT = JOBS.read_text(encoding="utf-8") if JOBS.is_file() else ""

REPORT_KEYS = frozenset(
    {
        "status",
        "carbon_budget_grams",
        "grams_spent",
        "grams_waste",
        "jobs_total",
        "jobs_completed",
        "completion_rate",
        "waste_ratio",
        "dep_violations",
        "schedule_inversions",
        "renew_deferred",
        "emissions_saved",
        "report_digest",
        "jobs",
    }
)
ROW_KEYS = frozenset(
    {
        "job_id",
        "team",
        "priority",
        "grams_reserved",
        "grams_used",
        "waste_grams",
        "completed",
        "dep_ready",
        "schedule_rank",
        "renew_slot",
        "emissions_saved",
    }
)


def _load_overlay() -> dict[str, int]:
    overlay: dict[str, int] = {}
    if not OVERLAY.is_file():
        return overlay
    lines = OVERLAY.read_text(encoding="utf-8").splitlines()
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        job_id, grams = (part.strip() for part in line.split(",", 1))
        overlay[job_id] = int(grams)
    return overlay


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "carbon_budget_grams": 18000,
        "min_completion_rate": 0.75,
        "max_waste_ratio": 0.40,
        "max_dep_violations": 0,
        "max_schedule_inversions": 1,
        "min_renew_deferred": 0,
        "min_emissions_saved": 1.5,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in ("min_completion_rate", "max_waste_ratio", "min_emissions_saved"):
            cfg[key] = float(val)
        elif key in (
            "carbon_budget_grams",
            "max_dep_violations",
            "max_schedule_inversions",
            "min_renew_deferred",
        ):
            cfg[key] = int(float(val))
    return cfg


def _job_rows_from_text(text: str) -> list[dict]:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def _job_ids_from_text(text: str) -> list[str]:
    return [row["job_id"] for row in _job_rows_from_text(text)]


def _job_map_from_text(text: str) -> dict[str, dict]:
    return {row["job_id"]: row for row in _job_rows_from_text(text)}


def _assert_jobs_match_input(report: dict, jobs_text: str) -> None:
    expected_ids = _job_ids_from_text(jobs_text)
    report_ids = [row["job_id"] for row in report["jobs"]]
    assert report["jobs_total"] == len(expected_ids)
    assert len(report_ids) == len(expected_ids)
    assert set(report_ids) == set(expected_ids)


@pytest.fixture(autouse=True)
def restore_default_jobs() -> None:
    yield
    if _DEFAULT_JOBS_TEXT:
        _atomic_write_text(JOBS, _DEFAULT_JOBS_TEXT)


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _swap_fixture(stem: str) -> str:
    src = CASES / f"{stem}.jsonl"
    text = src.read_text(encoding="utf-8")
    _atomic_write_text(JOBS, text)
    return text


def _expected_digest(report: dict) -> str:
    payload = dict(report)
    payload["report_digest"] = ""
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _invoke_default() -> None:
    proc = subprocess.run(
        ["/app/tools/run_dispatch"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "dispatch_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    _invoke_default()


def test_report_top_level_keys_exact() -> None:
    """Report must expose only the documented top-level keys."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS


def test_job_row_schema() -> None:
    """Each job row must match the documented per-job schema."""
    report = _load_report()
    assert report["jobs"]
    for row in report["jobs"]:
        assert set(row.keys()) == ROW_KEYS
        assert isinstance(row["job_id"], str) and row["job_id"]
        assert isinstance(row["team"], str) and row["team"]
        assert isinstance(row["priority"], int)
        assert row["grams_reserved"] >= 0
        assert row["grams_used"] >= 0
        assert row["waste_grams"] >= 0
        assert isinstance(row["completed"], bool)
        assert isinstance(row["dep_ready"], bool)
        assert row["schedule_rank"] >= 1
        assert row["renew_slot"] >= 0
        assert row["emissions_saved"] >= 0.0


def test_passing_run_contract() -> None:
    """Default bundle must finish ok and meet carbon.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["carbon_budget_grams"] == cfg["carbon_budget_grams"]
    _assert_jobs_match_input(report, _DEFAULT_JOBS_TEXT)
    assert report["completion_rate"] >= cfg["min_completion_rate"]
    assert report["waste_ratio"] <= cfg["max_waste_ratio"]
    assert report["dep_violations"] <= cfg["max_dep_violations"]
    assert report["schedule_inversions"] <= cfg["max_schedule_inversions"]
    assert report["renew_deferred"] >= cfg["min_renew_deferred"]
    assert report["emissions_saved"] >= cfg["min_emissions_saved"]


def test_jobs_total_matches_input_rows() -> None:
    """Report job IDs must cover every input JSONL row with no drops or extras."""
    report = _load_report()
    _assert_jobs_match_input(report, _DEFAULT_JOBS_TEXT)


def test_report_digest_matches_payload() -> None:
    """report_digest must hash the compact pre-digest JSON payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_deterministic_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_dep_rows_finish_in_order() -> None:
    """Dependency rows must not start before prerequisites even when a child outranks its parent."""
    report = _load_report()
    ranks = {row["job_id"]: row["schedule_rank"] for row in report["jobs"]}
    root = next(r for r in report["jobs"] if r["job_id"] == "j_dep_root")
    leaf = next(r for r in report["jobs"] if r["job_id"] == "j_dep_leaf")
    assert ranks["j_dep_leaf"] < ranks["j_dep_root"], (leaf, root)
    assert report["dep_violations"] == 0
    assert root["completed"] is True
    for row in report["jobs"]:
        if row["job_id"].startswith("j_dep_") and row["completed"]:
            assert row["dep_ready"] is True, row


def test_prio_hot_ranks_before_cold() -> None:
    """Late priority revision rows must finish before stale low-revision peers."""
    report = _load_report()
    hot = next(r for r in report["jobs"] if r["job_id"] == "j_prio_hot")
    cold = next(r for r in report["jobs"] if r["job_id"] == "j_prio_cold")
    assert hot["completed"] is True
    assert cold["completed"] is True
    assert hot["schedule_rank"] < cold["schedule_rank"], (hot, cold)


def test_drift_accounting_semantics() -> None:
    """Drift rows reserve estimates, bill actuals, and record reserved minus used."""
    report = _load_report()
    inputs = _job_map_from_text(_DEFAULT_JOBS_TEXT)
    overlay = _load_overlay()
    for row in report["jobs"]:
        if not row["job_id"].startswith("j_drift_") or not row["completed"]:
            continue
        spec = inputs[row["job_id"]]
        expected_used = overlay.get(row["job_id"], spec["act_grams"])
        assert row["grams_reserved"] == spec["est_grams"]
        assert row["grams_used"] == expected_used
        assert row["waste_grams"] == max(0, row["grams_reserved"] - row["grams_used"])


def test_drift_rows_record_waste() -> None:
    """Drift-prone rows with inflated reservations must record waste_grams."""
    report = _load_report()
    drift_rows = [r for r in report["jobs"] if r["job_id"].startswith("j_drift_")]
    assert drift_rows
    assert any(r["waste_grams"] > 0 for r in drift_rows if r["completed"])


def test_scenario_dep_chain() -> None:
    """Dependency-chain scenario must block child rows until prerequisites finish."""
    jobs_text = _swap_fixture("dep_chain")
    _invoke_default()
    report = _load_report()
    _assert_jobs_match_input(report, jobs_text)
    assert report["dep_violations"] == 0
    assert report["status"] == "ok"
    ranks = {row["job_id"]: row["schedule_rank"] for row in report["jobs"]}
    root = next(r for r in report["jobs"] if r["job_id"] == "j_dep_root")
    assert ranks["j_dep_leaf"] < ranks["j_dep_root"]
    assert root["completed"] is True


def test_scenario_priority_flip() -> None:
    """Priority-flip scenario must schedule late revisions ahead of stale peers."""
    cfg = _parse_cfg()
    jobs_text = _swap_fixture("priority_flip")
    _invoke_default()
    report = _load_report()
    _assert_jobs_match_input(report, jobs_text)
    hot = next(r for r in report["jobs"] if r["job_id"] == "j_prio_hot")
    cold = next(r for r in report["jobs"] if r["job_id"] == "j_prio_cold")
    assert hot["schedule_rank"] < cold["schedule_rank"]
    assert report["schedule_inversions"] <= cfg["max_schedule_inversions"]
    assert report["status"] == "ok"


def test_scenario_est_drift() -> None:
    """Estimate-drift scenario must keep waste_ratio under max_waste_ratio."""
    cfg = _parse_cfg()
    jobs_text = _swap_fixture("est_drift")
    _invoke_default()
    report = _load_report()
    _assert_jobs_match_input(report, jobs_text)
    inputs = _job_map_from_text(jobs_text)
    for row in report["jobs"]:
        if not row["job_id"].startswith("j_drift_") or not row["completed"]:
            continue
        spec = inputs[row["job_id"]]
        assert row["grams_reserved"] == spec["est_grams"]
        assert row["waste_grams"] == max(0, row["grams_reserved"] - row["grams_used"])
        assert row["waste_grams"] > 0
    assert report["waste_ratio"] <= cfg["max_waste_ratio"]
    assert report["status"] == "ok"


def test_scenario_value_mix() -> None:
    """Carbon-weight mix scenario must meet emissions_saved floor."""
    cfg = _parse_cfg()
    jobs_text = _swap_fixture("value_mix")
    _invoke_default()
    report = _load_report()
    _assert_jobs_match_input(report, jobs_text)
    assert report["status"] == "ok"
    assert report["emissions_saved"] >= cfg["min_emissions_saved"]
