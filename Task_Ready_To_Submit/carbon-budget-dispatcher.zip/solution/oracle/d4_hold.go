package k2

import "strings"

// DxGate reports whether dependency prerequisites are satisfied.
func DxGate(depOn []string, done map[string]bool) bool {
	if len(depOn) == 0 {
		return true
	}
	for _, depID := range depOn {
		depID = strings.TrimSpace(depID)
		if depID == "" {
			continue
		}
		if !done[depID] {
			return false
		}
	}
	return true
}
