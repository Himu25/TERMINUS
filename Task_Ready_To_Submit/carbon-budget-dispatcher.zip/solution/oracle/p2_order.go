package q9

import (
	"sort"

	"cbd.disp/pkg/types"
)

// PxSeq ranks pending jobs for carbon-aware dispatch.
func PxSeq(cases []types.JobCase) []types.JobCase {
	out := make([]types.JobCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		a, b := out[i], out[j]
		if a.PriorityRev != b.PriorityRev {
			return a.PriorityRev > b.PriorityRev
		}
		if a.Priority != b.Priority {
			return a.Priority > b.Priority
		}
		if a.CarbonWeight != b.CarbonWeight {
			return a.CarbonWeight > b.CarbonWeight
		}
		return a.JobID < b.JobID
	})
	return out
}
