package z1

// RxGap totals gram reservation waste for one job wave.
func RxGap(reserved, used int) int {
	if reserved <= used {
		return 0
	}
	return reserved - used
}
