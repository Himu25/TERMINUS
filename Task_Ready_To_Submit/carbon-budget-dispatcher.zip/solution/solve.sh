#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/carbon.toml
require_file /app/data/job_specs.jsonl
require_file /app/data/region_intensity.csv
require_file /app/data/runtime_overlay.csv
mkdir -p /app/bin /app/output

log "apply patched sources"
cp "${ROOT_DIR}/oracle/p2_order.go" /app/q9/p2_order.go
cp "${ROOT_DIR}/oracle/d4_hold.go" /app/k2/d4_hold.go
cp "${ROOT_DIR}/oracle/w5_roll.go" /app/z1/w5_roll.go

log "rebuild dispatcher"
bash /app/scripts/build.sh

log "refresh default job bundle"
/app/bin/jobpack /app/data/job_specs.jsonl /app/data/jobs_default.jsonl

log "emit default dispatch report"
/app/tools/run_dispatch

log "post-run validation against carbon.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/carbon.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k in ("min_completion_rate", "max_waste_ratio", "min_emissions_saved"):
        cfg[k] = float(v)
    elif k.startswith("max_") or k.startswith("min_") or k == "carbon_budget_grams":
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/dispatch_report.json").read_text())
assert report["status"] == "ok", report
assert report["completion_rate"] >= cfg["min_completion_rate"]
assert report["waste_ratio"] <= cfg["max_waste_ratio"]
assert report["dep_violations"] <= cfg["max_dep_violations"]
assert report["schedule_inversions"] <= cfg["max_schedule_inversions"]
assert report["renew_deferred"] >= cfg["min_renew_deferred"]
assert report["emissions_saved"] >= cfg["min_emissions_saved"]
for row in report["jobs"]:
    if row["job_id"].startswith("j_dep_") and row["completed"]:
        assert row["dep_ready"], row
print("ok", report["completion_rate"], report["waste_ratio"], report["emissions_saved"])
PY

log "oracle complete"
