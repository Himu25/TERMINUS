# Manifest contract

`scenario_runs` holds one object per invocation.

- `scenario_tag` — pack label from the case bundle.
- `applied_labels` — corpus keys with a durable human mark after merge.
- `conflict_resolved` — contradictory human marks on the same revision where the higher sequence wins.
- `stale_blocked` — human marks rejected because sequence does not advance the head, including below a rollback restore head.
- `CONFLICT_HOLD` — a sentinel hold on a corpus key suppresses later `HUMAN` marks for that key only; sibling keys are unaffected.
- `rollback_clean` — `1` when final merged heads show no key still above its rollback-restored snapshot floor; `0` if any post-rollback human mark re-elevates a key. Evaluated after the full pipeline, not at the rollback row alone.
- `consistency_drift` — keys whose final mark differs from the pack canonical table.
- `replay_dup` — duplicate deliveries removed before ordering.
