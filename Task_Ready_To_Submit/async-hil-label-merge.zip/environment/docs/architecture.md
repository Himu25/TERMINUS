# Pipeline layout

Correction packs flow through replay dedupe, ingest ordering, reviewer hold filtering, rollback preparation, and the Rust seal pass. Each stage mutates the in-memory stream before manifest emission.
