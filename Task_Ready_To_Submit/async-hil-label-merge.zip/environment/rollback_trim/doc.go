// Package rollback_trim prepares rollback rows for the seal pass.
package rollback_trim
