package runner

import (
	"hilbench/eventwire"
	"hilbench/verdict_gate"
)

func runGate(rows []eventwire.StreamRow) []eventwire.StreamRow {
	return verdict_gate.FilterSpan(rows)
}
