package runner

import (
	"hilbench/eventwire"
	"hilbench/label_seal"
)

func runSeal(rows []eventwire.StreamRow, canonical map[string]string, snaps map[string]map[string]eventwire.SnapCell) label_seal.Manifest {
	return label_seal.MeterSpan(rows, canonical, snaps)
}
