package runner

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"

	"hilbench/eventwire"
)

// PackRun is one scenario row in the manifest JSON.
type PackRun struct {
	ScenarioTag      string `json:"scenario_tag"`
	AppliedLabels    int    `json:"applied_labels"`
	ConflictResolved int    `json:"conflict_resolved"`
	StaleBlocked     int    `json:"stale_blocked"`
	RollbackClean    int    `json:"rollback_clean"`
	ConsistencyDrift int    `json:"consistency_drift"`
	ReplayDup        int    `json:"replay_dup"`
}

type packPayload struct {
	ScenarioRuns []PackRun `json:"scenario_runs"`
}

// Run loads one pack via tb_pack and writes /app/output/label_manifest.json.
func Run() error {
	stem := os.Getenv("tb_pack")
	if stem == "" {
		return errors.New("tb_pack must name a stem under /app/cases")
	}
	emit := "/app/output/label_manifest.json"
	raw, err := os.ReadFile(filepath.Join("/app", "cases", stem+".json"))
	if err != nil {
		return err
	}
	var bundle eventwire.Bundle
	if err := json.Unmarshal(raw, &bundle); err != nil {
		return err
	}
	trimmed, dup := runClip(bundle.Stream)
	filtered := runGate(trimmed)
	ordered := runOrder(filtered)
	swept := runSweep(ordered, bundle.Snapshots)
	view := runSeal(swept, bundle.Canonical, bundle.Snapshots)
	run := PackRun{
		ScenarioTag:      bundle.ScenarioLabel,
		AppliedLabels:    view.AppliedLabels,
		ConflictResolved: view.ConflictResolved,
		StaleBlocked:     view.StaleBlocked,
		RollbackClean:    view.RollbackClean,
		ConsistencyDrift: view.ConsistencyDrift,
		ReplayDup:        dup,
	}
	out := packPayload{ScenarioRuns: []PackRun{run}}
	if err := os.MkdirAll(filepath.Dir(emit), 0o755); err != nil {
		return err
	}
	buf, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		return err
	}
	tmp := emit + ".tmp"
	if err := os.WriteFile(tmp, buf, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, emit)
}

// MainExit is the cmd entry wrapper.
func MainExit() int {
	if err := Run(); err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		return 1
	}
	return 0
}
