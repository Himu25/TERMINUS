package runner

import (
	"hilbench/eventwire"
	"hilbench/rollback_trim"
)

func runSweep(rows []eventwire.StreamRow, snaps map[string]map[string]eventwire.SnapCell) []eventwire.StreamRow {
	return rollback_trim.SweepSpan(rows, snaps)
}
