// Package runner drives one scenario pack through the hil merge pipeline.
package runner
