package runner

import (
	"hilbench/eventwire"
	"hilbench/replay_lane"
)

func runClip(rows []eventwire.StreamRow) ([]eventwire.StreamRow, int) {
	return replay_lane.ClipSpan(rows)
}
