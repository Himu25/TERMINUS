package runner

import (
	"hilbench/eventwire"
	"hilbench/ingest_fold"
)

func runOrder(rows []eventwire.StreamRow) []eventwire.StreamRow {
	return ingest_fold.OrderSpan(rows)
}
