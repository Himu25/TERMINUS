# Hil merge worker

Mixed Go and Rust pipeline that ingests correction packs from `/app/cases` and emits label manifests under `/app/output`.
