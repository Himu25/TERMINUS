module hilbench

go 1.22
