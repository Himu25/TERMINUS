package eventwire

// StreamRow is one correction or control event in arrival order.
type StreamRow struct {
	CorpusKey string `json:"corpus_key"`
	RevID     int    `json:"rev_id"`
	Lane      string `json:"lane"`
	Mark      string `json:"mark"`
	SeqNo     int    `json:"seq_no"`
	RecvMS    int    `json:"recv_ms"`
	Sentinel  bool   `json:"sentinel"`
}

// SnapCell is a frozen revision snapshot for rollback.
type SnapCell struct {
	RevID int    `json:"rev_id"`
	Mark  string `json:"mark"`
	SeqNo int    `json:"seq_no"`
}

// Bundle is one scenario pack under /app/cases.
type Bundle struct {
	ScenarioLabel string                       `json:"scenario_label"`
	Stream        []StreamRow                  `json:"stream"`
	Snapshots     map[string]map[string]SnapCell `json:"snapshots,omitempty"`
	Canonical     map[string]string            `json:"canonical"`
}
