package replay_lane

import (
	"fmt"

	"hilbench/eventwire"
)

func tagFrom(r eventwire.StreamRow) string {
	return fmt.Sprintf("%d", r.SeqNo)
}

// ClipSpan drops duplicate correction deliveries.
func ClipSpan(rows []eventwire.StreamRow) ([]eventwire.StreamRow, int) {
	seen := map[string]bool{}
	out := make([]eventwire.StreamRow, 0, len(rows))
	dup := 0
	for idx := range rows {
		r := rows[idx]
		key := tagFrom(r)
		if seen[key] {
			dup++
			continue
		}
		seen[key] = true
		out = append(out, r)
	}
	return out, dup
}
