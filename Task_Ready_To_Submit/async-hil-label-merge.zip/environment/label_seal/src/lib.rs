use std::collections::HashMap;
use std::ffi::CStr;
use std::os::raw::{c_char, c_int};

#[repr(C)]
pub struct LfRow {
    pub corpus_key: *const c_char,
    pub rev_id: c_int,
    pub lane: *const c_char,
    pub mark: *const c_char,
    pub seq_no: c_int,
    pub sentinel: bool,
}

#[repr(C)]
pub struct LfRoll {
    pub applied_labels: c_int,
    pub conflict_resolved: c_int,
    pub stale_blocked: c_int,
    pub rollback_clean: c_int,
    pub consistency_drift: c_int,
}

#[derive(Clone)]
struct RowView {
    corpus: String,
    rev_id: i32,
    lane: String,
    mark: String,
    seq_no: i32,
}

#[derive(Clone)]
struct Head {
    rev_id: i32,
    mark: String,
    seq_no: i32,
}

fn parse_canon(blob: &str) -> HashMap<String, String> {
    if blob.is_empty() {
        return HashMap::new();
    }
    serde_json::from_str(blob).unwrap_or_default()
}

fn parse_snap(blob: &str) -> HashMap<String, HashMap<i32, Head>> {
    let mut out: HashMap<String, HashMap<i32, Head>> = HashMap::new();
    if blob.is_empty() {
        return out;
    }
    let v: serde_json::Value = match serde_json::from_str(blob) {
        Ok(x) => x,
        Err(_) => return out,
    };
    let Some(obj) = v.as_object() else {
        return out;
    };
    for (corpus, revs) in obj {
        let Some(rev_obj) = revs.as_object() else {
            continue;
        };
        let mut table = HashMap::new();
        for (rev_s, cell) in rev_obj {
            let Ok(rev_id) = rev_s.parse::<i32>() else {
                continue;
            };
            let mark = cell
                .get("mark")
                .and_then(|m| m.as_str())
                .unwrap_or("")
                .to_string();
            let seq_no = cell.get("seq_no").and_then(|s| s.as_i64()).unwrap_or(0) as i32;
            table.insert(
                rev_id,
                Head {
                    rev_id,
                    mark,
                    seq_no,
                },
            );
        }
        out.insert(corpus.clone(), table);
    }
    out
}

fn row_at(raw: &LfRow) -> Option<RowView> {
    unsafe {
        Some(RowView {
            corpus: CStr::from_ptr(raw.corpus_key).to_str().ok()?.to_string(),
            rev_id: raw.rev_id,
            lane: CStr::from_ptr(raw.lane).to_str().ok()?.to_string(),
            mark: CStr::from_ptr(raw.mark).to_str().ok()?.to_string(),
            seq_no: raw.seq_no,
        })
    }
}

fn apply_rollback(
    state: &mut HashMap<String, Head>,
    snaps: &HashMap<String, HashMap<i32, Head>>,
    corpus: &str,
    target_rev: i32,
) -> i32 {
    if let Some(table) = snaps.get(corpus) {
        if let Some(cell) = table.get(&target_rev) {
            state.insert(corpus.to_string(), cell.clone());
            return 0;
        }
    }
    if let Some(head) = state.get(corpus) {
        if head.rev_id >= target_rev {
            state.remove(corpus);
        }
    }
    0
}

fn meter(rows: &[RowView], canonical: &HashMap<String, String>, snaps: &HashMap<String, HashMap<i32, Head>>) -> LfRoll {
    let mut state: HashMap<String, Head> = HashMap::new();
    let mut stale_blocked = 0;
    let mut conflict_resolved = 0;
    let mut rollback_violations = 0;

    for r in rows {
        if r.lane == "ROLLBACK" {
            let prev = state.get(&r.corpus).cloned();
            rollback_violations += apply_rollback(&mut state, snaps, &r.corpus, r.rev_id);
            if let (Some(mut head), Some(p)) = (state.get_mut(&r.corpus).cloned(), prev) {
                if head.seq_no < p.seq_no {
                    head.seq_no = p.seq_no;
                    state.insert(r.corpus.clone(), head);
                }
            }
            continue;
        }
        if r.lane != "HUMAN" {
            continue;
        }
        if let Some(h) = state.get(&r.corpus) {
            if h.rev_id == r.rev_id && h.mark != r.mark {
                conflict_resolved += 1;
            }
        }
        state.insert(
            r.corpus.clone(),
            Head {
                rev_id: r.rev_id,
                mark: r.mark.clone(),
                seq_no: r.seq_no,
            },
        );
    }

    let mut drift = 0;
    for (key, want) in canonical {
        let got = state.get(key).map(|h| h.mark.as_str()).unwrap_or("");
        if got != want.as_str() {
            drift += 1;
        }
    }
    let rollback_clean = if rollback_violations == 0 { 1 } else { 0 };
    LfRoll {
        applied_labels: state.len() as c_int,
        conflict_resolved,
        stale_blocked,
        rollback_clean,
        consistency_drift: drift,
    }
}

#[no_mangle]
pub extern "C" fn lf_meter_span(
    rows: *const LfRow,
    count: usize,
    canon_blob: *const c_char,
    snap_blob: *const c_char,
) -> LfRoll {
    let read_blob = |ptr: *const c_char| -> String {
        if ptr.is_null() {
            return String::new();
        }
        unsafe {
            CStr::from_ptr(ptr)
                .to_str()
                .unwrap_or("")
                .to_string()
        }
    };
    let canonical = parse_canon(&read_blob(canon_blob));
    let snaps = parse_snap(&read_blob(snap_blob));

    let mut parsed = Vec::with_capacity(count);
    if !rows.is_null() {
        let slice = unsafe { std::slice::from_raw_parts(rows, count) };
        for raw in slice {
            if let Some(v) = row_at(raw) {
                parsed.push(v);
            }
        }
    }
    meter(&parsed, &canonical, &snaps)
}
