#pragma once

#include <stdbool.h>
#include <stddef.h>

typedef struct lf_row {
  const char *corpus_key;
  int rev_id;
  const char *lane;
  const char *mark;
  int seq_no;
  bool sentinel;
} lf_row;

typedef struct lf_roll {
  int applied_labels;
  int conflict_resolved;
  int stale_blocked;
  int rollback_clean;
  int consistency_drift;
} lf_roll;

struct lf_roll lf_meter_span(const struct lf_row *rows, size_t count,
                             const char *canon_blob, const char *snap_blob);
