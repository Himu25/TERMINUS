// Package label_seal binds the Rust label fold static library.
package label_seal
