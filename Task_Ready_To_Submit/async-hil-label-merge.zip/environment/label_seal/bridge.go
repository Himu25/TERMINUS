package label_seal

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/liblabel_fold.a -ldl -lm
#include "seal_fold.h"
#include <stdlib.h>
*/
import "C"

import (
	"encoding/json"
	"unsafe"

	"hilbench/eventwire"
)

// Manifest is one scenario emission row.
type Manifest struct {
	AppliedLabels    int
	ConflictResolved int
	StaleBlocked     int
	RollbackClean    int
	ConsistencyDrift int
}

// MeterSpan folds delayed human corrections into manifest metrics.
func MeterSpan(rows []eventwire.StreamRow, canonical map[string]string, snaps map[string]map[string]eventwire.SnapCell) Manifest {
	keepers := make([]*C.char, 0, len(rows)*4+2)
	defer freeAll(keepers)

	cRows := make([]C.lf_row, len(rows))
	for idx := range rows {
		r := rows[idx]
		c := C.CString(r.CorpusKey)
		l := C.CString(r.Lane)
		m := C.CString(r.Mark)
		keepers = append(keepers, c, l, m)
		cRows[idx] = C.lf_row{
			corpus_key: c,
			rev_id:     C.int(r.RevID),
			lane:       l,
			mark:       m,
			seq_no:     C.int(r.SeqNo),
			sentinel:   C.bool(r.Sentinel),
		}
	}
	var rowPtr *C.lf_row
	if len(cRows) > 0 {
		rowPtr = (*C.lf_row)(unsafe.Pointer(&cRows[0]))
	}
	canon := cStr(jsonBlob(canonical), &keepers)
	snap := cStr(snapJSON(snaps), &keepers)
	ct := C.lf_meter_span(rowPtr, C.size_t(len(cRows)), canon, snap)
	return manifestFrom(ct)
}

func jsonBlob(v any) string {
	if v == nil {
		return ""
	}
	buf, err := json.Marshal(v)
	if err != nil {
		return ""
	}
	return string(buf)
}

func snapJSON(snaps map[string]map[string]eventwire.SnapCell) string {
	if len(snaps) == 0 {
		return ""
	}
	return jsonBlob(snaps)
}

func cStr(s string, keepers *[]*C.char) *C.char {
	p := C.CString(s)
	*keepers = append(*keepers, p)
	return p
}

func freeAll(ptrs []*C.char) {
	for _, p := range ptrs {
		C.free(unsafe.Pointer(p))
	}
}

func manifestFrom(ct C.lf_roll) Manifest {
	return Manifest{
		AppliedLabels:    int(ct.applied_labels),
		ConflictResolved: int(ct.conflict_resolved),
		StaleBlocked:     int(ct.stale_blocked),
		RollbackClean:    int(ct.rollback_clean),
		ConsistencyDrift: int(ct.consistency_drift),
	}
}
