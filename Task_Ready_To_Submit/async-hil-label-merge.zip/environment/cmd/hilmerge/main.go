package main

import (
	"os"

	"hilbench/internal/runner"
)

func main() {
	os.Exit(runner.MainExit())
}
