package ingest_fold

import (
	"sort"

	"hilbench/eventwire"
)

// OrderSpan sorts the stream for merge application.
func OrderSpan(rows []eventwire.StreamRow) []eventwire.StreamRow {
	out := make([]eventwire.StreamRow, len(rows))
	copy(out, rows)
	sort.Slice(out, func(i, j int) bool {
		return out[i].RecvMS < out[j].RecvMS
	})
	return out
}
