// Package ingest_fold orders inbound correction events for merge.
package ingest_fold
