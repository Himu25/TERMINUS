package verdict_gate

import "hilbench/eventwire"

// FilterSpan applies reviewer hold rows before human marks merge.
func FilterSpan(rows []eventwire.StreamRow) []eventwire.StreamRow {
	out := make([]eventwire.StreamRow, 0, len(rows))
	frozen := false
	for idx := range rows {
		r := rows[idx]
		if r.Lane == "CONFLICT_HOLD" && r.Sentinel {
			frozen = true
			out = append(out, r)
			continue
		}
		if frozen && r.Lane == "HUMAN" {
			continue
		}
		out = append(out, r)
	}
	return out
}
