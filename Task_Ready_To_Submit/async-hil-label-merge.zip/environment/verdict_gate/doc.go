// Package verdict_gate applies reviewer hold rows before human merge.
package verdict_gate
