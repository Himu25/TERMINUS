"""Verifier for async human-in-the-loop label manifest emission."""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

APP = Path("/app")
REPORT = APP / "output" / "label_manifest.json"


def _stem_tag(stem: str) -> str:
    bundle = json.loads((APP / "cases" / f"{stem}.json").read_text(encoding="utf-8"))
    return str(bundle["scenario_label"])


def _drive(stem: str) -> dict:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    if REPORT.exists():
        REPORT.unlink()
    subprocess.run(
        ["/app/bin/hilmerge"],
        cwd=str(APP),
        env={**os.environ, "tb_pack": stem},
        check=True,
    )
    payload = json.loads(REPORT.read_text(encoding="utf-8"))
    assert "scenario_runs" in payload and len(payload["scenario_runs"]) == 1
    row = payload["scenario_runs"][0]
    assert row.get("scenario_tag") == _stem_tag(stem)
    return row


def _assert_row(
    row: dict,
    *,
    applied_labels: int,
    conflict_resolved: int,
    stale_blocked: int,
    rollback_clean: int,
    consistency_drift: int,
    replay_dup: int,
) -> None:
    assert row["applied_labels"] == applied_labels
    assert row["conflict_resolved"] == conflict_resolved
    assert row["stale_blocked"] == stale_blocked
    assert row["rollback_clean"] == rollback_clean
    assert row["consistency_drift"] == consistency_drift
    assert row["replay_dup"] == replay_dup



def test_pack_alpha() -> None:
    """Delayed corrections on the same revision must follow sequence order, not ingest time."""
    row = _drive("pack_alpha")
    _assert_row(
        row,
        applied_labels=2,
        conflict_resolved=1,
        stale_blocked=0,
        rollback_clean=1,
        consistency_drift=0,
        replay_dup=0,
    )


def test_pack_beta() -> None:
    """Contradictory marks on one revision resolve to the higher sequence winner."""
    row = _drive("pack_beta")
    _assert_row(
        row,
        applied_labels=1,
        conflict_resolved=1,
        stale_blocked=0,
        rollback_clean=1,
        consistency_drift=0,
        replay_dup=0,
    )


def test_pack_canyon() -> None:
    """Hold on one key leaves a sibling key free to reach its canonical mark."""
    row = _drive("pack_canyon")
    _assert_row(
        row,
        applied_labels=1,
        conflict_resolved=1,
        stale_blocked=0,
        rollback_clean=1,
        consistency_drift=1,
        replay_dup=0,
    )


def test_pack_delta() -> None:
    """A hold row for one corpus key must not block human marks on another key."""
    row = _drive("pack_delta")
    _assert_row(
        row,
        applied_labels=1,
        conflict_resolved=0,
        stale_blocked=0,
        rollback_clean=1,
        consistency_drift=1,
        replay_dup=0,
    )


def test_pack_echo() -> None:
    """Duplicate deliveries with the same sequence on different keys must not collapse."""
    row = _drive("pack_echo")
    _assert_row(
        row,
        applied_labels=2,
        conflict_resolved=0,
        stale_blocked=0,
        rollback_clean=1,
        consistency_drift=0,
        replay_dup=1,
    )


def test_pack_frost() -> None:
    """Rollback must restore the snapshot revision without drift from the canonical mark."""
    row = _drive("pack_frost")
    _assert_row(
        row,
        applied_labels=1,
        conflict_resolved=0,
        stale_blocked=0,
        rollback_clean=1,
        consistency_drift=0,
        replay_dup=0,
    )


def test_pack_gamma() -> None:
    """Two human marks on one revision keep the later sequence value."""
    row = _drive("pack_gamma")
    _assert_row(
        row,
        applied_labels=1,
        conflict_resolved=1,
        stale_blocked=0,
        rollback_clean=1,
        consistency_drift=0,
        replay_dup=0,
    )


def test_pack_haze() -> None:
    """Out-of-order ingest timestamps still merge to sequence-ordered heads."""
    row = _drive("pack_haze")
    _assert_row(
        row,
        applied_labels=3,
        conflict_resolved=2,
        stale_blocked=0,
        rollback_clean=1,
        consistency_drift=0,
        replay_dup=0,
    )


def test_pack_iron() -> None:
    """Multiple conflicting marks resolve through sequence precedence without drift."""
    row = _drive("pack_iron")
    _assert_row(
        row,
        applied_labels=1,
        conflict_resolved=3,
        stale_blocked=0,
        rollback_clean=1,
        consistency_drift=0,
        replay_dup=0,
    )


def test_pack_jade() -> None:
    """Shared sequence numbers across keys remain independent after replay dedupe."""
    row = _drive("pack_jade")
    _assert_row(
        row,
        applied_labels=2,
        conflict_resolved=2,
        stale_blocked=0,
        rollback_clean=1,
        consistency_drift=0,
        replay_dup=0,
    )


def test_pack_kite() -> None:
    """Per-key hold rows block only the disputed corpus key."""
    row = _drive("pack_kite")
    _assert_row(
        row,
        applied_labels=1,
        conflict_resolved=0,
        stale_blocked=0,
        rollback_clean=1,
        consistency_drift=1,
        replay_dup=0,
    )


def test_pack_loom() -> None:
    """Late high-sequence corrections win over early low-sequence marks on one revision."""
    row = _drive("pack_loom")
    _assert_row(
        row,
        applied_labels=1,
        conflict_resolved=1,
        stale_blocked=0,
        rollback_clean=1,
        consistency_drift=0,
        replay_dup=0,
    )


def test_pack_mist() -> None:
    """Replay dedupe must not drop independent keys sharing a sequence number."""
    row = _drive("pack_mist")
    _assert_row(
        row,
        applied_labels=2,
        conflict_resolved=1,
        stale_blocked=0,
        rollback_clean=1,
        consistency_drift=0,
        replay_dup=1,
    )


def test_pack_nova() -> None:
    """Rollback on one key while another key keeps its human mark."""
    row = _drive("pack_nova")
    _assert_row(
        row,
        applied_labels=2,
        conflict_resolved=1,
        stale_blocked=0,
        rollback_clean=1,
        consistency_drift=0,
        replay_dup=0,
    )


def test_pack_ozone() -> None:
    """Lower-sequence shadow marks cannot replace a higher-sequence prime mark."""
    row = _drive("pack_ozone")
    _assert_row(
        row,
        applied_labels=1,
        conflict_resolved=1,
        stale_blocked=0,
        rollback_clean=1,
        consistency_drift=0,
        replay_dup=0,
    )


def test_pack_peak() -> None:
    """Composite pack mixes dedupe, conflict resolution, and canonical alignment."""
    row = _drive("pack_peak")
    _assert_row(
        row,
        applied_labels=2,
        conflict_resolved=2,
        stale_blocked=0,
        rollback_clean=1,
        consistency_drift=0,
        replay_dup=1,
    )


def test_pack_stale() -> None:
    """After rollback restore, sub-head sequence marks count as stale blocks."""
    row = _drive("pack_stale")
    _assert_row(
        row,
        applied_labels=1,
        conflict_resolved=1,
        stale_blocked=1,
        rollback_clean=1,
        consistency_drift=0,
        replay_dup=0,
    )


def test_pack_tide() -> None:
    """Later human marks that re-elevate revision after rollback report rollback_clean as zero."""
    row = _drive("pack_tide")
    _assert_row(
        row,
        applied_labels=1,
        conflict_resolved=1,
        stale_blocked=0,
        rollback_clean=0,
        consistency_drift=1,
        replay_dup=0,
    )
