#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TASK_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

if [ -f "/app/go.mod" ] && [ -d "/app/ingest_fold" ]; then
  env_dir="/app"
elif [ -d "$TASK_DIR/environment" ]; then
  env_dir="$TASK_DIR/environment"
elif [ -d "/environment" ] && [ -f "/environment/go.mod" ]; then
  env_dir="/environment"
else
  echo "Could not locate task environment layout." >&2
  exit 1
fi

cd "$SCRIPT_DIR"
patch -p1 --forward -d "$env_dir" <fixes.patch

bash "$env_dir/scripts/build.sh"

if [ ! -x "$env_dir/bin/hilmerge" ]; then
  echo "hilmerge binary missing after rebuild" >&2
  exit 1
fi

for probe in pack_alpha pack_stale pack_echo pack_tide; do
  rm -f "$env_dir/output/label_manifest.json"
  (
    cd "$env_dir"
    export tb_pack="$probe"
    ./bin/hilmerge >/dev/null
  )
  if [ ! -s "$env_dir/output/label_manifest.json" ]; then
    echo "probe pack $probe produced no manifest" >&2
    exit 1
  fi
done

echo "Oracle applied merge ordering, dedupe scope, hold scope, pipeline stage order, and seal fixes."
