"""Verifier for /app/output/recovery_report.json."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
REPORT = APP / "output" / "recovery_report.json"
SCENARIOS = APP / "fixtures" / "scenarios"
OFFSETS = APP / "data" / "offsets" / "committed.json"
DEFAULTS = APP / "config" / "defaults.yaml"


def _env() -> dict[str, str]:
    return os.environ.copy()


def rebuild_binaries() -> None:
    subprocess.run(
        ["go", "build", "-o", "/app/brokerd", "./cmd/brokerd"],
        cwd=str(APP),
        check=True,
        env=_env(),
    )
    subprocess.run(
        ["cargo", "build", "--release", "--bin", "ledgerd"],
        cwd=str(APP / "rollup"),
        check=True,
        env=_env(),
    )
    shutil.copy2(APP / "rollup" / "target" / "release" / "ledgerd", APP / "ledgerd")


def run_brokerd(extra: dict[str, str] | None = None) -> None:
    env = _env()
    if extra:
        env.update(extra)
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        [
            "/app/brokerd",
            "-scenarios",
            str(SCENARIOS),
            "-out",
            str(REPORT),
        ],
        cwd=str(APP),
        check=True,
        env=env,
    )


def _load_scenario(name: str) -> dict:
    return json.loads((SCENARIOS / f"{name}.json").read_text())


def _load_offsets() -> dict[str, int]:
    return json.loads(OFFSETS.read_text())["rows"]


def _max_pending() -> int:
    for line in DEFAULTS.read_text().splitlines():
        if line.startswith("max_pending:"):
            return int(line.split(":", 1)[1].strip())
    return 512


def _digest(accounts: list[dict]) -> str:
    lines = [f"{a['id']}:{a['balance']}:{a['version']}" for a in sorted(accounts, key=lambda x: x["id"])]
    body = "\n".join(lines) + "\n"
    proc = subprocess.run(
        ["openssl", "dgst", "-sha256", "-hex"],
        input=body,
        text=True,
        capture_output=True,
        check=True,
    )
    hex_line = proc.stdout.strip().split()[-1]
    return hex_line.lower()


def _reference_outcome(scenario: dict, cut_seq: int) -> dict:
    accounts = {a["id"]: dict(a) for a in scenario["initial"]}
    seen: set[str] = set()
    applied = 0
    skipped = 0
    cap = _max_pending()

    pending: dict[int, list[dict]] = {}
    collected: list[dict] = []
    for wire in scenario["wire"]:
        pending.setdefault(wire["flush_id"], []).append(wire)
        if len(pending[wire["flush_id"]]) >= cap:
            collected.extend(pending.pop(wire["flush_id"]))
    for batch in pending.values():
        collected.extend(batch)

    ordered = sorted(collected, key=lambda w: w["seq"])
    for entry in ordered:
        if entry["seq"] <= cut_seq:
            skipped += 1
            continue
        key = f"{entry['stream']}:{entry['seq']}"
        if key in seen:
            skipped += 1
            continue
        seen.add(key)
        row = accounts.setdefault(
            entry["target"],
            {"id": entry["target"], "balance": 0, "version": 0},
        )
        if entry["kind"] == "credit":
            row["balance"] += entry["amount"]
        elif entry["kind"] == "debit":
            row["balance"] -= entry["amount"]
        row["version"] += 1
        applied += 1

    acct_rows = sorted(accounts.values(), key=lambda a: a["id"])
    return {
        "safe_cut_seq": cut_seq,
        "applied_count": applied,
        "skipped_dup": skipped,
        "accounts": acct_rows,
        "state_digest_hex": _digest(acct_rows),
    }


def _expected(name: str) -> dict:
    scenario = _load_scenario(name)
    cut = scenario.get("committed_watermark", 0)
    offsets = _load_offsets()
    if name in offsets:
        cut = offsets[name]
    return _reference_outcome(scenario, cut)


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    rebuild_binaries()


@pytest.fixture()
def report() -> dict:
    run_brokerd()
    return json.loads(REPORT.read_text())


def _scenario(report: dict, name: str) -> dict:
    for row in report["scenarios"]:
        if row["name"] == name:
            return row
    raise AssertionError(f"missing scenario {name!r}")


def test_report_schema(report: dict) -> None:
    """recovery_report.json matches the published contract."""
    assert isinstance(report, dict)
    rows = report["scenarios"]
    assert isinstance(rows, list) and len(rows) == 3
    names = sorted(r["name"] for r in rows)
    assert names == ["ooo_shard", "retry_burst", "rewind_storm"]
    for row in rows:
        assert set(row.keys()) >= {
            "name",
            "finish_reason",
            "safe_cut_seq",
            "applied_count",
            "skipped_dup",
            "accounts",
            "state_digest_hex",
        }


def test_all_scenarios_complete(report: dict) -> None:
    """Every bundled scenario reaches a completed recovery run."""
    for name in ("rewind_storm", "retry_burst", "ooo_shard"):
        assert _scenario(report, name)["finish_reason"] == "complete"


def test_rewind_storm_cut_and_digest(report: dict) -> None:
    """Rewind scenario exposes the committed cut and expected digest."""
    exp = _expected("rewind_storm")
    row = _scenario(report, "rewind_storm")
    assert row["safe_cut_seq"] == exp["safe_cut_seq"]
    assert row["state_digest_hex"] == exp["state_digest_hex"]


def test_rewind_storm_balances(report: dict) -> None:
    """Rewind scenario leaves account A settled without double counting replayed rows."""
    exp = {a["id"]: a for a in _expected("rewind_storm")["accounts"]}
    acct = {a["id"]: a for a in _scenario(report, "rewind_storm")["accounts"]}
    assert acct["A"] == exp["A"]


def test_retry_burst_no_double_apply(report: dict) -> None:
    """Retry burst applies each live row once and matches the golden digest."""
    exp = _expected("retry_burst")
    row = _scenario(report, "retry_burst")
    assert row["applied_count"] == exp["applied_count"]
    acct = {a["id"]: a for a in row["accounts"]}
    assert acct["A"] == {a["id"]: a for a in exp["accounts"]}["A"]
    assert row["state_digest_hex"] == exp["state_digest_hex"]


def test_ooo_shard_ordering_digest(report: dict) -> None:
    """Out-of-order ingress still settles both accounts with the expected digest."""
    exp = _expected("ooo_shard")
    row = _scenario(report, "ooo_shard")
    acct = {a["id"]: a for a in row["accounts"]}
    for key, want in {a["id"]: a for a in exp["accounts"]}.items():
        assert acct[key]["balance"] == want["balance"]
    assert row["state_digest_hex"] == exp["state_digest_hex"]


def test_ooo_shard_version_monotonic(report: dict) -> None:
    """Shard ordering keeps per-account version counters aligned with two live applies."""
    exp = _expected("ooo_shard")
    row = _scenario(report, "ooo_shard")
    acct = {a["id"]: a for a in row["accounts"]}
    for key, want in {a["id"]: a for a in exp["accounts"]}.items():
        assert acct[key]["version"] == want["version"]
    assert row["applied_count"] == exp["applied_count"]


def test_fastpath_ignored() -> None:
    """Documented fast-path env var does not change settled digests."""
    run_brokerd({"BROKERD_UNSAFE_FASTPATH": "1"})
    report = json.loads(REPORT.read_text())
    for name in ("rewind_storm", "retry_burst", "ooo_shard"):
        exp = _expected(name)
        assert _scenario(report, name)["state_digest_hex"] == exp["state_digest_hex"]


def test_rebuild_from_source(report: dict) -> None:
    """Fresh go and rust rebuilds reproduce the same recovery report."""
    rebuild_binaries()
    run_brokerd()
    again = json.loads(REPORT.read_text())
    assert again["scenarios"] == report["scenarios"]
