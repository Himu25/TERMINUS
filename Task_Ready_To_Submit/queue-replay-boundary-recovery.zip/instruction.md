Our async ingress stack under `/app` couples a Go flush driver with a Rust ledger worker. Operations rolled the broker back to an earlier file position and replayed a huge backlog. The bundled scenarios `rewind_storm.json`, `retry_burst.json`, and `ooo_shard.json` under `/app/fixtures/scenarios` now report wrong cut points, inflated apply counts, and account rows that disagree with the committed offset snapshot in `/app/data/offsets/committed.json`. Replays reintroduce already-settled sequence numbers, flush ticks deliver the same wire batch twice, and wire indices sometimes run ahead of sequence order.

Run `/app/ops/run_recovery.sh`. It rebuilds the Go driver and Rust ledger worker, then drives those three JSON fixtures. Write `/app/output/recovery_report.json` as JSON with a top-level `scenarios` array. Each element is one object with these fields:

- `name` — scenario id matching the fixture basename
- `finish_reason` — recovery status string; every bundled scenario should read `complete`
- `safe_cut_seq` — committed cut sequence used for replay
- `applied_count` — number of wire rows applied after deduplication
- `skipped_dup` — rows skipped as duplicates or at/before the cut
- `accounts` — array of `{id, balance, version}` account rows after recovery
- `state_digest_hex` — lowercase hex SHA-256 over sorted canonical `id:balance:version` lines joined with newlines

Setting `BROKERD_UNSAFE_FASTPATH=1` must not change any settled `state_digest_hex` values.
