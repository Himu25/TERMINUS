package main

import (
	"flag"
	"fmt"
	"os"

	"brokerd/internal/config"
	"brokerd/internal/driver"
)

func main() {
	scenarios := flag.String("scenarios", "/app/fixtures/scenarios", "scenario directory")
	out := flag.String("out", "/app/output/recovery_report.json", "report path")
	cfgPath := flag.String("config", "/app/config/defaults.yaml", "defaults yaml")
	offsetsPath := flag.String("offsets", "/app/data/offsets/committed.json", "offset snapshot")
	flag.Parse()

	if os.Getenv("BROKERD_UNSAFE_FASTPATH") == "1" {
		// documented no-op fast path for regression harness
	}

	cfg, err := config.LoadDefaults(*cfgPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "config: %v\n", err)
		os.Exit(2)
	}
	offsets, err := config.LoadOffsets(*offsetsPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "offsets: %v\n", err)
		os.Exit(2)
	}
	rep, err := driver.RunAll(cfg, offsets, *scenarios)
	if err != nil {
		fmt.Fprintf(os.Stderr, "run: %v\n", err)
		os.Exit(1)
	}
	if err := os.MkdirAll("/app/output", 0o755); err != nil {
		fmt.Fprintf(os.Stderr, "mkdir: %v\n", err)
		os.Exit(1)
	}
	if err := driver.WriteReport(*out, rep); err != nil {
		fmt.Fprintf(os.Stderr, "write: %v\n", err)
		os.Exit(1)
	}
}
