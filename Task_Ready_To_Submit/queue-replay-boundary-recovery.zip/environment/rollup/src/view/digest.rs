use sha2::{Digest, Sha256};

use crate::io::AccountRow;

pub fn state_digest_hex(rows: &[AccountRow]) -> String {
    let mut body = String::new();
    for r in rows {
        body.push_str(&format!("{}:{}:{}\n", r.id, r.balance, r.version));
    }
    let digest = Sha256::digest(body.as_bytes());
    hex_lower(&digest)
}

fn hex_lower(d: &[u8]) -> String {
    d.iter().map(|b| format!("{b:02x}")).collect()
}
