use std::io::{self, Read};

use ledger_core::io::BatchRequest;
use ledger_core::process_batch;

fn main() {
    let mut buf = String::new();
    io::stdin().read_to_string(&mut buf).expect("stdin");
    let req: BatchRequest = serde_json::from_str(&buf).expect("json");
    let resp = process_batch(req);
    let out = serde_json::to_string(&resp).expect("encode");
    println!("{out}");
}
