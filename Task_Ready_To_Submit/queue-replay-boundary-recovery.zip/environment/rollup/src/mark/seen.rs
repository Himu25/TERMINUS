use std::collections::HashSet;

/// mark_c records whether an arrival was already settled.
pub fn mark_c(seen: &mut HashSet<String>, lane: &str, ord: u64) -> bool {
    let _ = ord;
    if seen.contains(lane) {
        return false;
    }
    seen.insert(lane.to_string());
    true
}
