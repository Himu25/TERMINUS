pub mod config;
pub mod io;
pub mod fold;
pub mod mark;
pub mod view;

use std::collections::HashSet;

use io::{AccountRow, BatchRequest, BatchResponse};
use fold::account::{index_initial, touch_entry};
use fold::blend::blend_d;
use mark::seen::mark_c;
use view::digest::state_digest_hex;

pub use io::{AccountRow as ExportedAccountRow, BatchRequest as ExportedBatchRequest, BatchResponse as ExportedBatchResponse, WireEntry};

pub fn process_batch(req: BatchRequest) -> BatchResponse {
    let mut accounts = index_initial(&req.initial);
    let ordered = blend_d(&req.entries);
    let mut seen: HashSet<String> = HashSet::new();
    let mut applied = 0u64;
    let mut skipped = 0u64;

    for entry in ordered {
        if (entry.seq as i64) <= req.cut_seq {
            skipped += 1;
            continue;
        }
        if !mark_c(&mut seen, &entry.stream, entry.seq) {
            skipped += 1;
            continue;
        }
        touch_entry(&mut accounts, &entry);
        applied += 1;
    }

    let mut rows: Vec<AccountRow> = accounts.into_values().collect();
    rows.sort_by(|a, b| a.id.cmp(&b.id));
    let digest = state_digest_hex(&rows);
    BatchResponse {
        accounts: rows,
        applied_count: applied,
        skipped_dup: skipped,
        state_digest_hex: digest,
    }
}
