pub struct Tunables {
    pub trace: bool,
}

impl Default for Tunables {
    fn default() -> Self {
        Self { trace: false }
    }
}
