use std::collections::BTreeMap;

use crate::io::{AccountRow, WireEntry};

pub fn apply_opcode(row: &mut AccountRow, kind: &str, amount: i64) {
    match kind {
        "credit" => row.balance += amount,
        "debit" => row.balance -= amount,
        _ => {}
    }
    row.version += 1;
}

pub fn index_initial(rows: &[AccountRow]) -> BTreeMap<String, AccountRow> {
    let mut m = BTreeMap::new();
    for r in rows {
        m.insert(r.id.clone(), r.clone());
    }
    m
}

pub fn row_mut<'a>(m: &'a mut BTreeMap<String, AccountRow>, id: &str) -> &'a mut AccountRow {
    if !m.contains_key(id) {
        m.insert(
            id.to_string(),
            AccountRow {
                id: id.to_string(),
                balance: 0,
                version: 0,
            },
        );
    }
    m.get_mut(id).unwrap()
}

pub fn touch_entry(m: &mut BTreeMap<String, AccountRow>, entry: &WireEntry) {
    let row = row_mut(m, &entry.target);
    apply_opcode(row, &entry.kind, entry.amount);
}
