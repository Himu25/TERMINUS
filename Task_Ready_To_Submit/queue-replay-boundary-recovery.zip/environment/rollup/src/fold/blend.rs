use crate::io::WireEntry;

/// blend_d orders entries before balance rollup.
pub fn blend_d(entries: &[WireEntry]) -> Vec<WireEntry> {
    let mut out: Vec<WireEntry> = entries.to_vec();
    out.sort_by_key(|e| e.wire);
    out
}
