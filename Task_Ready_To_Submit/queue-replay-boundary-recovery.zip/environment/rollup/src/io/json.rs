use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct AccountRow {
    pub id: String,
    pub balance: i64,
    pub version: i64,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct WireEntry {
    pub stream: String,
    pub seq: u64,
    pub wire: u64,
    pub kind: String,
    pub target: String,
    pub amount: i64,
    pub flush_id: u64,
}

#[derive(Debug, Deserialize)]
pub struct BatchRequest {
    pub initial: Vec<AccountRow>,
    pub entries: Vec<WireEntry>,
    pub cut_seq: i64,
}

#[derive(Debug, Serialize)]
pub struct BatchResponse {
    pub accounts: Vec<AccountRow>,
    pub applied_count: u64,
    pub skipped_dup: u64,
    pub state_digest_hex: String,
}
