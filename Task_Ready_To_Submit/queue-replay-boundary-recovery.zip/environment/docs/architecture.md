# Recovery stack layout

The Go driver under `/app` reads JSON scenarios, groups ingress lines into flush buckets, and forwards batches to the Rust ledger worker at `/app/ledgerd`. The rollup crate under `/app/rollup` deduplicates arrivals and rolls account rows forward before emitting a digest.

Committed offset snapshots live in `/app/data/offsets`. Scenario fixtures live in `/app/fixtures/scenarios`. Defaults in `/app/config/defaults.yaml` cap pending batch size via `max_pending` and locate the ledger binary.
