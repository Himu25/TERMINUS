package stream

import "brokerd/pkg/api"

// Fold forwards flush batches through fold_a.
func Fold(batch []api.WireEntry, apply func(api.WireEntry)) {
	fold_a(batch, apply)
}

// fold_a walks a flush batch and invokes apply for each element.
func fold_a(batch []api.WireEntry, apply func(api.WireEntry)) {
	relay(batch, apply)
	relay(batch, apply)
}

func relay(batch []api.WireEntry, apply func(api.WireEntry)) {
	for _, row := range batch {
		apply(row)
	}
}
