package stream

import "brokerd/pkg/api"

// Buffer holds pending wire lines keyed by flush epoch.
type Buffer struct {
	cap int
	pending map[int][]api.WireEntry
}

// NewBuffer constructs a buffer with capacity hint.
func NewBuffer(cap int) *Buffer {
	return &Buffer{cap: cap, pending: make(map[int][]api.WireEntry)}
}

// Push adds one line to a flush bucket.
func (b *Buffer) Push(w api.WireEntry) {
	b.pending[w.FlushID] = append(b.pending[w.FlushID], w)
}

// Drain removes and returns one flush bucket.
func (b *Buffer) Drain(flushID int) []api.WireEntry {
	rows := b.pending[flushID]
	delete(b.pending, flushID)
	return rows
}

// PendingFlushIDs returns sorted flush ids with work remaining.
func (b *Buffer) PendingFlushIDs() []int {
	ids := make([]int, 0, len(b.pending))
	for k := range b.pending {
		ids = append(ids, k)
	}
	for i := 0; i < len(ids); i++ {
		for j := i + 1; j < len(ids); j++ {
			if ids[j] < ids[i] {
				ids[i], ids[j] = ids[j], ids[i]
			}
		}
	}
	return ids
}

// AtCap reports whether a flush bucket hit the configured ceiling.
func (b *Buffer) AtCap(flushID int) bool {
	return len(b.pending[flushID]) >= b.cap
}
