package config

import (
	"encoding/json"
	"os"

	"gopkg.in/yaml.v3"
)

// Defaults holds non-secret tunables from YAML.
type Defaults struct {
	MaxPending int `yaml:"max_pending"`
	LedgerBin string `yaml:"ledger_bin"`
}

// OffsetTable maps scenario names to committed watermarks.
type OffsetTable struct {
	Rows map[string]int `json:"rows"`
}

// LoadDefaults reads /app/config/defaults.yaml.
func LoadDefaults(path string) (*Defaults, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var d Defaults
	if err := yaml.Unmarshal(raw, &d); err != nil {
		return nil, err
	}
	if d.MaxPending == 0 {
		d.MaxPending = 512
	}
	if d.LedgerBin == "" {
		d.LedgerBin = "/app/ledgerd"
	}
	return &d, nil
}

// LoadOffsets reads committed offset snapshot JSON.
func LoadOffsets(path string) (*OffsetTable, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var t OffsetTable
	if err := json.Unmarshal(raw, &t); err != nil {
		return nil, err
	}
	return &t, nil
}
