package clock

// Sim advances a virtual tick counter used for logging only.
type Sim struct {
	n int
}

// Step increments ticks.
func (s *Sim) Step() {
	s.n++
}

// Ticks returns the current tick count.
func (s *Sim) Ticks() int {
	return s.n
}
