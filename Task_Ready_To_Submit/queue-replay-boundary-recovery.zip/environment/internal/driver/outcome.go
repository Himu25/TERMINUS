package driver

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"brokerd/internal/config"
	"brokerd/pkg/api"
)

// LoadScenario reads one JSON scenario.
func LoadScenario(path string) (*api.ScenarioFile, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var sc api.ScenarioFile
	if err := json.Unmarshal(raw, &sc); err != nil {
		return nil, err
	}
	return &sc, nil
}

// ListScenarios returns sorted JSON paths in a directory.
func ListScenarios(dir string) ([]string, error) {
	ents, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}
	var paths []string
	for _, e := range ents {
		if e.IsDir() {
			continue
		}
		if strings.HasSuffix(e.Name(), ".json") {
			paths = append(paths, filepath.Join(dir, e.Name()))
		}
	}
	sort.Strings(paths)
	return paths, nil
}

// RunAll executes every scenario and builds the recovery report.
func RunAll(cfg *config.Defaults, offsets *config.OffsetTable, dir string) (*api.RecoveryReport, error) {
	paths, err := ListScenarios(dir)
	if err != nil {
		return nil, err
	}
	runner := NewRunner(cfg, offsets)
	rep := &api.RecoveryReport{}
	for _, p := range paths {
		sc, err := LoadScenario(p)
		if err != nil {
			return nil, err
		}
		out, err := runner.Run(sc)
		if err != nil {
			return nil, err
		}
		rep.Scenarios = append(rep.Scenarios, *out)
	}
	return rep, nil
}

// WriteReport persists recovery_report.json.
func WriteReport(path string, rep *api.RecoveryReport) error {
	raw, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}
