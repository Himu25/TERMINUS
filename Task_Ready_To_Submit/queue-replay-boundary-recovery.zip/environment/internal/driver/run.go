package driver

import (
	"brokerd/internal/config"
	"brokerd/internal/cut"
	"brokerd/internal/ledger"
	"brokerd/internal/stream"
	"brokerd/pkg/api"
)

// Runner executes one scenario file through Go flush logic and Rust rollup.
type Runner struct {
	cfg     *config.Defaults
	offsets *config.OffsetTable
	buf     *stream.Buffer
}

// NewRunner wires subsystems.
func NewRunner(cfg *config.Defaults, offsets *config.OffsetTable) *Runner {
	return &Runner{
		cfg:     cfg,
		offsets: offsets,
		buf:     stream.NewBuffer(cfg.MaxPending),
	}
}

// Run processes sc and returns an outcome summary.
func (r *Runner) Run(sc *api.ScenarioFile) (*api.ScenarioOutcome, error) {
	cutSeq := cut.Pick(sc, r.offsets)
	out := &api.ScenarioOutcome{
		Name:         sc.Name,
		FinishReason: "complete",
		SafeCutSeq:   cutSeq,
	}

	var collected []api.WireEntry
	apply := func(w api.WireEntry) {
		collected = append(collected, w)
	}

	for _, w := range sc.Wire {
		r.buf.Push(w)
		if r.buf.AtCap(w.FlushID) {
			batch := r.buf.Drain(w.FlushID)
			stream.Fold(batch, apply)
		}
	}
	for _, fid := range r.buf.PendingFlushIDs() {
		batch := r.buf.Drain(fid)
		stream.Fold(batch, apply)
	}

	resp, err := ledger.ApplyBatch(r.cfg.LedgerBin, ledger.BatchRequest{
		Initial: sc.Initial,
		Entries: collected,
		CutSeq:  cutSeq,
	})
	if err != nil {
		out.FinishReason = "deadlock"
		return out, err
	}
	out.AppliedCount = resp.AppliedCount
	out.SkippedDup = resp.SkippedDup
	out.Accounts = resp.Accounts
	out.StateDigestHex = resp.StateDigestHex
	return out, nil
}
