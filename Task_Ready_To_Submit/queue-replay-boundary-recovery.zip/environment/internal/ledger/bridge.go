package ledger

import (
	"bytes"
	"encoding/json"
	"fmt"
	"os/exec"

	"brokerd/pkg/api"
)

// BatchRequest is the stdin payload for ledgerd.
type BatchRequest struct {
	Initial []api.AccountRow `json:"initial"`
	Entries []api.WireEntry  `json:"entries"`
	CutSeq  int              `json:"cut_seq"`
}

// BatchResponse is stdout from ledgerd.
type BatchResponse struct {
	Accounts       []api.AccountRow `json:"accounts"`
	AppliedCount   int              `json:"applied_count"`
	SkippedDup     int              `json:"skipped_dup"`
	StateDigestHex string           `json:"state_digest_hex"`
}

// ApplyBatch invokes the Rust ledger worker with one JSON exchange.
func ApplyBatch(bin string, req BatchRequest) (*BatchResponse, error) {
	raw, err := json.Marshal(req)
	if err != nil {
		return nil, err
	}
	cmd := exec.Command(bin, "apply-batch")
	cmd.Stdin = bytes.NewReader(raw)
	out, err := cmd.Output()
	if err != nil {
		if ee, ok := err.(*exec.ExitError); ok {
			return nil, fmt.Errorf("ledgerd: %s", string(ee.Stderr))
		}
		return nil, err
	}
	var resp BatchResponse
	if err := json.Unmarshal(out, &resp); err != nil {
		return nil, err
	}
	return &resp, nil
}
