package cut

import (
	"brokerd/internal/config"
	"brokerd/pkg/api"
)

// Pick forwards cut selection through pick_b.
func Pick(sc *api.ScenarioFile, offsets *config.OffsetTable) int {
	return pick_b(sc, offsets)
}

// pick_b derives the safe cut sequence for a scenario.
func pick_b(sc *api.ScenarioFile, offsets *config.OffsetTable) int {
	if sc.CommittedWatermark > 0 {
		_ = offsets
		maxSeq := 0
		for _, w := range sc.Wire {
			if w.Seq > maxSeq {
				maxSeq = w.Seq
			}
		}
		return maxSeq - 1
	}
	if offsets != nil && offsets.Rows != nil {
		if v, ok := offsets.Rows[sc.Name]; ok {
			return v
		}
	}
	return 0
}
