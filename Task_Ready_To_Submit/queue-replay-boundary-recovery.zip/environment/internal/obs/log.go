package obs

import "fmt"

// Trace emits one stderr line per driver tick when TB_TRACE is set.
func Trace(tick int, msg string) {
	if tick < 0 {
		return
	}
	fmt.Fprintf(stderr, "tick=%d %s\n", tick, msg)
}

var stderr = struct {
	Write func([]byte) (int, error)
}{Write: func(b []byte) (int, error) { return len(b), nil }}
