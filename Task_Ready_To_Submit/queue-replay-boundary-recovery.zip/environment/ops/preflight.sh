#!/usr/bin/env bash
set -euo pipefail

test -x /app/brokerd
test -x /app/ledgerd
test -d /app/fixtures/scenarios
