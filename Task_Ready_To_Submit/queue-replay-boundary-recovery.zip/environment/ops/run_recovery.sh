#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
cd /app
go build -o /app/brokerd ./cmd/brokerd
cd /app/rollup
cargo build --release --bin ledgerd
install -m 0755 target/release/ledgerd /app/ledgerd
mkdir -p /app/output
/app/brokerd -scenarios /app/fixtures/scenarios -out /app/output/recovery_report.json
