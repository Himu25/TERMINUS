package api

// WireEntry is one ingress line from the broker journal fixture.
type WireEntry struct {
	Stream  string `json:"stream"`
	Seq     int    `json:"seq"`
	Wire    int    `json:"wire"`
	Kind    string `json:"kind"`
	Target  string `json:"target"`
	Amount  int    `json:"amount"`
	FlushID int    `json:"flush_id"`
}

// AccountRow is one ledger row exported in the recovery report.
type AccountRow struct {
	ID      string `json:"id"`
	Balance int    `json:"balance"`
	Version int    `json:"version"`
}

// ScenarioFile drives one deterministic recovery run.
type ScenarioFile struct {
	Name                 string       `json:"name"`
	CommittedWatermark   int          `json:"committed_watermark"`
	Initial              []AccountRow `json:"initial"`
	Wire                 []WireEntry  `json:"wire"`
}

// ScenarioOutcome is one element of recovery_report.json.
type ScenarioOutcome struct {
	Name          string       `json:"name"`
	FinishReason  string       `json:"finish_reason"`
	SafeCutSeq    int          `json:"safe_cut_seq"`
	AppliedCount  int          `json:"applied_count"`
	SkippedDup    int          `json:"skipped_dup"`
	Accounts      []AccountRow `json:"accounts"`
	StateDigestHex string      `json:"state_digest_hex"`
}

// RecoveryReport is written to -out.
type RecoveryReport struct {
	Scenarios []ScenarioOutcome `json:"scenarios"`
}
