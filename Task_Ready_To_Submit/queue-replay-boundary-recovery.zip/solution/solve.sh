#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
cd /app

cat > internal/stream/slot.go <<'EOF'
package stream

import "brokerd/pkg/api"

func normalize_batch(batch []api.WireEntry) []api.WireEntry {
	if len(batch) == 0 {
		return batch
	}
	out := make([]api.WireEntry, len(batch))
	copy(out, batch)
	return out
}

// Fold forwards flush batches through fold_a.
func Fold(batch []api.WireEntry, apply func(api.WireEntry)) {
	fold_a(batch, apply)
}

// fold_a walks a flush batch and invokes apply for each element.
func fold_a(batch []api.WireEntry, apply func(api.WireEntry)) {
	rows := normalize_batch(batch)
	for _, row := range rows {
		apply(row)
	}
}
EOF

cat > internal/cut/point.go <<'EOF'
package cut

import (
	"brokerd/internal/config"
	"brokerd/pkg/api"
)

func committed_marker(sc *api.ScenarioFile) int {
	if sc.CommittedWatermark <= 0 {
		return 0
	}
	return sc.CommittedWatermark
}

func offset_fallback(offsets *config.OffsetTable, name string) int {
	if offsets == nil || offsets.Rows == nil {
		return 0
	}
	if v, ok := offsets.Rows[name]; ok {
		return v
	}
	return 0
}

// Pick forwards cut selection through pick_b.
func Pick(sc *api.ScenarioFile, offsets *config.OffsetTable) int {
	return pick_b(sc, offsets)
}

// pick_b derives the safe cut sequence for a scenario.
func pick_b(sc *api.ScenarioFile, offsets *config.OffsetTable) int {
	if offsets != nil && offsets.Rows != nil {
		if v, ok := offsets.Rows[sc.Name]; ok {
			return v
		}
	}
	if sc.CommittedWatermark > 0 {
		return committed_marker(sc)
	}
	return 0
}
EOF

cat > rollup/src/mark/seen.rs <<'EOF'
use std::collections::HashSet;

fn slot_key(lane: &str, ord: u64) -> String {
    format!("{lane}:{ord}")
}

/// mark_c records whether an arrival was already settled.
pub fn mark_c(seen: &mut HashSet<String>, lane: &str, ord: u64) -> bool {
    let key = slot_key(lane, ord);
    if seen.contains(&key) {
        return false;
    }
    seen.insert(key);
    true
}
EOF

cat > rollup/src/fold/blend.rs <<'EOF'
use crate::io::WireEntry;

fn seq_rank(a: &WireEntry, b: &WireEntry) -> std::cmp::Ordering {
    a.seq.cmp(&b.seq)
}

/// blend_d orders entries before balance rollup.
pub fn blend_d(entries: &[WireEntry]) -> Vec<WireEntry> {
    let mut out: Vec<WireEntry> = entries.to_vec();
    out.sort_by(seq_rank);
    out
}
EOF

bash /app/ops/run_recovery.sh
