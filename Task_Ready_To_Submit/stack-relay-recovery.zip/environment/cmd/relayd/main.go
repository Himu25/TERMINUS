package main

import (
	"log"
	"net/http"
	"path/filepath"

	"relay.lab/dock"
	"relay.lab/skiff"
)

func main() {
	cfgPath := filepath.Join("/app", "config", "relay.toml")
	envLink := filepath.Join("/app", "runtime", "active.env")
	cfg, err := skiff.LoadCfg(cfgPath)
	if err != nil {
		log.Fatalf("config: %v", err)
	}
	resolved, err := filepath.EvalSymlinks(envLink)
	if err != nil {
		log.Fatalf("runtime link: %v", err)
	}
	if err := skiff.OverlayEnv(&cfg, resolved); err != nil {
		log.Fatalf("profile overlay: %v", err)
	}
	srv := &dock.Server{Cfg: cfg, OutDir: filepath.Join("/app", "output")}
	mux := http.NewServeMux()
	mux.HandleFunc("/health", srv.Health)
	mux.HandleFunc("/ready", srv.Ready)
	log.Printf("relay listening on %s profile=%s", cfg.ListenAddr, cfg.ProfileLabel)
	if err := http.ListenAndServe(cfg.ListenAddr, mux); err != nil {
		log.Fatal(err)
	}
}
