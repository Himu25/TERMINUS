package types

type SlotRow struct {
	SlotID string `json:"slot_id"`
	State  string `json:"state"`
}
