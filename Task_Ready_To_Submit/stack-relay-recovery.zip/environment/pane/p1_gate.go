package pane

import (
	"os"
	"path/filepath"
)

func MarkReady(stateDir string) error {
	if err := os.MkdirAll(stateDir, 0o775); err != nil {
		return err
	}
	marker := filepath.Join(stateDir, ".ready")
	return os.WriteFile(marker, []byte("1\n"), 0o664)
}

func IsReady(stateDir string) bool {
	marker := filepath.Join(stateDir, ".ready")
	_, err := os.Stat(marker)
	return err == nil
}

func CanWrite(stateDir string) bool {
	probe := filepath.Join(stateDir, ".write_probe")
	if err := os.WriteFile(probe, []byte("ok\n"), 0o664); err != nil {
		return false
	}
	_ = os.Remove(probe)
	return true
}
