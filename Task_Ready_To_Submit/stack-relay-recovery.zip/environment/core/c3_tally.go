package core

import (
	"encoding/json"
	"os"

	"relay.lab/pkg/types"
)

func CountSlots(path string) (open int, closed int, err error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return 0, 0, err
	}
	var rows []types.SlotRow
	if err := json.Unmarshal(raw, &rows); err != nil {
		return 0, 0, err
	}
	for _, row := range rows {
		switch row.State {
		case "open":
			open++
		case "closed":
			closed++
		}
	}
	return open, closed, nil
}
