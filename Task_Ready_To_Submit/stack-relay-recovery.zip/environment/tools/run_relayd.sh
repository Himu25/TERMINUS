#!/bin/bash
set -euo pipefail
cd /app
exec /app/bin/relayd
