#!/bin/bash
set -euo pipefail
cd /app
if [[ ! -x /app/bin/relayd ]]; then
  go build -o /app/bin/relayd ./cmd/relayd
fi
nginx -t
if ! pgrep -x relayd >/dev/null 2>&1; then
  /app/tools/run_relayd.sh &
  sleep 1
fi
if ! pgrep -x nginx >/dev/null 2>&1; then
  nginx
fi
