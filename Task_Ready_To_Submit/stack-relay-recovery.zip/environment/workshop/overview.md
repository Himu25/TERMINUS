# Stack probe overview

The relay writes `/app/output/stack_probe.json` after a successful ready cycle.

## Fields

- profile_label — copied from the active runtime profile overlay
- edge_ok — true when the edge proxy can reach the relay health surface
- relay_ok — true when the loopback listener answered during the ready pass
- ready_ok — true when the state directory accepted the ready marker
- open_slots — inventory rows in open state
- closed_slots — inventory rows in closed state

## Bundled lab steady state

With `/app/data/inventory.json` and profile lab-edge:

| field | value |
|-------|------:|
| open_slots | 3 |
| closed_slots | 2 |
| edge_ok | true |
| relay_ok | true |
| ready_ok | true |

## Operator surfaces

- Build: go build -o /app/bin/relayd ./cmd/relayd
- Listener defaults live in `/app/config/relay.toml`; profile overlay via `/app/runtime/active.env`
- Edge site file: `/app/k9/w/site.conf` (symlinked under `/etc/nginx/sites-enabled/k9-edge.conf`)
- Bind metadata ledger: `/app/k9/r/runtime.bind`, `/app/k9/m/policy.map`, and `/app/k9/h/lane.headers`
- Unit template: `/app/k9/u/worker.service` (runs as deploy, EnvironmentFile=/app/runtime/active.env)
- Publish fragment: `/app/k9/p/sidecar.fragment.yml` (every host publish must avoid relay bind port 9090)
- State directory: `/app/var/relay` (owned by deploy, mode 775, .ready marker after successful ready)
- External verifier issues HTTP GET requests to http://127.0.0.1 on health and ready routes, and may probe loopback port 9090 directly
- The bundled unit template must not reference missing.env; use `/app/runtime/active.env` instead
- When healthy, X-Edge-Conflict-Listen in lane.headers must read disabled
