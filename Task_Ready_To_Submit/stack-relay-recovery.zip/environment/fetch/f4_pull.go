package fetch

import (
	"encoding/json"
	"os"

	"relay.lab/pkg/types"
)

// Bench-only prefetch; production relayd does not import this package.
func PrefetchRows(path string) ([]types.SlotRow, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var rows []types.SlotRow
	if err := json.Unmarshal(raw, &rows); err != nil {
		return nil, err
	}
	return rows, nil
}
