package skiff

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

type RelayCfg struct {
	ListenAddr    string
	InventoryPath string
	StateDir      string
	ProfileKey    string
	ProfileLabel  string
}

func LoadCfg(path string) (RelayCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return RelayCfg{}, err
	}
	cfg := RelayCfg{ProfileKey: "RELAY_PROFILE"}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.Trim(strings.TrimSpace(val), `"`)
		switch key {
		case "listen_addr":
			cfg.ListenAddr = val
		case "inventory_path":
			cfg.InventoryPath = val
		case "state_dir":
			cfg.StateDir = val
		case "profile_key":
			cfg.ProfileKey = val
		}
	}
	if cfg.ListenAddr == "" || cfg.InventoryPath == "" || cfg.StateDir == "" {
		return RelayCfg{}, fmt.Errorf("incomplete relay config")
	}
	return cfg, nil
}

func OverlayEnv(cfg *RelayCfg, envPath string) error {
	f, err := os.Open(envPath)
	if err != nil {
		return err
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.Trim(strings.TrimSpace(val), `"`)
		switch key {
		case "LISTEN_ADDR":
			if val != "" {
				cfg.ListenAddr = val
			}
		case "RELAY_PROFILE":
			cfg.ProfileLabel = val
		}
	}
	return sc.Err()
}
