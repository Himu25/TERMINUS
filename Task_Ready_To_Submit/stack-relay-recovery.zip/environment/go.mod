module relay.lab

go 1.22
