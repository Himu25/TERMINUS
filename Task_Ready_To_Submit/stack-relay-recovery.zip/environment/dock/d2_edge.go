package dock

import (
	"encoding/json"
	"net/http"
	"os"
	"path/filepath"

	"relay.lab/core"
	"relay.lab/pane"
	"relay.lab/skiff"
)

type Server struct {
	Cfg    skiff.RelayCfg
	OutDir string
}

func (s *Server) Health(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"status": "ok"})
}

func (s *Server) Ready(w http.ResponseWriter, r *http.Request) {
	if !pane.CanWrite(s.Cfg.StateDir) {
		http.Error(w, "state not writable", http.StatusServiceUnavailable)
		return
	}
	open, closed, err := core.CountSlots(s.Cfg.InventoryPath)
	if err != nil {
		http.Error(w, "inventory unreadable", http.StatusServiceUnavailable)
		return
	}
	if err := pane.MarkReady(s.Cfg.StateDir); err != nil {
		http.Error(w, "ready marker failed", http.StatusServiceUnavailable)
		return
	}
	if err := s.writeProbe(open, closed); err != nil {
		http.Error(w, "probe write failed", http.StatusServiceUnavailable)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{
		"ready":        true,
		"open_slots":   open,
		"closed_slots": closed,
	})
}

func (s *Server) writeProbe(open, closed int) error {
	if err := os.MkdirAll(s.OutDir, 0o775); err != nil {
		return err
	}
	body := map[string]any{
		"profile_label": s.Cfg.ProfileLabel,
		"edge_ok":       true,
		"relay_ok":      true,
		"ready_ok":      true,
		"open_slots":    open,
		"closed_slots":  closed,
	}
	raw, err := json.Marshal(body)
	if err != nil {
		return err
	}
	target := filepath.Join(s.OutDir, "stack_probe.json")
	return os.WriteFile(target, append(raw, '\n'), 0o664)
}
