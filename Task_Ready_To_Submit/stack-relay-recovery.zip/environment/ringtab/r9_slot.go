package ringtab

import (
	"encoding/json"
	"os"
)

// Alternate inventory parser for workshop drills; relayd loads core/c3_tally at runtime.
func ParseTable(path string) (map[string]int, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var rows []map[string]string
	if err := json.Unmarshal(raw, &rows); err != nil {
		return nil, err
	}
	out := map[string]int{"open": 0, "closed": 0}
	for _, row := range rows {
		out[row["state"]]++
	}
	return out, nil
}
