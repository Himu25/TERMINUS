# Architecture fragment

The relay process binds on loopback using `relay.toml` plus the profile file referenced by `/app/runtime/active.env`. The edge proxy terminates HTTP on port 80 and forwards `/health` and `/ready` to that upstream. Inventory rows live in JSON at `/app/data/inventory.json`. The deploy account (see `/etc/passwd`) must be able to create markers under `/app/var/relay`.
