# Runbook fragment

When the edge returns bad gateway, compare the edge upstream port, profile `LISTEN_ADDR`, and the publish host map. Permission errors on ready usually mean `/app/var/relay` is not writable by the service account named in the unit file.
