#!/usr/bin/env python3
"""Probe contract audit after ready cycle."""

from __future__ import annotations

import json
from pathlib import Path


def main() -> None:
    probe_path = Path("/app/output/stack_probe.json")
    probe = json.loads(probe_path.read_text(encoding="utf-8"))
    required = {
        "profile_label",
        "edge_ok",
        "relay_ok",
        "ready_ok",
        "open_slots",
        "closed_slots",
    }
    missing = required - set(probe)
    if missing:
        raise SystemExit(f"probe missing keys: {missing}")
    if probe["profile_label"] != "lab-edge":
        raise SystemExit(f"unexpected profile: {probe['profile_label']}")
    if probe["open_slots"] != 3 or probe["closed_slots"] != 2:
        raise SystemExit(f"unexpected lab counts: {probe}")
    for flag in ("edge_ok", "relay_ok", "ready_ok"):
        if probe[flag] is not True:
            raise SystemExit(f"{flag} not true: {probe}")

    rows = json.loads(Path("/app/data/inventory.json").read_text(encoding="utf-8"))
    open_count = sum(1 for row in rows if row["state"] == "open")
    closed_count = sum(1 for row in rows if row["state"] == "closed")
    if probe["open_slots"] != open_count or probe["closed_slots"] != closed_count:
        raise SystemExit("probe counts disagree with inventory.json")


if __name__ == "__main__":
    main()
