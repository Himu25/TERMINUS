#!/usr/bin/env python3
"""Cross-surface consistency audit used by the oracle."""

from __future__ import annotations

import re
from pathlib import Path


def _parse_kv(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = line.split("=", 1)
        out[key.strip()] = val.strip()
    return out


def _parse_headers(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = line.split(":", 1)
        out[key.strip()] = val.strip()
    return out


def _profile_port(active_link: Path) -> int:
    resolved = active_link.resolve()
    for line in resolved.read_text(encoding="utf-8").splitlines():
        if line.strip().startswith("LISTEN_ADDR="):
            addr = line.split("=", 1)[1].strip().strip('"')
            return int(addr.rsplit(":", 1)[1])
    raise SystemExit("LISTEN_ADDR missing from active profile")


def main() -> None:
    app = Path("/app")
    bind = _parse_kv(app / "k9" / "r" / "runtime.bind")
    policy = _parse_kv(app / "k9" / "m" / "policy.map")
    hdr = _parse_headers(app / "k9" / "h" / "lane.headers")
    site = (app / "k9" / "w" / "site.conf").read_text(encoding="utf-8")
    unit = (app / "k9" / "u" / "worker.service").read_text(encoding="utf-8")
    frag = (app / "k9" / "p" / "sidecar.fragment.yml").read_text(encoding="utf-8")
    active = app / "runtime" / "active.env"
    listen = _profile_port(active)

    upstream_ports = [int(m.group(1)) for m in re.finditer(r"server\s+127\.0\.0\.1:(\d+)", site)]
    publish_ports = [int(m.group(1)) for m in re.finditer(r'-\s*"(\d+):\d+"', frag)]

    checks = [
        ("primary_upstream_port", bind["primary_upstream_port"], str(listen)),
        ("shadow_upstream_port", bind["shadow_upstream_port"], str(listen)),
        ("profile_listen_port", bind["profile_listen_port"], str(listen)),
        ("lane_upstream_token", bind["lane_upstream_token"], str(listen)),
        ("lane_shadow_token", bind["lane_shadow_token"], str(listen)),
        ("hdr_upstream", hdr["X-Edge-Upstream-Port"], str(listen)),
        ("hdr_shadow", hdr["X-Edge-Shadow-Port"], str(listen)),
        ("unit_account", bind["unit_account"], "deploy"),
        ("unit_env", bind["unit_env_file"], "/app/runtime/active.env"),
        ("conflict_listen", bind["conflict_listen"], "disabled"),
        ("lane_conflict", hdr["X-Edge-Conflict-Listen"], "disabled"),
        ("lane_conflict_token", bind["lane_conflict_token"], "disabled"),
        ("active_profile_link", bind["active_profile_link"], "lab.env"),
        ("state_owner", bind["state_dir_owner"], "deploy"),
        ("state_mode", bind["state_dir_mode"], "775"),
    ]
    for label, got, want in checks:
        if got != want:
            raise SystemExit(f"{label}: expected {want!r}, got {got!r}")

    if not upstream_ports or any(port != listen for port in upstream_ports):
        raise SystemExit(f"nginx upstream ports {upstream_ports} != listen {listen}")
    if any(port == listen for port in publish_ports):
        raise SystemExit(f"publish ports collide with relay bind: {publish_ports}")
    if re.search(r"listen\s+9090", site):
        raise SystemExit("edge site still declares relay bind listener")
    if "User=deploy" not in unit or "missing.env" in unit:
        raise SystemExit("unit template still references broken account or env file")
    if str(active.readlink()).endswith("stale.env"):
        raise SystemExit("active profile link still targets stale pack")

    if policy["upstream_primary"] != str(listen):
        raise SystemExit("policy map upstream still mismatched")
    if policy["unit_user"] != "deploy":
        raise SystemExit("policy map unit user still mismatched")
    if policy["conflict_bind"] != "disabled":
        raise SystemExit("policy map conflict bind still mismatched")

    enabled = Path("/etc/nginx/sites-enabled/k9-edge.conf")
    if not enabled.exists():
        raise SystemExit("enabled edge symlink missing")
    if enabled.resolve() != (app / "k9" / "w" / "site.conf").resolve():
        raise SystemExit("enabled edge symlink points at wrong site file")


if __name__ == "__main__":
    main()
