#!/bin/bash
# Terminal-Bench Canary: stack-relay-recovery oracle
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

echo "Installing corrected k9 surfaces"
install -m 0644 "${ROOT_DIR}/oracle/k9/w/site.conf" /app/k9/w/site.conf
install -m 0644 "${ROOT_DIR}/oracle/k9/u/worker.service" /app/k9/u/worker.service
install -m 0644 "${ROOT_DIR}/oracle/k9/p/sidecar.fragment.yml" /app/k9/p/sidecar.fragment.yml
install -m 0644 "${ROOT_DIR}/oracle/k9/h/lane.headers" /app/k9/h/lane.headers
install -m 0644 "${ROOT_DIR}/oracle/k9/r/runtime.bind" /app/k9/r/runtime.bind
install -m 0644 "${ROOT_DIR}/oracle/k9/m/policy.map" /app/k9/m/policy.map

echo "Pointing runtime profile link at lab pack"
ln -sfn /app/runtime/profiles/lab.env /app/runtime/active.env

echo "Repairing state directory ownership for deploy account"
chown deploy:deploy /app/var/relay
chmod 775 /app/var/relay

echo "Refreshing enabled edge site symlink"
ln -sfn /app/k9/w/site.conf /etc/nginx/sites-enabled/k9-edge.conf

echo "Building relay binary"
go build -o /app/bin/relayd ./cmd/relayd

echo "Validating edge configuration"
nginx -t

python3 "${ROOT_DIR}/verify_surfaces.py"

echo "Stopping stale listeners"
pkill -x relayd 2>/dev/null || true
pkill -x nginx 2>/dev/null || true
sleep 1

echo "Starting relay and edge proxy"
/app/tools/run_relayd.sh &
sleep 1
nginx

echo "Driving health and ready surfaces"
curl -sf http://127.0.0.1/health >/dev/null
curl -sf http://127.0.0.1/ready >/dev/null

python3 "${ROOT_DIR}/verify_probe.py"

echo "Oracle complete"
