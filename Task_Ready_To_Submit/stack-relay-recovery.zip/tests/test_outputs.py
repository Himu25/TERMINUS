"""Verifier for stack-relay-recovery."""

from __future__ import annotations

import json
import os
import re
import subprocess
import time
from pathlib import Path
from typing import Any, NamedTuple

import pytest

APP = Path("/app")
PROBE = APP / "output" / "stack_probe.json"
INVENTORY = APP / "data" / "inventory.json"
EDGE_SITE = APP / "k9" / "w" / "site.conf"
LANE_HEADERS = APP / "k9" / "h" / "lane.headers"
RUNTIME_BIND = APP / "k9" / "r" / "runtime.bind"
POLICY_MAP = APP / "k9" / "m" / "policy.map"
UNIT_FILE = APP / "k9" / "u" / "worker.service"
PUBLISH_FRAGMENT = APP / "k9" / "p" / "sidecar.fragment.yml"
ACTIVE_LINK = APP / "runtime" / "active.env"
STATE_DIR = APP / "var" / "relay"
NGINX_ENABLED = Path("/etc/nginx/sites-enabled/k9-edge.conf")
FIXTURES = Path(__file__).resolve().parent / "fixtures"
BASE = "http://127.0.0.1"
RELAY_PORT = 9090

PROBE_KEYS = {
    "profile_label",
    "edge_ok",
    "relay_ok",
    "ready_ok",
    "open_slots",
    "closed_slots",
}

LAB_INVENTORY = INVENTORY.read_text(encoding="utf-8")


class ScenarioPack(NamedTuple):
    profile_label: str
    open_slots: int
    closed_slots: int
    profile_env: str
    inventory: str


class ProcHolder:
    relay: subprocess.Popen[bytes] | None = None


HOLDER = ProcHolder()
_RELAY_BUILT = False


def _hard_scenarios() -> set[str]:
    path = APP / "workshop" / "hard_fixtures.txt"
    return {line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()}


def _deploy_uid() -> int:
    for line in Path("/etc/passwd").read_text(encoding="utf-8").splitlines():
        if line.startswith("deploy:"):
            return int(line.split(":", 3)[2])
    raise AssertionError("deploy account missing")


def _discover_scenarios() -> list[str]:
    return sorted(p.name for p in FIXTURES.iterdir() if p.is_dir())


def _load_pack(name: str) -> ScenarioPack:
    root = FIXTURES / name
    steady = json.loads((root / "steady.json").read_text(encoding="utf-8"))
    return ScenarioPack(
        profile_label=str(steady["profile_label"]),
        open_slots=int(steady["open_slots"]),
        closed_slots=int(steady["closed_slots"]),
        profile_env=(root / "profile.env").read_text(encoding="utf-8"),
        inventory=(root / "inventory.json").read_text(encoding="utf-8"),
    )


def _atomic_write(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _parse_bind_file(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = line.split("=", 1)
        out[key.strip()] = val.strip()
    return out


def _healthy_unit_account() -> str:
    ledger = (APP / "workshop" / "bind_ledger.txt").read_text(encoding="utf-8")
    for line in ledger.splitlines():
        if line.startswith("Healthy unit account:"):
            return line.split(":", 1)[1].strip()
    return "deploy"


def _parse_unit_service(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("["):
            continue
        if "=" not in line:
            continue
        key, val = line.split("=", 1)
        out[key.strip()] = val.strip()
    return out


def _parse_kv_file(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = line.split(":", 1)
        out[key.strip()] = val.strip()
    return out


def _nginx_upstream_ports() -> list[int]:
    text = EDGE_SITE.read_text(encoding="utf-8")
    return [int(m.group(1)) for m in re.finditer(r"server\s+127\.0\.0\.1:(\d+)", text)]


def _compose_host_ports() -> list[int]:
    text = PUBLISH_FRAGMENT.read_text(encoding="utf-8")
    ports = [int(m.group(1)) for m in re.finditer(r'-\s*"(\d+):\d+"', text)]
    assert ports, "publish host ports not found"
    return ports


def _inventory_counts(path: Path = INVENTORY) -> tuple[int, int]:
    rows = json.loads(path.read_text(encoding="utf-8"))
    open_slots = sum(1 for row in rows if row["state"] == "open")
    closed_slots = sum(1 for row in rows if row["state"] == "closed")
    return open_slots, closed_slots


def _profile_listen_port() -> int:
    resolved = ACTIVE_LINK.resolve()
    text = resolved.read_text(encoding="utf-8")
    for line in text.splitlines():
        if line.strip().startswith("LISTEN_ADDR="):
            addr = line.split("=", 1)[1].strip().strip('"')
            return int(addr.rsplit(":", 1)[1])
    raise AssertionError("LISTEN_ADDR missing from active profile")


def _profile_label_from_env() -> str:
    resolved = ACTIVE_LINK.resolve()
    for line in resolved.read_text(encoding="utf-8").splitlines():
        if line.strip().startswith("RELAY_PROFILE="):
            return line.split("=", 1)[1].strip().strip('"')
    raise AssertionError("RELAY_PROFILE missing from active profile")


def _unit_listen_hint_port() -> int:
    text = UNIT_FILE.read_text(encoding="utf-8")
    match = re.search(r"RELAY_LISTEN_HINT=127\.0\.0\.1:(\d+)", text)
    assert match, "RELAY_LISTEN_HINT missing from unit template"
    return int(match.group(1))


def _curl_status(url: str) -> int:
    proc = subprocess.run(
        ["curl", "-sS", "-o", "/dev/null", "-w", "%{http_code}", url],
        check=False,
        capture_output=True,
        text=True,
    )
    return int(proc.stdout.strip() or "0")


def _curl_json(url: str) -> tuple[int, dict[str, Any]]:
    proc = subprocess.run(
        ["curl", "-sS", "-w", "\n%{http_code}", url],
        check=False,
        capture_output=True,
        text=True,
    )
    raw = proc.stdout
    body_text, _, status_text = raw.rpartition("\n")
    status = int(status_text.strip() or "0")
    if body_text.strip():
        body = json.loads(body_text)
    else:
        body = {}
    return status, body


def _ensure_relay_built() -> None:
    """Build relayd once per verifier session; runtime tests still exercise a fresh binary."""
    global _RELAY_BUILT
    binary = APP / "bin" / "relayd"
    if _RELAY_BUILT and binary.is_file():
        return
    subprocess.run(
        ["go", "build", "-o", "/app/bin/relayd", "./cmd/relayd"],
        cwd=APP,
        check=True,
    )
    _RELAY_BUILT = True


def _stop_stack() -> None:
    if HOLDER.relay and HOLDER.relay.poll() is None:
        HOLDER.relay.terminate()
        try:
            HOLDER.relay.wait(timeout=3)
        except subprocess.TimeoutExpired:
            HOLDER.relay.kill()
    HOLDER.relay = None
    subprocess.run(["pkill", "-x", "nginx"], check=False)
    subprocess.run(["pkill", "-x", "relayd"], check=False)
    time.sleep(0.3)


def _start_stack() -> None:
    _stop_stack()
    if PROBE.exists():
        PROBE.unlink()
    ready_marker = STATE_DIR / ".ready"
    if ready_marker.exists():
        ready_marker.unlink()
    _ensure_relay_built()
    subprocess.run(["nginx", "-t"], check=True)
    HOLDER.relay = subprocess.Popen(
        ["/app/bin/relayd"],
        cwd=APP,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    time.sleep(0.5)
    subprocess.run(["nginx"], check=True)
    time.sleep(0.3)


def _drive_ready() -> tuple[dict[str, Any], dict[str, Any]]:
    status, body = _curl_json(f"{BASE}/ready")
    assert status == 200, f"ready returned {status}: {body}"
    assert PROBE.is_file(), "stack_probe.json was not written"
    probe = json.loads(PROBE.read_text(encoding="utf-8"))
    assert PROBE_KEYS <= set(probe), f"missing probe keys: {PROBE_KEYS - set(probe)}"
    return probe, body


def _restore_lab_bundle() -> None:
    _atomic_write(INVENTORY, LAB_INVENTORY)
    if ACTIVE_LINK.is_symlink() or ACTIVE_LINK.exists():
        ACTIVE_LINK.unlink()
    os.symlink(APP / "runtime" / "profiles" / "lab.env", ACTIVE_LINK)


def _apply_pack(pack: ScenarioPack) -> None:
    profile_path = APP / "runtime" / "profiles" / f"{pack.profile_label}.env"
    _atomic_write(INVENTORY, pack.inventory)
    _atomic_write(profile_path, pack.profile_env)
    if ACTIVE_LINK.is_symlink() or ACTIVE_LINK.exists():
        ACTIVE_LINK.unlink()
    os.symlink(profile_path, ACTIVE_LINK)


@pytest.fixture(scope="session", autouse=True)
def _shutdown_stack() -> None:
    yield
    _stop_stack()


# --- static surface checks (fail on broken baseline without a running stack) ---


def test_edge_config_syntax() -> None:
    """Edge site must parse."""
    subprocess.run(["nginx", "-t"], check=True)


def test_unit_template_references_active_env() -> None:
    """Unit must run as deploy and load the live runtime link."""
    unit = _parse_unit_service(UNIT_FILE)
    account = _healthy_unit_account()
    assert unit.get("User") == account
    assert unit.get("Group") == account
    env_file = unit.get("EnvironmentFile", "")
    assert env_file.lstrip("-") == "/app/runtime/active.env"
    assert "missing.env" not in env_file


def test_runtime_symlink_target() -> None:
    """Active profile link must not point at the stale pack."""
    _restore_lab_bundle()
    target = os.readlink(ACTIVE_LINK)
    assert "stale.env" not in target
    assert target.endswith("lab.env") or ACTIVE_LINK.resolve().name == "lab.env"


def test_var_directory_deploy_writable() -> None:
    """State directory must be owned by deploy and writable."""
    st = STATE_DIR.stat()
    assert st.st_uid == _deploy_uid()
    assert oct(st.st_mode & 0o777) in {"0o775", "0o777"}
    probe = STATE_DIR / ".write_probe"
    probe.write_text("ok\n", encoding="utf-8")
    probe.unlink()


def test_publish_host_port_not_colliding() -> None:
    """Publish host ports must not bind host 9090 while relay uses 9090."""
    for host_port in _compose_host_ports():
        assert host_port != RELAY_PORT


def test_compose_all_publish_ports_clear_relay_bind() -> None:
    """Every publish mapping must avoid the relay loopback bind port on the host side."""
    assert len(_compose_host_ports()) >= 2
    assert all(port != RELAY_PORT for port in _compose_host_ports())


def test_relay_listen_port_matches_upstream() -> None:
    """Profile listen port must match every edge upstream block."""
    _restore_lab_bundle()
    listen = _profile_listen_port()
    upstreams = _nginx_upstream_ports()
    assert upstreams, "no upstream blocks found"
    assert all(port == listen for port in upstreams)


def test_all_nginx_upstream_ports_match_profile() -> None:
    """Primary and shadow upstream blocks must share the profile listen port."""
    _restore_lab_bundle()
    ports = _nginx_upstream_ports()
    assert len(ports) >= 2
    assert len(set(ports)) == 1
    assert ports[0] == _profile_listen_port()


def test_lane_header_upstream_ports_aligned() -> None:
    """Lane header ledger ports must match the profile listen port."""
    _restore_lab_bundle()
    listen = _profile_listen_port()
    hdr = _parse_kv_file(LANE_HEADERS)
    assert hdr["X-Edge-Upstream-Port"] == str(listen)
    assert hdr["X-Edge-Shadow-Port"] == str(listen)


def test_lane_header_conflict_listen_disabled() -> None:
    """Conflict listen token must be disabled once surfaces agree."""
    hdr = _parse_kv_file(LANE_HEADERS)
    assert hdr["X-Edge-Conflict-Listen"] == "disabled"


def test_runtime_bind_metadata_aligned() -> None:
    """Bind metadata ledger must agree with profile, unit, and lane headers."""
    _restore_lab_bundle()
    listen = _profile_listen_port()
    bind = _parse_bind_file(RUNTIME_BIND)
    hdr = _parse_kv_file(LANE_HEADERS)
    assert bind["primary_upstream_port"] == str(listen)
    assert bind["shadow_upstream_port"] == str(listen)
    assert bind["profile_listen_port"] == str(listen)
    assert bind["lane_upstream_token"] == str(listen)
    assert bind["lane_shadow_token"] == str(listen)
    assert hdr["X-Edge-Upstream-Port"] == str(listen)
    assert bind["unit_account"] == "deploy"
    assert bind["unit_env_file"] == "/app/runtime/active.env"
    assert bind["conflict_listen"] == "disabled"
    assert bind["lane_conflict_token"] == "disabled"
    assert bind["active_profile_link"] == "lab.env"
    assert bind["state_dir_owner"] == "deploy"
    assert bind["state_dir_mode"] == "775"


def test_policy_map_metadata_aligned() -> None:
    """Policy map must agree with profile listen port, unit, and publish rules."""
    _restore_lab_bundle()
    listen = _profile_listen_port()
    policy = _parse_bind_file(POLICY_MAP)
    assert policy["upstream_primary"] == str(listen)
    assert policy["upstream_shadow"] == str(listen)
    assert policy["lane_upstream"] == str(listen)
    assert policy["lane_shadow"] == str(listen)
    assert policy["unit_user"] == "deploy"
    assert policy["unit_env"] == "/app/runtime/active.env"
    assert policy["profile_overlay"] == "lab.env"
    assert policy["state_owner"] == "deploy"
    assert policy["state_mode"] == "775"
    assert policy["conflict_bind"] == "disabled"
    assert policy["lane_conflict"] == "disabled"
    assert int(policy["publish_primary_host"]) != RELAY_PORT
    assert int(policy["publish_secondary_host"]) != RELAY_PORT
    assert policy["publish_primary_host"] != policy["publish_secondary_host"]


def test_edge_site_no_relay_port_listener() -> None:
    """Edge site must not declare a host listener on the relay bind port."""
    text = EDGE_SITE.read_text(encoding="utf-8")
    assert not re.search(r"listen\s+9090", text)


def test_unit_listen_hint_matches_profile() -> None:
    """Unit listen hint must mirror the active profile port."""
    _restore_lab_bundle()
    assert _unit_listen_hint_port() == _profile_listen_port()


def test_nginx_enabled_symlink_targets_site_conf() -> None:
    """Enabled edge site must resolve to the k9 site file."""
    assert NGINX_ENABLED.is_symlink() or NGINX_ENABLED.exists()
    target = NGINX_ENABLED.resolve()
    assert target == EDGE_SITE.resolve()


# --- runtime integration checks ---


def test_edge_health_via_proxy() -> None:
    """Edge /health must succeed through port 80."""
    _restore_lab_bundle()
    _start_stack()
    status, body = _curl_json(f"{BASE}/health")
    assert status == 200
    assert body.get("status") == "ok"


def test_health_is_idempotent() -> None:
    """Repeated /health calls must stay healthy."""
    _restore_lab_bundle()
    _start_stack()
    for _ in range(3):
        status, body = _curl_json(f"{BASE}/health")
        assert status == 200
        assert body.get("status") == "ok"


def test_loopback_health_direct() -> None:
    """Loopback listener must answer /health without the edge proxy."""
    _restore_lab_bundle()
    _start_stack()
    port = _profile_listen_port()
    status, body = _curl_json(f"http://127.0.0.1:{port}/health")
    assert status == 200
    assert body.get("status") == "ok"


def test_ready_endpoint() -> None:
    """Edge /ready must succeed and return slot counts."""
    _restore_lab_bundle()
    _start_stack()
    status, body = _curl_json(f"{BASE}/ready")
    assert status == 200
    assert body.get("ready") is True
    open_slots = body.get("open_slots")
    closed_slots = body.get("closed_slots")
    assert isinstance(open_slots, int)
    assert isinstance(closed_slots, int)
    expected_open, expected_closed = _inventory_counts()
    assert open_slots == expected_open
    assert closed_slots == expected_closed


def test_ready_creates_state_marker() -> None:
    """Successful ready must leave a marker in the state directory."""
    _restore_lab_bundle()
    _start_stack()
    marker = STATE_DIR / ".ready"
    if marker.exists():
        marker.unlink()
    _drive_ready()
    assert marker.is_file()


def test_stack_probe_schema() -> None:
    """Probe must include required booleans and inventory-aligned counts."""
    _restore_lab_bundle()
    _start_stack()
    expected_open, expected_closed = _inventory_counts()
    probe, _ = _drive_ready()
    assert set(probe.keys()) == PROBE_KEYS
    assert isinstance(probe["profile_label"], str)
    assert isinstance(probe["edge_ok"], bool)
    assert isinstance(probe["relay_ok"], bool)
    assert isinstance(probe["ready_ok"], bool)
    assert isinstance(probe["open_slots"], int)
    assert isinstance(probe["closed_slots"], int)
    assert probe["open_slots"] == expected_open
    assert probe["closed_slots"] == expected_closed
    assert probe["edge_ok"] is True
    assert probe["relay_ok"] is True
    assert probe["ready_ok"] is True


def test_ready_body_matches_probe_counts() -> None:
    """Ready JSON and stack_probe.json must agree on slot counts and profile."""
    _restore_lab_bundle()
    _start_stack()
    probe, body = _drive_ready()
    assert body["open_slots"] == probe["open_slots"]
    assert body["closed_slots"] == probe["closed_slots"]
    assert probe["profile_label"] == _profile_label_from_env()


def test_probe_slot_counts_lab() -> None:
    """Bundled inventory must yield workshop steady counts."""
    _restore_lab_bundle()
    _start_stack()
    expected_open, expected_closed = _inventory_counts()
    probe, _ = _drive_ready()
    assert probe["profile_label"] == "lab-edge"
    assert probe["open_slots"] == expected_open
    assert probe["closed_slots"] == expected_closed
    assert expected_open == 3
    assert expected_closed == 2


def test_metrics_route_blocked_at_edge() -> None:
    """Edge must not proxy metrics; route stays absent/blocked."""
    _restore_lab_bundle()
    _start_stack()
    assert _curl_status(f"{BASE}/metrics") == 404


def test_relay_binary_built() -> None:
    """Relay binary must exist after build for operator tooling."""
    _restore_lab_bundle()
    _start_stack()
    binary = APP / "bin" / "relayd"
    assert binary.is_file()
    assert os.access(binary, os.X_OK)


# --- fixture packs ---


@pytest.mark.parametrize("scenario", _discover_scenarios())
def test_scenario_substitution(scenario: str) -> None:
    """Fixture packs must pass the same health and probe contract."""
    pack = _load_pack(scenario)
    _apply_pack(pack)
    _start_stack()
    expected_open, expected_closed = _inventory_counts()
    status, _ = _curl_json(f"{BASE}/health")
    assert status == 200
    probe, body = _drive_ready()
    assert probe["profile_label"] == pack.profile_label == _profile_label_from_env()
    assert probe["open_slots"] == body["open_slots"] == expected_open == pack.open_slots
    assert probe["closed_slots"] == body["closed_slots"] == expected_closed == pack.closed_slots
    assert probe["open_slots"] + probe["closed_slots"] > 0


@pytest.mark.parametrize("scenario", sorted(_hard_scenarios()))
def test_hard_scenarios(scenario: str) -> None:
    """High-coupling packs stress profile, lane headers, and inventory alignment."""
    pack = _load_pack(scenario)
    _apply_pack(pack)
    listen = _profile_listen_port()
    hdr = _parse_kv_file(LANE_HEADERS)
    assert hdr["X-Edge-Upstream-Port"] == str(listen)
    assert all(port == listen for port in _nginx_upstream_ports())
    _start_stack()
    status, _ = _curl_json(f"{BASE}/health")
    assert status == 200
    expected_open, expected_closed = _inventory_counts()
    probe, body = _drive_ready()
    assert probe["open_slots"] == expected_open == pack.open_slots == body["open_slots"]
    assert probe["closed_slots"] == expected_closed == pack.closed_slots == body["closed_slots"]
    assert probe["profile_label"] == pack.profile_label
