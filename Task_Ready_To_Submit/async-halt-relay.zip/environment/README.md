# worker replay lab

Rust sources under `/app/crates` implement the poll loop and stop mesh primitives.
Rebuild with `/app/scripts/build.sh` and drive scenarios through `/app/bin/halt_lab`.
