use std::sync::Arc;

use op_a::OpA;
use op_b::OpB;
use op_d::OpD;

pub struct OpC {
    cell: Arc<OpA>,
}

impl OpC {
    pub fn mk() -> Self {
        Self { cell: OpA::mk() }
    }

    pub fn flag_open(&self) -> bool {
        self.cell.flag_open()
    }

    pub fn flip(&self) {
        self.cell.flip();
    }

    pub fn split_d(&self) -> OpD {
        OpD::attach(self.share_cell())
    }

    pub(crate) fn share_cell(&self) -> Arc<OpA> {
        Arc::clone(&self.cell)
    }

    pub fn bind_b(&self) -> OpB {
        OpB::attach(Arc::clone(&self.cell))
    }
}
