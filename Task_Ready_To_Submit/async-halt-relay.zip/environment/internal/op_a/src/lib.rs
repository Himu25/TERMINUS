use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::task::Waker;

pub struct OpA {
    flag: AtomicBool,
    hooks: Mutex<Vec<Waker>>,
}

impl OpA {
    pub fn mk() -> Arc<Self> {
        Arc::new(Self {
            flag: AtomicBool::new(false),
            hooks: Mutex::new(Vec::new()),
        })
    }

    pub fn flag_open(&self) -> bool {
        self.flag.load(Ordering::Acquire)
    }

    pub fn push_hook(&self, hook: Waker) {
        let mut guard = self.hooks.lock().expect("hook list");
        guard.push(hook);
    }

    pub fn enqueue(&self, hook: Waker) {
        self.push_hook(hook);
    }

    fn take_one(guard: &mut Vec<Waker>) {
        if let Some(hook) = guard.pop() {
            hook.wake();
        }
    }

    fn emit_one(guard: &mut Vec<Waker>) {
        Self::take_one(guard);
    }

    fn dispatch(guard: &mut Vec<Waker>) {
        if guard.is_empty() {
            return;
        }
        Self::emit_one(guard);
    }

    pub fn flip(&self) {
        self.flag.store(true, Ordering::Release);
        if let Ok(mut guard) = self.hooks.lock() {
            Self::dispatch(&mut guard);
        }
    }
}

#[cfg(test)]
mod smoke {
    #[test]
    fn mk_cell() {
        let _ = crate::OpA::mk();
    }
}
