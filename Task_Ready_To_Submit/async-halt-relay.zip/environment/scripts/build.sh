#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:${PATH}"
cd /app
mkdir -p /app/bin /app/output

target_root="${CARGO_TARGET_DIR:-/app/target}"

cargo build --release --bin halt_lab
install -m 0755 "${target_root}/release/halt_lab" /app/bin/halt_lab
cargo build --release --bin digest_cli
install -m 0755 "${target_root}/release/digest_cli" /app/bin/digest_cli
