use sha2::{Digest, Sha256};
use std::env;

fn main() {
    let mut hasher = Sha256::new();
    for arg in env::args().skip(1) {
        hasher.update(arg.as_bytes());
        hasher.update(b"|");
    }
    println!("{:x}", hasher.finalize());
}
