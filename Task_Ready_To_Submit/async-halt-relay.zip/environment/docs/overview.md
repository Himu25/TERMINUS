The async worker lab couples a single-threaded poll loop with a shared stop mesh used to park many cooperative workers during long replay stems.

Forked sub-handles participate in the same trip state as their parent in the regression bundle. Regression stems live under `/app/data/regression` and are listed in `/app/docs/scenario_index.txt`.
