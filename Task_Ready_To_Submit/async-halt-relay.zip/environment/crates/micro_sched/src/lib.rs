use std::future::Future;
use std::pin::Pin;
use std::task::{Context, Poll, RawWaker, RawWakerVTable, Waker};

pub struct Loop {
    queue: Vec<Pin<Box<dyn Future<Output = ()>>>>,
}

impl Loop {
    pub fn new() -> Self {
        Self { queue: Vec::new() }
    }

    pub fn spawn<F>(&mut self, fut: F)
    where
        F: Future<Output = ()> + 'static,
    {
        self.queue.push(Box::pin(fut));
    }

    pub fn run_until_idle(&mut self) {
        let mut pass = 0usize;
        while pass < 1_000_000 {
            pass += 1;
            if self.queue.is_empty() {
                break;
            }
            let mut pending = Vec::new();
            while let Some(mut task) = self.queue.pop() {
                let waker = dummy_waker();
                let mut cx = Context::from_waker(&waker);
                match task.as_mut().poll(&mut cx) {
                    Poll::Ready(()) => {}
                    Poll::Pending => pending.push(task),
                }
            }
            if pending.is_empty() {
                break;
            }
            self.queue = pending;
        }
    }

    pub fn block_on<F, T>(&mut self, fut: F) -> T
    where
        F: Future<Output = T>,
    {
        let mut pinned = Box::pin(fut);
        loop {
            let waker = dummy_waker();
            let mut cx = Context::from_waker(&waker);
            if let Poll::Ready(out) = pinned.as_mut().poll(&mut cx) {
                return out;
            }
            self.run_until_idle();
        }
    }
}

fn dummy_waker() -> Waker {
    unsafe fn clone(_: *const ()) -> RawWaker {
        RawWaker::new(std::ptr::null(), &VTABLE)
    }
    unsafe fn wake(_: *const ()) {}
    unsafe fn wake_by_ref(_: *const ()) {}
    unsafe fn drop(_: *const ()) {}

    const VTABLE: RawWakerVTable = RawWakerVTable::new(clone, wake, wake_by_ref, drop);
    unsafe { Waker::from_raw(RawWaker::new(std::ptr::null(), &VTABLE)) }
}

pub mod task {
    use super::*;

    pub fn spawn<F>(loop_ref: &mut Loop, fut: F)
    where
        F: Future<Output = ()> + 'static,
    {
        loop_ref.spawn(fut);
    }
}
