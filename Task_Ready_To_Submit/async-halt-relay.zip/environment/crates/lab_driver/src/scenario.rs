use std::fs;
use std::future::Future;
use std::path::Path;
use std::pin::Pin;
use std::sync::atomic::{AtomicU32, Ordering};
use std::sync::Arc;
use std::task::{Context, Poll, RawWaker, RawWakerVTable, Waker};

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

use micro_sched::Loop;
use op_c::OpC;

#[derive(Debug, Clone, Deserialize)]
pub struct Plan {
    pub pool_id: String,
    pub worker_count: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScenarioRow {
    pub name: String,
    pub finish_reason: String,
    pub parked_workers: u32,
    pub resumed_workers: u32,
    pub instant_unpark: u32,
    pub fork_follows: u32,
    pub root_drop_safe: u32,
    pub digest_hex: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Report {
    pub schema_version: u32,
    pub pool_id: String,
    pub scenarios: Vec<ScenarioRow>,
}

pub fn load_plan(path: &Path) -> Plan {
    let raw = std::fs::read_to_string(path).expect("plan json");
    serde_json::from_str(&raw).expect("plan parse")
}

pub fn digest_row(row: &ScenarioRow) -> String {
    let payload = format!(
        "{}|{}|{}|{}|{}|{}|{}|",
        row.name,
        row.finish_reason,
        row.parked_workers,
        row.resumed_workers,
        row.instant_unpark,
        row.fork_follows,
        row.root_drop_safe,
    );
    format!("{:x}", Sha256::digest(payload.as_bytes()))
}

fn finish(mut row: ScenarioRow) -> ScenarioRow {
    row.digest_hex = digest_row(&row);
    row
}

fn noop_waker() -> Waker {
    unsafe fn clone(_: *const ()) -> RawWaker {
        RawWaker::new(std::ptr::null(), &VT)
    }
    unsafe fn wake(_: *const ()) {}
    unsafe fn wake_by_ref(_: *const ()) {}
    unsafe fn drop(_: *const ()) {}
    const VT: RawWakerVTable = RawWakerVTable::new(clone, wake, wake_by_ref, drop);
    unsafe { Waker::from_raw(RawWaker::new(std::ptr::null(), &VT)) }
}

pub fn run_pre_trip(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    core.flip();
    let mut polls = 0u32;
    let mut fut = std::pin::pin!(core.bind_b());
    let waker = noop_waker();
    let mut cx = Context::from_waker(&waker);
    let mut done = false;
    loop {
        polls += 1;
        if fut.as_mut().poll(&mut cx).is_ready() {
            done = true;
            break;
        }
        if polls > 4 {
            break;
        }
    }
    let instant = done && polls == 1;
    finish(ScenarioRow {
        name: "case_pre_trip".into(),
        finish_reason: if done { "complete" } else { "stuck" }.into(),
        parked_workers: 1,
        resumed_workers: if done { 1 } else { 0 },
        instant_unpark: if instant { 1 } else { 0 },
        fork_follows: 0,
        root_drop_safe: 0,
        digest_hex: String::new(),
    })
}

pub fn run_mass_park(plan: &Plan) -> ScenarioRow {
    let count = plan.worker_count.max(1);
    let core = Arc::new(OpC::mk());
    let resumed = Arc::new(AtomicU32::new(0));
    let mut loop_ref = Loop::new();
    for _ in 0..count {
        let snap = Arc::clone(&core);
        let tally = Arc::clone(&resumed);
        loop_ref.spawn(async move {
            snap.bind_b().await;
            tally.fetch_add(1, Ordering::Relaxed);
        });
    }
    core.flip();
    loop_ref.run_until_idle();
    let got = resumed.load(Ordering::Relaxed);
    finish(ScenarioRow {
        name: "case_mass_park".into(),
        finish_reason: if got == count { "complete" } else { "partial" }.into(),
        parked_workers: count,
        resumed_workers: got,
        instant_unpark: 0,
        fork_follows: 0,
        root_drop_safe: 0,
        digest_hex: String::new(),
    })
}

pub fn run_fork_follow(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let leaf = core.split_d();
    core.flip();
    let mut loop_ref = Loop::new();
    let mut ok = false;
    loop_ref.block_on(async {
        leaf.bind_b().await;
        ok = true;
    });
    finish(ScenarioRow {
        name: "case_fork_follow".into(),
        finish_reason: if ok { "complete" } else { "stuck" }.into(),
        parked_workers: 1,
        resumed_workers: if ok { 1 } else { 0 },
        instant_unpark: 0,
        fork_follows: if ok { 1 } else { 0 },
        root_drop_safe: 0,
        digest_hex: String::new(),
    })
}

pub fn run_fork_life(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let leaf = core.split_d();
    core.flip();
    drop(core);
    let safe = true;
    let mut polls = 0u32;
    let mut fut = std::pin::pin!(leaf.bind_b());
    let waker = noop_waker();
    let mut cx = Context::from_waker(&waker);
    let mut ok = false;
    loop {
        polls += 1;
        if fut.as_mut().poll(&mut cx).is_ready() {
            ok = true;
            break;
        }
        if polls > 4 {
            break;
        }
    }
    finish(ScenarioRow {
        name: "case_fork_life".into(),
        finish_reason: if ok { "complete" } else { "stuck" }.into(),
        parked_workers: 1,
        resumed_workers: if ok { 1 } else { 0 },
        instant_unpark: 0,
        fork_follows: 0,
        root_drop_safe: if safe { 1 } else { 0 },
        digest_hex: String::new(),
    })
}

pub fn run_unpark_clean(_plan: &Plan) -> ScenarioRow {
    let core = OpC::mk();
    let panicked = std::panic::catch_unwind(|| {
        let mut loop_ref = Loop::new();
        loop_ref.block_on(async {
            drop(core.bind_b());
            core.flip();
        });
    })
    .is_err();
    finish(ScenarioRow {
        name: "case_unpark_clean".into(),
        finish_reason: if panicked { "panic" } else { "complete" }.into(),
        parked_workers: 1,
        resumed_workers: 0,
        instant_unpark: 0,
        fork_follows: 0,
        root_drop_safe: 0,
        digest_hex: String::new(),
    })
}

pub fn run_named(name: &str, plan: &Plan) -> ScenarioRow {
    match name {
        "case_pre_trip" => run_pre_trip(plan),
        "case_mass_park" => run_mass_park(plan),
        "case_fork_follow" => run_fork_follow(plan),
        "case_fork_life" => run_fork_life(plan),
        "case_unpark_clean" => run_unpark_clean(plan),
        other => finish(ScenarioRow {
            name: other.into(),
            finish_reason: "unknown".into(),
            parked_workers: 0,
            resumed_workers: 0,
            instant_unpark: 0,
            fork_follows: 0,
            root_drop_safe: 0,
            digest_hex: String::new(),
        }),
    }
}

pub fn run_bundle(plan: &Plan, names: &[String]) -> Report {
    let scenarios = names.iter().map(|n| run_named(n, plan)).collect();
    Report {
        schema_version: 3,
        pool_id: plan.pool_id.clone(),
        scenarios,
    }
}
