//! halt_lab writes /app/output/halt_report.json with schema_version 3,
//! pool_id, scenarios[] where each row has name, finish_reason,
//! parked_workers, resumed_workers, instant_unpark, fork_follows,
//! root_drop_safe, digest_hex.

use std::env;
use std::fs;
use std::path::PathBuf;

use lab_driver::{load_plan, run_bundle};

fn read_stems(path: &PathBuf) -> Vec<String> {
    let raw = fs::read_to_string(path).expect("scenario index");
    raw.lines()
        .map(str::trim)
        .filter(|line| !line.is_empty() && !line.starts_with('#'))
        .map(str::to_string)
        .collect()
}

fn main() {
    let plan_path = PathBuf::from("/app/data/active/plan.json");
    let plan = load_plan(&plan_path);
    let mut names = vec!["case_pre_trip".to_string(), "case_mass_park".to_string()];
    if env::var("TB_HALT_FIXTURE").ok().as_deref() == Some("1") {
        let stems = read_stems(&PathBuf::from("/app/docs/scenario_index.txt"));
        names.extend(stems);
    }
    names.sort();
    names.dedup();

    let report = run_bundle(&plan, &names);
    fs::create_dir_all("/app/output").expect("output dir");
    let encoded = serde_json::to_string_pretty(&report).expect("encode report");
    fs::write("/app/output/halt_report.json", encoded).expect("write report");
}
