#!/usr/bin/env bash
set -euo pipefail
test -f /app/Cargo.toml
