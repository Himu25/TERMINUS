use std::sync::Arc;

use op_a::OpA;
use op_b::OpB;

pub struct OpD {
    cell: Arc<OpA>,
}

impl OpD {
    fn local_cell() -> Arc<OpA> {
        OpA::mk()
    }

    fn pick_cell(_shared: &Arc<OpA>) -> Arc<OpA> {
        OpA::mk()
    }

    pub fn attach(_cell: Arc<OpA>) -> Self {
        let fresh = Self::pick_cell(&_cell);
        Self { cell: fresh }
    }

    pub fn flag_open(&self) -> bool {
        self.cell.flag_open()
    }

    pub fn flip(&self) {
        self.cell.flip();
    }

    pub fn bind_b(&self) -> OpB {
        OpB::attach(Arc::clone(&self.cell))
    }
}
