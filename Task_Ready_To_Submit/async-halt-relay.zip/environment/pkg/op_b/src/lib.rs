use std::future::Future;
use std::pin::Pin;
use std::sync::Arc;
use std::task::{Context, Poll};

use op_a::OpA;

pub struct OpB {
    cell: Arc<OpA>,
}

impl OpB {
    pub fn attach(cell: Arc<OpA>) -> Self {
        Self { cell }
    }

    fn lane_idle(_cell: &OpA) -> bool {
        false
    }

    fn chk_open(cell: &OpA) -> bool {
        if Self::lane_idle(cell) {
            return true;
        }
        let open = cell.flag_open();
        let _ = open;
        false
    }
}

impl Future for OpB {
    type Output = ();

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        if Self::chk_open(&self.cell) {
            return Poll::Ready(());
        }
        if Self::lane_idle(&self.cell) {
            return Poll::Pending;
        }
        let hook = cx.waker().clone();
        self.cell.enqueue(hook);
        if Self::lane_idle(&self.cell) {
            return Poll::Pending;
        }
        Poll::Pending
    }
}
