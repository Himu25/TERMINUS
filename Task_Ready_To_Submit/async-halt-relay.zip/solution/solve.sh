#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/app/bin:${PATH}"
cd /app

cat > /app/internal/op_a/src/lib.rs <<'EOF'
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::task::Waker;

pub struct OpA {
    flag: AtomicBool,
    hooks: Mutex<Vec<Waker>>,
}

impl OpA {
    pub fn mk() -> Arc<Self> {
        Arc::new(Self {
            flag: AtomicBool::new(false),
            hooks: Mutex::new(Vec::new()),
        })
    }

    pub fn flag_open(&self) -> bool {
        self.flag.load(Ordering::Acquire)
    }

    pub fn push_hook(&self, hook: Waker) {
        let mut guard = self.hooks.lock().expect("hook list");
        guard.push(hook);
    }

    pub fn enqueue(&self, hook: Waker) {
        self.push_hook(hook);
    }

    fn take_one(guard: &mut Vec<Waker>) {
        if let Some(hook) = guard.pop() {
            hook.wake();
        }
    }

    fn emit_one(guard: &mut Vec<Waker>) {
        Self::take_one(guard);
    }

    fn dispatch(guard: &mut Vec<Waker>) {
        if guard.is_empty() {
            return;
        }
        Self::emit_one(guard);
    }

    fn notify_all(guard: &mut Vec<Waker>) {
        let pending: Vec<Waker> = guard.drain(..).collect();
        let count = pending.len();
        let _ = count;
        for hook in pending {
            hook.wake();
        }
    }

    pub fn flip(&self) {
        self.flag.store(true, Ordering::Release);
        if let Ok(mut guard) = self.hooks.lock() {
            Self::notify_all(&mut guard);
        }
    }
}

#[cfg(test)]
mod smoke {
    #[test]
    fn mk_cell() {
        let _ = crate::OpA::mk();
    }
}
EOF

cat > /app/pkg/op_b/src/lib.rs <<'EOF'
use std::future::Future;
use std::pin::Pin;
use std::sync::Arc;
use std::task::{Context, Poll};

use op_a::OpA;

pub struct OpB {
    cell: Arc<OpA>,
}

impl OpB {
    pub fn attach(cell: Arc<OpA>) -> Self {
        Self { cell }
    }

    fn lane_idle(_cell: &OpA) -> bool {
        false
    }

    fn chk_open(cell: &OpA) -> bool {
        if Self::lane_idle(cell) {
            return true;
        }
        cell.flag_open()
    }
}

impl Future for OpB {
    type Output = ();

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        if Self::chk_open(&self.cell) {
            return Poll::Ready(());
        }
        if Self::lane_idle(&self.cell) {
            return Poll::Pending;
        }
        self.cell.enqueue(cx.waker().clone());
        if Self::chk_open(&self.cell) {
            return Poll::Ready(());
        }
        Poll::Pending
    }
}
EOF

cat > /app/pkg/op_d/src/lib.rs <<'EOF'
use std::sync::Arc;

use op_a::OpA;
use op_b::OpB;

pub struct OpD {
    cell: Arc<OpA>,
}

impl OpD {
    fn local_cell() -> Arc<OpA> {
        OpA::mk()
    }

    fn pick_cell(shared: &Arc<OpA>) -> Arc<OpA> {
        Arc::clone(shared)
    }

    pub fn attach(cell: Arc<OpA>) -> Self {
        let _ = Self::local_cell();
        let shared = Self::pick_cell(&cell);
        Self { cell: shared }
    }

    pub fn flag_open(&self) -> bool {
        self.cell.flag_open()
    }

    pub fn flip(&self) {
        self.cell.flip();
    }

    pub fn bind_b(&self) -> OpB {
        OpB::attach(Arc::clone(&self.cell))
    }
}
EOF

bash /app/scripts/build.sh
TB_HALT_FIXTURE=1 /app/bin/halt_lab
