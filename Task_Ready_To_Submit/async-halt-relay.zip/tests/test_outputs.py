"""Verifier for async halt relay lab reports."""


import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "halt_report.json"
BIN = "/app/bin/halt_lab"
ACTIVE_PLAN = APP / "data" / "active" / "plan.json"
STEM_INDEX = APP / "docs" / "scenario_index.txt"

SCHEMA_VERSION = 3
FINISH_COMPLETE = "complete"

EXPECTED = {
    "case_pre_trip": {
        "finish_reason": FINISH_COMPLETE,
        "resumed_workers": 1,
        "instant_unpark": 1,
    },
    "case_fork_follow": {
        "finish_reason": FINISH_COMPLETE,
        "fork_follows": 1,
        "resumed_workers": 1,
    },
    "case_fork_life": {
        "finish_reason": FINISH_COMPLETE,
        "root_drop_safe": 1,
        "resumed_workers": 1,
    },
}


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    """Build halt_lab once for the verifier session."""
    env = {**os.environ}
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _row_digest_matches_rust(row: dict) -> str:
    proc = subprocess.run(
        [
            "/app/bin/digest_cli",
            row["name"],
            row["finish_reason"],
            str(row["parked_workers"]),
            str(row["resumed_workers"]),
            str(row["instant_unpark"]),
            str(row["fork_follows"]),
            str(row["root_drop_safe"]),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return proc.stdout.strip()


def _run_lab(extra_env: dict | None = None) -> dict:
    env = {
        **os.environ,
        "TB_HALT_FIXTURE": "1",
    }
    if extra_env:
        env.update(extra_env)
    subprocess.run([BIN], cwd="/app", env=env, check=True)
    return json.loads(OUT.read_text())


def _by_name(report: dict) -> dict[str, dict]:
    return {row["name"]: row for row in report["scenarios"]}


def _load_stems() -> list[str]:
    lines = STEM_INDEX.read_text().splitlines()
    return [line.strip() for line in lines if line.strip() and not line.startswith("#")]


def test_report_schema_and_pool() -> None:
    """Report uses the lab schema version and the active pool id."""
    report = _run_lab()
    assert report["schema_version"] == SCHEMA_VERSION
    plan = json.loads(ACTIVE_PLAN.read_text())
    assert report["pool_id"] == plan["pool_id"]
    assert len(report["scenarios"]) >= 5


def test_report_row_names_present() -> None:
    """Each scenario row includes a stem name."""
    report = _run_lab()
    for row in report["scenarios"]:
        assert isinstance(row["name"], str)
        assert row["name"]


def test_pre_trip_instant_unpark() -> None:
    """Pre-trip stem completes immediately without extra poll rounds."""
    row = _by_name(_run_lab())["case_pre_trip"]
    ex = EXPECTED["case_pre_trip"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["resumed_workers"] == ex["resumed_workers"]
    assert row["instant_unpark"] == ex["instant_unpark"]


def test_mass_park_resumes_all() -> None:
    """Mass-park stem resumes every parked worker."""
    row = _by_name(_run_lab())["case_mass_park"]
    plan = json.loads(ACTIVE_PLAN.read_text())
    assert row["parked_workers"] == plan["worker_count"]
    assert row["finish_reason"] == FINISH_COMPLETE
    assert row["resumed_workers"] == row["parked_workers"]


def test_fork_follow_parent_trip() -> None:
    """Forked sub-handle observes a parent trip."""
    row = _by_name(_run_lab())["case_fork_follow"]
    ex = EXPECTED["case_fork_follow"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["fork_follows"] == ex["fork_follows"]
    assert row["resumed_workers"] == ex["resumed_workers"]


def test_fork_life_after_root_drop() -> None:
    """Sub-handle waiters finish after the root is dropped."""
    row = _by_name(_run_lab())["case_fork_life"]
    ex = EXPECTED["case_fork_life"]
    assert row["finish_reason"] == ex["finish_reason"]
    assert row["root_drop_safe"] == ex["root_drop_safe"]
    assert row["resumed_workers"] == ex["resumed_workers"]


def test_unpark_clean_finish() -> None:
    """Dropped waiters do not panic when the mesh trips."""
    row = _by_name(_run_lab())["case_unpark_clean"]
    assert row["finish_reason"] == FINISH_COMPLETE


def test_stem_pre_trip() -> None:
    """Regression pre-trip stem keeps instant unpark set."""
    row = _by_name(_run_lab())["case_pre_trip"]
    assert row["instant_unpark"] == EXPECTED["case_pre_trip"]["instant_unpark"]


def test_stem_fork_follow() -> None:
    """Regression fork-follow stem records fork_follows."""
    row = _by_name(_run_lab())["case_fork_follow"]
    assert row["fork_follows"] == EXPECTED["case_fork_follow"]["fork_follows"]


def test_stem_fork_life() -> None:
    """Regression fork-life stem records root_drop_safe."""
    row = _by_name(_run_lab())["case_fork_life"]
    assert row["root_drop_safe"] == EXPECTED["case_fork_life"]["root_drop_safe"]


def test_regression_stems_complete() -> None:
    """Every stem listed in scenario_index finishes complete."""
    report = _run_lab()
    rows = _by_name(report)
    for stem in _load_stems():
        assert rows[stem]["finish_reason"] == FINISH_COMPLETE


def test_row_digests_match_helper() -> None:
    """Each scenario digest matches the digest helper."""
    report = _run_lab()
    for row in report["scenarios"]:
        assert row["digest_hex"] == _row_digest_matches_rust(row)


def test_cargo_smoke_tests_pass() -> None:
    """Workspace unit smoke tests pass after the agent fix."""
    env = {**os.environ}
    subprocess.run(
        ["cargo", "test", "--workspace", "--quiet"],
        cwd="/app",
        env=env,
        check=True,
    )
