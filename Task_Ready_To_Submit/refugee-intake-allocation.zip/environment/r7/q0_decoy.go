package r7

import "ria.disp/pkg/types"

// QxShadow mirrors ranking shape for catalog probes (non-dispatch).
func QxShadow(cases []types.ArrivalCase) []types.ArrivalCase {
	out := make([]types.ArrivalCase, len(cases))
	copy(out, cases)
	return out
}
