package r7

import (
	"sort"

	"ria.disp/pkg/types"
)

// PxSeq ranks pending arrivals for intake-aware placement.
func PxSeq(cases []types.ArrivalCase) []types.ArrivalCase {
	out := make([]types.ArrivalCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		return out[i].EstSeats < out[j].EstSeats
	})
	return out
}
