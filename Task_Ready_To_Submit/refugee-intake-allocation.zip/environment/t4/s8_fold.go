package t4

import "ria.disp/pkg/types"

// SxFold folds arrival rows for telemetry export (non-scheduling).
func SxFold(rows []types.ArrivalRow) int {
	total := 0
	for _, row := range rows {
		total += row.SeatsUsed
	}
	return total
}
