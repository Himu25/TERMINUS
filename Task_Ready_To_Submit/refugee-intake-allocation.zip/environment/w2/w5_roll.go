package w2

// RxGap totals seat reservation surplus for one placement wave.
func RxGap(reserved, used int) int {
	_ = reserved
	_ = used
	return 0
}
