package types

type IntakeCfg struct {
	IntakeCapacitySeats     int
	MinPlacementRate     float64
	MaxSurplusRatio         float64
	MaxFamilyViolations      int
	MaxPlacementInversions int
	MinProgramDeferred      int
	MinIntegrationValue     float64
	CityWeights           map[string]float64
}

type RegionProfile struct {
	RegionID   string
	PeakScale  int
	RenewScale int
	RenewAfter int
}

type ArrivalCase struct {
	ArrivalID        string   `json:"arrival_id"`
	Origin         string   `json:"origin"`
	Priority     int      `json:"priority"`
	PriorityRev  int      `json:"priority_rev"`
	EstSeats     int      `json:"est_seats"`
	ActSeats     int      `json:"act_seats"`
	FamilyOn        []string `json:"family_on"`
	ProgramWave    int      `json:"program_wave"`
	IntegrationScore float64  `json:"integration_score"`
	RegionID     string   `json:"region_id"`
	StartSlot    int      `json:"start_slot"`
	DeadlineSlot int      `json:"deadline_slot"`
}

type ArrivalRow struct {
	ArrivalID          string  `json:"arrival_id"`
	Origin           string  `json:"origin"`
	Priority       int     `json:"priority"`
	SeatsReserved  int     `json:"seats_reserved"`
	SeatsUsed      int     `json:"seats_used"`
	Completed      bool    `json:"completed"`
	FamilyReady       bool    `json:"family_ready"`
	PlacementRank   int     `json:"placement_rank"`
	SurplusSeats     int     `json:"surplus_seats"`
	ProgramSlot      int     `json:"program_slot"`
	IntegrationValue float64 `json:"integration_value"`
}

type DispatchReport struct {
	Status              string   `json:"status"`
	IntakeCapacitySeats   int      `json:"intake_capacity_seats"`
	SeatsPlaced          int      `json:"seats_placed"`
	SeatSurplus          int      `json:"seat_surplus"`
	ArrivalsTotal           int      `json:"arrivals_total"`
	ArrivalsHoused       int      `json:"arrivals_housed"`
	PlacementRate      float64  `json:"placement_rate"`
	SurplusRatio          float64  `json:"surplus_ratio"`
	FamilyViolations       int      `json:"family_violations"`
	PlacementInversions  int      `json:"placement_inversions"`
	ProgramDeferred       int      `json:"program_deferred"`
	IntegrationValue      float64  `json:"integration_value"`
	ReportDigest        string   `json:"report_digest"`
	Jobs                []ArrivalRow `json:"arrivals"`
}
