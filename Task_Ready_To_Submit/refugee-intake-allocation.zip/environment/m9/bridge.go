package m9

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libm9_meter.a -ldl -lm
#include "seat_fold.h"
*/
import "C"

// Roll holds billable seats for one arrival.
type Roll struct {
	Billable  int
	DriftFlag bool
}

// MeterSpan resolves billable seats for an arrival row with city capacity blending.
func MeterSpan(est, act, overlay, peakScale, renewScale, renewAfter, startSlot int) Roll {
	ct := C.span_fold(
		C.int(est), C.int(act), C.int(overlay),
		C.int(peakScale), C.int(renewScale), C.int(renewAfter), C.int(startSlot),
	)
	return Roll{
		Billable:  int(ct.billable),
		DriftFlag: ct.drift_flag != 0,
	}
}

// MeterBatch scores a slice of estimates (decoy helper).
func MeterBatch(estimates []int32) int {
	if len(estimates) == 0 {
		return 0
	}
	sum := 0
	for _, e := range estimates {
		if e > 0 {
			sum += int(e)
		}
	}
	return sum
}
