// Package span wraps the Rust credit meter for Go callers.
package m9
