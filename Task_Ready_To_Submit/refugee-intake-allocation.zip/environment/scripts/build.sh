#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1

mkdir -p /app/bin
cd /app/m9
cargo build --release --locked
cd /app
GOFLAGS=-mod=mod go build -o /app/bin/intakedisp ./cmd/intakedisp
GOFLAGS=-mod=mod go build -o /app/bin/arrivalpack ./cmd/arrivalpack
