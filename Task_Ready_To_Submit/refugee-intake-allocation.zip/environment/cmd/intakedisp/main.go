package main

import (
	"fmt"
	"os"

	"ria.disp/drv"
)

func main() {
	if len(os.Args) < 3 {
		fmt.Fprintln(os.Stderr, "usage: intakedisp <arrivals.jsonl> <out.json>")
		os.Exit(2)
	}
	cfg, err := drv.LoadCfg("/app/config/intake.toml")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	cases, err := drv.LoadJobs(os.Args[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	overlay, err := drv.LoadOverlay("/app/data/intake_overlay.csv")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	regions, err := drv.LoadRegions("/app/data/city_capacity.csv")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	report, err := drv.Run(cfg, cases, overlay, regions)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if err := drv.WriteReport(os.Args[2], report); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
