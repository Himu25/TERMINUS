package drv

import "ria.disp/p5"

func waveRenewTotal(renewWave, estGrams, headroom int) int {
	if renewWave <= 0 {
		return 0
	}
	return p5.WxAbsorb(estGrams/4, headroom)
}
