package drv

import (
	"ria.disp/m9"
	"ria.disp/pkg/types"
	"ria.disp/w2"
)

func meterBillable(jc types.ArrivalCase, overlayVal int, rp types.RegionProfile) int {
	peakScale := rp.PeakScale
	renewScale := rp.RenewScale
	renewAfter := rp.RenewAfter
	if overlayVal > 0 {
		peakScale, renewScale, renewAfter = 100, 100, 0
	}
	roll := m9.MeterSpan(
		jc.EstSeats, jc.ActSeats, overlayVal,
		peakScale, renewScale, renewAfter, jc.StartSlot,
	)
	if roll.Billable > 0 {
		return roll.Billable
	}
	return jc.EstSeats
}

func jobWaste(reserved, used int) int {
	return w2.RxGap(reserved, used)
}
