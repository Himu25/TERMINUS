package drv

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"

	"ria.disp/f3"
	"ria.disp/pkg/types"
	"ria.disp/r7"
	"ria.disp/t4"
	"ria.disp/v6"
)

func LoadCfg(path string) (types.IntakeCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.IntakeCfg{}, err
	}
	cfg := types.IntakeCfg{
		IntakeCapacitySeats:     15000,
		MinPlacementRate:     0.75,
		MaxSurplusRatio:         0.35,
		MaxFamilyViolations:      0,
		MaxPlacementInversions: 1,
		MinProgramDeferred:      3,
        MinIntegrationValue:     1.5,
		CityWeights:           map[string]float64{"team_a": 1.0, "team_b": 1.0, "team_c": 1.0},
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "intake_capacity_seats":
			fmt.Sscanf(val, "%d", &cfg.IntakeCapacitySeats)
		case "min_placement_rate":
			fmt.Sscanf(val, "%f", &cfg.MinPlacementRate)
		case "max_surplus_ratio":
			fmt.Sscanf(val, "%f", &cfg.MaxSurplusRatio)
		case "max_family_violations":
			fmt.Sscanf(val, "%d", &cfg.MaxFamilyViolations)
		case "max_placement_inversions":
			fmt.Sscanf(val, "%d", &cfg.MaxPlacementInversions)
		case "min_program_deferred":
			fmt.Sscanf(val, "%d", &cfg.MinProgramDeferred)
		case "min_integration_value":
			fmt.Sscanf(val, "%f", &cfg.MinIntegrationValue)
		case "city_weight_origin_a":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.CityWeights["team_a"] = w
		case "city_weight_origin_b":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.CityWeights["team_b"] = w
		case "city_weight_origin_c":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.CityWeights["team_c"] = w
		}
	}
	return cfg, nil
}

func LoadRegions(path string) (map[string]types.RegionProfile, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]types.RegionProfile)
	for i, row := range rows {
		if i == 0 || len(row) < 4 {
			continue
		}
		var peak, renew, after int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &peak)
		fmt.Sscanf(strings.TrimSpace(row[2]), "%d", &renew)
		fmt.Sscanf(strings.TrimSpace(row[3]), "%d", &after)
		id := strings.TrimSpace(row[0])
		out[id] = types.RegionProfile{
			RegionID:   id,
			PeakScale:  peak,
			RenewScale: renew,
			RenewAfter: after,
		}
	}
	return out, nil
}

func LoadJobs(path string) ([]types.ArrivalCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.ArrivalCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var jc types.ArrivalCase
		if err := json.Unmarshal([]byte(line), &jc); err != nil {
			return nil, err
		}
		if jc.RegionID == "" {
			jc.RegionID = "us-east"
		}
		out = append(out, jc)
	}
	return out, sc.Err()
}

func LoadOverlay(path string) (map[string]int, error) {
	f, err := os.Open(path)
	if err != nil {
		return map[string]int{}, nil
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]int)
	for i, row := range rows {
		if i == 0 || len(row) < 2 {
			continue
		}
		var grams int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &grams)
		out[strings.TrimSpace(row[0])] = grams
	}
	return out, nil
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

func regionFor(jc types.ArrivalCase, regions map[string]types.RegionProfile) types.RegionProfile {
	if rp, ok := regions[jc.RegionID]; ok {
		return rp
	}
	return types.RegionProfile{RegionID: jc.RegionID, PeakScale: 100, RenewScale: 100, RenewAfter: 0}
}

func Run(cfg types.IntakeCfg, cases []types.ArrivalCase, overlay map[string]int, regions map[string]types.RegionProfile) (types.DispatchReport, error) {
	ordered := r7.PxSeq(cases)
	report := types.DispatchReport{
		Status:            "ok",
		IntakeCapacitySeats: cfg.IntakeCapacitySeats,
		ArrivalsTotal:         len(ordered),
	}
	done := make(map[string]bool)
	budgetLeft := cfg.IntakeCapacitySeats
	var spent, totalWaste, completed, depViol, inversions, renewTotal int
	var valueTotal float64
	prevRank := -1
	report.Jobs = make([]types.ArrivalRow, 0, len(ordered))

	for idx, jc := range ordered {
		actualReady := true
		for _, depID := range jc.FamilyOn {
			if !done[depID] {
				actualReady = false
				break
			}
		}
		depReady := f3.DxGate(jc.FamilyOn, done)
		if len(jc.FamilyOn) > 0 && !actualReady && depReady {
			depViol++
		}
		overlayVal := 0
		if act, ok := overlay[jc.ArrivalID]; ok && act > 0 {
			overlayVal = act
			jc.ActSeats = act
		}
		rp := regionFor(jc, regions)
		billable := meterBillable(jc, overlayVal, rp)
		if billable <= 0 {
			billable = jc.EstSeats
		}
		reserveNeed := v6.AxNeed(jc.EstSeats, billable)
		reserved, ok := v6.BxReserve(budgetLeft, reserveNeed)
		headroom := budgetLeft - reserved
		renewTotal += waveRenewTotal(jc.ProgramWave, jc.EstSeats, headroom)
		used := 0
		finished := false
		if ok && depReady {
			used = jc.ActSeats
			if used <= 0 {
				used = billable
			}
			if used > reserved {
				used = reserved
			}
			budgetLeft -= reserved
			spent += used
			finished = true
			completed++
			done[jc.ArrivalID] = true
			valueTotal += v6.VxValue(jc.IntegrationScore, used)
		}
		wasteAmt := jobWaste(reserved, used)
		totalWaste += wasteAmt
		rankScore := jc.PriorityRev*10 + jc.Priority
		if finished {
			if prevRank >= 0 && rankScore > prevRank {
				inversions++
			}
			prevRank = rankScore
		}
		row := types.ArrivalRow{
			ArrivalID:          jc.ArrivalID,
			Origin:           jc.Origin,
			Priority:       jc.Priority,
			SeatsReserved:  reserved,
			SeatsUsed:      used,
			Completed:      finished,
			FamilyReady:       depReady,
			PlacementRank:   idx + 1,
			SurplusSeats:     wasteAmt,
			ProgramSlot:      jc.ProgramWave,
			IntegrationValue: round4(v6.VxValue(jc.IntegrationScore, used)),
		}
		report.Jobs = append(report.Jobs, row)
	}

	report.SeatsPlaced = spent
	report.SeatSurplus = totalWaste
	report.ArrivalsHoused = completed
	if report.ArrivalsTotal > 0 {
		report.PlacementRate = round4(float64(completed) / float64(report.ArrivalsTotal))
	}
	if spent > 0 {
		report.SurplusRatio = round4(float64(totalWaste) / float64(spent))
	}
	report.FamilyViolations = depViol
	report.PlacementInversions = inversions
	report.ProgramDeferred = renewTotal
	report.IntegrationValue = round4(valueTotal)
	hasRenew := false
	for _, jc := range ordered {
		if jc.ProgramWave > 0 {
			hasRenew = true
			break
		}
	}
	if !meetsFloors(cfg, report, hasRenew) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func meetsFloors(cfg types.IntakeCfg, report types.DispatchReport, hasRenew bool) bool {
	if report.PlacementRate < cfg.MinPlacementRate {
		return false
	}
	if report.SurplusRatio > cfg.MaxSurplusRatio {
		return false
	}
	if report.FamilyViolations > cfg.MaxFamilyViolations {
		return false
	}
	if report.PlacementInversions > cfg.MaxPlacementInversions {
		return false
	}
	if report.ProgramDeferred < cfg.MinProgramDeferred {
		if hasRenew {
			return false
		}
	}
	if report.IntegrationValue < cfg.MinIntegrationValue {
		return false
	}
	for _, row := range report.Jobs {
		if strings.HasPrefix(row.ArrivalID, "a_fam_") && !row.FamilyReady && row.Completed {
			return false
		}
		if strings.HasPrefix(row.ArrivalID, "a_prog_") && row.ProgramSlot > 0 && !row.Completed {
			return false
		}
		if strings.HasPrefix(row.ArrivalID, "a_overlay_") && row.SurplusSeats == 0 && row.SeatsReserved > row.SeatsUsed+50 {
			return false
		}
		if strings.HasPrefix(row.ArrivalID, "a_city_") && row.Completed && row.SeatsUsed > row.SeatsReserved+200 {
			return false
		}
	}
	_ = t4.SxFold(report.Jobs)
	return true
}

type digestPayload struct {
	Status              string         `json:"status"`
	IntakeCapacitySeats   int            `json:"intake_capacity_seats"`
	SeatsPlaced          int            `json:"seats_placed"`
	SeatSurplus          int            `json:"seat_surplus"`
	ArrivalsTotal           int            `json:"arrivals_total"`
	ArrivalsHoused       int            `json:"arrivals_housed"`
	PlacementRate      float64        `json:"placement_rate"`
	SurplusRatio          float64        `json:"surplus_ratio"`
	FamilyViolations       int            `json:"family_violations"`
	PlacementInversions  int            `json:"placement_inversions"`
	ProgramDeferred       int            `json:"program_deferred"`
	IntegrationValue      float64        `json:"integration_value"`
	ReportDigest        string         `json:"report_digest"`
	Jobs                []types.ArrivalRow `json:"arrivals"`
}

func digestBody(report types.DispatchReport) string {
	payload := digestPayload{
		Status:             report.Status,
		IntakeCapacitySeats:  report.IntakeCapacitySeats,
		SeatsPlaced:         report.SeatsPlaced,
		SeatSurplus:         report.SeatSurplus,
		ArrivalsTotal:          report.ArrivalsTotal,
		ArrivalsHoused:      report.ArrivalsHoused,
		PlacementRate:     report.PlacementRate,
		SurplusRatio:         report.SurplusRatio,
		FamilyViolations:      report.FamilyViolations,
		PlacementInversions: report.PlacementInversions,
		ProgramDeferred:      report.ProgramDeferred,
		IntegrationValue:     report.IntegrationValue,
		ReportDigest:       "",
		Jobs:               report.Jobs,
	}
	raw, err := marshalDigestJSON(payload)
	if err != nil {
		return ""
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func marshalDigestJSON(payload digestPayload) ([]byte, error) {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return nil, err
	}
	b := buf.Bytes()
	if n := len(b); n > 0 && b[n-1] == '\n' {
		b = b[:n-1]
	}
	return b, nil
}

func WriteReport(path string, report types.DispatchReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func p95(values []int) int {
	if len(values) == 0 {
		return 0
	}
	cp := append([]int(nil), values...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}
