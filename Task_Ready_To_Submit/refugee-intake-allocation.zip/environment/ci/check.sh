#!/bin/bash
set -euo pipefail
cd /app
bash /app/scripts/build.sh
/app/bin/arrivalpack /app/data/arrival_manifest.jsonl /app/data/arrivals_default.jsonl
/app/tools/run_intake
