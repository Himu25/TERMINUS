Municipal refugee intake ties together a Go placement driver, Rust seat meter, and bash runners under /app.

The intakedisp binary performs daily intake-aware placement across family-linked arrival rows.
