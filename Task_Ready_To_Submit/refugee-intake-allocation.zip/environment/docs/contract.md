# Intake report contract

## Top-level fields

- status: ok when guardrails pass, otherwise fail
- intake_capacity_seats: daily seat pool from intake.toml
- seats_placed: billable seats consumed by housed arrivals
- seat_surplus: reservation surplus summed across arrivals
- arrivals_total: input JSONL row count
- arrivals_housed: arrivals marked completed
- placement_rate: arrivals_housed divided by arrivals_total
- surplus_ratio: seat_surplus divided by seats_placed
- family_violations: arrivals started before family linkages finished
- placement_inversions: completed arrivals whose rank score fell below a prior finish
- program_deferred: program headroom seats absorbed during waves
- integration_value: weighted integration score total for housed arrivals
- report_digest: sha256 hex of compact JSON with report_digest empty
- arrivals: per-arrival rows

## Arrival row fields

- arrival_id, origin, priority
- seats_reserved, seats_used, surplus_seats
- completed, family_ready, placement_rank, program_slot, integration_value

## Placement order

Pending arrivals are sorted before allocation using, in order:

1. priority_rev descending (late revisions outrank stale rows)
2. priority descending
3. integration_score descending
4. arrival_id ascending (stable tie-break)

## placement_rank

1-based position in the scheduler processing order after the sort above. Lower placement_rank means the arrival was placed earlier.

## Placement inversions

For each completed arrival, form rank score = priority_rev * 10 + priority. placement_inversions counts how often a completed arrival's rank score is greater than the rank score of an earlier-completed arrival.

## City capacity

city_capacity.csv supplies peak_scale, renew_scale, and renew_after per region_id. The Rust meter blends peak and program scales across each arrival's start_slot and duration before converting estimates and actuals into billable seats.

## Overlay and seat accounting

- seats_reserved: reservation size from est_seats when est_seats is positive; when est_seats is zero, reservation follows regionally scaled billable seats from the meter
- seats_used: billable consumption charged against the pool for completed arrivals. When est_seats is positive, use overlay act_seats from intake_overlay.csv when present, otherwise raw act_seats from the arrival row (overlay rows skip regional rescaling). When est_seats is zero, use regionally scaled billable actual seats from the meter, capped by seats_reserved
- surplus_seats: seats_reserved minus seats_used (zero when reserved is not greater than used)
- Overlay drift rows keep the estimate reservation even when actual headcount is lower, so surplus_seats reflects reserved minus used
- seats_placed sums seats_used across completed arrivals

Digest JSON uses the same keys as the written report with report_digest set to empty string before hashing.
