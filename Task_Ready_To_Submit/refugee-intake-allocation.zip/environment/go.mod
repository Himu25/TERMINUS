module ria.disp

go 1.22
