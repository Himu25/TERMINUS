"""Validate /app/output/intake_report.json against intake.toml guardrails."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "intake_report.json"
ARRIVALS = APP / "data" / "arrivals_default.jsonl"
CFG = APP / "config" / "intake.toml"
OVERLAY = APP / "data" / "intake_overlay.csv"
CASES = Path(__file__).resolve().parent / "data"

_DEFAULT_ARRIVALS_TEXT = ARRIVALS.read_text(encoding="utf-8") if ARRIVALS.is_file() else ""
_DEFAULT_CFG_TEXT = CFG.read_text(encoding="utf-8") if CFG.is_file() else ""
_DEFAULT_OVERLAY_TEXT = OVERLAY.read_text(encoding="utf-8") if OVERLAY.is_file() else ""

REPORT_KEYS = frozenset(
    {
        "status",
        "intake_capacity_seats",
        "seats_placed",
        "seat_surplus",
        "arrivals_total",
        "arrivals_housed",
        "placement_rate",
        "surplus_ratio",
        "family_violations",
        "placement_inversions",
        "program_deferred",
        "integration_value",
        "report_digest",
        "arrivals",
    }
)
ROW_KEYS = frozenset(
    {
        "arrival_id",
        "origin",
        "priority",
        "seats_reserved",
        "seats_used",
        "surplus_seats",
        "completed",
        "family_ready",
        "placement_rank",
        "program_slot",
        "integration_value",
    }
)


def _load_overlay() -> dict[str, int]:
    overlay: dict[str, int] = {}
    if not OVERLAY.is_file():
        return overlay
    lines = OVERLAY.read_text(encoding="utf-8").splitlines()
    for line in lines[1:]:
        line = line.strip()
        if not line:
            continue
        arrival_id, seats = (part.strip() for part in line.split(",", 1))
        overlay[arrival_id] = int(seats)
    return overlay


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "intake_capacity_seats": 15000,
        "min_placement_rate": 0.75,
        "max_surplus_ratio": 0.35,
        "max_family_violations": 0,
        "max_placement_inversions": 1,
        "min_program_deferred": 3,
        "min_integration_value": 1.5,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in ("min_placement_rate", "max_surplus_ratio", "min_integration_value"):
            cfg[key] = float(val)
        elif key in (
            "intake_capacity_seats",
            "max_family_violations",
            "max_placement_inversions",
            "min_program_deferred",
        ):
            cfg[key] = int(float(val))
    return cfg


def _arrival_rows_from_text(text: str) -> list[dict]:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def _arrival_ids_from_text(text: str) -> list[str]:
    return [row["arrival_id"] for row in _arrival_rows_from_text(text)]


def _arrival_map_from_text(text: str) -> dict[str, dict]:
    return {row["arrival_id"]: row for row in _arrival_rows_from_text(text)}


def _assert_arrivals_match_input(report: dict, arrivals_text: str) -> None:
    expected_ids = _arrival_ids_from_text(arrivals_text)
    report_ids = [row["arrival_id"] for row in report["arrivals"]]
    assert report["arrivals_total"] == len(expected_ids)
    assert len(report_ids) == len(expected_ids)
    assert set(report_ids) == set(expected_ids)


@pytest.fixture(autouse=True)
def restore_default_arrivals() -> None:
    yield
    if _DEFAULT_ARRIVALS_TEXT:
        _atomic_write_text(ARRIVALS, _DEFAULT_ARRIVALS_TEXT)
    if _DEFAULT_CFG_TEXT:
        _atomic_write_text(CFG, _DEFAULT_CFG_TEXT)
    if _DEFAULT_OVERLAY_TEXT:
        _atomic_write_text(OVERLAY, _DEFAULT_OVERLAY_TEXT)


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _swap_fixture(stem: str) -> str:
    src = CASES / f"{stem}.jsonl"
    text = src.read_text(encoding="utf-8")
    _atomic_write_text(ARRIVALS, text)
    return text


def _swap_overlay_fixture(stem: str) -> None:
    src = CASES / f"{stem}.csv"
    _atomic_write_text(OVERLAY, src.read_text(encoding="utf-8"))


def _patch_cfg_capacity(seats: int) -> None:
    lines = []
    for line in _DEFAULT_CFG_TEXT.splitlines():
        if line.strip().startswith("intake_capacity_seats="):
            lines.append(f"intake_capacity_seats={seats}")
        else:
            lines.append(line)
    _atomic_write_text(CFG, "\n".join(lines) + "\n")


def _expected_digest(report: dict) -> str:
    payload = dict(report)
    payload["report_digest"] = ""
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _invoke_default() -> None:
    proc = subprocess.run(
        ["/app/tools/run_intake"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "intake_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    _invoke_default()


def test_report_top_level_keys_exact() -> None:
    """Report must expose only the documented top-level keys."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS


def test_arrival_row_schema() -> None:
    """Each arrival row must match the documented per-arrival schema."""
    report = _load_report()
    assert report["arrivals"]
    for row in report["arrivals"]:
        assert set(row.keys()) == ROW_KEYS
        assert isinstance(row["arrival_id"], str) and row["arrival_id"]
        assert isinstance(row["origin"], str) and row["origin"]
        assert isinstance(row["priority"], int)
        assert row["seats_reserved"] >= 0
        assert row["seats_used"] >= 0
        assert row["surplus_seats"] >= 0
        assert isinstance(row["completed"], bool)
        assert isinstance(row["family_ready"], bool)
        assert row["placement_rank"] >= 1
        assert row["program_slot"] >= 0
        assert row["integration_value"] >= 0.0


def test_passing_run_contract() -> None:
    """Default bundle must finish ok and meet intake.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["intake_capacity_seats"] == cfg["intake_capacity_seats"]
    _assert_arrivals_match_input(report, _DEFAULT_ARRIVALS_TEXT)
    assert report["placement_rate"] >= cfg["min_placement_rate"]
    assert report["surplus_ratio"] <= cfg["max_surplus_ratio"]
    assert report["family_violations"] <= cfg["max_family_violations"]
    assert report["placement_inversions"] <= cfg["max_placement_inversions"]
    assert report["program_deferred"] >= cfg["min_program_deferred"]
    assert report["integration_value"] >= cfg["min_integration_value"]


def test_arrivals_total_matches_input_rows() -> None:
    """Report arrival IDs must cover every input JSONL row with no drops or extras."""
    report = _load_report()
    _assert_arrivals_match_input(report, _DEFAULT_ARRIVALS_TEXT)


def test_report_digest_matches_payload() -> None:
    """report_digest must hash the compact pre-digest JSON payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_deterministic_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_family_rows_finish_in_order() -> None:
    """Family linkage rows must not start before prerequisites even when a child outranks its parent."""
    report = _load_report()
    ranks = {row["arrival_id"]: row["placement_rank"] for row in report["arrivals"]}
    root = next(r for r in report["arrivals"] if r["arrival_id"] == "a_fam_root")
    leaf = next(r for r in report["arrivals"] if r["arrival_id"] == "a_fam_leaf")
    assert ranks["a_fam_leaf"] < ranks["a_fam_root"], (leaf, root)
    assert report["family_violations"] == 0
    assert root["completed"] is True
    for row in report["arrivals"]:
        if row["arrival_id"].startswith("a_fam_") and row["completed"]:
            assert row["family_ready"] is True, row


def test_vuln_hot_ranks_before_cold() -> None:
    """Late vulnerability revision rows must finish before stale low-revision peers."""
    report = _load_report()
    hot = next(r for r in report["arrivals"] if r["arrival_id"] == "a_vuln_hot")
    cold = next(r for r in report["arrivals"] if r["arrival_id"] == "a_vuln_cold")
    assert hot["completed"] is True
    assert cold["completed"] is True
    assert hot["placement_rank"] < cold["placement_rank"], (hot, cold)


def test_overlay_accounting_semantics() -> None:
    """Overlay rows reserve estimates, bill actuals, and record reserved minus used."""
    report = _load_report()
    inputs = _arrival_map_from_text(_DEFAULT_ARRIVALS_TEXT)
    overlay = _load_overlay()
    for row in report["arrivals"]:
        if not row["arrival_id"].startswith("a_overlay_") or not row["completed"]:
            continue
        spec = inputs[row["arrival_id"]]
        expected_used = overlay.get(row["arrival_id"], spec["act_seats"])
        assert row["seats_reserved"] == spec["est_seats"]
        assert row["seats_used"] == expected_used
        assert row["surplus_seats"] == max(0, row["seats_reserved"] - row["seats_used"])


def test_overlay_rows_record_surplus() -> None:
    """Overlay-prone rows with inflated reservations must record surplus_seats."""
    report = _load_report()
    overlay_rows = [r for r in report["arrivals"] if r["arrival_id"].startswith("a_overlay_")]
    assert overlay_rows
    assert any(r["surplus_seats"] > 0 for r in overlay_rows if r["completed"])


def test_program_rows_complete() -> None:
    """Program-wave rows with the a_prog_ prefix must complete under the default bundle."""
    report = _load_report()
    burst_rows = [r for r in report["arrivals"] if r["arrival_id"].startswith("a_prog_")]
    assert burst_rows
    assert all(r["completed"] for r in burst_rows), burst_rows


def test_city_rows_respect_capacity() -> None:
    """City rows must bill through blended capacity, not raw headcount alone."""
    report = _load_report()
    us = next(r for r in report["arrivals"] if r["arrival_id"] == "a_city_us")
    eu = next(r for r in report["arrivals"] if r["arrival_id"] == "a_city_eu")
    assert us["completed"] and eu["completed"]
    assert eu["seats_reserved"] < us["seats_reserved"]
    assert eu["seats_used"] < us["seats_used"]


def test_program_late_row_completes() -> None:
    """Delayed-program a_prog_late row must complete under the default bundle."""
    report = _load_report()
    renew = next(r for r in report["arrivals"] if r["arrival_id"] == "a_prog_late")
    assert renew["completed"] is True
    assert renew["program_slot"] > 0


def test_seat_surplus_matches_row_totals() -> None:
    """seat_surplus must equal the sum of per-row surplus_seats."""
    report = _load_report()
    row_total = sum(row["surplus_seats"] for row in report["arrivals"])
    assert report["seat_surplus"] == row_total


def test_seats_placed_matches_used_sum() -> None:
    """seats_placed must equal billed seats_used for completed arrivals."""
    report = _load_report()
    used_total = sum(row["seats_used"] for row in report["arrivals"] if row["completed"])
    assert report["seats_placed"] == used_total


def test_placement_rate_matches_housed_ratio() -> None:
    """placement_rate must match housed arrivals over total rounded to four decimals."""
    report = _load_report()
    if report["arrivals_total"] == 0:
        expected = 0.0
    else:
        expected = round(report["arrivals_housed"] / report["arrivals_total"], 4)
    assert report["placement_rate"] == expected


def test_arrivals_housed_matches_completed_count() -> None:
    """arrivals_housed must equal the number of completed arrival rows."""
    report = _load_report()
    completed = sum(1 for row in report["arrivals"] if row["completed"])
    assert report["arrivals_housed"] == completed


def test_hidden_overlay_drift() -> None:
    """Overlay-drift scenario must keep surplus_ratio under max_surplus_ratio."""
    cfg = _parse_cfg()
    arrivals_text = _swap_fixture("est_drift")
    _invoke_default()
    report = _load_report()
    _assert_arrivals_match_input(report, arrivals_text)
    inputs = _arrival_map_from_text(arrivals_text)
    for row in report["arrivals"]:
        if not row["arrival_id"].startswith("a_overlay_") or not row["completed"]:
            continue
        spec = inputs[row["arrival_id"]]
        assert row["seats_reserved"] == spec["est_seats"]
        assert row["surplus_seats"] == max(0, row["seats_reserved"] - row["seats_used"])
        assert row["surplus_seats"] > 0
    assert report["surplus_ratio"] <= cfg["max_surplus_ratio"]
    assert report["status"] == "ok"


def test_hidden_program_cluster_defers() -> None:
    """Program-cluster scenario must defer enough program headroom."""
    cfg = _parse_cfg()
    arrivals_text = _swap_fixture("burst_cluster")
    _invoke_default()
    report = _load_report()
    _assert_arrivals_match_input(report, arrivals_text)
    burst_rows = [r for r in report["arrivals"] if r["arrival_id"].startswith("a_prog_")]
    assert burst_rows
    assert all(r["completed"] for r in burst_rows)
    assert report["program_deferred"] >= cfg["min_program_deferred"]
    assert report["status"] == "ok"


def test_hidden_value_mix_floor() -> None:
    """Integration-score mix scenario must meet integration_value floor."""
    cfg = _parse_cfg()
    arrivals_text = _swap_fixture("value_mix")
    _invoke_default()
    report = _load_report()
    _assert_arrivals_match_input(report, arrivals_text)
    assert report["status"] == "ok"
    assert report["integration_value"] >= cfg["min_integration_value"]


def test_hidden_overlay_meter() -> None:
    """Zero-estimate overlay row must bill overlay seats through the meter."""
    arrivals_text = _swap_fixture("overlay_meter")
    _invoke_default()
    report = _load_report()
    _assert_arrivals_match_input(report, arrivals_text)
    overlay = _load_overlay()
    expected_used = overlay["a_meter_overlay"]
    row = next(r for r in report["arrivals"] if r["arrival_id"] == "a_meter_overlay")
    assert row["completed"] is True
    assert row["seats_used"] == expected_used
    assert row["seats_reserved"] >= row["seats_used"]
    assert row["surplus_seats"] == max(0, row["seats_reserved"] - row["seats_used"])


def test_hidden_city_mix_bills() -> None:
    """City variability scenario must bill eu-west below us-east for similar headcount."""
    arrivals_text = _swap_fixture("region_mix")
    _invoke_default()
    report = _load_report()
    _assert_arrivals_match_input(report, arrivals_text)
    us = next(r for r in report["arrivals"] if r["arrival_id"] == "a_city_us")
    eu = next(r for r in report["arrivals"] if r["arrival_id"] == "a_city_eu")
    assert us["completed"] and eu["completed"]
    assert eu["seats_reserved"] < us["seats_reserved"]
    assert eu["seats_used"] < us["seats_used"]


def test_hidden_capacity_shrink() -> None:
    """Shrunk intake_capacity_seats must still meet guardrails on the default bundle."""
    cfg = _parse_cfg()
    _patch_cfg_capacity(12000)
    _invoke_default()
    report = _load_report()
    assert report["intake_capacity_seats"] == 12000
    assert report["status"] == "ok"
    assert report["placement_rate"] >= cfg["min_placement_rate"]


def test_hidden_delayed_overlay() -> None:
    """Delayed overlay reporting must still reconcile surplus_seats for overlay rows."""
    cfg = _parse_cfg()
    _swap_overlay_fixture("delayed_overlay")
    _invoke_default()
    report = _load_report()
    overlay_rows = [
        r
        for r in report["arrivals"]
        if r["arrival_id"].startswith("a_overlay_") and r["completed"]
    ]
    assert overlay_rows
    assert all(
        r["surplus_seats"] == max(0, r["seats_reserved"] - r["seats_used"]) for r in overlay_rows
    )
    assert report["surplus_ratio"] <= cfg["max_surplus_ratio"]
    assert report["status"] == "ok"
