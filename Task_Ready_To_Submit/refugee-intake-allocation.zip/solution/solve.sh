#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/intake.toml
require_file /app/data/arrival_manifest.jsonl
require_file /app/data/city_capacity.csv
require_file /app/data/intake_overlay.csv
mkdir -p /app/bin /app/output

log "apply patched sources"
cp "${ROOT_DIR}/oracle/p2_order.go" /app/r7/p2_order.go
cp "${ROOT_DIR}/oracle/d4_hold.go" /app/f3/d4_hold.go
cp "${ROOT_DIR}/oracle/b7_slot.go" /app/p5/b7_slot.go
cp "${ROOT_DIR}/oracle/w5_roll.go" /app/w2/w5_roll.go
cp "${ROOT_DIR}/oracle/lib.rs" /app/m9/src/lib.rs

log "rebuild intake dispatcher"
bash /app/scripts/build.sh

log "refresh default arrival bundle"
/app/bin/arrivalpack /app/data/arrival_manifest.jsonl /app/data/arrivals_default.jsonl

log "emit default intake report"
/app/tools/run_intake

log "post-run validation against intake.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/intake.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k in ("min_placement_rate", "max_surplus_ratio", "min_integration_value"):
        cfg[k] = float(v)
    elif k.startswith("max_") or k.startswith("min_") or k == "intake_capacity_seats":
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/intake_report.json").read_text())
assert report["status"] == "ok", report
assert report["placement_rate"] >= cfg["min_placement_rate"]
assert report["surplus_ratio"] <= cfg["max_surplus_ratio"]
assert report["family_violations"] <= cfg["max_family_violations"]
assert report["placement_inversions"] <= cfg["max_placement_inversions"]
assert report["program_deferred"] >= cfg["min_program_deferred"]
assert report["integration_value"] >= cfg["min_integration_value"]
for row in report["arrivals"]:
    if row["arrival_id"].startswith("a_fam_") and row["completed"]:
        assert row["family_ready"], row
    if row["arrival_id"].startswith("a_prog_"):
        assert row["completed"], row
print("ok", report["placement_rate"], report["surplus_ratio"], report["integration_value"])
PY

log "oracle complete"
