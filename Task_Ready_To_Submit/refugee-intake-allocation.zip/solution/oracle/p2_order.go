package r7

import (
	"sort"

	"ria.disp/pkg/types"
)

// PxSeq ranks pending arrivals for intake-aware placement.
func PxSeq(cases []types.ArrivalCase) []types.ArrivalCase {
	out := make([]types.ArrivalCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		a, b := out[i], out[j]
		if a.PriorityRev != b.PriorityRev {
			return a.PriorityRev > b.PriorityRev
		}
		if a.Priority != b.Priority {
			return a.Priority > b.Priority
		}
		if a.IntegrationScore != b.IntegrationScore {
			return a.IntegrationScore > b.IntegrationScore
		}
		return a.ArrivalID < b.ArrivalID
	})
	return out
}
