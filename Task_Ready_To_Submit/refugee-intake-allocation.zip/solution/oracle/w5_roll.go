package w2

// RxGap totals seat reservation surplus for one placement wave.
func RxGap(reserved, used int) int {
	if reserved <= used {
		return 0
	}
	return reserved - used
}
