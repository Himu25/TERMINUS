package unit

// Profile holds per-unit clock and partition marks.
// ClockSkewMS is subtracted from segment gps_ms when comparing rows for ordering.
type Profile struct {
	UnitID    string `json:"unit_id"`
	ClockSkewMS    int64  `json:"clock_skew_ms"`
	RadioHoldMS int64  `json:"radio_hold_ms"`
	StaleMark uint32 `json:"stale_mark"`
}
