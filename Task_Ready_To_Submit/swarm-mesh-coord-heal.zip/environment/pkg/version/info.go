package version

// ToolingTag is stamped into build metadata.
const ToolingTag = "swarm-coord-0.9"
