package offsetfold

import "lab.local/swarm_mesh_coord/radiogate"

// FoldUnitSkew applies optional radio hold smear to the recorded clock skew baseline.
func FoldUnitSkew(skewMS int64, radioHoldMS int64) int64 {
	return radiogate.ApplySmear(skewMS, radioHoldMS)
}
