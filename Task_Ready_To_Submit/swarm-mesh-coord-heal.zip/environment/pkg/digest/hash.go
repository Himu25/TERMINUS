package digest

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
)

// ReportHex matches the pipe-separated digest in cmd/swarm_heal.
func ReportHex(
	packID string,
	formationEpoch, sweepSeq, reconcileCount, gapCount, unitsActive uint32,
	linkBand string,
	sepClean bool,
) string {
	ck := "true"
	if !sepClean {
		ck = "false"
	}
	raw := fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%s|%s",
		packID, formationEpoch, sweepSeq, reconcileCount, gapCount, unitsActive, linkBand, ck,
	)
	sum := sha256.Sum256([]byte(raw))
	return hex.EncodeToString(sum[:])
}
