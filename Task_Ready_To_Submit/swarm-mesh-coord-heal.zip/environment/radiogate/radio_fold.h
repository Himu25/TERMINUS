#pragma once

long long lf_apply_smear(long long base_ms, long long hold_ms);
