package radiogate

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libradiogate.a -ldl -lm
#include "radio_fold.h"
*/
import "C"

// ApplySmear combines unit clock skew with an optional radio hold band.
func ApplySmear(baseMS int64, holdMS int64) int64 {
	return int64(C.lf_apply_smear(C.longlong(baseMS), C.longlong(holdMS)))
}
