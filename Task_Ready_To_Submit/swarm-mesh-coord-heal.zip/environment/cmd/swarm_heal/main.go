// Report JSON for /app/output/coord_report.json:
//
// schema_version — string, must be "1"
// pack_id — string, echoes active pack name
// formation_epoch — highest epoch in the consistent chain
// sweep_seq — highest contiguous sequence included in the chain
// reconcile_count — checksum fixes applied during heal
// gap_count — sweep positions without replica agreement
// units_active — count of units contributing to accepted rows
// link_band — string, "tight" or "wide"
// sep_clean — boolean (not 0/1 strings)
// digest_hex — lowercase hex SHA-256 of pack_id|formation_epoch|sweep_seq|reconcile_count|gap_count|units_active|link_band|sep_clean
//
// Root object contains only these keys.
package main

import (
	"log"
	"os"

	"lab.local/swarm_mesh_coord/internal/driver"
)

func main() {
	if os.Getenv("TB_SWARM_FIXTURE") != "1" {
		log.Fatal("TB_SWARM_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/coord_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
