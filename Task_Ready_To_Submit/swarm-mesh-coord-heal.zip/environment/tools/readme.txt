Operator tools live outside the heal driver; use /app/bin/swarm_heal for pack replay.
Verifier helpers include /tmp/swarm_heal_verify_bin and /app/tools/digest_cli for digest recomputation.
