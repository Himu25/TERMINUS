# Radio hold notes

Units record `clock_skew_ms` from their onboard clock source. During mesh link hold windows,
`radio_hold_ms` smears the effective skew baseline used when comparing beacon timestamps.
