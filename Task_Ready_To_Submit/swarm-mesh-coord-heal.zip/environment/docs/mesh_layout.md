# Swarm layout

Five units (`n1`–`n5`) append sector-claim rows under `/app/data/active/units/`.
Each unit carries `clock_skew_ms`, optional `radio_hold_ms`, and a `stale_mark` watermark in `meta.json`.
