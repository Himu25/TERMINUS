package driver

import (
	"encoding/json"
	"os"
)

// Report is the outward JSON envelope.
type Report struct {
	SchemaVersion string `json:"schema_version"`
	PackID        string `json:"pack_id"`
	FormationEpoch     uint32 `json:"formation_epoch"`
	SweepSeq     uint32 `json:"sweep_seq"`
	ReconcileCount   uint32 `json:"reconcile_count"`
	GapCount     uint32 `json:"gap_count"`
	UnitsActive   uint32 `json:"units_active"`
	LinkBand     string `json:"link_band"`
	SepClean    bool   `json:"sep_clean"`
	DigestHex     string `json:"digest_hex"`
}

// EmitReport writes the heal output document.
func EmitReport(path string, rep Report) error {
	raw, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}
