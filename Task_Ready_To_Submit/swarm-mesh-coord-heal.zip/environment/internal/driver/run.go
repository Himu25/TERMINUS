package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"

	"lab.local/swarm_mesh_coord/internal/config"
	"lab.local/swarm_mesh_coord/internal/engine"
)

// RunActive loads the active pack and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	pack, profiles, rows, offsets, err := config.LoadPack(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(pack.PackID, pack.QSize, pack.SepEpoch, pack.LinkTightMS, profiles, rows, offsets)
	ck := "true"
	if !out.SepClean {
		ck = "false"
	}
	digest := sha256.Sum256([]byte(fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%s|%s",
		pack.PackID,
		out.FormationEpoch,
		out.SweepSeq,
		out.ReconcileCount,
		out.GapCount,
		out.UnitsActive,
		out.LinkBand,
		ck,
	)))
	return Report{
		SchemaVersion: "1",
		PackID:        pack.PackID,
		FormationEpoch:     out.FormationEpoch,
		SweepSeq:     out.SweepSeq,
		ReconcileCount:   out.ReconcileCount,
		GapCount:     out.GapCount,
		UnitsActive:   out.UnitsActive,
		LinkBand:     out.LinkBand,
		SepClean:    out.SepClean,
		DigestHex:     hex.EncodeToString(digest[:]),
	}, nil
}
