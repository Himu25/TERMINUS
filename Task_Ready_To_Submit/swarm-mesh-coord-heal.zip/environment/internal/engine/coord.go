package engine

import (
	"lab.local/swarm_mesh_coord/internal/freeze"
	"lab.local/swarm_mesh_coord/internal/merge"
	"lab.local/swarm_mesh_coord/pkg/frame"
	"lab.local/swarm_mesh_coord/pkg/unit"
)

// Replay executes one pack through freeze and merge stages.
func Replay(
	packID string,
	qSize int,
	sepEpoch uint32,
	linkTight int64,
	profiles []unit.Profile,
	allRows map[uint32][]frame.Row,
	offsets map[string]int64,
) merge.Outcome {
	wm := freeze.Watermark(profiles)
	above := make(map[uint32][]frame.Row)
	for seq, rows := range allRows {
		if seq > uint32(wm) {
			above[seq] = rows
		}
	}
	out := merge.FusePack(uint32(wm), qSize, sepEpoch, linkTight, offsets, above, allRows)
	_ = packID
	return out
}
