module lab.local/swarm_mesh_coord

go 1.22
