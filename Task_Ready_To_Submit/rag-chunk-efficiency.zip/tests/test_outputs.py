"""Validate /app/output/chunk_bench.json against chunk.toml guardrails."""

from __future__ import annotations

import json
import os
import re
import subprocess
from collections.abc import Callable
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "chunk_bench.json"
CFG = APP / "config" / "chunk.toml"
MANIFEST = APP / "registry" / "chunk_manifest.json"
RUNS = APP / "data" / "runs_default.jsonl"
RUN_SPECS = APP / "data" / "run_specs.jsonl"
DIGEST_TABLE = APP / "ref" / "anchors" / "digest_table.json"
PANE_Q1 = "q1_lg.go"
PANE_Q2 = "q2_scan.go"
PANE_Q3 = "q3_win.go"
PANE_Q4 = "q4_pk.go"
LANE_Q5 = "q5_lane.go"
LANE_Q6 = "q6_units.go"
FOLD_LIB = "lib.rs"
FIXTURES = Path(__file__).resolve().parent / "fixtures"

REPORT_KEYS = frozenset(
    {
        "status",
        "corpus_docs",
        "chunk_profile",
        "runs_total",
        "mean_recall_at_k",
        "mean_embedding_count",
        "mean_redundancy_ratio",
        "mean_index_units",
        "intact_block_rate",
        "report_digest",
        "runs",
    }
)
RUN_KEYS = frozenset(
    {
        "run_id",
        "recall_at_k",
        "embedding_count",
        "redundancy_ratio",
        "index_units",
        "intact_blocks",
        "query_hits",
        "chunk_ids",
    }
)

_SUBPROC_ENV = os.environ.copy()
_SUBPROC_ENV["PATH"] = "/usr/local/go/bin:/app/bin:" + _SUBPROC_ENV.get("PATH", "")
_SUBPROC_ENV["LD_LIBRARY_PATH"] = "/app/lib:" + _SUBPROC_ENV.get("LD_LIBRARY_PATH", "")
_BUILD_TIMEOUT = 240
_RUN_TIMEOUT = 120


def _parse_cfg() -> dict:
    cfg: dict = {
        "recall_floor": 0.92,
        "max_mean_embedding_count": 42,
        "max_mean_redundancy_ratio": 0.18,
        "max_mean_index_units": 28000,
        "intact_block_floor": 0.95,
        "structured_recall_floor": 0.90,
        "multilingual_recall_floor": 0.88,
        "chunk_profile": "v3",
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key.endswith("_floor") or key.startswith("max_mean_"):
            cfg[key] = float(val)
        elif key.startswith("max_"):
            cfg[key] = int(float(val))
        elif key == "chunk_profile":
            cfg[key] = val
    return cfg


def _round4(value: float) -> float:
    return round(value * 10000 + 0.5) / 10000


def _digest_body(report: dict) -> str:
    body = dict(report)
    body["report_digest"] = ""
    raw = json.dumps(body, separators=(",", ":"))
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _bench_env(corpus_path: Path | None = None) -> dict[str, str]:
    env = dict(_SUBPROC_ENV)
    if corpus_path is not None:
        env["TB_CORPUS_PATH"] = str(corpus_path)
    else:
        env.pop("TB_CORPUS_PATH", None)
    return env


def _build_all(*, required: bool = True, env: dict[str, str] | None = None) -> None:
    proc = subprocess.run(
        ["bash", "/app/scripts/build_all.sh"],
        cwd=APP,
        capture_output=True,
        text=True,
        timeout=_BUILD_TIMEOUT,
        env=env or _SUBPROC_ENV,
    )
    if proc.returncode != 0:
        if required:
            raise subprocess.CalledProcessError(
                proc.returncode,
                proc.args,
                proc.stdout,
                proc.stderr,
            )


def _run_chunkbench(
    runs_path: Path,
    out_path: Path,
    *,
    corpus_path: Path | None = None,
) -> dict:
    env = _bench_env(corpus_path)
    out_path.unlink(missing_ok=True)
    subprocess.run(
        ["/app/bin/chunkbench", runs_path.as_posix(), out_path.as_posix()],
        cwd=APP,
        check=True,
        capture_output=True,
        text=True,
        timeout=_RUN_TIMEOUT,
        env=env,
    )
    return json.loads(out_path.read_text(encoding="utf-8"))


def _rebuild_and_run(
    runs_path: Path | None = None,
    out_path: Path | None = None,
    corpus_path: Path | None = None,
    *,
    rebuild: bool = True,
) -> dict:
    runs_path = runs_path or RUNS
    out_path = out_path or OUT
    env = _bench_env(corpus_path)
    if rebuild:
        _build_all(env=env)
    return _run_chunkbench(runs_path, out_path, corpus_path=corpus_path)


def _run_rows(report: dict) -> dict[str, dict]:
    return {row["run_id"]: row for row in report["runs"]}


def _load_run_specs() -> dict[str, list[str]]:
    specs: dict[str, list[str]] = {}
    for line in RUN_SPECS.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        obj = json.loads(line)
        specs[obj["run_id"]] = obj["doc_ids"]
    return specs


def _gold_digests_for_run(run_id: str) -> list[str]:
    table = json.loads(DIGEST_TABLE.read_text(encoding="utf-8"))
    specs = _load_run_specs()
    out: list[str] = []
    for doc_id in specs[run_id]:
        out.extend(table.get(doc_id, []))
    return out


def _assert_fixture_pack(pack: str, cfg: dict) -> None:
    corpus = FIXTURES / pack / "corpus.json"
    specs = FIXTURES / pack / "run_specs.jsonl"
    tmp_out = APP / "output" / f"chunk_{pack}.json"
    report = _rebuild_and_run(specs, tmp_out, corpus, rebuild=False)
    assert report["status"] == "ok"
    assert report["mean_recall_at_k"] >= cfg["recall_floor"]
    assert int(report["mean_embedding_count"]) <= cfg["max_mean_embedding_count"]
    assert report["intact_block_rate"] >= cfg["intact_block_floor"]


def _apply_ablation(
    target: Path,
    broken_name: str,
    runner: Callable[[], None],
    extra_targets: list[tuple[Path, str]] | None = None,
) -> None:
    backups: list[tuple[Path, str]] = [(target, target.read_text(encoding="utf-8"))]
    if extra_targets:
        for path, name in extra_targets:
            backups.append((path, path.read_text(encoding="utf-8")))
    broken = (FIXTURES / broken_name).read_text(encoding="utf-8")
    try:
        target.write_text(broken, encoding="utf-8")
        if extra_targets:
            for path, name in extra_targets:
                path.write_text((FIXTURES / name).read_text(encoding="utf-8"), encoding="utf-8")
        runner()
    finally:
        for path, content in backups:
            path.write_text(content, encoding="utf-8")
        _build_all()


@pytest.fixture(scope="session", autouse=True)
def _session_baseline() -> None:
    """Best-effort baseline build so broken agent trees still reach pytest scoring."""
    _build_all(required=False)
    if not OUT.is_file():
        try:
            _run_chunkbench(RUNS, OUT)
        except (OSError, subprocess.CalledProcessError, subprocess.TimeoutExpired):
            pass


@pytest.fixture(scope="module")
def cfg() -> dict:
    return _parse_cfg()


@pytest.fixture(scope="module")
def default_report() -> dict:
    if not OUT.is_file():
        _rebuild_and_run()
    return json.loads(OUT.read_text(encoding="utf-8"))


def test_chunkbench_binary_exists() -> None:
    """The chunkbench driver binary is present after environment build."""
    bench = APP / "bin" / "chunkbench"
    assert bench.is_file() and os.access(bench, os.X_OK)


def test_report_schema_and_digest(default_report: dict) -> None:
    """Top-level schema and report_digest must match compact pre-digest JSON."""
    assert set(default_report.keys()) == REPORT_KEYS
    assert re.fullmatch(r"[0-9a-f]{64}", default_report["report_digest"])
    assert default_report["report_digest"] == _digest_body(default_report)
    for row in default_report["runs"]:
        assert set(row.keys()) == RUN_KEYS


def test_default_pack_quality_floors(default_report: dict, cfg: dict) -> None:
    """Default run pack must meet chunk.toml mean floors and ceilings."""
    assert default_report["status"] == "ok"
    assert default_report["runs_total"] == len(
        [ln for ln in RUNS.read_text(encoding="utf-8").splitlines() if ln.strip()]
    )
    assert default_report["mean_recall_at_k"] >= cfg["recall_floor"]
    assert int(default_report["mean_embedding_count"]) <= cfg["max_mean_embedding_count"]
    assert default_report["mean_redundancy_ratio"] <= cfg["max_mean_redundancy_ratio"]
    assert int(default_report["mean_index_units"]) <= cfg["max_mean_index_units"]
    assert default_report["intact_block_rate"] >= cfg["intact_block_floor"]


def test_summary_means_recomputed_from_run_rows(default_report: dict) -> None:
    """Aggregate means must match the arithmetic mean of per-run rows."""
    rows = default_report["runs"]
    n = len(rows)
    assert n > 0
    assert default_report["mean_recall_at_k"] == _round4(
        sum(r["recall_at_k"] for r in rows) / n
    )
    assert default_report["mean_embedding_count"] == _round4(
        sum(r["embedding_count"] for r in rows) / n
    )
    assert default_report["mean_redundancy_ratio"] == _round4(
        sum(r["redundancy_ratio"] for r in rows) / n
    )
    assert default_report["mean_index_units"] == _round4(
        sum(r["index_units"] for r in rows) / n
    )


def test_recall_hits_consistent_with_gold_table(default_report: dict) -> None:
    """Per-run recall_at_k must align with canonical digest_table gold counts."""
    for row in default_report["runs"]:
        gold = _gold_digests_for_run(row["run_id"])
        if not gold:
            continue
        implied_hits = row["recall_at_k"] * len(gold)
        assert abs(implied_hits - round(implied_hits)) < 1e-3
        assert row["recall_at_k"] <= 1.0
        assert row["query_hits"] == row["embedding_count"]


def test_index_units_minimum_overhead(default_report: dict) -> None:
    """Each emitted chunk contributes at least four index units beyond raw text."""
    for row in default_report["runs"]:
        assert row["index_units"] >= row["embedding_count"] * 4


def test_table_code_run_intact_blocks(default_report: dict, cfg: dict) -> None:
    """r_table_code_fence must preserve fenced and table blocks as intact spans."""
    row = _run_rows(default_report)["r_table_code_fence"]
    assert row["intact_blocks"] >= 2
    assert row["recall_at_k"] >= cfg["structured_recall_floor"]


def test_structured_long_run_recall(default_report: dict, cfg: dict) -> None:
    """r_structured_long must reach structured_recall_floor."""
    row = _run_rows(default_report)["r_structured_long"]
    assert row["recall_at_k"] >= cfg["structured_recall_floor"]


def test_overlap_stress_low_redundancy(default_report: dict, cfg: dict) -> None:
    """r_overlap_stress must keep redundancy_ratio under the configured ceiling."""
    row = _run_rows(default_report)["r_overlap_stress"]
    assert row["redundancy_ratio"] <= cfg["max_mean_redundancy_ratio"]
    assert row["embedding_count"] <= cfg["max_mean_embedding_count"]


def test_per_run_index_units_ceiling(default_report: dict, cfg: dict) -> None:
    """Every run row must stay within max_mean_index_units."""
    for row in default_report["runs"]:
        assert row["index_units"] <= cfg["max_mean_index_units"]


def test_chunk_ids_sorted_per_run(default_report: dict) -> None:
    """chunk_ids within each run must be lexicographically sorted."""
    for row in default_report["runs"]:
        ids = row["chunk_ids"]
        assert ids == sorted(ids)


def test_multilingual_run_embedding_budget(default_report: dict, cfg: dict) -> None:
    """Multilingual blend run must not exceed the mean embedding ceiling."""
    row = _run_rows(default_report)["r_multilingual_blend"]
    assert row["embedding_count"] <= cfg["max_mean_embedding_count"]
    assert row["recall_at_k"] >= cfg["multilingual_recall_floor"]


def test_chunk_profile_matches_manifest(default_report: dict) -> None:
    """chunk_profile in the report must match registry chunk_manifest.json."""
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    assert default_report["chunk_profile"] == manifest["chunk_profile"]


def test_determinism_repeat_run(default_report: dict) -> None:
    """Identical inputs must yield byte-identical chunk_bench.json."""
    first = OUT.read_bytes()
    _rebuild_and_run()
    second = OUT.read_bytes()
    assert first == second


def test_pack_long_structured_regression(cfg: dict) -> None:
    """Hidden long structured corpus must pass recall and embedding ceilings."""
    _assert_fixture_pack("pack_long_structured", cfg)


def test_pack_table_code_regression(cfg: dict) -> None:
    """Hidden table and fenced-code corpus must pass intact block and recall floors."""
    _assert_fixture_pack("pack_table_code", cfg)


def test_pack_multilingual_regression(cfg: dict) -> None:
    """Hidden multilingual corpus must pass recall and embedding ceilings."""
    _assert_fixture_pack("pack_multilingual", cfg)


def test_ablation_q3_inflates_redundancy(cfg: dict, default_report: dict) -> None:
    """Partial q3 window repair must blow redundancy or embedding ceilings."""
    out = APP / "output" / "chunk_ablation_q3.json"
    baseline = _run_rows(default_report)["r_overlap_stress"]["redundancy_ratio"]

    def run() -> None:
        report = _rebuild_and_run(out_path=out)
        row = _run_rows(report)["r_overlap_stress"]
        assert report["status"] == "fail" or row["redundancy_ratio"] > baseline or row[
            "embedding_count"
        ] > _run_rows(default_report)["r_overlap_stress"]["embedding_count"]

    _apply_ablation(
        APP / "pane" / PANE_Q3,
        "broken_q3_win.go",
        run,
        extra_targets=[(APP / "pane" / PANE_Q4, "broken_q4_pk.go")],
    )


def test_ablation_q2_drops_intact_blocks(cfg: dict) -> None:
    """Partial q2 scan repair must collapse intact_block_rate below the floor."""
    out = APP / "output" / "chunk_ablation_q2.json"

    def run() -> None:
        report = _rebuild_and_run(out_path=out)
        assert report["intact_block_rate"] < cfg["intact_block_floor"] or report[
            "status"
        ] == "fail"

    _apply_ablation(APP / "pane" / PANE_Q2, "broken_q2_scan.go", run)


def test_ablation_q5_skips_dedup(cfg: dict, default_report: dict) -> None:
    """Partial q5 lane repair must exceed embedding or redundancy ceilings."""
    out = APP / "output" / "chunk_ablation_q5.json"
    baseline_emb = int(default_report["mean_embedding_count"])

    def run() -> None:
        report = _rebuild_and_run(out_path=out)
        assert report["status"] == "fail" or int(report["mean_embedding_count"]) > baseline_emb

    _apply_ablation(
        APP / "lane" / LANE_Q5,
        "broken_q5_lane.go",
        run,
        extra_targets=[(APP / "pane" / PANE_Q4, "broken_q4_pk.go")],
    )


def test_ablation_q1_fails_multilingual_recall(cfg: dict) -> None:
    """Partial q1 language split repair must drop multilingual recall."""
    out = APP / "output" / "chunk_ablation_q1.json"

    def run() -> None:
        report = _rebuild_and_run(out_path=out)
        row = _run_rows(report)["r_multilingual_blend"]
        assert row["recall_at_k"] < cfg["multilingual_recall_floor"] or report[
            "status"
        ] == "fail"

    _apply_ablation(APP / "pane" / PANE_Q1, "broken_q1_lg.go", run)


def test_ablation_q7_inflates_embeddings(cfg: dict, default_report: dict) -> None:
    """Partial x9fold repair must miss near-duplicate rejection."""
    out = APP / "output" / "chunk_ablation_q7.json"
    target = APP / "x9fold" / "src" / FOLD_LIB
    baseline_emb = _run_rows(default_report)["r_overlap_stress"]["embedding_count"]

    def run() -> None:
        report = _rebuild_and_run(out_path=out)
        row = _run_rows(report)["r_overlap_stress"]
        assert report["status"] == "fail" or row["embedding_count"] > baseline_emb

    _apply_ablation(
        target,
        "broken_q7_fold.rs",
        run,
        extra_targets=[(APP / "pane" / PANE_Q4, "broken_q4_pk.go")],
    )


def test_ablation_q4_splits_tables(cfg: dict) -> None:
    """Partial q4 pk repair must miss intact block floors on table runs."""
    out = APP / "output" / "chunk_ablation_q4.json"

    def run() -> None:
        report = _rebuild_and_run(out_path=out)
        row = _run_rows(report)["r_table_code_fence"]
        assert row["intact_blocks"] < 2 or report["intact_block_rate"] < cfg[
            "intact_block_floor"
        ]

    _apply_ablation(APP / "pane" / PANE_Q4, "broken_q4_pk.go", run)


def test_ablation_q6_inflates_index_units(cfg: dict, default_report: dict) -> None:
    """Partial q6 units repair must exceed index unit ceilings."""
    out = APP / "output" / "chunk_ablation_q6.json"
    baseline_units = int(default_report["mean_index_units"])

    def run() -> None:
        report = _rebuild_and_run(out_path=out)
        assert report["status"] == "fail" or int(report["mean_index_units"]) > baseline_units

    _apply_ablation(APP / "lane" / LANE_Q6, "broken_q6_units.go", run)
