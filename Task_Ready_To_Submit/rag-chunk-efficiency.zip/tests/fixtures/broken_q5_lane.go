package lane

import "chunklab.dev/ragchunk/pane"

func SpFilter(chunks []pane.Chunk) []pane.Chunk {
	return chunks
}
