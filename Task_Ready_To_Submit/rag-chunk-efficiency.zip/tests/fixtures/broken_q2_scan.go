package pane

func BlkScan(body string) []Block {
	_ = body
	return nil
}
