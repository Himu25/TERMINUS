package pane

import "strings"

func LgSplit(body string) []LangSpan {
	lines := strings.Split(body, "\n")
	var spans []LangSpan
	var curLang string
	var buf strings.Builder
	flush := func() {
		if buf.Len() == 0 {
			return
		}
		lang := curLang
		if lang == "" {
			lang = "und"
		}
		spans = append(spans, LangSpan{Lang: lang, Text: buf.String()})
		buf.Reset()
	}
	for _, line := range lines {
		if tag := LgTag(line); tag != "" {
			flush()
			curLang = tag
			continue
		}
		if buf.Len() > 0 {
			buf.WriteByte('\n')
		}
		buf.WriteString(line)
	}
	flush()
	if len(spans) == 0 {
		return []LangSpan{{Lang: "und", Text: body}}
	}
	return spans
}

func LgTag(line string) string {
	line = strings.TrimSpace(line)
	if !strings.HasPrefix(line, "[") || !strings.Contains(line, "]") {
		return ""
	}
	end := strings.Index(line, "]")
	if end <= 1 {
		return ""
	}
	return strings.ToLower(line[1:end])
}
