package lane

/*
#cgo LDFLAGS: -L${SRCDIR}/../../lib -lx9fold
#include <stdint.h>
#include <stdlib.h>
uint64_t sp_fingerprint(const uint8_t* text, size_t len);
*/
import "C"
import (
	"math/bits"
	"unsafe"

	"chunklab.dev/ragchunk/pane"
)

func hamming(a, b uint64) uint32 {
	return uint32(bits.OnesCount64(a ^ b))
}

func SpFilter(chunks []pane.Chunk) []pane.Chunk {
	var fps []uint64
	out := make([]pane.Chunk, 0, len(chunks))
	for _, ch := range chunks {
		fp := fpOf(ch.Text)
		skip := false
		for _, prev := range fps {
			if hamming(fp, prev) <= 3 {
				skip = true
				break
			}
		}
		if skip {
			continue
		}
		fps = append(fps, fp)
		out = append(out, ch)
	}
	return out
}

func fpOf(text string) uint64 {
	if len(text) == 0 {
		return 0
	}
	ptr := (*C.uint8_t)(unsafe.Pointer(unsafe.StringData(text)))
	return uint64(C.sp_fingerprint(ptr, C.size_t(len(text))))
}
