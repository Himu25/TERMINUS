package pane

import "strings"

func BlkScan(body string) []Block {
	var blocks []Block
	lines := strings.Split(body, "\n")
	inFence := false
	var fence strings.Builder
	var table []string
	flushTable := func() {
		if len(table) == 0 {
			return
		}
		blocks = append(blocks, Block{Kind: "table", Text: strings.Join(table, "\n")})
		table = nil
	}
	for _, line := range lines {
		trim := strings.TrimSpace(line)
		if strings.HasPrefix(trim, "```") {
			if inFence {
				fence.WriteString("\n")
				fence.WriteString(line)
				blocks = append(blocks, Block{Kind: "fence", Text: fence.String()})
				fence.Reset()
				inFence = false
				continue
			}
			flushTable()
			inFence = true
			fence.WriteString(line)
			continue
		}
		if inFence {
			if fence.Len() > 0 {
				fence.WriteByte('\n')
			}
			fence.WriteString(line)
			continue
		}
		if strings.Contains(line, "|") {
			table = append(table, line)
			continue
		}
		flushTable()
	}
	flushTable()
	if inFence && fence.Len() > 0 {
		blocks = append(blocks, Block{Kind: "fence", Text: fence.String()})
	}
	return blocks
}
