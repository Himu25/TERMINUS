package pane

import "strings"

func lex_a(text string) []string {
	return strings.Fields(strings.ToLower(text))
}

func op_a(tokens []string, primary int, secondary int) []string {
	if primary <= 0 {
		return nil
	}
	step := secondary
	if step <= 0 {
		step = primary
	}
	out := make([]string, 0)
	for start := 0; start < len(tokens); start += step {
		end := start + primary
		if end > len(tokens) {
			end = len(tokens)
		}
		if start >= end {
			break
		}
		out = append(out, strings.Join(tokens[start:end], " "))
		if end == len(tokens) {
			break
		}
	}
	return out
}

func WinMk(body string, primary int, secondary int) []string {
	return op_a(lex_a(body), primary, secondary)
}
