#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

log "preflight: rag chunk efficiency workspace"
test -f /app/go.mod
test -f /app/config/chunk.toml
test -f /app/data/corpus_default.json
test -f /app/data/run_specs.jsonl
mkdir -p /app/bin /app/lib /app/output

log "survey: guardrails and subsystem layout"
grep -nE 'recall|embedding|redundancy|intact|index_units' \
  /app/config/chunk.toml /app/metrics/guardrails.txt /app/policies/retention.txt 2>/dev/null | head -n 24 || true
wc -l /app/pane/*.go /app/lane/*.go /app/x9fold/src/lib.rs /app/bench/drive.go /app/ref/*.go

log "restore language-aware document spans"
cp "${ROOT_DIR}/oracle/q1_lg.go" /app/pane/q1_lg.go

log "restore block extraction for tables and fenced code"
cp "${ROOT_DIR}/oracle/q2_scan.go" /app/pane/q2_scan.go

log "restore non-overlapping stride windows without tail duplication"
cp "${ROOT_DIR}/oracle/q3_win.go" /app/pane/q3_win.go

log "restore pipeline assembly with atomic structure blocks"
cp "${ROOT_DIR}/oracle/q4_pk.go" /app/pane/q4_pk.go

log "restore simhash fingerprint core and near-duplicate rejection"
cp "${ROOT_DIR}/oracle/x9fold.rs" /app/x9fold/src/lib.rs
cp "${ROOT_DIR}/oracle/q5_lane.go" /app/lane/q5_lane.go

log "restore intact block scoring against structure spans"
cp "${ROOT_DIR}/oracle/q6_units.go" /app/lane/q6_units.go

log "rebuild Rust x9fold shared library and Go bench driver"
bash /app/scripts/build_all.sh

log "run default chunk efficiency bench report"
chmod +x /app/scripts/run_bench.sh
/app/scripts/run_bench.sh /app/data/runs_default.jsonl /app/output/chunk_bench.json

log "post-run validation against chunk.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg = {}
for line in Path("/app/config/chunk.toml").read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = (p.strip() for p in line.split("=", 1))
    if k.endswith("_floor") or k.startswith("max_mean_"):
        cfg[k] = float(v)
    elif k.startswith("max_"):
        cfg[k] = int(float(v))
    else:
        cfg[k] = v

report = json.loads(Path("/app/output/chunk_bench.json").read_text())
assert report["status"] == "ok", report.get("status")
assert report["mean_recall_at_k"] >= cfg["recall_floor"]
assert int(report["mean_embedding_count"]) <= cfg["max_mean_embedding_count"]
assert report["mean_redundancy_ratio"] <= cfg["max_mean_redundancy_ratio"]
assert int(report["mean_index_units"]) <= cfg["max_mean_index_units"]
assert report["intact_block_rate"] >= cfg["intact_block_floor"]
manifest = json.loads(Path("/app/registry/chunk_manifest.json").read_text())
assert report["chunk_profile"] == manifest["chunk_profile"]
print("chunk bench ok", report["mean_recall_at_k"], report["mean_embedding_count"])
PY

log "done"
