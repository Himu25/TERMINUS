package bench

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"

	"chunklab.dev/ragchunk/corpus"
	"chunklab.dev/ragchunk/lane"
	"chunklab.dev/ragchunk/ingest"
	"chunklab.dev/ragchunk/pkg/types"
	"chunklab.dev/ragchunk/ref"
	"chunklab.dev/ragchunk/pane"
)

func Run(cfg types.ChunkCfg, cases []types.RunCase) (types.ChunkReport, error) {
	if override := os.Getenv("TB_CORPUS_PATH"); override != "" {
		cfg.CorpusPath = override
	}
	docs, err := corpus.Load(cfg.CorpusPath)
	if err != nil {
		return types.ChunkReport{}, err
	}
	byID := corpus.ByID(docs)
	report := types.ChunkReport{
		Status:       "ok",
		CorpusDocs:   len(docs),
		ChunkProfile: cfg.ChunkProfile,
		RunsTotal:    len(cases),
	}
	var sumRecall, sumEmb, sumRed, sumUnits float64
	totalBlocks, intactBlocks := 0, 0
	report.Runs = make([]types.RunRow, 0, len(cases))

	for _, rc := range cases {
		var allChunks []pane.Chunk
		var allBlocks []pane.Block
		goldDigests := make([]string, 0)
		for _, docID := range rc.DocIDs {
			doc, ok := byID[docID]
			if !ok {
				continue
			}
			raw := pane.PkBuild(doc.ID, doc.Text, cfg.PrimaryWindow, cfg.SecondaryStride)
			allChunks = append(allChunks, raw...)
			for _, span := range pane.LgSplit(doc.Text) {
				allBlocks = append(allBlocks, pane.BlkScan(span.Text)...)
			}
			goldDigests = append(goldDigests, ref.GoldChunks(doc.ID, doc.Text, cfg.PrimaryWindow, cfg.SecondaryStride)...)
		}
		sparse := lane.SpFilter(allChunks)
		produced := make([]string, 0, len(sparse))
		chunkIDs := make([]string, 0, len(sparse))
		for _, ch := range sparse {
			dg := ref.DgFold(ch.Text)
			produced = append(produced, dg)
			chunkIDs = append(chunkIDs, ch.ID)
		}
		sort.Strings(chunkIDs)
		recall := ref.RecallAtK(goldDigests, produced, len(produced))
		red := pane.PkOverlapRatio(allChunks)
		units := lane.RegUnits(sparse)
		intact := lane.RegIntact(sparse, allBlocks)
		totalBlocks += len(allBlocks)
		intactBlocks += intact
		row := types.RunRow{
			RunID:           rc.RunID,
			RecallAtK:       round4(recall),
			EmbeddingCount:  len(sparse),
			RedundancyRatio: round4(red),
			IndexUnits:      units,
			IntactBlocks:    intact,
			QueryHits:       len(produced),
			ChunkIDs:        chunkIDs,
		}
		report.Runs = append(report.Runs, row)
		sumRecall += row.RecallAtK
		sumEmb += float64(row.EmbeddingCount)
		sumRed += row.RedundancyRatio
		sumUnits += float64(row.IndexUnits)
	}
	n := float64(len(cases))
	if n > 0 {
		report.MeanRecallAtK = round4(sumRecall / n)
		report.MeanEmbeddingCount = round4(sumEmb / n)
		report.MeanRedundancyRatio = round4(sumRed / n)
		report.MeanIndexUnits = round4(sumUnits / n)
	}
	switch {
	case totalBlocks == 0:
		report.IntactBlockRate = 1
	default:
		report.IntactBlockRate = round4(float64(intactBlocks) / float64(totalBlocks))
	}
	sort.Slice(report.Runs, func(i, j int) bool {
		return report.Runs[i].RunID < report.Runs[j].RunID
	})
	if report.MeanRecallAtK < cfg.RecallFloor ||
		int(report.MeanEmbeddingCount) > cfg.MaxMeanEmbeddingCount ||
		report.MeanRedundancyRatio > cfg.MaxMeanRedundancyRatio ||
		int(report.MeanIndexUnits) > cfg.MaxMeanIndexUnits ||
		report.IntactBlockRate < cfg.IntactBlockFloor {
		report.Status = "fail"
	}
	report.ReportDigest = digestReport(report)
	return report, nil
}

func digestReport(report types.ChunkReport) string {
	body := report
	body.ReportDigest = ""
	raw, _ := json.Marshal(body)
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func WriteReport(path string, report types.ChunkReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

func LoadCfgAndRuns(cfgPath, runsPath string) (types.ChunkCfg, []types.RunCase, error) {
	cfg, err := ingest.LoadCfg(cfgPath)
	if err != nil {
		return cfg, nil, err
	}
	cases, err := ingest.LoadRuns(runsPath)
	if err != nil {
		return cfg, nil, err
	}
	return cfg, cases, nil
}

func SortRuns(runs []types.RunRow) {
	sort.Slice(runs, func(i, j int) bool {
		return runs[i].RunID < runs[j].RunID
	})
}

func FormatRun(id string) string {
	return fmt.Sprintf("run-%s", id)
}
