package pane

import "strings"

func BlkIntact(kind string, chunk string) bool {
	if kind == "fence" {
		return strings.Contains(chunk, "```")
	}
	if kind == "table" {
		return strings.Contains(chunk, "|") && strings.Contains(chunk, "---")
	}
	return true
}
