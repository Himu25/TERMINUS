package pane

import "strings"

func LgSplit(body string) []LangSpan {
	lines := strings.Split(body, "\n")
	var spans []LangSpan
	var tag string
	var buf []string
	flush := func() {
		if len(buf) == 0 {
			return
		}
		lang := tag
		if lang == "" {
			lang = "und"
		}
		spans = append(spans, LangSpan{Lang: lang, Text: strings.Join(buf, "\n")})
		buf = nil
	}
	for _, line := range lines {
		if t := LgTag(line); t != "" {
			flush()
			tag = t
			buf = append(buf, line)
			continue
		}
		buf = append(buf, line)
	}
	flush()
	if len(spans) == 0 {
		return []LangSpan{{Lang: "und", Text: body}}
	}
	return spans
}

func LgTag(line string) string {
	line = strings.TrimSpace(line)
	if !strings.HasPrefix(line, "[") || !strings.Contains(line, "]") {
		return ""
	}
	end := strings.Index(line, "]")
	if end <= 1 {
		return ""
	}
	return strings.ToLower(line[1:end])
}
