package pane

import "strings"

func CutlineAux(body string, width int, hop int) []string {
	if width <= 0 {
		return nil
	}
	if hop <= 0 {
		hop = width
	}
	tokens := strings.Fields(strings.ToLower(body))
	out := make([]string, 0)
	for start := 0; start < len(tokens); start += hop {
		end := start + width
		if end > len(tokens) {
			end = len(tokens)
		}
		if start >= end {
			break
		}
		out = append(out, strings.Join(tokens[start:end], " "))
	}
	return out
}
