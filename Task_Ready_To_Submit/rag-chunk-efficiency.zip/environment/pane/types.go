package pane

type Block struct {
	Kind string
	Text string
}

type LangSpan struct {
	Lang string
	Text string
}

type Chunk struct {
	ID   string
	Text string
	Kind string
}
