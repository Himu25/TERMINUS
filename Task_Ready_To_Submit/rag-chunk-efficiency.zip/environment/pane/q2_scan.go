package pane

import (
	"regexp"
	"strings"
)

var tableRowRe = regexp.MustCompile(`\|`)

func BlkScan(body string) []Block {
	lines := strings.Split(body, "\n")
	var blocks []Block
	var prose []string
	inFence := false
	var fenceLines []string

	emitProse := func() {
		if len(prose) == 0 {
			return
		}
		blocks = append(blocks, Block{Kind: "prose", Text: strings.Join(prose, "\n")})
		prose = nil
	}

	for _, line := range lines {
		trim := strings.TrimSpace(line)
		if strings.HasPrefix(trim, "```") {
			emitProse()
			if inFence {
				fenceLines = append(fenceLines, line)
				blocks = append(blocks, Block{Kind: "fence", Text: strings.Join(fenceLines, "\n")})
				fenceLines = nil
				inFence = false
				continue
			}
			inFence = true
			fenceLines = []string{line}
			continue
		}
		if inFence {
			fenceLines = append(fenceLines, line)
			continue
		}
		if tableRowRe.MatchString(line) {
			emitProse()
			blocks = append(blocks, Block{Kind: "table", Text: line})
			continue
		}
		prose = append(prose, line)
	}
	emitProse()
	if inFence && len(fenceLines) > 0 {
		blocks = append(blocks, Block{Kind: "fence", Text: strings.Join(fenceLines, "\n")})
	}
	return blocks
}
