package pane

import "strings"

func lex_a(text string) []string {
	return strings.Fields(strings.ToLower(text))
}

func op_a(tokens []string, primary int, secondary int) []string {
	if primary <= 0 {
		return nil
	}
	step := secondary
	if step <= 0 || step > primary {
		step = primary / 2
	}
	if step <= 0 {
		step = 1
	}
	out := make([]string, 0)
	for start := 0; start < len(tokens); start += step {
		end := start + primary
		if end > len(tokens) {
			end = len(tokens)
		}
		if start >= end {
			break
		}
		chunk := strings.Join(tokens[start:end], " ")
		out = append(out, chunk)
		if end == len(tokens) {
			out = append(out, chunk)
			break
		}
	}
	return out
}

func WinMk(body string, primary int, secondary int) []string {
	return op_a(lex_a(body), primary, secondary)
}
