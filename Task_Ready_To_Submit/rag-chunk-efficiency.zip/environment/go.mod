module chunklab.dev/ragchunk

go 1.22
