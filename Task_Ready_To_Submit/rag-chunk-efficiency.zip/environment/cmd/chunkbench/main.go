package main

import (
	"fmt"
	"os"

	"chunklab.dev/ragchunk/bench"
)

func main() {
	if len(os.Args) != 3 {
		fmt.Fprintf(os.Stderr, "usage: chunkbench <runs.jsonl> <out.json>\n")
		os.Exit(2)
	}
	cfg, cases, err := bench.LoadCfgAndRuns("/app/config/chunk.toml", os.Args[1])
	if err != nil {
		fmt.Fprintf(os.Stderr, "load: %v\n", err)
		os.Exit(1)
	}
	report, err := bench.Run(cfg, cases)
	if err != nil {
		fmt.Fprintf(os.Stderr, "run: %v\n", err)
		os.Exit(1)
	}
	if err := bench.WriteReport(os.Args[2], report); err != nil {
		fmt.Fprintf(os.Stderr, "write: %v\n", err)
		os.Exit(1)
	}
}
