use std::collections::hash_map::DefaultHasher;
use std::hash::{Hash, Hasher};

const VEC_WIDTH: usize = 32;

fn tokenize(text: &str) -> Vec<String> {
    text.split_whitespace()
        .map(|t| t.to_lowercase())
        .collect()
}

fn fold_token(tok: &str) -> u64 {
    let mut hasher = DefaultHasher::new();
    tok.hash(&mut hasher);
    hasher.finish()
}

fn simhash64(text: &str) -> u64 {
    let tokens = tokenize(text);
    if tokens.is_empty() {
        return 0;
    }
    let mut acc = [0i32; VEC_WIDTH];
    for tok in tokens {
        let h = fold_token(&tok);
        for bit in 0..VEC_WIDTH {
            if (h >> bit) & 1 == 1 {
                acc[bit] += 1;
            } else {
                acc[bit] -= 1;
            }
        }
    }
    let mut out = 0u64;
    for bit in 0..VEC_WIDTH {
        if acc[bit] > 0 {
            out |= 1u64 << bit;
        }
    }
    out
}

#[no_mangle]
pub extern "C" fn sp_fingerprint(text: *const u8, len: usize) -> u64 {
    if text.is_null() || len == 0 {
        return 0;
    }
    let slice = unsafe { std::slice::from_raw_parts(text, len) };
    let s = String::from_utf8_lossy(slice);
    simhash64(&s)
}

#[no_mangle]
pub extern "C" fn sp_should_keep(_fp: u64, seen_count: u32) -> u8 {
    if seen_count > 0 {
        0
    } else {
        1
    }
}
