package ingest

import (
	"bufio"
	"encoding/json"
	"os"
	"strconv"
	"strings"

	"chunklab.dev/ragchunk/pkg/types"
)

func LoadCfg(path string) (types.ChunkCfg, error) {
	cfg := types.ChunkCfg{
		CorpusPath:              "/app/data/corpus_default.json",
		WorkerCount:             4,
		ChunkProfile:            "v3",
		PrimaryWindow:           48,
		SecondaryStride:         40,
		RecallFloor:             0.92,
		MaxMeanEmbeddingCount:   42,
		MaxMeanRedundancyRatio:  0.18,
		MaxMeanIndexUnits:       28000,
		IntactBlockFloor:        0.95,
		StructuredRecallFloor:   0.90,
		MultilingualRecallFloor: 0.88,
	}
	f, err := os.Open(path)
	if err != nil {
		return cfg, err
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		parts := strings.SplitN(line, "=", 2)
		if len(parts) != 2 {
			continue
		}
		key := strings.TrimSpace(parts[0])
		val := strings.TrimSpace(parts[1])
		switch key {
		case "corpus_path":
			cfg.CorpusPath = val
		case "chunk_profile":
			cfg.ChunkProfile = val
		case "worker_count", "primary_window", "secondary_stride",
			"max_mean_embedding_count", "max_mean_index_units":
			n, _ := strconv.Atoi(val)
			switch key {
			case "worker_count":
				cfg.WorkerCount = n
			case "primary_window":
				cfg.PrimaryWindow = n
			case "secondary_stride":
				cfg.SecondaryStride = n
			case "max_mean_embedding_count":
				cfg.MaxMeanEmbeddingCount = n
			case "max_mean_index_units":
				cfg.MaxMeanIndexUnits = n
			}
		case "recall_floor", "max_mean_redundancy_ratio", "intact_block_floor",
			"structured_recall_floor", "multilingual_recall_floor":
			fv, _ := strconv.ParseFloat(val, 64)
			switch key {
			case "recall_floor":
				cfg.RecallFloor = fv
			case "max_mean_redundancy_ratio":
				cfg.MaxMeanRedundancyRatio = fv
			case "intact_block_floor":
				cfg.IntactBlockFloor = fv
			case "structured_recall_floor":
				cfg.StructuredRecallFloor = fv
			case "multilingual_recall_floor":
				cfg.MultilingualRecallFloor = fv
			}
		}
	}
	return cfg, sc.Err()
}

func LoadRuns(path string) ([]types.RunCase, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var out []types.RunCase
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		var rc types.RunCase
		if err := jsonUnmarshal(line, &rc); err != nil {
			return nil, err
		}
		out = append(out, rc)
	}
	return out, nil
}

func jsonUnmarshal(line string, rc *types.RunCase) error {
	return json.Unmarshal([]byte(line), rc)
}
