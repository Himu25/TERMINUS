# Architecture notes

Corpus JSON lives at `/app/data/corpus_default.json`. Run packs are JSONL with run_id and doc_ids. The Go driver `/app/bin/chunkbench` loads `/app/config/chunk.toml`, segments documents through `/app/pane` (`q1_lg.go`, `q2_scan.go`, `q3_win.go`, `q4_pk.go`), deduplicates via `/app/lane/q5_lane.go` and the Rust helper at `/app/x9fold/src/lib.rs`, tallies units with `/app/lane/q6_units.go`, and writes `/app/output/chunk_bench.json`. Rebuild with `/app/scripts/build_all.sh` and run `/app/scripts/run_bench.sh`. Verifier auxiliary reports use names like `chunk_ablation_q1.json`, `chunk_ablation_q2.json`, `chunk_ablation_q3.json`, `chunk_ablation_q4.json`, `chunk_ablation_q5.json`, `chunk_ablation_q6.json`, and `chunk_ablation_q7.json` under `/app/output/`. Ablation sources under the verifier fixtures tree include `broken_q1_lg.go`, `broken_q2_scan.go`, `broken_q3_win.go`, `broken_q4_pk.go`, `broken_q5_lane.go`, `broken_q6_units.go`, and `broken_q7_fold.rs`.

Top-level report keys: status, corpus_docs, chunk_profile, runs_total, mean_recall_at_k, mean_embedding_count, mean_redundancy_ratio, mean_index_units, intact_block_rate, report_digest, runs.

Each runs row: run_id, recall_at_k, embedding_count, redundancy_ratio, index_units, intact_blocks, query_hits, chunk_ids. query_hits equals embedding_count on every row; both count chunks emitted after x9fold dedup. recall_at_k is the fraction of canonical reference chunk digests recovered in the indexed chunk set. Reference digests are keyed by document id in `/app/ref/anchors/digest_table.json`. Unit fields are synthetic cost tallies, not wall-clock timings.

Digest covers every report field except report_digest, serialized as compact JSON with report_digest set to an empty string. chunkbench computes the digest from that payload before writing the indented report file.

redundancy_ratio measures duplicate normalized chunk bodies before x9fold dedup. intact_blocks counts structure blocks (fenced code or markdown tables) whose full text appears in a single emitted chunk. index_units sums utf8 rune counts across emitted chunks plus four overhead units per chunk after dedup. Quality gates compare means against floors and ceilings in chunk.toml.

Regenerate the default run pack with `/app/bin/refgen` after corpus edits. Verifier fixture benches may override corpus via TB_CORPUS_PATH and may write auxiliary reports under `/app/output/`. Verifier rebuilds prepend `/usr/local/go/bin:/app/bin:` to PATH.

Ablation runs swap one pane, lane, or fold source at a time for a broken variant from the verifier fixtures tree. Exported symbols in the replaced module must remain defined and linkable from unchanged callers so `/app/scripts/build_all.sh` still completes.
