Workspace root is /app. Build outputs land under /app/output.
