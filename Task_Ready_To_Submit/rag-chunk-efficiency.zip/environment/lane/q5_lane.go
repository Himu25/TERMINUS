package lane

/*
#cgo LDFLAGS: -L${SRCDIR}/../../lib -lx9fold
#include <stdint.h>
#include <stdlib.h>
uint64_t sp_fingerprint(const uint8_t* text, size_t len);
*/
import "C"
import (
	"unsafe"

	"chunklab.dev/ragchunk/pane"
)

func SpFilter(chunks []pane.Chunk) []pane.Chunk {
	var fps []uint64
	out := make([]pane.Chunk, 0, len(chunks))
	for _, ch := range chunks {
		fp := fpOf(ch.Text)
		dup := false
		for _, prev := range fps {
			if bitDiff(fp, prev) <= 6 {
				dup = true
				break
			}
		}
		if dup {
			continue
		}
		fps = append(fps, fp)
		out = append(out, ch)
	}
	return out
}

func bitDiff(a, b uint64) int {
	x := a ^ b
	n := 0
	for x != 0 {
		n += int(x & 1)
		x >>= 1
	}
	return n
}

func fpOf(text string) uint64 {
	if len(text) == 0 {
		return 0
	}
	ptr := (*C.uint8_t)(unsafe.Pointer(unsafe.StringData(text)))
	return uint64(C.sp_fingerprint(ptr, C.size_t(len(text))))
}
