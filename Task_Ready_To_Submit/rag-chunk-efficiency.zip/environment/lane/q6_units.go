package lane

import (
	"strings"
	"unicode/utf8"

	"chunklab.dev/ragchunk/pane"
)

func RegUnits(chunks []pane.Chunk) int {
	total := 0
	for _, ch := range chunks {
		total += utf8.RuneCountInString(ch.Text)
		total += 8
	}
	return total
}

func RegIntact(chunks []pane.Chunk, blocks []pane.Block) int {
	if len(blocks) == 0 {
		return 0
	}
	intact := 0
	for _, blk := range blocks {
		needle := strings.TrimSpace(blk.Text)
		if len(needle) > 32 {
			needle = needle[len(needle)-32:]
		}
		for _, ch := range chunks {
			if pane.BlkIntact(blk.Kind, ch.Text) && strings.Contains(ch.Text, needle) {
				intact++
				break
			}
		}
	}
	return intact
}
