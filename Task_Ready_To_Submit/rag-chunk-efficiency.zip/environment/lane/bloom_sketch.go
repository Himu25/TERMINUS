package lane

import "chunklab.dev/ragchunk/pane"

func BloomSketch(chunks []pane.Chunk) []pane.Chunk {
	seen := make(map[string]struct{}, len(chunks))
	out := make([]pane.Chunk, 0, len(chunks))
	for _, ch := range chunks {
		key := ch.Text
		if _, ok := seen[key]; ok {
			continue
		}
		seen[key] = struct{}{}
		out = append(out, ch)
	}
	return out
}
