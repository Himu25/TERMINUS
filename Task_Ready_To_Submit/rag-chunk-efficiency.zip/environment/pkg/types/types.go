package types

type ChunkCfg struct {
	CorpusPath              string
	WorkerCount             int
	ChunkProfile            string
	PrimaryWindow           int
	SecondaryStride         int
	RecallFloor             float64
	MaxMeanEmbeddingCount   int
	MaxMeanRedundancyRatio  float64
	MaxMeanIndexUnits       int
	IntactBlockFloor        float64
	StructuredRecallFloor   float64
	MultilingualRecallFloor float64
}

type Doc struct {
	ID   string `json:"id"`
	Text string `json:"text"`
	Lang string `json:"lang"`
}

type RunCase struct {
	RunID  string   `json:"run_id"`
	DocIDs []string `json:"doc_ids"`
}

type RunRow struct {
	RunID            string   `json:"run_id"`
	RecallAtK        float64  `json:"recall_at_k"`
	EmbeddingCount   int      `json:"embedding_count"`
	RedundancyRatio  float64  `json:"redundancy_ratio"`
	IndexUnits       int      `json:"index_units"`
	IntactBlocks     int      `json:"intact_blocks"`
	QueryHits        int      `json:"query_hits"`
	ChunkIDs         []string `json:"chunk_ids"`
}

type ChunkReport struct {
	Status               string   `json:"status"`
	CorpusDocs           int      `json:"corpus_docs"`
	ChunkProfile         string   `json:"chunk_profile"`
	RunsTotal            int      `json:"runs_total"`
	MeanRecallAtK        float64  `json:"mean_recall_at_k"`
	MeanEmbeddingCount   float64  `json:"mean_embedding_count"`
	MeanRedundancyRatio  float64  `json:"mean_redundancy_ratio"`
	MeanIndexUnits       float64  `json:"mean_index_units"`
	IntactBlockRate      float64  `json:"intact_block_rate"`
	ReportDigest         string   `json:"report_digest"`
	Runs                 []RunRow `json:"runs"`
}
