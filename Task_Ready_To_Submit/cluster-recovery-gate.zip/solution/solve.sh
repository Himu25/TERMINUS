#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
app_root="/app"
sheet_u="$app_root/zq/u.props"
sheet_v="$app_root/x9/v.props"
sheet_k="$app_root/y2/k.props"

log() {
  printf '[oracle] %s\n' "$1"
}

require_file() {
  local p="$1"
  if [[ ! -f "$p" ]]; then
    log "missing required file: $p"
    exit 1
  fi
}

require_key() {
  local file="$1" key="$2"
  if ! awk -F= -v k="$key" '$1==k{found=1} END{exit (found+0)?0:1}' "$file"; then
    log "missing key $key in $file"
    exit 1
  fi
}

verify_u_sheet() {
  require_key "$sheet_u" north_host
  require_key "$sheet_u" path_prefix
  require_key "$sheet_u" cohort_ready
  require_key "$sheet_u" cohort_total
}

verify_v_sheet() {
  require_key "$sheet_v" vault_epoch
  require_key "$sheet_v" vault_deadline
}

verify_k_sheet() {
  require_key "$sheet_k" milli_request
  require_key "$sheet_k" milli_limit
  require_key "$sheet_k" buddy_must_zero
  require_key "$sheet_k" actual_exit
}

sync_layer_zero() {
  cat >"$sheet_u" <<'EOF'
# cohort routing for the north storefront slice
# cohort_ready should reach cohort_total before idle rollup
north_host=store.lab.local
path_prefix=/api
cohort_ready=2
cohort_total=2
slice_tag=north-storefront
export_rev=14
rollout_lane=primary
cohort_lane=storefront
audit_tag=lab-north
EOF
}

sync_layer_one() {
  cat >"$sheet_v" <<'EOF'
# vault window instants (UTC ISO-8601)
# notAfter must be on or after notBefore for window validity
vault_epoch=2026-05-10T00:00:00Z
vault_deadline=2026-05-20T00:00:00Z
window_kind=rolling
retention_class=hot
audit_lane=primary
EOF
}

sync_layer_two() {
  cat >"$sheet_k" <<'EOF'
# millicore slice and companion exit policy
# milli_request must stay at or under milli_limit for low-pressure label
milli_request=100
milli_limit=500
buddy_must_zero=1
actual_exit=0
pressure_lane=storefront
quota_class=standard
burst_ceiling=900
EOF
}

rebuild_emitter() {
  local list
  list="$(mktemp)"
  find "$app_root/alpha" "$app_root/beta" "$app_root/gamma" "$app_root/delta" -name '*.java' | LC_ALL=C sort >"$list"
  javac -encoding UTF-8 -d "$app_root/out" @"$list"
  rm -f "$list"
}

emit_gate_report() {
  java -cp "$app_root/out" delta.run.M0 "$app_root/output/gate_report.json"
}

assert_digest() {
  local want="0a7e3dba"
  local got
  got="$(jq -r '.ledger_digest' "$app_root/output/gate_report.json")"
  if [[ "$got" != "$want" ]]; then
    log "digest mismatch want=$want got=$got"
    exit 1
  fi
}

assert_gate_shape() {
  jq -e '
    (. | keys | sort) == ["buddy_lane","fault_mode","health_tier","ledger_digest","pressure_flag","vault_state"]
    and .health_tier == "ok"
    and .fault_mode == "idle"
    and .vault_state == "fresh"
    and .buddy_lane == "up"
    and .pressure_flag == "relaxed"
  ' "$app_root/output/gate_report.json" >/dev/null
}

assert_cohort_rollout() {
  local ready total
  ready="$(awk -F= '$1=="cohort_ready"{print $2}' "$sheet_u")"
  total="$(awk -F= '$1=="cohort_total"{print $2}' "$sheet_u")"
  if [[ -z "$ready" || -z "$total" ]]; then
    log "cohort fields missing"
    exit 1
  fi
  if [[ "$ready" -lt "$total" || "$total" -lt 2 ]]; then
    log "cohort props inconsistent ready=$ready total=$total"
    exit 1
  fi
}

assert_ledger_size() {
  local sz
  sz="$(wc -c <"$app_root/vault/ledger.dat" | tr -d ' ')"
  if [[ "$sz" != "21" ]]; then
    log "unexpected ledger size: $sz"
    exit 1
  fi
}

main() {
  log "preflight paths"
  require_file "$sheet_u"
  require_file "$sheet_v"
  require_file "$sheet_k"
  require_file "$SCRIPT_DIR/recovery.patch"
  require_file "$app_root/vault/ledger.dat"

  log "apply reconciliation patch"
  cd "$SCRIPT_DIR"
  patch -d /app -p0 <recovery.patch

  log "write sheet overlays"
  sync_layer_zero
  sync_layer_one
  sync_layer_two

  log "verify sheet keys before compile"
  verify_u_sheet
  verify_v_sheet
  verify_k_sheet

  log "rebuild java emitters"
  rebuild_emitter

  log "smoke compile classpath"
  [[ -d "$app_root/out" ]]

  log "emit gate report"
  mkdir -p "$app_root/output"
  emit_gate_report

  log "verify ledger fingerprint"
  assert_digest

  log "spot-check json keys and nominal labels"
  assert_gate_shape

  log "verify cohort props align with fault readout"
  assert_cohort_rollout

  log "vault ledger untouched length"
  assert_ledger_size

  log "done"
}

main "$@"
