# shell profile fragment used by local harness scripts
TB_LAYER_ROOT=/app/zq
TB_VAULT_ROOT=/app/vault
TB_OUT=/app/output
TB_SHEET_U=/app/zq/u.props
TB_SHEET_V=/app/x9/v.props
TB_SHEET_K=/app/y2/k.props
TB_CLASS_ROOT=/app/out
TB_MAIN_CLASS=delta.run.M0
# verifier probe path /app/output/.gate_readback.json
# After classes land under TB_CLASS_ROOT, emit gate json at TB_OUT/gate_report.json:
#   java -cp /app/out delta.run.M0 /app/output/gate_report.json
