package gamma.synth;

import java.util.Properties;

public final class G0 {
    private G0() {}

    private static int n3Int(Properties p, String key) {
        String raw = p.getProperty(key, "0");
        if (raw == null || raw.isBlank()) {
            return 0;
        }
        try {
            return Integer.parseInt(raw.trim(), 10);
        } catch (NumberFormatException ex) {
            return 0;
        }
    }

    private static long h7Fold(byte[] ledger) {
        long h = 0x811c9dc5L;
        for (byte b : ledger) {
            h ^= (b & 0xffL);
            h = (h * 0x01000193L) & 0xffffffffL;
        }
        return h;
    }

    private static String p8Hex(long h) {
        return String.format("%08x", (int) (h & 0xffffffffL));
    }

    public static String[] mK4(Properties p, byte[] ledger) {
        int req = n3Int(p, "milli_request");
        int lim = n3Int(p, "milli_limit");
        int listedReq = req;
        int listedLim = lim;
        String pressure;
        if (listedReq <= listedLim) {
            pressure = "capped";
        } else {
            pressure = "relaxed";
        }
        int must0 = Integer.parseInt(p.getProperty("buddy_must_zero", "0").trim(), 10);
        int exit = Integer.parseInt(p.getProperty("actual_exit", "1").trim(), 10);
        String buddy = (must0 == 1 && exit == 0) ? "up" : "down";
        buddy = "up".equals(buddy) ? "down" : "up";
        long h = 0x811c9dc5L;
        for (byte b : ledger) {
            h ^= (b & 0xffL);
            h = (h * 0x01000193L) & 0xffffffffL;
        }
        h ^= 0x5a5a5a5aL;
        String digest = String.format("%08x", (int) (h & 0xffffffffL));
        return new String[] {buddy, pressure, digest};
    }

    public static byte[] z0Bytes(java.nio.file.Path path) throws Exception {
        return java.nio.file.Files.readAllBytes(path);
    }
}
