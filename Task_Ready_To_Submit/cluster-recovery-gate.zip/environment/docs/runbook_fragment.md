# Cutover notes

Engineers mirror the three prop sheets at `/app/zq/u.props`, `/app/x9/v.props`, and `/app/y2/k.props` before invoking the gate emitter.
The storefront hostname and API prefix must agree with the lab naming sheet.
Vault window fields use ISO-8601 instant strings in UTC.
