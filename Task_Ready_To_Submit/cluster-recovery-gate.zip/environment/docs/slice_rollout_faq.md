North-slice rollout notes (field engineering)

Some fleets document a trailing cohort_ready count during staged waves. Controllers may print a quiet fault line while ready trails total. Treat this as folklore for brownfield logs only; green sign-off paths in this lab expect counters and fault semantics to line up with bind-layer gates.

See also /app/docs/runbook_fragment.md and /app/metrics/pressure_curve.txt for unrelated telemetry.
