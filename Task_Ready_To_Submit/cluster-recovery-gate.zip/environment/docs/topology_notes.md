# Topology sketch

North edge terminates TLS at the shared listener. Companion processes should
exit zero when the policy demands a quiet lane. Millicore request must stay
under the declared ceiling for the relaxed pressure label.
