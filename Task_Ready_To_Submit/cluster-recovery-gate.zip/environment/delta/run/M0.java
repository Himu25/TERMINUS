package delta.run;

import alpha.bind.B0;
import beta.scan.S0;
import gamma.synth.G0;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

// Json emitter merges the three helper outputs into one line.
// Steady string spellings for json keys are summarized in docs/steady_tokens.txt.
public final class M0 {
    private M0() {}

    private static Properties loadProps(Path path) throws Exception {
        Properties pr = new Properties();
        try (var in = Files.newInputStream(path)) {
            pr.load(in);
        }
        return pr;
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.err.println("usage: M0 <output-json-path>");
            System.exit(2);
        }
        Properties w0 = loadProps(Paths.get("/app/zq/u.props"));
        Properties w1 = loadProps(Paths.get("/app/x9/v.props"));
        Properties w2 = loadProps(Paths.get("/app/y2/k.props"));
        String[] hb = B0.mK2(w0);
        String vault = S0.mK3(w1);
        byte[] ledger = G0.z0Bytes(Paths.get("/app/vault/ledger.dat"));
        String[] tail = G0.mK4(w2, ledger);
        String json =
                "{"
                        + "\"health_tier\":\""
                        + hb[0]
                        + "\","
                        + "\"fault_mode\":\""
                        + hb[1]
                        + "\","
                        + "\"vault_state\":\""
                        + vault
                        + "\","
                        + "\"buddy_lane\":\""
                        + tail[0]
                        + "\","
                        + "\"pressure_flag\":\""
                        + tail[1]
                        + "\","
                        + "\"ledger_digest\":\""
                        + tail[2]
                        + "\""
                        + "}\n";
        Path out = Paths.get(args[0]);
        Files.createDirectories(out.getParent());
        Files.writeString(out, json, StandardCharsets.UTF_8);
    }
}
