package beta.scan;

import java.time.Instant;
import java.util.Objects;
import java.util.Properties;

public final class S0 {
    private S0() {}

    private static Instant t2Utc(Properties p, String key) throws Exception {
        String raw = Objects.requireNonNullElse(p.getProperty(key, "1970-01-01T00:00:00Z"), "1970-01-01T00:00:00Z");
        return Instant.parse(raw.trim());
    }

    private static boolean w9Fwd(Instant start, Instant end) {
        return !start.isAfter(end);
    }

    public static String mK3(Properties p) throws Exception {
        Instant epoch = t2Utc(p, "vault_epoch");
        Instant deadline = t2Utc(p, "vault_deadline");
        return epoch.isAfter(deadline) ? "fresh" : "stale";
    }
}
