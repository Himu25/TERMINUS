package alpha.bind;

import java.util.Properties;

public final class B0 {
    private B0() {}

    private static int n3Int(Properties p, String key) {
        String raw = p.getProperty(key, "0");
        if (raw == null || raw.isBlank()) {
            return 0;
        }
        try {
            return Integer.parseInt(raw.trim(), 10);
        } catch (NumberFormatException ex) {
            return 0;
        }
    }

    private static String s1Trim(Properties p, String key) {
        String raw = p.getProperty(key, "");
        return raw == null ? "" : raw.trim();
    }

    public static String[] mK2(Properties p) {
        String host = s1Trim(p, "north_host");
        String prefix = s1Trim(p, "path_prefix");
        int ready = n3Int(p, "cohort_ready");
        int total = n3Int(p, "cohort_total");
        String health = ("store.lab.local".equals(host) && "/api".equals(prefix)) ? "ok" : "down";
        String fault = (ready > 0 && total > 0) ? "idle" : "storm";
        return new String[] {health, fault};
    }
}
