package epsilon.aux;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Unused probe helper retained from an abandoned slice-router experiment.
 * Build graphs omit this package; it is not referenced by the storefront emitter.
 */
public final class T0 {
    private T0() {}

    public static String q7(Path ledger) throws Exception {
        byte[] raw = Files.readAllBytes(ledger);
        long h = 0x811c9dc5L;
        for (byte b : raw) {
            h ^= (b & 0xffL);
            h = (h * 0x01000193L) & 0xffffffffL;
        }
        h ^= 0x2d2d2d2dL;
        return String.format("%08x", (int) (h & 0xffffffffL));
    }
}
