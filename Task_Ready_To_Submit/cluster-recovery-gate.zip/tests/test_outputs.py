"""Verifier for cluster-recovery-gate gate_report contract."""

from __future__ import annotations

import configparser
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

APP = Path("/app")
OUT = APP / "output" / "gate_report.json"
PROPS_PATHS = {
    "u.props": APP / "zq" / "u.props",
    "v.props": APP / "x9" / "v.props",
    "k.props": APP / "y2" / "k.props",
}
LEDGER = APP / "vault" / "ledger.dat"
EXPECTED_LEDGER = b"record;9;shard-north;"
EXPECTED_DIGEST = "0a7e3dba"
GATE_TMP = APP / "output" / ".gate_readback.json"


def fnv1a32(data: bytes) -> int:
    h = 0x811C9DC5
    for b in data:
        h ^= b
        h = (h * 0x01000193) & 0xFFFFFFFF
    return h


def run_emitter_and_sync_output() -> dict[str, str]:
    subprocess.run(
        [
            "java",
            "-cp",
            str(APP / "out"),
            "delta.run.M0",
            str(GATE_TMP),
        ],
        check=True,
        cwd=str(APP),
    )
    tmp_obj = json.loads(GATE_TMP.read_text(encoding="utf-8"))
    assert OUT.exists(), "expected gate json at /app/output/gate_report.json"
    disk_obj = json.loads(OUT.read_text(encoding="utf-8"))
    assert disk_obj == tmp_obj, "disk gate json diverges from emitter readback"
    return disk_obj


def run_emitter_to_primary_output() -> dict[str, str]:
    """Run M0 writing the canonical /app/output/gate_report.json (no readback compare)."""
    subprocess.run(
        [
            "java",
            "-cp",
            str(APP / "out"),
            "delta.run.M0",
            str(OUT),
        ],
        check=True,
        cwd=str(APP),
    )
    return json.loads(OUT.read_text(encoding="utf-8"))


def load_gate() -> dict[str, str]:
    return run_emitter_and_sync_output()


def load_props(name: str) -> configparser.SectionProxy:
    cfg = configparser.ConfigParser(interpolation=None)
    path = PROPS_PATHS[name]
    text = "[root]\n" + path.read_text(encoding="utf-8")
    cfg.read_string(text)
    return cfg["root"]


def _parse_utc_instant(raw: str) -> datetime:
    s = raw.strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    return datetime.fromisoformat(s).astimezone(timezone.utc)


def test_u_props_lab_north_binding() -> None:
    """North sheet uses store.lab.local and /api, not the broken offsite / legacy export tail."""
    w0 = load_props("u.props")
    assert w0["north_host"] == "store.lab.local"
    assert w0["path_prefix"] == "/api"


def test_health_tier_ok() -> None:
    """health_tier settles to ok when the north host and prefix match the lab sheet."""
    data = load_gate()
    assert data["health_tier"] == "ok"


def test_fault_mode_idle() -> None:
    """fault_mode settles to the idle token from steady_tokens when the cohort is fully rolled in."""
    data = load_gate()
    assert data["fault_mode"] == "idle"


def test_vault_state_fresh() -> None:
    """vault_state reads fresh when scan logic and the parsed vault window agree with bind rules."""
    data = load_gate()
    assert data["vault_state"] == "fresh"


def test_buddy_lane_up() -> None:
    """buddy_lane reads up when k.props actual_exit matches the buddy_must_zero companion policy."""
    data = load_gate()
    assert data["buddy_lane"] == "up"


def test_pressure_flag_relaxed() -> None:
    """pressure_flag reads relaxed when millicore request stays at or under the ceiling on the sheet."""
    data = load_gate()
    assert data["pressure_flag"] == "relaxed"


def test_ledger_digest_fnv() -> None:
    """ledger_digest matches the catalog row in /app/docs/steady_tokens.txt and FNV-1a over ledger bytes."""
    data = load_gate()
    assert data["ledger_digest"] == EXPECTED_DIGEST
    assert data["ledger_digest"] == f"{fnv1a32(EXPECTED_LEDGER):08x}"


def test_no_storm_when_surface_ok() -> None:
    """Do not publish ok health while fault_mode carries the noisy spike label."""
    data = load_gate()
    assert not (data["health_tier"] == "ok" and data["fault_mode"] == "storm")


def test_idle_requires_full_rollout() -> None:
    """idle fault_mode implies cohort_ready reached cohort_total on the first sheet."""
    data = load_gate()
    w0 = load_props("u.props")
    ready = int(w0.get("cohort_ready", "0"), 10)
    total = int(w0.get("cohort_total", "0"), 10)
    if data["fault_mode"] == "idle":
        assert ready >= total
        assert total >= 2


def test_ledger_bundle_unmodified() -> None:
    """Ledger bytes on disk stay identical to the shipped bundle."""
    assert LEDGER.read_bytes() == EXPECTED_LEDGER


def test_gate_json_top_level_keys() -> None:
    """Gate JSON exposes only the six documented top-level keys."""
    data = load_gate()
    assert set(data.keys()) == {
        "health_tier",
        "fault_mode",
        "vault_state",
        "buddy_lane",
        "pressure_flag",
        "ledger_digest",
    }


def test_emitter_tracks_u_props_not_static_json() -> None:
    """Mutating the north host on the live sheet must change health_tier after emitter re-run."""
    path = PROPS_PATHS["u.props"]
    original = path.read_text(encoding="utf-8")
    try:
        data0 = load_gate()
        assert data0["health_tier"] == "ok"
        mutated_lines: list[str] = []
        for line in original.splitlines():
            if line.startswith("north_host="):
                mutated_lines.append("north_host=" + "bad")
            else:
                mutated_lines.append(line)
        new_body = "\n".join(mutated_lines)
        if original.endswith("\n"):
            new_body += "\n"
        path.write_text(new_body, encoding="utf-8")
        data1 = run_emitter_to_primary_output()
        assert data1["health_tier"] == "down"
    finally:
        path.write_text(original, encoding="utf-8")
        run_emitter_to_primary_output()
    data2 = run_emitter_and_sync_output()
    assert data2["health_tier"] == "ok"


def test_emitter_tracks_path_prefix_for_health() -> None:
    """Mutating only path_prefix on the live sheet must flip health_tier after emitter re-run."""
    path = PROPS_PATHS["u.props"]
    original = path.read_text(encoding="utf-8")
    try:
        data0 = load_gate()
        assert data0["health_tier"] == "ok"
        mutated_lines: list[str] = []
        for line in original.splitlines():
            if line.startswith("path_prefix="):
                mutated_lines.append("path_prefix=/legacy")
            else:
                mutated_lines.append(line)
        new_body = "\n".join(mutated_lines)
        if original.endswith("\n"):
            new_body += "\n"
        path.write_text(new_body, encoding="utf-8")
        data1 = run_emitter_to_primary_output()
        assert data1["health_tier"] == "down"
    finally:
        path.write_text(original, encoding="utf-8")
        run_emitter_to_primary_output()
    data2 = run_emitter_and_sync_output()
    assert data2["health_tier"] == "ok"


def test_emitter_tracks_cohort_ready_for_fault_mode() -> None:
    """Lowering cohort_ready below cohort_total must surface storm on the fault line after re-run."""
    path = PROPS_PATHS["u.props"]
    original = path.read_text(encoding="utf-8")
    try:
        data0 = load_gate()
        assert data0["fault_mode"] == "idle"
        mutated_lines: list[str] = []
        for line in original.splitlines():
            if line.startswith("cohort_ready="):
                mutated_lines.append("cohort_ready=1")
            else:
                mutated_lines.append(line)
        new_body = "\n".join(mutated_lines)
        if original.endswith("\n"):
            new_body += "\n"
        path.write_text(new_body, encoding="utf-8")
        data1 = run_emitter_to_primary_output()
        assert data1["fault_mode"] == "storm"
    finally:
        path.write_text(original, encoding="utf-8")
        run_emitter_to_primary_output()
    data2 = run_emitter_and_sync_output()
    assert data2["fault_mode"] == "idle"


def test_emitter_tracks_vault_window_for_vault_state() -> None:
    """Breaking the parsed forward vault window must flip vault_state away from fresh after re-run."""
    path = PROPS_PATHS["v.props"]
    original = path.read_text(encoding="utf-8")
    try:
        data0 = load_gate()
        assert data0["vault_state"] == "fresh"
        mutated_lines: list[str] = []
        for line in original.splitlines():
            if line.startswith("vault_epoch="):
                mutated_lines.append("vault_epoch=2026-05-18T00:00:00Z")
            elif line.startswith("vault_deadline="):
                mutated_lines.append("vault_deadline=2026-05-02T00:00:00Z")
            else:
                mutated_lines.append(line)
        new_body = "\n".join(mutated_lines)
        if original.endswith("\n"):
            new_body += "\n"
        path.write_text(new_body, encoding="utf-8")
        data1 = run_emitter_to_primary_output()
        assert data1["vault_state"] == "stale"
    finally:
        path.write_text(original, encoding="utf-8")
        run_emitter_to_primary_output()
    data2 = run_emitter_and_sync_output()
    assert data2["vault_state"] == "fresh"


def test_emitter_tracks_millicore_for_pressure() -> None:
    """Raising milli_request above milli_limit must move pressure_flag to capped after re-run."""
    path = PROPS_PATHS["k.props"]
    original = path.read_text(encoding="utf-8")
    kp = load_props("k.props")
    lim = int(str(kp["milli_limit"]).strip(), 10)
    surge_req = lim + 100
    try:
        data0 = load_gate()
        assert data0["pressure_flag"] == "relaxed"
        mutated_lines: list[str] = []
        for line in original.splitlines():
            if line.startswith("milli_request="):
                mutated_lines.append(f"milli_request={surge_req}")
            else:
                mutated_lines.append(line)
        new_body = "\n".join(mutated_lines)
        if original.endswith("\n"):
            new_body += "\n"
        path.write_text(new_body, encoding="utf-8")
        data1 = run_emitter_to_primary_output()
        assert data1["pressure_flag"] == "capped"
    finally:
        path.write_text(original, encoding="utf-8")
        run_emitter_to_primary_output()
    data2 = run_emitter_and_sync_output()
    assert data2["pressure_flag"] == "relaxed"


def test_emitter_tracks_actual_exit_for_buddy_lane() -> None:
    """Non-zero actual_exit under buddy_must_zero must drop buddy_lane after re-run."""
    path = PROPS_PATHS["k.props"]
    original = path.read_text(encoding="utf-8")
    try:
        data0 = load_gate()
        assert data0["buddy_lane"] == "up"
        mutated_lines: list[str] = []
        for line in original.splitlines():
            if line.startswith("actual_exit="):
                mutated_lines.append("actual_exit=1")
            else:
                mutated_lines.append(line)
        new_body = "\n".join(mutated_lines)
        if original.endswith("\n"):
            new_body += "\n"
        path.write_text(new_body, encoding="utf-8")
        data1 = run_emitter_to_primary_output()
        assert data1["buddy_lane"] == "down"
    finally:
        path.write_text(original, encoding="utf-8")
        run_emitter_to_primary_output()
    data2 = run_emitter_and_sync_output()
    assert data2["buddy_lane"] == "up"


def test_vault_sheet_window_valid_when_fresh() -> None:
    """When vault_state is fresh, vault_epoch must parse on or before vault_deadline on the live sheet."""
    data = load_gate()
    assert data["vault_state"] == "fresh"
    vp = load_props("v.props")
    epoch = _parse_utc_instant(vp["vault_epoch"])
    deadline = _parse_utc_instant(vp["vault_deadline"])
    assert epoch <= deadline


def test_millicore_sheet_respects_ceiling_when_relaxed() -> None:
    """relaxed pressure_flag requires milli_request at or under milli_limit on the live sheet."""
    data = load_gate()
    assert data["pressure_flag"] == "relaxed"
    kp = load_props("k.props")
    req = int(str(kp["milli_request"]).strip(), 10)
    lim = int(str(kp["milli_limit"]).strip(), 10)
    assert req <= lim
