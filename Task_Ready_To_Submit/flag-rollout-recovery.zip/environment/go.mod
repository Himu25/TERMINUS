module lab.local/flag_rollout_recovery

go 1.22
