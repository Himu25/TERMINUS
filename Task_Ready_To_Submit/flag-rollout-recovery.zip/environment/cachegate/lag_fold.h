#pragma once

long long cg_apply_lag(long long base_ms, long long lag_ms);
