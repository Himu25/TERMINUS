package cachegate

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libcachegate.a -ldl -lm
#include "lag_fold.h"
*/
import "C"

// ApplyLag combines regional clock skew with an optional lag band.
func ApplyLag(baseMS int64, lagMS int64) int64 {
	return int64(C.cg_apply_lag(C.longlong(baseMS), C.longlong(lagMS)))
}
