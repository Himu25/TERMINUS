// Report JSON for /app/output/rollout_report.json:
//
// schema_version — string, always "1"
// plan_id — string, echoes active mesh plan name
// adopted_ver — uint32, highest version in the consistent adoption chain
// converge_seq — highest contiguous rollout step included in the chain after folding the earliest regional stale_mark watermark
// stale_cache_repairs — shard rows in the winning version group whose integrity tag failed validation
// propagation_gaps — rollout steps above the watermark without regional quorum agreement on one version
// services_up — count of regional shards contributing to accepted rows
// revert_count — shards assigned rollback version after partial heal
// keep_count — shards kept on target version
// prop_band — string, "tight" or "wide"
// rollback_clean — boolean (not 0/1 strings)
// digest_hex — lowercase hex SHA-256 of plan_id|adopted_ver|converge_seq|stale_cache_repairs|propagation_gaps|services_up|revert_count|keep_count|prop_band|rollback_clean
//
// Root object contains only these keys.
package main

import (
	"log"
	"os"

	"lab.local/flag_rollout_recovery/internal/driver"
)

func main() {
	if os.Getenv("TB_FLAG_FIXTURE") != "1" {
		log.Fatal("TB_FLAG_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/rollout_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
