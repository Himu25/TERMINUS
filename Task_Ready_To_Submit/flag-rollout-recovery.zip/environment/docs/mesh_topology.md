# Regional mesh topology

Fifty logical services are grouped into five regional shards (ten services per shard).
Each shard contributes rollout observations and a stale-mark watermark used during replay.
