package merge

import (
	"lab.local/flag_rollout_recovery/internal/skew"
	"lab.local/flag_rollout_recovery/internal/vercheck"
	"lab.local/flag_rollout_recovery/pkg/frame"
	"lab.local/flag_rollout_recovery/pkg/quorumgate"
)

// Outcome is the folded recovery counters for one plan replay.
type Outcome struct {
	AdoptedVer          uint32
	ConvergeSeq         uint32
	StaleCacheRepairs   uint32
	PropagationGaps     uint32
	ServicesUp          uint32
	RevertCount         uint32
	KeepCount           uint32
	PropBand            string
	RollbackClean       bool
}

// FusePlan rebuilds consistent rollout state above a watermark.
func FusePlan(
	watermark uint32,
	qSize int,
	sepSeq uint32,
	propTight int64,
	targetVer uint32,
	rollbackVer uint32,
	offsets map[string]int64,
	bySeq map[uint32][]frame.Row,
	allRows map[uint32][]frame.Row,
) Outcome {
	var spreadMin, spreadMax int64
	for _, off := range offsets {
		if spreadMin == 0 && spreadMax == 0 {
			spreadMin, spreadMax = off, off
			continue
		}
		if off < spreadMin {
			spreadMin = off
		}
		if off > spreadMax {
			spreadMax = off
		}
	}
	band := "tight"
	if spreadMax-spreadMin > propTight {
		band = "wide"
	}

	accepted := map[uint32]uint32{}
	repair := uint32(0)
	loss := uint32(0)
	live := map[string]struct{}{}
	rollbackClean := true
	regionKeep := map[string]bool{}

	seqs := make([]uint32, 0, len(bySeq))
	for s := range bySeq {
		seqs = append(seqs, s)
	}
	for _, s := range op_rUint(seqs) {
		rows := bySeq[s]
		buckets := map[[2]string][]frame.Row{}
		for _, row := range rows {
			key := [2]string{itoaU(row.Ver), row.Region}
			buckets[key] = append(buckets[key], row)
		}
		var pickedKey [2]string
		var pickedRows []frame.Row
		var bestAdj int64
		found := false
		for key, items := range buckets {
			memSet := map[string]struct{}{}
			for _, it := range items {
				memSet[it.ServiceID] = struct{}{}
			}
			if !quorumgate.OpQ(len(memSet), qSize) {
				continue
			}
			valid := make([]frame.Row, 0, len(items))
			for _, it := range items {
				if vercheck.OpValid(it.RolloutSeq, it.ServiceID, it.Ver, it.CRC) {
					valid = append(valid, it)
				}
			}
			if len(valid) < qSize {
				continue
			}
			adj := skew.AdjustWall(valid[0], offsets[valid[0].Region])
			for _, it := range valid[1:] {
				a := skew.AdjustWall(it, offsets[it.Region])
				if a < adj {
					adj = a
				}
			}
			if !found || adj < bestAdj {
				found = true
				bestAdj = adj
				pickedKey = key
				pickedRows = valid
			}
		}
		if !found {
			loss++
			continue
		}
		for _, it := range buckets[pickedKey] {
			if !vercheck.OpValid(it.RolloutSeq, it.ServiceID, it.Ver, it.CRC) {
				repair++
			}
		}
		ver := parseU(pickedKey[0])
		if ver > sepSeq {
			mem := map[string]struct{}{}
			for _, it := range pickedRows {
				mem[it.ServiceID] = struct{}{}
			}
			if len(mem) < qSize {
				rollbackClean = false
			}
		}
		rid := pickedKey[1]
		if ver >= targetVer {
			regionKeep[rid] = true
		}
		for _, it := range pickedRows {
			live[it.Region] = struct{}{}
		}
		accepted[s] = ver
	}

	global := uint32(0)
	for s := uint32(1); ; s++ {
		if s <= watermark {
			global = s
			continue
		}
		if _, ok := accepted[s]; ok {
			global = s
			continue
		}
		break
	}

	adopted := uint32(0)
	for s, ver := range accepted {
		if s <= global && ver > adopted {
			adopted = ver
		}
	}
	for _, rows := range allRows {
		for _, row := range rows {
			if row.RolloutSeq > global {
				continue
			}
			if ver, ok := accepted[row.RolloutSeq]; ok {
				if row.Ver == ver && vercheck.OpValid(row.RolloutSeq, row.ServiceID, row.Ver, row.CRC) && row.Ver > adopted {
					adopted = row.Ver
				}
			} else if row.RolloutSeq <= watermark && row.Ver > adopted {
				adopted = row.Ver
			}
		}
	}

	revert := uint32(0)
	keep := uint32(0)
	for rid := range offsets {
		if regionKeep[rid] {
			keep++
		} else {
			revert++
		}
	}

	return Outcome{
		AdoptedVer:        adopted,
		ConvergeSeq:       global,
		StaleCacheRepairs: repair,
		PropagationGaps:   loss,
		ServicesUp:        uint32(len(live)),
		RevertCount:       revert,
		KeepCount:         keep,
		PropBand:          band,
		RollbackClean:     rollbackClean,
	}
}

func op_rUint(seqs []uint32) []uint32 {
	out := append([]uint32(nil), seqs...)
	for i := 0; i < len(out); i++ {
		for j := i + 1; j < len(out); j++ {
			if out[j] < out[i] {
				out[i], out[j] = out[j], out[i]
			}
		}
	}
	return out
}

func itoaU(v uint32) string {
	if v == 0 {
		return "0"
	}
	var buf [12]byte
	i := len(buf)
	n := v
	for n > 0 {
		i--
		buf[i] = byte('0' + n%10)
		n /= 10
	}
	return string(buf[i:])
}

func parseU(s string) uint32 {
	var n uint32
	for _, c := range s {
		if c < '0' || c > '9' {
			continue
		}
		n = n*10 + uint32(c-'0')
	}
	return n
}
