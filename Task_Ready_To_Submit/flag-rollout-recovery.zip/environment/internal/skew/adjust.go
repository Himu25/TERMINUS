package skew

import (
	"lab.local/flag_rollout_recovery/pkg/frame"
	"lab.local/flag_rollout_recovery/pkg/timenorm"
)

// AdjustWall normalizes observed time for a shard row.
func AdjustWall(row frame.Row, offset int64) int64 {
	return timenorm.OpT(row.WallMS, offset)
}
