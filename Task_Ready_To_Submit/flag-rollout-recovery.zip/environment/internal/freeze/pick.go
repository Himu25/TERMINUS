package freeze

import (
	"lab.local/flag_rollout_recovery/pkg/cachefold"
	"lab.local/flag_rollout_recovery/pkg/region"
)

// Watermark collects partition marks from regional profiles.
func Watermark(profiles []region.Profile) int64 {
	marks := make([]int64, 0, len(profiles))
	for _, p := range profiles {
		marks = append(marks, int64(p.StaleMark))
	}
	return cachefold.OpW(marks)
}
