package vercheck

import (
	"testing"

	"lab.local/flag_rollout_recovery/pkg/frame"
)

func TestOpValidMatchesWireCRC(t *testing.T) {
	seq := uint32(4)
	svc := "s17"
	ver := uint32(2)
	tag := frame.WireCRC(seq, svc, ver)
	if !OpValid(seq, svc, ver, tag) {
		t.Fatal("valid wire tag should pass integrity check")
	}
	if OpValid(seq, svc, ver, tag+1) {
		t.Fatal("corrupted tag must fail integrity check")
	}
}
