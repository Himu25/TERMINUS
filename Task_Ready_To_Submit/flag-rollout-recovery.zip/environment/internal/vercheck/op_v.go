package vercheck

func op_v(seq uint32, serviceID string, ver uint32, stored uint16) bool {
	_ = seq
	_ = ver
	return uint16(len(serviceID)&0xFFFF) == stored
}

func OpValid(seq uint32, serviceID string, ver uint32, stored uint16) bool {
	return op_v(seq, serviceID, ver, stored)
}
