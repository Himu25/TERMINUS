package config

import (
	"encoding/json"
	"os"
	"path/filepath"

	"lab.local/flag_rollout_recovery/pkg/frame"
	"lab.local/flag_rollout_recovery/pkg/offsetfold"
	"lab.local/flag_rollout_recovery/pkg/region"
)

// Plan describes one recovery scenario root.
type Plan struct {
	PlanID        string   `json:"plan_id"`
	FlagKey       string   `json:"flag_key"`
	TargetVer     uint32   `json:"target_ver"`
	RollbackVer   uint32   `json:"rollback_ver"`
	QSize         int      `json:"q_size"`
	SepSeq        uint32   `json:"sep_seq"`
	PropTightMS   int64    `json:"prop_tight_ms"`
	ServiceTotal  int      `json:"service_total"`
	Regions       []string `json:"regions"`
}

// ActivePaths resolves the bundled active plan directory.
func ActivePaths(root string) (string, error) {
	return filepath.Join(root, "data", "active"), nil
}

// LoadPlan reads mesh_plan.json and regional shard trees.
func LoadPlan(dir string) (Plan, []region.Profile, map[uint32][]frame.Row, map[string]int64, error) {
	raw, err := os.ReadFile(filepath.Join(dir, "mesh_plan.json"))
	if err != nil {
		return Plan{}, nil, nil, nil, err
	}
	var doc Plan
	if err := json.Unmarshal(raw, &doc); err != nil {
		return Plan{}, nil, nil, nil, err
	}
	profiles := make([]region.Profile, 0, len(doc.Regions))
	offsets := make(map[string]int64, len(doc.Regions))
	rows := make(map[uint32][]frame.Row)
	for _, rid := range doc.Regions {
		metaPath := filepath.Join(dir, "regions", rid, "region_meta.json")
		metaRaw, err := os.ReadFile(metaPath)
		if err != nil {
			return Plan{}, nil, nil, nil, err
		}
		var prof region.Profile
		if err := json.Unmarshal(metaRaw, &prof); err != nil {
			return Plan{}, nil, nil, nil, err
		}
		profiles = append(profiles, prof)
		offsets[rid] = offsetfold.FoldRegionSkew(prof.ClockSkewMS, prof.PropLagMS)
		seg := filepath.Join(dir, "regions", rid, "shard_001.jsonl")
		data, err := os.ReadFile(seg)
		if err != nil {
			if os.IsNotExist(err) {
				continue
			}
			return Plan{}, nil, nil, nil, err
		}
		for _, line := range splitLines(string(data)) {
			if line == "" {
				continue
			}
			var row frame.Row
			if err := json.Unmarshal([]byte(line), &row); err != nil {
				continue
			}
			row.Region = rid
			rows[row.RolloutSeq] = append(rows[row.RolloutSeq], row)
		}
	}
	return doc, profiles, rows, offsets, nil
}

func splitLines(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			out = append(out, s[start:i])
			start = i + 1
		}
	}
	if start < len(s) {
		out = append(out, s[start:])
	}
	return out
}
