package engine

import (
	"lab.local/flag_rollout_recovery/internal/freeze"
	"lab.local/flag_rollout_recovery/internal/merge"
	"lab.local/flag_rollout_recovery/pkg/frame"
	"lab.local/flag_rollout_recovery/pkg/region"
)

// Replay executes one plan through freeze and merge stages.
func Replay(
	planID string,
	qSize int,
	sepSeq uint32,
	propTight int64,
	targetVer uint32,
	rollbackVer uint32,
	profiles []region.Profile,
	allRows map[uint32][]frame.Row,
	offsets map[string]int64,
) merge.Outcome {
	wm := freeze.Watermark(profiles)
	above := make(map[uint32][]frame.Row)
	for seq, rows := range allRows {
		if seq > uint32(wm) {
			above[seq] = rows
		}
	}
	out := merge.FusePlan(uint32(wm), qSize, sepSeq, propTight, targetVer, rollbackVer, offsets, above, allRows)
	_ = planID
	return out
}
