package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"

	"lab.local/flag_rollout_recovery/internal/config"
	"lab.local/flag_rollout_recovery/internal/engine"
)

// Report is the outward JSON document.
type Report struct {
	SchemaVersion       string `json:"schema_version"`
	PlanID              string `json:"plan_id"`
	AdoptedVer          uint32 `json:"adopted_ver"`
	ConvergeSeq         uint32 `json:"converge_seq"`
	StaleCacheRepairs   uint32 `json:"stale_cache_repairs"`
	PropagationGaps     uint32 `json:"propagation_gaps"`
	ServicesUp          uint32 `json:"services_up"`
	RevertCount         uint32 `json:"revert_count"`
	KeepCount           uint32 `json:"keep_count"`
	PropBand            string `json:"prop_band"`
	RollbackClean       bool   `json:"rollback_clean"`
	DigestHex           string `json:"digest_hex"`
}

// RunActive loads the active plan and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	plan, profiles, rows, offsets, err := config.LoadPlan(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(plan.PlanID, plan.QSize, plan.SepSeq, plan.PropTightMS, plan.TargetVer, plan.RollbackVer, profiles, rows, offsets)
	ck := "true"
	if !out.RollbackClean {
		ck = "false"
	}
	digest := sha256.Sum256([]byte(fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%d|%d|%s|%s",
		plan.PlanID,
		out.AdoptedVer,
		out.ConvergeSeq,
		out.StaleCacheRepairs,
		out.PropagationGaps,
		out.ServicesUp,
		out.RevertCount,
		out.KeepCount,
		out.PropBand,
		ck,
	)))
	return Report{
		SchemaVersion:     "1",
		PlanID:            plan.PlanID,
		AdoptedVer:        out.AdoptedVer,
		ConvergeSeq:       out.ConvergeSeq,
		StaleCacheRepairs: out.StaleCacheRepairs,
		PropagationGaps:   out.PropagationGaps,
		ServicesUp:        out.ServicesUp,
		RevertCount:       out.RevertCount,
		KeepCount:         out.KeepCount,
		PropBand:          out.PropBand,
		RollbackClean:     out.RollbackClean,
		DigestHex:         hex.EncodeToString(digest[:]),
	}, nil
}
