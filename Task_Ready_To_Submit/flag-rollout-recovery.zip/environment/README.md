# Flag rollout recovery lab

Mixed-language recovery driver for regional shard convergence after a partial control-plane push.
