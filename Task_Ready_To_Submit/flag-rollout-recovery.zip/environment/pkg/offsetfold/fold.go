package offsetfold

import "lab.local/flag_rollout_recovery/cachegate"

// FoldRegionSkew applies optional propagation lag smear to the recorded clock skew baseline.
func FoldRegionSkew(skewMS int64, propLagMS int64) int64 {
	return cachegate.ApplyLag(skewMS, propLagMS)
}
