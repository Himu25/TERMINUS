package offsetfold

import "testing"

func TestFoldRegionSkewSubtractsPropagationLag(t *testing.T) {
	got := FoldRegionSkew(26, 8)
	if got != 18 {
		t.Fatalf("lag smear fold = %d, want 18", got)
	}
}
