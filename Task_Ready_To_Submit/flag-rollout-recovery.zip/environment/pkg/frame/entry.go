package frame

// Row is one append-only shard line from a regional segment.
type Row struct {
	RolloutSeq uint32 `json:"rollout_seq"`
	Ver        uint32 `json:"ver"`
	WallMS     int64  `json:"observed_ms"`
	ServiceID  string `json:"service_id"`
	CRC        uint16 `json:"crc"`
	Region     string `json:"region"`
}
