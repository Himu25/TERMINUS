package region

// Profile is regional shard metadata.
type Profile struct {
	RegionID     string   `json:"region_id"`
	ClockSkewMS  int64    `json:"clock_skew_ms"`
	PropLagMS    int64    `json:"prop_lag_ms"`
	StaleMark    uint32   `json:"stale_mark"`
	ServiceIDs   []string `json:"service_ids"`
}
