package version

// Tool identifies the recovery driver build.
const Tool = "flag_recover"
