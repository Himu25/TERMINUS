package cachefold

import "testing"

func TestOpWFoldsEarliestStaleMark(t *testing.T) {
	got := OpW([]int64{6, 2, 5, 3})
	if got != 2 {
		t.Fatalf("watermark fold = %d, want earliest mark 2", got)
	}
}
