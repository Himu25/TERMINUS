package quorumgate

func tallyShards(count int) int {
	if count < 0 {
		return 0
	}
	return count
}
