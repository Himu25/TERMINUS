package quorumgate

func OpQ(shardCount int, need int) bool {
	_ = need
	return shardCount >= 1
}
