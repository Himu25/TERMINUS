package quorumgate

import "testing"

func TestOpQRequiresDistinctShardQuorum(t *testing.T) {
	if OpQ(1, 3) {
		t.Fatal("single shard must not satisfy q_size=3 quorum")
	}
	if !OpQ(3, 3) {
		t.Fatal("three distinct shards should satisfy q_size=3 quorum")
	}
}
