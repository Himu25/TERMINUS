"""Verifier for fifty-service regional flag rollout recovery report."""

import json
import os
import shutil
import subprocess
from collections import defaultdict
from pathlib import Path

import pytest

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = Path("/tests") / "fixtures"
OUT = APP / "output" / "rollout_report.json"
GO_BIN = "go"
VERIFY_BIN = "/app/bin/flag_recover"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _digest_hex(
    plan_id: str,
    adopted_ver: int,
    converge_seq: int,
    repair: int,
    gaps: int,
    services_up: int,
    revert: int,
    keep: int,
    band: str,
    rollback_clean: bool,
) -> str:
    ck = "true" if rollback_clean else "false"
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            plan_id,
            str(adopted_ver),
            str(converge_seq),
            str(repair),
            str(gaps),
            str(services_up),
            str(revert),
            str(keep),
            band,
            ck,
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _crc16(seq: int, service_id: str, ver: int) -> int:
    s = sum(service_id.encode()) & 0xFFFFFFFF
    s ^= seq ^ ver
    return s & 0xFFFF


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = FIXTURES / pack_name
    plan = json.loads((pack_dir / "mesh_plan.json").read_text())
    q = plan["q_size"]
    sep_seq = plan["sep_seq"]
    target_ver = plan["target_ver"]
    prop_tight = plan["prop_tight_ms"]
    offsets: dict[str, int] = {}
    freezes: list[int] = []
    rows: list[dict] = []
    for rid in plan["regions"]:
        meta = json.loads((pack_dir / "regions" / rid / "region_meta.json").read_text())
        lag = int(meta.get("prop_lag_ms", 0))
        offsets[rid] = int(meta["clock_skew_ms"]) - lag
        freezes.append(meta["stale_mark"])
        seg = pack_dir / "regions" / rid / "shard_001.jsonl"
        if not seg.exists():
            continue
        for line in seg.read_text().splitlines():
            if not line.strip():
                continue
            entry = json.loads(line)
            entry["region"] = rid
            rows.append(entry)
    wm = min(freezes) if freezes else 0
    by_seq: dict[int, list] = defaultdict(list)
    all_rows: dict[int, list] = defaultdict(list)
    for entry in rows:
        seq = entry["rollout_seq"]
        all_rows[seq].append(entry)
        if seq > wm:
            by_seq[seq].append(entry)
    accepted: dict[int, int] = {}
    repair = 0
    loss = 0
    live: set[str] = set()
    rollback_clean = True
    region_keep: dict[str, bool] = {}
    for seq in sorted(by_seq):
        buckets: dict[tuple, list] = defaultdict(list)
        for entry in by_seq[seq]:
            buckets[(entry["ver"], entry["region"])].append(entry)
        picked = None
        best_adj = None
        for (ver, region), items in buckets.items():
            if len({it["service_id"] for it in items}) < q:
                continue
            valid = [
                it
                for it in items
                if _crc16(it["rollout_seq"], it["service_id"], it["ver"]) == it["crc"]
            ]
            if len(valid) < q:
                continue
            adj = min(it["observed_ms"] - offsets[it["region"]] for it in valid)
            if picked is None or adj < best_adj:
                picked, best_adj = (ver, region), adj
        if picked is None:
            loss += 1
            continue
        ver, region = picked
        items = buckets[(ver, region)]
        repair += sum(
            1
            for it in items
            if _crc16(it["rollout_seq"], it["service_id"], it["ver"]) != it["crc"]
        )
        if ver > sep_seq and len({it["service_id"] for it in items if _crc16(it["rollout_seq"], it["service_id"], it["ver"]) == it["crc"]}) < q:
            rollback_clean = False
        if ver >= target_ver:
            region_keep[region] = True
        for it in items:
            if _crc16(it["rollout_seq"], it["service_id"], it["ver"]) == it["crc"]:
                live.add(it["region"])
        accepted[seq] = ver
    converge_seq = 0
    s = 1
    while True:
        if s <= wm or s in accepted:
            converge_seq = s
            s += 1
        else:
            break
    adopted_ver = 0
    for seq, seq_rows in all_rows.items():
        if seq > converge_seq:
            continue
        for entry in seq_rows:
            if seq in accepted and entry["ver"] == accepted[seq]:
                if _crc16(entry["rollout_seq"], entry["service_id"], entry["ver"]) == entry["crc"] and entry["ver"] > adopted_ver:
                    adopted_ver = entry["ver"]
            elif seq <= wm and entry["ver"] > adopted_ver:
                adopted_ver = entry["ver"]
    revert = 0
    keep = 0
    for rid in offsets:
        if region_keep.get(rid):
            keep += 1
        else:
            revert += 1
    spread = max(offsets.values()) - min(offsets.values())
    band = "tight" if spread <= prop_tight else "wide"
    digest = _digest_hex(
        plan["plan_id"],
        adopted_ver,
        converge_seq,
        repair,
        loss,
        len(live),
        revert,
        keep,
        band,
        rollback_clean,
    )
    return {
        "schema_version": "1",
        "plan_id": plan["plan_id"],
        "adopted_ver": adopted_ver,
        "converge_seq": converge_seq,
        "stale_cache_repairs": repair,
        "propagation_gaps": loss,
        "services_up": len(live),
        "revert_count": revert,
        "keep_count": keep,
        "prop_band": band,
        "rollback_clean": rollback_clean,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_FLAG_FIXTURE": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_alpha_report_matches_quorum_replay() -> None:
    """Alpha mesh should reach tight prop band with full five-shard chain."""
    _swap("mesh_alpha")
    exp = _expected_from_fixture("mesh_alpha")
    got = _run_tool()
    assert got["converge_seq"] == exp["converge_seq"]
    assert got["propagation_gaps"] == exp["propagation_gaps"]
    assert got["adopted_ver"] == exp["adopted_ver"]
    assert got["prop_band"] == exp["prop_band"]
    assert got["services_up"] == exp["services_up"]
    assert got["rollback_clean"] == exp["rollback_clean"]
    assert got["digest_hex"] == exp["digest_hex"]


def test_beta_report_matches_quorum_replay() -> None:
    """Beta mesh applies propagation lag smear when folding regional skew for replay."""
    _swap("mesh_beta")
    exp = _expected_from_fixture("mesh_beta")
    got = _run_tool()
    assert got["prop_band"] == exp["prop_band"]
    assert got["keep_count"] == exp["keep_count"]
    assert got["revert_count"] == exp["revert_count"]
    assert got["services_up"] == exp["services_up"]
    assert got["rollback_clean"] == exp["rollback_clean"]
    assert got["digest_hex"] == exp["digest_hex"]


def test_gamma_propagation_gaps_after_lone_version() -> None:
    """Gamma stops the chain when only one shard carries a high version row."""
    _swap("mesh_gamma")
    exp = _expected_from_fixture("mesh_gamma")
    got = _run_tool()
    assert got["propagation_gaps"] == exp["propagation_gaps"]
    assert got["converge_seq"] == exp["converge_seq"]
    assert got["services_up"] == exp["services_up"]
    assert got["rollback_clean"] == exp["rollback_clean"]
    assert got["digest_hex"] == exp["digest_hex"]


def test_delta_high_propagation_gaps() -> None:
    """Delta orphan high step should not extend the global chain."""
    _swap("mesh_delta")
    exp = _expected_from_fixture("mesh_delta")
    got = _run_tool()
    assert got["propagation_gaps"] == exp["propagation_gaps"]
    assert got["converge_seq"] == exp["converge_seq"]
    assert got["services_up"] == exp["services_up"]
    assert got["rollback_clean"] == exp["rollback_clean"]
    assert got["digest_hex"] == exp["digest_hex"]


def test_epsilon_stale_cache_repairs_nonzero() -> None:
    """Epsilon should count one integrity repair on the winning version group."""
    _swap("mesh_epsilon")
    exp = _expected_from_fixture("mesh_epsilon")
    got = _run_tool()
    assert got["stale_cache_repairs"] == exp["stale_cache_repairs"]
    assert got["converge_seq"] == exp["converge_seq"]
    assert got["services_up"] == exp["services_up"]
    assert got["rollback_clean"] == exp["rollback_clean"]
    assert got["digest_hex"] == exp["digest_hex"]


def test_zeta_converge_seq_watermark() -> None:
    """Alpha mesh converge_seq tracks replay watermark fold."""
    _swap("mesh_alpha")
    exp = _expected_from_fixture("mesh_alpha")
    got = _run_tool()
    assert got["converge_seq"] == exp["converge_seq"]
    assert got["services_up"] == exp["services_up"]
    assert got["rollback_clean"] == exp["rollback_clean"]
    assert got["digest_hex"] == exp["digest_hex"]


def test_theta_keep_revert_split() -> None:
    """Beta partial heal should split keep and revert counts across shards."""
    _swap("mesh_beta")
    exp = _expected_from_fixture("mesh_beta")
    got = _run_tool()
    assert got["keep_count"] == exp["keep_count"]
    assert got["revert_count"] == exp["revert_count"]
    assert got["services_up"] == exp["services_up"]
    assert got["rollback_clean"] == exp["rollback_clean"]
    assert got["digest_hex"] == exp["digest_hex"]


def test_go_subsystem_tests_pass() -> None:
    """Go unit tests under /app must pass after the repair."""
    subprocess.run(
        [GO_BIN, "test", "./..."],
        cwd="/app",
        env={
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        },
        check=True,
    )
