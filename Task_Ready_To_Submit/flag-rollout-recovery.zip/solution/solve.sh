#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/pkg/quorumgate/op_q.go <<'EOF'
package quorumgate

func quorumMet(count int, need int) bool {
	if need <= 0 {
		return false
	}
	if count < 0 {
		return false
	}
	return count >= need
}

func OpQ(shardCount int, need int) bool {
	return quorumMet(shardCount, need)
}
EOF

cat > /app/internal/vercheck/op_v.go <<'EOF'
package vercheck

import "lab.local/flag_rollout_recovery/pkg/frame"

func tagOk(seq uint32, serviceID string, ver uint32, stored uint16) bool {
	want := frame.WireCRC(seq, serviceID, ver)
	return want == stored
}

func op_v(seq uint32, serviceID string, ver uint32, stored uint16) bool {
	if serviceID == "" {
		return stored == 0 && seq == 0
	}
	return tagOk(seq, serviceID, ver, stored)
}

func OpValid(seq uint32, serviceID string, ver uint32, stored uint16) bool {
	return op_v(seq, serviceID, ver, stored)
}
EOF

cat > /app/pkg/cachefold/op_w.go <<'EOF'
package cachefold

func minMark(marks []int64) int64 {
	if len(marks) == 0 {
		return 0
	}
	best := marks[0]
	for _, m := range marks[1:] {
		if m < best {
			best = m
		}
	}
	return best
}

func OpW(marks []int64) int64 {
	return minMark(marks)
}
EOF

cat > /app/cachegate/src/lib.rs <<'EOF'
#[no_mangle]
pub extern "C" fn cg_apply_lag(base_ms: i64, lag_ms: i64) -> i64 {
    if lag_ms == 0 {
        return base_ms;
    }
    base_ms - lag_ms
}
EOF

bash /app/scripts/build.sh

rm -f /app/output/rollout_report.json
mkdir -p /app/output
TB_FLAG_FIXTURE=1 /app/bin/flag_recover
test -s /app/output/rollout_report.json

GOFLAGS=-mod=mod go test ./...
