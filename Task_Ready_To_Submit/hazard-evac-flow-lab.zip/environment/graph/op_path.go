package graph

import "sort"

// OpPath is the exported entry for the planner.
func OpPath(g *Graph, from string, to string, k int) [][]string {
	return op_path(g, from, to, k)
}

// op_path returns up to k simple routes ordered by length.
func op_path(g *Graph, from string, to string, k int) [][]string {
	if g == nil || from == "" || to == "" {
		return nil
	}
	best := dijkstra(g, from, to)
	if best == nil {
		return nil
	}
	return [][]string{best}
}

func dijkstra(g *Graph, from string, to string) []string {
	dist := map[string]int{from: 0}
	prev := map[string]string{}
	seen := map[string]bool{}
	for len(seen) < len(g.adj)+1 {
		var cur string
		best := int(1e9)
		for n, d := range dist {
			if seen[n] {
				continue
			}
			if d < best {
				best = d
				cur = n
			}
		}
		if cur == "" {
			break
		}
		if cur == to {
			break
		}
		seen[cur] = true
		for _, e := range g.adj[cur] {
			nd := dist[cur] + e.Len
			if old, ok := dist[e.To]; !ok || nd < old {
				dist[e.To] = nd
				prev[e.To] = cur
			}
		}
	}
	if dist[to] == 0 && from != to {
		if _, ok := prev[to]; !ok {
			return nil
		}
	}
	if from == to {
		return []string{from}
	}
	if _, ok := prev[to]; !ok {
		return nil
	}
	var path []string
	for at := to; at != ""; at = prev[at] {
		path = append([]string{at}, path...)
		if at == from {
			break
		}
	}
	if len(path) == 0 || path[0] != from {
		return nil
	}
	return path
}

func pathLen(g *Graph, nodes []string) int {
	if len(nodes) < 2 {
		return 0
	}
	total := 0
	for i := 0; i < len(nodes)-1; i++ {
		found := false
		for _, e := range g.Edges {
			if e.From == nodes[i] && e.To == nodes[i+1] {
				total += e.Len
				found = true
				break
			}
		}
		if !found {
			return int(1e9)
		}
	}
	return total
}

func altPaths(g *Graph, from string, to string, k int) [][]string {
	base := dijkstra(g, from, to)
	if base == nil {
		return nil
	}
	out := [][]string{base}
	type cand struct {
		nodes []string
		cost  int
	}
	var queue []cand
	queue = append(queue, cand{nodes: base, cost: pathLen(g, base)})
	seen := map[string]bool{join(base): true}
	for len(out) < k && len(queue) > 0 {
		cur := queue[0]
		queue = queue[1:]
		if len(cur.nodes) < 2 {
			continue
		}
		for skip := 1; skip < len(cur.nodes)-1; skip++ {
			prefix := append([]string{}, cur.nodes[:skip]...)
			suffix := append([]string{}, cur.nodes[skip+1:]...)
			altMid := dijkstra(g, prefix[len(prefix)-1], suffix[0])
			if altMid == nil || len(altMid) < 2 {
				continue
			}
			combined := append(append(prefix, altMid[1:]...), suffix[1:]...)
			key := join(combined)
			if seen[key] {
				continue
			}
			cost := pathLen(g, combined)
			if cost >= int(1e8) {
				continue
			}
			seen[key] = true
			out = append(out, combined)
			queue = append(queue, cand{nodes: combined, cost: cost})
		}
	}
	sort.Slice(out, func(i, j int) bool {
		return pathLen(g, out[i]) < pathLen(g, out[j])
	})
	if len(out) > k {
		out = out[:k]
	}
	return out
}

func join(nodes []string) string {
	s := ""
	for _, n := range nodes {
		s += n + "|"
	}
	return s
}
