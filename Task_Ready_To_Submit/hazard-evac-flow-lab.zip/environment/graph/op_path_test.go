package graph

import "testing"

func TestOpPathReturnsMultipleRoutes(t *testing.T) {
	g := Build([]Edge{
		{From: "a", To: "b", Cap: 100, Len: 1},
		{From: "b", To: "d", Cap: 100, Len: 1},
		{From: "a", To: "c", Cap: 100, Len: 2},
		{From: "c", To: "d", Cap: 100, Len: 1},
	})
	paths := OpPath(g, "a", "d", 2)
	if len(paths) < 2 {
		t.Fatalf("expected at least 2 paths, got %d", len(paths))
	}
}
