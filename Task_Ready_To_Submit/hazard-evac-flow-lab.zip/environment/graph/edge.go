package graph

// Edge is a directed corridor with capacity and travel cost.
type Edge struct {
	From string
	To   string
	Cap  int
	Len  int
}

// Graph holds adjacency for routing.
type Graph struct {
	Edges []Edge
	adj   map[string][]Edge
}

// Build indexes edges for traversal.
func Build(edges []Edge) *Graph {
	g := &Graph{Edges: edges, adj: make(map[string][]Edge)}
	for _, e := range edges {
		g.adj[e.From] = append(g.adj[e.From], e)
	}
	return g
}

// WithoutEdge returns a copy of the graph omitting one directed edge.
func (g *Graph) WithoutEdge(from string, to string) *Graph {
	var kept []Edge
	for _, e := range g.Edges {
		if e.From == from && e.To == to {
			continue
		}
		kept = append(kept, e)
	}
	return Build(kept)
}
