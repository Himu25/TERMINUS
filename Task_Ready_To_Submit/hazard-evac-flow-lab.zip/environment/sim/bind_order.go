package sim

import "lab.local/evac_flow/prior"

func zoneOrder(doc packDoc) []int {
	return prior.OpRank(toPriorZones(doc))
}
