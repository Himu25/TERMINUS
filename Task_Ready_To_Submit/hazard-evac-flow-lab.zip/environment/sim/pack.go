package sim

import (
	"encoding/json"
	"os"

	"lab.local/evac_flow/graph"
	"lab.local/evac_flow/hazard"
	"lab.local/evac_flow/prior"
)

type zoneDoc struct {
	ID         string `json:"id"`
	Population int    `json:"population"`
	Vulnerable int    `json:"vulnerable"`
	Origin     string `json:"origin"`
	Shelter    string `json:"shelter"`
}

type shelterDoc struct {
	ID       string `json:"id"`
	Node     string `json:"node"`
	Capacity int    `json:"capacity"`
}

type edgeDoc struct {
	From string `json:"from"`
	To   string `json:"to"`
	Cap  int    `json:"cap"`
	Len  int    `json:"len"`
}

type blockDoc struct {
	From     string `json:"from"`
	To       string `json:"to"`
	FromTick int    `json:"from_tick"`
}

type packDoc struct {
	PackID         string       `json:"pack_id"`
	HorizonTicks   int          `json:"horizon_ticks"`
	HazardStart    int          `json:"hazard_start"`
	PeakCap        float64      `json:"peak_cap"`
	PriorityFloor  float64      `json:"priority_floor"`
	PhaseCount     int          `json:"phase_count"`
	Zones          []zoneDoc    `json:"zones"`
	Shelters       []shelterDoc `json:"shelters"`
	Edges          []edgeDoc    `json:"edges"`
	Blocks         []blockDoc   `json:"blocks"`
}

func readPack(path string) packDoc {
	b, err := os.ReadFile(path)
	if err != nil {
		panic(err)
	}
	var d packDoc
	if err := json.Unmarshal(b, &d); err != nil {
		panic(err)
	}
	if d.PhaseCount <= 0 {
		d.PhaseCount = 4
	}
	if d.PeakCap <= 0 {
		d.PeakCap = 0.82
	}
	if d.PriorityFloor <= 0 {
		d.PriorityFloor = 0.90
	}
	return d
}

func shelterNode(doc packDoc, shelterID string) string {
	for _, s := range doc.Shelters {
		if s.ID == shelterID {
			return s.Node
		}
	}
	return ""
}

func toGraph(doc packDoc) *graph.Graph {
	var edges []graph.Edge
	for _, e := range doc.Edges {
		edges = append(edges, graph.Edge{From: e.From, To: e.To, Cap: e.Cap, Len: e.Len})
	}
	return graph.Build(edges)
}

func toBlocks(doc packDoc) []hazard.Block {
	var out []hazard.Block
	for _, b := range doc.Blocks {
		out = append(out, hazard.Block{From: b.From, To: b.To, FromTick: b.FromTick})
	}
	return out
}

func toPriorZones(doc packDoc) []prior.Zone {
	var out []prior.Zone
	for _, z := range doc.Zones {
		out = append(out, prior.Zone{ID: z.ID, Population: z.Population, Vulnerable: z.Vulnerable})
	}
	return out
}
