package sim

import "lab.local/evac_flow/wave"

func departPhase(seq int, phases int) int {
	return wave.OpPhase(seq, phases)
}
