package sim

import (
	"lab.local/evac_flow/hazard"
	"lab.local/evac_flow/metrics"
)

const pathK = 3

// RunPack executes one evacuation scenario and returns folded counters.
func RunPack(packPath string) metrics.Stats {
	doc := readPack(packPath)
	g := toGraph(doc)
	blocks := toBlocks(doc)
	order := zoneOrder(doc)

	shelterLoad := map[string]int{}
	shelterCap := map[string]int{}
	for _, s := range doc.Shelters {
		shelterCap[s.ID] = s.Capacity
	}

	edgeCap := map[string]int{}
	for _, e := range doc.Edges {
		key := e.From + "->" + e.To
		edgeCap[key] = e.Cap
	}

	phaseLoad := make(map[int]map[string]int)
	for p := 0; p < doc.PhaseCount; p++ {
		phaseLoad[p] = make(map[string]int)
	}

	var totalVulnerable int
	var evacuatedVulnerable int
	peak := 0.0
	shelterOK := true
	hazardOK := true

	for seq, zi := range order {
		z := doc.Zones[zi]
		totalVulnerable += z.Vulnerable
		dest := shelterNode(doc, z.Shelter)
		if dest == "" {
			continue
		}
		phase := departPhase(seq, doc.PhaseCount)
		if phase >= doc.PhaseCount {
			phase = phase % doc.PhaseCount
		}
		paths := pathsFor(g, z.Origin, dest, pathK)
		if len(paths) == 0 {
			shelterOK = false
			hazardOK = false
			continue
		}
		var safePaths [][]string
		for _, p := range paths {
			blocked := false
			for i := 0; i < len(p)-1; i++ {
				if hazard.OpBlocked(blocks, p[i], p[i+1], phase) {
					blocked = true
					break
				}
			}
			if !blocked {
				safePaths = append(safePaths, p)
			}
		}
		if len(safePaths) == 0 {
			hazardOK = false
			continue
		}
		paths = safePaths

		tickLoad := phaseLoad[phase]
		var lens []int
		var headroom []int
		for _, p := range paths {
			lens = append(lens, len(p))
			minCap := int(1e9)
			for i := 0; i < len(p)-1; i++ {
				key := p[i] + "->" + p[i+1]
				cap := edgeCap[key]
				load := tickLoad[key]
				room := cap - load
				if room < minCap {
					minCap = room
				}
			}
			if minCap < 0 {
				minCap = 0
			}
			headroom = append(headroom, minCap)
		}

		shares := splitFlow(z.Population, lens, headroom)
		if len(shares) == 0 {
			shelterOK = false
			continue
		}

		assigned := 0
		for pi, share := range shares {
			if share <= 0 {
				continue
			}
			p := paths[pi]
			for i := 0; i < len(p)-1; i++ {
				key := p[i] + "->" + p[i+1]
				if hazard.OpBlocked(blocks, p[i], p[i+1], phase) {
					hazardOK = false
				}
				tickLoad[key] += share
				if edgeCap[key] > 0 {
					ratio := float64(tickLoad[key]) / float64(edgeCap[key])
					if ratio > peak {
						peak = ratio
					}
				}
			}
			assigned += share
			if z.Vulnerable > 0 {
				frac := float64(share) / float64(z.Population)
				evacuatedVulnerable += int(float64(z.Vulnerable)*frac + 0.5)
			}
		}

		shelterLoad[z.Shelter] += assigned
		if shelterLoad[z.Shelter] > shelterCap[z.Shelter] {
			shelterOK = false
		}
	}

	jam := "severe"
	if peak < 0.65 {
		jam = "clear"
	} else if peak < doc.PeakCap {
		jam = "tight"
	}

	priorityOK := true
	if totalVulnerable > 0 {
		share := float64(evacuatedVulnerable) / float64(totalVulnerable)
		if share+1e-9 < doc.PriorityFloor {
			priorityOK = false
		}
	}

	return metrics.Stats{
		PeakRatio:     peak,
		JamBand:       jam,
		ShelterOK:     shelterOK,
		HazardOK:      hazardOK,
		PriorityOK:    priorityOK,
		PriorityFloor: doc.PriorityFloor,
		PeakCap:       doc.PeakCap,
	}
}
