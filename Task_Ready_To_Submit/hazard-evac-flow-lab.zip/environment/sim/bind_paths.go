package sim

import "lab.local/evac_flow/flow"
import "lab.local/evac_flow/graph"

func pathsFor(g *graph.Graph, from string, to string, k int) [][]string {
	return graph.OpPath(g, from, to, k)
}

func splitFlow(total int, lens []int, caps []int) []int {
	return flow.OpSplit(total, lens, caps)
}
