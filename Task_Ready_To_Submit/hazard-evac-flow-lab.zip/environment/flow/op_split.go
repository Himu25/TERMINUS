package flow

// OpSplit is the exported entry for the planner.
func OpSplit(total int, pathLens []int, caps []int) []int {
	return op_split(total, pathLens, caps)
}

// op_split spreads population across paths using capacity headroom.
func op_split(total int, pathLens []int, caps []int) []int {
	if total <= 0 || len(pathLens) == 0 {
		return nil
	}
	out := make([]int, len(pathLens))
	out[0] = total
	return out
}
