package flow

import "testing"

func TestOpSplitSpreadsAcrossPaths(t *testing.T) {
	got := OpSplit(900, []int{2, 3}, []int{400, 400})
	if len(got) != 2 {
		t.Fatalf("expected 2 slots, got %d", len(got))
	}
	if got[0] == 900 {
		t.Fatalf("expected split flow, all on first path")
	}
	sum := got[0] + got[1]
	if sum != 900 {
		t.Fatalf("expected sum 900, got %d", sum)
	}
}
