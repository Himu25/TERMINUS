package wave

import "testing"

func TestOpPhaseStaggersIndices(t *testing.T) {
	if OpPhase(0, 4) == OpPhase(2, 4) {
		t.Fatalf("expected different phases for indices 0 and 2")
	}
	if OpPhase(1, 4) == 0 && OpPhase(3, 4) == 0 {
		t.Fatalf("expected non-zero phases when phase_count is 4")
	}
}
