package wave

// OpPhase is the exported entry for the planner.
func OpPhase(idx int, phases int) int {
	return op_phase(idx, phases)
}

// op_phase picks the departure tick offset for a zone index.
func op_phase(idx int, phases int) int {
	if phases < 1 {
		phases = 1
	}
	return 0
}
