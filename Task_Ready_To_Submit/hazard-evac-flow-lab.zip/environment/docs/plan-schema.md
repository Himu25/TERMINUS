# Evacuation plan schema

Written to `/app/output/evac_plan.json` after running `/app/bin/evac_planner`.

| Field | Type | Meaning |
|-------|------|---------|
| `schema_tag` | string | Lab schema marker (`tb3-evac-flow-01`) |
| `jam_band` | string | `clear` when peak edge utilization stays below 0.65; `tight` when below the pack `peak_cap`; otherwise `severe` |
| `peak_ratio` | number | Maximum edge utilization ratio observed during replay |
| `shelter_ok` | bool | No shelter receives more evacuees than its capacity |
| `hazard_ok` | bool | No convoy departs through an edge blocked at its departure tick |
| `priority_ok` | bool | Share of vulnerable residents reaching shelter meets the pack `priority_floor` |

`jam_band` must always agree with `peak_ratio` and the active pack's `peak_cap`.

## Fixture grading expectations

When replaying `/app/data/fixtures/`:

| Pack | Expected outcomes |
|------|-------------------|
| `dual_bottleneck.json` | `jam_band` is `tight` (below that pack's `peak_cap`, at or above the clear cutoff); `shelter_ok` is true |
| `late_hazard.json` | `hazard_ok` is true; `jam_band` is `tight`; `peak_ratio` is at least 0.7 |
| `shelter_tight.json` | `shelter_ok` is true; `jam_band` is `tight` |
| `priority_stress.json` | `priority_ok` is true; `jam_band` is `severe`; `peak_ratio` is between 0.95 and 0.99 |

## Stress replays

Grading may mutate the active pack before replay:

- Inflating a zone population enough to overflow shelter capacity must set `shelter_ok` false and `jam_band` to `severe`.
- Collapsing `phase_count` to 1 on the bundled pack must report `jam_band` severe with `peak_ratio` at or above 1.0 while `shelter_ok`, `hazard_ok`, and `priority_ok` stay true.

Back-to-back planner runs on the same pack must emit identical plans.
