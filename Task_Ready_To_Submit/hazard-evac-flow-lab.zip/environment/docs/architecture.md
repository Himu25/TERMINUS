# Evacuation replay architecture

The planner replays zone-ordered departures across a directed road graph. Each zone assigns population to one or more routes toward its designated shelter while hazard blocks edges after configured ticks. Metrics fold edge loads, shelter tallies, hazard crossings, and vulnerable throughput into the public plan JSON.

Packages:

- `graph` — topology and path enumeration
- `flow` — per-path population assignment
- `wave` — departure phase selection
- `prior` — zone processing order
- `hazard` — blocked-edge lookup
- `sim` — pack driver
- `metrics` — outward report mapping
