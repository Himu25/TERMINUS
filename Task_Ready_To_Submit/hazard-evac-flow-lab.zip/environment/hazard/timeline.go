package hazard

// Window returns the first tick when any block in the list activates.
func Window(blocks []Block) int {
	if len(blocks) == 0 {
		return int(1e9)
	}
	min := blocks[0].FromTick
	for _, b := range blocks {
		if b.FromTick < min {
			min = b.FromTick
		}
	}
	return min
}
