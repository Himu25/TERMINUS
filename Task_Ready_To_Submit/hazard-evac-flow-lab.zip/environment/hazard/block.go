package hazard

// Block marks an edge unusable from a tick onward.
type Block struct {
	From     string
	To       string
	FromTick int
}

// OpBlocked reports whether an edge is closed at tick t.
func OpBlocked(blocks []Block, from string, to string, tick int) bool {
	for _, b := range blocks {
		if b.From == from && b.To == to && tick >= b.FromTick {
			return true
		}
	}
	return false
}
