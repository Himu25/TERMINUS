package main

import (
	"encoding/json"
	"os"

	"lab.local/evac_flow/metrics"
	"lab.local/evac_flow/sim"
)

func main() {
	outDir := "/app/output"
	if v := os.Getenv("EVAC_PLANNER_OUT"); v != "" {
		outDir = v
	}
	if err := os.MkdirAll(outDir, 0o755); err != nil {
		panic(err)
	}
	stats := sim.RunPack("/app/data/evac_pack.json")
	rep := metrics.FromStats(stats)
	b, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		panic(err)
	}
	target := outDir + "/evac_plan.json"
	if err := os.WriteFile(target, b, 0o644); err != nil {
		panic(err)
	}
}
