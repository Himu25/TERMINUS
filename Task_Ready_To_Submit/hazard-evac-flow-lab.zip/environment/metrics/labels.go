package metrics

// LabSchemaTag returns the stable schema marker for this lab.
func LabSchemaTag() string {
	return "tb3-evac-flow-01"
}
