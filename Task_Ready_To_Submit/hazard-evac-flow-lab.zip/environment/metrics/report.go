package metrics

// Stats carries raw counters from replay.
type Stats struct {
	PeakRatio       float64
	JamBand         string
	ShelterOK       bool
	HazardOK        bool
	PriorityOK      bool
	PriorityFloor   float64
	PeakCap         float64
}

// Report is the public JSON contract.
type Report struct {
	SchemaTag  string  `json:"schema_tag"`
	JamBand    string  `json:"jam_band"`
	PeakRatio  float64 `json:"peak_ratio"`
	ShelterOK  bool    `json:"shelter_ok"`
	HazardOK   bool    `json:"hazard_ok"`
	PriorityOK bool    `json:"priority_ok"`
}

// FromStats maps counters to outward labels.
func FromStats(s Stats) Report {
	return Report{
		SchemaTag:  LabSchemaTag(),
		JamBand:    s.JamBand,
		PeakRatio:  round3(s.PeakRatio),
		ShelterOK:  s.ShelterOK,
		HazardOK:   s.HazardOK,
		PriorityOK: s.PriorityOK,
	}
}

func round3(v float64) float64 {
	if v < 0 {
		return 0
	}
	return float64(int(v*1000+0.5)) / 1000
}
