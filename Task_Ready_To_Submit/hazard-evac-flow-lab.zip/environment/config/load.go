package config

import (
	"os"
	"strconv"
	"strings"
)

// PhaseCount reads stagger phases from catalog TOML.
func PhaseCount(path string) int {
	data, err := os.ReadFile(path)
	if err != nil {
		return 4
	}
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "phase_count") {
			parts := strings.Split(line, "=")
			if len(parts) == 2 {
				if n, err := strconv.Atoi(strings.TrimSpace(parts[1])); err == nil && n > 0 {
					return n
				}
			}
		}
	}
	return 4
}
