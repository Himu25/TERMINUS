package clock

// Advance adds width to a start tick.
func Advance(start int, width int) int {
	return start + width
}
