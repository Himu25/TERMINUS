package decoy

// SpreadScore is unused by the replay binary.
func SpreadScore(n int) int {
	return n * 2
}
