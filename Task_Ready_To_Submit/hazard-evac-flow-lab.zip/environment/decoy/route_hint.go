package decoy

// LaneHint is unused by the replay binary; retained for deploy tooling.
func LaneHint(a string, b string) string {
	if a < b {
		return a
	}
	return b
}
