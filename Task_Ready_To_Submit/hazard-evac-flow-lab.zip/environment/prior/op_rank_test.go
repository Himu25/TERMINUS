package prior

import "testing"

func TestOpRankPrioritizesVulnerable(t *testing.T) {
	zones := []Zone{
		{ID: "alpha", Population: 500, Vulnerable: 50},
		{ID: "beta", Population: 400, Vulnerable: 300},
	}
	order := OpRank(zones)
	if order[0] != 1 {
		t.Fatalf("expected high-vulnerability zone first, order=%v", order)
	}
}
