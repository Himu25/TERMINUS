package prior

import "sort"

// Zone carries ordering inputs.
type Zone struct {
	ID         string
	Population int
	Vulnerable int
}

// OpRank is the exported entry for the planner.
func OpRank(zones []Zone) []int {
	return op_rank(zones)
}

// op_rank returns zone indices in processing order.
func op_rank(zones []Zone) []int {
	idx := make([]int, len(zones))
	for i := range idx {
		idx[i] = i
	}
	sort.Slice(idx, func(i, j int) bool {
		return zones[idx[i]].ID < zones[idx[j]].ID
	})
	return idx
}
