module lab.local/evac_flow

go 1.22
