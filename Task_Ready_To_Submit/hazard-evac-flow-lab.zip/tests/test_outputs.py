"""Verifier for hazard evacuation flow lab."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Any

import pytest

APP = Path("/app")
OUT = APP / "output"
PLAN = OUT / "evac_plan.json"
BIN = APP / "bin" / "evac_planner"
PACK = APP / "data" / "evac_pack.json"
FIXTURES = APP / "data" / "fixtures"

PUBLIC_KEYS = {
    "schema_tag",
    "jam_band",
    "peak_ratio",
    "shelter_ok",
    "hazard_ok",
    "priority_ok",
}

SUBSYSTEM_PACKAGES = [
    "./graph",
    "./flow",
    "./wave",
    "./prior",
]

CLEAR_PEAK_CUTOFF = 0.65


def run_checked(
    cmd: list[str],
    *,
    env: dict[str, str] | None = None,
    cwd: str | None = None,
    timeout: int = 120,
) -> None:
    result = subprocess.run(
        cmd, text=True, capture_output=True, timeout=timeout, env=env, cwd=cwd, check=False
    )
    if result.returncode != 0:
        raise AssertionError(
            f"command failed: {' '.join(cmd)}\nstdout:\n{result.stdout}\nstderr:\n{result.stderr}"
        )


def run_go_test(pkg: str) -> None:
    env = os.environ.copy()
    env.setdefault("GOWORK", "off")
    run_checked(["go", "test", pkg, "-count=1"], cwd=str(APP), env=env)


def run_planner(out_dir: Path = OUT) -> dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["EVAC_PLANNER_OUT"] = str(out_dir)
    run_checked([str(BIN)], env=env)
    return json.loads((out_dir / "evac_plan.json").read_text(encoding="utf-8"))


def run_planner_with_pack(pack_path: Path, out_dir: Path) -> dict[str, Any]:
    original = PACK.read_text(encoding="utf-8")
    try:
        PACK.write_text(pack_path.read_text(encoding="utf-8"), encoding="utf-8")
        return run_planner(out_dir)
    finally:
        PACK.write_text(original, encoding="utf-8")


def lab_schema_tag() -> str:
    for line in (APP / "metrics" / "labels.go").read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped.startswith('return "tb3-'):
            return stripped.split('"')[1]
    raise AssertionError("LabSchemaTag return not found in labels.go")


def load_pack() -> dict[str, Any]:
    return json.loads(PACK.read_text(encoding="utf-8"))


def pack_peak_cap(pack_path: Path) -> float:
    return float(json.loads(pack_path.read_text(encoding="utf-8"))["peak_cap"])


def run_planner_with_pack_dict(pack: dict[str, Any], out_dir: Path) -> dict[str, Any]:
    original = PACK.read_text(encoding="utf-8")
    try:
        PACK.write_text(json.dumps(pack), encoding="utf-8")
        return run_planner(out_dir)
    finally:
        PACK.write_text(original, encoding="utf-8")


def assert_jam_peak_coherent(rep: dict[str, Any], *, peak_cap: float) -> None:
    """jam_band labels must match peak_ratio bands from plan-schema."""
    band = rep.get("jam_band")
    peak = float(rep["peak_ratio"])
    if band == "clear":
        assert peak < CLEAR_PEAK_CUTOFF
    elif band == "tight":
        assert CLEAR_PEAK_CUTOFF <= peak < peak_cap
    elif band == "severe":
        assert peak >= peak_cap
    else:
        raise AssertionError(f"unknown jam_band {band!r}")


def assert_bundled_completion(rep: dict[str, Any]) -> None:
    assert rep.get("jam_band") == "clear"
    assert rep.get("shelter_ok") is True
    assert rep.get("hazard_ok") is True
    assert rep.get("priority_ok") is True
    assert float(rep["peak_ratio"]) < CLEAR_PEAK_CUTOFF


@pytest.fixture(scope="module")
def plan() -> dict[str, Any]:
    assert BIN.is_file(), "evac_planner binary missing"
    return run_planner()


@pytest.mark.parametrize("pkg", SUBSYSTEM_PACKAGES)
def test_subsystem_unit(pkg: str) -> None:
    """Each planner subsystem must pass direct Go unit tests."""
    run_go_test(pkg)


def test_p01(plan: dict[str, Any]) -> None:
    """Bundled pack declares the lab schema marker from metrics."""
    assert plan.get("schema_tag") == lab_schema_tag()


def test_p02(plan: dict[str, Any]) -> None:
    """Bundled pack keeps corridor utilization in the clear band."""
    assert plan.get("jam_band") == "clear"


def test_p03(plan: dict[str, Any]) -> None:
    """Bundled pack peak ratio stays below the clear threshold."""
    assert isinstance(plan.get("peak_ratio"), (int, float))
    assert float(plan["peak_ratio"]) < 0.65


def test_p04(plan: dict[str, Any]) -> None:
    """Bundled pack assigns evacuees within shelter capacity."""
    assert plan.get("shelter_ok") is True


def test_p05(plan: dict[str, Any]) -> None:
    """Bundled pack avoids hazard-blocked edges at departure."""
    assert plan.get("hazard_ok") is True


def test_p06(plan: dict[str, Any]) -> None:
    """Bundled pack meets vulnerable-resident priority floor."""
    assert plan.get("priority_ok") is True


def test_p07() -> None:
    """Dual bottleneck fixture generalizes jam and shelter fields."""
    rep = run_planner_with_pack(FIXTURES / "dual_bottleneck.json", OUT)
    assert rep.get("jam_band") in {"clear", "tight"}
    assert rep.get("shelter_ok") is True


def test_p08() -> None:
    """Late hazard fixture keeps convoys off blocked bridge lanes."""
    rep = run_planner_with_pack(FIXTURES / "late_hazard.json", OUT)
    assert rep.get("hazard_ok") is True


def test_p09() -> None:
    """Tight shelter fixture stays within hall capacity."""
    rep = run_planner_with_pack(FIXTURES / "shelter_tight.json", OUT)
    assert rep.get("shelter_ok") is True


def test_p10() -> None:
    """Priority stress fixture evacuates vulnerable share above floor."""
    rep = run_planner_with_pack(FIXTURES / "priority_stress.json", OUT)
    assert rep.get("priority_ok") is True


def test_p11(plan: dict[str, Any]) -> None:
    """Plan exposes exactly the six public fields."""
    assert set(plan.keys()) == PUBLIC_KEYS


def test_h01() -> None:
    """Inflated zone population must surface shelter overflow in the plan."""
    pack = load_pack()
    pack["zones"][1]["population"] = 2000
    rep = run_planner_with_pack_dict(pack, OUT)
    assert rep.get("shelter_ok") is False
    assert rep.get("jam_band") == "severe"


def test_h02(plan: dict[str, Any]) -> None:
    """Bundled jam_band label must agree with peak_ratio and pack peak_cap."""
    assert_jam_peak_coherent(plan, peak_cap=float(load_pack()["peak_cap"]))


def test_h03() -> None:
    """Dual bottleneck fixture lands in the tight band below its peak_cap."""
    pack_path = FIXTURES / "dual_bottleneck.json"
    rep = run_planner_with_pack(pack_path, OUT)
    assert rep.get("jam_band") == "tight"
    assert_jam_peak_coherent(rep, peak_cap=pack_peak_cap(pack_path))


def test_h04() -> None:
    """Late hazard fixture routes around the blocked bridge with measurable load."""
    pack_path = FIXTURES / "late_hazard.json"
    rep = run_planner_with_pack(pack_path, OUT)
    assert rep.get("hazard_ok") is True
    assert rep.get("jam_band") == "tight"
    assert float(rep["peak_ratio"]) >= 0.7
    assert_jam_peak_coherent(rep, peak_cap=pack_peak_cap(pack_path))


def test_h05() -> None:
    """Shelter tight fixture keeps utilization in the tight band under peak_cap."""
    pack_path = FIXTURES / "shelter_tight.json"
    rep = run_planner_with_pack(pack_path, OUT)
    assert rep.get("shelter_ok") is True
    assert rep.get("jam_band") == "tight"
    assert_jam_peak_coherent(rep, peak_cap=pack_peak_cap(pack_path))


def test_h06() -> None:
    """Priority stress fixture saturates corridors while still meeting the floor."""
    pack_path = FIXTURES / "priority_stress.json"
    rep = run_planner_with_pack(pack_path, OUT)
    assert rep.get("priority_ok") is True
    assert rep.get("jam_band") == "severe"
    peak = float(rep["peak_ratio"])
    assert 0.95 <= peak <= 0.99
    assert_jam_peak_coherent(rep, peak_cap=pack_peak_cap(pack_path))


def test_h07() -> None:
    """Back-to-back planner runs on the bundled pack emit identical plans."""
    first = run_planner(OUT)
    second = run_planner(OUT)
    assert first == second


def test_h08() -> None:
    """Fixture substitution restores the primary evac pack bytes on disk."""
    before = PACK.read_bytes()
    for name in (
        "dual_bottleneck.json",
        "late_hazard.json",
        "shelter_tight.json",
        "priority_stress.json",
    ):
        _ = run_planner_with_pack(FIXTURES / name, OUT)
    assert PACK.read_bytes() == before


def test_h09() -> None:
    """Bundled pack still clears after exercising every grading fixture."""
    for name in (
        "dual_bottleneck.json",
        "late_hazard.json",
        "shelter_tight.json",
        "priority_stress.json",
    ):
        _ = run_planner_with_pack(FIXTURES / name, OUT)
    assert_bundled_completion(run_planner(OUT))


def test_h10() -> None:
    """Single-phase packs report severe jam while keeping safety flags true."""
    pack = load_pack()
    pack["phase_count"] = 1
    rep = run_planner_with_pack_dict(pack, OUT)
    assert rep.get("jam_band") == "severe"
    assert float(rep["peak_ratio"]) >= 1.0
    assert rep.get("shelter_ok") is True
    assert rep.get("hazard_ok") is True
    assert rep.get("priority_ok") is True
