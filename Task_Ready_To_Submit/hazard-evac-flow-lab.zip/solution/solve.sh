#!/usr/bin/env bash
set -euo pipefail

cd /app

cat > /app/graph/op_path.go <<'EOF'
package graph

import "sort"

// OpPath is the exported entry for the planner.
func OpPath(g *Graph, from string, to string, k int) [][]string {
	return op_path(g, from, to, k)
}

// op_path returns up to k simple routes ordered by length.
func op_path(g *Graph, from string, to string, k int) [][]string {
	if g == nil || from == "" || to == "" {
		return nil
	}
	if k < 1 {
		k = 1
	}
	var paths [][]string
	seen := map[string]bool{}
	base := dijkstra(g, from, to)
	if base == nil {
		return nil
	}
	paths = append(paths, base)
	seen[join(base)] = true
	for i := 0; i < len(base)-1 && len(paths) < k; i++ {
		sub := g.WithoutEdge(base[i], base[i+1])
		alt := dijkstra(sub, from, to)
		if alt == nil {
			continue
		}
		key := join(alt)
		if seen[key] {
			continue
		}
		seen[key] = true
		paths = append(paths, alt)
	}
	sort.Slice(paths, func(i, j int) bool {
		return pathLen(g, paths[i]) < pathLen(g, paths[j])
	})
	if len(paths) > k {
		paths = paths[:k]
	}
	return paths
}

func dijkstra(g *Graph, from string, to string) []string {
	dist := map[string]int{from: 0}
	prev := map[string]string{}
	seen := map[string]bool{}
	for len(seen) < len(g.adj)+1 {
		var cur string
		best := int(1e9)
		for n, d := range dist {
			if seen[n] {
				continue
			}
			if d < best {
				best = d
				cur = n
			}
		}
		if cur == "" {
			break
		}
		if cur == to {
			break
		}
		seen[cur] = true
		for _, e := range g.adj[cur] {
			nd := dist[cur] + e.Len
			if old, ok := dist[e.To]; !ok || nd < old {
				dist[e.To] = nd
				prev[e.To] = cur
			}
		}
	}
	if from == to {
		return []string{from}
	}
	if _, ok := prev[to]; !ok {
		return nil
	}
	var path []string
	for at := to; at != ""; at = prev[at] {
		path = append([]string{at}, path...)
		if at == from {
			break
		}
	}
	if len(path) == 0 || path[0] != from {
		return nil
	}
	return path
}

func pathLen(g *Graph, nodes []string) int {
	if len(nodes) < 2 {
		return 0
	}
	total := 0
	for i := 0; i < len(nodes)-1; i++ {
		found := false
		for _, e := range g.Edges {
			if e.From == nodes[i] && e.To == nodes[i+1] {
				total += e.Len
				found = true
				break
			}
		}
		if !found {
			return int(1e9)
		}
	}
	return total
}

func join(nodes []string) string {
	s := ""
	for _, n := range nodes {
		s += n + "|"
	}
	return s
}
EOF

cat > /app/flow/op_split.go <<'EOF'
package flow

// OpSplit is the exported entry for the planner.
func OpSplit(total int, pathLens []int, caps []int) []int {
	return op_split(total, pathLens, caps)
}

// op_split spreads population across paths using capacity headroom.
func op_split(total int, pathLens []int, caps []int) []int {
	if total <= 0 || len(pathLens) == 0 {
		return nil
	}
	if len(pathLens) == 1 {
		return []int{total}
	}
	weights := make([]float64, len(pathLens))
	sum := 0.0
	for i := range pathLens {
		w := float64(caps[i])
		if pathLens[i] > 0 {
			w /= float64(pathLens[i])
		}
		if w < 1 {
			w = 1
		}
		weights[i] = w
		sum += w
	}
	out := make([]int, len(pathLens))
	rem := total
	for i := 0; i < len(pathLens)-1; i++ {
		share := int(float64(total)*weights[i]/sum + 0.5)
		if share > caps[i] {
			share = caps[i]
		}
		if share > rem {
			share = rem
		}
		out[i] = share
		rem -= share
	}
	out[len(pathLens)-1] = rem
	if out[len(pathLens)-1] < 0 {
		out[len(pathLens)-1] = 0
	}
	return out
}
EOF

cat > /app/wave/op_phase.go <<'EOF'
package wave

// OpPhase is the exported entry for the planner.
func OpPhase(idx int, phases int) int {
	return op_phase(idx, phases)
}

// op_phase picks the departure tick offset for a zone index.
func op_phase(idx int, phases int) int {
	if phases < 1 {
		phases = 1
	}
	return idx % phases
}
EOF

cat > /app/prior/op_rank.go <<'EOF'
package prior

import "sort"

// Zone carries ordering inputs.
type Zone struct {
	ID         string
	Population int
	Vulnerable int
}

// OpRank is the exported entry for the planner.
func OpRank(zones []Zone) []int {
	return op_rank(zones)
}

// op_rank returns zone indices in processing order.
func op_rank(zones []Zone) []int {
	idx := make([]int, len(zones))
	for i := range idx {
		idx[i] = i
	}
	sort.Slice(idx, func(i, j int) bool {
		ri := vulnRatio(zones[idx[i]])
		rj := vulnRatio(zones[idx[j]])
		if ri != rj {
			return ri > rj
		}
		return zones[idx[i]].ID < zones[idx[j]].ID
	})
	return idx
}

func vulnRatio(z Zone) float64 {
	if z.Population <= 0 {
		return 0
	}
	return float64(z.Vulnerable) / float64(z.Population)
}
EOF

mkdir -p /app/bin
go build -buildvcs=false -o /app/bin/evac_planner ./cmd/evac_planner
/app/bin/evac_planner
