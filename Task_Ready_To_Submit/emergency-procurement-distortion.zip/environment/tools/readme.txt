Digest helper: go run -mod=mod /app/tools/digest_cli <args>
Run procurement audit with TB_PROCURE_FIXTURE=1 after build.
