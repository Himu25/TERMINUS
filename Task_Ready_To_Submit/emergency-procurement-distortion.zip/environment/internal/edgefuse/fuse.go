package edgefuse

import (
    "lab.local/procure_distortion/internal/catalog"
    "lab.local/procure_distortion/internal/config"
    "lab.local/procure_distortion/pkg/graph"
    "lab.local/procure_distortion/pkg/lanehint"
)

// Bundle holds merged edges plus bookkeeping counters.
type Bundle struct {
    Edges        []graph.Edge
    StaleWaivers int
    ExemptionHits int
}

// Merge combines catalog, runtime, and overlay inputs into one edge list.
func Merge(inc config.Incident, reg config.RegistryFile, runtime []graph.Edge, hints []config.ExemptionHint) Bundle {
    edges := make([]graph.Edge, 0, len(reg.Edges)+len(runtime)+len(hints))
    stale := 0
    for _, row := range reg.Edges {
        if catalog.OpS(row.AsOf, inc.RegistryCutoff) {
            edges = append(edges, graph.Edge{Provider: row.Provider, Consumer: row.Consumer})
            continue
        }
        stale++
    }
    edges = append(edges, runtime...)
    shadow := 0
    for _, hint := range hints {
        if lanehint.OpH(hint.Lane, hint.Provider != "" && hint.Consumer != "") {
            edges = append(edges, graph.Edge{Provider: hint.Provider, Consumer: hint.Consumer})
            shadow++
        }
    }
    return Bundle{Edges: edges, StaleWaivers: stale, ExemptionHits: shadow}
}
