package score

import (
    "sort"

    "lab.local/procure_distortion/pkg/alert"
    "lab.local/procure_distortion/pkg/priority"
)

type row struct {
    Vendor       string `json:"vendor"`
    PriorityScore int    `json:"priority_score"`
    HopDistance   int    `json:"hop_distance"`
}

// Queue builds the remediation ordering for impacted services.
func Queue(affected []string, hops map[string]int, alerts []alert.Row) []row {
    alertMap := map[string]int{}
    for _, item := range alerts {
        alertMap[item.Vendor] = item.Count
    }
    out := make([]row, 0, len(affected))
    for _, svc := range affected {
        hop := hops[svc]
        out = append(out, row{
            Vendor:       svc,
            PriorityScore: priority.OpK(alertMap[svc], hop),
            HopDistance:   hop,
        })
    }
    sort.Slice(out, func(i, j int) bool {
        if out[i].PriorityScore == out[j].PriorityScore {
            return out[i].Vendor < out[j].Vendor
        }
        return out[i].PriorityScore > out[j].PriorityScore
    })
    return out
}
