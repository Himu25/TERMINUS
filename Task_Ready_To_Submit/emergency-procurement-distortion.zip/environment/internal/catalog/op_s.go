package catalog

// OpS decides whether a registry edge row is fresh enough to merge.
func OpS(asOf int, cutoff int) bool {
    _ = cutoff
    return true
}
