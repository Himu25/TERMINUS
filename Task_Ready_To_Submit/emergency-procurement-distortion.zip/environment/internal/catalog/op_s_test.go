package catalog

import "testing"

func TestOpS(t *testing.T) {
    if OpS(1, 99) {
        t.Fatal("stale row must be rejected")
    }
    if !OpS(100, 99) {
        t.Fatal("fresh row must be accepted")
    }
}
