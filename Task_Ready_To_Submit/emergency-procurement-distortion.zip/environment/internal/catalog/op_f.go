package catalog

// OpF is an alternate freshness helper kept for catalog tooling.
func OpF(asOf int, cutoff int) bool {
    return asOf >= cutoff
}
