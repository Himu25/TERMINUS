package driver

import (
    "bufio"
    "encoding/json"
    "fmt"
    "os"
    "path/filepath"
    "strings"

    "lab.local/procure_distortion/internal/config"
    "lab.local/procure_distortion/internal/engine"
    "lab.local/procure_distortion/pkg/alert"
    "lab.local/procure_distortion/pkg/digest"
    "lab.local/procure_distortion/pkg/graph"
)

type report struct {
    SchemaVersion   string `json:"schema_version"`
    RunID           string `json:"run_id"`
    AnchorProgram     string `json:"anchor_program"`
    AffectedCommitments   int    `json:"affected_commitments"`
    ApprovalDepth int    `json:"approval_depth"`
    ExemptionHits    int    `json:"exemption_hits"`
    StaleWaivers    int    `json:"stale_waivers"`
    SubstitutionCycles      int    `json:"substitution_cycles"`
    RemediationQueue []struct {
        Vendor       string `json:"vendor"`
        PriorityScore int    `json:"priority_score"`
        HopDistance   int    `json:"hop_distance"`
    } `json:"remediation_queue"`
    DigestHex string `json:"digest_hex"`
}

// RunActive replays the pack linked from /app/data/active.
func RunActive(appRoot string) (report, error) {
    return RunPack(filepath.Join(appRoot, "data", "active"))
}

// RunPack replays one fixture directory.
func RunPack(packDir string) (report, error) {
    inc, err := config.LoadIncident(packDir)
    if err != nil {
        return report{}, err
    }
    reg, err := config.LoadRegistry(packDir)
    if err != nil {
        return report{}, err
    }
    runtime, err := loadRuntimeEdges(filepath.Join(packDir, "approval_events.jsonl"))
    if err != nil {
        return report{}, err
    }
    hints, err := loadHints(filepath.Join(packDir, "exemption_lane.jsonl"))
    if err != nil {
        return report{}, err
    }
    alerts, err := loadAlerts(filepath.Join(packDir, "spend_alerts.jsonl"))
    if err != nil {
        return report{}, err
    }
    out := engine.Replay(inc, reg, runtime, hints, alerts)
    queueHead := ""
    if len(out.Queue) > 0 {
        queueHead = out.Queue[0].Vendor
    }
    rep := report{
        SchemaVersion:   "1",
        RunID:           inc.RunID,
        AnchorProgram:     out.AnchorProgram,
        AffectedCommitments:   out.AffectedCommitments,
        ApprovalDepth: out.ApprovalDepth,
        ExemptionHits:    out.ExemptionHits,
        StaleWaivers:    out.StaleWaivers,
        SubstitutionCycles:      out.SubstitutionCycles,
        DigestHex: digest.Hex(
            inc.RunID,
            out.AffectedCommitments,
            out.ApprovalDepth,
            out.ExemptionHits,
            out.StaleWaivers,
            out.SubstitutionCycles,
            queueHead,
        ),
    }
    rep.RemediationQueue = make([]struct {
        Vendor       string `json:"vendor"`
        PriorityScore int    `json:"priority_score"`
        HopDistance   int    `json:"hop_distance"`
    }, len(out.Queue))
    for i, row := range out.Queue {
        rep.RemediationQueue[i].Vendor = row.Vendor
        rep.RemediationQueue[i].PriorityScore = row.PriorityScore
        rep.RemediationQueue[i].HopDistance = row.HopDistance
    }
    return rep, nil
}

// EmitReport writes the JSON artifact.
func EmitReport(path string, rep report) error {
    if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
        return err
    }
    raw, err := json.MarshalIndent(rep, "", "  ")
    if err != nil {
        return err
    }
    raw = append(raw, '\n')
    return os.WriteFile(path, raw, 0o644)
}

func loadRuntimeEdges(path string) ([]graph.Edge, error) {
    f, err := os.Open(path)
    if err != nil {
        if os.IsNotExist(err) {
            return nil, nil
        }
        return nil, err
    }
    defer f.Close()
    out := []graph.Edge{}
    scan := bufio.NewScanner(f)
    for scan.Scan() {
        line := strings.TrimSpace(scan.Text())
        if line == "" {
            continue
        }
        var e graph.Edge
        if err := json.Unmarshal([]byte(line), &e); err != nil {
            return nil, err
        }
        out = append(out, e)
    }
    return out, scan.Err()
}

func loadHints(path string) ([]config.ExemptionHint, error) {
    f, err := os.Open(path)
    if err != nil {
        if os.IsNotExist(err) {
            return nil, nil
        }
        return nil, err
    }
    defer f.Close()
    out := []config.ExemptionHint{}
    scan := bufio.NewScanner(f)
    for scan.Scan() {
        line := strings.TrimSpace(scan.Text())
        if line == "" {
            continue
        }
        var h config.ExemptionHint
        if err := json.Unmarshal([]byte(line), &h); err != nil {
            return nil, err
        }
        out = append(out, h)
    }
    return out, scan.Err()
}

func loadAlerts(path string) ([]alert.Row, error) {
    f, err := os.Open(path)
    if err != nil {
        return nil, err
    }
    defer f.Close()
    out := []alert.Row{}
    scan := bufio.NewScanner(f)
    for scan.Scan() {
        line := strings.TrimSpace(scan.Text())
        if line == "" {
            continue
        }
        var row alert.Row
        if err := json.Unmarshal([]byte(line), &row); err != nil {
            return nil, err
        }
        out = append(out, row)
    }
    if len(out) == 0 {
        return nil, fmt.Errorf("spend_alerts.jsonl empty")
    }
    return out, scan.Err()
}
