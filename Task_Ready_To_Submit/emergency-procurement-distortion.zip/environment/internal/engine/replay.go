package engine

import (
    "lab.local/procure_distortion/internal/config"
    "lab.local/procure_distortion/internal/cycletab"
    "lab.local/procure_distortion/internal/edgefuse"
    "lab.local/procure_distortion/internal/reach"
    "lab.local/procure_distortion/internal/score"
    "lab.local/procure_distortion/pkg/alert"
    "lab.local/procure_distortion/pkg/graph"
)

type queueRow struct {
    Vendor       string `json:"vendor"`
    PriorityScore int    `json:"priority_score"`
    HopDistance   int    `json:"hop_distance"`
}

// Outcome is the folded counters for one pack replay.
type Outcome struct {
    AnchorProgram     string
    AffectedCommitments   int
    ApprovalDepth int
    ExemptionHits    int
    StaleWaivers    int
    SubstitutionCycles      int
    Queue           []queueRow
}

// Replay executes one incident pack through the procurement audit pipeline.
func Replay(inc config.Incident, reg config.RegistryFile, runtime []graph.Edge, hints []config.ExemptionHint, alerts []alert.Row) Outcome {
    merged := edgefuse.Merge(inc, reg, runtime, hints)
    walked := reach.Expand(inc.AnchorProgram, merged.Edges, inc.MaxDepth)
    ranked := score.Queue(walked.Affected, walked.Hops, alerts)
    cycles := cycletab.Count(merged.Edges, inc.SubstitutionCap)

    queue := make([]queueRow, len(ranked))
    for i, row := range ranked {
        queue[i] = queueRow{
            Vendor:       row.Vendor,
            PriorityScore: row.PriorityScore,
            HopDistance:   row.HopDistance,
        }
    }

    return Outcome{
        AnchorProgram:     inc.AnchorProgram,
        AffectedCommitments:   len(walked.Affected),
        ApprovalDepth: walked.MaxHop,
        ExemptionHits:    merged.ExemptionHits,
        StaleWaivers:    merged.StaleWaivers,
        SubstitutionCycles:      cycles,
        Queue:           queue,
    }
}
