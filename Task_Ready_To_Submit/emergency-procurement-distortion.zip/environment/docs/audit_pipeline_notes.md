# Audit pipeline notes

The procurement audit driver merges three edge feeds (registry catalog, approval events, exemption lane overlays), walks approval reach from the anchor program, ranks remediation candidates from delayed-invoice volume, and tallies cyclic supplier-substitution paths through the Rust spanfold cap.

Build with `/app/scripts/build.sh`. Digest tooling lives at `/app/tools/digest_cli`.
