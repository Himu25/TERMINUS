# Procurement platform map

Multi-source spending history for the procurement audit pipeline:

| Source | File | Role |
| --- | --- | --- |
| Approval registry | `registry.json` | Declared upstream/downstream edges with freshness timestamps |
| Emergency events | `approval_events.jsonl` | Observed purchase edges during the crisis window |
| Exemption overlay | `exemption_lane.jsonl` | Temporary waiver sidecars still routing spend |
| Delayed invoices | `spend_alerts.jsonl` | Per-vendor late-invoice volume for remediation ranking |

Replay packs are indexed in `/app/docs/replay_index.txt`. The active symlink target under `/app/data/active/` is what `procure_audit_run` reads when `TB_PROCURE_FIXTURE=1`.

Verifier harness copies the built audit binary to `/tmp/procure_audit_run_verify_bin` for isolated replay runs. Go tests invoke `/usr/local/go/bin/go`.
