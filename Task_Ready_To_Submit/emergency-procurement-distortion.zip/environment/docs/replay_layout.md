# Emergency procurement distortion audit replay layout

Each replay pack under `/app/data/replay/` is a directory containing:

- `incident.json` — run_id, anchor_program, waiver_cutoff, max_depth, substitution_cap
- `registry.json` — approval-chain edges with as_of timestamps
- `approval_events.jsonl` — purchase events observed during the emergency window
- `exemption_lane.jsonl` — optional sidecar rows for temporary crisis exemptions
- `spend_alerts.jsonl` — delayed-invoice counts per impacted vendor

The active pack lives at `/app/data/active/`. Run `/app/bin/procure_audit_run` with `TB_PROCURE_FIXTURE=1` to emit `/app/output/procurement_audit_report.json`.

## Replay merge

Registry rows merge when `as_of` meets `waiver_cutoff`. Approval events append after catalog rows. Exemption-lane rows append when `exemption_lane.jsonl` exists. Edges aim `provider` at `consumer`.

## Reach and scoring

Breadth-first reach from `anchor_program` continues while current hop depth is strictly below `max_depth`. Remediation `priority_score` is delayed-invoice count times one hundred minus hop distance times ten. The remediation queue sorts by descending `priority_score`, then ascending `vendor`.

## Supplier substitutions

Cyclic vendor nodes are collected from merged edges, visited in sorted vendor name order. Each visit folds a running counter through the Rust spanfold cap helper using `substitution_cap`; nodes count while the folded counter stays at or below the cap.

## Report digest

`digest_hex` is lowercase hex SHA-256 of pipe-joined fields in order: `run_id`, `affected_commitments`, `approval_depth`, `exemption_hits`, `stale_waivers`, `substitution_cycles`, and the first remediation queue vendor (empty string when the queue is empty).
