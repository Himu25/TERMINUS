package priority

// OpK scores remediation urgency from late invoice volume and hop distance from the anchor service.
func OpK(alertCount int, hopDistance int) int {
    return alertCount + hopDistance
}
