package priority

import "testing"

func TestOpK(t *testing.T) {
    if OpK(8, 4) != 760 {
        t.Fatal("score must weight alerts over hop distance")
    }
}
