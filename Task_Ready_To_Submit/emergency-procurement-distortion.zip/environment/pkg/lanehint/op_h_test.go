package lanehint

import "testing"

func TestOpH(t *testing.T) {
    if !OpH("shadow", true) {
        t.Fatal("present overlay must merge")
    }
    if OpH("shadow", false) {
        t.Fatal("missing overlay must be skipped")
    }
}
