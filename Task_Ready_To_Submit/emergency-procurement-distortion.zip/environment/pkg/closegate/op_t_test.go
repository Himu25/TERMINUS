package closegate

import "testing"

func TestGateT(t *testing.T) {
    if !GateT(0, 4) {
        t.Fatal("depth zero should expand when max depth allows")
    }
    if GateT(4, 4) {
        t.Fatal("depth at cap should stop expansion")
    }
}
