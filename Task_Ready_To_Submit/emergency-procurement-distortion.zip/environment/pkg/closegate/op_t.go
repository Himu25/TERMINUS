package closegate

// GateT decides whether graph expansion may continue past the current depth.
func GateT(currentDepth int, maxDepth int) bool {
    if maxDepth <= 0 {
        return false
    }
    if currentDepth < 0 {
        return false
    }
    return currentDepth >= maxDepth
}
