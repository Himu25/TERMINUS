package alert

// Row is one paging row tied to a service name.
type Row struct {
    Vendor string `json:"vendor"`
    Count   int    `json:"count"`
}
