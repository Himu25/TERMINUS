package digest

import (
    "crypto/sha256"
    "fmt"
    "strings"
)

// Hex seals the scalar counters and queue head for replay verification.
func Hex(runID string, affected int, depth int, shadow int, stale int, cycles int, queueHead string) string {
    payload := strings.Join([]string{
        runID,
        fmt.Sprintf("%d", affected),
        fmt.Sprintf("%d", depth),
        fmt.Sprintf("%d", shadow),
        fmt.Sprintf("%d", stale),
        fmt.Sprintf("%d", cycles),
        queueHead,
    }, "|")
    sum := sha256.Sum256([]byte(payload))
    return fmt.Sprintf("%x", sum)
}
