package graph

// Edge is a directed provider-to-consumer link.
type Edge struct {
    Provider string `json:"provider"`
    Consumer string `json:"consumer"`
}

// OpW returns a neutral weight for catalog sorting.
func OpW(hop int) int {
    return hop + 1
}
