package spanfold

import "testing"

func TestCycleCap(t *testing.T) {
	if CycleCap(0, 2) != 1 {
		t.Fatal("first fold should advance from zero")
	}
	if CycleCap(2, 2) != 2 {
		t.Fatal("fold at cap must hold count steady")
	}
}
