#ifndef SPANFOLD_CYCLE_CAP_H
#define SPANFOLD_CYCLE_CAP_H

#include <stdint.h>

int32_t sg_cycle_cap(int32_t visit_count, int32_t limit);

#endif
