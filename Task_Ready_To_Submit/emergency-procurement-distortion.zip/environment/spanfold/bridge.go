package spanfold

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libspanfold.a -ldl -lm
#include "cycle_cap.h"
*/
import "C"

// CycleCap folds visitCount toward limit. When visitCount is already at or above
// limit the counter is returned unchanged.
func CycleCap(visitCount int, limit int) int {
	return int(C.sg_cycle_cap(C.int(visitCount), C.int(limit)))
}
