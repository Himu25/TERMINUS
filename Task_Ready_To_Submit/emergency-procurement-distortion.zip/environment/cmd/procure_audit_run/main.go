package main

import (
	"log"
	"os"

	"lab.local/procure_distortion/internal/driver"
)

func main() {
	if os.Getenv("TB_PROCURE_FIXTURE") != "1" {
		log.Fatal("TB_PROCURE_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/procurement_audit_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
