module lab.local/procure_distortion

go 1.22
