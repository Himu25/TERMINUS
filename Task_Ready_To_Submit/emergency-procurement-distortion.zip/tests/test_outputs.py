"""Verifier for emergency procurement exception audit report."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess

import pytest
from pathlib import Path

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = APP / "data" / "replay"
OUT = APP / "output" / "procurement_audit_report.json"
SCHEMA = APP / "schemas" / "procurement_audit_report.schema.json"
GO_BIN = "/usr/local/go/bin/go"
VERIFY_BIN = "/tmp/procure_audit_run_verify_bin"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:/usr/local/go/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)
    subprocess.run(["cp", "/app/bin/procure_audit_run", VERIFY_BIN], check=True)


def _digest_hex(
    run_id: str,
    affected: int,
    depth: int,
    shadow: int,
    stale: int,
    cycles: int,
    queue_head: str,
) -> str:
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            run_id,
            str(affected),
            str(depth),
            str(shadow),
            str(stale),
            str(cycles),
            queue_head,
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _gate_t(depth: int, max_depth: int) -> bool:
    return depth < max_depth


def _op_s(as_of: int, cutoff: int) -> bool:
    return as_of >= cutoff


def _op_h(_lane: str, present: bool) -> bool:
    return present


def _op_k(alert_count: int, hop_distance: int) -> int:
    return alert_count * 100 - hop_distance * 10


def _cycle_cap(visit_count: int, limit: int) -> int:
    if visit_count >= limit:
        return visit_count
    return visit_count + 1


def _load_pack(pack_dir: Path) -> tuple[dict, list[dict], list[dict], list[dict], list[dict]]:
    inc = json.loads((pack_dir / "incident.json").read_text())
    reg = json.loads((pack_dir / "registry.json").read_text())
    runtime: list[dict] = []
    rt_path = pack_dir / "approval_events.jsonl"
    if rt_path.exists():
        for line in rt_path.read_text().splitlines():
            if line.strip():
                runtime.append(json.loads(line))
    hints: list[dict] = []
    hint_path = pack_dir / "exemption_lane.jsonl"
    if hint_path.exists():
        for line in hint_path.read_text().splitlines():
            if line.strip():
                hints.append(json.loads(line))
    alerts: list[dict] = []
    for line in (pack_dir / "spend_alerts.jsonl").read_text().splitlines():
        if line.strip():
            alerts.append(json.loads(line))
    return inc, reg["edges"], runtime, hints, alerts


def _tally_substitution_cycles(edges: list[dict], limit: int) -> int:
    adj: dict[str, list[str]] = {}
    nodes: set[str] = set()
    for e in edges:
        adj.setdefault(e["provider"], []).append(e["consumer"])
        nodes.add(e["provider"])
        nodes.add(e["consumer"])
    for k in adj:
        adj[k].sort()

    cyclic: set[str] = set()
    for start in nodes:
        stack = [start]
        on_path = {start: 0}

        def walk(pos: int) -> None:
            cur = stack[pos]
            for nxt in adj.get(cur, []):
                if nxt in on_path:
                    idx = on_path[nxt]
                    for i in range(idx, pos + 1):
                        cyclic.add(stack[i])
                    continue
                on_path[nxt] = pos + 1
                stack.append(nxt)
                walk(pos + 1)
                stack.pop()
                del on_path[nxt]

        walk(0)

    if not cyclic:
        return 0
    acc = 0
    count = 0
    for _ in sorted(cyclic):
        acc = _cycle_cap(acc, limit)
        if acc <= limit:
            count += 1
    return count


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = FIXTURES / pack_name
    inc, reg_edges, runtime, hints, alerts = _load_pack(pack_dir)
    cutoff = inc["waiver_cutoff"]
    max_depth = inc.get("max_depth", 8)
    substitution_cap = inc.get("substitution_cap", 2)
    root = inc["anchor_program"]

    edges: list[dict] = []
    stale = 0
    for row in reg_edges:
        if _op_s(row["as_of"], cutoff):
            edges.append({"provider": row["provider"], "consumer": row["consumer"]})
        else:
            stale += 1
    edges.extend(runtime)
    shadow = 0
    for hint in hints:
        present = bool(hint.get("provider")) and bool(hint.get("consumer"))
        if _op_h(hint.get("lane", ""), present):
            edges.append({"provider": hint["provider"], "consumer": hint["consumer"]})
            shadow += 1

    adj: dict[str, list[str]] = {}
    for e in edges:
        adj.setdefault(e["provider"], []).append(e["consumer"])
    for k in adj:
        adj[k].sort()

    hops = {root: 0}
    queue = [root]
    max_hop = 0
    while queue:
        cur = queue.pop(0)
        depth = hops[cur]
        if not _gate_t(depth, max_depth):
            continue
        for nxt in adj.get(cur, []):
            if nxt in hops:
                continue
            nd = depth + 1
            max_hop = max(max_hop, nd)
            hops[nxt] = nd
            queue.append(nxt)

    affected = sorted(s for s in hops if s != root)
    alert_map = {row["vendor"]: row["count"] for row in alerts}
    remediation = []
    for svc in affected:
        hop = hops[svc]
        remediation.append(
            {
                "vendor": svc,
                "priority_score": _op_k(alert_map.get(svc, 0), hop),
                "hop_distance": hop,
            }
        )
    remediation.sort(key=lambda r: (-r["priority_score"], r["vendor"]))
    queue_head = remediation[0]["vendor"] if remediation else ""
    cycles = _tally_substitution_cycles(edges, substitution_cap)
    digest = _digest_hex(
        inc["run_id"],
        len(affected),
        max_hop,
        shadow,
        stale,
        cycles,
        queue_head,
    )
    return {
        "schema_version": "1",
        "run_id": inc["run_id"],
        "anchor_program": root,
        "affected_commitments": len(affected),
        "approval_depth": max_hop,
        "exemption_hits": shadow,
        "stale_waivers": stale,
        "substitution_cycles": cycles,
        "remediation_queue": remediation,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_PROCURE_FIXTURE": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_alpha_report_matches_replay() -> None:
    """Alpha pack should replay with full impact chain and digest."""
    _swap("procure_alpha")
    exp = _expected_from_fixture("procure_alpha")
    got = _run_tool()
    assert got == exp


def test_alpha_downstream_reach() -> None:
    """Alpha should reach three approval hops beyond the anchor program."""
    _swap("procure_alpha")
    exp = _expected_from_fixture("procure_alpha")
    got = _run_tool()
    assert got["approval_depth"] == exp["approval_depth"]
    assert got["affected_commitments"] == exp["affected_commitments"]


def test_beta_retired_row_dropped() -> None:
    """Beta must drop the stale waiver row and keep only the live approval-chain edge."""
    _swap("procure_beta")
    exp = _expected_from_fixture("procure_beta")
    got = _run_tool()
    assert got["stale_waivers"] == exp["stale_waivers"]
    assert got["affected_commitments"] == exp["affected_commitments"]


def test_gamma_exemption_lane_merged() -> None:
    """Gamma should merge the exemption-lane vendor into the impact graph."""
    _swap("procure_gamma")
    exp = _expected_from_fixture("procure_gamma")
    got = _run_tool()
    assert got["exemption_hits"] == exp["exemption_hits"]
    assert got["affected_commitments"] == exp["affected_commitments"]


def test_delta_substitution_cycles_capped() -> None:
    """Delta should cap supplier substitution cycles while still reaching the branch vendor."""
    _swap("procure_delta")
    exp = _expected_from_fixture("procure_delta")
    got = _run_tool()
    assert got["substitution_cycles"] == exp["substitution_cycles"]
    assert got["affected_commitments"] == exp["affected_commitments"]


def test_epsilon_queue_rank_order() -> None:
    """Epsilon should rank the heavier delayed-invoice vendor ahead of the deeper hop."""
    _swap("procure_epsilon")
    exp = _expected_from_fixture("procure_epsilon")
    got = _run_tool()
    assert [row["vendor"] for row in got["remediation_queue"]] == [
        row["vendor"] for row in exp["remediation_queue"]
    ]


def _validate_report_schema(report: dict, schema: dict) -> None:
    for key in schema["required"]:
        assert key in report
    props = schema["properties"]
    assert report["schema_version"] == props["schema_version"]["const"]
    assert isinstance(report["run_id"], str)
    assert isinstance(report["anchor_program"], str)
    for int_key in (
        "affected_commitments",
        "approval_depth",
        "exemption_hits",
        "stale_waivers",
        "substitution_cycles",
    ):
        assert isinstance(report[int_key], int)
    assert isinstance(report["remediation_queue"], list)
    for row in report["remediation_queue"]:
        assert set(row) == {"vendor", "priority_score", "hop_distance"}
        assert isinstance(row["vendor"], str)
        assert isinstance(row["priority_score"], int)
        assert isinstance(row["hop_distance"], int)
    assert re.fullmatch(props["digest_hex"]["pattern"], report["digest_hex"])


def test_report_satisfies_schema() -> None:
    """Emitted report must validate against the procurement audit JSON schema."""
    schema = json.loads(SCHEMA.read_text())
    _swap("procure_alpha")
    got = _run_tool()
    _validate_report_schema(got, schema)


def test_go_subsystem_tests_pass() -> None:
    """Go tests under /app must pass after the repair."""
    subprocess.run(
        [GO_BIN, "test", "./..."],
        cwd="/app",
        env={
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:/usr/local/go/bin:" + os.environ.get("PATH", ""),
        },
        check=True,
    )
