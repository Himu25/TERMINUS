"""Verifier for multi-stage pipeline audit emission."""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

APP = Path("/app")
REPORT = APP / "output" / "pipeline_audit.json"


def _stem_tag(stem: str) -> str:
    bundle = json.loads((APP / "cases" / f"{stem}.json").read_text(encoding="utf-8"))
    return str(bundle["scenario_label"])


def _drive(stem: str) -> dict:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    if REPORT.exists():
        REPORT.unlink()
    subprocess.run(
        ["/app/bin/flowdrive"],
        cwd=str(APP),
        env={**os.environ, "tb_flow": stem},
        check=True,
    )
    payload = json.loads(REPORT.read_text(encoding="utf-8"))
    assert "scenario_runs" in payload and len(payload["scenario_runs"]) == 1
    row = payload["scenario_runs"][0]
    assert row.get("scenario_tag") == _stem_tag(stem)
    return row


def _assert_row(
    row: dict,
    *,
    published_jobs: int,
    cycle_holds: int,
    claim_stalls: int,
    retry_stuck: int,
    order_skips: int,
) -> None:
    assert row["published_jobs"] == published_jobs
    assert row["cycle_holds"] == cycle_holds
    assert row["claim_stalls"] == claim_stalls
    assert row["retry_stuck"] == retry_stuck
    assert row["order_skips"] == order_skips


def test_flow_alpha() -> None:
    """Three jobs in sequence must all reach the terminal stage."""
    row = _drive("flow_alpha")
    _assert_row(row, published_jobs=3, cycle_holds=0, claim_stalls=0, retry_stuck=0, order_skips=0)


def test_flow_beta() -> None:
    """Priority lane must not break sequence ordering across jobs."""
    row = _drive("flow_beta")
    _assert_row(row, published_jobs=2, cycle_holds=0, claim_stalls=0, retry_stuck=0, order_skips=0)


def test_flow_gamma() -> None:
    """A single job must traverse every stage to completion."""
    row = _drive("flow_gamma")
    _assert_row(row, published_jobs=1, cycle_holds=0, claim_stalls=0, retry_stuck=0, order_skips=0)


def test_flow_cycle() -> None:
    """Unsatisfiable stage prerequisites must not hold jobs after graph repair."""
    row = _drive("flow_cycle")
    _assert_row(row, published_jobs=2, cycle_holds=0, claim_stalls=0, retry_stuck=0, order_skips=0)


def test_flow_race() -> None:
    """Overlapping worker claims must record a stall without blocking after release."""
    row = _drive("flow_race")
    _assert_row(row, published_jobs=1, cycle_holds=0, claim_stalls=1, retry_stuck=0, order_skips=0)


def test_flow_retry() -> None:
    """Exhausted retry budget must not leave jobs in a retry state."""
    row = _drive("flow_retry")
    _assert_row(row, published_jobs=1, cycle_holds=0, claim_stalls=0, retry_stuck=0, order_skips=0)


def test_flow_mixed() -> None:
    """Retry drain must work when multiple jobs are present."""
    row = _drive("flow_mixed")
    _assert_row(row, published_jobs=2, cycle_holds=0, claim_stalls=0, retry_stuck=0, order_skips=0)


def test_flow_order() -> None:
    """Lower sequence numbers must finish before higher ones."""
    row = _drive("flow_order")
    _assert_row(row, published_jobs=2, cycle_holds=0, claim_stalls=0, retry_stuck=0, order_skips=0)


def test_flow_echo() -> None:
    """Sequential claims by the same worker must not count as a stall."""
    row = _drive("flow_echo")
    _assert_row(row, published_jobs=1, cycle_holds=0, claim_stalls=0, retry_stuck=0, order_skips=0)


def test_flow_peak() -> None:
    """Larger pack with overlapping claims and a held slot that still blocks one job."""
    row = _drive("flow_peak")
    _assert_row(row, published_jobs=3, cycle_holds=0, claim_stalls=1, retry_stuck=0, order_skips=0)
