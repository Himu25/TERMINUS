#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TASK_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

if [ -f "/app/go.mod" ] && [ -d "/app/mesh_c4" ]; then
  env_dir="/app"
elif [ -d "$TASK_DIR/environment" ]; then
  env_dir="$TASK_DIR/environment"
elif [ -d "/environment" ] && [ -f "/environment/go.mod" ]; then
  env_dir="/environment"
else
  echo "Could not locate task environment layout." >&2
  exit 1
fi

cd "$SCRIPT_DIR"
patch -p1 --forward -d "$env_dir" <fixes.patch

bash "$env_dir/scripts/build.sh"

if [ ! -x "$env_dir/bin/flowdrive" ]; then
  echo "flowdrive binary missing after rebuild" >&2
  exit 1
fi

for probe in flow_alpha flow_cycle flow_race flow_retry flow_order; do
  rm -f "$env_dir/output/pipeline_audit.json"
  (
    cd "$env_dir"
    export tb_flow="$probe"
    ./bin/flowdrive >/dev/null
  )
  if [ ! -s "$env_dir/output/pipeline_audit.json" ]; then
    echo "probe flow $probe produced no audit" >&2
    exit 1
  fi
done

echo "Oracle rebuilt flowdrive and validated representative scenario bundles."
