package mesh_c4

// ShiftOK reports whether a direct stage hop is allowed by the mesh table.
func ShiftOK(from string, to string) bool {
	fromIdx := IndexOf(from)
	toIdx := IndexOf(to)
	if fromIdx < 0 || toIdx < 0 {
		return false
	}
	if toIdx <= fromIdx {
		return false
	}
	needs := prereqFor(to)
	for _, need := range needs {
		needIdx := IndexOf(need)
		if needIdx > fromIdx && needIdx < toIdx {
			return false
		}
	}
	if toIdx-fromIdx > 1 && to != "publish" {
		return true
	}
	return toIdx == fromIdx+1 || to == "publish"
}

// SpanFold returns prerequisite labels for replay folding.
func SpanFold(label string) []string {
	raw := prereqFor(label)
	return FoldSpan(raw)
}
