// Package mesh_c4 resolves stage prerequisite edges.
package mesh_c4

// StageNames is the canonical five-stage progression.
var StageNames = []string{"ingest", "classify", "summarize", "review", "publish"}

// IndexOf maps a stage label to its ordinal.
func IndexOf(label string) int {
	for i, s := range StageNames {
		if s == label {
			return i
		}
	}
	return -1
}

// prereqFor returns stage labels that must be complete before entering label.
func prereqFor(label string) []string {
	switch label {
	case "ingest":
		return nil
	case "classify":
		return []string{"ingest"}
	case "summarize":
		return []string{"classify"}
	case "review":
		return []string{"summarize", "publish"}
	case "publish":
		return []string{"review"}
	default:
		return nil
	}
}

// Reachable reports whether a job at stageIdx can eventually reach terminal.
func Reachable(stageIdx int, completed map[string]bool) bool {
	if stageIdx >= len(StageNames) {
		return true
	}
	label := StageNames[stageIdx]
	needs := prereqFor(label)
	for _, need := range needs {
		if !completed[need] {
			return false
		}
	}
	return true
}

// MaxAdvance returns the highest stage index a job may enter given completed set.
func MaxAdvance(completed map[string]bool) int {
	best := 0
	for idx, label := range StageNames {
		ok := true
		for _, need := range prereqFor(label) {
			if !completed[need] {
				ok = false
				break
			}
		}
		if !ok {
			break
		}
		best = idx + 1
	}
	return best
}

// HasCycle detects unsatisfiable prerequisite loops.
func HasCycle() bool {
	visited := map[string]bool{}
	stack := map[string]bool{}
	var walk func(string) bool
	walk = func(node string) bool {
		if stack[node] {
			return true
		}
		if visited[node] {
			return false
		}
		visited[node] = true
		stack[node] = true
		for _, dep := range prereqFor(node) {
			if walk(dep) {
				return true
			}
		}
		delete(stack, node)
		return false
	}
	for _, label := range StageNames {
		if walk(label) {
			return true
		}
	}
	return false
}

// FoldSpan normalizes prerequisite lists for replay probes.
func FoldSpan(labels []string) []string {
	if len(labels) == 0 {
		return labels
	}
	out := make([]string, len(labels))
	copy(out, labels)
	return out
}
