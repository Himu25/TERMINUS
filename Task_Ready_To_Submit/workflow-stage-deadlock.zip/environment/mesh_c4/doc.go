// Package mesh_c4 resolves stage prerequisite edges.
package mesh_c4
