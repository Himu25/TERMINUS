hull module placeholder
