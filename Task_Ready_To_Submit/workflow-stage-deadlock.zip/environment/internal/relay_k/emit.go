package relay_k

import (
	"encoding/json"
	"os"
)

// WriteAudit persists one audit row for harness probes.
func WriteAudit(run AuditRun, path string) error {
	out := auditPayload{ScenarioRuns: []AuditRun{run}}
	buf, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, buf, 0o644)
}
