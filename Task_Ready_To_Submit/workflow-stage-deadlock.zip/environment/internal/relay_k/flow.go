package relay_k

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"

	"axbench/mesh_c4"
	"axbench/pack_io"
	"axbench/spool_v9"
	"axbench/ticket_n3"
)

// AuditRun is one scenario row in the audit JSON.
// PublishedJobs counts terminal-stage completions.
// CycleHolds counts jobs blocked by unsatisfiable prerequisite chains.
// ClaimStalls counts overlapping worker claims that never released cleanly.
// RetryStuck counts exhausted retry rows still marked active.
// OrderSkips counts higher-sequence finishes ahead of lower-sequence work.
type AuditRun struct {
	ScenarioTag   string `json:"scenario_tag"`
	PublishedJobs int    `json:"published_jobs"`
	CycleHolds    int    `json:"cycle_holds"`
	ClaimStalls   int    `json:"claim_stalls"`
	RetryStuck    int    `json:"retry_stuck"`
	OrderSkips    int    `json:"order_skips"`
}

type auditPayload struct {
	ScenarioRuns []AuditRun `json:"scenario_runs"`
}

type timedClaim struct {
	MS      int
	JobID   string
	Worker  int
	Release bool
}

func rankRows(rows []pack_io.JobRow) []pack_io.JobRow {
	out := make([]pack_io.JobRow, len(rows))
	copy(out, rows)
	sort.Slice(out, func(i, j int) bool {
		if out[i].JobID != out[j].JobID {
			return out[i].JobID < out[j].JobID
		}
		return out[i].Seq < out[j].Seq
	})
	return out
}

func processClaims(claims []pack_io.ClaimRow) (stalls int, blocked map[string]bool) {
	blocked = map[string]bool{}
	if len(claims) == 0 {
		return 0, blocked
	}
	ticket_n3.Reset()
	timeline := make([]timedClaim, 0, len(claims)*2)
	for _, ev := range claims {
		timeline = append(timeline, timedClaim{
			MS: ev.ClaimMS, JobID: ev.JobID, Worker: ev.Worker, Release: false,
		})
		if ev.ReleaseMS > 0 {
			timeline = append(timeline, timedClaim{
				MS: ev.ReleaseMS, JobID: ev.JobID, Worker: ev.Worker, Release: true,
			})
		}
	}
	sort.Slice(timeline, func(i, j int) bool {
		if timeline[i].MS != timeline[j].MS {
			return timeline[i].MS < timeline[j].MS
		}
		if timeline[i].Release != timeline[j].Release {
			return !timeline[i].Release
		}
		return timeline[i].Worker < timeline[j].Worker
	})
	stalls = 0
	for _, ev := range timeline {
		if ticket_n3.Ticket(ev.JobID, ev.Worker, ev.Release) > 0 {
			stalls++
		}
	}
	for _, ev := range claims {
		if ticket_n3.Held(ev.JobID) {
			blocked[ev.JobID] = true
		}
	}
	return stalls, blocked
}

func advanceJob() int {
	completed := map[string]bool{}
	for _, label := range mesh_c4.StageNames {
		completed[label] = false
	}
	stageIdx := 0
	for stageIdx < len(mesh_c4.StageNames)-1 {
		from := mesh_c4.StageNames[stageIdx]
		to := mesh_c4.StageNames[stageIdx+1]
		if !mesh_c4.ShiftOK(from, to) {
			break
		}
		completed[from] = true
		stageIdx++
	}
	if stageIdx < len(mesh_c4.StageNames)-1 {
		return stageIdx
	}
	completed[mesh_c4.StageNames[stageIdx]] = true
	return mesh_c4.MaxAdvance(completed)
}

func simulate(bundle pack_io.Bundle) AuditRun {
	ordered := rankRows(bundle.Jobs)
	cycleHolds := 0
	if mesh_c4.HasCycle() {
		cycleHolds = len(bundle.Jobs)
	}

	claimStalls, claimBlock := processClaims(bundle.Claims)

	retryBlock := map[string]bool{}
	retryAttempts := make([]int, 0, len(bundle.Retries))
	retryTokens := make([]int, 0, len(bundle.Retries))
	for _, row := range bundle.Retries {
		retryAttempts = append(retryAttempts, row.Attempt)
		retryTokens = append(retryTokens, row.Token)
		if spool_v9.DrainRetry(row.Attempt, bundle.RetryCap, row.Token) {
			retryBlock[row.JobID] = true
		}
	}
	retryStuck := spool_v9.StuckJobs(retryAttempts, retryTokens, bundle.RetryCap)

	published := 0
	orderSkips := 0
	maxSeqPublished := -1

	for _, job := range ordered {
		if cycleHolds > 0 {
			continue
		}
		if claimBlock[job.JobID] {
			continue
		}
		if retryBlock[job.JobID] {
			continue
		}

		if advanceJob() >= len(mesh_c4.StageNames) {
			if maxSeqPublished >= 0 && job.Seq < maxSeqPublished {
				orderSkips++
			}
			if job.Seq > maxSeqPublished {
				maxSeqPublished = job.Seq
			}
			published++
		}
	}

	return AuditRun{
		ScenarioTag:   bundle.ScenarioLabel,
		PublishedJobs: published,
		CycleHolds:    cycleHolds,
		ClaimStalls:   claimStalls,
		RetryStuck:    retryStuck,
		OrderSkips:    orderSkips,
	}
}

// Run loads one pack via tb_flow and writes /app/output/pipeline_audit.json.
func Run() error {
	stem := os.Getenv("tb_flow")
	if stem == "" {
		return errors.New("tb_flow must name a stem under /app/cases")
	}
	emit := "/app/output/pipeline_audit.json"
	raw, err := os.ReadFile(filepath.Join("/app", "cases", stem+".json"))
	if err != nil {
		return err
	}
	var bundle pack_io.Bundle
	if err := json.Unmarshal(raw, &bundle); err != nil {
		return err
	}
	run := simulate(bundle)
	out := auditPayload{ScenarioRuns: []AuditRun{run}}
	if err := os.MkdirAll(filepath.Dir(emit), 0o755); err != nil {
		return err
	}
	buf, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		return err
	}
	tmp := emit + ".tmp"
	if err := os.WriteFile(tmp, buf, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, emit)
}

// MainExit is the cmd entry wrapper.
func MainExit() int {
	if err := Run(); err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		return 1
	}
	return 0
}
