package pack_io

// JobRow is one unit of work in a scenario pack.
type JobRow struct {
	JobID string `json:"job_id"`
	Seq   int    `json:"seq"`
	Lane  string `json:"lane"`
}

// ClaimRow is one queue claim or release event.
type ClaimRow struct {
	JobID     string `json:"job_id"`
	Worker    int    `json:"worker"`
	ClaimMS   int    `json:"claim_ms"`
	ReleaseMS int    `json:"release_ms"`
}

// RetryRow tracks retry attempts for one job.
type RetryRow struct {
	JobID   string `json:"job_id"`
	Attempt int    `json:"attempt"`
	Token   int    `json:"token"`
}

// Bundle is one scenario pack under /app/cases.
type Bundle struct {
	ScenarioLabel string     `json:"scenario_label"`
	Jobs          []JobRow   `json:"jobs"`
	Claims        []ClaimRow `json:"claims"`
	Retries       []RetryRow `json:"retries"`
	RetryCap      int        `json:"retry_cap"`
}
