# Flow bench

Mixed Go and Rust driver for scenario replay under `/app/cases`.

Build: `/app/scripts/build.sh`
Run: `tb_flow=<stem> /app/bin/flowdrive`
