station module placeholder
