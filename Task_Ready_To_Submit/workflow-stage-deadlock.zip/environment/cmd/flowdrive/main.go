package main

import (
	"os"

	"axbench/internal/relay_k"
)

// flowdrive replays one scenario bundle named by tb_flow.
// Audit JSON exposes scenario_tag, published_jobs, cycle_holds,
// claim_stalls, retry_stuck, and order_skips per the relay_k audit struct.
func main() {
	os.Exit(relay_k.MainExit())
}
