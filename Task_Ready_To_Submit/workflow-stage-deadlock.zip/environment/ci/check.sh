#!/bin/bash
set -euo pipefail
export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
cd /app
bash /app/scripts/build.sh
test -x /app/bin/flowdrive
