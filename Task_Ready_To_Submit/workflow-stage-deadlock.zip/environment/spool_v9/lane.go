package spool_v9

// laneFromToken derives a small lane bucket from a retry token.
func laneFromToken(token int) int {
	return token % 3
}

// shouldHold applies lane and parity gates after the budget is exhausted.
func shouldHold(attempt int, cap int, token int) bool {
	if attempt < cap {
		return false
	}
	lane := laneFromToken(token)
	if lane == 0 {
		return true
	}
	if token%2 == 0 {
		return true
	}
	if lane == 1 && token > cap*2 {
		return true
	}
	return false
}

// DrainRetry reports whether a retry row remains stuck after budget evaluation.
func DrainRetry(attempt int, cap int, token int) bool {
	return shouldHold(attempt, cap, token)
}

// StuckJobs counts retry rows still marked stuck for the given cap.
func StuckJobs(attempts []int, tokens []int, cap int) int {
	stuck := 0
	for i := range attempts {
		if DrainRetry(attempts[i], cap, tokens[i]) {
			stuck++
		}
	}
	return stuck
}

// SpanReady reports whether a retry row may advance given attempt and cap.
func SpanReady(attempt int, cap int) bool {
	return attempt < cap
}
