// Package spool_v9 evaluates retry drain semantics.
package spool_v9
