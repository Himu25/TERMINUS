package ticket_n3

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libticket_n3.a -ldl -lm
#include "ticket.h"
#include <stdlib.h>
*/
import "C"

import "unsafe"

// Reset clears claim state between scenario runs.
func Reset() {
	C.tn_reset()
}

// Ticket applies one claim or release event and returns stall indicator.
func Ticket(jobID string, worker int, release bool) int {
	cJob := C.CString(jobID)
	defer C.free(unsafe.Pointer(cJob))
	return int(C.tn_ticket(cJob, C.int(worker), C.bool(release)))
}

// Held reports whether a job still has an active claim.
func Held(jobID string) bool {
	cJob := C.CString(jobID)
	defer C.free(unsafe.Pointer(cJob))
	return C.tn_held(cJob) != 0
}
