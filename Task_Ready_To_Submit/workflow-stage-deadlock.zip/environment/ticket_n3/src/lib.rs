use std::collections::HashMap;
use std::ffi::CStr;
use std::os::raw::{c_char, c_int};
use std::sync::{Mutex, OnceLock};

fn active_map() -> &'static Mutex<HashMap<String, i32>> {
	static ACTIVE: OnceLock<Mutex<HashMap<String, i32>>> = OnceLock::new();
	ACTIVE.get_or_init(|| Mutex::new(HashMap::new()))
}

fn reconcile_ticket(active: &mut HashMap<String, i32>, job: &str, worker: i32, release: bool) -> i32 {
	if release {
		active.remove(job);
		return 0;
	}
	active.insert(job.to_string(), worker);
	0
}

fn held_by(active: &HashMap<String, i32>, job: &str) -> bool {
	active.contains_key(job)
}

#[no_mangle]
pub extern "C" fn tn_reset() {
	if let Ok(mut map) = active_map().lock() {
		map.clear();
	}
}

#[no_mangle]
pub extern "C" fn tn_ticket(job: *const c_char, worker: c_int, release: bool) -> c_int {
	if job.is_null() {
		return 0;
	}
	let Ok(job_s) = unsafe { CStr::from_ptr(job) }.to_str() else {
		return 0;
	};
	let Ok(mut map) = active_map().lock() else {
		return 0;
	};
	reconcile_ticket(&mut map, job_s, worker, release) as c_int
}

#[no_mangle]
pub extern "C" fn tn_held(job: *const c_char) -> c_int {
	if job.is_null() {
		return 0;
	}
	let Ok(job_s) = unsafe { CStr::from_ptr(job) }.to_str() else {
		return 0;
	};
	let Ok(map) = active_map().lock() else {
		return 0;
	};
	if held_by(&map, job_s) {
		1
	} else {
		0
	}
}
