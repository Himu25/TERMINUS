#pragma once

#include <stdbool.h>

void tn_reset(void);
int tn_ticket(const char *job, int worker, bool release);
int tn_held(const char *job);
