# Dependencies

Go 1.22, Rust 1.81, CGO enabled for ticket_n3 staticlib.
