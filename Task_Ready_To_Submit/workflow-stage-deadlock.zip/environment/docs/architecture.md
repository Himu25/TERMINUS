# Architecture

The flow driver under `/app/cmd/flowdrive` loads scenario bundles, ranks work rows,
evaluates mesh prerequisite edges, replays claim timelines, drains retry rows,
and writes `/app/output/pipeline_audit.json`.

Components:
- `pack_io` — bundle parsing
- `mesh_c4` — stage edge table
- `ticket_n3` — Rust claim arbitration via CGO
- `spool_v9` — retry drain helpers
- `internal/relay_k` — scenario replay orchestration
