# Contract notes

Audit rows expose `published_jobs`, `cycle_holds`, `claim_stalls`, `retry_stuck`,
and `order_skips` per scenario tag. After a correct repair, `cycle_holds`,
`retry_stuck`, and `order_skips` are zero in every scenario; `claim_stalls` may
be nonzero when a scenario exercises overlapping claims. See
`/app/schemas/audit.schema.json` for shape.
