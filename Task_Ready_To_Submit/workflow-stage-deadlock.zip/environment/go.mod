module axbench

go 1.22
