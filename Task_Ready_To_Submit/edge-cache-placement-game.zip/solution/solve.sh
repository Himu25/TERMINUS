#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/pkg/slotfold/op_f.go <<'EOF'
package slotfold

// OpF returns the per-pop floor slice from a global pool.
func OpF(global uint32, live int, total int) uint32 {
	if live <= 0 {
		return 0
	}
	_ = total
	return global / uint32(live)
}
EOF

cat > /app/pkg/populnorm/op_d.go <<'EOF'
package populnorm

// OpD weights pop demand for remainder distribution.
func OpD(demand uint32) uint32 {
	if demand == 0 {
		return 1
	}
	return demand
}
EOF

cat > /app/pkg/viewfold/op_y.go <<'EOF'
package viewfold

// OpY selects the coordinator epoch visible to a pop.
func OpY(current uint32, lag uint32) uint32 {
	if lag >= current {
		return 1
	}
	return current - lag
}
EOF

cat > /app/internal/vacate/reclaim.go <<'EOF'
package vacate

// OpR returns slot units recovered when a pop drops offline.
func OpR(tokens uint32, goingOffline bool) uint32 {
	if !goingOffline {
		return 0
	}
	return tokens
}
EOF

cat > /app/foldcore/src/lib.rs <<'EOF'
#[no_mangle]
pub extern "C" fn fc_apply_k(tokens: i64, refill: i64, cap: i64) -> i64 {
    if refill == 0 {
        return tokens;
    }
    let mut out = tokens + refill;
    if out > cap {
        out = cap;
    }
    if out < 0 {
        out = 0;
    }
    out
}
EOF

bash /app/scripts/build.sh

rm -f /app/output/placement_report.json
mkdir -p /app/output
TB_EDGE_FIXTURE=1 /app/bin/edge_placer
test -s /app/output/placement_report.json
