package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
)

func main() {
	if len(os.Args) != 12 {
		fmt.Fprintln(os.Stderr, "usage: digest_cli grid_id epochs hits misses idle balance surge drain stale pops origin_ms")
		os.Exit(2)
	}
	payload := fmt.Sprintf(
		"%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s",
		os.Args[1], os.Args[2], os.Args[3], os.Args[4], os.Args[5],
		os.Args[6], os.Args[7], os.Args[8], os.Args[9], os.Args[10], os.Args[11],
	)
	sum := sha256.Sum256([]byte(payload))
	fmt.Println(hex.EncodeToString(sum[:]))
}
