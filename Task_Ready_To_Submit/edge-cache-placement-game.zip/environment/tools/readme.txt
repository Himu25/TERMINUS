Digest helper for placement report fingerprinting at /app/tools/digest_cli.
