// Report JSON for /app/output/placement_report.json.
// Replay folding rules: /app/docs/placement_contract.md
//
// schema_version — string, must be "1"
// grid_id — string, echoes active grid plan name
// epochs_run — highest traffic epoch included in replay
// hits_total — object requests served from local edge slots
// misses_total — requests that fell through to origin fetch
// idle_slots — placement capacity left unused after serving
// balance_ok_flag — string, "yes" or "no"; grading rule in placement_contract.md
// surge_absorbed — hit volume above steady baseline at base_epoch
// drain_reclaims — slot units reclaimed when pops go offline
// stale_view_epochs — epochs where lagged placement differed from live grant
// pops_live — edge pops contributing to the final epoch replay
// origin_latency_ms — sum of misses times per-region origin round-trip ms
// digest_hex — lowercase hex SHA-256 of grid_id|epochs_run|hits_total|misses_total|idle_slots|balance_ok_flag|surge_absorbed|drain_reclaims|stale_view_epochs|pops_live|origin_latency_ms
//
// Root object contains only these keys.
package main

import (
	"log"
	"os"

	"lab.local/edge_cache_placement_game/internal/driver"
)

func main() {
	if os.Getenv("TB_EDGE_FIXTURE") != "1" {
		log.Fatal("TB_EDGE_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/placement_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
