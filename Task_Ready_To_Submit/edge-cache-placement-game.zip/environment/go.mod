module lab.local/edge_cache_placement_game

go 1.22
