# Edge placement replay contract

Normative rules for folding `/app/data/active` into
`/app/output/placement_report.json`. The driver replays every traffic epoch
from `grid_plan.json` and regional `shard_001.jsonl` rows in ascending epoch
order.

## Live pops and offline drain

A pop is live in epoch E when its region `offline_epoch` is zero or E is
strictly before that epoch. When a pop transitions from live to offline,
every slot unit still held in its local pool is reclaimed into `drain_reclaims`
and its pool resets to zero.

## Coordinator slot grants

For each epoch, split `global_slots` across live pops:

1. Assign each live pop the same floor share: `global_slots // live_count`
   (zero when no pops are live).
2. Distribute any leftover slots one at a time to live pops with the highest
   current-epoch demand weight. Demand zero counts as weight one. Break ties
   by pop id ascending.
3. Remember each epoch's grant map for lagged lookups below.

## Lagged coordinator view

Each pop's visible coordinator epoch is the current epoch minus the sum of
`sync_delay_epochs` from the grid plan and `sync_lag_epochs` from its region
profile. When that lag is at or beyond the current epoch, the visible epoch is
epoch 1 (never earlier than 1). The pop serves traffic using the slot grant
from its visible epoch; if the visible epoch differs from the current epoch
and the visible grant differs from the live grant, count one
`stale_view_epochs`.

## Surge refill and admission

Before admitting traffic each epoch, fold `surge_refill` into the pop's slot
pool through the Rust surge helper linked at build time: add refill when
non-zero, then clamp the pool to `surge_cap`, never below zero. Add the
visible-epoch grant to the pool, then admit `min(demand, pool)` requests.
Subtract admits from the pool.

- `hits_total` accumulates admits.
- `misses_total` accumulates unmet demand.
- `idle_slots` accumulates grant capacity left unused after admits
  (`visible_grant - admit` when positive).
- `origin_latency_ms` adds `misses * origin_ms` for the pop's region profile.

## Surge absorbed

At `base_epoch`, record each pop's demand as its steady baseline. Later, when
current demand exceeds that positive baseline, count admits above the baseline
portion toward `surge_absorbed`.

## Balance flag

`balance_ok_flag` is `yes` when fewer than two pops recorded positive total
admits across the replay, or when the smallest positive pop admit total is at
least half the largest positive pop admit total; otherwise `no`.

## Report fields

- `schema_version` — string `"1"`.
- `grid_id` — echoes the active `grid_plan.json` name.
- `epochs_run` — highest traffic epoch in the replay.
- `pops_live` — live pop count in the final epoch.
- `digest_hex` — lowercase hex SHA-256 of the pipe-joined tuple
  `grid_id|epochs_run|hits_total|misses_total|idle_slots|balance_ok_flag|surge_absorbed|drain_reclaims|stale_view_epochs|pops_live|origin_latency_ms`.

The root JSON object contains only the thirteen documented keys.
