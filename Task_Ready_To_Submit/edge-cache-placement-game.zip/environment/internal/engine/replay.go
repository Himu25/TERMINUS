package engine

import (
	"lab.local/edge_cache_placement_game/internal/config"
	"lab.local/edge_cache_placement_game/internal/merge"
	"lab.local/edge_cache_placement_game/pkg/popnode"
	"lab.local/edge_cache_placement_game/pkg/region"
)

// Replay executes one grid plan through the placement stage.
func Replay(plan config.Plan, profiles []region.Profile, rows []popnode.Row) merge.Outcome {
	return merge.PlaceGrid(
		plan.GlobalSlots,
		plan.SurgeCap,
		plan.SurgeRefill,
		plan.SyncDelayEpochs,
		plan.BaseEpoch,
		plan.PopTotal,
		profiles,
		rows,
	)
}
