package config

import (
	"encoding/json"
	"os"
	"path/filepath"

	"lab.local/edge_cache_placement_game/pkg/popnode"
	"lab.local/edge_cache_placement_game/pkg/region"
)

// Plan describes one edge placement grid scenario root.
type Plan struct {
	GridID           string   `json:"grid_id"`
	GlobalSlots      uint32   `json:"global_slots"`
	SurgeCap         uint32   `json:"surge_cap"`
	SurgeRefill      uint32   `json:"surge_refill"`
	SyncDelayEpochs  uint32   `json:"sync_delay_epochs"`
	BaseEpoch        uint32   `json:"base_epoch"`
	PopTotal        int      `json:"pop_total"`
	Regions          []string `json:"regions"`
}

// ActivePaths resolves the bundled active plan directory.
func ActivePaths(root string) (string, error) {
	return filepath.Join(root, "data", "active"), nil
}

// LoadPlan reads grid_plan.json and regional shard trees.
func LoadPlan(dir string) (Plan, []region.Profile, []popnode.Row, error) {
	raw, err := os.ReadFile(filepath.Join(dir, "grid_plan.json"))
	if err != nil {
		return Plan{}, nil, nil, err
	}
	var doc Plan
	if err := json.Unmarshal(raw, &doc); err != nil {
		return Plan{}, nil, nil, err
	}
	profiles := make([]region.Profile, 0, len(doc.Regions))
	rows := make([]popnode.Row, 0, 128)
	for _, rid := range doc.Regions {
		metaPath := filepath.Join(dir, "regions", rid, "region_meta.json")
		metaRaw, err := os.ReadFile(metaPath)
		if err != nil {
			return Plan{}, nil, nil, err
		}
		var prof region.Profile
		if err := json.Unmarshal(metaRaw, &prof); err != nil {
			return Plan{}, nil, nil, err
		}
		profiles = append(profiles, prof)
		seg := filepath.Join(dir, "regions", rid, "shard_001.jsonl")
		data, err := os.ReadFile(seg)
		if err != nil {
			if os.IsNotExist(err) {
				continue
			}
			return Plan{}, nil, nil, err
		}
		for _, line := range splitLines(string(data)) {
			if line == "" {
				continue
			}
			var row popnode.Row
			if err := json.Unmarshal([]byte(line), &row); err != nil {
				continue
			}
			row.Region = rid
			rows = append(rows, row)
		}
	}
	return doc, profiles, rows, nil
}

func splitLines(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			out = append(out, s[start:i])
			start = i + 1
		}
	}
	if start < len(s) {
		out = append(out, s[start:])
	}
	return out
}
