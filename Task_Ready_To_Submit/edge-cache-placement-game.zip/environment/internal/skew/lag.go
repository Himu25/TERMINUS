package skew

// LagSum folds grid-wide and regional sync lag into one band.
func LagSum(gridLag uint32, regionLag uint32) uint32 {
	return gridLag + regionLag
}
