package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"

	"lab.local/edge_cache_placement_game/internal/config"
	"lab.local/edge_cache_placement_game/internal/engine"
)

// Report is the outward JSON document.
type Report struct {
	SchemaVersion     string `json:"schema_version"`
	GridID            string `json:"grid_id"`
	EpochsRun         uint32 `json:"epochs_run"`
	HitsTotal         uint32 `json:"hits_total"`
	MissesTotal       uint32 `json:"misses_total"`
	IdleSlots         uint32 `json:"idle_slots"`
	BalanceOKFlag     string `json:"balance_ok_flag"`
	SurgeAbsorbed     uint32 `json:"surge_absorbed"`
	DrainReclaims     uint32 `json:"drain_reclaims"`
	StaleViewEpochs   uint32 `json:"stale_view_epochs"`
	PopsLive          uint32 `json:"pops_live"`
	OriginLatencyMs   uint32 `json:"origin_latency_ms"`
	DigestHex         string `json:"digest_hex"`
}

// RunActive loads the active grid plan and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	plan, profiles, rows, err := config.LoadPlan(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(plan, profiles, rows)
	digest := sha256.Sum256([]byte(fmt.Sprintf(
		"%s|%d|%d|%d|%d|%s|%d|%d|%d|%d|%d",
		plan.GridID,
		out.EpochsRun,
		out.HitsTotal,
		out.MissesTotal,
		out.IdleSlots,
		out.BalanceOKFlag,
		out.SurgeAbsorbed,
		out.DrainReclaims,
		out.StaleViewEpochs,
		out.PopsLive,
		out.OriginLatencyMs,
	)))
	return Report{
		SchemaVersion:   "1",
		GridID:          plan.GridID,
		EpochsRun:       out.EpochsRun,
		HitsTotal:       out.HitsTotal,
		MissesTotal:     out.MissesTotal,
		IdleSlots:       out.IdleSlots,
		BalanceOKFlag:   out.BalanceOKFlag,
		SurgeAbsorbed:   out.SurgeAbsorbed,
		DrainReclaims:   out.DrainReclaims,
		StaleViewEpochs: out.StaleViewEpochs,
		PopsLive:        out.PopsLive,
		OriginLatencyMs: out.OriginLatencyMs,
		DigestHex:       hex.EncodeToString(digest[:]),
	}, nil
}
