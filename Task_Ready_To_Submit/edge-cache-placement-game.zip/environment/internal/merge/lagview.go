package merge

import "lab.local/edge_cache_placement_game/pkg/viewfold"

// ViewEpoch selects the coordinator epoch visible to a popnode.
func ViewEpoch(current uint32, lag uint32) uint32 {
	return viewfold.OpY(current, lag)
}
