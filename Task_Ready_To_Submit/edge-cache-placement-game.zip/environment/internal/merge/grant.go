package merge

import (
	"sort"

	"lab.local/edge_cache_placement_game/pkg/populnorm"
	"lab.local/edge_cache_placement_game/pkg/slotfold"
)

// BuildSlots folds a global pool into per-pop slot grants.
func BuildSlots(globalSlots uint32, liveIDs []string, popTotal int, demands map[string]uint32) map[string]uint32 {
	base := slotfold.OpF(globalSlots, len(liveIDs), popTotal)
	grants := make(map[string]uint32, len(liveIDs))
	for _, id := range liveIDs {
		grants[id] = base
	}
	remainder := int(globalSlots) - int(base)*len(liveIDs)
	if remainder <= 0 || len(liveIDs) == 0 {
		return grants
	}
	type pair struct {
		id string
		w  uint32
	}
	weights := make([]pair, 0, len(liveIDs))
	for _, id := range liveIDs {
		weights = append(weights, pair{id: id, w: populnorm.OpD(demands[id])})
	}
	sort.Slice(weights, func(i, j int) bool {
		if weights[i].w == weights[j].w {
			return weights[i].id < weights[j].id
		}
		return weights[i].w > weights[j].w
	})
	for i := 0; i < remainder && i < len(weights); i++ {
		grants[weights[i].id]++
	}
	return grants
}
