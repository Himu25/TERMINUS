package merge

import "lab.local/edge_cache_placement_game/foldcore"

// RefillSlots folds surge refill into a pop slot pool.
func RefillSlots(tokens uint32, refill uint32, cap uint32) uint32 {
	next := foldcore.ApplySurge(int64(tokens), int64(refill), int64(cap))
	if next < 0 {
		return 0
	}
	return uint32(next)
}
