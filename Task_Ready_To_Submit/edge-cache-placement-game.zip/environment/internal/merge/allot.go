package merge

import (
	"sort"

	"lab.local/edge_cache_placement_game/internal/vacate"
	"lab.local/edge_cache_placement_game/internal/skew"
	"lab.local/edge_cache_placement_game/pkg/popnode"
	"lab.local/edge_cache_placement_game/pkg/livefold"
	"lab.local/edge_cache_placement_game/pkg/region"
)

// Outcome is the folded placement counters for one grid replay.
type Outcome struct {
	EpochsRun         uint32
	HitsTotal         uint32
	MissesTotal       uint32
	IdleSlots         uint32
	BalanceOKFlag     string
	SurgeAbsorbed     uint32
	DrainReclaims     uint32
	StaleViewEpochs   uint32
	PopsLive          uint32
	OriginLatencyMs   uint32
}

type popMeta struct {
	region     string
	offlineAt  uint32
	regionLag  uint32
	steady     uint32
	tokens     uint32
	wasLive    bool
	totalAdmit uint32
}

// PlaceGrid rebuilds object placement across edge epochs.
func PlaceGrid(
	globalSlots uint32,
	surgeCap uint32,
	surgeRefill uint32,
	syncDelay uint32,
	baseEpoch uint32,
	popTotal int,
	profiles []region.Profile,
	rows []popnode.Row,
) Outcome {
	regionLag := map[string]uint32{}
	offlineAt := map[string]uint32{}
	originMs := map[string]uint32{}
	for _, p := range profiles {
		regionLag[p.RegionID] = p.SyncLagEpochs
		offlineAt[p.RegionID] = p.OfflineEpoch
		originMs[p.RegionID] = p.OriginMs
	}
	nodes := map[string]*popMeta{}
	maxEpoch := uint32(0)
	byEpoch := map[uint32][]popnode.Row{}
	for _, row := range rows {
		byEpoch[row.Epoch] = append(byEpoch[row.Epoch], row)
		if row.Epoch > maxEpoch {
			maxEpoch = row.Epoch
		}
		if _, ok := nodes[row.PopID]; !ok {
			nodes[row.PopID] = &popMeta{region: row.Region, offlineAt: offlineAt[row.Region], regionLag: regionLag[row.Region]}
		}
		if row.Epoch == baseEpoch {
			nodes[row.PopID].steady = row.Demand
		}
	}
	sliceHist := map[uint32]map[string]uint32{}
	var out Outcome
	for epoch := uint32(1); epoch <= maxEpoch; epoch++ {
		liveIDs := make([]string, 0, len(nodes))
		for id, st := range nodes {
			live := livefold.OpL(epoch, st.offlineAt)
			if live {
				liveIDs = append(liveIDs, id)
			} else if st.wasLive {
				out.DrainReclaims += vacate.OpR(st.tokens, true)
				st.tokens = 0
			}
			st.wasLive = live
		}
		sort.Strings(liveIDs)
		demands := map[string]uint32{}
		for _, id := range liveIDs {
			demands[id] = demandAt(byEpoch[epoch], id)
		}
		grants := BuildSlots(globalSlots, liveIDs, popTotal, demands)
		sliceHist[epoch] = grants
		for _, id := range liveIDs {
			st := nodes[id]
			lag := skew.LagSum(syncDelay, st.regionLag)
			viewEpoch := ViewEpoch(epoch, lag)
			if viewEpoch < 1 {
				viewEpoch = 1
			}
			liveGrant := grants[id]
			viewGrant := liveGrant
			if hist, ok := sliceHist[viewEpoch]; ok {
				if g, ok2 := hist[id]; ok2 {
					viewGrant = g
				}
			}
			if viewEpoch != epoch && viewGrant != liveGrant {
				out.StaleViewEpochs++
			}
			st.tokens = RefillSlots(st.tokens, surgeRefill, surgeCap)
			st.tokens += viewGrant
			demand := demands[id]
			admit := demand
			if st.tokens < admit {
				admit = st.tokens
			}
			st.tokens -= admit
			out.HitsTotal += admit
			if demand > admit {
				missed := demand - admit
				out.MissesTotal += missed
				out.OriginLatencyMs += missed * originMs[st.region]
			}
			if viewGrant > admit {
				out.IdleSlots += viewGrant - admit
			}
			st.totalAdmit += admit
			if demand > st.steady && st.steady > 0 {
				baseAdmit := st.steady
				if admit < baseAdmit {
					baseAdmit = admit
				}
				if admit > baseAdmit {
					out.SurgeAbsorbed += admit - baseAdmit
				}
			}
		}
	}
	out.EpochsRun = maxEpoch
	out.PopsLive = uint32(len(liveAt(maxEpoch, nodes)))
	out.BalanceOKFlag = balanceFlag(nodes)
	return out
}

func demandAt(rows []popnode.Row, popID string) uint32 {
	for _, row := range rows {
		if row.PopID == popID {
			return row.Demand
		}
	}
	return 0
}

func liveAt(epoch uint32, nodes map[string]*popMeta) []string {
	out := make([]string, 0, len(nodes))
	for id, st := range nodes {
		if livefold.OpL(epoch, st.offlineAt) {
			out = append(out, id)
		}
	}
	sort.Strings(out)
	return out
}

func balanceFlag(nodes map[string]*popMeta) string {
	var admits []uint32
	for _, st := range nodes {
		if st.totalAdmit > 0 {
			admits = append(admits, st.totalAdmit)
		}
	}
	if len(admits) < 2 {
		return "yes"
	}
	sort.Slice(admits, func(i, j int) bool { return admits[i] < admits[j] })
	minA := admits[0]
	maxA := admits[len(admits)-1]
	if maxA == 0 {
		return "yes"
	}
	if minA*2 >= maxA {
		return "yes"
	}
	return "no"
}
