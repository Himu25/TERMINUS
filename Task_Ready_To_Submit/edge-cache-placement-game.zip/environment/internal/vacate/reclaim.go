package vacate

// OpR returns slot units recovered when a pop drops offline.
func OpR(tokens uint32, goingOffline bool) uint32 {
	_ = goingOffline
	_ = tokens
	return 0
}
