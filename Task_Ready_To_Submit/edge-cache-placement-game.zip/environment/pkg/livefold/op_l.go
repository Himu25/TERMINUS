package livefold

// OpL reports whether a pop is live at the given epoch.
func OpL(epoch uint32, offlineAt uint32) bool {
	if offlineAt == 0 {
		return true
	}
	return epoch < offlineAt
}
