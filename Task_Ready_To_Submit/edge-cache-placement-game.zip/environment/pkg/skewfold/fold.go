package skewfold

// FoldSkew combines two signed offsets for regional clock bands.
func FoldSkew(skew int64, lag int64) int64 {
	return skew - lag
}
