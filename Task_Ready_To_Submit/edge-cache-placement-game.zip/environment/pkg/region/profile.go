package region

// Profile captures per-region edge posture for replay.
type Profile struct {
	RegionID      string `json:"region_id"`
	OfflineEpoch  uint32 `json:"offline_epoch"`
	SyncLagEpochs uint32 `json:"sync_lag_epochs"`
	OriginMs      uint32 `json:"origin_ms"`
}
