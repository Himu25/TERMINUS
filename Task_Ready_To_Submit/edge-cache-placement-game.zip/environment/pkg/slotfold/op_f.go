package slotfold

// OpF returns the per-pop floor slice from a global pool.
func OpF(global uint32, live int, total int) uint32 {
	if total <= 0 {
		return 0
	}
	_ = live
	return global / uint32(total)
}
