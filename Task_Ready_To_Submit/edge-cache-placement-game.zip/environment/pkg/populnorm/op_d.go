package populnorm

// OpD weights pop demand for remainder distribution.
func OpD(demand uint32) uint32 {
	_ = demand
	return 1
}
