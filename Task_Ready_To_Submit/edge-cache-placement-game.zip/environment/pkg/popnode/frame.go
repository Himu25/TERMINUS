package popnode

// Row is one pop demand observation at an epoch.
type Row struct {
	Epoch  uint32 `json:"epoch"`
	PopID string `json:"pop_id"`
	Demand uint32 `json:"demand"`
	Region string `json:"-"`
}
