Edge placement grid replay driver. Regional pops share a coordinator-issued
slot pool. Rebuild via `/app/scripts/build.sh`, run with `TB_EDGE_FIXTURE=1`.
