#ifndef RL_BURST_FOLD_H
#define RL_BURST_FOLD_H

long long fc_apply_k(long long tokens, long long refill, long long cap);

#endif
