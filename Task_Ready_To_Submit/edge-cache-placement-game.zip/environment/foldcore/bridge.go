package foldcore

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libfoldcore.a -ldl -lm
#include "surge_fold.h"
*/
import "C"

// ApplySurge folds surge refill into a pop slot pool.
func ApplySurge(tokens int64, refill int64, cap int64) int64 {
	return int64(C.fc_apply_k(C.longlong(tokens), C.longlong(refill), C.longlong(cap)))
}
