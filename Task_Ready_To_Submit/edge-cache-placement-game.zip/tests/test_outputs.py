"""Verifier for edge cache placement replay report."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = Path("/tests") / "fixtures"
OUT = APP / "output" / "placement_report.json"
VERIFY_BIN = "/app/bin/edge_placer"
GO_BIN = "go"

ORIGIN_MS = {"east": 120, "west": 80, "north": 150, "south": 100}


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _digest_hex(
    grid_id: str,
    epochs_run: int,
    hits: int,
    misses: int,
    idle: int,
    balance: str,
    surge: int,
    drain: int,
    stale: int,
    pops_live: int,
    origin_ms: int,
) -> str:
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            grid_id,
            str(epochs_run),
            str(hits),
            str(misses),
            str(idle),
            balance,
            str(surge),
            str(drain),
            str(stale),
            str(pops_live),
            str(origin_ms),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _op_f(global_q: int, live: int, total: int) -> int:
    if live <= 0:
        return 0
    return global_q // live


def _op_d(demand: int) -> int:
    return demand if demand > 0 else 1


def _op_y(current: int, lag: int) -> int:
    if lag >= current:
        return 1
    return current - lag


def _op_l(epoch: int, offline_at: int) -> bool:
    if offline_at == 0:
        return True
    return epoch < offline_at


def _apply_surge(tokens: int, refill: int, cap: int) -> int:
    if refill == 0:
        return tokens
    out = tokens + refill
    if out > cap:
        out = cap
    return max(0, out)


def _reclaim_offline(tokens: int, going_offline: bool) -> int:
    return tokens if going_offline else 0


def _lag_sum(grid_lag: int, region_lag: int) -> int:
    return grid_lag + region_lag


def _demand_at(rows: list[dict], pop_id: str) -> int:
    for row in rows:
        if row["pop_id"] == pop_id:
            return int(row["demand"])
    return 0


def _load_fixture(pack_name: str) -> tuple[dict, list[dict], list[dict]]:
    pack_dir = FIXTURES / pack_name
    plan = json.loads((pack_dir / "grid_plan.json").read_text())
    profiles: list[dict] = []
    rows: list[dict] = []
    for rid in plan["regions"]:
        meta = json.loads((pack_dir / "regions" / rid / "region_meta.json").read_text())
        profiles.append(meta)
        seg = pack_dir / "regions" / rid / "shard_001.jsonl"
        if not seg.exists():
            continue
        for line in seg.read_text().splitlines():
            if not line.strip():
                continue
            entry = json.loads(line)
            entry["region"] = rid
            rows.append(entry)
    return plan, profiles, rows


def _expected_from_fixture(pack_name: str) -> dict:
    plan, profiles, rows = _load_fixture(pack_name)
    region_lag = {p["region_id"]: int(p.get("sync_lag_epochs", 0)) for p in profiles}
    offline_at = {p["region_id"]: int(p.get("offline_epoch", 0)) for p in profiles}
    origin_ms = {
        p["region_id"]: int(p.get("origin_ms", ORIGIN_MS.get(p["region_id"], 100)))
        for p in profiles
    }
    nodes: dict[str, list] = {}
    max_epoch = 0
    by_epoch: dict[int, list[dict]] = {}
    for row in rows:
        ep = int(row["epoch"])
        by_epoch.setdefault(ep, []).append(row)
        max_epoch = max(max_epoch, ep)
        if row["pop_id"] not in nodes:
            nodes[row["pop_id"]] = [
                offline_at[row["region"]],
                region_lag[row["region"]],
                0,
                0,
                False,
                0,
                row["region"],
            ]
        if ep == int(plan["base_epoch"]):
            nodes[row["pop_id"]][2] = int(row["demand"])

    hits_total = 0
    misses_total = 0
    idle_slots = 0
    surge_absorbed = 0
    drain_reclaims = 0
    stale_view_epochs = 0
    origin_latency_ms = 0
    slice_hist: dict[int, dict[str, int]] = {}

    for epoch in range(1, max_epoch + 1):
        live_ids = sorted(nid for nid, st in nodes.items() if _op_l(epoch, st[0]))
        for st in nodes.values():
            live = _op_l(epoch, st[0])
            if not live and st[4]:
                drain_reclaims += _reclaim_offline(st[3], True)
                st[3] = 0
            st[4] = live

        base = _op_f(int(plan["global_slots"]), len(live_ids), int(plan["pop_total"]))
        grants = {nid: base for nid in live_ids}
        remainder = int(plan["global_slots"]) - base * len(live_ids)
        if remainder > 0 and live_ids:
            weights = sorted(
                ((nid, _op_d(_demand_at(by_epoch.get(epoch, []), nid))) for nid in live_ids),
                key=lambda x: (-x[1], x[0]),
            )
            for i in range(min(remainder, len(weights))):
                grants[weights[i][0]] += 1
        slice_hist[epoch] = dict(grants)

        for nid in live_ids:
            st = nodes[nid]
            lag = _lag_sum(int(plan["sync_delay_epochs"]), st[1])
            view_epoch = _op_y(epoch, lag)
            live_grant = grants[nid]
            view_grant = slice_hist.get(view_epoch, {}).get(nid, live_grant)
            if view_epoch != epoch and view_grant != live_grant:
                stale_view_epochs += 1

            st[3] = _apply_surge(st[3], int(plan["surge_refill"]), int(plan["surge_cap"]))
            st[3] += view_grant
            demand = _demand_at(by_epoch.get(epoch, []), nid)
            admit = min(demand, st[3])
            st[3] -= admit
            hits_total += admit
            if demand > admit:
                missed = demand - admit
                misses_total += missed
                origin_latency_ms += missed * origin_ms[st[6]]
            if view_grant > admit:
                idle_slots += view_grant - admit
            st[5] += admit
            if demand > st[2] > 0:
                base_admit = min(st[2], admit)
                if admit > base_admit:
                    surge_absorbed += admit - base_admit

    pops_live = sum(1 for st in nodes.values() if _op_l(max_epoch, st[0]))
    admits = [st[5] for st in nodes.values() if st[5] > 0]
    if len(admits) < 2:
        balance = "yes"
    else:
        mn, mx = min(admits), max(admits)
        balance = "yes" if mx == 0 or mn * 2 >= mx else "no"

    rep = {
        "schema_version": "1",
        "grid_id": plan["grid_id"],
        "epochs_run": max_epoch,
        "hits_total": hits_total,
        "misses_total": misses_total,
        "idle_slots": idle_slots,
        "balance_ok_flag": balance,
        "surge_absorbed": surge_absorbed,
        "drain_reclaims": drain_reclaims,
        "stale_view_epochs": stale_view_epochs,
        "pops_live": pops_live,
        "origin_latency_ms": origin_latency_ms,
    }
    rep["digest_hex"] = _digest_hex(
        rep["grid_id"],
        rep["epochs_run"],
        rep["hits_total"],
        rep["misses_total"],
        rep["idle_slots"],
        rep["balance_ok_flag"],
        rep["surge_absorbed"],
        rep["drain_reclaims"],
        rep["stale_view_epochs"],
        rep["pops_live"],
        rep["origin_latency_ms"],
    )
    return rep


def _swap_active(pack_name: str) -> None:
    src = FIXTURES / pack_name
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_driver() -> dict:
    OUT.unlink(missing_ok=True)
    env = {**os.environ, "TB_EDGE_FIXTURE": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    return json.loads(OUT.read_text())


PACKS = ["grid_steady", "grid_surge", "grid_drain", "grid_drift", "grid_mix"]


class TestEdgeCachePlacement:
    """Edge placement replay report checks."""

    def test_active_catalog_report(self) -> None:
        """Shipped active grid catalog replays to the reference report."""
        _swap_active("grid_active")
        expected = _expected_from_fixture("grid_active")
        got = _run_driver()
        assert got == expected

    def test_steady_stem_report(self) -> None:
        """Steady regression stem replays to the reference report."""
        _swap_active("grid_steady")
        expected = _expected_from_fixture("grid_steady")
        got = _run_driver()
        for key, val in expected.items():
            assert got[key] == val, f"steady {key}: got {got[key]!r} want {val!r}"

    def test_surge_regional_spike(self) -> None:
        """Surge stem replays with absorbed spike volume and origin latency."""
        _swap_active("grid_surge")
        expected = _expected_from_fixture("grid_surge")
        got = _run_driver()
        assert got["surge_absorbed"] == expected["surge_absorbed"]
        assert got["misses_total"] == expected["misses_total"]
        assert got["origin_latency_ms"] == expected["origin_latency_ms"]
        assert got["digest_hex"] == expected["digest_hex"]

    def test_drain_pop_offline(self) -> None:
        """Offline stem reclaims stranded slots and raises live count."""
        _swap_active("grid_drain")
        expected = _expected_from_fixture("grid_drain")
        got = _run_driver()
        assert got["drain_reclaims"] == expected["drain_reclaims"]
        assert got["pops_live"] == expected["pops_live"]
        assert got["idle_slots"] == expected["idle_slots"]
        assert got["digest_hex"] == expected["digest_hex"]

    def test_drift_changing_demand(self) -> None:
        """Drift stem counts epochs with stale coordinator placement."""
        _swap_active("grid_drift")
        expected = _expected_from_fixture("grid_drift")
        got = _run_driver()
        assert got["stale_view_epochs"] == expected["stale_view_epochs"]
        assert got["stale_view_epochs"] > 0
        assert got["drain_reclaims"] == expected["drain_reclaims"]
        assert got["digest_hex"] == expected["digest_hex"]

    def test_mix_combined_stress(self) -> None:
        """Combined stem balances surge, drain, and drift."""
        _swap_active("grid_mix")
        expected = _expected_from_fixture("grid_mix")
        got = _run_driver()
        assert got == expected

    def test_schema_keys_only(self) -> None:
        """Outward JSON carries only documented keys."""
        _swap_active("grid_steady")
        got = _run_driver()
        allowed = {
            "schema_version",
            "grid_id",
            "epochs_run",
            "hits_total",
            "misses_total",
            "idle_slots",
            "balance_ok_flag",
            "surge_absorbed",
            "drain_reclaims",
            "stale_view_epochs",
            "pops_live",
            "origin_latency_ms",
            "digest_hex",
        }
        assert set(got.keys()) == allowed

    def test_balance_flag_values(self) -> None:
        """Balance flag is yes or no across stems."""
        for pack in PACKS:
            _swap_active(pack)
            got = _run_driver()
            assert got["balance_ok_flag"] in ("yes", "no")

    def test_hits_nonzero_steady(self) -> None:
        """Steady stem serves traffic from edge slots."""
        _swap_active("grid_steady")
        got = _run_driver()
        assert got["hits_total"] > 0

    def test_binary_exists(self) -> None:
        """Driver binary is present at the documented path."""
        assert Path(VERIFY_BIN).is_file()

    def test_fixture_index_stems(self) -> None:
        """Listed regression stems exist under harness fixtures."""
        index = (APP / "docs" / "fixture_index.txt").read_text().splitlines()
        stems = [line.strip() for line in index if line.strip()]
        for stem in stems:
            assert (FIXTURES / stem / "grid_plan.json").is_file()
