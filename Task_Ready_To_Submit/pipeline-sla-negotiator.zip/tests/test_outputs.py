"""Validate sla_plan.json for the pipeline SLA negotiator repair task."""

from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

APP = Path("/app")
OUT = APP / "output" / "sla_plan.json"
CFG = APP / "config" / "windows.toml"
SCENARIOS = APP / "scenarios"

REPORT_KEYS = frozenset(
    {
        "status",
        "window_budget",
        "minutes_used",
        "minutes_slack",
        "pipelines_total",
        "pipelines_met",
        "sla_rate",
        "slack_ratio",
        "dep_breaches",
        "tier_inversions",
        "arrival_absorbed",
        "value_met",
        "plan_digest",
        "pipelines",
    }
)

PIPE_KEYS = frozenset(
    {
        "pipeline_id",
        "owner",
        "tier",
        "minutes_reserved",
        "minutes_used",
        "slack_minutes",
        "met_sla",
        "dep_clear",
        "tier_rank",
        "arrival_wave",
        "value_met",
    }
)


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "window_budget": 15000,
        "min_sla_rate": 0.75,
        "max_slack_ratio": 0.25,
        "max_dep_breaches": 0,
        "max_tier_inversions": 2,
        "min_arrival_absorbed": 3,
        "min_value_met": 8.5,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in ("min_sla_rate", "max_slack_ratio", "min_value_met"):
            cfg[key] = float(val)
        elif key in (
            "window_budget",
            "max_dep_breaches",
            "max_tier_inversions",
            "min_arrival_absorbed",
        ):
            cfg[key] = int(float(val))
    return cfg


def _digest_payload(report: dict) -> dict:
    return {
        "status": report["status"],
        "window_budget": report["window_budget"],
        "minutes_used": report["minutes_used"],
        "minutes_slack": report["minutes_slack"],
        "pipelines_total": report["pipelines_total"],
        "pipelines_met": report["pipelines_met"],
        "sla_rate": report["sla_rate"],
        "slack_ratio": report["slack_ratio"],
        "dep_breaches": report["dep_breaches"],
        "tier_inversions": report["tier_inversions"],
        "arrival_absorbed": report["arrival_absorbed"],
        "value_met": report["value_met"],
        "plan_digest": "",
        "pipelines": report["pipelines"],
    }


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _assert_pipe_row(row: dict) -> None:
    assert set(row) == PIPE_KEYS
    assert isinstance(row["pipeline_id"], str) and row["pipeline_id"]
    assert isinstance(row["owner"], str) and row["owner"]
    assert isinstance(row["tier"], int)
    assert isinstance(row["minutes_reserved"], int)
    assert isinstance(row["minutes_used"], int)
    assert isinstance(row["slack_minutes"], int)
    assert isinstance(row["met_sla"], bool)
    assert isinstance(row["dep_clear"], bool)
    assert isinstance(row["tier_rank"], int) and row["tier_rank"] >= 1
    assert isinstance(row["arrival_wave"], int) and row["arrival_wave"] >= 0
    assert isinstance(row["value_met"], (int, float))


def _assert_report_schema(data: dict) -> None:
    assert set(data) == REPORT_KEYS
    assert data["status"] in {"ok", "fail"}
    for key in (
        "window_budget",
        "minutes_used",
        "minutes_slack",
        "pipelines_total",
        "pipelines_met",
        "dep_breaches",
        "tier_inversions",
        "arrival_absorbed",
    ):
        assert isinstance(data[key], int)
        assert data[key] >= 0
    for key in ("sla_rate", "slack_ratio", "value_met"):
        assert isinstance(data[key], (int, float))
        assert float(data[key]) >= 0.0
    digest = data["plan_digest"]
    assert isinstance(digest, str) and len(digest) == 64
    assert digest == digest.lower()
    assert re.fullmatch(r"[0-9a-f]{64}", digest)
    assert isinstance(data["pipelines"], list)
    for row in data["pipelines"]:
        _assert_pipe_row(row)


def _load_report(path: Path = OUT) -> dict:
    assert path.is_file(), f"missing plan at {path}"
    data = json.loads(path.read_text(encoding="utf-8"))
    _assert_report_schema(data)
    return data


def _load_pipe_specs(path: Path) -> list[dict]:
    rows: list[dict] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            rows.append(json.loads(line))
    return rows


def _assert_tier_ranks_respect_deps(report: dict, specs: list[dict]) -> None:
    by_id = {row["pipeline_id"]: row for row in report["pipelines"]}
    for spec in specs:
        row = by_id[spec["pipeline_id"]]
        for dep_id in spec.get("dep_on", []):
            assert by_id[dep_id]["tier_rank"] < row["tier_rank"], (
                f"{spec['pipeline_id']} must finish after prerequisite {dep_id}"
            )


def _guardrails(report: dict, cfg: dict[str, float | int]) -> None:
    assert report["sla_rate"] >= cfg["min_sla_rate"]
    if report["minutes_used"] > 0:
        assert report["slack_ratio"] <= cfg["max_slack_ratio"]
    assert report["dep_breaches"] <= cfg["max_dep_breaches"]
    assert report["tier_inversions"] <= cfg["max_tier_inversions"]
    assert report["arrival_absorbed"] >= cfg["min_arrival_absorbed"]
    assert report["value_met"] >= cfg["min_value_met"]


def _run_plan(
    pipelines_path: Path,
    out_path: Path,
    *,
    overlay_path: Path | None = None,
) -> dict:
    env = os.environ.copy()
    if overlay_path is not None:
        env["TB_ARRIVAL_OVERLAY"] = str(overlay_path)
    else:
        env.pop("TB_ARRIVAL_OVERLAY", None)
    if out_path.exists():
        out_path.unlink()
    cmd = [
        "/app/bin/slaneg",
        pipelines_path.as_posix(),
        out_path.as_posix(),
    ]
    subprocess.run(cmd, check=True, capture_output=True, text=True, env=env)
    return _load_report(out_path)


class TestPipelineSlaNegotiator:
    def test_default_plan_meets_guardrails(self) -> None:
        """Default bundle report clears windows.toml floors."""
        report = _load_report()
        cfg = _parse_cfg()
        assert report["status"] == "ok"
        assert report["pipelines_total"] == 20
        assert report["pipelines_met"] >= int(cfg["min_sla_rate"] * report["pipelines_total"])
        _guardrails(report, cfg)
        assert report["plan_digest"] == _expected_digest(report)

    def test_row_dep_invariants_on_default(self) -> None:
        """Dependency rows on the default bundle stay ordered and clear."""
        report = _load_report()
        specs = _load_pipe_specs(APP / "data/pipelines_default.jsonl")
        by_id = {row["pipeline_id"]: row for row in report["pipelines"]}
        root = by_id["p_dep_root"]
        leaf = by_id["p_dep_leaf"]
        chain = by_id["p_dep_chain"]
        assert root["dep_clear"] is True and root["met_sla"] is True
        assert leaf["dep_clear"] is True and leaf["met_sla"] is True
        assert chain["dep_clear"] is True and chain["met_sla"] is True
        _assert_tier_ranks_respect_deps(report, specs)

    def test_drift_rows_use_overlay_minutes(self) -> None:
        """Overlay drift pipelines bill the arrival-adjusted minute totals."""
        report = _load_report()
        by_id = {row["pipeline_id"]: row for row in report["pipelines"]}
        alpha = by_id["p_drift_alpha"]
        assert alpha["met_sla"] is True
        assert alpha["minutes_used"] == 720
        beta = by_id["p_drift_beta"]
        assert beta["met_sla"] is True
        assert beta["minutes_used"] == 640

    def test_dep_chain_scenario_pack(self) -> None:
        """Indexed dep-chain pack finishes without dependency breaches."""
        pack = SCENARIOS / "scenario_dep_chain"
        pipelines_path = pack / "pipelines.jsonl"
        out = APP / "output" / "pack_dep_chain.json"
        report = _run_plan(pipelines_path, out)
        specs = _load_pipe_specs(pipelines_path)
        assert report["dep_breaches"] == 0
        assert all(row["dep_clear"] or not row["met_sla"] for row in report["pipelines"])
        _assert_tier_ranks_respect_deps(report, specs)

    def test_tier_flip_scenario_pack(self) -> None:
        """Hot tier-rev pipeline ranks ahead of cold rows in the tier-flip pack."""
        pack = SCENARIOS / "scenario_tier_flip"
        out = APP / "output" / "pack_tier_flip.json"
        report = _run_plan(pack / "pipelines.jsonl", out)
        by_id = {row["pipeline_id"]: row for row in report["pipelines"]}
        assert by_id["p_prio_hot"]["tier_rank"] <= 2
        assert by_id["p_prio_hot"]["met_sla"] is True

    def test_arrival_drift_scenario_pack(self) -> None:
        """Arrival-drift pack honors overlay minutes and keeps slack visible."""
        pack = SCENARIOS / "scenario_arrival_drift"
        out = APP / "output" / "pack_arrival_drift.json"
        report = _run_plan(
            pack / "pipelines.jsonl",
            out,
            overlay_path=pack / "arrival_overlay.csv",
        )
        by_id = {row["pipeline_id"]: row for row in report["pipelines"]}
        assert by_id["p_drift_alpha"]["minutes_used"] == 720
        assert by_id["p_drift_beta"]["minutes_used"] == 640

    def test_burst_cluster_scenario_pack(self) -> None:
        """Burst cluster pack absorbs delayed arrivals from spare headroom."""
        pack = SCENARIOS / "scenario_burst_cluster"
        out = APP / "output" / "pack_burst_cluster.json"
        report = _run_plan(pack / "pipelines.jsonl", out)
        assert report["arrival_absorbed"] >= 3
        burst_rows = [r for r in report["pipelines"] if r["pipeline_id"].startswith("p_burst_")]
        assert burst_rows and all(row["met_sla"] for row in burst_rows)

    def test_value_mix_scenario_pack(self) -> None:
        """Value-mix pack keeps chained tail rows met after the window-fill root."""
        pack = SCENARIOS / "scenario_value_mix"
        out = APP / "output" / "pack_value_mix.json"
        report = _run_plan(pack / "pipelines.jsonl", out)
        by_id = {row["pipeline_id"]: row for row in report["pipelines"]}
        assert by_id["p_window_fill"]["met_sla"] is True
        assert by_id["p_sla_tail"]["met_sla"] is True
        assert by_id["p_sla_tail"]["tier_rank"] > by_id["p_window_fill"]["tier_rank"]

    def test_deterministic_rerun(self) -> None:
        """Identical inputs yield byte-identical default output."""
        first = OUT.read_bytes()
        out2 = APP / "output" / "sla_plan_rerun.json"
        _run_plan(APP / "data/pipelines_default.jsonl", out2)
        assert out2.read_bytes() == first
