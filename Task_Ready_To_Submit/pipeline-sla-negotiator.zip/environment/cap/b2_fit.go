package cap

// B2Q0 reserves credits from the remaining budget.
func B2Q0(budget, need int) (int, bool) {
	if need <= 0 {
		need = 1
	}
	if budget < need {
		return 0, false
	}
	return need, true
}

// V2Score scales captured value for a completed job.
func V2Score(weight float64, used int) float64 {
	if used <= 0 {
		return 0
	}
	if weight <= 0 {
		weight = 1.0
	}
	return weight * float64(used) / 1000.0
}

// A2Span picks reservation size from estimate and billable actual.
func A2Span(est, billable int) int {
	if billable > 0 && billable < est {
		return est
	}
	if est > 0 {
		return est
	}
	return billable
}
