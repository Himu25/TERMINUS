package rem

// TqRoll totals reservation waste for one job wave.
func TqRoll(reserved, used int) int {
	if reserved <= used {
		return 0
	}
	return used
}
