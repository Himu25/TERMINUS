# SLA plan contract

## Top-level fields

- status: ok when guardrails pass, otherwise fail
- window_budget: daily pool from windows.toml
- minutes_used: billable minutes consumed by pipelines that met SLA
- minutes_slack: reservation slack summed across pipelines
- pipelines_total: input JSONL row count
- pipelines_met: pipelines marked met_sla
- sla_rate: pipelines_met divided by pipelines_total
- slack_ratio: minutes_slack divided by minutes_used
- dep_breaches: pipelines started before dependencies finished
- tier_inversions: met pipelines whose rank score fell below a prior finish
- arrival_absorbed: delayed-arrival headroom minutes absorbed during waves
- value_met: weighted value total for met pipelines
- plan_digest: sha256 hex of compact JSON with plan_digest empty
- pipelines: per-pipeline rows

## Pipeline row fields

- pipeline_id, owner, tier
- minutes_reserved, minutes_used, slack_minutes
- met_sla, dep_clear
- tier_rank: 1-based finish position; when dep_on is non-empty, rank exceeds every prerequisite's rank
- arrival_wave, value_met

Digest JSON uses the same keys as the written plan with plan_digest set to empty string before hashing.

Scenario pack inputs are mirrored under `/app/scenarios/<pack>/pipelines.jsonl` with arrival overlay at `/app/scenarios/scenario_arrival_drift/arrival_overlay.csv`.

Scenario pack grading writes `/app/output/pack_dep_chain.json`, `/app/output/pack_tier_flip.json`, `/app/output/pack_arrival_drift.json`, `/app/output/pack_burst_cluster.json`, and `/app/output/pack_value_mix.json`.

Determinism reruns may write `/app/output/sla_plan_rerun.json`.

`/app/tools/run_negotiate` reads arrival overlay CSV from `/app/data/arrival_overlay.csv` by default; `TB_ARRIVAL_OVERLAY` may override that path.

Arrival overlay CSV rows override act_minutes for matching pipeline_id values when the overlay file is loaded.
