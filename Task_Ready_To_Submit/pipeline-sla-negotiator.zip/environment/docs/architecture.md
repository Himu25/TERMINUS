The SLA negotiator combines a Go driver, Rust span meter, and bash runners under `/app`.
The driver loads `/app/config/windows.toml`, pipeline JSONL bundles, and `/app/data/arrival_overlay.csv`
before simulating daily window allocation across dependent data pipelines.

Ordering, gate, reservation, wave, and slack behavior is split across several small Go packages
under `/app/seq`, `/app/mux`, `/app/cap`, `/app/rem`, and `/app/catch`. Billable minute totals
for overlay-adjusted rows come from the Rust static library in `/app/book`.

Build via `/app/scripts/build.sh`. Default bundle generation uses `/app/bin/pipepack` on
`/app/data/pipeline_specs.jsonl`. The bundled driver is `/app/tools/run_negotiate`.
Scenario pack inputs and graded pack outputs are indexed in `/app/docs/scenario_index.txt`.
