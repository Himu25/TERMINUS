package types

type WindowCfg struct {
	WindowBudget          int
	MinSlaRate     float64
	MaxSlackRatio         float64
	MaxDepBreaches      int
	MaxTierInversions int
	MinArrivalAbsorbed      int
	MinValueMet      float64
	OwnerWeights           map[string]float64
}

type PipeCase struct {
	PipelineID string   `json:"pipeline_id"`
	Owner      string   `json:"owner"`
	Tier       int      `json:"tier"`
	TierRev    int      `json:"tier_rev"`
	EstMinutes  int      `json:"est_minutes"`
	ActMinutes  int      `json:"act_minutes"`
	DepOn       []string `json:"dep_on"`
	ArrivalWave   int      `json:"arrival_wave"`
	SlaWeight float64  `json:"sla_weight"`
}

type PipeRow struct {
	PipelineID           string  `json:"pipeline_id"`
	Owner            string  `json:"owner"`
	Tier        int     `json:"tier"`
	MinutesReserved int     `json:"minutes_reserved"`
	MinutesUsed     int     `json:"minutes_used"`
	MetSla       bool    `json:"met_sla"`
	DepClear        bool    `json:"dep_clear"`
	TierRank    int     `json:"tier_rank"`
	SlackMinutes    int     `json:"slack_minutes"`
	ArrivalWave       int     `json:"arrival_wave"`
	ValueMet   float64 `json:"value_met"`
}

type SlaPlan struct {
	Status             string   `json:"status"`
	WindowBudget       int      `json:"window_budget"`
	MinutesUsed       int      `json:"minutes_used"`
	MinutesSlack       int      `json:"minutes_slack"`
	PipelinesTotal          int      `json:"pipelines_total"`
	PipelinesMet      int      `json:"pipelines_met"`
	SlaRate     float64  `json:"sla_rate"`
	SlackRatio         float64  `json:"slack_ratio"`
	DepBreaches      int      `json:"dep_breaches"`
	TierInversions int      `json:"tier_inversions"`
	ArrivalAbsorbed      int      `json:"arrival_absorbed"`
	ValueMet      float64  `json:"value_met"`
	PlanDigest       string   `json:"plan_digest"`
	Pipelines               []PipeRow `json:"pipelines"`
}
