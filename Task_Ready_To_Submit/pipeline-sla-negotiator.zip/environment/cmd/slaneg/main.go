// Plan JSON for /app/output/sla_plan.json:
//
// status — "ok" or "blocked"
// window_budget — daily pool from windows.toml
// minutes_used — billable minutes for pipelines that met SLA
// minutes_slack — reservation slack summed across pipelines
// pipelines_total — input JSONL row count
// pipelines_met — pipelines with met_sla true
// sla_rate — pipelines_met / pipelines_total
// slack_ratio — minutes_slack / minutes_used
// dep_breaches — pipelines scheduled before dependencies finished
// tier_inversions — met pipelines whose tier_rev rose versus prior finishes
// arrival_absorbed — delayed-arrival headroom minutes absorbed during waves
// value_met — weighted value total for met pipelines
// plan_digest — lowercase hex SHA-256 of compact JSON with plan_digest empty
// pipelines — array of pipeline rows
//
// Each pipeline row: pipeline_id, owner, tier, minutes_reserved, minutes_used,
// slack_minutes, met_sla, dep_clear, tier_rank, arrival_wave, value_met.
// tier_rank is 1-based finish order; rows with dep_on prerequisites rank after them.
//
// TB_ARRIVAL_OVERLAY may override the default /app/data/arrival_overlay.csv path.
package main

import (
	"fmt"
	"os"

	"sla.neg/drv"
)

func main() {
	if len(os.Args) < 3 {
		fmt.Fprintln(os.Stderr, "usage: slaneg <pipelines.jsonl> <out.json>")
		os.Exit(2)
	}
	cfg, err := drv.LoadCfg("/app/config/windows.toml")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	cases, err := drv.LoadPipelines(os.Args[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	overlayPath := "/app/data/arrival_overlay.csv"
	if v := os.Getenv("TB_ARRIVAL_OVERLAY"); v != "" {
		overlayPath = v
	}
	overlay, err := drv.LoadOverlay(overlayPath)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	report, err := drv.Run(cfg, cases, overlay)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if err := drv.WriteReport(os.Args[2], report); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
