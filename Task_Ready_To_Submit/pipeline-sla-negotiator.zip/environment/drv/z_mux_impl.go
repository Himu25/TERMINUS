package drv

import "sla.neg/mux"

func prereqReady(depOn []string, done map[string]bool) bool {
	return mux.MxQ0(depOn, done)
}
