package drv

import (
	"sla.neg/pkg/types"
	"sla.neg/seq"
)

func orderCases(cases []types.PipeCase) []types.PipeCase {
	return seq.KxOrder(cases)
}
