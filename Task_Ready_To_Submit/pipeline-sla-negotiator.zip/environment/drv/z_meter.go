package drv

import "sla.neg/book"

func billableSpan(est, act, overlay int) int {
	roll := book.MeterSpan(est, act, overlay)
	if roll.Billable > 0 {
		return roll.Billable
	}
	return est
}
