package drv

import "sla.neg/cap"

func reserveNeed(est, billable int) int {
	return cap.A2Span(est, billable)
}

func reserveHold(budget, need int) (int, bool) {
	return cap.B2Q0(budget, need)
}

func scoreValue(weight float64, used int) float64 {
	return cap.V2Score(weight, used)
}
