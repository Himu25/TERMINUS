package drv

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"

	"sla.neg/pkg/types"
	"sla.neg/summ"
)

func LoadCfg(path string) (types.WindowCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.WindowCfg{}, err
	}
	cfg := types.WindowCfg{
		WindowBudget:          15000,
		MinSlaRate:     0.75,
		MaxSlackRatio:         0.25,
		MaxDepBreaches:      0,
		MaxTierInversions: 2,
		MinArrivalAbsorbed:      3,
		MinValueMet:      8.5,
		OwnerWeights:           map[string]float64{"owner_a": 1.0, "owner_b": 1.0, "owner_c": 1.0},
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "window_budget":
			fmt.Sscanf(val, "%d", &cfg.WindowBudget)
		case "min_sla_rate":
			fmt.Sscanf(val, "%f", &cfg.MinSlaRate)
		case "max_slack_ratio":
			fmt.Sscanf(val, "%f", &cfg.MaxSlackRatio)
		case "max_dep_breaches":
			fmt.Sscanf(val, "%d", &cfg.MaxDepBreaches)
		case "max_tier_inversions":
			fmt.Sscanf(val, "%d", &cfg.MaxTierInversions)
		case "min_arrival_absorbed":
			fmt.Sscanf(val, "%d", &cfg.MinArrivalAbsorbed)
		case "min_value_met":
			fmt.Sscanf(val, "%f", &cfg.MinValueMet)
		case "owner_weight_owner_a":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.OwnerWeights["owner_a"] = w
		case "owner_weight_owner_b":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.OwnerWeights["owner_b"] = w
		case "owner_weight_owner_c":
			var w float64
			fmt.Sscanf(val, "%f", &w)
			cfg.OwnerWeights["owner_c"] = w
		}
	}
	return cfg, nil
}

func LoadPipelines(path string) ([]types.PipeCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.PipeCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var jc types.PipeCase
		if err := json.Unmarshal([]byte(line), &jc); err != nil {
			return nil, err
		}
		out = append(out, jc)
	}
	return out, sc.Err()
}

func LoadOverlay(path string) (map[string]int, error) {
	f, err := os.Open(path)
	if err != nil {
		return map[string]int{}, nil
	}
	defer f.Close()
	r := csv.NewReader(f)
	rows, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make(map[string]int)
	for i, row := range rows {
		if i == 0 || len(row) < 2 {
			continue
		}
		var credits int
		fmt.Sscanf(strings.TrimSpace(row[1]), "%d", &credits)
		out[strings.TrimSpace(row[0])] = credits
	}
	return out, nil
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

func Run(cfg types.WindowCfg, cases []types.PipeCase, overlay map[string]int) (types.SlaPlan, error) {
	ordered := orderCases(cases)
	report := types.SlaPlan{
		Status:       "ok",
		WindowBudget: cfg.WindowBudget,
		PipelinesTotal:    len(ordered),
	}
	done := make(map[string]bool)
	budgetLeft := cfg.WindowBudget
	var spent, totalWaste, completed, depViol, inversions, burstTotal int
	var valueTotal float64
	prevTierRev := -1
	report.Pipelines = make([]types.PipeRow, 0, len(ordered))

	for idx, jc := range ordered {
		depReady := prereqReady(jc.DepOn, done)
		if !depReady {
			depViol++
		}
		overlayVal := 0
		if act, ok := overlay[jc.PipelineID]; ok && act > 0 {
			overlayVal = act
			jc.ActMinutes = act
		}
		billable := billableSpan(jc.EstMinutes, jc.ActMinutes, overlayVal)
		if billable <= 0 {
			billable = jc.EstMinutes
		}
		need := reserveNeed(jc.EstMinutes, billable)
		reserved, ok := reserveHold(budgetLeft, need)
		headroom := budgetLeft - reserved
		if jc.ArrivalWave > 0 {
			burstTotal += absorbWave(jc.EstMinutes/4, headroom)
		}
		used := 0
		finished := false
		if ok && depReady {
			used = jc.ActMinutes
			if used <= 0 {
				used = billable
			}
			if used > reserved {
				used = reserved
			}
			budgetLeft -= reserved
			spent += used
			finished = true
			completed++
			done[jc.PipelineID] = true
			valueTotal += scoreValue(jc.SlaWeight, used)
		}
		wasteAmt := rollSlack(reserved, used)
		totalWaste += wasteAmt
		if finished {
			if prevTierRev >= 0 && jc.TierRev > prevTierRev {
				inversions++
			}
			prevTierRev = jc.TierRev
		}
		row := types.PipeRow{
			PipelineID:           jc.PipelineID,
			Owner:            jc.Owner,
			Tier:        jc.Tier,
			MinutesReserved: reserved,
			MinutesUsed:     used,
			MetSla:       finished,
			DepClear:        depReady,
			TierRank:    idx + 1,
			SlackMinutes:    wasteAmt,
			ArrivalWave:       jc.ArrivalWave,
			ValueMet:   round4(scoreValue(jc.SlaWeight, used)),
		}
		report.Pipelines = append(report.Pipelines, row)
	}

	report.MinutesUsed = spent
	report.MinutesSlack = totalWaste
	report.PipelinesMet = completed
	if report.PipelinesTotal > 0 {
		report.SlaRate = round4(float64(completed) / float64(report.PipelinesTotal))
	}
	if spent > 0 {
		report.SlackRatio = round4(float64(totalWaste) / float64(spent))
	}
	report.DepBreaches = depViol
	report.TierInversions = inversions
	report.ArrivalAbsorbed = burstTotal
	report.ValueMet = round4(valueTotal)
	if !meetsFloors(cfg, report) {
		report.Status = "fail"
	}
	report.PlanDigest = digestBody(report)
	return report, nil
}

func meetsFloors(cfg types.WindowCfg, report types.SlaPlan) bool {
	if report.SlaRate < cfg.MinSlaRate {
		return false
	}
	if report.SlackRatio > cfg.MaxSlackRatio {
		return false
	}
	if report.DepBreaches > cfg.MaxDepBreaches {
		return false
	}
	if report.TierInversions > cfg.MaxTierInversions {
		return false
	}
	if report.ArrivalAbsorbed < cfg.MinArrivalAbsorbed {
		return false
	}
	if report.ValueMet < cfg.MinValueMet {
		return false
	}
	_ = summ.SxFold(report.Pipelines)
	return true
}

type digestPayload struct {
	Status             string         `json:"status"`
	WindowBudget       int            `json:"window_budget"`
	MinutesUsed       int            `json:"minutes_used"`
	MinutesSlack       int            `json:"minutes_slack"`
	PipelinesTotal          int            `json:"pipelines_total"`
	PipelinesMet      int            `json:"pipelines_met"`
	SlaRate     float64        `json:"sla_rate"`
	SlackRatio         float64        `json:"slack_ratio"`
	DepBreaches      int            `json:"dep_breaches"`
	TierInversions int            `json:"tier_inversions"`
	ArrivalAbsorbed      int            `json:"arrival_absorbed"`
	ValueMet      float64        `json:"value_met"`
	PlanDigest       string         `json:"plan_digest"`
	Pipelines               []types.PipeRow `json:"pipelines"`
}

func digestBody(report types.SlaPlan) string {
	payload := digestPayload{
		Status:             report.Status,
		WindowBudget:       report.WindowBudget,
		MinutesUsed:       report.MinutesUsed,
		MinutesSlack:       report.MinutesSlack,
		PipelinesTotal:          report.PipelinesTotal,
		PipelinesMet:      report.PipelinesMet,
		SlaRate:     report.SlaRate,
		SlackRatio:         report.SlackRatio,
		DepBreaches:      report.DepBreaches,
		TierInversions: report.TierInversions,
		ArrivalAbsorbed:      report.ArrivalAbsorbed,
		ValueMet:      report.ValueMet,
		PlanDigest:       "",
		Pipelines:               report.Pipelines,
	}
	raw, err := marshalDigestJSON(payload)
	if err != nil {
		return ""
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func marshalDigestJSON(payload digestPayload) ([]byte, error) {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return nil, err
	}
	b := buf.Bytes()
	if n := len(b); n > 0 && b[n-1] == '\n' {
		b = b[:n-1]
	}
	return b, nil
}

func WriteReport(path string, report types.SlaPlan) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func p95(values []int) int {
	if len(values) == 0 {
		return 0
	}
	cp := append([]int(nil), values...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}
