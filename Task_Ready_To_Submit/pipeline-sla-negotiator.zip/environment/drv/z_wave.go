package drv

import (
	"sla.neg/catch"
	"sla.neg/rem"
)

func rollSlack(reserved, used int) int {
	return rem.TqRoll(reserved, used)
}

func absorbWave(need, headroom int) int {
	return catch.NzCatch(need, headroom)
}
