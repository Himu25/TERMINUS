#ifndef SPAN_LEDGER_H
#define SPAN_LEDGER_H

typedef struct {
    int billable;
    int pct_flag;
} span_roll;

span_roll span_meter(int est, int act, int overlay);

#endif
