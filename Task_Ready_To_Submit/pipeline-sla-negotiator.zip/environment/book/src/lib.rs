use std::os::raw::c_int;

#[repr(C)]
pub struct SpanRoll {
    pub billable: c_int,
    pub pct_flag: c_int,
}

fn pct_delta(est: i32, act: i32) -> bool {
    if est <= 0 {
        return false;
    }
    let delta = (act - est).abs();
    delta * 100 > est * 15
}

#[no_mangle]
pub extern "C" fn span_meter(est: c_int, act: c_int, overlay: c_int) -> SpanRoll {
    let est_i = est.max(0);
    let act_i = act.max(0);
    let overlay_i = overlay.max(0);
    let billable = if overlay_i > 0 { est_i } else { est_i.max(act_i) };
    let flag = if overlay_i > 0 && pct_delta(est_i, act_i) {
        1
    } else {
        0
    };
    SpanRoll {
        billable,
        pct_flag: flag,
    }
}
