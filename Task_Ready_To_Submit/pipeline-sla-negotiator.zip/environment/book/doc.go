// Package book wraps the Rust span meter for Go callers.
package book
