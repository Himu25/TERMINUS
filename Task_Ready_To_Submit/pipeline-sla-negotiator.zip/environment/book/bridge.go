package book

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libbook_meter.a -ldl -lm
#include "span_fold.h"
*/
import "C"

// Roll holds billable minutes for one pipeline row.
type Roll struct {
	Billable  int
	DriftFlag bool
}

// MeterSpan calls the Rust span_meter export in book/src/lib.rs.
func MeterSpan(est, act, overlay int) Roll {
	ct := C.span_meter(C.int(est), C.int(act), C.int(overlay))
	return Roll{
		Billable:  int(ct.billable),
		DriftFlag: ct.pct_flag != 0,
	}
}

// MeterBatch scores a slice of estimates (decoy helper).
func MeterBatch(estimates []int32) int {
	if len(estimates) == 0 {
		return 0
	}
	sum := 0
	for _, e := range estimates {
		if e > 0 {
			sum += int(e)
		}
	}
	return sum
}
