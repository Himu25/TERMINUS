package summ

import "sla.neg/pkg/types"

// SxFold folds job rows for telemetry export (non-scheduling).
func SxFold(rows []types.PipeRow) int {
	total := 0
	for _, row := range rows {
		total += row.MinutesUsed
	}
	return total
}
