module sla.neg

go 1.22
