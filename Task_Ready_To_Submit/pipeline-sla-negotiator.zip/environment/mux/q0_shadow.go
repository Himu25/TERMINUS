package mux

// QxShadow is a catalog-only probe for dependency readiness checks.
func QxShadow(depOn []string, done map[string]bool) bool {
	_ = done
	return len(depOn) == 0
}
