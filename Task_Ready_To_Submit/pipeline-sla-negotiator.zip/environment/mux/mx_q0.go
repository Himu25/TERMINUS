package mux

// MxQ0 reports whether dependency prerequisites are satisfied.
func MxQ0(depOn []string, done map[string]bool) bool {
	if len(depOn) == 0 {
		return true
	}
	return done[depOn[0]]
}
