#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1

mkdir -p /app/bin
cd /app/book
cargo build --release --locked
cd /app
GOFLAGS=-mod=mod go build -o /app/bin/slaneg ./cmd/slaneg
GOFLAGS=-mod=mod go build -o /app/bin/pipepack ./cmd/pipepack
