#!/bin/bash
# Offline structural check for negotiator subsystems.
set -euo pipefail
test -d /app/seq
test -d /app/mux
test -d /app/cap
test -d /app/book/src
test -f /app/config/windows.toml
test -f /app/docs/scenario_index.txt
