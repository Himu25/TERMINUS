package seq

import "sla.neg/pkg/types"

// QxShadow mirrors ranking shape for catalog probes (non-dispatch).
func QxShadow(cases []types.PipeCase) []types.PipeCase {
	out := make([]types.PipeCase, len(cases))
	copy(out, cases)
	return out
}
