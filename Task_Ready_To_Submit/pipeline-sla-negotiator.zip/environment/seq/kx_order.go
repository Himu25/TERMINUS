package seq

import (
	"sort"

	"sla.neg/pkg/types"
)

// KxOrder ranks pending pipelines for window allocation.
func KxOrder(cases []types.PipeCase) []types.PipeCase {
	out := make([]types.PipeCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		return out[i].Tier < out[j].Tier
	})
	return out
}
