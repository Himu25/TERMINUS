# Pipeline SLA negotiator

Twenty nightly data pipelines share a fixed daily window pool under `/app`. See `/app/docs/architecture.md` and `/app/docs/contract.md`.

Build with `/app/scripts/build.sh`. The negotiator driver lives at `/app/tools/run_negotiate`.
