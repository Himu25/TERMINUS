package mux

// MxQ0 reports whether dependency prerequisites are satisfied.
func MxQ0(depOn []string, done map[string]bool) bool {
	if len(depOn) == 0 {
		return true
	}
	for _, depID := range depOn {
		if !done[depID] {
			return false
		}
	}
	return true
}
