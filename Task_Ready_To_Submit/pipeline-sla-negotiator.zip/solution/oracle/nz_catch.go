package catch

// NzCatch counts burst credits absorbed from spare headroom.
func NzCatch(burstNeed, headroom int) int {
	if burstNeed <= 0 || headroom <= 0 {
		return 0
	}
	if burstNeed > headroom {
		return headroom
	}
	return burstNeed
}
