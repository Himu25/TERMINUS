package seq

import (
	"sort"

	"sla.neg/pkg/types"
)

// KxOrder ranks pending pipelines for window allocation.
func KxOrder(cases []types.PipeCase) []types.PipeCase {
	out := make([]types.PipeCase, len(cases))
	copy(out, cases)
	sort.SliceStable(out, func(i, j int) bool {
		a, b := out[i], out[j]
		if a.TierRev != b.TierRev {
			return a.TierRev > b.TierRev
		}
		if a.Tier != b.Tier {
			return a.Tier > b.Tier
		}
		if a.SlaWeight != b.SlaWeight {
			return a.SlaWeight > b.SlaWeight
		}
		return a.PipelineID < b.PipelineID
	})
	return out
}
