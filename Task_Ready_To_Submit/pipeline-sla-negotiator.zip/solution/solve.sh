#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight: pipeline SLA negotiator workspace"
require_file /app/go.mod
require_file /app/config/windows.toml
require_file /app/data/pipeline_specs.jsonl
mkdir -p /app/bin /app/output

log "survey guardrails and subsystem layout"
grep -nE 'sla_rate|slack_ratio|dep_breaches|arrival_absorbed|window_budget' \
  /app/config/windows.toml /app/docs/contract.md 2>/dev/null | head -n 20 || true
wc -l /app/seq/kx_order.go /app/mux/mx_q0.go /app/cap/b2_fit.go \
  /app/rem/tq_roll.go /app/catch/nz_catch.go /app/book/src/lib.rs

log "restore dependency hold gate"
cp "${ROOT_DIR}/oracle/mx_q0.go" /app/mux/mx_q0.go

log "restore tier ordering pass"
cp "${ROOT_DIR}/oracle/kx_order.go" /app/seq/kx_order.go

log "restore reservation sizing"
python3 - <<'PY'
from pathlib import Path
path = Path("/app/cap/b2_fit.go")
text = path.read_text()
old = """func A2Span(est, billable int) int {
\tif billable > 0 && billable < est {
\t\treturn est
\t}
\tif est > 0 {
\t\treturn est
\t}
\treturn billable
}"""
new = """func A2Span(est, billable int) int {
\tif billable > 0 && billable < est {
\t\treturn billable
\t}
\tif est > 0 {
\t\treturn est
\t}
\treturn billable
}"""
if old not in text:
    raise SystemExit("A2Span site not found")
path.write_text(text.replace(old, new, 1))
PY

log "restore slack roll-up"
cp "${ROOT_DIR}/oracle/tq_roll.go" /app/rem/tq_roll.go

log "restore delayed arrival absorption"
cp "${ROOT_DIR}/oracle/nz_catch.go" /app/catch/nz_catch.go

log "restore span meter for overlay drift rows"
cp "${ROOT_DIR}/oracle/lib.rs" /app/book/src/lib.rs

log "rebuild slaneg and pipepack"
bash /app/scripts/build.sh

log "refresh default pipeline bundle"
/app/bin/pipepack /app/data/pipeline_specs.jsonl /app/data/pipelines_default.jsonl

log "emit default SLA plan"
/app/tools/run_negotiate

log "post-run guardrail check"
python3 - <<'PY'
import json
from pathlib import Path

cfg = {}
for line in Path("/app/config/windows.toml").read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k.endswith("_rate") or k.startswith("max_slack") or k.startswith("min_value"):
        cfg[k] = float(v)
    elif k.startswith("max_") or k.startswith("min_arrival") or k == "window_budget":
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/sla_plan.json").read_text())
assert report["status"] == "ok", report
assert report["sla_rate"] >= cfg["min_sla_rate"]
assert report["slack_ratio"] <= cfg["max_slack_ratio"]
assert report["dep_breaches"] <= cfg["max_dep_breaches"]
assert report["arrival_absorbed"] >= cfg["min_arrival_absorbed"]
assert report["value_met"] >= cfg["min_value_met"]
assert report["pipelines_total"] == 20
print("ok", report["sla_rate"], report["dep_breaches"], report["plan_digest"][:12])
PY

log "oracle complete"
