package main

import (
	"flag"
	"fmt"
	"os"

	"lab.local/merger_ledger_replay/internal/driver"
)

func main() {
	profile := flag.String("profile", "/app/config/bench_profiles.json", "bench profile path")
	thresholds := flag.String("thresholds", "/app/config/thresholds.toml", "threshold floors")
	cutover := flag.String("cutover", "/app/config/cutover_manifest.json", "cutover manifest")
	out := flag.String("out", "/app/output/consolidation_report.json", "report output path")
	flag.Parse()

	rep, err := driver.RunProfile("/app", *profile, *thresholds, *cutover)
	if err != nil {
		fmt.Fprintf(os.Stderr, "replay run failed: %v\n", err)
		os.Exit(1)
	}
	if err := driver.Emit(*out, rep); err != nil {
		fmt.Fprintf(os.Stderr, "emit failed: %v\n", err)
		os.Exit(1)
	}
}
