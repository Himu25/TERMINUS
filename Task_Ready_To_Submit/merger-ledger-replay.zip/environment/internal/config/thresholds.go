package config

import "strconv"

// FloorInt coerces a float floor entry to int when present.
func FloorInt(floors map[string]float64, key string) int {
	if v, ok := floors[key]; ok {
		return int(v)
	}
	return 0
}

// FloorBool parses 1/0 style bool floors.
func FloorBool(floors map[string]float64, key string) bool {
	if v, ok := floors[key]; ok {
		return v >= 1.0
	}
	return false
}

func ParseBoolString(raw string) bool {
	b, err := strconv.ParseBool(raw)
	if err != nil {
		return raw == "1"
	}
	return b
}
