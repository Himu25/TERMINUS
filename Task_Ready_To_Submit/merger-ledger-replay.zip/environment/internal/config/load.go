package config

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
)

type ScenarioEntry struct {
	Name string `json:"name"`
	Dir  string `json:"dir"`
}

type Profile struct {
	Scenarios []ScenarioEntry `json:"scenarios"`
}

type CutoverManifest struct {
	CutoverISO   string `json:"cutover_iso"`
	OverlapStart string `json:"overlap_start"`
	OverlapEnd   string `json:"overlap_end"`
}

func Resolve(root, rel string) string {
	if filepath.IsAbs(rel) {
		return rel
	}
	return filepath.Join(root, rel)
}

func LoadProfile(path string) (Profile, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return Profile{}, err
	}
	var profile Profile
	if err := json.Unmarshal(raw, &profile); err != nil {
		return Profile{}, err
	}
	return profile, nil
}

func LoadCutover(path string) (CutoverManifest, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return CutoverManifest{}, err
	}
	var manifest CutoverManifest
	if err := json.Unmarshal(raw, &manifest); err != nil {
		return CutoverManifest{}, err
	}
	return manifest, nil
}

func LoadFloors(path string) (map[string]float64, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	out := map[string]float64{}
	for _, line := range strings.Split(string(raw), "\n") {
		stripped := strings.Split(line, "#")[0]
		stripped = strings.TrimSpace(stripped)
		if stripped == "" || !strings.Contains(stripped, "=") {
			continue
		}
		parts := strings.SplitN(stripped, "=", 2)
		key := strings.TrimSpace(parts[0])
		var val float64
		if err := fmtScanFloat(parts[1], &val); err != nil {
			return nil, err
		}
		out[key] = val
	}
	return out, nil
}

func fmtScanFloat(s string, v *float64) error {
	s = strings.TrimSpace(s)
	var n float64
	if err := json.Unmarshal([]byte(s), &n); err == nil {
		*v = n
		return nil
	}
	parsed, err := parseFloat(s)
	if err != nil {
		return err
	}
	*v = parsed
	return nil
}

func parseFloat(s string) (float64, error) {
	var n json.Number = json.Number(s)
	return n.Float64()
}
