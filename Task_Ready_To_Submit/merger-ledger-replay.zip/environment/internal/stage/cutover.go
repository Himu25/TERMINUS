package stage

import (
	"lab.local/merger_ledger_replay/internal/cutover"
	"lab.local/merger_ledger_replay/internal/config"
	"lab.local/merger_ledger_replay/internal/dedupe"
	"lab.local/merger_ledger_replay/pkg/txn"
)

type ZoneSplit struct {
	Overlap []txn.Record
	Other   []txn.Record
}

func SplitZones(rows []txn.Record, manifest config.CutoverManifest) ZoneSplit {
	out := ZoneSplit{}
	for i := range rows {
		zone := cutover.OpT(manifest.CutoverISO, manifest.OverlapStart, manifest.OverlapEnd, &rows[i])
		if zone == cutover.ZoneInside {
			out.Overlap = append(out.Overlap, rows[i])
		} else {
			out.Other = append(out.Other, rows[i])
		}
	}
	return out
}

func SuppressOverlap(rows []txn.Record, manifest config.CutoverManifest) ([]txn.Record, int) {
	deduped, removed := dedupe.OpW(rows, manifest.OverlapStart, manifest.OverlapEnd)
	return deduped, removed
}
