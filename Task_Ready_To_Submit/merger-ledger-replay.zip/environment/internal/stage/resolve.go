package stage

import (
	"lab.local/merger_ledger_replay/internal/partyresolve"
	"lab.local/merger_ledger_replay/internal/skuresolve"
	"lab.local/merger_ledger_replay/pkg/party"
	"lab.local/merger_ledger_replay/pkg/sku"
	"lab.local/merger_ledger_replay/pkg/txn"
)

type Resolved struct {
	Row        txn.Record
	SKUCanon   string
	PartyCanon string
	SKUMiss    bool
	PartyMiss  bool
}

func ResolveRows(rows []txn.Record, skuMap []sku.Row, partyMap []party.Row) []Resolved {
	out := make([]Resolved, 0, len(rows))
	for _, row := range rows {
		item := Resolved{Row: row}
		sCanon, ok := skuresolve.OpK(skuMap, row.SKURaw, 3)
		if !ok {
			item.SKUMiss = true
			item.SKUCanon = row.SKURaw
		} else {
			item.SKUCanon = sCanon
		}
		pCanon, ok := partyresolve.OpP(partyMap, row.PartyRaw, 3)
		if !ok {
			item.PartyMiss = true
			item.PartyCanon = row.PartyRaw
		} else {
			item.PartyCanon = pCanon
		}
		out = append(out, item)
	}
	return out
}
