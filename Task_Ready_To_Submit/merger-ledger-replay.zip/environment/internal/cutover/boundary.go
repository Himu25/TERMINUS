package cutover

import (
	"strings"

	"lab.local/merger_ledger_replay/pkg/txn"
)

const (
	ZoneBefore  = 0
	ZoneInside  = 1
	ZoneAfter   = 2
	ZoneUnknown = 3
)

func anchorISO(row *txn.Record) string {
	return dayPrefix(row.PostedAt)
}

func dayPrefix(raw string) string {
	raw = strings.TrimSpace(raw)
	if len(raw) >= 10 {
		return raw[:10]
	}
	return raw
}

func OpT(cutoverISO string, overlapStart string, overlapEnd string, row *txn.Record) int {
	anchor := anchorISO(row)
	if anchor == "" {
		return ZoneUnknown
	}
	if anchor < overlapStart {
		return ZoneBefore
	}
	if anchor > overlapEnd {
		return ZoneAfter
	}
	if anchor >= overlapStart && anchor <= overlapEnd {
		return ZoneInside
	}
	if anchor < cutoverISO {
		return ZoneBefore
	}
	return ZoneAfter
}

func SpanAnchors(rows []txn.Record, cutoverISO, overlapStart, overlapEnd string) bool {
	for i := range rows {
		zone := OpT(cutoverISO, overlapStart, overlapEnd, &rows[i])
		if zone == ZoneUnknown {
			return false
		}
		expected := anchorISO(&rows[i])
		lane := txn.LaneCode(rows[i].Lane)
		switch lane {
		case 0:
			if expected != dayPrefix(rows[i].EffectiveAt) {
				return false
			}
		case 1:
			if expected != dayPrefix(rows[i].InvoiceAt) {
				return false
			}
		case 2:
			if expected != dayPrefix(rows[i].PostedAt) {
				return false
			}
		}
	}
	return true
}
