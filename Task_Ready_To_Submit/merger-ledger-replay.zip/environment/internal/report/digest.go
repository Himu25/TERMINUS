package report

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"math"
	"os"
	"path/filepath"
)

func Round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

// SealU computes scenario_digest hex from rounded numeric tuple.
func SealU(revenue float64, invDelta float64, dupRemoved int, skuMiss int, partyMiss int) string {
	payload := struct {
		R float64 `json:"r"`
		I float64 `json:"i"`
		D int     `json:"d"`
		S int     `json:"s"`
		P int     `json:"p"`
	}{
		R: Round4(revenue),
		I: Round4(invDelta),
		D: dupRemoved,
		S: skuMiss,
		P: partyMiss,
	}
	raw, _ := json.Marshal(payload)
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])[:8]
}

func WriteJSON(path string, payload any) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(payload, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}
