package report

type ScenarioRow struct {
	Name                   string  `json:"name"`
	TxnsIn                 int     `json:"txns_in"`
	TxnsQuarantined        int     `json:"txns_quarantined"`
	RevenueTotal           float64 `json:"revenue_total"`
	InventoryDelta         float64 `json:"inventory_delta"`
	DuplicatePostingsRemoved int   `json:"duplicate_postings_removed"`
	UnmatchedSKUCount      int     `json:"unmatched_sku_count"`
	UnmatchedPartyCount    int     `json:"unmatched_party_count"`
	SpanAnchors            bool    `json:"cutover_honored"`
	RecognitionAligned     bool    `json:"recognition_aligned"`
	ScenarioDigest         string  `json:"scenario_digest"`
}

type Summary struct {
	CompositeScore   float64 `json:"composite_score"`
	TotalQuarantined int     `json:"total_quarantined"`
	PassesGate       bool    `json:"passes_gate"`
}

type Report struct {
	Scenarios []ScenarioRow `json:"scenarios"`
	Summary   Summary       `json:"summary"`
}

func ApplyGate(rep *Report, floors map[string]float64) {
	allClear := true
	for _, row := range rep.Scenarios {
		if floor, ok := floors[row.Name]; ok {
			score := scenarioScore(row)
			if score < floor {
				allClear = false
			}
		}
	}
	compositeFloor := floors["composite_score"]
	if rep.Summary.CompositeScore < compositeFloor {
		allClear = false
	}
	rep.Summary.PassesGate = allClear
}

func scenarioScore(row ScenarioRow) float64 {
	score := 1.0
	if !row.SpanAnchors {
		score -= 0.25
	}
	if !row.RecognitionAligned {
		score -= 0.25
	}
	if row.UnmatchedSKUCount > 0 {
		score -= 0.25
	}
	if row.UnmatchedPartyCount > 0 {
		score -= 0.25
	}
	if score < 0 {
		return 0
	}
	return score
}

func BuildSummary(rows []ScenarioRow) Summary {
	var scores []float64
	totalQ := 0
	for _, row := range rows {
		scores = append(scores, scenarioScore(row))
		totalQ += row.TxnsQuarantined
	}
	composite := 1.0
	if len(scores) > 0 {
		sum := 0.0
		for _, s := range scores {
			sum += s
		}
		composite = Round4(sum / float64(len(scores)))
	}
	return Summary{
		CompositeScore:   composite,
		TotalQuarantined: totalQ,
		PassesGate:       false,
	}
}
