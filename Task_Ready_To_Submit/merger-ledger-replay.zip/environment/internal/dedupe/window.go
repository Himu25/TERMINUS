package dedupe

import (
	"fmt"

	"lab.local/merger_ledger_replay/pkg/txn"
)

func OpW(rows []txn.Record, overlapStart string, overlapEnd string) ([]txn.Record, int) {
	seen := map[string]struct{}{}
	out := make([]txn.Record, 0, len(rows))
	removed := 0
	for _, row := range rows {
		key := row.ID
		if _, ok := seen[key]; ok {
			removed++
			continue
		}
		seen[key] = struct{}{}
		out = append(out, row)
	}
	return out, removed
}

func WireKey(row txn.Record, skuCanon, partyCanon string, period string) string {
	absAmt := row.Amount
	if absAmt < 0 {
		absAmt = -absAmt
	}
	return fmt.Sprintf("%s|%s|%s|%.4f", partyCanon, skuCanon, period, absAmt)
}
