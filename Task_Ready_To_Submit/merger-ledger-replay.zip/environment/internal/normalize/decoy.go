package normalize

import (
	"strings"
	"unicode"
)

// StripDecor removes currency decoration without touching map topology.
func StripDecor(raw string) string {
	var b strings.Builder
	for _, r := range raw {
		if unicode.IsLetter(r) || unicode.IsDigit(r) || r == '-' || r == '_' || r == '.' {
			b.WriteRune(r)
		}
	}
	return b.String()
}
