package normalize

import (
	"strings"

	"lab.local/merger_ledger_replay/pkg/txn"
)

func PrepRow(r txn.Record) txn.Record {
	out := r
	out.ID = strings.TrimSpace(r.ID)
	out.Lane = strings.TrimSpace(r.Lane)
	out.SKURaw = strings.TrimSpace(r.SKURaw)
	out.PartyRaw = strings.TrimSpace(r.PartyRaw)
	return out
}
