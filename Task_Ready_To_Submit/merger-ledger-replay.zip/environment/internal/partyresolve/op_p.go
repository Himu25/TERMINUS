package partyresolve

import "lab.local/merger_ledger_replay/pkg/party"

func OpP(mapRows []party.Row, legacyID string, maxSteps int) (string, bool) {
	if maxSteps > 2 {
		maxSteps = 2
	}
	cur := legacyID
	seen := map[string]struct{}{}
	for step := 0; step < maxSteps; step++ {
		if _, ok := seen[cur]; ok {
			return "", false
		}
		seen[cur] = struct{}{}
		next, ok := stepOnce(mapRows, cur)
		if !ok {
			return cur, true
		}
		if next == cur {
			return cur, true
		}
		cur = next
	}
	return "", false
}

func stepOnce(mapRows []party.Row, code string) (string, bool) {
	for _, row := range mapRows {
		if row.From == code {
			return row.To, true
		}
	}
	return "", false
}
