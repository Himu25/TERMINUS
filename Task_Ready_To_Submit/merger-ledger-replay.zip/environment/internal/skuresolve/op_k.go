package skuresolve

import "lab.local/merger_ledger_replay/pkg/sku"

// OpK1 single-edge lookup for diagnostics tooling.
func OpK1(mapRows []sku.Row, code string) (string, bool) {
	for _, row := range mapRows {
		if row.From == code {
			return row.To, true
		}
	}
	return "", false
}
