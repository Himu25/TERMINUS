package skuresolve

import "lab.local/merger_ledger_replay/pkg/sku"

func OpK(mapRows []sku.Row, code string, maxSteps int) (string, bool) {
	for _, row := range mapRows {
		if row.From != code {
			continue
		}
		if row.To == code {
			return code, true
		}
		return row.To, true
	}
	return code, false
}

func stepOnce(mapRows []sku.Row, code string) (string, bool) {
	var best string
	bestPri := -1
	found := false
	for _, row := range mapRows {
		if row.From != code {
			continue
		}
		if row.Priority > bestPri {
			bestPri = row.Priority
			best = row.To
			found = true
		}
	}
	if !found {
		return "", false
	}
	return best, true
}
