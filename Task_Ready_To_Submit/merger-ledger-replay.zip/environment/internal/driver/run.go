package driver

import (
	"bufio"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"

	"lab.local/merger_ledger_replay/internal/config"
	"lab.local/merger_ledger_replay/internal/cutover"
	"lab.local/merger_ledger_replay/internal/normalize"
	"lab.local/merger_ledger_replay/internal/recognition"
	"lab.local/merger_ledger_replay/internal/report"
	"lab.local/merger_ledger_replay/internal/stage"
	"lab.local/merger_ledger_replay/pkg/party"
	"lab.local/merger_ledger_replay/pkg/sku"
	"lab.local/merger_ledger_replay/pkg/txn"
)

func RunProfile(appRoot, profilePath, thresholdsPath, cutoverPath string) (report.Report, error) {
	profile, err := config.LoadProfile(profilePath)
	if err != nil {
		return report.Report{}, err
	}
	manifest, err := config.LoadCutover(cutoverPath)
	if err != nil {
		return report.Report{}, err
	}
	skuMap, err := loadSKU(config.Resolve(appRoot, "data/staging/sku_map.jsonl"))
	if err != nil {
		return report.Report{}, err
	}
	partyMap, err := loadParty(config.Resolve(appRoot, "data/staging/party_map.jsonl"))
	if err != nil {
		return report.Report{}, err
	}
	var rows []report.ScenarioRow
	for _, entry := range profile.Scenarios {
		row, err := runScenario(appRoot, entry.Name, entry.Dir, manifest, skuMap, partyMap)
		if err != nil {
			return report.Report{}, err
		}
		rows = append(rows, row)
	}
	rep := report.Report{Scenarios: rows, Summary: report.BuildSummary(rows)}
	floors, err := config.LoadFloors(thresholdsPath)
	if err != nil {
		return report.Report{}, err
	}
	report.ApplyGate(&rep, floors)
	return rep, nil
}

func runScenario(appRoot, name, relDir string, manifest config.CutoverManifest, skuMap []sku.Row, partyMap []party.Row) (report.ScenarioRow, error) {
	dir := config.Resolve(appRoot, relDir)
	rawRows, quarantined, err := loadScenario(dir)
	if err != nil {
		return report.ScenarioRow{}, err
	}
	admitted := make([]txn.Record, 0, len(rawRows))
	for _, raw := range rawRows {
		row := normalize.PrepRow(raw)
		if !txn.Valid(row) {
			continue
		}
		admitted = append(admitted, row)
	}
	resolved := stage.ResolveRows(admitted, skuMap, partyMap)
	skuMiss := 0
	partyMiss := 0
	for _, item := range resolved {
		if item.SKUMiss {
			skuMiss++
		}
		if item.PartyMiss {
			partyMiss++
		}
	}
	zones := stage.SplitZones(admitted, manifest)
	dedupedOverlap, removed := stage.SuppressOverlap(zones.Overlap, manifest)
	finalRows := append(zones.Other, dedupedOverlap...)

	revenue := 0.0
	invDelta := 0.0
	finalSet := map[string]struct{}{}
	for _, row := range finalRows {
		finalSet[row.ID] = struct{}{}
	}
	for _, item := range resolved {
		if _, ok := finalSet[item.Row.ID]; !ok {
			continue
		}
		switch item.Row.Lane {
		case "a", "b":
			revenue += report.Round4(item.Row.Amount)
		case "inv":
			invDelta += report.Round4(item.Row.Amount)
		}
	}

	row := report.ScenarioRow{
		Name:                     name,
		TxnsIn:                   len(admitted),
		TxnsQuarantined:          quarantined,
		RevenueTotal:             report.Round4(revenue),
		InventoryDelta:           report.Round4(invDelta),
		DuplicatePostingsRemoved: removed,
		UnmatchedSKUCount:        skuMiss,
		UnmatchedPartyCount:      partyMiss,
		SpanAnchors:              cutover.SpanAnchors(admitted, manifest.CutoverISO, manifest.OverlapStart, manifest.OverlapEnd),
		RecognitionAligned:       recognition.RecognitionAligned(admitted),
	}
	row.ScenarioDigest = report.SealU(row.RevenueTotal, row.InventoryDelta, row.DuplicatePostingsRemoved, row.UnmatchedSKUCount, row.UnmatchedPartyCount)
	return row, nil
}

func loadScenario(dir string) ([]txn.Record, int, error) {
	var rows []txn.Record
	quarantined := 0
	for _, name := range []string{"billing_a.jsonl", "billing_b.jsonl", "inventory_moves.jsonl"} {
		path := filepath.Join(dir, name)
		part, bad, err := loadJSONL(path)
		if err != nil {
			return nil, 0, err
		}
		rows = append(rows, part...)
		quarantined += bad
	}
	return rows, quarantined, nil
}

func loadJSONL(path string) ([]txn.Record, int, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, 0, err
	}
	defer f.Close()
	var rows []txn.Record
	quarantined := 0
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		var row txn.Record
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			quarantined++
			continue
		}
		if !txn.Valid(row) {
			quarantined++
			continue
		}
		rows = append(rows, row)
	}
	return rows, quarantined, sc.Err()
}

func loadSKU(path string) ([]sku.Row, error) {
	return loadMapLines(path, func(line string) (sku.Row, error) {
		var row sku.Row
		err := json.Unmarshal([]byte(line), &row)
		return row, err
	})
}

func loadParty(path string) ([]party.Row, error) {
	return loadMapLines(path, func(line string) (party.Row, error) {
		var row party.Row
		err := json.Unmarshal([]byte(line), &row)
		return row, err
	})
}

func loadMapLines[T any](path string, parse func(string) (T, error)) ([]T, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	var out []T
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		row, err := parse(line)
		if err != nil {
			continue
		}
		out = append(out, row)
	}
	return out, sc.Err()
}

func Emit(outPath string, rep report.Report) error {
	return report.WriteJSON(outPath, rep)
}
