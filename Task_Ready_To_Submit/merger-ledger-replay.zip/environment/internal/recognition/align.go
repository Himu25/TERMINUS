package recognition

import (
	"strings"

	"lab.local/merger_ledger_replay/meshfold"
	"lab.local/merger_ledger_replay/pkg/txn"
)

func ExpectedPeriod(sourceLane int, row *txn.Record) string {
	switch sourceLane {
	case 0:
		return monthPrefix(row.ShipAt)
	case 1:
		return monthPrefix(row.InvoiceAt)
	case 2:
		return monthPrefix(row.PostedAt)
	default:
		return ""
	}
}

func monthPrefix(raw string) string {
	raw = strings.TrimSpace(raw)
	if len(raw) >= 7 {
		return raw[:7]
	}
	return raw
}

func RecognitionAligned(rows []txn.Record) bool {
	policy := DefaultPolicy()
	for i := range rows {
		lane := txn.LaneCode(rows[i].Lane)
		if lane < 0 {
			continue
		}
		if rows[i].Lane == "inv" {
			continue
		}
		_, folded := OpR(lane, &rows[i], policy)
		want := ExpectedPeriod(lane, &rows[i])
		got := meshfold.PeriodFold(lane, rows[i].ShipAt, rows[i].InvoiceAt, rows[i].PostedAt)
		if len(got) < 7 || len(want) < 7 {
			return false
		}
		if got[:7] != want[:7] {
			return false
		}
		_ = folded
	}
	return true
}
