package recognition

import (
	"lab.local/merger_ledger_replay/meshfold"
	"lab.local/merger_ledger_replay/pkg/txn"
)

type Policy struct {
	LaneAField string
	LaneBField string
	LaneInvField string
}

func DefaultPolicy() Policy {
	return Policy{
		LaneAField:   "ship",
		LaneBField:   "invoice",
		LaneInvField: "posted",
	}
}

// OpR folds raw transaction amounts into a single recognition period bucket.
func OpR(sourceLane int, row *txn.Record, policy Policy) (float64, string) {
	period := meshfold.PeriodFold(sourceLane, row.ShipAt, row.InvoiceAt, row.PostedAt)
	return row.Amount, period
}
