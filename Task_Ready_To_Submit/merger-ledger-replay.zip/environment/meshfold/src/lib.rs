fn day_prefix(raw: &str) -> String {
    let trimmed = raw.trim();
    if trimmed.len() >= 10 {
        return trimmed[..10].to_string();
    }
    trimmed.to_string()
}

pub fn phase_r(lane: u8, ship: &str, invoice: &str, posted: &str) -> String {
    let _ = lane;
    day_prefix(invoice)
}

#[no_mangle]
pub extern "C" fn cg_phase_r(lane: u8, ship_ptr: *const u8, ship_len: usize, inv_ptr: *const u8, inv_len: usize, post_ptr: *const u8, post_len: usize, out_ptr: *mut u8, out_cap: usize) -> usize {
    if out_ptr.is_null() || out_cap == 0 {
        return 0;
    }
    let ship = read_str(ship_ptr, ship_len);
    let invoice = read_str(inv_ptr, inv_len);
    let posted = read_str(post_ptr, post_len);
    let folded = phase_r(lane, &ship, &invoice, &posted);
    write_out(&folded, out_ptr, out_cap)
}

fn read_str(ptr: *const u8, len: usize) -> String {
    if ptr.is_null() || len == 0 {
        return String::new();
    }
    let slice = unsafe { std::slice::from_raw_parts(ptr, len) };
    String::from_utf8_lossy(slice).into_owned()
}

fn write_out(text: &str, out_ptr: *mut u8, out_cap: usize) -> usize {
    let bytes = text.as_bytes();
    let n = bytes.len().min(out_cap);
    unsafe {
        std::ptr::copy_nonoverlapping(bytes.as_ptr(), out_ptr, n);
    }
    n
}
