package meshfold

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libmeshfold.a -ldl -lm
#include "fold_gate.h"
*/
import "C"
import "unsafe"

func PeriodFold(lane int, ship, invoice, posted string) string {
	if lane < 0 {
		return ""
	}
	s := []byte(ship)
	i := []byte(invoice)
	p := []byte(posted)
	out := make([]byte, 32)
	var sp, ip, pp *C.uint8_t
	if len(s) > 0 {
		sp = (*C.uint8_t)(unsafe.Pointer(&s[0]))
	}
	if len(i) > 0 {
		ip = (*C.uint8_t)(unsafe.Pointer(&i[0]))
	}
	if len(p) > 0 {
		pp = (*C.uint8_t)(unsafe.Pointer(&p[0]))
	}
	n := C.cg_phase_r(
		C.uint8_t(lane),
		sp, C.size_t(len(s)),
		ip, C.size_t(len(i)),
		pp, C.size_t(len(p)),
		(*C.uint8_t)(unsafe.Pointer(&out[0])), C.size_t(len(out)),
	)
	return string(out[:int(n)])
}
