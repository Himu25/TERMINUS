#ifndef MESHFOLD_FOLD_GATE_H
#define MESHFOLD_FOLD_GATE_H

#include <stddef.h>
#include <stdint.h>

size_t cg_phase_r(uint8_t lane, const uint8_t *ship_ptr, size_t ship_len,
                  const uint8_t *inv_ptr, size_t inv_len,
                  const uint8_t *post_ptr, size_t post_len,
                  uint8_t *out_ptr, size_t out_cap);

#endif
