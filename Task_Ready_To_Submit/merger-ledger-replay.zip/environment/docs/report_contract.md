# Consolidation report contract

The report JSON carries a `scenarios` array listing one row per active bench profile entry in order, plus a `summary` block.

Each scenario row in `/app/output/consolidation_report.json` exposes:

- `name` — scenario stem from the active bench profile
- `txns_in` — admitted transaction rows after ingest validation
- `txns_quarantined` — malformed or incomplete source rows excluded from replay
- `revenue_total` — summed billing-lane amounts after overlap suppression (four-decimal rounding)
- `inventory_delta` — summed movement-lane amounts after overlap suppression
- `duplicate_postings_removed` — overlap-band postings collapsed when resolved party, canonical SKU, recognition period, and absolute amount match
- `unmatched_sku_count` — rows whose product token could not reach a canonical code via staging map walks
- `unmatched_party_count` — rows whose party token could not reach a survivor via staging remap walks (zero when fully resolved)

- `cutover_honored` — true when every admitted row used the lane-specific anchor date described in `/app/docs/cutover_policy.md`
- `recognition_aligned` — true when billing-lane period folding matches `/app/docs/recognition_notes.md`
- `scenario_digest` — eight lowercase hex characters sealing the rounded `(revenue_total, inventory_delta, duplicate_postings_removed, unmatched_sku_count, unmatched_party_count)` tuple

Summary block carries `composite_score` (unweighted mean of per-scenario alignment scores, four-decimal rounding), `total_quarantined`, and `passes_gate` (false unless every scenario clears its floor in `/app/config/thresholds.toml`).

Fully resolved scenarios report zero `unmatched_sku_count` and zero `unmatched_party_count`.

Digest serialization rounds revenue and inventory fields to four decimal places before JSON marshaling the tuple for SHA-256.
