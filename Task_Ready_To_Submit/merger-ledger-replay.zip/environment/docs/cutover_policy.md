# Cutover anchor policy

The cutover manifest at `/app/config/cutover_manifest.json` defines `cutover_iso`, `overlap_start`, and `overlap_end`.

Lane-specific anchor dates for zone classification:

| Source lane tag | Anchor field on each admitted row |
|-----------------|-----------------------------------|
| `a`             | `effective_at`                    |
| `b`             | `invoice_at`                      |
| `inv`           | `posted_at`                       |

Rows whose anchor falls between `overlap_start` and `overlap_end` inclusive enter the overlap band where duplicate economic postings may appear in both legacy billing and unified movement feeds.
