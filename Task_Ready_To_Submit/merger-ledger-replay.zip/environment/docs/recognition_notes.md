# Recognition folding notes

Billing lane `a` folds to the calendar month of `ship_at`.

Billing lane `b` folds to the calendar month of `invoice_at`.

Movement lane `inv` is excluded from recognition alignment checks; it still contributes to `inventory_delta`.

Alignment requires folded billing periods to match these lane rules for every admitted billing row.
