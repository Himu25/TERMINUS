package txn

import "strings"

type Record struct {
	ID          string  `json:"id"`
	Lane        string  `json:"lane"`
	SKURaw      string  `json:"sku_raw"`
	PartyRaw    string  `json:"party_raw"`
	Amount      float64 `json:"amount"`
	ShipAt      string  `json:"ship_at"`
	InvoiceAt   string  `json:"invoice_at"`
	PostedAt    string  `json:"posted_at"`
	EffectiveAt string  `json:"effective_at"`
}

func LaneCode(lane string) int {
	switch strings.TrimSpace(lane) {
	case "a":
		return 0
	case "b":
		return 1
	case "inv":
		return 2
	default:
		return -1
	}
}

func Valid(r Record) bool {
	if strings.TrimSpace(r.ID) == "" {
		return false
	}
	if LaneCode(r.Lane) < 0 {
		return false
	}
	if strings.TrimSpace(r.SKURaw) == "" {
		return false
	}
	if strings.TrimSpace(r.PartyRaw) == "" {
		return false
	}
	return true
}
