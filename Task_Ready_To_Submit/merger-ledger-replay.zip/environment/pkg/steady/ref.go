package steady

// Schema version marker for offline replay bundles.
const SchemaVersion = "1"
