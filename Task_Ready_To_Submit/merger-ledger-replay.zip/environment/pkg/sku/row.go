package sku

type Row struct {
	From     string `json:"from"`
	To       string `json:"to"`
	Priority int    `json:"priority"`
}
