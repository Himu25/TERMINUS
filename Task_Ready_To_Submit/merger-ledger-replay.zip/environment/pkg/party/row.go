package party

type Row struct {
	From string `json:"from"`
	To   string `json:"to"`
}
