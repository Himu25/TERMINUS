module lab.local/merger_ledger_replay

go 1.22
