#!/bin/bash
set -euo pipefail

log_line() {
  printf '[oracle] %s\n' "$1"
}

rewrite_boundary() {
  log_line "rewriting cutover boundary"
  cat > /app/internal/cutover/boundary.go <<'GO'
package cutover

import (
	"strings"

	"lab.local/merger_ledger_replay/pkg/txn"
)

const (
	ZoneBefore  = 0
	ZoneInside  = 1
	ZoneAfter   = 2
	ZoneUnknown = 3
)

func anchorISO(row *txn.Record) string {
	switch txn.LaneCode(row.Lane) {
	case 0:
		return dayPrefix(row.EffectiveAt)
	case 1:
		return dayPrefix(row.InvoiceAt)
	case 2:
		return dayPrefix(row.PostedAt)
	default:
		return dayPrefix(row.PostedAt)
	}
}

func dayPrefix(raw string) string {
	raw = strings.TrimSpace(raw)
	if len(raw) >= 10 {
		return raw[:10]
	}
	return raw
}

func OpT(cutoverISO string, overlapStart string, overlapEnd string, row *txn.Record) int {
	anchor := anchorISO(row)
	if anchor == "" {
		return ZoneUnknown
	}
	if anchor < overlapStart {
		return ZoneBefore
	}
	if anchor > overlapEnd {
		return ZoneAfter
	}
	if anchor >= overlapStart && anchor <= overlapEnd {
		return ZoneInside
	}
	if anchor < cutoverISO {
		return ZoneBefore
	}
	return ZoneAfter
}

func SpanAnchors(rows []txn.Record, cutoverISO, overlapStart, overlapEnd string) bool {
	for i := range rows {
		zone := OpT(cutoverISO, overlapStart, overlapEnd, &rows[i])
		if zone == ZoneUnknown {
			return false
		}
		expected := anchorISO(&rows[i])
		lane := txn.LaneCode(rows[i].Lane)
		switch lane {
		case 0:
			if expected != dayPrefix(rows[i].EffectiveAt) {
				return false
			}
		case 1:
			if expected != dayPrefix(rows[i].InvoiceAt) {
				return false
			}
		case 2:
			if expected != dayPrefix(rows[i].PostedAt) {
				return false
			}
		}
	}
	return true
}
GO
}

rewrite_walk() {
  log_line "rewriting sku walk"
  cat > /app/internal/skuresolve/walk.go <<'GO'
package skuresolve

import "lab.local/merger_ledger_replay/pkg/sku"

func OpK(mapRows []sku.Row, code string, maxSteps int) (string, bool) {
	cur := code
	seen := map[string]struct{}{}
	steps := 0
	for {
		if _, ok := seen[cur]; ok {
			return "", false
		}
		seen[cur] = struct{}{}
		next, ok := stepOnce(mapRows, cur)
		if !ok {
			return cur, true
		}
		if next == cur {
			return cur, true
		}
		cur = next
		steps++
		if steps >= maxSteps {
			return "", false
		}
	}
}

func stepOnce(mapRows []sku.Row, code string) (string, bool) {
	var best string
	bestPri := -1
	found := false
	for _, row := range mapRows {
		if row.From != code {
			continue
		}
		if row.Priority > bestPri {
			bestPri = row.Priority
			best = row.To
			found = true
		}
	}
	if !found {
		return "", false
	}
	return best, true
}
GO
}

rewrite_party() {
  log_line "rewriting party resolver"
  cat > /app/internal/partyresolve/op_p.go <<'GO'
package partyresolve

import "lab.local/merger_ledger_replay/pkg/party"

func OpP(mapRows []party.Row, legacyID string, maxSteps int) (string, bool) {
	cur := legacyID
	seen := map[string]struct{}{}
	for step := 0; step < maxSteps; step++ {
		if _, ok := seen[cur]; ok {
			return "", false
		}
		seen[cur] = struct{}{}
		next, ok := stepOnce(mapRows, cur)
		if !ok {
			return cur, true
		}
		if next == cur {
			return cur, true
		}
		cur = next
	}
	if _, ok := stepOnce(mapRows, cur); !ok {
		return cur, true
	}
	next, ok := stepOnce(mapRows, cur)
	if ok && next == cur {
		return cur, true
	}
	return "", false
}

func stepOnce(mapRows []party.Row, code string) (string, bool) {
	for _, row := range mapRows {
		if row.From == code {
			return row.To, true
		}
	}
	return "", false
}
GO
}

rewrite_dedupe() {
  log_line "rewriting overlap dedupe"
  cat > /app/internal/dedupe/window.go <<'GO'
package dedupe

import (
	"fmt"
	"math"

	"lab.local/merger_ledger_replay/pkg/txn"
)

func OpW(rows []txn.Record, overlapStart string, overlapEnd string) ([]txn.Record, int) {
	seen := map[string]struct{}{}
	out := make([]txn.Record, 0, len(rows))
	removed := 0
	for _, row := range rows {
		absAmt := math.Abs(row.Amount)
		key := fmt.Sprintf("%s|%s|%s|%.4f", row.Lane, row.PartyRaw, row.SKURaw, absAmt)
		if _, ok := seen[key]; ok {
			removed++
			continue
		}
		seen[key] = struct{}{}
		out = append(out, row)
	}
	return out, removed
}

func WireKey(row txn.Record, skuCanon, partyCanon string, period string) string {
	absAmt := math.Abs(row.Amount)
	return fmt.Sprintf("%s|%s|%s|%.4f", partyCanon, skuCanon, period, absAmt)
}
GO
}

rewrite_meshfold() {
  log_line "rewriting meshfold period fold"
  cat > /app/meshfold/src/lib.rs <<'RUST'
fn day_prefix(raw: &str) -> String {
    let trimmed = raw.trim();
    if trimmed.len() >= 10 {
        return trimmed[..10].to_string();
    }
    trimmed.to_string()
}

pub fn phase_r(lane: u8, ship: &str, invoice: &str, posted: &str) -> String {
    match lane {
        0 => day_prefix(ship),
        1 => day_prefix(invoice),
        2 => day_prefix(posted),
        _ => day_prefix(invoice),
    }
}

#[no_mangle]
pub extern "C" fn cg_phase_r(lane: u8, ship_ptr: *const u8, ship_len: usize, inv_ptr: *const u8, inv_len: usize, post_ptr: *const u8, post_len: usize, out_ptr: *mut u8, out_cap: usize) -> usize {
    if out_ptr.is_null() || out_cap == 0 {
        return 0;
    }
    let ship = read_str(ship_ptr, ship_len);
    let invoice = read_str(inv_ptr, inv_len);
    let posted = read_str(post_ptr, post_len);
    let folded = phase_r(lane, &ship, &invoice, &posted);
    write_out(&folded, out_ptr, out_cap)
}

fn read_str(ptr: *const u8, len: usize) -> String {
    if ptr.is_null() || len == 0 {
        return String::new();
    }
    let slice = unsafe { std::slice::from_raw_parts(ptr, len) };
    String::from_utf8_lossy(slice).into_owned()
}

fn write_out(text: &str, out_ptr: *mut u8, out_cap: usize) -> usize {
    let bytes = text.as_bytes();
    let n = bytes.len().min(out_cap);
    unsafe {
        std::ptr::copy_nonoverlapping(bytes.as_ptr(), out_ptr, n);
    }
    n
}
RUST
}

rewrite_boundary
rewrite_walk
rewrite_party
rewrite_dedupe
rewrite_meshfold

log_line "rebuilding replay stack"
bash /app/scripts/build.sh

log_line "running ledger replay harness"
/app/tools/ledger_replay /app/config/bench_profiles.json

log_line "done"
