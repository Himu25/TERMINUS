"""Verifier for post-merger ledger replay consolidation report."""

from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "consolidation_report.json"
HARNESS = APP / "tools" / "ledger_replay"
PROFILE = APP / "config" / "bench_profiles.json"
THRESHOLDS = APP / "config" / "thresholds.toml"
FIXTURES = Path("/tests/fixtures")

STEADY: dict[str, dict] = {
    "clean_anchor": {
        "revenue_total": 150.0,
        "inventory_delta": -10.0,
        "duplicate_postings_removed": 0,
        "unmatched_sku_count": 0,
        "unmatched_party_count": 0,
        "cutover_honored": True,
        "recognition_aligned": True,
        "scenario_digest": "ad48fd45",
    },
    "cutover_overlap": {
        "revenue_total": 80.0,
        "inventory_delta": -80.0,
        "duplicate_postings_removed": 1,
        "unmatched_sku_count": 0,
        "unmatched_party_count": 0,
        "cutover_honored": True,
        "recognition_aligned": True,
        "scenario_digest": "678c3c6f",
    },
    "sku_bridge": {
        "revenue_total": 120.0,
        "inventory_delta": -5.0,
        "duplicate_postings_removed": 0,
        "unmatched_sku_count": 0,
        "unmatched_party_count": 0,
        "cutover_honored": True,
        "recognition_aligned": True,
        "scenario_digest": "1f50d528",
    },
    "id_conflict": {
        "revenue_total": 75.0,
        "inventory_delta": 0.0,
        "duplicate_postings_removed": 0,
        "unmatched_sku_count": 0,
        "unmatched_party_count": 0,
        "cutover_honored": True,
        "recognition_aligned": True,
        "scenario_digest": "009bc581",
    },
    "party_chain": {
        "revenue_total": 90.0,
        "inventory_delta": -3.0,
        "duplicate_postings_removed": 0,
        "unmatched_sku_count": 0,
        "unmatched_party_count": 0,
        "cutover_honored": True,
        "recognition_aligned": True,
        "scenario_digest": "d663f438",
    },
    "recognition_mix": {
        "revenue_total": 160.0,
        "inventory_delta": 0.0,
        "duplicate_postings_removed": 0,
        "unmatched_sku_count": 0,
        "unmatched_party_count": 0,
        "cutover_honored": True,
        "recognition_aligned": True,
        "scenario_digest": "095e6292",
    },
    "corrupt_mix": {
        "revenue_total": 25.0,
        "inventory_delta": 0.0,
        "duplicate_postings_removed": 0,
        "unmatched_sku_count": 0,
        "unmatched_party_count": 0,
        "cutover_honored": True,
        "recognition_aligned": True,
        "scenario_digest": "a67cd608",
        "txns_in": 1,
        "txns_quarantined": 1,
    },
}

SCENARIO_KEYS = frozenset(
    {
        "name",
        "txns_in",
        "txns_quarantined",
        "revenue_total",
        "inventory_delta",
        "duplicate_postings_removed",
        "unmatched_sku_count",
        "unmatched_party_count",
        "cutover_honored",
        "recognition_aligned",
        "scenario_digest",
    }
)
SUMMARY_KEYS = frozenset({"composite_score", "total_quarantined", "passes_gate"})
DIGEST_RE = re.compile(r"^[0-9a-f]{8}$")


def _parse_thresholds(path: Path) -> dict[str, float]:
    floors: dict[str, float] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.split("#", 1)[0].strip()
        if not stripped or "=" not in stripped:
            continue
        key, raw = stripped.split("=", 1)
        floors[key.strip()] = float(raw.strip())
    return floors


_FLOORS = _parse_thresholds(THRESHOLDS)


def _run_harness(profile: Path | None = None) -> None:
    cmd = [str(HARNESS)]
    if profile is not None:
        cmd.append(str(profile))
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "consolidation_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


def _by_name(report: dict) -> dict[str, dict]:
    return {row["name"]: row for row in report["scenarios"]}


def _assert_row_matches(name: str, row: dict) -> None:
    exp = STEADY[name]
    assert row["revenue_total"] == exp["revenue_total"]
    assert row["inventory_delta"] == exp["inventory_delta"]
    assert row["duplicate_postings_removed"] == exp["duplicate_postings_removed"]
    assert row["unmatched_sku_count"] == exp["unmatched_sku_count"]
    assert row["unmatched_party_count"] == exp["unmatched_party_count"]
    assert row["cutover_honored"] is exp["cutover_honored"]
    assert row["recognition_aligned"] is exp["recognition_aligned"]
    assert row["scenario_digest"] == exp["scenario_digest"]
    if "txns_in" in exp:
        assert row["txns_in"] == exp["txns_in"]
    if "txns_quarantined" in exp:
        assert row["txns_quarantined"] == exp["txns_quarantined"]


@pytest.fixture(scope="module")
def default_report() -> dict:
    _run_harness(PROFILE)
    return _load_report()


def test_clean_anchor_totals(default_report: dict) -> None:
    """Baseline scenario revenue, inventory_delta, and cutover flags match steady refs."""
    _assert_row_matches("clean_anchor", _by_name(default_report)["clean_anchor"])


def test_cutover_overlap_no_double_count(default_report: dict) -> None:
    """Overlap-window scenario removes duplicate billing postings without double revenue."""
    row = _by_name(default_report)["cutover_overlap"]
    _assert_row_matches("cutover_overlap", row)
    floor = int(_FLOORS["duplicate_postings_removed_cutover_overlap"])
    assert row["duplicate_postings_removed"] >= floor


def test_sku_bridge_chain(default_report: dict) -> None:
    """SKU bridge scenario revenue, inventory delta, and digest match contract."""
    _assert_row_matches("sku_bridge", _by_name(default_report)["sku_bridge"])


def test_id_conflict_scenario_totals(default_report: dict) -> None:
    """Identifier conflict scenario revenue and alignment flags match contract."""
    _assert_row_matches("id_conflict", _by_name(default_report)["id_conflict"])


def test_party_chain_scenario_totals(default_report: dict) -> None:
    """Party chain scenario totals and unmatched counts match contract."""
    _assert_row_matches("party_chain", _by_name(default_report)["party_chain"])


def test_recognition_mix_scenario_totals(default_report: dict) -> None:
    """Recognition mix scenario revenue and alignment flags match contract."""
    _assert_row_matches("recognition_mix", _by_name(default_report)["recognition_mix"])


def test_partial_migration_quarantine(default_report: dict) -> None:
    """Corrupt ingest rows quarantine without inflating admitted totals."""
    row = _by_name(default_report)["corrupt_mix"]
    _assert_row_matches("corrupt_mix", row)
    floor = int(_FLOORS["txns_quarantined_corrupt_mix"])
    assert row["txns_quarantined"] >= floor


def test_exception_counts_preserved(default_report: dict) -> None:
    """Resolved scenarios report zero unmatched sku and party counts."""
    rows = _by_name(default_report)
    for name in ("sku_bridge", "party_chain", "id_conflict"):
        assert rows[name]["unmatched_sku_count"] == 0
        assert rows[name]["unmatched_party_count"] == 0


def test_passes_gate_and_determinism(default_report: dict) -> None:
    """Default profile clears passes_gate and back-to-back runs match bytes."""
    assert default_report["summary"]["passes_gate"] is True
    assert default_report["summary"]["composite_score"] >= _FLOORS["composite_score"]
    first = OUT.read_bytes()
    _run_harness(PROFILE)
    second = OUT.read_bytes()
    assert first == second


def test_report_schema_and_digest(default_report: dict) -> None:
    """Report exposes required keys and eight-char lowercase digests."""
    assert SUMMARY_KEYS.issubset(default_report["summary"].keys())
    for row in default_report["scenarios"]:
        assert SCENARIO_KEYS.issubset(row.keys())
        assert DIGEST_RE.match(row["scenario_digest"])


def test_alternate_profile_fixture() -> None:
    """Harness runs cleanly when given a single-scenario profile path."""
    alt = FIXTURES / "profile_overlap_only.json"
    assert alt.is_file()
    _run_harness(alt)
    report = _load_report()
    names = [row["name"] for row in report["scenarios"]]
    assert names == ["cutover_overlap"]
    _assert_row_matches("cutover_overlap", report["scenarios"][0])
