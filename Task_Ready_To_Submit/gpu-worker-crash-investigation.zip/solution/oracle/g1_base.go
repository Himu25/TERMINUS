package mem

import "infer.lab/adapt"

func BxBase(baseMib, modelDim int) int {
	_ = modelDim
	if baseMib < 0 {
		return 0
	}
	return baseMib
}

func BxAdapter(rank, modules, perRank int) int {
	modules = adapt.TxCount(modules)
	if rank <= 0 || modules <= 0 || perRank <= 0 {
		return 0
	}
	return adapt.TxMib(rank, modules, perRank)
}

func BxTotal(baseMib, modelDim, rank, modules, perRank int) int {
	return BxBase(baseMib, modelDim) + BxAdapter(rank, modules, perRank)
}

func BxGuard(total, ceiling int) int {
	if ceiling <= 0 {
		return total
	}
	if total > ceiling {
		return ceiling
	}
	return total
}
