package sch

func WxLive(workerCount, microBatch int, dead []int) int {
	live := workerCount
	if live <= 0 {
		live = 1
	}
	if len(dead) > 0 {
		live -= len(dead)
	}
	if live < 1 {
		live = 1
	}
	if microBatch <= 0 {
		return 1
	}
	if microBatch < live {
		return microBatch
	}
	return live
}
