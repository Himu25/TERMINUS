package sch

func SxUnits(active, accum int) int {
	if active <= 0 {
		active = 1
	}
	if accum <= 0 {
		accum = 1
	}
	return active * (accum + 1) * 12
}
