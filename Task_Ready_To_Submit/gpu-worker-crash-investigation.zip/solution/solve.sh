#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/pipeline.toml
require_file /app/data/batch_specs.jsonl
require_file /app/data/val_corpus.json
mkdir -p /app/bin /app/output

log "apply patched sources"
cp "${ROOT_DIR}/oracle/m4_scale.go" /app/adapt/m4_scale.go
cp "${ROOT_DIR}/oracle/l1_layers.go" /app/adapt/l1_layers.go
cp "${ROOT_DIR}/oracle/g1_base.go" /app/mem/g1_base.go
cp "${ROOT_DIR}/oracle/g2_frag.go" /app/mem/g2_frag.go
cp "${ROOT_DIR}/oracle/g3_batch.go" /app/mem/g3_batch.go
cp "${ROOT_DIR}/oracle/w5_sync.go" /app/sch/w5_sync.go
cp "${ROOT_DIR}/oracle/w6_lane.go" /app/sch/w6_lane.go
cp "${ROOT_DIR}/oracle/w7_mp.go" /app/sch/w7_mp.go
cp "${ROOT_DIR}/oracle/w8_pool.go" /app/sch/w8_pool.go
cp "${ROOT_DIR}/oracle/w9_sync.go" /app/sch/w9_sync.go
cp "${ROOT_DIR}/oracle/p5_balance.go" /app/coord/p5_balance.go
cp "${ROOT_DIR}/oracle/q9_mix.go" /app/eval/q9_mix.go
cp "${ROOT_DIR}/oracle/r4_span.go" /app/drv/r4_span.go

log "rebuild driver"
go build -o /app/bin/inferd ./cmd/inferd
go build -o /app/bin/batchgen ./cmd/batchgen

log "refresh default batch bundle"
/app/bin/batchgen /app/data/batch_specs.jsonl /app/data/batches_default.jsonl

log "emit default report"
/app/bin/inferd /app/data/batches_default.jsonl /app/output/worker_bench.json

log "post-run validation against pipeline.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/pipeline.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k.endswith("_floor") or k.endswith("_score") or k.startswith("mp_") or k.startswith("sync_") or k.startswith("corpus_mix"):
        cfg[k] = float(v)
    elif k.startswith("max_") or k.startswith("long_") or k.startswith("burst_") or k == "balance_workers_floor":
        cfg[k] = int(float(v))
    elif k == "balance_spread_floor":
        cfg[k] = float(v)

report = json.loads(Path("/app/output/worker_bench.json").read_text())
assert report["status"] == "ok", report
assert report["mean_infer_quality"] >= cfg["infer_quality_floor"]
assert report["mean_gpu_mib"] <= cfg["max_mean_gpu_mib"]
assert report["p95_gpu_mib"] <= cfg["max_p95_gpu_mib"]
assert report["mean_uptime_score"] >= cfg["min_uptime_score"]
assert report["pool_peak_mib"] <= cfg["max_pool_peak_mib"]
assert report["mean_mp_stable"] >= cfg["mp_min_stable"]
assert report["mean_corpus_mix"] >= cfg["corpus_mix_floor"]
assert report["mean_sync_stable"] >= cfg["sync_min_stable"]
assert report["mean_sync_units"] <= cfg["max_mean_sync_units"]
for row in report["batches"]:
    if row["batch_id"] == "b_balance_mix":
        assert row["workers_active"] >= cfg["balance_workers_floor"], row
        assert row["balance_spread"] >= cfg["balance_spread_floor"], row
    if row["batch_id"].startswith("b_burst_ctx_"):
        assert row["gpu_mib"] <= cfg["long_ctx_gpu_ceiling"], row
    if row["batch_id"].startswith("b_burst_batch_"):
        assert row["gpu_mib"] <= cfg["burst_batch_gpu_ceiling"], row
    if row["batch_id"].startswith("b_sync_") and row["accum_steps"] > 1:
        assert row["sync_stable"] is True, row
print("ok", report["mean_infer_quality"], report["p95_gpu_mib"], report["pool_peak_mib"])
PY

log "oracle complete"
