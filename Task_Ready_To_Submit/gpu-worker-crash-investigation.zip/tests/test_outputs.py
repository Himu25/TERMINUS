"""Validate /app/output/worker_bench.json against pipeline.toml guardrails.

Covers report schema, digest determinism, default-bundle quality floors,
long-context and wide-batch CUDA memory ceilings, mixed-precision stability,
worker sync carryover, pool residency spikes, and ablations for fragmented
GPU memory, mixed-precision drift, and worker starvation partial fixes.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from contextlib import contextmanager
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "worker_bench.json"
BATCHES = APP / "data" / "batches_default.jsonl"
CFG = APP / "config" / "pipeline.toml"
LORAD = "/app/bin/inferd"
INVOKER = Path(__file__).resolve().parent / "invoke_runner.sh"
FX = Path(__file__).resolve().parent / "fx"
FIXTURES = Path(__file__).resolve().parent / "fixtures"
STEADY = APP / "docs" / "steady_tokens.txt"
MEAN_TOLERANCE = 2e-4

def _bundled_batches_text() -> str:
    if BATCHES.is_file():
        return BATCHES.read_text(encoding="utf-8")
    return ""


REPORT_KEYS = frozenset(
    {
        "status",
        "model_dim",
        "worker_count",
        "batches_total",
        "mean_infer_quality",
        "mean_gpu_mib",
        "mean_infer_units",
        "mean_uptime_score",
        "p95_gpu_mib",
        "pool_peak_mib",
        "mean_mp_stable",
        "mean_corpus_mix",
        "mean_sync_stable",
        "mean_sync_units",
        "mean_workers_active",
        "mean_balance_spread",
        "report_digest",
        "batches",
    }
)
ROW_KEYS = frozenset(
    {
        "batch_id",
        "seq_len",
        "infer_quality",
        "gpu_mib",
        "infer_units",
        "uptime_score",
        "accum_steps",
        "pool_mib",
        "mp_stable",
        "corpus_mix",
        "sync_stable",
        "workers_active",
        "sync_units",
        "balance_spread",
    }
)

HARD_BAND_STEMS = [
    "scenario_frag_storm",
    "scenario_mp_ladder",
    "scenario_worker_starve",
    "scenario_dual_burst",
    "scenario_pool_spike",
    "scenario_sync_storm",
]


def _steady_lookup() -> dict[str, float]:
    out: dict[str, float] = {}
    if not STEADY.is_file():
        return out
    for line in STEADY.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) == 2:
            key, val = parts
            if val.replace(".", "", 1).isdigit():
                out[key] = float(val)
    return out


def _steady_pct(key: str) -> float:
    steady = _steady_lookup()
    return steady[key] / 100.0


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "model_dim": 768,
        "worker_count": 16,
        "mp_scale": 32,
        "base_mib": 380,
        "adapter_mib_per_rank": 2,
        "infer_quality_floor": 0.65,
        "max_mean_gpu_mib": 820,
        "max_p95_gpu_mib": 950,
        "min_uptime_score": 1.0,
        "max_pool_peak_mib": 1100,
        "long_ctx_gpu_ceiling": 740,
        "mp_min_stable": 0.85,
        "corpus_mix_floor": 0.10,
        "sync_min_stable": 0.85,
        "burst_batch_gpu_ceiling": 680,
        "max_mean_sync_units": 4200,
        "balance_workers_floor": 4,
        "balance_spread_floor": 0.72,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in (
            "infer_quality_floor",
            "min_uptime_score",
            "mp_min_stable",
            "corpus_mix_floor",
            "sync_min_stable",
        ):
            cfg[key] = float(val)
        elif key in (
            "model_dim",
            "worker_count",
            "mp_scale",
            "base_mib",
            "adapter_mib_per_rank",
            "max_mean_gpu_mib",
            "max_p95_gpu_mib",
            "max_pool_peak_mib",
            "long_ctx_gpu_ceiling",
            "burst_batch_gpu_ceiling",
            "max_mean_sync_units",
            "balance_workers_floor",
        ):
            cfg[key] = int(float(val))
        elif key == "balance_spread_floor":
            cfg[key] = float(val)
    return cfg


@pytest.fixture(autouse=True)
def restore_default_batches() -> None:
    yield
    bundled = _bundled_batches_text()
    if bundled:
        _atomic_write_text(BATCHES, bundled)


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _swap_fixture(stem: str) -> None:
    src = FIXTURES / f"{stem}.jsonl"
    _atomic_write_text(BATCHES, src.read_text(encoding="utf-8"))


def _round4(value: float) -> float:
    return round(value * 10000 + 0.5) / 10000


def _expected_means(rows: list[dict]) -> tuple[float, float, float, float, float, float, float, float, float, float]:
    if not rows:
        return (0.0,) * 10
    total = len(rows)
    acc = sum(row["infer_quality"] for row in rows) / total
    vram = sum(row["gpu_mib"] for row in rows) / total
    units = sum(row["infer_units"] for row in rows) / total
    tput = sum(row["uptime_score"] for row in rows) / total
    stable = sum(1 for row in rows if row["mp_stable"]) / total
    mix = sum(row["corpus_mix"] for row in rows) / total
    resume = sum(1 for row in rows if row["sync_stable"]) / total
    sync = sum(row["sync_units"] for row in rows) / total
    active = sum(row["workers_active"] for row in rows) / total
    balance = sum(row["balance_spread"] for row in rows) / total
    return (
        _round4(acc),
        _round4(vram),
        _round4(units),
        _round4(tput),
        _round4(stable),
        _round4(mix),
        _round4(resume),
        _round4(sync),
        _round4(active),
        _round4(balance),
    )


def _p95_vram(rows: list[dict]) -> int:
    vals = sorted(row["gpu_mib"] for row in rows)
    if not vals:
        return 0
    idx = max(0, min(len(vals) - 1, int(0.95 * len(vals) + 0.999999) - 1))
    return vals[idx]


def _digest_payload(report: dict) -> dict:
    return {
        "status": report["status"],
        "model_dim": report["model_dim"],
        "worker_count": report["worker_count"],
        "batches_total": report["batches_total"],
        "mean_infer_quality": report["mean_infer_quality"],
        "mean_gpu_mib": report["mean_gpu_mib"],
        "mean_infer_units": report["mean_infer_units"],
        "mean_uptime_score": report["mean_uptime_score"],
        "p95_gpu_mib": report["p95_gpu_mib"],
        "pool_peak_mib": report["pool_peak_mib"],
        "mean_mp_stable": report["mean_mp_stable"],
        "mean_corpus_mix": report["mean_corpus_mix"],
        "mean_sync_stable": report["mean_sync_stable"],
        "mean_sync_units": report["mean_sync_units"],
        "mean_workers_active": report["mean_workers_active"],
        "mean_balance_spread": report["mean_balance_spread"],
        "report_digest": "",
        "batches": report["batches"],
    }


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _run_bench(batch_path: Path, out_path: Path) -> None:
    proc = subprocess.run(
        [LORAD, str(batch_path), str(out_path)],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _invoke_default() -> None:
    proc = subprocess.run(
        ["bash", str(INVOKER)],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "worker_bench.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


def _bench_fixture(name: str, batch_file: Path) -> dict:
    out = APP / "output" / name
    _run_bench(batch_file, out)
    return json.loads(out.read_text(encoding="utf-8"))


class _AblationBuildFailed(Exception):
    """Raised when the broken file causes a compile error — valid ablation signal."""


@contextmanager
def _swap_go(rel_path: str, fixture_name: str):
    target = APP / rel_path
    backup = target.read_text(encoding="utf-8")
    shutil.copy(FX / fixture_name, target)
    try:
        proc = subprocess.run(
            ["go", "build", "-o", str(APP / "bin" / "inferd"), "./cmd/inferd"],
            cwd=str(APP),
            capture_output=True,
            text=True,
            check=False,
        )
        if proc.returncode != 0:
            raise _AblationBuildFailed(proc.stderr or proc.stdout)
        yield
    finally:
        target.write_text(backup, encoding="utf-8")
        proc = subprocess.run(
            ["go", "build", "-o", str(APP / "bin" / "inferd"), "./cmd/inferd"],
            cwd=str(APP),
            capture_output=True,
            text=True,
            check=False,
        )
        assert proc.returncode == 0, proc.stderr or proc.stdout
        _invoke_default()


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    """Run the default bench once before the module-scoped assertions."""
    assert INVOKER.is_file(), "runner script missing"
    _invoke_default()


def test_report_top_level_keys_exact() -> None:
    """Report must expose only the documented top-level keys."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS


def test_batch_row_schema() -> None:
    """Each batch row must match the documented per-batch schema."""
    report = _load_report()
    assert report["batches"]
    for row in report["batches"]:
        assert set(row.keys()) == ROW_KEYS
        assert isinstance(row["batch_id"], str) and row["batch_id"]
        assert isinstance(row["seq_len"], int) and row["seq_len"] > 0
        assert isinstance(row["accum_steps"], int) and row["accum_steps"] >= 1
        assert 0.0 <= float(row["infer_quality"]) <= 1.0
        assert row["gpu_mib"] >= 0
        assert row["infer_units"] >= 0
        assert float(row["uptime_score"]) >= 0.0
        assert row["pool_mib"] >= 0
        assert isinstance(row["mp_stable"], bool)
        assert 0.0 <= float(row["corpus_mix"]) <= 1.0
        assert isinstance(row["sync_stable"], bool)
        assert row["workers_active"] >= 0
        assert row["sync_units"] >= 0
        assert 0.0 <= float(row["balance_spread"]) <= 1.0


def test_passing_run_contract() -> None:
    """Default bundle must finish ok and meet pipeline.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["model_dim"] == cfg["model_dim"]
    assert report["worker_count"] == cfg["worker_count"]
    assert report["batches_total"] == len(report["batches"])
    assert report["mean_infer_quality"] >= cfg["infer_quality_floor"]
    assert report["mean_gpu_mib"] <= cfg["max_mean_gpu_mib"]
    assert report["p95_gpu_mib"] <= cfg["max_p95_gpu_mib"]
    assert report["mean_uptime_score"] >= cfg["min_uptime_score"]
    assert report["pool_peak_mib"] <= cfg["max_pool_peak_mib"]
    assert report["mean_mp_stable"] >= cfg["mp_min_stable"]
    assert report["mean_corpus_mix"] >= cfg["corpus_mix_floor"]
    assert report["mean_sync_stable"] >= cfg["sync_min_stable"]
    assert report["mean_sync_units"] <= cfg["max_mean_sync_units"]


def test_mean_fields_recomputed_from_batches() -> None:
    """Summary means must match per-batch rows within tolerance."""
    report = _load_report()
    (
        exp_acc,
        exp_vram,
        exp_units,
        exp_tput,
        exp_stable,
        exp_mix,
        exp_resume,
        exp_sync,
        exp_active,
        exp_balance,
    ) = _expected_means(report["batches"])
    assert abs(report["mean_infer_quality"] - exp_acc) <= MEAN_TOLERANCE
    assert abs(report["mean_gpu_mib"] - exp_vram) <= MEAN_TOLERANCE
    assert abs(report["mean_infer_units"] - exp_units) <= MEAN_TOLERANCE
    assert abs(report["mean_uptime_score"] - exp_tput) <= MEAN_TOLERANCE
    assert abs(report["mean_mp_stable"] - exp_stable) <= MEAN_TOLERANCE
    assert abs(report["mean_corpus_mix"] - exp_mix) <= MEAN_TOLERANCE
    assert abs(report["mean_sync_stable"] - exp_resume) <= MEAN_TOLERANCE
    assert abs(report["mean_sync_units"] - exp_sync) <= MEAN_TOLERANCE
    assert abs(report["mean_workers_active"] - exp_active) <= MEAN_TOLERANCE
    assert abs(report["mean_balance_spread"] - exp_balance) <= MEAN_TOLERANCE
    assert report["p95_gpu_mib"] == _p95_vram(report["batches"])
    peak = max(row["pool_mib"] for row in report["batches"])
    assert report["pool_peak_mib"] == peak


def test_report_digest_matches_payload() -> None:
    """report_digest must hash the compact pre-digest JSON payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_deterministic_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_long_context_rows_respect_ceiling() -> None:
    """Long-context default rows must stay at or below long_ctx_gpu_ceiling."""
    cfg = _parse_cfg()
    report = _load_report()
    long_rows = [row for row in report["batches"] if row["batch_id"].startswith("b_burst_ctx_")]
    assert long_rows, "expected b_burst_ctx_ rows in default bundle"
    for row in long_rows:
        assert row["gpu_mib"] <= cfg["long_ctx_gpu_ceiling"], row


def test_shard_rows_respect_ceiling() -> None:
    """Micro-shard default rows must stay at or below burst_batch_gpu_ceiling."""
    cfg = _parse_cfg()
    report = _load_report()
    shard_rows = [row for row in report["batches"] if row["batch_id"].startswith("b_burst_batch_")]
    assert len(shard_rows) >= 2
    for row in shard_rows:
        assert row["gpu_mib"] <= cfg["burst_batch_gpu_ceiling"], row


def test_resume_rows_stable() -> None:
    """Named resume rows must report sync_stable true with accum_steps above one."""
    report = _load_report()
    for batch_id in ("b_sync_ops", "b_sync_billing"):
        row = next(r for r in report["batches"] if r["batch_id"] == batch_id)
        assert row["accum_steps"] > 1
        assert row["sync_stable"] is True, row


def test_accumulation_rows_stable() -> None:
    """Named accumulation rows must report mp_stable true with accum_steps above one."""
    report = _load_report()
    for batch_id in ("b_mp_ops", "b_mp_billing"):
        row = next(r for r in report["batches"] if r["batch_id"] == batch_id)
        assert row["accum_steps"] > 1
        assert row["mp_stable"] is True, row


def test_balance_row_spreads_workers() -> None:
    """Balance-mix row must fan out workers and meet spread floor."""
    cfg = _parse_cfg()
    report = _load_report()
    row = next(r for r in report["batches"] if r["batch_id"] == "b_balance_mix")
    assert row["workers_active"] >= cfg["balance_workers_floor"], row
    assert row["balance_spread"] >= cfg["balance_spread_floor"], row
    assert row["uptime_score"] >= cfg["min_uptime_score"], row


def test_long_seq_fixture_pack() -> None:
    """Long-sequence fixture pack must keep VRAM under the long-context ceiling."""
    cfg = _parse_cfg()
    report = _bench_fixture("bench_long_seq.json", APP / "data" / "fixture_long_seq.jsonl")
    for row in report["batches"]:
        assert row["batch_id"].startswith("b_burst_ctx_")
        assert row["gpu_mib"] <= cfg["long_ctx_gpu_ceiling"], row
    assert report["p95_gpu_mib"] <= cfg["max_p95_gpu_mib"]


def test_accum_fixture_pack() -> None:
    """Gradient-accumulation fixture pack must keep mp_stable high."""
    cfg = _parse_cfg()
    report = _bench_fixture("bench_accum_pack.json", APP / "data" / "fixture_accum.jsonl")
    assert report["mean_mp_stable"] >= cfg["mp_min_stable"]
    for row in report["batches"]:
        if row["accum_steps"] > 1:
            assert row["mp_stable"] is True, row


def test_opt_spike_fixture_pack() -> None:
    """Optimizer-heavy fixture pack must stay within peak residency ceiling."""
    cfg = _parse_cfg()
    report = _bench_fixture("bench_opt_spike.json", APP / "data" / "fixture_opt.jsonl")
    assert report["pool_peak_mib"] <= cfg["max_pool_peak_mib"]
    assert report["mean_infer_quality"] >= cfg["infer_quality_floor"]
    opt_rows = [row for row in report["batches"] if row["batch_id"].startswith("b_pool_")]
    assert len(opt_rows) >= 2
    for row in opt_rows:
        assert row["pool_mib"] <= cfg["max_pool_peak_mib"], row


def test_shard_fixture_pack() -> None:
    """Micro-shard fixture pack must keep shard VRAM under the shard ceiling."""
    cfg = _parse_cfg()
    report = _bench_fixture("bench_shard_pack.json", APP / "data" / "fixture_shard.jsonl")
    for row in report["batches"]:
        assert row["batch_id"].startswith("b_burst_batch_")
        assert row["gpu_mib"] <= cfg["burst_batch_gpu_ceiling"], row


def test_resume_fixture_pack() -> None:
    """Resume fixture pack must keep sync_stable high on multi-step rows."""
    cfg = _parse_cfg()
    report = _bench_fixture("bench_resume_pack.json", APP / "data" / "fixture_resume.jsonl")
    assert report["mean_sync_stable"] >= cfg["sync_min_stable"]
    for row in report["batches"]:
        if row["batch_id"].startswith("b_sync_") and row["accum_steps"] > 1:
            assert row["sync_stable"] is True, row


def test_corpus_fixture_pack() -> None:
    """Corpus-weighted fixture pack must keep mean accuracy above the floor."""
    cfg = _parse_cfg()
    report = _bench_fixture("bench_corpus_pack.json", APP / "data" / "fixture_corpus.jsonl")
    assert report["mean_infer_quality"] >= cfg["infer_quality_floor"]
    assert report["mean_corpus_mix"] >= cfg["corpus_mix_floor"]


def test_broken_scale_ablation_fails_accuracy() -> None:
    """Inverted inference scaling must drop validation accuracy below the floor."""
    cfg = _parse_cfg()
    baseline = _bench_fixture("bench_baseline_scale.json", APP / "data" / "batches_default.jsonl")
    try:
        with _swap_go("adapt/m4_scale.go", "broken_m4_scale.go"):
            report = _bench_fixture(
                "bench_ablation_scale.json",
                APP / "data" / "batches_default.jsonl",
            )
    except _AblationBuildFailed:
        return
    floor_violated = report["mean_infer_quality"] < cfg["infer_quality_floor"]
    significant_drop = baseline["mean_infer_quality"] - report["mean_infer_quality"] > 0.04
    assert floor_violated or significant_drop, (
        f"baseline={baseline['mean_infer_quality']}, broken={report['mean_infer_quality']}"
    )


def test_broken_seqpad_ablation_fails_long_seq() -> None:
    """Fragmented CUDA pool padding must blow past the long-context gpu_mib ceiling."""
    cfg = _parse_cfg()
    baseline = _bench_fixture("bench_baseline_seqpad.json", APP / "data" / "fixture_long_seq.jsonl")
    try:
        with _swap_go("mem/g2_frag.go", "broken_g2_frag.go"):
            report = _bench_fixture(
                "bench_ablation_seqpad.json",
                APP / "data" / "fixture_long_seq.jsonl",
            )
    except _AblationBuildFailed:
        return
    over = [row for row in report["batches"] if row["gpu_mib"] > cfg["long_ctx_gpu_ceiling"]]
    vram_increase = report["mean_gpu_mib"] - baseline["mean_gpu_mib"] > 40
    assert over or vram_increase, "expected long-seq VRAM ceiling violation under broken padding"


def test_broken_accum_ablation_unstable() -> None:
    """Multiply-style mixed-precision normalization must mark mp_stable false."""
    baseline = _bench_fixture("bench_baseline_accum.json", APP / "data" / "fixture_accum.jsonl")
    try:
        with _swap_go("sch/w7_mp.go", "broken_w7_mp.go"):
            report = _bench_fixture(
                "bench_ablation_accum.json",
                APP / "data" / "fixture_accum.jsonl",
            )
    except _AblationBuildFailed:
        return
    unstable = [row for row in report["batches"] if row["accum_steps"] > 1 and not row["mp_stable"]]
    stability_drop = baseline["mean_mp_stable"] - report["mean_mp_stable"] > 0.1
    assert unstable or stability_drop, "expected unstable accum rows under broken normalization"


def test_broken_optstate_ablation_spikes() -> None:
    """Inflated optimizer residency model must exceed the peak ceiling."""
    cfg = _parse_cfg()
    baseline = _bench_fixture("bench_baseline_opt.json", APP / "data" / "fixture_opt.jsonl")
    try:
        with _swap_go("sch/w8_pool.go", "broken_w8_pool.go"):
            report = _bench_fixture(
                "bench_ablation_opt.json",
                APP / "data" / "fixture_opt.jsonl",
            )
    except _AblationBuildFailed:
        return
    ceiling_violated = report["pool_peak_mib"] > cfg["max_pool_peak_mib"]
    significant_spike = report["pool_peak_mib"] - baseline["pool_peak_mib"] > 80
    assert ceiling_violated or significant_spike, (
        f"baseline_peak={baseline['pool_peak_mib']}, broken_peak={report['pool_peak_mib']}"
    )


def test_broken_adapter_ablation_spikes_vram() -> None:
    """Under-counted adapter residency must push opt-heavy rows past mean VRAM ceiling."""
    cfg = _parse_cfg()
    baseline = _bench_fixture("bench_baseline_adapter.json", APP / "data" / "fixture_opt.jsonl")
    try:
        with _swap_go("adapt/l1_layers.go", "broken_l1_layers.go"):
            report = _bench_fixture(
                "bench_ablation_adapter.json",
                APP / "data" / "fixture_opt.jsonl",
            )
    except _AblationBuildFailed:
        return
    ceiling_violated = report["pool_peak_mib"] > cfg["max_pool_peak_mib"]
    significant_spike = report["pool_peak_mib"] - baseline["pool_peak_mib"] > 80
    assert ceiling_violated or significant_spike, (
        f"baseline_peak={baseline['pool_peak_mib']}, broken_peak={report['pool_peak_mib']}"
    )


def test_broken_corpus_mix_ablation_fails_accuracy() -> None:
    """Subtract-style corpus mixing must drop validation accuracy below the floor."""
    cfg = _parse_cfg()
    baseline = _bench_fixture("bench_baseline_corpus.json", APP / "data" / "fixture_corpus.jsonl")
    try:
        with _swap_go("eval/q9_mix.go", "broken_q9_mix.go"):
            report = _bench_fixture(
                "bench_ablation_corpus.json",
                APP / "data" / "fixture_corpus.jsonl",
            )
    except _AblationBuildFailed:
        return
    floor_violated = report["mean_infer_quality"] < cfg["infer_quality_floor"]
    significant_drop = baseline["mean_infer_quality"] - report["mean_infer_quality"] > 0.04
    assert floor_violated or significant_drop, (
        f"baseline={baseline['mean_infer_quality']}, broken={report['mean_infer_quality']}"
    )


def test_broken_shard_ablation_fails_ceiling() -> None:
    """Linear micro-batch shard padding must blow past the shard VRAM ceiling."""
    cfg = _parse_cfg()
    baseline = _bench_fixture("bench_baseline_shard.json", APP / "data" / "fixture_shard.jsonl")
    try:
        with _swap_go("mem/g3_batch.go", "broken_g3_batch.go"):
            report = _bench_fixture(
                "bench_ablation_shard.json",
                APP / "data" / "fixture_shard.jsonl",
            )
    except _AblationBuildFailed:
        return
    over = [row for row in report["batches"] if row["gpu_mib"] > cfg["burst_batch_gpu_ceiling"]]
    vram_increase = report["mean_gpu_mib"] - baseline["mean_gpu_mib"] > 40
    assert over or vram_increase, "expected shard VRAM ceiling violation under broken shard padding"


def test_broken_resume_ablation_unstable() -> None:
    """Inflated worker sync carryover must mark sync rows unstable."""
    baseline = _bench_fixture("bench_baseline_resume.json", APP / "data" / "fixture_resume.jsonl")
    try:
        with _swap_go("sch/w9_sync.go", "broken_w9_sync.go"):
            report = _bench_fixture(
                "bench_ablation_resume.json",
                APP / "data" / "fixture_resume.jsonl",
            )
    except _AblationBuildFailed:
        return
    unstable = [
        row
        for row in report["batches"]
        if row["batch_id"].startswith("b_sync_") and row["accum_steps"] > 1 and not row["sync_stable"]
    ]
    sync_drop = baseline["mean_sync_stable"] - report["mean_sync_stable"] > 0.1
    assert unstable or sync_drop, "expected unstable resume rows under broken carryover"


def test_broken_worker_lane_ablation_starves() -> None:
    """Pinned single-worker dispatch must fail balance spread on starve pack."""
    cfg = _parse_cfg()
    _swap_fixture("scenario_worker_starve")
    _invoke_default()
    baseline = _load_report()
    baseline_row = next(r for r in baseline["batches"] if r["batch_id"] == "b_balance_mix")
    try:
        with _swap_go("sch/w6_lane.go", "broken_w6_lane.go"):
            _swap_fixture("scenario_worker_starve")
            _invoke_default()
            report = _load_report()
    except _AblationBuildFailed:
        return
    row = next(r for r in report["batches"] if r["batch_id"] == "b_balance_mix")
    floor_violated = row["workers_active"] < cfg["balance_workers_floor"]
    significant_drop = baseline_row["workers_active"] - row["workers_active"] >= 2
    assert floor_violated or significant_drop, row


def test_broken_sync_units_ablation_spikes() -> None:
    """Under-counted sync units must keep mean_sync_units below oracle tally."""
    try:
        with _swap_go("sch/w5_sync.go", "broken_w5_sync.go"):
            _swap_fixture("scenario_dual_burst")
            _invoke_default()
            broken = _load_report()
    except _AblationBuildFailed:
        return
    _swap_fixture("scenario_dual_burst")
    _invoke_default()
    fixed = _load_report()
    assert broken["mean_sync_units"] < fixed["mean_sync_units"]


@pytest.mark.parametrize("stem", HARD_BAND_STEMS)
def test_hard_scenario_target_bands(stem: str) -> None:
    """Indexed hard stems must meet oracle replay bands with bounded slack."""
    cfg = _parse_cfg()
    _swap_fixture(stem)
    _invoke_default()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["mean_infer_quality"] >= cfg["infer_quality_floor"] * _steady_pct(
        "hard_band_quality_pct"
    )
    assert report["mean_uptime_score"] >= cfg["min_uptime_score"] * _steady_pct(
        "hard_band_uptime_pct"
    )
    assert report["mean_mp_stable"] >= cfg["mp_min_stable"] * _steady_pct(
        "hard_band_quality_pct"
    )
    assert report["mean_sync_stable"] >= cfg["sync_min_stable"] * _steady_pct(
        "hard_band_quality_pct"
    )
    assert report["mean_sync_units"] <= cfg["max_mean_sync_units"]
    assert len(report["report_digest"]) == 64


@pytest.mark.parametrize(
    "stem",
    [
        "scenario_frag_storm",
        "scenario_mp_ladder",
        "scenario_worker_starve",
        "scenario_dual_burst",
        "scenario_pool_spike",
        "scenario_sync_storm",
    ],
)
def test_indexed_fixture_scenarios(stem: str) -> None:
    """Indexed scenario packs listed in fixture_index.txt must bench clean."""
    cfg = _parse_cfg()
    _swap_fixture(stem)
    _invoke_default()
    report = _load_report()
    assert report["status"] == "ok"
    steady = _steady_lookup()
    assert report["mean_infer_quality"] >= steady["fixture_infer_quality_floor"]
    assert report["mean_uptime_score"] >= steady["fixture_uptime_floor"]
    assert report["mean_sync_units"] <= cfg["max_mean_sync_units"]
