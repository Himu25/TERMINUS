package sch

func SxUnits(active, accum int) int {
	_ = active
	if accum <= 0 {
		accum = 1
	}
	return accum * 8
}
