#!/bin/bash
set -euo pipefail
cd /app
mkdir -p /app/output
/app/tools/run_infer
