package types

type PipelineCfg struct {
	ModelDim               int
	LoraRank               int
	LoraAlpha              int
	BaseMib                int
	AdapterMibPerRank      int
	ValAccuracyFloor       float64
	MaxMeanVramMib         int
	MaxP95VramMib          int
	MinThroughputScore     float64
	MaxPeakOptimizerMib    int
	LongSeqVramCeiling     int
	AccumMinStable         float64
	CorpusMixFloor         float64
	ResumeMinStable        float64
	MicroShardVramCeiling  int
	MaxMeanSyncUnits       int
	BalanceWorkersFloor    int
	BalanceSpreadFloor     float64
	CorpusPath             string
}

type BatchCase struct {
	BatchID       string  `json:"batch_id"`
	SeqLen        int     `json:"seq_len"`
	MicroBatch    int     `json:"micro_batch"`
	AccumSteps    int     `json:"accum_steps"`
	TargetModules int     `json:"target_modules"`
	ValLabel      float64 `json:"val_label"`
	Topic         string  `json:"topic"`
	ResumeEpoch   int     `json:"resume_epoch"`
	DeadWorkers   []int   `json:"dead_workers,omitempty"`
}

type BatchRow struct {
	BatchID         string  `json:"batch_id"`
	SeqLen          int     `json:"seq_len"`
	ValAccuracy     float64 `json:"infer_quality"`
	VramMib         int     `json:"gpu_mib"`
	StepUnits       int     `json:"infer_units"`
	ThroughputScore float64 `json:"uptime_score"`
	AccumSteps      int     `json:"accum_steps"`
	OptimizerMib    int     `json:"pool_mib"`
	AccumStable     bool    `json:"mp_stable"`
	CorpusMix       float64 `json:"corpus_mix"`
	ResumeStable    bool    `json:"sync_stable"`
	WorkersActive   int     `json:"workers_active"`
	SyncUnits       int     `json:"sync_units"`
	BalanceSpread   float64 `json:"balance_spread"`
}

type BenchReport struct {
	Status              string     `json:"status"`
	ModelDim            int        `json:"model_dim"`
	LoraRank            int        `json:"worker_count"`
	BatchesTotal        int        `json:"batches_total"`
	MeanValAccuracy     float64    `json:"mean_infer_quality"`
	MeanVramMib         float64    `json:"mean_gpu_mib"`
	MeanStepUnits       float64    `json:"mean_infer_units"`
	MeanThroughputScore float64    `json:"mean_uptime_score"`
	P95VramMib          int        `json:"p95_gpu_mib"`
	PeakOptimizerMib    int        `json:"pool_peak_mib"`
	MeanAccumStable     float64    `json:"mean_mp_stable"`
	MeanCorpusMix       float64    `json:"mean_corpus_mix"`
	MeanResumeStable    float64    `json:"mean_sync_stable"`
	MeanSyncUnits       float64    `json:"mean_sync_units"`
	MeanWorkersActive   float64    `json:"mean_workers_active"`
	MeanBalanceSpread   float64    `json:"mean_balance_spread"`
	ReportDigest        string     `json:"report_digest"`
	Batches             []BatchRow `json:"batches"`
}
