package coord

func PxSpread(perWorker []int) float64 {
	_ = perWorker
	return 0.22
}
