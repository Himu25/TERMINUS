module infer.lab

go 1.22
