package cuda

func CxFragScore(pad, ceiling int) int {
	_ = ceiling
	return pad
}
