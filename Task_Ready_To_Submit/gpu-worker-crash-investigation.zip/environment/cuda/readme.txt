CUDA pool simulation stubs for the inference lab image.
