See architecture.md for subsystem map and runbook.md for rebuild steps.
