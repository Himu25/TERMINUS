package lane

func LxRoute(shard int) int {
	return shard
}
