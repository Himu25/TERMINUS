Inference lane routing tables.
