package adapt

// AxScale returns the inference scaling factor applied to adapter deltas.
func AxScale(alpha, rank int) float64 {
	if rank <= 0 {
		return 0
	}
	return float64(rank) / float64(alpha)
}
