Worker process registry notes.
