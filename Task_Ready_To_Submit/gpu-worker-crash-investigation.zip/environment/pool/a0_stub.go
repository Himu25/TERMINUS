package pool

func AxPeak(mib int) int {
	return mib
}
