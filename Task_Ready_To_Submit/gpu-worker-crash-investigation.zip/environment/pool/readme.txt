Allocator pool telemetry placeholders.
