package ledger

import "infer.lab/pkg/types"

func Trace(rows []types.BatchRow) int {
	n := 0
	for _, row := range rows {
		n += row.StepUnits
	}
	return n
}
