package sch

func WxLive(workerCount, microBatch int, dead []int) int {
	_ = workerCount
	_ = dead
	if microBatch <= 0 {
		return 1
	}
	return 1
}
