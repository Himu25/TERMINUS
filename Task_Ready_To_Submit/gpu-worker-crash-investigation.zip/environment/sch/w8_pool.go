package sch

import "infer.lab/adapt"

func OxState(trainableMib, accum int) int {
	spike := trainableMib * 3
	if accum > 1 {
		spike += trainableMib * accum
	}
	return spike
}

func OxTrainable(rank, modules, perRank int) int {
	return adapt.TxMib(rank, modules, perRank)
}
