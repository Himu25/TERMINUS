package drv

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"strings"

	"infer.lab/adapt"
	"infer.lab/coord"
	"infer.lab/corpus"
	"infer.lab/eval"
	"infer.lab/mem"
	"infer.lab/pkg/types"
	"infer.lab/sch"
)

func LoadCfg(path string) (types.PipelineCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.PipelineCfg{}, err
	}
	cfg := types.PipelineCfg{
		CorpusPath:          "/app/data/val_corpus.json",
		MaxMeanSyncUnits:    4200,
		BalanceWorkersFloor: 4,
		BalanceSpreadFloor:  0.72,
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "model_dim":
			fmt.Sscanf(val, "%d", &cfg.ModelDim)
		case "worker_count":
			fmt.Sscanf(val, "%d", &cfg.LoraRank)
		case "mp_scale":
			fmt.Sscanf(val, "%d", &cfg.LoraAlpha)
		case "base_mib":
			fmt.Sscanf(val, "%d", &cfg.BaseMib)
		case "adapter_mib_per_rank":
			fmt.Sscanf(val, "%d", &cfg.AdapterMibPerRank)
		case "infer_quality_floor":
			fmt.Sscanf(val, "%f", &cfg.ValAccuracyFloor)
		case "max_mean_gpu_mib":
			fmt.Sscanf(val, "%d", &cfg.MaxMeanVramMib)
		case "max_p95_gpu_mib":
			fmt.Sscanf(val, "%d", &cfg.MaxP95VramMib)
		case "min_uptime_score":
			fmt.Sscanf(val, "%f", &cfg.MinThroughputScore)
		case "max_pool_peak_mib":
			fmt.Sscanf(val, "%d", &cfg.MaxPeakOptimizerMib)
		case "long_ctx_gpu_ceiling":
			fmt.Sscanf(val, "%d", &cfg.LongSeqVramCeiling)
		case "mp_min_stable":
			fmt.Sscanf(val, "%f", &cfg.AccumMinStable)
		case "corpus_mix_floor":
			fmt.Sscanf(val, "%f", &cfg.CorpusMixFloor)
		case "sync_min_stable":
			fmt.Sscanf(val, "%f", &cfg.ResumeMinStable)
		case "burst_batch_gpu_ceiling":
			fmt.Sscanf(val, "%d", &cfg.MicroShardVramCeiling)
		case "max_mean_sync_units":
			fmt.Sscanf(val, "%d", &cfg.MaxMeanSyncUnits)
		case "balance_workers_floor":
			fmt.Sscanf(val, "%d", &cfg.BalanceWorkersFloor)
		case "balance_spread_floor":
			fmt.Sscanf(val, "%f", &cfg.BalanceSpreadFloor)
		case "corpus_path":
			cfg.CorpusPath = val
		}
	}
	return cfg, nil
}

func LoadBatches(path string) ([]types.BatchCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.BatchCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var bc types.BatchCase
		if err := json.Unmarshal([]byte(line), &bc); err != nil {
			return nil, err
		}
		out = append(out, bc)
	}
	return out, sc.Err()
}

func Run(cfg types.PipelineCfg, cases []types.BatchCase) (types.BenchReport, error) {
	topics, err := corpus.LoadTopics(cfg.CorpusPath)
	if err != nil {
		return types.BenchReport{}, err
	}
	scale := adapt.AxScale(cfg.LoraAlpha, cfg.LoraRank)
	report := types.BenchReport{
		Status:       "ok",
		ModelDim:     cfg.ModelDim,
		LoraRank:     cfg.LoraRank,
		BatchesTotal: len(cases),
	}
	var sumAcc, sumVram, sumUnits, sumTput, sumStable, sumMix, sumResume, sumSync, sumActive, sumBalance float64
	vramVals := make([]int, 0, len(cases))
	peakOpt := 0
	report.Batches = make([]types.BatchRow, 0, len(cases))
	for _, bc := range cases {
		modules := adapt.TxCount(bc.TargetModules)
		topic := bc.Topic
		if topic == "" {
			topic = "ops"
		}
		mixW := corpus.TopicWeight(topics, topic)
		baseAcc := eval.VxBase(bc.ValLabel, bc.SeqLen)
		normLoss := sch.GxNorm(baseAcc, bc.AccumSteps)
		acc := eval.VxScaled(baseAcc, scale)
		acc = eval.VxCorpusMix(acc, topic, mixW)
		if bc.AccumSteps > 1 && !sch.GxStable(bc.AccumSteps, normLoss, baseAcc) {
			acc *= 0.55
		}
		acc = eval.VxRound(acc)
		stable := sch.GxStable(bc.AccumSteps, normLoss, baseAcc)
		footprint := mem.BxTotal(cfg.BaseMib, cfg.ModelDim, cfg.LoraRank, modules, cfg.AdapterMibPerRank)
		seqPad := mem.SxPad(bc.SeqLen, cfg.ModelDim)
		shardPad := mem.SxShard(bc.MicroBatch, cfg.ModelDim)
		vram := footprint + seqPad + shardPad + bc.MicroBatch*2
		trainable := sch.OxTrainable(cfg.LoraRank, modules, cfg.AdapterMibPerRank)
		optMib := sch.RxCarry(sch.OxState(trainable, bc.AccumSteps), bc.ResumeEpoch)
		if optMib > peakOpt {
			peakOpt = optMib
		}
		resumeStable := sch.RxStable(bc.ResumeEpoch, optMib, trainable)
		active := sch.WxLive(cfg.LoraRank, bc.MicroBatch, bc.DeadWorkers)
		syncUnits := sch.SxUnits(active, bc.AccumSteps)
		perWorker := splitUnits(bc.MicroBatch, active)
		balance := coord.PxSpread(perWorker)
		baseUnits := cfg.ModelDim / 8
		stepUnits := UxStep(baseUnits, bc.SeqLen, bc.MicroBatch, bc.AccumSteps)
		tput := UxThroughput(stepUnits, bc.SeqLen, bc.MicroBatch, bc.AccumSteps)
		if strings.HasPrefix(bc.BatchID, "b_balance_") && active < cfg.BalanceWorkersFloor {
			tput *= 0.35
		}
		if strings.HasPrefix(bc.BatchID, "b_failover_") && len(bc.DeadWorkers) > 0 && active < cfg.LoraRank-len(bc.DeadWorkers) {
			tput *= 0.5
		}
		row := types.BatchRow{
			BatchID:         bc.BatchID,
			SeqLen:          bc.SeqLen,
			ValAccuracy:     acc,
			VramMib:         vram,
			StepUnits:       stepUnits,
			ThroughputScore: eval.VxRound(tput),
			AccumSteps:      bc.AccumSteps,
			OptimizerMib:    optMib,
			AccumStable:     stable,
			CorpusMix:       eval.VxRound(mixW),
			ResumeStable:    resumeStable,
			WorkersActive:   active,
			SyncUnits:       syncUnits,
			BalanceSpread:   balance,
		}
		report.Batches = append(report.Batches, row)
		sumAcc += acc
		sumVram += float64(vram)
		sumUnits += float64(stepUnits)
		sumTput += tput
		sumMix += mixW
		sumSync += float64(syncUnits)
		sumActive += float64(active)
		sumBalance += balance
		if stable {
			sumStable += 1
		}
		if resumeStable {
			sumResume += 1
		}
		vramVals = append(vramVals, vram)
	}
	n := float64(len(cases))
	if n > 0 {
		report.MeanValAccuracy = eval.VxRound(sumAcc / n)
		report.MeanVramMib = eval.VxRound(sumVram / n)
		report.MeanStepUnits = eval.VxRound(sumUnits / n)
		report.MeanThroughputScore = eval.VxRound(sumTput / n)
		report.MeanAccumStable = eval.VxRound(sumStable / n)
		report.MeanCorpusMix = eval.VxRound(sumMix / n)
		report.MeanResumeStable = eval.VxRound(sumResume / n)
		report.MeanSyncUnits = eval.VxRound(sumSync / n)
		report.MeanWorkersActive = eval.VxRound(sumActive / n)
		report.MeanBalanceSpread = eval.VxRound(sumBalance / n)
	}
	report.P95VramMib = p95(vramVals)
	report.PeakOptimizerMib = peakOpt
	if !meetsFloors(cfg, report) {
		report.Status = "fail"
	}
	report.ReportDigest = digestBody(report)
	return report, nil
}

func splitUnits(microBatch, active int) []int {
	if active <= 0 {
		active = 1
	}
	if microBatch <= 0 {
		microBatch = 1
	}
	out := make([]int, active)
	base := microBatch / active
	rem := microBatch % active
	for i := 0; i < active; i++ {
		out[i] = base
		if i < rem {
			out[i]++
		}
	}
	return out
}

func meetsFloors(cfg types.PipelineCfg, report types.BenchReport) bool {
	if report.MeanValAccuracy < cfg.ValAccuracyFloor {
		return false
	}
	if int(report.MeanVramMib) > cfg.MaxMeanVramMib {
		return false
	}
	if report.P95VramMib > cfg.MaxP95VramMib {
		return false
	}
	if report.MeanThroughputScore < cfg.MinThroughputScore {
		return false
	}
	if report.PeakOptimizerMib > cfg.MaxPeakOptimizerMib {
		return false
	}
	if report.MeanAccumStable < cfg.AccumMinStable {
		return false
	}
	if report.MeanCorpusMix < cfg.CorpusMixFloor {
		return false
	}
	if report.MeanResumeStable < cfg.ResumeMinStable {
		return false
	}
	if int(report.MeanSyncUnits) > cfg.MaxMeanSyncUnits {
		return false
	}
	for _, row := range report.Batches {
		if strings.HasPrefix(row.BatchID, "b_burst_ctx_") && row.VramMib > cfg.LongSeqVramCeiling {
			return false
		}
		if strings.HasPrefix(row.BatchID, "b_burst_batch_") && row.VramMib > cfg.MicroShardVramCeiling {
			return false
		}
		if row.AccumSteps > 1 && strings.HasPrefix(row.BatchID, "b_sync_") && !row.ResumeStable {
			return false
		}
		if strings.HasPrefix(row.BatchID, "b_balance_") {
			if row.WorkersActive < cfg.BalanceWorkersFloor {
				return false
			}
			if row.BalanceSpread < cfg.BalanceSpreadFloor {
				return false
			}
		}
		if strings.HasPrefix(row.BatchID, "b_failover_") && row.WorkersActive < 1 {
			return false
		}
	}
	return true
}

func p95(values []int) int {
	if len(values) == 0 {
		return 0
	}
	cp := append([]int(nil), values...)
	sort.Ints(cp)
	idx := int(math.Ceil(0.95*float64(len(cp)))) - 1
	if idx < 0 {
		idx = 0
	}
	if idx >= len(cp) {
		idx = len(cp) - 1
	}
	return cp[idx]
}

type digestPayload struct {
	Status              string           `json:"status"`
	ModelDim            int              `json:"model_dim"`
	LoraRank            int              `json:"worker_count"`
	BatchesTotal        int              `json:"batches_total"`
	MeanValAccuracy     float64          `json:"mean_infer_quality"`
	MeanVramMib         float64          `json:"mean_gpu_mib"`
	MeanStepUnits       float64          `json:"mean_infer_units"`
	MeanThroughputScore float64          `json:"mean_uptime_score"`
	P95VramMib          int              `json:"p95_gpu_mib"`
	PeakOptimizerMib    int              `json:"pool_peak_mib"`
	MeanAccumStable     float64          `json:"mean_mp_stable"`
	MeanCorpusMix       float64          `json:"mean_corpus_mix"`
	MeanResumeStable    float64          `json:"mean_sync_stable"`
	MeanSyncUnits       float64          `json:"mean_sync_units"`
	MeanWorkersActive   float64          `json:"mean_workers_active"`
	MeanBalanceSpread   float64          `json:"mean_balance_spread"`
	ReportDigest        string           `json:"report_digest"`
	Batches             []types.BatchRow `json:"batches"`
}

func digestBody(report types.BenchReport) string {
	payload := digestPayload{
		Status:              report.Status,
		ModelDim:            report.ModelDim,
		LoraRank:            report.LoraRank,
		BatchesTotal:        report.BatchesTotal,
		MeanValAccuracy:     report.MeanValAccuracy,
		MeanVramMib:         report.MeanVramMib,
		MeanStepUnits:       report.MeanStepUnits,
		MeanThroughputScore: report.MeanThroughputScore,
		P95VramMib:          report.P95VramMib,
		PeakOptimizerMib:    report.PeakOptimizerMib,
		MeanAccumStable:     report.MeanAccumStable,
		MeanCorpusMix:       report.MeanCorpusMix,
		MeanResumeStable:    report.MeanResumeStable,
		MeanSyncUnits:       report.MeanSyncUnits,
		MeanWorkersActive:   report.MeanWorkersActive,
		MeanBalanceSpread:   report.MeanBalanceSpread,
		ReportDigest:        "",
		Batches:             report.Batches,
	}
	raw, err := marshalDigestJSON(payload)
	if err != nil {
		return ""
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func marshalDigestJSON(payload digestPayload) ([]byte, error) {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return nil, err
	}
	b := buf.Bytes()
	if n := len(b); n > 0 && b[n-1] == '\n' {
		b = b[:n-1]
	}
	return b, nil
}

func WriteReport(path string, report types.BenchReport) error {
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}
