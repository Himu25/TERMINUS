Document-to-embedding metadata under `/app` drifted from a partial shard cutover. Replay reports show collapsed recall probes, wire integrity gaps, and catalog docs missing from the hot index; pre-watermark segments carry rows the chain no longer admits. Duplicate document ids point at conflicting vectors. Mapping rows lack usable timestamps. Shard routing hints disagree with the writing site. The Go and Rust stack compiles.

Repair the pipeline end-to-end, rebuild `/app/bin/meta_recover`, and run it with `TB_META_FIXTURE=1` so deterministic replay of `/app/data/active` matches the graded report. Go unit tests under `/app` must pass.

Regression substitution packs under `/tests/fixtures` exercise quorum replay, catalog recovery, lane recall, and routing repairs across the matrix. `/app/docs/fixture_index.txt` lists pack ids. All eight packs must replay cleanly: meta_alpha, meta_beta, meta_gamma, meta_delta, meta_epsilon, meta_dup_ids, meta_missing_ts, and meta_bad_shard.

Version token `schema_version` is `"1"`. Report counters: `pack_id`, `vector_dim`.

Chain extent: `material_epoch`, `replay_seq`.

Repair tallies: `mapping_repairs`, `gap_count`.

`shards_active` is the count of distinct shard sites that contributed at least one admitted row. Orphan tally: `orphans_recovered`.

Lane health: `recall_ok`, `skew_band` (`"tight"` or `"wide"`), `sep_clean`.

Post-replay tallies: `duplicates_collapsed`, `ts_inferred`, `shard_routes_fixed`, `digest_hex`. Replay semantics and digest composition live in `/app/docs/metadata_recovery.md`.

Graded deliverable: `/app/output/meta_recover_report.json`.
