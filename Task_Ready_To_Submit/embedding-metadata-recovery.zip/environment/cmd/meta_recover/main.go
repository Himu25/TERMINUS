package main

import (
	"log"
	"os"

	"lab.local/embed_meta_recover/internal/driver"
)

func main() {
	if os.Getenv("TB_META_FIXTURE") != "1" {
		log.Fatal("TB_META_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/meta_recover_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
