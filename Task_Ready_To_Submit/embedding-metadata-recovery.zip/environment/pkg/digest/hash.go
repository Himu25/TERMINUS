package digest

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
)

// ReportHex matches the pipe-separated digest in cmd/meta_recover.
func ReportHex(
	packID string,
	vectorDim, materialEpoch, replaySeq, mappingRepairs, gapCount, shardsActive, orphansRecovered uint32,
	recallOK bool,
	skewBand string,
	sepClean bool,
	duplicatesCollapsed, tsInferred, shardRoutesFixed uint32,
) string {
	ret := "true"
	if !recallOK {
		ret = "false"
	}
	ck := "true"
	if !sepClean {
		ck = "false"
	}
	raw := fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%d|%d|%s|%s|%s|%d|%d|%d",
		packID,
		vectorDim,
		materialEpoch,
		replaySeq,
		mappingRepairs,
		gapCount,
		shardsActive,
		orphansRecovered,
		ret,
		skewBand,
		ck,
		duplicatesCollapsed,
		tsInferred,
		shardRoutesFixed,
	)
	sum := sha256.Sum256([]byte(raw))
	return hex.EncodeToString(sum[:])
}
