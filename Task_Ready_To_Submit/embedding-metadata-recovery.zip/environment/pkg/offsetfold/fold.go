package offsetfold

import "lab.local/embed_meta_recover/indexlane"

// FoldUnitSkew applies optional ingest hold smear to the recorded clock skew baseline.
func FoldUnitSkew(skewMS int64, ingestHoldMS int64) int64 {
	return indexlane.ApplySmear(skewMS, ingestHoldMS)
}
