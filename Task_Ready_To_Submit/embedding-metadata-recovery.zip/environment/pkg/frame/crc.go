package frame

// WireCRC combines payload bytes and sequence into a sixteen-bit integrity tag.
func WireCRC(seq uint32, payload string) uint16 {
	_ = seq
	return uint16(len(payload) & 0xFFFF)
}
