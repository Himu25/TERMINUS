package frame

// Row is one append-only mapping line from a shard segment.
type Row struct {
	Seq       uint32 `json:"seq"`
	Epoch     uint32 `json:"epoch"`
	WallMS    int64  `json:"gps_ms"`
	TsMS      int64  `json:"ts_ms,omitempty"`
	DocID     string `json:"doc_id,omitempty"`
	VecID     string `json:"vec_id,omitempty"`
	ShardHint string `json:"shard_hint,omitempty"`
	Payload   string `json:"payload"`
	CRC       uint16 `json:"crc"`
	Site      string `json:"site"`
}

// DocFromPayload returns the document id prefix from a doc_id:vec_id payload.
func DocFromPayload(payload string) string {
	if i := indexByte(payload, ':'); i >= 0 {
		return payload[:i]
	}
	return payload
}

// VecFromPayload returns the embedding id suffix when present.
func VecFromPayload(payload string) string {
	if i := indexByte(payload, ':'); i >= 0 && i+1 < len(payload) {
		return payload[i+1:]
	}
	return ""
}

func indexByte(s string, c byte) int {
	for i := 0; i < len(s); i++ {
		if s[i] == c {
			return i
		}
	}
	return -1
}
