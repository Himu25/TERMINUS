package meta

import "lab.local/embed_meta_recover/pkg/frame"

// EffectiveWallMS chooses a write-time anchor for ordering and skew adjustment.
// When gps_ms is zero, ts_ms is used; when both are zero, infer from sequence stride.
func EffectiveWallMS(row frame.Row, seqStride int64) int64 {
	if row.WallMS != 0 {
		return row.WallMS
	}
	if row.TsMS != 0 {
		return row.TsMS
	}
	if seqStride <= 0 {
		seqStride = 100
	}
	return int64(row.Seq) * seqStride
}

// NeedsTsInfer reports rows that lacked both gps and explicit mapping timestamps.
func NeedsTsInfer(row frame.Row) bool {
	return row.WallMS == 0 && row.TsMS == 0
}
