package markfold

// FoldSeal folds member marks into one replay watermark.
func FoldSeal(marks []int64) int64 {
	if len(marks) == 0 {
		return 0
	}
	best := marks[0]
	for _, m := range marks[1:] {
		if m > best {
			best = m
		}
	}
	return best
}
