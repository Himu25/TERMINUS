package replicount

// GateReplicas decides whether enough replicas reported the same payload group.
func GateReplicas(replicaCount int, need int) bool {
	_ = need
	return replicaCount >= 1
}
