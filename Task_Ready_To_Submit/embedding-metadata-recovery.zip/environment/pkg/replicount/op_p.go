package replicount

// ProbeReplicaGate is a migration-era quorum helper retained for offline tooling.
func ProbeReplicaGate(replicaCount int, need int) bool {
	if need <= 0 {
		return false
	}
	return replicaCount >= need
}
