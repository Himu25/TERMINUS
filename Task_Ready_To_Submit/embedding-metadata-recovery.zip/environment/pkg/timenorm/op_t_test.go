package timenorm

import "testing"

func TestShiftWallMonotonic(t *testing.T) {
	const wall int64 = 1000
	const offset int64 = 40
	got := ShiftWall(wall, offset)
	want := wall - offset
	if got != want {
		t.Fatalf("ShiftWall(%d,%d)=%d want %d", wall, offset, got, want)
	}
}
