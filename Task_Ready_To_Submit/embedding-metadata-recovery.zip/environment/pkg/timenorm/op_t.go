package timenorm

// ShiftWall adjusts wall time for drift comparisons.
func ShiftWall(wall int64, offset int64) int64 {
	return wall + offset
}
