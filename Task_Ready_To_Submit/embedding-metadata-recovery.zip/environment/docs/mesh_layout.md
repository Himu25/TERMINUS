# Metadata mesh layout

Five shards (`n1`–`n5`) append document-to-embedding mapping rows under `/app/data/active/shards/*/map_001.jsonl`.
Each shard carries `clock_skew_ms`, optional `ingest_hold_ms`, and a `stale_mark` watermark in `meta.json`.
The active pack lists `catalog` document ids that may be recovered from pre-watermark segments and `probe_docs` checked against the hot-lane path.
Rows may include `doc_id`, `vec_id`, `ts_ms`, and `shard_hint` fields alongside the canonical `payload` (`doc_id:vec_id`).
