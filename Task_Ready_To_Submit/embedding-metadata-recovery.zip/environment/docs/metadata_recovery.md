# Metadata recovery replay contract

## Report envelope

`schema_version` is `"1"`. The root object contains only the fields listed in the driver prompt. Booleans render as JSON booleans, not strings.

`pack_id` and `vector_dim` come from the active `meta_pack.json`. `skew_band` is `"tight"` when the spread between max and min shard replay offsets is at most `skew_tight_ms` from the pack, otherwise `"wide"`.

`shards_active` counts distinct shard sites that contributed at least one admitted row.

`digest_hex` is lowercase hex SHA-256 of
`pack_id|vector_dim|material_epoch|replay_seq|mapping_repairs|gap_count|shards_active|orphans_recovered|recall_ok|skew_band|sep_clean|duplicates_collapsed|ts_inferred|shard_routes_fixed`
with booleans rendered as `true` or `false` strings.

## Watermark and admission

Derive one watermark from the five shard `stale_mark` values in each shard `meta.json` — use the lowest mark across the pack (`markfold.FoldSeal`).

Only rows with sequence above that watermark participate in quorum admission. At each such sequence, rows sharing the same version epoch and mapping payload form an update group.

A group is admitted only when it has quorum support within itself: at least `q_size` distinct shards and at least `q_size` CRC-valid rows in that same group, where `q_size` comes from the active pack (`replicount.GateReplicas`).

CRC validity means the stored sixteen-bit tag equals the lower sixteen bits of the payload byte sum XOR sequence (`crc.tagOk` / `frame.WireCRC`).

Sequences with no admitted group increment `gap_count`. When several groups qualify at one sequence, the winning group is the one whose earliest drift-adjusted effective write time wins.

## Time and skew

Effective wall time uses `gps_ms` when nonzero, else `ts_ms`, else `seq` times `ts_stride_ms` from `meta_pack.json`.

Each shard replay offset is `clock_skew_ms` minus `ingest_hold_ms` from that shard `meta.json` (when `ingest_hold_ms` is zero, the offset is `clock_skew_ms` alone). Shard skew baselines that pass through the indexlane smear fold use that same subtraction (`indexlane.ApplySmear`).

Drift-adjusted time subtracts this offset from effective wall time via `timenorm.ShiftWall`; do not add the offset.

`mapping_repairs` tallies CRC-invalid replicas in the admitted group only. After `sep_epoch`, `sep_clean` is false when an admitted epoch lacks quorum-valid support from distinct shards.

## Chain extent and counters

`replay_seq` is the highest sequence `s` reached by walking upward from 1 while each step satisfies `s` is at or below the watermark or has an admitted group; stop at the first sequence above the watermark with no admission.

`material_epoch` scans every row with sequence at most `replay_seq`: for admitted sequences, consider CRC-valid rows whose epoch matches the group's winning epoch; for sequences at or below the watermark, consider all rows regardless of admission; track the maximum epoch seen.

After replay, collapse duplicate document ids in winning mappings to the latest sequence (`duplicates_collapsed` counts removed entries). `ts_inferred` counts admitted rows with zero `gps_ms` and `ts_ms`. `shard_routes_fixed` counts admitted rows whose `shard_hint` differs from the writing site.

`orphans_recovered` counts `catalog` docs absent from collapsed winners but present in valid pre-watermark rows at any sequence through the watermark inclusive.

## Hot-lane recall

`recall_ok` exercises the Rust index-lane hot path against replay for every doc in the pack `probe_docs` list. For each probe, read the latest winning mapping cell, derive the probe key from its vec suffix after `:` (or the whole cell key if no suffix exists), and require the mapping wire integrity tag at sequence zero to equal the Rust lane digest for that key.

The wire tag is the lower sixteen bits of the payload byte sum XOR sequence; the lane digest is the wrapping thirty-two-bit sum of the key UTF-8 bytes.
