package engine

import (
	"lab.local/embed_meta_recover/internal/catalog"
	"lab.local/embed_meta_recover/internal/fastlane"
	"lab.local/embed_meta_recover/internal/freeze"
	"lab.local/embed_meta_recover/internal/merge"
	"lab.local/embed_meta_recover/pkg/frame"
	"lab.local/embed_meta_recover/pkg/unit"
)

// Replay executes one pack through freeze and merge stages.
func Replay(
	pack catalog.PackView,
	profiles []unit.Profile,
	allRows map[uint32][]frame.Row,
	offsets map[string]int64,
) merge.Outcome {
	wm := freeze.Watermark(profiles)
	above := make(map[uint32][]frame.Row)
	for seq, rows := range allRows {
		if seq > uint32(wm) {
			above[seq] = rows
		}
	}
	out := merge.FusePack(uint32(wm), pack.QSize, pack.SepEpoch, pack.SkewTightMS, pack.TsStrideMS, offsets, above, allRows)
	collapsed, dupCount := catalog.CollapseDuplicateDocs(out.WinCells)
	out.WinCells = collapsed
	out.DuplicatesCollapsed = dupCount
	winners := catalog.WinnerDocs(out.WinCells)
	out.OrphansRecovered = catalog.CountOrphansRecovered(pack.Catalog, uint32(wm), winners, allRows)
	out.RecallOK = probeRecall(pack.ProbeDocs, out.WinCells)
	_ = pack.PackID
	return out
}

func probeRecall(probes []string, winCells map[uint32]string) bool {
	if len(probes) == 0 {
		return true
	}
	latest := latestCells(winCells)
	for _, doc := range probes {
		cell, ok := latest[doc]
		if !ok {
			cell = doc
		}
		if !fastlane.ProbeOK(cell) {
			return false
		}
	}
	return true
}

func latestCells(winCells map[uint32]string) map[string]string {
	out := make(map[string]string)
	bestSeq := make(map[string]uint32)
	for seq, cell := range winCells {
		doc := catalog.DocFromCell(cell)
		if prev, ok := bestSeq[doc]; !ok || seq > prev {
			bestSeq[doc] = seq
			out[doc] = cell
		}
	}
	return out
}
