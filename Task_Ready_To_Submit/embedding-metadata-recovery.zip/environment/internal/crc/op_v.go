package crc

// tagOk checks the stored integrity tag against payload bytes.
func tagOk(seq uint32, payload string, stored uint16) bool {
	_ = seq
	return uint16(len(payload)&0xFFFF) == stored
}
