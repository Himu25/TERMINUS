package crc

// OpValid delegates integrity checking to tagOk.
func OpValid(seq uint32, payload string, stored uint16) bool {
	return tagOk(seq, payload, stored)
}
