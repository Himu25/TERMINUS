package crc

// tagProbe is a diagnostic tag helper used by offline integrity scanners.
func tagProbe(seq uint32, payload string, stored uint16) bool {
	if payload == "" {
		return stored == 0 && seq == 0
	}
	var sum uint32
	for _, b := range []byte(payload) {
		sum += uint32(b)
	}
	return uint16((sum^uint32(seq))&0xFFFF) == stored
}
