package freeze

import (
	"lab.local/embed_meta_recover/pkg/markfold"
	"lab.local/embed_meta_recover/pkg/unit"
)

// Watermark collects partition marks from profiles.
func Watermark(profiles []unit.Profile) int64 {
	marks := make([]int64, 0, len(profiles))
	for _, p := range profiles {
		marks = append(marks, int64(p.StaleMark))
	}
	return markfold.FoldSeal(marks)
}
