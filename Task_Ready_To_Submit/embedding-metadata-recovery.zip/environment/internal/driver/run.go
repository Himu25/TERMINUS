package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"

	"lab.local/embed_meta_recover/internal/catalog"
	"lab.local/embed_meta_recover/internal/config"
	"lab.local/embed_meta_recover/internal/engine"
)

// Report is the outward JSON envelope.
type Report struct {
	SchemaVersion       string `json:"schema_version"`
	PackID              string `json:"pack_id"`
	VectorDim           uint32 `json:"vector_dim"`
	MaterialEpoch       uint32 `json:"material_epoch"`
	ReplaySeq           uint32 `json:"replay_seq"`
	MappingRepairs      uint32 `json:"mapping_repairs"`
	GapCount            uint32 `json:"gap_count"`
	ShardsActive        uint32 `json:"shards_active"`
	OrphansRecovered    uint32 `json:"orphans_recovered"`
	RecallOK            bool   `json:"recall_ok"`
	SkewBand            string `json:"skew_band"`
	SepClean            bool   `json:"sep_clean"`
	DuplicatesCollapsed uint32 `json:"duplicates_collapsed"`
	TsInferred          uint32 `json:"ts_inferred"`
	ShardRoutesFixed    uint32 `json:"shard_routes_fixed"`
	DigestHex           string `json:"digest_hex"`
}

// RunActive loads the active pack and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	pack, profiles, rows, offsets, err := config.LoadPack(dir)
	if err != nil {
		return Report{}, err
	}
	view := catalog.PackView{
		PackID:       pack.PackID,
		QSize:        pack.QSize,
		SepEpoch:     pack.SepEpoch,
		SkewTightMS:  pack.SkewTightMS,
		TsStrideMS:   pack.TsStrideMS,
		VectorDim:    pack.VectorDim,
		Catalog:      pack.Catalog,
		ProbeDocs:    pack.ProbeDocs,
	}
	out := engine.Replay(view, profiles, rows, offsets)
	ck := "true"
	if !out.SepClean {
		ck = "false"
	}
	ret := "true"
	if !out.RecallOK {
		ret = "false"
	}
	digest := sha256.Sum256([]byte(fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%d|%d|%s|%s|%s|%d|%d|%d",
		pack.PackID,
		pack.VectorDim,
		out.MaterialEpoch,
		out.ReplaySeq,
		out.MappingRepairs,
		out.GapCount,
		out.ShardsActive,
		out.OrphansRecovered,
		ret,
		out.SkewBand,
		ck,
		out.DuplicatesCollapsed,
		out.TsInferred,
		out.ShardRoutesFixed,
	)))
	return Report{
		SchemaVersion:       "1",
		PackID:              pack.PackID,
		VectorDim:           pack.VectorDim,
		MaterialEpoch:       out.MaterialEpoch,
		ReplaySeq:           out.ReplaySeq,
		MappingRepairs:      out.MappingRepairs,
		GapCount:            out.GapCount,
		ShardsActive:        out.ShardsActive,
		OrphansRecovered:    out.OrphansRecovered,
		RecallOK:            out.RecallOK,
		SkewBand:            out.SkewBand,
		SepClean:            out.SepClean,
		DuplicatesCollapsed: out.DuplicatesCollapsed,
		TsInferred:          out.TsInferred,
		ShardRoutesFixed:    out.ShardRoutesFixed,
		DigestHex:           hex.EncodeToString(digest[:]),
	}, nil
}
