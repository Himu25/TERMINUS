package skew

import (
	"lab.local/embed_meta_recover/pkg/frame"
	"lab.local/embed_meta_recover/pkg/meta"
	"lab.local/embed_meta_recover/pkg/timenorm"
)

// PickEarlier returns the row with smaller drift-adjusted write time.
func PickEarlier(a, b frame.Row, offA, offB int64, stride int64) frame.Row {
	if AdjustWall(a, offA, stride) <= AdjustWall(b, offB, stride) {
		return a
	}
	return b
}

// AdjustWall returns drift-adjusted effective write time for one row.
func AdjustWall(row frame.Row, offset int64, stride int64) int64 {
	wall := meta.EffectiveWallMS(row, stride)
	return timenorm.ShiftWall(wall, offset)
}
