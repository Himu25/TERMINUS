package catalog

import (
	"strings"

	"lab.local/embed_meta_recover/internal/crc"
	"lab.local/embed_meta_recover/pkg/frame"
)

// DocFromCell splits a document id from a mapping payload.
func DocFromCell(cellKey string) string {
	return frame.DocFromPayload(cellKey)
}

// CountOrphansRecovered tallies catalog docs absent from winners but restorable below watermark.
func CountOrphansRecovered(
	catalog []string,
	watermark uint32,
	winners map[string]struct{},
	allRows map[uint32][]frame.Row,
) uint32 {
	if len(catalog) == 0 {
		return 0
	}
	var recovered uint32
	for _, doc := range catalog {
		if _, ok := winners[doc]; ok {
			continue
		}
		found := false
		for seq := uint32(1); seq < watermark; seq++ {
			for _, row := range allRows[seq] {
				if DocFromCell(row.Payload) != doc {
					continue
				}
				if !crc.OpValid(row.Seq, row.Payload, row.CRC) {
					continue
				}
				found = true
				break
			}
			if found {
				break
			}
		}
		if found {
			recovered++
		}
	}
	return recovered
}

// WinnerDocs collects document ids present in accepted winning payloads.
func WinnerDocs(accepted map[uint32]string) map[string]struct{} {
	out := make(map[string]struct{}, len(accepted))
	for _, cell := range accepted {
		out[DocFromCell(cell)] = struct{}{}
	}
	return out
}

// CollapseDuplicateDocs keeps the highest-sequence mapping per document id.
func CollapseDuplicateDocs(winCells map[uint32]string) (map[uint32]string, uint32) {
	bestSeq := make(map[string]uint32)
	bestCell := make(map[string]string)
	for seq, cell := range winCells {
		doc := DocFromCell(cell)
		if prev, ok := bestSeq[doc]; !ok || seq > prev {
			bestSeq[doc] = seq
			bestCell[doc] = cell
		}
	}
	out := make(map[uint32]string, len(bestCell))
	var collapsed uint32
	for doc, seq := range bestSeq {
		out[seq] = bestCell[doc]
	}
	if len(out) < len(winCells) {
		collapsed = uint32(len(winCells) - len(out))
	}
	return out, collapsed
}

// EntityFromCell is kept for legacy call sites during migration.
func EntityFromCell(cellKey string) string {
	if i := strings.IndexByte(cellKey, ':'); i >= 0 {
		return cellKey[:i]
	}
	return cellKey
}
