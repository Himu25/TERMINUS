package catalog

// PackView is the replay-facing subset of a loaded metadata pack.
type PackView struct {
	PackID      string
	QSize       int
	SepEpoch    uint32
	SkewTightMS int64
	TsStrideMS  int64
	VectorDim   uint32
	Catalog     []string
	ProbeDocs   []string
}
