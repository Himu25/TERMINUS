package config

import (
	"encoding/json"
	"os"
	"path/filepath"

	"lab.local/embed_meta_recover/pkg/frame"
	"lab.local/embed_meta_recover/pkg/offsetfold"
	"lab.local/embed_meta_recover/pkg/unit"
)

// Pack describes one embedding-metadata recovery scenario root.
type Pack struct {
	PackID       string   `json:"pack_id"`
	QSize        int      `json:"q_size"`
	SepEpoch     uint32   `json:"sep_epoch"`
	SkewTightMS  int64    `json:"skew_tight_ms"`
	TsStrideMS   int64    `json:"ts_stride_ms"`
	VectorDim    uint32   `json:"vector_dim"`
	Catalog      []string `json:"catalog"`
	ProbeDocs    []string `json:"probe_docs"`
	Shards       []string `json:"shards"`
}

// ActivePaths resolves the bundled active pack directory.
func ActivePaths(root string) (string, error) {
	return filepath.Join(root, "data", "active"), nil
}

// LoadPack reads meta_pack.json and shard mapping trees.
func LoadPack(dir string) (Pack, []unit.Profile, map[uint32][]frame.Row, map[string]int64, error) {
	raw, err := os.ReadFile(filepath.Join(dir, "meta_pack.json"))
	if err != nil {
		return Pack{}, nil, nil, nil, err
	}
	var doc Pack
	if err := json.Unmarshal(raw, &doc); err != nil {
		return Pack{}, nil, nil, nil, err
	}
	if doc.TsStrideMS <= 0 {
		doc.TsStrideMS = 100
	}
	profiles := make([]unit.Profile, 0, len(doc.Shards))
	offsets := make(map[string]int64, len(doc.Shards))
	rows := make(map[uint32][]frame.Row)
	for _, mid := range doc.Shards {
		metaPath := filepath.Join(dir, "shards", mid, "meta.json")
		metaRaw, err := os.ReadFile(metaPath)
		if err != nil {
			return Pack{}, nil, nil, nil, err
		}
		var prof unit.Profile
		if err := json.Unmarshal(metaRaw, &prof); err != nil {
			return Pack{}, nil, nil, nil, err
		}
		profiles = append(profiles, prof)
		offsets[mid] = offsetfold.FoldUnitSkew(prof.ClockSkewMS, prof.IngestHoldMS)
		seg := filepath.Join(dir, "shards", mid, "map_001.jsonl")
		data, err := os.ReadFile(seg)
		if err != nil {
			if os.IsNotExist(err) {
				continue
			}
			return Pack{}, nil, nil, nil, err
		}
		for _, line := range splitLines(string(data)) {
			if line == "" {
				continue
			}
			var row frame.Row
			if err := json.Unmarshal([]byte(line), &row); err != nil {
				continue
			}
			row.Site = mid
			if row.Payload == "" && row.DocID != "" {
				if row.VecID != "" {
					row.Payload = row.DocID + ":" + row.VecID
				} else {
					row.Payload = row.DocID
				}
			}
			rows[row.Seq] = append(rows[row.Seq], row)
		}
	}
	return doc, profiles, rows, offsets, nil
}

func splitLines(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			out = append(out, s[start:i])
			start = i + 1
		}
	}
	if start < len(s) {
		out = append(out, s[start:])
	}
	return out
}
