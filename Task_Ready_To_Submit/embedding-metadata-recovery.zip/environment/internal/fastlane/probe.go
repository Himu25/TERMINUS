package fastlane

import (
	"lab.local/embed_meta_recover/indexlane"
	"lab.local/embed_meta_recover/pkg/frame"
)

// ProbeOK checks the low-latency lane signature against replay-derived vec material.
func ProbeOK(cellKey string) bool {
	probeKey := frame.VecFromPayload(cellKey)
	if probeKey == "" {
		probeKey = cellKey
	}
	want := uint32(frame.WireCRC(0, probeKey))
	got := uint32(indexlane.CellSig(probeKey))
	return want == got
}
