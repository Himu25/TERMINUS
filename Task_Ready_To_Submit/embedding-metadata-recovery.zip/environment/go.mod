module lab.local/embed_meta_recover

go 1.22
