package main

import (
	"fmt"
	"os"
	"strconv"

	"lab.local/embed_meta_recover/pkg/digest"
)

func main() {
	if len(os.Args) < 15 {
		fmt.Fprintln(os.Stderr, "usage: digest_cli pack vector_dim material replay repairs gap shards orphans recall skew sep dup ts shard")
		os.Exit(2)
	}
	vectorDim, _ := strconv.ParseUint(os.Args[2], 10, 32)
	material, _ := strconv.ParseUint(os.Args[3], 10, 32)
	replay, _ := strconv.ParseUint(os.Args[4], 10, 32)
	repairs, _ := strconv.ParseUint(os.Args[5], 10, 32)
	gap, _ := strconv.ParseUint(os.Args[6], 10, 32)
	shards, _ := strconv.ParseUint(os.Args[7], 10, 32)
	orphans, _ := strconv.ParseUint(os.Args[8], 10, 32)
	recall := os.Args[9] == "true"
	clean := os.Args[11] == "true"
	dup, _ := strconv.ParseUint(os.Args[12], 10, 32)
	ts, _ := strconv.ParseUint(os.Args[13], 10, 32)
	route, _ := strconv.ParseUint(os.Args[14], 10, 32)
	fmt.Print(digest.ReportHex(
		os.Args[1],
		uint32(vectorDim),
		uint32(material),
		uint32(replay),
		uint32(repairs),
		uint32(gap),
		uint32(shards),
		uint32(orphans),
		recall,
		os.Args[10],
		clean,
		uint32(dup),
		uint32(ts),
		uint32(route),
	))
}
