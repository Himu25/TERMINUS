Operator tools live outside the sync driver; use /app/bin/meta_recover for pack replay.
Verifier helpers include /tmp/meta_recover_verify_bin and /app/tools/digest_cli for digest recomputation.
