#pragma once

long long rl_smear_base(long long base_ms, long long hold_ms);
unsigned int rl_lane_digest(const char *cell_key);
