"""Verifier for embedding metadata recovery report."""

import json
import os
import shutil
import subprocess
from collections import defaultdict
from pathlib import Path

import pytest

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = Path("/tests") / "fixtures"
OUT = APP / "output" / "meta_recover_report.json"
GO_BIN = "/usr/local/go/bin/go"
VERIFY_BIN = "/tmp/meta_recover_verify_bin"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)
    subprocess.run(["cp", "/app/bin/meta_recover", VERIFY_BIN], check=True)


def _doc(cell_key: str) -> str:
    if ":" in cell_key:
        return cell_key.split(":", 1)[0]
    return cell_key


def _wire_crc(seq: int, payload: str) -> int:
    total = sum(payload.encode()) & 0xFFFFFFFF
    return (total ^ seq) & 0xFFFF


def _effective_wall(entry: dict, stride: int) -> int:
    gps = int(entry.get("gps_ms", 0))
    if gps != 0:
        return gps
    ts = int(entry.get("ts_ms", 0))
    if ts != 0:
        return ts
    return int(entry["seq"]) * stride


def _needs_ts_infer(entry: dict) -> bool:
    return int(entry.get("gps_ms", 0)) == 0 and int(entry.get("ts_ms", 0)) == 0


def _adjust_wall(entry: dict, offsets: dict[str, int], stride: int) -> int:
    return _effective_wall(entry, stride) - offsets[entry["site"]]


def _collapse_duplicates(win_cells: dict[int, str]) -> tuple[dict[int, str], int]:
    best_seq: dict[str, int] = {}
    best_cell: dict[str, str] = {}
    for seq, cell in win_cells.items():
        doc = _doc(cell)
        if doc not in best_seq or seq > best_seq[doc]:
            best_seq[doc] = seq
            best_cell[doc] = cell
    out = {seq: best_cell[doc] for doc, seq in best_seq.items()}
    collapsed = len(win_cells) - len(out)
    return out, collapsed


def _digest_hex(
    pack_id: str,
    vector_dim: int,
    material_epoch: int,
    replay_seq: int,
    repair: int,
    loss: int,
    shards_active: int,
    orphans: int,
    recall_ok: bool,
    drift: str,
    sep_clean: bool,
    dup: int,
    ts_inf: int,
    shard_fix: int,
) -> str:
    ck = "true" if sep_clean else "false"
    ret = "true" if recall_ok else "false"
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            pack_id,
            str(vector_dim),
            str(material_epoch),
            str(replay_seq),
            str(repair),
            str(loss),
            str(shards_active),
            str(orphans),
            ret,
            drift,
            ck,
            str(dup),
            str(ts_inf),
            str(shard_fix),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _orphans_recovered(catalog: list[str], watermark: int, win_cells: dict[int, str], all_rows: dict[int, list]) -> int:
    winners = {_doc(cell) for cell in win_cells.values()}
    recovered = 0
    for doc in catalog:
        if doc in winners:
            continue
        found = False
        for seq in range(1, watermark + 1):
            for entry in all_rows.get(seq, []):
                if _doc(entry["payload"]) != doc:
                    continue
                if _wire_crc(entry["seq"], entry["payload"]) == entry["crc"]:
                    found = True
                    break
            if found:
                break
        if found:
            recovered += 1
    return recovered


def _vec_from_payload(payload: str) -> str:
    if ":" in payload:
        return payload.split(":", 1)[1]
    return ""


def _cell_sig(probe_key: str) -> int:
    total = 0
    for b in probe_key.encode():
        total = (total + b) & 0xFFFFFFFF
    return total


def _recall_ok(probes: list[str], win_cells: dict[int, str]) -> bool:
    if not probes:
        return True
    latest: dict[str, str] = {}
    best_seq: dict[str, int] = {}
    for seq, cell in win_cells.items():
        doc = _doc(cell)
        if doc not in best_seq or seq > best_seq[doc]:
            best_seq[doc] = seq
            latest[doc] = cell
    for doc in probes:
        cell = latest.get(doc, doc)
        probe_key = _vec_from_payload(cell) or cell
        want = _wire_crc(0, probe_key)
        got = _cell_sig(probe_key)
        if want != got:
            return False
    return True


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = FIXTURES / pack_name
    pack = json.loads((pack_dir / "meta_pack.json").read_text())
    q = pack["q_size"]
    sep_epoch = pack["sep_epoch"]
    drift_tight = pack["skew_tight_ms"]
    stride = int(pack.get("ts_stride_ms", 100))
    offsets: dict[str, int] = {}
    freezes: list[int] = []
    rows: list[dict] = []
    for mid in pack["shards"]:
        meta = json.loads((pack_dir / "shards" / mid / "meta.json").read_text())
        hold = int(meta.get("ingest_hold_ms", 0))
        offsets[mid] = int(meta["clock_skew_ms"]) - hold
        freezes.append(meta["stale_mark"])
        seg = pack_dir / "shards" / mid / "map_001.jsonl"
        if not seg.exists():
            continue
        for line in seg.read_text().splitlines():
            if not line.strip():
                continue
            entry = json.loads(line)
            entry["site"] = mid
            if not entry.get("payload") and entry.get("doc_id"):
                vec = entry.get("vec_id", "")
                entry["payload"] = f"{entry['doc_id']}:{vec}" if vec else entry["doc_id"]
            rows.append(entry)
    wm = min(freezes) if freezes else 0
    by_seq: dict[int, list] = defaultdict(list)
    all_rows: dict[int, list] = defaultdict(list)
    for entry in rows:
        all_rows[entry["seq"]].append(entry)
        if entry["seq"] > wm:
            by_seq[entry["seq"]].append(entry)
    accepted: dict[int, int] = {}
    win_cells: dict[int, str] = {}
    repair = 0
    loss = 0
    live: set[str] = set()
    sep_clean = True
    ts_inferred = 0
    shard_fixed = 0
    for seq in sorted(by_seq):
        buckets: dict[tuple, list] = defaultdict(list)
        for entry in by_seq[seq]:
            buckets[(entry["epoch"], entry["payload"])].append(entry)
        picked = None
        best_adj = None
        for key, items in buckets.items():
            if len({it["site"] for it in items}) < q:
                continue
            valid = [it for it in items if _wire_crc(it["seq"], it["payload"]) == it["crc"]]
            if len(valid) < q:
                continue
            adj = min(_adjust_wall(it, offsets, stride) for it in valid)
            if picked is None or adj < best_adj:
                picked, best_adj = key, adj
        if picked is None:
            loss += 1
            continue
        items = buckets[picked]
        repair += sum(1 for it in items if _wire_crc(it["seq"], it["payload"]) != it["crc"])
        epoch = picked[0]
        valid = [it for it in items if _wire_crc(it["seq"], it["payload"]) == it["crc"]]
        if epoch > sep_epoch and len({it["site"] for it in valid}) < q:
            sep_clean = False
        for it in valid:
            live.add(it["site"])
            if _needs_ts_infer(it):
                ts_inferred += 1
            hint = it.get("shard_hint", "")
            if hint and hint != it["site"]:
                shard_fixed += 1
        accepted[seq] = epoch
        win_cells[seq] = picked[1]
    replay_seq = 0
    s = 1
    while True:
        if s <= wm or s in accepted:
            replay_seq = s
            s += 1
        else:
            break
    material_epoch = 0
    for seq, seq_rows in all_rows.items():
        if seq > replay_seq:
            continue
        for entry in seq_rows:
            if seq in accepted and entry["epoch"] == accepted[seq]:
                if _wire_crc(entry["seq"], entry["payload"]) == entry["crc"] and entry["epoch"] > material_epoch:
                    material_epoch = entry["epoch"]
            elif seq <= wm and entry["epoch"] > material_epoch:
                material_epoch = entry["epoch"]
    win_cells, dup_collapsed = _collapse_duplicates(win_cells)
    spread = max(offsets.values()) - min(offsets.values())
    drift = "tight" if spread <= drift_tight else "wide"
    orphans = _orphans_recovered(pack.get("catalog", []), wm, win_cells, all_rows)
    recall_ok = _recall_ok(pack.get("probe_docs", []), win_cells)
    digest = _digest_hex(
        pack["pack_id"],
        pack["vector_dim"],
        material_epoch,
        replay_seq,
        repair,
        loss,
        len(live),
        orphans,
        recall_ok,
        drift,
        sep_clean,
        dup_collapsed,
        ts_inferred,
        shard_fixed,
    )
    return {
        "schema_version": "1",
        "pack_id": pack["pack_id"],
        "vector_dim": pack["vector_dim"],
        "material_epoch": material_epoch,
        "replay_seq": replay_seq,
        "mapping_repairs": repair,
        "gap_count": loss,
        "shards_active": len(live),
        "orphans_recovered": orphans,
        "recall_ok": recall_ok,
        "skew_band": drift,
        "sep_clean": sep_clean,
        "duplicates_collapsed": dup_collapsed,
        "ts_inferred": ts_inferred,
        "shard_routes_fixed": shard_fixed,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_META_FIXTURE": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_alpha_report_matches_quorum_replay() -> None:
    """Alpha pack should reach tight skew band with catalog recovery and recall probes."""
    _swap("meta_alpha")
    exp = _expected_from_fixture("meta_alpha")
    got = _run_tool()
    assert got == exp


def test_beta_report_matches_quorum_replay() -> None:
    """Beta pack applies ingest hold smear when folding shard skew for replay."""
    _swap("meta_beta")
    exp = _expected_from_fixture("meta_beta")
    got = _run_tool()
    assert got == exp


def test_gamma_loss_after_lone_epoch() -> None:
    """Gamma stops the chain when only one shard carries a high material row."""
    _swap("meta_gamma")
    exp = _expected_from_fixture("meta_gamma")
    got = _run_tool()
    assert got == exp


def test_delta_high_gap_count() -> None:
    """Delta orphan high sequence should not extend the global chain."""
    _swap("meta_delta")
    exp = _expected_from_fixture("meta_delta")
    got = _run_tool()
    assert got == exp


def test_epsilon_mapping_repairs_nonzero() -> None:
    """Epsilon should count one integrity repair on the winning update group."""
    _swap("meta_epsilon")
    exp = _expected_from_fixture("meta_epsilon")
    got = _run_tool()
    assert got == exp


def test_alpha_orphans_recovered_catalog() -> None:
    """Alpha catalog doc ghost_doc must restore from pre-watermark valid rows."""
    _swap("meta_alpha")
    exp = _expected_from_fixture("meta_alpha")
    got = _run_tool()
    assert got["orphans_recovered"] == exp["orphans_recovered"]
    assert exp["orphans_recovered"] > 0


def test_beta_recall_lane_ok() -> None:
    """Beta probe_docs must report recall_ok true after hot-lane repair."""
    _swap("meta_beta")
    exp = _expected_from_fixture("meta_beta")
    got = _run_tool()
    assert got["recall_ok"] == exp["recall_ok"]


def test_dup_ids_fixture_collapses_duplicates() -> None:
    """meta_dup_ids pack must collapse duplicate document ids to the latest sequence."""
    _swap("meta_dup_ids")
    exp = _expected_from_fixture("meta_dup_ids")
    got = _run_tool()
    assert got == exp
    assert exp["duplicates_collapsed"] > 0


def test_missing_ts_fixture_infers_timestamps() -> None:
    """meta_missing_ts pack must infer write times from sequence stride when gps and ts are zero."""
    _swap("meta_missing_ts")
    exp = _expected_from_fixture("meta_missing_ts")
    got = _run_tool()
    assert got == exp
    assert exp["ts_inferred"] > 0


def test_bad_shard_fixture_counts_route_repairs() -> None:
    """meta_bad_shard pack must count route repairs when shard_hint disagrees with the writing site."""
    _swap("meta_bad_shard")
    exp = _expected_from_fixture("meta_bad_shard")
    got = _run_tool()
    assert got == exp
    assert exp["shard_routes_fixed"] > 0


def test_go_subsystem_tests_pass() -> None:
    """Go unit tests under /app must pass after the repair."""
    subprocess.run(
        [GO_BIN, "test", "./..."],
        cwd="/app",
        env={
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        },
        check=True,
    )
