#!/usr/bin/env bash
set -euo pipefail

# Terminal-Bench Canary: embedding-metadata-recovery (solve.sh)

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/pkg/replicount/op_q.go <<'EOF'
package replicount

func quorumMet(count int, need int) bool {
	if need <= 0 {
		return false
	}
	if count < 0 {
		return false
	}
	return count >= need
}

// GateReplicas decides whether enough replicas reported the same payload group.
func GateReplicas(replicaCount int, need int) bool {
	return quorumMet(replicaCount, need)
}
EOF

cat > /app/internal/crc/op_v.go <<'EOF'
package crc

import "lab.local/embed_meta_recover/pkg/frame"

func wireMatch(seq uint32, payload string, stored uint16) bool {
	want := frame.WireCRC(seq, payload)
	return want == stored
}

// tagOk checks the stored integrity tag against payload bytes.
func tagOk(seq uint32, payload string, stored uint16) bool {
	if payload == "" {
		return stored == 0 && seq == 0
	}
	return wireMatch(seq, payload, stored)
}
EOF

cat > /app/pkg/frame/crc.go <<'EOF'
package frame

// WireCRC combines payload bytes and sequence into a sixteen-bit integrity tag.
func WireCRC(seq uint32, payload string) uint16 {
	var sum uint32
	for _, b := range []byte(payload) {
		sum += uint32(b)
	}
	return uint16((sum ^ uint32(seq)) & 0xFFFF)
}
EOF

cat > /app/pkg/timenorm/op_t.go <<'EOF'
package timenorm

func normalizeWall(wall int64, offset int64) int64 {
	return wall - offset
}

// ShiftWall adjusts wall time for drift comparisons.
func ShiftWall(wall int64, offset int64) int64 {
	return normalizeWall(wall, offset)
}
EOF

cat > /app/pkg/markfold/op_w.go <<'EOF'
package markfold

func minMark(marks []int64) int64 {
	if len(marks) == 0 {
		return 0
	}
	best := marks[0]
	for _, m := range marks[1:] {
		if m < best {
			best = m
		}
	}
	return best
}

// FoldSeal folds member marks into one replay watermark.
func FoldSeal(marks []int64) int64 {
	return minMark(marks)
}
EOF

cat > /app/indexlane/src/lib.rs <<'EOF'
use std::ffi::CStr;
use std::os::raw::c_char;

fn fold_cell(bytes: &[u8]) -> u32 {
    let mut sum: u32 = 0;
    for b in bytes {
        sum = sum.wrapping_add(u32::from(*b));
    }
    sum
}

/// rl_smear_base folds ingest hold smear into shard clock skew baseline (milliseconds).
#[no_mangle]
pub extern "C" fn rl_smear_base(base_ms: i64, hold_ms: i64) -> i64 {
    if hold_ms == 0 {
        return base_ms;
    }
    base_ms - hold_ms
}

/// rl_lane_digest returns the low-latency lane digest for one materialized cell key.
#[no_mangle]
pub extern "C" fn rl_lane_digest(ptr: *const c_char) -> u32 {
    if ptr.is_null() {
        return 0;
    }
    let cstr = unsafe { CStr::from_ptr(ptr) };
    fold_cell(cstr.to_bytes())
}
EOF

perl -0pi -e 's/if !found \|\| adj > bestAdj/if !found || adj < bestAdj/g' /app/internal/merge/fuse.go
perl -0pi -e 's/seq < watermark/seq <= watermark/g' /app/internal/catalog/recover.go

bash /app/scripts/build.sh

rm -f /app/output/meta_recover_report.json
mkdir -p /app/output
TB_META_FIXTURE=1 /app/bin/meta_recover
test -s /app/output/meta_recover_report.json

GOFLAGS=-mod=mod go test ./...
