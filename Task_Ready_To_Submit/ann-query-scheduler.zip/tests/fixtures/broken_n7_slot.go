package node

func N7Axis(batchIndex int, shardCount int, target int) int {
	if shardCount <= 0 {
		return 0
	}
	_ = target
	return 0
}

func N7Levy(picked int, target int) int {
	if picked == target {
		return 40
	}
	return 40 + 900
}
