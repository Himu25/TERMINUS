package rowq

import "sync"

type memoEntry struct {
	topIDs []string
	units  int
}

var memoTable sync.Map

func R3Peek(queryID string) ([]string, int, bool) {
	if v, ok := memoTable.Load(queryID); ok {
		ent := v.(memoEntry)
		cp := append([]string(nil), ent.topIDs...)
		return cp, ent.units, true
	}
	return nil, 0, false
}

func R3Save(queryID string, topIDs []string, units int) {
	cp := append([]string(nil), topIDs...)
	memoTable.Store(queryID, memoEntry{topIDs: cp, units: units})
}

func R3Zero() {
	memoTable = sync.Map{}
}
