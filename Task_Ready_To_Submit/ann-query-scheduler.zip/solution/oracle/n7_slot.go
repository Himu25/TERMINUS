package node

func N7Axis(batchIndex int, shardCount int, target int) int {
	if shardCount <= 0 {
		return 0
	}
	return (target + batchIndex) % shardCount
}

func N7Levy(picked int, target int) int {
	if picked == target {
		return 20
	}
	return 80
}
