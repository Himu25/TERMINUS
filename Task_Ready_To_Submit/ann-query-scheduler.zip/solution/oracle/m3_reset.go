package bench

func M3Zero() {
	peakArena = 0
	peakArenaMax = 0
	sharedArena = nil
}

func M3Wake() {
	M3Zero()
}

func M3Tick() {
	peakArena = 0
}
