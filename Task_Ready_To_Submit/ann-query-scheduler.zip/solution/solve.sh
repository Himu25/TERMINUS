#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

require_file() {
  if [[ ! -f "$1" ]]; then
    echo "missing required file: $1" >&2
    exit 1
  fi
}

require_file /app/go.mod
require_file /app/config/scheduler.toml
require_file /app/data/corpus_default.json
require_file /app/data/query_specs.jsonl
mkdir -p /app/bin /app/output

cp "${ROOT_DIR}/oracle/qk_fold.go" /app/codec/qk_fold.go
cp "${ROOT_DIR}/oracle/r3_memo.go" /app/rowq/r3_memo.go
cp "${ROOT_DIR}/oracle/n7_slot.go" /app/node/n7_slot.go
python3 - <<'PY'
from pathlib import Path

fold = Path("/app/coord/r4_fold.go")
text = fold.read_text(encoding="utf-8")
broken = "return topK*len(partials) + R4CoordSurcharge(topK) + R4CoordSurcharge(topK)"
fixed = "return topK*len(partials) + R4CoordSurcharge(topK)"
if broken not in text:
    raise SystemExit(f"unexpected r4_fold.go body in {fold}")
fold.write_text(text.replace(broken, fixed, 1), encoding="utf-8")
PY
cp "${ROOT_DIR}/oracle/m3_bump.go" /app/bench/m3_bump.go
cp "${ROOT_DIR}/oracle/m3_reset.go" /app/bench/m3_reset.go

go build -o /app/bin/goldgen ./cmd/goldgen
/app/bin/goldgen \
  /app/data/corpus_default.json \
  /app/data/query_specs.jsonl \
  /app/data/queries_default.jsonl

go build -o /app/bin/schedd ./cmd/benchd
chmod +x /app/tools/run_replay
/app/tools/run_replay \
  /app/data/queries_default.jsonl \
  /app/output/scheduler_report.json

python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/scheduler.toml")
cfg: dict[str, float | int] = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    key, val = (part.strip() for part in line.split("=", 1))
    if key.endswith("_floor") or key.startswith("min_"):
        cfg[key] = float(val)
    elif key.startswith("max_") or key == "batch_window":
        cfg[key] = int(float(val))

report = json.loads(Path("/app/output/scheduler_report.json").read_text())
assert report["status"] == "ok", report
assert report["mean_recall_at_10"] >= cfg["recall_floor"]
assert report["mean_merge_units"] <= cfg["max_mean_merge_units"]
assert report["mean_batch_efficiency"] >= cfg["min_batch_efficiency"]
assert report["p95_query_units"] <= cfg["max_p95_query_units"]
assert report["peak_scratch_bytes"] <= cfg["max_peak_scratch_bytes"]
assert report["starved_lanes"] <= cfg["max_starved_lanes"]
assert any(q.get("cache_hit") for q in report["queries"])
PY
