package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"sort"

	"schedq.lab/bench"
	"schedq.lab/corpus"
	"schedq.lab/embed"
	"schedq.lab/pkg/types"
	"schedq.lab/lane"
)

func main() {
	if len(os.Args) < 4 {
		fmt.Fprintln(os.Stderr, "usage: goldgen <corpus.json> <specs.jsonl> <out.jsonl>")
		os.Exit(2)
	}
	cfg, err := bench.LoadCfg("/app/config/scheduler.toml")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	docs, err := corpus.Load(os.Args[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	type scored struct {
		id    string
		score float64
	}
	specs, err := os.Open(os.Args[2])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer specs.Close()
	out, err := os.Create(os.Args[3])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer out.Close()
	w := bufio.NewWriter(out)
	defer w.Flush()
	sc := bufio.NewScanner(specs)
	for sc.Scan() {
		line := sc.Text()
		if line == "" {
			continue
		}
		var spec struct {
			QueryID    string `json:"query_id"`
			Query      string `json:"query"`
			DeadShards []int  `json:"dead_shards"`
		}
		if err := json.Unmarshal([]byte(line), &spec); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		qv := embed.VecFromText(spec.Query, cfg.VectorDim)
		dead := make(map[int]struct{}, len(spec.DeadShards))
		for _, d := range spec.DeadShards {
			dead[d] = struct{}{}
		}
		pairs := make([]scored, 0, len(docs))
		for _, doc := range docs {
			sid := lane.RouteDoc(doc.ID, cfg.ShardCount)
			if _, off := dead[sid]; off {
				continue
			}
			vec := embed.VecFromText(doc.Text, cfg.VectorDim)
			pairs = append(pairs, scored{id: doc.ID, score: embed.Dot(qv, vec)})
		}
		sort.Slice(pairs, func(i, j int) bool {
			return pairs[i].score > pairs[j].score
		})
		k := cfg.TopK
		if k > len(pairs) {
			k = len(pairs)
		}
		gold := make([]string, 0, k)
		for i := 0; i < k; i++ {
			gold = append(gold, pairs[i].id)
		}
		row := types.QueryCase{
			QueryID:    spec.QueryID,
			Query:      spec.Query,
			GoldIDs:    gold,
			DeadShards: spec.DeadShards,
		}
		raw, _ := json.Marshal(row)
		w.Write(raw)
		w.WriteByte('\n')
	}
	if err := sc.Err(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
