package node

import "schedq.lab/lane"

func NxTally(lanes []lane.Lane, dim int, dead []int) int {
	deadSet := make(map[int]struct{}, len(dead))
	for _, d := range dead {
		deadSet[d] = struct{}{}
	}
	total := 0
	for _, ln := range lanes {
		if _, off := deadSet[ln.ShardID]; off {
			continue
		}
		total += lane.KxSpan(ln, dim)
	}
	return total
}
