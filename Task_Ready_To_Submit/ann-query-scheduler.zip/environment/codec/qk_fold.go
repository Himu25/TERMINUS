package codec

func QkFold(pending int, window int) int {
	if pending <= 0 {
		return 0
	}
	if pending < 2 {
		return pending
	}
	return 2
}

func QkTax(batchSize int) int {
	if batchSize <= 1 {
		return 220
	}
	return 120
}
