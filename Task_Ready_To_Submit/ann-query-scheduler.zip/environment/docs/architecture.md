# Architecture notes

Corpus JSON is embedded, partitioned across shard lanes by doc id hash, scheduled in batches through the query dispatcher, probed per live lane, then merged globally.

`/app/output/scheduler_report.json` top-level keys: status, corpus_vectors, vector_dim, shard_count, queries_total, mean_recall_at_10, mean_ndcg_at_10, mean_shard_units, mean_merge_units, mean_batch_efficiency, p95_query_units, peak_scratch_bytes, starved_lanes, report_digest, queries.

Each queries row: query_id, recall_at_10, ndcg_at_10, gold_hits, shard_units, merge_units, query_units, shards_queried, top_ids, batch_size, cache_hit. Ranking metrics are between zero and one; gold_hits is non-negative. Unit fields are synthetic cost tallies, not wall-clock timings. query_units equals shard_units plus merge_units plus scheduler overhead. mean_batch_efficiency compares realized batch sizes against batch_window from scheduler.toml. starved_lanes counts shard lanes that received zero scheduled queries during the replay. peak_scratch_bytes is the high-water mark of scratch allocations for the run.

Digest covers every report field except the live digest value. Build compact JSON with `separators=(',', ':')` and UTF-8, hashing with SHA-256 lowercase hex. Top-level key order: status, corpus_vectors, vector_dim, shard_count, queries_total, mean_recall_at_10, mean_ndcg_at_10, mean_shard_units, mean_merge_units, mean_batch_efficiency, p95_query_units, peak_scratch_bytes, starved_lanes, report_digest (empty string), queries. Each queries[] row key order: query_id, recall_at_10, ndcg_at_10, gold_hits, shard_units, merge_units, query_units, shards_queried, top_ids, batch_size, cache_hit. Verifier mean recomputation allows four-decimal drift (2e-4).

Quality gates compare means against floors and ceilings in scheduler.toml. When every scheduler.toml guardrail passes, status is the string ok; otherwise status is fail. Failover packs list dead_shards per query; only live lanes may be queried. The hot-skew pack must keep `starved_lanes` at or below `max_starved_lanes_skew`. The tight-recall pack security row must meet `tight_security_recall_floor`.

Per-field unit semantics and merge fold pass worked examples are in `/app/docs/unit_ledger.md`.

## Regression scope

Scheduling regressions span batch coalescing and coalesce tax (codec), query memo reuse (rowq), lane placement against shard targets (node), global merge unit tally (coord), and scratch high-water plus per-batch reset (bench). Repairs must correct those canonical implementations in place. Bridge or wrapper modules that route around them while leaving the originals broken will not pass ablation checks.

Verifier fixture benches write generated query JSONL under `/app/output/queries_<pack>.jsonl` (never under `/tests`) and may write `/app/output/pack_failover.json`, `/app/output/pack_skew.json`, `/app/output/pack_tight.json`, `/app/output/pack_burst.json`, `/app/output/ablation_batch.json`, `/app/output/ablation_memo.json`, `/app/output/ablation_lane.json`, `/app/output/ablation_merge.json`, `/app/output/ablation_scratch.json`. Ablation sources live under the verifier fixture tree.
