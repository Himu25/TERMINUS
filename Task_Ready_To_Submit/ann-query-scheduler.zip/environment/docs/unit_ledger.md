# Unit ledger

Synthetic unit fields in `/app/output/scheduler_report.json` are deterministic cost tallies used by guardrails in `/app/config/scheduler.toml`. They are not wall-clock timings.

## Shard probe units

`shard_units` sums per-lane probe work for every live shard lane. Failover query specs list `dead_shards`; those lanes are skipped. `shards_queried` equals the live lane count.

## Merge units

Non-cache rows bill merge comparator work during partial fan-out and the coordinator fold:

- one `top_k`-width pass per live shard partial stream (`len(partials)` in replay)
- one additional `top_k`-width coordinator fold pass after partials are merged

For `top_k` from `/app/config/scheduler.toml` and `live` live shard lanes, non-cache `merge_units` is `top_k * (live + 1)`. Cache-hit rows reuse prior results and record `merge_units = 0`.

Examples with `top_k = 10`:

| live lanes | merge_units |
| --- | --- |
| 4 | 50 |
| 3 | 40 |
| 2 | 30 |

## Query units

`query_units` adds shard and merge tallies to scheduler overhead from batch coalescing tax and worker lane placement tax. Memo cache hits copy prior `query_units` and skip merge work.

## Scratch bytes

`peak_scratch_bytes` tracks the high-water mark of scratch arena allocations across the replay. Per-batch tick hooks reset transient scratch counters while preserving the run peak.
