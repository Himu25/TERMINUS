Rebuild schedd after Go changes:

  go build -o /app/bin/goldgen ./cmd/goldgen
  go build -o /app/bin/schedd ./cmd/benchd

Regenerate queries jsonl when corpus or specs change:

  /app/bin/goldgen /app/data/corpus_default.json /app/data/query_specs.jsonl /app/data/queries_default.jsonl

Run /app/tools/run_replay with query jsonl and output path.
