package rowq

// R3Depth reports memo table size for metrics probes only.
func R3Depth() int {
	n := 0
	memoTable.Range(func(_, _ any) bool {
		n++
		return true
	})
	return n
}
