package rowq

import "sync"

type memoEntry struct {
	topIDs []string
	units  int
}

var memoTable sync.Map

func R3Peek(queryID string) ([]string, int, bool) {
	return nil, 0, false
}

func R3Save(queryID string, topIDs []string, units int) {
	_ = queryID
	_ = topIDs
	_ = units
}

func R3Zero() {
	memoTable = sync.Map{}
}
