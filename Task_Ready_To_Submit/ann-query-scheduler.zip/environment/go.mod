module schedq.lab

go 1.22
