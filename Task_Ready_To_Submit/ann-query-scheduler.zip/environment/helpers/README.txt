Helper scripts live under /app/tools. The apply_patch helper accepts Cursor-style patch hunks on stdin; go and gofmt are on PATH via /usr/local/go/bin.
