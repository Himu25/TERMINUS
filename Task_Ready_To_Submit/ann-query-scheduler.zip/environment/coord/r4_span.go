package coord

import "schedq.lab/pkg/types"

// R4Span reports candidate cardinality before fold; not used in replay totals.
func R4Span(partials [][]types.PartialHit) int {
	n := 0
	for _, block := range partials {
		n += len(block)
	}
	return n
}
