package coord

import (
	"sort"

	"schedq.lab/pkg/types"
)

func MxFold(partials [][]types.PartialHit, topK int) []types.PartialHit {
	best := make(map[string]types.PartialHit)
	for _, block := range partials {
		for _, hit := range block {
			cur, ok := best[hit.DocID]
			if !ok || hit.Score > cur.Score {
				best[hit.DocID] = hit
			}
		}
	}
	flat := make([]types.PartialHit, 0, len(best))
	for _, hit := range best {
		flat = append(flat, hit)
	}
	sort.Slice(flat, func(i, j int) bool {
		if flat[i].Score == flat[j].Score {
			return flat[i].DocID < flat[j].DocID
		}
		return flat[i].Score > flat[j].Score
	})
	if topK <= 0 || topK > len(flat) {
		topK = len(flat)
	}
	return flat[:topK]
}

func R4CoordSurcharge(topK int) int {
	return topK
}

func R4Weight(partials [][]types.PartialHit, topK int) int {
	if len(partials) == 0 {
		return 0
	}
	return topK*len(partials) + R4CoordSurcharge(topK) + R4CoordSurcharge(topK)
}

func MxSpan(partials [][]types.PartialHit) int {
	n := 0
	for _, block := range partials {
		n += len(block)
	}
	return n
}
