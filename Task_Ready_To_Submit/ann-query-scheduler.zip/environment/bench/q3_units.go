package bench

import (
	"schedq.lab/lane"
	"schedq.lab/node"
)

func ProbeUnits(lanes []lane.Lane, dim int, dead []int) int {
	return node.NxTally(lanes, dim, dead)
}
