package bench

import "schedq.lab/rowq"

func MemoLookup(queryID string) ([]string, int, bool) {
	return rowq.R3Peek(queryID)
}

func MemoSave(queryID string, topIDs []string, units int) {
	rowq.R3Save(queryID, topIDs, units)
}
