package bench

import "schedq.lab/codec"

func CoalesceWindow(pending int, window int) int {
	return codec.QkFold(pending, window)
}

func CoalesceTax(batchSize int) int {
	return codec.QkTax(batchSize)
}
