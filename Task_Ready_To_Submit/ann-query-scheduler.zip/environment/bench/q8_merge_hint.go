package bench

// MergeHintWeight mirrors the unit_ledger merge row; replay uses FoldTopK.
func MergeHintWeight(liveShards int, topK int) int {
	if liveShards <= 0 {
		return 0
	}
	return topK * (liveShards + 1)
}
