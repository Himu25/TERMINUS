package bench

func ScratchAlloc(dim int) []float64 {
	return M3Bump(dim)
}

func ScratchPeak() int {
	return M3High()
}
