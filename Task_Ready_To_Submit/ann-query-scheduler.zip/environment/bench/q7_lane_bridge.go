package bench

import "schedq.lab/node"

func WorkerPick(target int, batchIndex int, shardCount int) int {
	return node.N7Axis(batchIndex, shardCount, target)
}

func WorkerTax(picked int, target int) int {
	return node.N7Levy(picked, target)
}
