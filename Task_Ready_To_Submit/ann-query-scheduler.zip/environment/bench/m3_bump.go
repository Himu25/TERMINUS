package bench

var peakArena int

func M3Bump(dim int) []float64 {
	buf := make([]float64, dim*4)
	used := dim * 20
	if used > peakArena {
		peakArena = used
	}
	return buf
}

func M3High() int {
	return peakArena
}
