package lane

// S3Stride is a legacy batch stride helper kept for lane diagnostics; the live
// dispatcher does not call it during replay.
func S3Stride(pending int, window int) int {
	if pending <= 0 || window <= 0 {
		return 0
	}
	if pending < window {
		return pending
	}
	return window
}
