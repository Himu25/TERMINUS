package config

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"lab.local/shadow_feature_flag_collapse/pkg/gen"
)

// Bundle describes one flag replay pack.
type Bundle struct {
	RunID                   string `json:"run_id"`
	EvalCount               int    `json:"eval_count"`
	CacheFloorSlots          int    `json:"cache_floor_slots"`
	RolloutCapSlots           int    `json:"rollout_cap_slots"`
	BreachThresholdSlots int    `json:"breach_threshold_slots"`
	ConfigRevision        int    `json:"config_revision"`
	ActiveRevision          int    `json:"active_revision"`
	IsolateBand             int    `json:"isolate_band"`
}

// ActivePaths returns the active pack directory under appRoot.
func ActivePaths(appRoot string) (string, error) {
	dir := filepath.Join(appRoot, "data", "active", "run_alpha")
	if st, err := os.Stat(dir); err != nil || !st.IsDir() {
		return "", fmt.Errorf("active pack missing: %s", dir)
	}
	return dir, nil
}

// LoadBundle reads flag_bundle.json and evals.jsonl from dir.
func LoadBundle(dir string) (Bundle, []gen.Row, error) {
	raw, err := os.ReadFile(filepath.Join(dir, "flag_bundle.json"))
	if err != nil {
		return Bundle{}, nil, err
	}
	var bundle Bundle
	if err := json.Unmarshal(raw, &bundle); err != nil {
		return Bundle{}, nil, err
	}
	lines, err := os.ReadFile(filepath.Join(dir, "evals.jsonl"))
	if err != nil {
		return Bundle{}, nil, err
	}
	var rows []gen.Row
	for _, line := range splitLines(string(lines)) {
		if line == "" {
			continue
		}
		var row gen.Row
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return Bundle{}, nil, err
		}
		rows = append(rows, row)
	}
	return bundle, rows, nil
}

func splitLines(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			out = append(out, s[start:i])
			start = i + 1
		}
	}
	if start < len(s) {
		out = append(out, s[start:])
	}
	return out
}
