package engine

import (
	"lab.local/shadow_feature_flag_collapse/pathcore"
	"lab.local/shadow_feature_flag_collapse/pkg/dimfold"
	"lab.local/shadow_feature_flag_collapse/pkg/phasgate"
	"lab.local/shadow_feature_flag_collapse/pkg/driftlane"
	"lab.local/shadow_feature_flag_collapse/pkg/roomgap"
	"lab.local/shadow_feature_flag_collapse/pkg/veilclip"
)

func latRoll(wait, cache_hit, floor int) int {
	return veilclip.OpV(wait, cache_hit, floor)
}

func rRoll(tenant_tier, granted, floor, band int) int {
	return roomgap.OpR(tenant_tier, granted, floor, band)
}

func dimRoll(invertFlag, tenant_tier int) int {
	return dimfold.OpS(invertFlag, tenant_tier)
}

func phasRoll(burstPhase, granted, cap int) int {
	return phasgate.OpY(burstPhase, granted, cap)
}

func driftRoll(lane, prev int, first bool) int {
	return driftlane.OpL(lane, prev, first)
}

func fRoll(base, granted int) int {
	return pathcore.Fold(base, granted)
}

func cfgBit(schedRev, activeRev int) int {
	if activeRev < schedRev {
		return 1
	}
	return 0
}

func leakGap(tenant_tier, waitEff, granted, band int) int {
	if tenant_tier < band {
		return 0
	}
	gap := waitEff - granted
	if gap <= 0 {
		return 0
	}
	return gap
}
