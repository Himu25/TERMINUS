package engine

import (
	"lab.local/shadow_feature_flag_collapse/internal/config"
	"lab.local/shadow_feature_flag_collapse/pkg/gen"
)

// Outcome is folded counters for one pack replay.
type Outcome struct {
	EvalCount            int
	FastPathTotal       int
	MaxLeakSlots   int
	IsolationDebtTotal    int
	ShadowLeakEvents      int
	SyncFailureCount    int
	EvalFoldUnits      int
	RollbackShifts      int
	ConfigStaleFlag    int
	BreachHits       int
}

// Replay executes one active pack through the flag audit pipeline.
func Replay(bundle config.Bundle, rows []gen.Row) Outcome {
	sortRows(rows)
	totalWait := 0
	maxStarve := 0
	debt := 0
	inversions := 0
	burstPen := 0
	throughput := 0
	rebalance := 0
	starveHits := 0
	ticks := 0
	prevLane := 0
	firstLane := true

	for _, row := range rows {
		if row.Seq <= 0 {
			continue
		}
		ticks++
		waitEff := latRoll(row.LatencySlots, row.CacheHit, bundle.CacheFloorSlots)
		totalWait += waitEff
		gap := leakGap(row.TenantTier, waitEff, row.RolloutSlots, bundle.IsolateBand)
		if gap > maxStarve {
			maxStarve = gap
		}
		debt += rRoll(row.TenantTier, row.RolloutSlots, bundle.CacheFloorSlots, bundle.IsolateBand)
		inversions += dimRoll(row.ShadowBit, row.TenantTier)
		burstPen += phasRoll(row.SyncPhase, row.RolloutSlots, bundle.RolloutCapSlots)
		throughput = fRoll(throughput, row.RolloutSlots)
		rebalance += driftRoll(row.RegionLane, prevLane, firstLane)
		prevLane = row.RegionLane
		firstLane = false
		if gap > bundle.BreachThresholdSlots {
			starveHits++
		}
	}

	tickCount := bundle.EvalCount
	if tickCount <= 0 {
		tickCount = ticks
	}
	stale := cfgBit(bundle.ConfigRevision, bundle.ActiveRevision)

	return Outcome{
		EvalCount:          tickCount,
		FastPathTotal:     totalWait,
		MaxLeakSlots: maxStarve,
		IsolationDebtTotal:  debt,
		ShadowLeakEvents:    inversions,
		SyncFailureCount:  burstPen,
		EvalFoldUnits:    throughput,
		RollbackShifts:    rebalance,
		ConfigStaleFlag:  stale,
		BreachHits:     starveHits,
	}
}

func sortRows(rows []gen.Row) {
	for i := 0; i < len(rows); i++ {
		for j := i + 1; j < len(rows); j++ {
			if rows[j].Seq < rows[i].Seq {
				rows[i], rows[j] = rows[j], rows[i]
			}
		}
	}
}
