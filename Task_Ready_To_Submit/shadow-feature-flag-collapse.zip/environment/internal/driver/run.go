package driver

import (
	"encoding/json"
	"os"

	"lab.local/shadow_feature_flag_collapse/internal/config"
	"lab.local/shadow_feature_flag_collapse/internal/engine"
	"lab.local/shadow_feature_flag_collapse/pkg/digest"
)

// Report is the JSON shape written to /app/output/flag_audit.json.
type Report struct {
	SchemaVersion        string `json:"schema_version"`
	RunID                string `json:"run_id"`
	EvalCount            int    `json:"eval_count"`
	FastPathTotal       int    `json:"fast_path_total"`
	MaxLeakSlots   int    `json:"max_leak_slots"`
	IsolationDebtTotal    int    `json:"isolation_debt_total"`
	ShadowLeakEvents      int    `json:"shadow_leak_events"`
	SyncFailureCount    int    `json:"sync_failure_count"`
	EvalFoldUnits      int    `json:"eval_fold_units"`
	RollbackShifts      int    `json:"rollback_shifts"`
	ConfigStaleFlag    int    `json:"config_stale_flag"`
	BreachHits       int    `json:"breach_hits"`
	DigestHex            string `json:"digest_hex"`
}

// RunActive loads the active pack and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	bundle, rows, err := config.LoadBundle(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(bundle, rows)
	digestHex := digest.FoldReport(
		bundle.RunID,
		itoa(out.EvalCount),
		itoa(out.FastPathTotal),
		itoa(out.MaxLeakSlots),
		itoa(out.IsolationDebtTotal),
		itoa(out.ShadowLeakEvents),
		itoa(out.SyncFailureCount),
		itoa(out.EvalFoldUnits),
		itoa(out.RollbackShifts),
		itoa(out.ConfigStaleFlag),
		itoa(out.BreachHits),
	)
	return Report{
		SchemaVersion:      "1",
		RunID:              bundle.RunID,
		EvalCount:          out.EvalCount,
		FastPathTotal:     out.FastPathTotal,
		MaxLeakSlots: out.MaxLeakSlots,
		IsolationDebtTotal:  out.IsolationDebtTotal,
		ShadowLeakEvents:    out.ShadowLeakEvents,
		SyncFailureCount:  out.SyncFailureCount,
		EvalFoldUnits:    out.EvalFoldUnits,
		RollbackShifts:    out.RollbackShifts,
		ConfigStaleFlag:  out.ConfigStaleFlag,
		BreachHits:     out.BreachHits,
		DigestHex:          digestHex,
	}, nil
}

// EmitReport writes rep to path as compact JSON.
func EmitReport(path string, rep Report) error {
	if err := os.MkdirAll("/app/output", 0o755); err != nil {
		return err
	}
	raw, err := json.Marshal(rep)
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func itoa(v int) string {
	if v == 0 {
		return "0"
	}
	var buf [16]byte
	i := len(buf)
	n := v
	neg := false
	if n < 0 {
		neg = true
		n = -n
	}
	for n > 0 {
		i--
		buf[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		buf[i] = '-'
	}
	return string(buf[i:])
}
