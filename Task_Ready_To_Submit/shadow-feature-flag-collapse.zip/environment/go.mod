module lab.local/shadow_feature_flag_collapse

go 1.22
