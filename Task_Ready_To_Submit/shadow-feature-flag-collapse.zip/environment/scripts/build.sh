#!/bin/bash
set -euo pipefail

# CGO_ENABLED=1 links the Go binary against pathcore (required for fRoll).
export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1

mkdir -p /app/bin
cd /app/pathcore
cargo build --release --locked
cd /app
GOFLAGS=-mod=mod go build -trimpath -buildvcs=false -o /app/bin/flag_audit ./cmd/flag_audit
