// Report JSON for /app/output/flag_audit.json:
//
// schema_version — string, always "1"
// run_id — string, echoes active pack name
// eval_count — evaluation rows in the bundle schedule (seq > 0 rows)
// fast_path_total — sum of per-row effective latency slots after cache-hit clipping
// max_leak_slots — largest latency-minus-rollout gap for rows in the isolate band
// isolation_debt_total — sum of per-row isolation debt for the isolate band
// shadow_leak_events — count of shadow-path activations on eval rows
// sync_failure_count — count of sync-phase rows whose rollout slots exceed rollout_cap_slots
// eval_fold_units — running fold of rollout slots through the pathcore helper
// rollback_shifts — count of region changes between consecutive eval rows
// config_stale_flag — 1 when active revision lags config revision, else 0
// breach_hits — eval rows whose leak gap exceeds breach_threshold_slots
// digest_hex — lowercase hex SHA-256 of run_id|eval_count|fast_path_total|max_leak_slots|
//   isolation_debt_total|shadow_leak_events|sync_failure_count|eval_fold_units|rollback_shifts|
//   config_stale_flag|breach_hits
//
// Root object contains only these keys.
//
// Replay sorts eval rows by seq. Control rows with seq zero are ignored.
// Effective latency uses cache-hit clipping from the bundle cache_floor_slots.
// Isolation debt applies only when tenant_tier is at or above isolate_band.
// Sync failures apply only when sync_phase is set and rollout slots exceed rollout_cap_slots.
// Shadow leak events count every eval row with shadow_bit set.
// Rollback shifts increment when region_lane changes from the previous eval row.
// Config stale is active revision strictly below config revision.
// Breach hits use a gap strictly greater than breach_threshold_slots.
package main

import (
	"log"
	"os"

	"lab.local/shadow_feature_flag_collapse/internal/driver"
)

func main() {
	if os.Getenv("TB_FLAG_AUDIT") != "1" {
		log.Fatal("TB_FLAG_AUDIT unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/flag_audit.json", rep); err != nil {
		log.Fatal(err)
	}
}
