package roomgap

// OpR accrues isolation debt for rows in the isolate band.
func OpR(a, b, c, d int) int {
	if a < d {
		return 0
	}
	gap := b - c
	if gap <= 0 {
		return 0
	}
	return gap
}
