package roomgap

import "testing"

func TestOpRLowBandZero(t *testing.T) {
	if OpR(3, 0, 2, 7) != 0 {
		t.Fatal("expected zero debt below band")
	}
}

func TestOpRDebtWhenUnderServed(t *testing.T) {
	if OpR(8, 1, 2, 7) != 1 {
		t.Fatal("expected debt when granted is below floor")
	}
}
