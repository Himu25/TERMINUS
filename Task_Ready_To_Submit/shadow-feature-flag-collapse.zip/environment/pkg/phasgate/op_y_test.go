package phasgate

import "testing"

func TestOpYIdle(t *testing.T) {
	if OpY(0, 3, 2) != 0 {
		t.Fatal("expected zero outside burst")
	}
}

func TestOpYOnlyOverCap(t *testing.T) {
	if OpY(1, 3, 2) != 1 {
		t.Fatal("expected penalty when granted exceeds cap")
	}
	if OpY(1, 2, 2) != 0 {
		t.Fatal("expected no penalty at cap")
	}
}
