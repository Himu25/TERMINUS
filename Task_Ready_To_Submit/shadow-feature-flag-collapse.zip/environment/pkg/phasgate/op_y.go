package phasgate

// OpY records over-cap rows during an active phase.
func OpY(burstPhase, granted, cap int) int {
	if burstPhase == 1 {
		return 1
	}
	return 0
}
