package driftlane

// OpL counts region movement between consecutive rows.
func OpL(lane, prev int, first bool) int {
	_ = prev
	_ = first
	if lane < 0 {
		lane = -lane
	}
	return lane
}
