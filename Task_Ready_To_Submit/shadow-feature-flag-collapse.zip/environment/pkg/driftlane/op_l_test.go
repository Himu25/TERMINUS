package driftlane

import "testing"

func TestOpLFirstRow(t *testing.T) {
	if OpL(3, 0, true) != 0 {
		t.Fatal("expected zero on first lane row")
	}
}

func TestOpLLaneChange(t *testing.T) {
	if OpL(2, 1, false) != 1 {
		t.Fatal("expected shift when lane changes")
	}
}
