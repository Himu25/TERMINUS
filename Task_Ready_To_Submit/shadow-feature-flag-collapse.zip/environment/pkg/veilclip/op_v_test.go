package veilclip

import "testing"

func TestOpVNoCacheHit(t *testing.T) {
	if OpV(5, 0, 2) != 5 {
		t.Fatal("expected unchanged wait")
	}
}

func TestOpVClipsCacheHit(t *testing.T) {
	if OpV(4, 1, 2) != 2 {
		t.Fatal("expected clipped wait under cache_hit")
	}
}
