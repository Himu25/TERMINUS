package veilclip

// OpV scales latency slots when an edge snapshot hits.
func OpV(wait, cache_hit, floor int) int {
	if cache_hit == 1 {
		return wait * 2
	}
	return wait
}
