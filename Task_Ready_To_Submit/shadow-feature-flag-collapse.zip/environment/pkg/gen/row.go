package gen

// Row is one flag evaluation from the pack log.
type Row struct {
	Seq          int `json:"seq"`
	Tick         int `json:"tick"`
	TenantTier     int `json:"tenant_tier"`
	LatencySlots    int `json:"latency_slots"`
	RolloutSlots int `json:"rollout_slots"`
	SyncPhase   int `json:"sync_phase"`
	ShadowBit   int `json:"shadow_bit"`
	RegionLane       int `json:"region_lane"`
	CacheHit  int `json:"cache_hit"`
}
