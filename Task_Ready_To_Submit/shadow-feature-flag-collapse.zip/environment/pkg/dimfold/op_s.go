package dimfold

// OpS counts activations on an eval row.
func OpS(invertFlag, tier int) int {
	if invertFlag != 1 {
		return 0
	}
	if tier <= 3 {
		return 1
	}
	return 0
}
