package dimfold

import "testing"

func TestOpSNoInvert(t *testing.T) {
	if OpS(0, 8) != 0 {
		t.Fatal("expected zero without invert flag")
	}
}

func TestOpSInvertAnyBand(t *testing.T) {
	if OpS(1, 8) != 1 {
		t.Fatal("expected inversion count for high band row")
	}
}
