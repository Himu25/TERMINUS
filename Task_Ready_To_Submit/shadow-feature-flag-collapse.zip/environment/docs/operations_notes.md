# Operations notes

The flag audit harness replays evaluation logs from `/app/data/active` and indexed packs listed in `replay_index.txt`. Isolation accounting spans Go heuristics and the pathcore native fold.
