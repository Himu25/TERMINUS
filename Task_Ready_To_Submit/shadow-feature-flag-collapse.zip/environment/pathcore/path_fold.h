#pragma once
#include <stdint.h>
int32_t path_fold(int32_t base, int32_t granted);
