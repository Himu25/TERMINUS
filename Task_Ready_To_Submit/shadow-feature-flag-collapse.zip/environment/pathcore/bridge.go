package pathcore

// #cgo LDFLAGS: -L${SRCDIR}/target/release -lpathcore
// #include "path_fold.h"
import "C"

// Fold applies the native throughput fold across ticks.
func Fold(base, granted int) int {
	return int(C.path_fold(C.int32_t(base), C.int32_t(granted)))
}
