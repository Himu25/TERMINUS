/// PathFold folds rollout slots into a running tally.
#[no_mangle]
pub extern "C" fn path_fold(base: i32, granted: i32) -> i32 {
    base - granted
}
