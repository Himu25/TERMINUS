#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > pkg/roomgap/op_r.go <<'EOF'
package roomgap

// OpR accrues isolation debt for rows in the isolate band.
func OpR(a, b, c, d int) int {
	if a < d {
		return 0
	}
	gap := c - b
	if gap <= 0 {
		return 0
	}
	return gap
}
EOF

cat > pkg/veilclip/op_v.go <<'EOF'
package veilclip

// OpV scales latency slots when an edge snapshot hits.
func OpV(wait, cache_hit, floor int) int {
	if cache_hit == 1 {
		if wait < floor {
			return wait
		}
		return floor
	}
	return wait
}
EOF

cat > pkg/dimfold/op_s.go <<'EOF'
package dimfold

// OpS counts shadow-path activations on an eval row.
func OpS(invertFlag, tier int) int {
	_ = tier
	if invertFlag == 1 {
		return 1
	}
	return 0
}
EOF

cat > pkg/phasgate/op_y.go <<'EOF'
package phasgate

// OpY records sync-phase over-cap rows.
func OpY(burstPhase, granted, cap int) int {
	if burstPhase != 1 {
		return 0
	}
	if granted > cap {
		return 1
	}
	return 0
}
EOF

cat > pkg/driftlane/op_l.go <<'EOF'
package driftlane

// OpL counts region movement for rollback accounting.
func OpL(lane, prev int, first bool) int {
	if first {
		return 0
	}
	if lane != prev {
		return 1
	}
	return 0
}
EOF

sed -i 's/base - granted/base + granted/' pathcore/src/lib.rs

bash /app/scripts/build.sh

GOFLAGS=-mod=mod CGO_ENABLED=1 go test ./pkg/roomgap ./pkg/veilclip ./pkg/dimfold ./pkg/phasgate ./pkg/driftlane -count=1

rm -f /app/output/flag_audit.json
TB_FLAG_AUDIT=1 /app/bin/flag_audit
test -s /app/output/flag_audit.json
