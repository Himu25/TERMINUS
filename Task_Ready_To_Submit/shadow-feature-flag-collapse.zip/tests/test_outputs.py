"""Verifier for shadow feature flag collapse audit."""

import json
import os
import shutil
import subprocess

import pytest
from pathlib import Path

APP = Path("/app")
ACTIVE = APP / "data" / "active" / "run_alpha"
FIXTURES = APP / "data" / "replay"
OUT = APP / "output" / "flag_audit.json"
GO_BIN = "go"
VERIFY_BIN = "/app/bin/flag_audit"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _digest_hex(
    run_id: str,
    eval_count: int,
    total_wait: int,
    max_starve: int,
    debt: int,
    inv: int,
    burst: int,
    thr: int,
    rebal: int,
    stale: int,
    starve_hits: int,
) -> str:
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            run_id,
            str(eval_count),
            str(total_wait),
            str(max_starve),
            str(debt),
            str(inv),
            str(burst),
            str(thr),
            str(rebal),
            str(stale),
            str(starve_hits),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _op_t(tenant_tier: int, granted: int, floor: int, band: int) -> int:
    if tenant_tier < band:
        return 0
    d = floor - granted
    return d if d > 0 else 0


def _op_w(wait: int, cache_hit: int, floor: int) -> int:
    if cache_hit == 1:
        return min(wait, floor)
    return wait


def _op_f(shadow_bit: int) -> int:
    return 1 if shadow_bit == 1 else 0


def _op_g(burst: int, granted: int, cap: int) -> int:
    if burst != 1:
        return 0
    return 1 if granted > cap else 0


def _op_h(lane: int, prev: int, first: bool) -> int:
    if first:
        return 0
    return 1 if lane != prev else 0


def _fold_thr(base: int, granted: int) -> int:
    return base + granted


def _starve_gap(tenant_tier: int, wait_eff: int, granted: int, band: int) -> int:
    if tenant_tier < band:
        return 0
    gap = wait_eff - granted
    return gap if gap > 0 else 0


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = FIXTURES / pack_name
    bundle = json.loads((pack_dir / "flag_bundle.json").read_text())
    rows = []
    for line in (pack_dir / "evals.jsonl").read_text().splitlines():
        if line.strip():
            rows.append(json.loads(line))
    rows.sort(key=lambda r: r["seq"])

    total_wait = 0
    max_starve = 0
    debt = 0
    inv = 0
    burst = 0
    thr = 0
    rebal = 0
    starve_hits = 0
    ticks = 0
    prev_lane = 0
    first_lane = True

    for row in rows:
        if row["seq"] <= 0:
            continue
        ticks += 1
        wait_eff = _op_w(row["latency_slots"], row["cache_hit"], bundle["cache_floor_slots"])
        total_wait += wait_eff
        gap = _starve_gap(
            row["tenant_tier"], wait_eff, row["rollout_slots"], bundle["isolate_band"]
        )
        max_starve = max(max_starve, gap)
        debt += _op_t(
            row["tenant_tier"],
            row["rollout_slots"],
            bundle["cache_floor_slots"],
            bundle["isolate_band"],
        )
        inv += _op_f(row["shadow_bit"])
        burst += _op_g(
            row["sync_phase"], row["rollout_slots"], bundle["rollout_cap_slots"]
        )
        thr = _fold_thr(thr, row["rollout_slots"])
        rebal += _op_h(row["region_lane"], prev_lane, first_lane)
        prev_lane = row["region_lane"]
        first_lane = False
        if gap > bundle["breach_threshold_slots"]:
            starve_hits += 1

    eval_count = bundle["eval_count"] if bundle["eval_count"] > 0 else ticks
    stale = (
        1
        if bundle["active_revision"] < bundle["config_revision"]
        else 0
    )

    digest = _digest_hex(
        bundle["run_id"],
        eval_count,
        total_wait,
        max_starve,
        debt,
        inv,
        burst,
        thr,
        rebal,
        stale,
        starve_hits,
    )
    return {
        "schema_version": "1",
        "run_id": bundle["run_id"],
        "eval_count": eval_count,
        "fast_path_total": total_wait,
        "max_leak_slots": max_starve,
        "isolation_debt_total": debt,
        "shadow_leak_events": inv,
        "sync_failure_count": burst,
        "eval_fold_units": thr,
        "rollback_shifts": rebal,
        "config_stale_flag": stale,
        "breach_hits": starve_hits,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    dest = ACTIVE
    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(src, dest)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_FLAG_AUDIT": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_alpha_report_matches_replay() -> None:
    """Active run_alpha pack should replay all flag counters including digest."""
    _swap("run_alpha")
    exp = _expected_from_fixture("run_alpha")
    got = _run_tool()
    assert got == exp


def test_partial_sync_failures_match_replay() -> None:
    """Indexed partial_sync_b pack should replay all flag counters including digest."""
    _swap("partial_sync_b")
    exp = _expected_from_fixture("partial_sync_b")
    got = _run_tool()
    assert got == exp


def test_stale_cache_max_gap_matches_replay() -> None:
    """Indexed stale_cache_a pack should replay all flag counters including digest."""
    _swap("stale_cache_a")
    exp = _expected_from_fixture("stale_cache_a")
    got = _run_tool()
    assert got == exp


def test_alpha_shadow_leaks_match_replay() -> None:
    """Alpha pack should count every shadow_bit row."""
    _swap("run_alpha")
    exp = _expected_from_fixture("run_alpha")
    got = _run_tool()
    assert got["shadow_leak_events"] == exp["shadow_leak_events"]


def test_alpha_rollback_shifts_match_replay() -> None:
    """Alpha pack should count region changes between consecutive eval rows."""
    _swap("run_alpha")
    exp = _expected_from_fixture("run_alpha")
    got = _run_tool()
    assert got["rollback_shifts"] == exp["rollback_shifts"]


def test_go_subsystem_tests_pass() -> None:
    """Go tests under /app must pass after the repair."""
    subprocess.run(
        [
            GO_BIN,
            "test",
            "./pkg/roomgap",
            "./pkg/veilclip",
            "./pkg/dimfold",
            "./pkg/phasgate",
            "./pkg/driftlane",
        ],
        cwd="/app",
        env={
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        },
        check=True,
    )
