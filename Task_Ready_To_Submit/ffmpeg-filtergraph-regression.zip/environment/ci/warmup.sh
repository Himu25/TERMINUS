#!/bin/bash
set -euo pipefail
make -C /app fglab
/app/bin/fglab synth >/dev/null || true
