#include "flux/op_c.h"

#include <sstream>

#include "bridge/json_util.h"

namespace flux {
namespace {

void push_fail(std::vector<bridge::FailureRow>& rows, const std::string& field,
               const std::string& expected, const std::string& actual) {
  rows.push_back({field, expected, actual});
}

std::string short_hash(const std::string& full) {
  if (full.size() <= 16) {
    return full;
  }
  return full.substr(0, 16);
}

}  // namespace

bridge::RegressionReport op_c(const std::string& manifest_path,
                              const bridge::ProbeBundle& bundle) {
  const bridge::ManifestDoc doc = bridge::load_manifest(manifest_path);
  bridge::RegressionReport report;
  report.schema_tag = doc.schema_tag;
  for (const auto& manifest_row : doc.cases) {
    const bridge::ProbeCaseRow* probe = nullptr;
    for (const auto& row : bundle.cases) {
      if (row.id == manifest_row.id) {
        probe = &row;
        break;
      }
    }
    bridge::RegressionCaseRow case_row;
    case_row.id = manifest_row.id;
    case_row.status = "pass";
    if (!probe) {
      case_row.status = "fail";
      push_fail(case_row.failures, "", "probe row", "missing");
      report.cases.push_back(case_row);
      continue;
    }
    const auto& g = manifest_row.golden;
    if (probe->video_streams != g.video_streams) {
      case_row.status = "fail";
      std::ostringstream e;
      e << g.video_streams;
      std::ostringstream a;
      a << probe->video_streams;
      push_fail(case_row.failures, "", e.str(), a.str());
    }
    if (probe->audio_streams != g.audio_streams) {
      case_row.status = "fail";
      std::ostringstream e;
      e << g.audio_streams;
      std::ostringstream a;
      a << probe->audio_streams;
      push_fail(case_row.failures, "", e.str(), a.str());
    }
    if (!g.codec_video.empty() && probe->codec_video != g.codec_video) {
      case_row.status = "fail";
      push_fail(case_row.failures, "", g.codec_video, probe->codec_video);
    }
    if (!g.codec_audio.empty() && probe->codec_audio != g.codec_audio) {
      case_row.status = "fail";
      push_fail(case_row.failures, "", g.codec_audio, probe->codec_audio);
    }
    if (g.width > 0 && probe->width != g.width) {
      case_row.status = "fail";
      std::ostringstream e, a;
      e << g.width;
      a << probe->width;
      push_fail(case_row.failures, "", e.str(), a.str());
    }
    if (g.height > 0 && probe->height != g.height) {
      case_row.status = "fail";
      std::ostringstream e, a;
      e << g.height;
      a << probe->height;
      push_fail(case_row.failures, "", e.str(), a.str());
    }
    if (g.duration_sec > 0.0 &&
        probe->duration_sec != g.duration_sec) {
      case_row.status = "fail";
      std::ostringstream e, a;
      e << g.duration_sec;
      a << probe->duration_sec;
      push_fail(case_row.failures, "", e.str(), a.str());
    }
    if (g.sample_rate > 0 && probe->sample_rate != g.sample_rate) {
      case_row.status = "fail";
      std::ostringstream e, a;
      e << g.sample_rate;
      a << probe->sample_rate;
      push_fail(case_row.failures, "", e.str(), a.str());
    }
    for (size_t i = 0; i < g.frame_hashes.size(); ++i) {
      const std::string& expected = g.frame_hashes[i];
      std::string actual;
      if (i < probe->frame_hashes.size()) {
        actual = probe->frame_hashes[i];
      }
      if (actual != expected) {
        case_row.status = "fail";
        std::ostringstream label;
        label << "frame_hashes[" << i << "]";
        push_fail(case_row.failures, "", expected, actual);
      }
    }
    report.cases.push_back(case_row);
  }
  bridge::write_regression_report("/app/output/regression_report.json", report);
  return report;
}

}  // namespace flux
