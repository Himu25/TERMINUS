#include <algorithm>
#include <string>
#include <vector>

namespace flux {

std::vector<std::string> sort_tokens(std::vector<std::string> rows) {
  std::sort(rows.begin(), rows.end());
  return rows;
}

}  // namespace flux
