namespace flux {

int compare_pass() { return 0; }

}  // namespace flux
