namespace vault {

int vault_epoch() { return 1; }

}  // namespace vault
