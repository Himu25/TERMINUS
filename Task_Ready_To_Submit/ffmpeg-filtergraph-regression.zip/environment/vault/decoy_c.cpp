#include <string>
#include <vector>

namespace vault {

bool lex_lt(const std::string& a, const std::string& b) { return a < b; }

}  // namespace vault
