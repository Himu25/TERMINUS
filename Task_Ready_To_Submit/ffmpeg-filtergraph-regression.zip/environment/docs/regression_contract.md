# Regression lab outputs

## Synth manifest (`/app/output/synth_manifest.json`)
- `schema_tag` must be `tb3-ffgraph-regression-01`
- `cases` sorted by `id`
- Each row lists `video_digest`, `audio_digest`, `width`, `height`, `audio_samples`

## Probe bundle (`/app/output/probe_bundle.json`)
- `schema_tag` `tb3-ffgraph-regression-01`
- Per-case `video_streams`, `audio_streams`, codec names, `width`, `height`, `duration_sec`, `sample_rate`, `frame_hashes`
- `video_streams` and `audio_streams` are counted per stream type (not both set to the format-wide stream total)
- `duration_sec` is in seconds as returned by ffprobe (not multiplied by 1000)
- Filtered-frame digests use `select` on frame index `n`, not `n+1`

## Regression CI (`/app/cases/regression_ci.json`)
- Case inventory only in the workspace image (`id` per row); golden `probe_row` objects are published by CI after a green probe pass and are not present in `manifest.json`
- Do not copy `/app/output/probe_bundle.json` into this file to “fix” regress — edit capture/regress source instead
- Regress loads published `probe_row` fields and `frame_hashes` when diffing `/app/output/probe_bundle.json`

## Regression report (`/app/output/regression_report.json`)
- `schema_tag` `tb3-ffgraph-regression-01`
- Each case has `status` (`pass` or `fail`) and `failures` with `field`, `expected`, `actual`
- Frame-hash comparison uses only the first 16 hex characters of each digest
- Frame-hash comparison starts at index 1 (does not compare `frame_hashes[0]`)
