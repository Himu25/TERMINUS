namespace lane {

int scrape_depth() { return 2; }

}  // namespace lane
