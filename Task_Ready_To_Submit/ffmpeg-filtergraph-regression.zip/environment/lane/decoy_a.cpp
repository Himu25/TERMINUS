#include <string>

namespace lane {

std::string tail_line(const std::string& blob) {
  const auto pos = blob.rfind('\n');
  if (pos == std::string::npos) {
    return blob;
  }
  return blob.substr(pos + 1);
}

}  // namespace lane
