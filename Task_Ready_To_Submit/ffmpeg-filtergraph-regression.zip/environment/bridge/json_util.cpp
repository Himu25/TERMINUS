#include "bridge/json_util.h"

#include <cctype>
#include <fstream>
#include <regex>
#include <sstream>

namespace bridge {
namespace {

std::string read_file(const std::string& path) {
  std::ifstream in(path);
  std::ostringstream ss;
  ss << in.rdbuf();
  return ss.str();
}

std::string extract_string(const std::string& blob, const std::string& key) {
  std::regex re("\"" + key + "\"\\s*:\\s*\"([^\"]*)\"");
  std::smatch m;
  if (std::regex_search(blob, m, re)) {
    return m[1].str();
  }
  return "";
}

int extract_int(const std::string& blob, const std::string& key) {
  std::regex re("\"" + key + "\"\\s*:\\s*(-?[0-9]+)");
  std::smatch m;
  if (std::regex_search(blob, m, re)) {
    return std::stoi(m[1].str());
  }
  return 0;
}

double extract_double(const std::string& blob, const std::string& key) {
  std::regex re("\"" + key + "\"\\s*:\\s*(-?[0-9]+(?:\\.[0-9]+)?)");
  std::smatch m;
  if (std::regex_search(blob, m, re)) {
    return std::stod(m[1].str());
  }
  return 0.0;
}

std::vector<std::string> extract_string_array(const std::string& blob,
                                              const std::string& key) {
  std::vector<std::string> out;
  std::regex block("\"" + key + "\"\\s*:\\s*\\[([^\\]]*)\\]");
  std::smatch m;
  if (!std::regex_search(blob, m, block)) {
    return out;
  }
  std::regex item("\"([^\"]*)\"");
  auto begin = std::sregex_iterator(m[1].first, m[1].second, item);
  auto end = std::sregex_iterator();
  for (auto it = begin; it != end; ++it) {
    out.push_back((*it)[1].str());
  }
  return out;
}

std::vector<std::string> split_objects(const std::string& array_body) {
  std::vector<std::string> parts;
  int depth = 0;
  size_t start = 0;
  for (size_t i = 0; i < array_body.size(); ++i) {
    if (array_body[i] == '{') {
      if (depth == 0) {
        start = i;
      }
      ++depth;
    } else if (array_body[i] == '}') {
      --depth;
      if (depth == 0) {
        parts.push_back(array_body.substr(start, i - start + 1));
      }
    }
  }
  return parts;
}

GoldenRow parse_golden(const std::string& blob) {
  GoldenRow g;
  g.video_streams = extract_int(blob, "video_streams");
  g.audio_streams = extract_int(blob, "audio_streams");
  g.codec_video = extract_string(blob, "codec_video");
  g.codec_audio = extract_string(blob, "codec_audio");
  g.width = extract_int(blob, "width");
  g.height = extract_int(blob, "height");
  g.duration_sec = extract_double(blob, "duration_sec");
  g.sample_rate = extract_int(blob, "sample_rate");
  g.frame_hashes = extract_string_array(blob, "frame_hashes");
  return g;
}

CaseRow parse_case(const std::string& blob) {
  CaseRow row;
  row.id = extract_string(blob, "id");
  row.seed = static_cast<uint32_t>(extract_int(blob, "seed"));
  row.filter = extract_string(blob, "filter");
  std::regex video_block("\"video\"\\s*:\\s*\\{([^}]*)\\}");
  std::regex audio_block("\"audio\"\\s*:\\s*\\{([^}]*)\\}");
  std::regex golden_block("\"golden\"\\s*:\\s*\\{");
  std::smatch m;
  if (std::regex_search(blob, m, video_block)) {
    row.has_video = true;
    row.video.width = extract_int(m[1].str(), "width");
    row.video.height = extract_int(m[1].str(), "height");
    row.video.fps = extract_int(m[1].str(), "fps");
    row.video.frames = extract_int(m[1].str(), "frames");
  }
  if (std::regex_search(blob, m, audio_block)) {
    row.has_audio = true;
    row.audio.rate = extract_int(m[1].str(), "rate");
    row.audio.channels = extract_int(m[1].str(), "channels");
    row.audio.samples = extract_int(m[1].str(), "samples");
  }
  size_t gpos = blob.find("\"golden\"");
  if (gpos != std::string::npos) {
    size_t start = blob.find('{', gpos);
    int depth = 0;
    size_t end = start;
    for (size_t i = start; i < blob.size(); ++i) {
      if (blob[i] == '{') {
        ++depth;
      } else if (blob[i] == '}') {
        --depth;
        if (depth == 0) {
          end = i;
          break;
        }
      }
    }
    row.golden = parse_golden(blob.substr(start, end - start + 1));
  }
  return row;
}

std::string extract_array_body(const std::string& blob, const std::string& key) {
  const std::string needle = "\"" + key + "\"";
  const size_t key_pos = blob.find(needle);
  if (key_pos == std::string::npos) {
    return "";
  }
  const size_t open = blob.find('[', key_pos);
  if (open == std::string::npos) {
    return "";
  }
  int depth = 0;
  for (size_t i = open; i < blob.size(); ++i) {
    if (blob[i] == '[') {
      ++depth;
    } else if (blob[i] == ']') {
      --depth;
      if (depth == 0) {
        return blob.substr(open + 1, i - open - 1);
      }
    }
  }
  return "";
}

}  // namespace

ManifestDoc load_manifest(const std::string& path) {
  const std::string blob = read_file(path);
  ManifestDoc doc;
  doc.schema_tag = extract_string(blob, "schema_tag");
  const std::string cases_body = extract_array_body(blob, "cases");
  if (cases_body.empty()) {
    return doc;
  }
  for (const auto& part : split_objects(cases_body)) {
    doc.cases.push_back(parse_case(part));
  }
  return doc;
}

void attach_regression_ci(ManifestDoc& doc, const std::string& path) {
  const std::string blob = read_file(path);
  const std::string cases_body = extract_array_body(blob, "cases");
  if (cases_body.empty()) {
    return;
  }
  for (const auto& part : split_objects(cases_body)) {
    const std::string id = extract_string(part, "id");
    GoldenRow golden;
    const size_t gpos = part.find("\"probe_row\"");
    if (gpos != std::string::npos) {
      const size_t start = part.find('{', gpos);
      int depth = 0;
      size_t end = start;
      for (size_t i = start; i < part.size(); ++i) {
        if (part[i] == '{') {
          ++depth;
        } else if (part[i] == '}') {
          --depth;
          if (depth == 0) {
            end = i;
            break;
          }
        }
      }
      golden = parse_golden(part.substr(start, end - start + 1));
    }
    for (auto& row : doc.cases) {
      if (row.id == id) {
        row.golden = golden;
        break;
      }
    }
  }
}

ProbeBundle load_probe_bundle(const std::string& path) {
  const std::string blob = read_file(path);
  ProbeBundle doc;
  doc.schema_tag = extract_string(blob, "schema_tag");
  const std::string cases_body = extract_array_body(blob, "cases");
  if (cases_body.empty()) {
    return doc;
  }
  for (const auto& part : split_objects(cases_body)) {
    ProbeCaseRow row;
    row.id = extract_string(part, "id");
    row.video_streams = extract_int(part, "video_streams");
    row.audio_streams = extract_int(part, "audio_streams");
    row.codec_video = extract_string(part, "codec_video");
    row.codec_audio = extract_string(part, "codec_audio");
    row.width = extract_int(part, "width");
    row.height = extract_int(part, "height");
    row.duration_sec = extract_double(part, "duration_sec");
    row.sample_rate = extract_int(part, "sample_rate");
    row.frame_hashes = extract_string_array(part, "frame_hashes");
    doc.cases.push_back(row);
  }
  return doc;
}

void write_synth_manifest(const std::string& path, const SynthManifest& doc) {
  std::ofstream out(path);
  out << "{\n  \"schema_tag\": \"" << doc.schema_tag << "\",\n  \"cases\": [\n";
  for (size_t i = 0; i < doc.cases.size(); ++i) {
    const auto& c = doc.cases[i];
    out << "    {\"id\": \"" << c.id << "\", \"video_digest\": \"" << c.video_digest
        << "\", \"audio_digest\": \"" << c.audio_digest << "\", \"width\": " << c.width
        << ", \"height\": " << c.height << ", \"audio_samples\": " << c.audio_samples
        << "}";
    if (i + 1 < doc.cases.size()) {
      out << ",";
    }
    out << "\n";
  }
  out << "  ]\n}\n";
}

void write_probe_bundle(const std::string& path, const ProbeBundle& doc) {
  std::ofstream out(path);
  out << "{\n  \"schema_tag\": \"" << doc.schema_tag << "\",\n  \"cases\": [\n";
  for (size_t i = 0; i < doc.cases.size(); ++i) {
    const auto& c = doc.cases[i];
    auto esc = [](const std::string& s) {
      std::string o;
      for (char ch : s) {
        if (ch == '"' || ch == '\\') {
          o.push_back('\\');
        }
        if (static_cast<unsigned char>(ch) >= 0x20) {
          o.push_back(ch);
        }
      }
      return o;
    };
    out << "    {\"id\": \"" << c.id << "\", \"video_streams\": " << c.video_streams
        << ", \"audio_streams\": " << c.audio_streams << ", \"codec_video\": \""
        << c.codec_video << "\", \"codec_audio\": \"" << c.codec_audio
        << "\", \"width\": " << c.width << ", \"height\": " << c.height
        << ", \"duration_sec\": " << c.duration_sec << ", \"sample_rate\": "
        << c.sample_rate << ", \"frame_hashes\": [";
    for (size_t j = 0; j < c.frame_hashes.size(); ++j) {
      out << "\"" << esc(c.frame_hashes[j]) << "\"";
      if (j + 1 < c.frame_hashes.size()) {
        out << ", ";
      }
    }
    out << "]}";
    if (i + 1 < doc.cases.size()) {
      out << ",";
    }
    out << "\n";
  }
  out << "  ]\n}\n";
}

void write_regression_report(const std::string& path, const RegressionReport& doc) {
  std::ofstream out(path);
  out << "{\n  \"schema_tag\": \"" << doc.schema_tag << "\",\n  \"cases\": [\n";
  for (size_t i = 0; i < doc.cases.size(); ++i) {
    const auto& c = doc.cases[i];
    out << "    {\"id\": \"" << c.id << "\", \"status\": \"" << c.status
        << "\", \"failures\": [";
    for (size_t j = 0; j < c.failures.size(); ++j) {
      const auto& f = c.failures[j];
      out << "{\"field\": \"" << f.field << "\", \"expected\": \"" << f.expected
          << "\", \"actual\": \"" << f.actual << "\"}";
      if (j + 1 < c.failures.size()) {
        out << ", ";
      }
    }
    out << "]}";
    if (i + 1 < doc.cases.size()) {
      out << ",";
    }
    out << "\n";
  }
  out << "  ]\n}\n";
}

}  // namespace bridge
