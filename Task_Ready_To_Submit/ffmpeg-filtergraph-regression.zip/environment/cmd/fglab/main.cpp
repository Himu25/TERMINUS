#include <iostream>
#include <string>

#include "bridge/json_util.h"
#include "flux/op_c.h"
#include "lane/op_b.h"
#include "ring/op_a.h"

namespace {

int usage() {
  std::cerr << "usage: fglab <synth|probe|regress>\n";
  return 2;
}

}  // namespace

int main(int argc, char** argv) {
  if (argc < 2) {
    return usage();
  }
  const std::string cmd = argv[1];
  const std::string manifest = "/app/cases/manifest.json";
  const std::string synth_root = "/app/work/synth";
  if (cmd == "synth") {
    ring::op_a(manifest, synth_root);
    return 0;
  }
  if (cmd == "probe") {
    lane::op_b(manifest, synth_root);
    return 0;
  }
  if (cmd == "regress") {
    const bridge::ProbeBundle bundle =
        bridge::load_probe_bundle("/app/output/probe_bundle.json");
    flux::op_c(manifest, bundle);
    return 0;
  }
  return usage();
}
