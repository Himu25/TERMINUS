#include "ring/op_a.h"

namespace ring {

int warmup_rows() { return 3; }

}  // namespace ring
