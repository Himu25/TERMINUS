#include "ring/op_a.h"

#include <filesystem>
#include <fstream>
#include <iomanip>
#include <sstream>

#include "bridge/json_util.h"

namespace ring {
namespace {

std::string digest_bytes(const std::vector<uint8_t>& data) {
  // lightweight deterministic fingerprint for raw payloads (FNV-1a 64)
  uint64_t h = 1469598103934665603ULL;
  for (uint8_t b : data) {
    h ^= b;
    h *= 1099511628211ULL;
  }
  std::ostringstream ss;
  ss << std::hex << std::setw(16) << std::setfill('0') << h;
  return ss.str();
}

void write_video_raw(const bridge::CaseRow& row, const std::string& path, size_t index) {
  const int w = row.video.width;
  const int h = row.video.height;
  const uint32_t mixed = row.seed ^ static_cast<uint32_t>(index + 1);
  std::vector<uint8_t> y(w * h);
  std::vector<uint8_t> u(w);
  std::vector<uint8_t> v(w);
  for (int yrow = 0; yrow < h; ++yrow) {
    for (int x = 0; x < w; ++x) {
      y[yrow * w + x] = static_cast<uint8_t>((mixed + x + yrow) % 251);
    }
  }
  for (int i = 0; i < w; ++i) {
    u[i] = static_cast<uint8_t>((mixed + i) % 251);
    v[i] = static_cast<uint8_t>((mixed + i * 3) % 251);
  }
  std::vector<uint8_t> blob;
  blob.insert(blob.end(), y.begin(), y.end());
  blob.insert(blob.end(), u.begin(), u.end());
  blob.insert(blob.end(), v.begin(), v.end());
  std::ofstream out(path, std::ios::binary);
  out.write(reinterpret_cast<const char*>(blob.data()),
            static_cast<std::streamsize>(blob.size()));
}

void write_audio_raw(const bridge::CaseRow& row, const std::string& path, size_t index) {
  const int samples = row.audio.samples / 2;
  const uint32_t mixed = row.seed ^ static_cast<uint32_t>(index + 1);
  std::vector<uint8_t> blob(samples * 2);
  for (int i = 0; i < samples; ++i) {
    int16_t sample = static_cast<int16_t>((mixed * (i + 1)) % 20000);
    blob[2 * i] = static_cast<uint8_t>(sample & 0xff);
    blob[2 * i + 1] = static_cast<uint8_t>((sample >> 8) & 0xff);
  }
  std::ofstream out(path, std::ios::binary);
  out.write(reinterpret_cast<const char*>(blob.data()),
            static_cast<std::streamsize>(blob.size()));
}

}  // namespace

bridge::SynthManifest op_a(const std::string& manifest_path,
                           const std::string& work_root) {
  const bridge::ManifestDoc doc = bridge::load_manifest(manifest_path);
  bridge::SynthManifest out;
  out.schema_tag = "tb3-ffgraph-regression-00";
  std::filesystem::create_directories(work_root);
  size_t idx = 0;
  for (const auto& row : doc.cases) {
    const auto case_dir = std::filesystem::path(work_root) / row.id;
    std::filesystem::create_directories(case_dir);
    bridge::SynthCaseRow synth;
    synth.id = row.id;
    synth.width = row.video.width;
    synth.height = row.video.height;
    synth.audio_samples = row.audio.samples;
    if (row.has_video) {
      const auto vpath = (case_dir / "video.raw").string();
      write_video_raw(row, vpath, idx);
      std::ifstream in(vpath, std::ios::binary);
      std::vector<uint8_t> bytes((std::istreambuf_iterator<char>(in)),
                                 std::istreambuf_iterator<char>());
      synth.video_digest = digest_bytes(bytes);
    } else {
      synth.video_digest = "0000000000000000";
    }
    if (row.has_audio) {
      const auto apath = (case_dir / "audio.raw").string();
      write_audio_raw(row, apath, idx);
      std::ifstream in(apath, std::ios::binary);
      std::vector<uint8_t> bytes((std::istreambuf_iterator<char>(in)),
                                 std::istreambuf_iterator<char>());
      synth.audio_digest = digest_bytes(bytes);
    } else {
      synth.audio_digest = "0000000000000000";
    }
    out.cases.push_back(synth);
    ++idx;
  }
  bridge::write_synth_manifest("/app/output/synth_manifest.json", out);
  return out;
}

}  // namespace ring
