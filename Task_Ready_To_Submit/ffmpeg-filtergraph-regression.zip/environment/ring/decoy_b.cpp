#include <cstdint>
#include <vector>

namespace ring {

uint64_t fold_buffer(const std::vector<uint8_t>& buf) {
  uint64_t acc = 0;
  for (uint8_t b : buf) {
    acc = (acc << 3) ^ b;
  }
  return acc;
}

}  // namespace ring
