#pragma once

#include <string>

#include "bridge/types.h"

namespace bridge {

ManifestDoc load_manifest(const std::string& path);
void attach_regression_ci(ManifestDoc& doc, const std::string& path);
ProbeBundle load_probe_bundle(const std::string& path);
void write_synth_manifest(const std::string& path, const SynthManifest& doc);
void write_probe_bundle(const std::string& path, const ProbeBundle& doc);
void write_regression_report(const std::string& path, const RegressionReport& doc);

}  // namespace bridge
