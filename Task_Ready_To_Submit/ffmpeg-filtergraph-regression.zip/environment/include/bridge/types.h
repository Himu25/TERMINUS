#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace bridge {

struct VideoSpec {
  int width = 0;
  int height = 0;
  int fps = 25;
  int frames = 0;
};

struct AudioSpec {
  int rate = 48000;
  int channels = 1;
  int samples = 0;
};

struct GoldenRow {
  int video_streams = 0;
  int audio_streams = 0;
  std::string codec_video;
  std::string codec_audio;
  int width = 0;
  int height = 0;
  double duration_sec = 0.0;
  int sample_rate = 0;
  std::vector<std::string> frame_hashes;
};

struct CaseRow {
  std::string id;
  uint32_t seed = 0;
  VideoSpec video;
  AudioSpec audio;
  std::string filter;
  GoldenRow golden;
  bool has_video = false;
  bool has_audio = false;
};

struct ManifestDoc {
  std::string schema_tag;
  std::vector<CaseRow> cases;
};

struct SynthCaseRow {
  std::string id;
  std::string video_digest;
  std::string audio_digest;
  int width = 0;
  int height = 0;
  int audio_samples = 0;
};

struct SynthManifest {
  std::string schema_tag;
  std::vector<SynthCaseRow> cases;
};

struct ProbeCaseRow {
  std::string id;
  int video_streams = 0;
  int audio_streams = 0;
  std::string codec_video;
  std::string codec_audio;
  int width = 0;
  int height = 0;
  double duration_sec = 0.0;
  int sample_rate = 0;
  std::vector<std::string> frame_hashes;
};

struct ProbeBundle {
  std::string schema_tag;
  std::vector<ProbeCaseRow> cases;
};

struct FailureRow {
  std::string field;
  std::string expected;
  std::string actual;
};

struct RegressionCaseRow {
  std::string id;
  std::string status;
  std::vector<FailureRow> failures;
};

struct RegressionReport {
  std::string schema_tag;
  std::vector<RegressionCaseRow> cases;
};

}  // namespace bridge
