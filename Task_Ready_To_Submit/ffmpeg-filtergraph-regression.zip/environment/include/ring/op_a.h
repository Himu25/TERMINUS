#pragma once

#include <string>

#include "bridge/types.h"

namespace ring {

bridge::SynthManifest op_a(const std::string& manifest_path, const std::string& work_root);

}  // namespace ring
