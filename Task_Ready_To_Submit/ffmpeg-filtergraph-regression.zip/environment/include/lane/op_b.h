#pragma once

#include <string>

#include "bridge/types.h"

namespace lane {

bridge::ProbeBundle op_b(const std::string& manifest_path, const std::string& synth_root);

}  // namespace lane
