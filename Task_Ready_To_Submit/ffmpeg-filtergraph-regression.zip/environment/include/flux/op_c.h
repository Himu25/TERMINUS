#pragma once

#include <string>

#include "bridge/types.h"

namespace flux {

bridge::RegressionReport op_c(const std::string& manifest_path,
                              const bridge::ProbeBundle& bundle);

}  // namespace flux
