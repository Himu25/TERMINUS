#!/bin/bash
set -euo pipefail
cd /app

sed -i 's/index + 1)/index)/g' ring/op_a.cpp
sed -i 's/std::vector<uint8_t> u(w);/std::vector<uint8_t> u(w * h \/ 4);/' ring/op_a.cpp
sed -i 's/std::vector<uint8_t> v(w);/std::vector<uint8_t> v(w * h \/ 4);/' ring/op_a.cpp
sed -i 's/for (int i = 0; i < w; ++i) {/for (int i = 0; i < w * h \/ 4; ++i) {/' ring/op_a.cpp
sed -i 's/const int samples = row.audio.samples \/ 2;/const int samples = row.audio.samples;/' ring/op_a.cpp
sed -i 's/tb3-ffgraph-regression-00/tb3-ffgraph-regression-01/' ring/op_a.cpp

make -C /app fglab
mkdir -p /app/output /app/work/synth
/app/bin/fglab synth
