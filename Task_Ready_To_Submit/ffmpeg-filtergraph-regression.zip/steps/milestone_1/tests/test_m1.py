"""Milestone 1 — synthetic payload manifest."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

OUT = Path("/app/output/synth_manifest.json")
SCHEMA = "tb3-ffgraph-regression-01"
CASE_IDS = ["aud_mix", "av_pair", "vid_scale"]
DIGESTS = {
    "aud_mix": ("0000000000000000", "48bb4ca248547b9e"),
    "av_pair": ("144380d1d2e20055", "6d6345c905e4cb25"),
    "vid_scale": ("21b62250d627b0d7", "0000000000000000"),
}
AV_PAIR_WIDTH = 48
AV_PAIR_HEIGHT = 36
AUD_MIX_SAMPLES = 2400


@pytest.fixture(scope="class")
def manifest() -> dict:
    assert OUT.is_file(), "run fglab synth first"
    return json.loads(OUT.read_text())


class TestMilestone1:
    def test_schema_tag(self, manifest: dict) -> None:
        """Synth manifest uses the contract schema tag."""
        assert manifest["schema_tag"] == SCHEMA

    def test_case_inventory(self, manifest: dict) -> None:
        """All three manifest case ids are present in sorted order."""
        assert [c["id"] for c in manifest["cases"]] == CASE_IDS

    def test_video_digest_vid_scale(self, manifest: dict) -> None:
        """vid_scale raw video digest matches the deterministic payload."""
        row = next(c for c in manifest["cases"] if c["id"] == "vid_scale")
        assert row["video_digest"] == DIGESTS["vid_scale"][0]

    def test_video_digest_av_pair(self, manifest: dict) -> None:
        """av_pair raw video digest matches the deterministic payload."""
        row = next(c for c in manifest["cases"] if c["id"] == "av_pair")
        assert row["video_digest"] == DIGESTS["av_pair"][0]

    def test_audio_digest_aud_mix(self, manifest: dict) -> None:
        """aud_mix raw audio digest matches the deterministic payload."""
        row = next(c for c in manifest["cases"] if c["id"] == "aud_mix")
        assert row["audio_digest"] == DIGESTS["aud_mix"][1]

    def test_audio_digest_av_pair(self, manifest: dict) -> None:
        """av_pair raw audio digest matches the deterministic payload."""
        row = next(c for c in manifest["cases"] if c["id"] == "av_pair")
        assert row["audio_digest"] == DIGESTS["av_pair"][1]

    def test_dimensions_av_pair(self, manifest: dict) -> None:
        """av_pair carries the manifest video geometry."""
        row = next(c for c in manifest["cases"] if c["id"] == "av_pair")
        assert row["width"] == AV_PAIR_WIDTH
        assert row["height"] == AV_PAIR_HEIGHT

    def test_audio_samples_aud_mix(self, manifest: dict) -> None:
        """aud_mix lists the full sample count from the manifest."""
        row = next(c for c in manifest["cases"] if c["id"] == "aud_mix")
        assert row["audio_samples"] == AUD_MIX_SAMPLES

    def test_fglab_binary_runs(self) -> None:
        """CLI binary exists after rebuild."""
        assert Path("/app/bin/fglab").is_file()
