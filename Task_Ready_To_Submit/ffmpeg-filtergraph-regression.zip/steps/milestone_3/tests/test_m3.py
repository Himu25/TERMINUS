"""Milestone 3 — regression report against CI contract rows."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import pytest

AGENT_BIN = Path("/app/bin/fglab")
VERIFIER_BIN = Path("/tests/vf_glab")
OUT = Path("/app/output/regression_report.json")
PROBE = Path("/app/output/probe_bundle.json")
REGRESSION_CI = Path("/app/cases/regression_ci.json")
REGRESSION_CI_GOLDEN = Path("/tests/fixtures/regression_ci.json")
SCHEMA = "tb3-ffgraph-regression-01"
CASE_IDS = ["aud_mix", "av_pair", "vid_scale"]


@pytest.fixture(scope="session", autouse=True)
def seed_regression_ci_contract() -> None:
    """Publish CI golden probe rows; the workspace image ships ids only."""
    assert REGRESSION_CI_GOLDEN.is_file(), "verifier fixture missing"
    shutil.copy2(REGRESSION_CI_GOLDEN, REGRESSION_CI)


def _verifier_fglab() -> Path:
    assert AGENT_BIN.is_file(), "fglab binary missing"
    shutil.copy2(AGENT_BIN, VERIFIER_BIN)
    return VERIFIER_BIN


def _run_regress() -> dict:
    assert PROBE.is_file(), "run fglab probe first"
    result = subprocess.run(
        [str(_verifier_fglab()), "regress"],
        capture_output=True,
        text=True,
        timeout=120,
        check=False,
    )
    assert result.returncode == 0, f"fglab regress failed: {result.stderr}"
    assert OUT.is_file(), "regress did not produce output"
    return json.loads(OUT.read_text())


@pytest.fixture(scope="class")
def report() -> dict:
    """Re-run regress after CI publishes probe_row rows (do not reuse a stale report)."""
    return _run_regress()


class TestMilestone3:
    def test_regression_schema(self, report: dict) -> None:
        """Regression report uses the contract schema tag."""
        assert report["schema_tag"] == SCHEMA

    def test_all_cases_pass(self, report: dict) -> None:
        """Every manifest case reports pass."""
        by_id = {c["id"]: c for c in report["cases"]}
        for case_id in CASE_IDS:
            assert by_id[case_id]["status"] == "pass"

    def test_zero_failures(self, report: dict) -> None:
        """No failure rows remain."""
        assert all(c["failures"] == [] for c in report["cases"])

    def test_case_ordering(self, report: dict) -> None:
        """Case rows stay in manifest order."""
        assert [c["id"] for c in report["cases"]] == CASE_IDS

    def test_prior_probe_intact(self) -> None:
        """Probe bundle still matches schema after regress."""
        bundle = json.loads(PROBE.read_text())
        assert bundle["schema_tag"] == SCHEMA

    def test_fglab_binary_present(self) -> None:
        """CLI binary remains available."""
        assert AGENT_BIN.is_file()

    def test_regress_ignores_first_frame_hash(self) -> None:
        """Diff pass skips frame_hashes[0] when comparing digests."""
        probe_backup = PROBE.read_text()
        report_backup = OUT.read_text() if OUT.is_file() else None
        try:
            bundle = json.loads(probe_backup)
            for row in bundle["cases"]:
                if row["id"] in ("av_pair", "vid_scale") and row.get("frame_hashes"):
                    row["frame_hashes"][0] = "f" * 64
            PROBE.write_text(json.dumps(bundle))
            report = _run_regress()
            by_id = {c["id"]: c for c in report["cases"]}
            for case_id in ("av_pair", "vid_scale"):
                assert by_id[case_id]["status"] == "pass"
        finally:
            PROBE.write_text(probe_backup)
            if report_backup is not None:
                OUT.write_text(report_backup)

    def test_truncated_digest_comparison(self) -> None:
        """Frame-hash diff compares only the first 16 hex characters."""
        probe_row_backup = REGRESSION_CI.read_text()
        probe_backup = PROBE.read_text()
        report_backup = OUT.read_text() if OUT.is_file() else None
        try:
            probe_row_doc = json.loads(probe_row_backup)
            probe = json.loads(probe_backup)
            av_probe_row = next(c for c in probe_row_doc["cases"] if c["id"] == "av_pair")
            full = av_probe_row["probe_row"]["frame_hashes"][0]
            prefix = full[:16]
            alt_probe_row = prefix + ("0" * (len(full) - 16))
            assert alt_probe_row != full
            av_probe_row["probe_row"]["frame_hashes"].append(alt_probe_row)

            av_probe = next(c for c in probe["cases"] if c["id"] == "av_pair")
            av_probe["frame_hashes"].append(prefix + ("f" * (len(full) - 16)))

            REGRESSION_CI.write_text(json.dumps(probe_row_doc))
            PROBE.write_text(json.dumps(probe))
            report = _run_regress()
            row = next(c for c in report["cases"] if c["id"] == "av_pair")
            assert row["status"] == "pass"
        finally:
            REGRESSION_CI.write_text(probe_row_backup)
            PROBE.write_text(probe_backup)
            if report_backup is not None:
                OUT.write_text(report_backup)

    def test_failure_rows_include_field_names(self) -> None:
        """Failure rows name the mismatched field and carry expected/actual values."""
        probe_backup = PROBE.read_text()
        report_backup = OUT.read_text() if OUT.is_file() else None
        try:
            probe_row_doc = json.loads(REGRESSION_CI.read_text())
            bundle = json.loads(probe_backup)
            aud = next(c for c in bundle["cases"] if c["id"] == "aud_mix")
            aud_probe_row = next(
                c for c in probe_row_doc["cases"] if c["id"] == "aud_mix"
            )["probe_row"]
            aud["video_streams"] = 99
            PROBE.write_text(json.dumps(bundle))
            report = _run_regress()
            row = next(c for c in report["cases"] if c["id"] == "aud_mix")
            assert row["status"] == "fail"
            assert row["failures"]
            fail = row["failures"][0]
            assert fail["field"] == "video_streams"
            assert fail["expected"] == str(aud_probe_row["video_streams"])
            assert fail["actual"] == str(aud["video_streams"])
        finally:
            PROBE.write_text(probe_backup)
            if report_backup is not None:
                OUT.write_text(report_backup)

    def test_frame_hash_mismatch_causes_failure(self) -> None:
        """Truncated frame-hash prefix mismatches produce a failure row."""
        probe_row_backup = REGRESSION_CI.read_text()
        probe_backup = PROBE.read_text()
        report_backup = OUT.read_text() if OUT.is_file() else None
        try:
            probe_row_doc = json.loads(probe_row_backup)
            bundle = json.loads(probe_backup)
            vid_probe_row = next(c for c in probe_row_doc["cases"] if c["id"] == "vid_scale")
            full = vid_probe_row["probe_row"]["frame_hashes"][0]
            vid_probe_row["probe_row"]["frame_hashes"].append(full)

            vid_probe = next(c for c in bundle["cases"] if c["id"] == "vid_scale")
            vid_probe["frame_hashes"].append("0" * 16 + ("a" * 48))

            REGRESSION_CI.write_text(json.dumps(probe_row_doc))
            PROBE.write_text(json.dumps(bundle))
            report = _run_regress()
            row = next(c for c in report["cases"] if c["id"] == "vid_scale")
            assert row["status"] == "fail"
            assert row["failures"]
            assert any("frame_hashes" in f["field"] for f in row["failures"])
        finally:
            REGRESSION_CI.write_text(probe_row_backup)
            PROBE.write_text(probe_backup)
            if report_backup is not None:
                OUT.write_text(report_backup)

    def test_width_mismatch_detected(self) -> None:
        """Geometry mismatches emit field, expected, and actual values."""
        probe_backup = PROBE.read_text()
        report_backup = OUT.read_text() if OUT.is_file() else None
        try:
            probe_row_doc = json.loads(REGRESSION_CI.read_text())
            bundle = json.loads(probe_backup)
            vid = next(c for c in bundle["cases"] if c["id"] == "vid_scale")
            vid_probe_row = next(
                c for c in probe_row_doc["cases"] if c["id"] == "vid_scale"
            )["probe_row"]
            vid["width"] = 999
            PROBE.write_text(json.dumps(bundle))
            report = _run_regress()
            row = next(c for c in report["cases"] if c["id"] == "vid_scale")
            assert row["status"] == "fail"
            fail = row["failures"][0]
            assert fail["field"] == "width"
            assert fail["expected"] == str(vid_probe_row["width"])
            assert fail["actual"] == str(vid["width"])
        finally:
            PROBE.write_text(probe_backup)
            if report_backup is not None:
                OUT.write_text(report_backup)
