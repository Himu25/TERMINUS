#!/bin/bash
set -euo pipefail
cd /app

sed -i 's/const bridge::ManifestDoc doc = bridge::load_manifest(manifest_path);/bridge::ManifestDoc doc = bridge::load_manifest(manifest_path);\n  bridge::attach_regression_ci(doc, "\/app\/cases\/regression_ci.json");/' flux/op_c.cpp
sed -i 's/for (size_t i = 0; i < g.frame_hashes.size(); ++i)/for (size_t i = 1; i < g.frame_hashes.size(); ++i)/' flux/op_c.cpp
sed -i 's/const std::string\& expected = g.frame_hashes\[i\];/const std::string expected = short_hash(g.frame_hashes[i]);/' flux/op_c.cpp
sed -i 's/actual = probe->frame_hashes\[i\];/actual = short_hash(probe->frame_hashes[i]);/' flux/op_c.cpp

sed -i '/probe->video_streams != g.video_streams/,/push_fail(case_row.failures, "", e.str(), a.str());/{
  s/push_fail(case_row.failures, "", e.str(), a.str());/push_fail(case_row.failures, "video_streams", e.str(), a.str());/
}' flux/op_c.cpp
sed -i '/probe->audio_streams != g.audio_streams/,/push_fail(case_row.failures, "", e.str(), a.str());/{
  s/push_fail(case_row.failures, "", e.str(), a.str());/push_fail(case_row.failures, "audio_streams", e.str(), a.str());/
}' flux/op_c.cpp
sed -i 's/push_fail(case_row.failures, "", g.codec_video, probe->codec_video);/push_fail(case_row.failures, "codec_video", g.codec_video, probe->codec_video);/' flux/op_c.cpp
sed -i 's/push_fail(case_row.failures, "", g.codec_audio, probe->codec_audio);/push_fail(case_row.failures, "codec_audio", g.codec_audio, probe->codec_audio);/' flux/op_c.cpp
sed -i '/g.width > 0 && probe->width != g.width/,/push_fail(case_row.failures, "", e.str(), a.str());/{
  s/push_fail(case_row.failures, "", e.str(), a.str());/push_fail(case_row.failures, "width", e.str(), a.str());/
}' flux/op_c.cpp
sed -i '/g.height > 0 && probe->height != g.height/,/push_fail(case_row.failures, "", e.str(), a.str());/{
  s/push_fail(case_row.failures, "", e.str(), a.str());/push_fail(case_row.failures, "height", e.str(), a.str());/
}' flux/op_c.cpp
sed -i '/g.duration_sec > 0.0/,/push_fail(case_row.failures, "", e.str(), a.str());/{
  s/push_fail(case_row.failures, "", e.str(), a.str());/push_fail(case_row.failures, "duration_sec", e.str(), a.str());/
}' flux/op_c.cpp
sed -i '/g.sample_rate > 0 && probe->sample_rate != g.sample_rate/,/push_fail(case_row.failures, "", e.str(), a.str());/{
  s/push_fail(case_row.failures, "", e.str(), a.str());/push_fail(case_row.failures, "sample_rate", e.str(), a.str());/
}' flux/op_c.cpp
sed -i 's/push_fail(case_row.failures, "", expected, actual);/push_fail(case_row.failures, label.str(), expected, actual);/' flux/op_c.cpp

make -C /app fglab
/app/bin/fglab regress
