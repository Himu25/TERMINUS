Run the regress pass to diff `/app/output/probe_bundle.json` against per-case `probe_row` baselines in `/app/cases/regression_ci.json` and write `/app/output/regression_report.json`.

The probe bundle from the prior step must satisfy the probe contract. `/app/cases/regression_ci.json` in the workspace ships case ids only — do not paste probe output or golden `probe_row` objects into that file. Published CI baselines arrive with full `probe_row` payloads; regress must load them at runtime via `attach_regression_ci` (see the Regression CI section of `/app/docs/regression_contract.md`) rather than hardcoding expected values in source.

Per the Regression report section of the same contract, frame-hash checks compare only the first 16 hex characters and start at index 1 (skip `frame_hashes[0]`). The shipped regress code still compares full digests from index 0, never calls `attach_regression_ci`, and leaves `field` empty on failure rows — wire up CI loading, implement the comparison rules, and populate `field`, `expected`, and `actual` on every failure.

Rebuild with `make -C /app fglab`, run probe then regress, and signal completion when the regression report matches the contract (schema_tag, per-case status, failures with field, expected, actual).
