"""Milestone 2 — filtergraph probe bundle."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

MANIFEST = Path("/app/cases/manifest.json")
REGRESSION_CI = Path("/app/cases/regression_ci.json")
OUT = Path("/app/output/probe_bundle.json")
SYNTH = Path("/app/output/synth_manifest.json")
SCHEMA = "tb3-ffgraph-regression-01"

# Contract probe rows (embedded in verifier; not read from manifest.json).
CONTRACT_PROBE = {
    "aud_mix": {
        "video_streams": 0,
        "audio_streams": 1,
        "codec_audio": "vorbis",
        "duration_sec": 0.053,
        "sample_rate": 44100,
        "frame_hashes": [],
    },
    "av_pair": {
        "video_streams": 1,
        "audio_streams": 1,
        "codec_video": "h264",
        "codec_audio": "vorbis",
        "width": 40,
        "height": 30,
        "duration_sec": 0.042,
        "sample_rate": 44100,
        "frame_hashes": [
            "a60cf64d1f187c7780822750d154e289c9275a9ae73e7f928f549207149dafb3"
        ],
    },
    "vid_scale": {
        "video_streams": 1,
        "audio_streams": 0,
        "codec_video": "h264",
        "width": 32,
        "height": 24,
        "duration_sec": 0.04,
        "frame_hashes": [
            "5ad476e9fd705bce1fdab13e122c00a68e2dba79864f398bcabc44c035ecfaa1"
        ],
    },
}


@pytest.fixture(scope="class")
def bundle() -> dict:
    assert SYNTH.is_file(), "run fglab synth first"
    assert OUT.is_file(), "run fglab probe first"
    return json.loads(OUT.read_text())


class TestMilestone2:
    def test_probe_schema(self, bundle: dict) -> None:
        """Probe bundle uses the contract schema tag."""
        assert bundle["schema_tag"] == SCHEMA

    def test_stream_counts(self, bundle: dict) -> None:
        """Per-case stream counts match contract golden rows."""
        by_id = {c["id"]: c for c in bundle["cases"]}
        for case_id in ("aud_mix", "av_pair", "vid_scale"):
            g = CONTRACT_PROBE[case_id]
            row = by_id[case_id]
            assert row["video_streams"] == g["video_streams"]
            assert row["audio_streams"] == g["audio_streams"]

    def test_codec_names(self, bundle: dict) -> None:
        """Codec names align with golden expectations."""
        by_id = {c["id"]: c for c in bundle["cases"]}
        assert by_id["aud_mix"]["codec_audio"] == CONTRACT_PROBE["aud_mix"]["codec_audio"]
        assert by_id["av_pair"]["codec_video"] == CONTRACT_PROBE["av_pair"]["codec_video"]
        assert by_id["vid_scale"]["codec_video"] == CONTRACT_PROBE["vid_scale"]["codec_video"]

    def test_duration_values(self, bundle: dict) -> None:
        """Reported durations match golden seconds."""
        by_id = {c["id"]: c for c in bundle["cases"]}
        for case_id in ("aud_mix", "av_pair", "vid_scale"):
            g = CONTRACT_PROBE[case_id]
            assert by_id[case_id]["duration_sec"] == g["duration_sec"]

    def test_geometry_and_rate(self, bundle: dict) -> None:
        """Scaled geometry and audio sample rate match golden rows."""
        av = next(c for c in bundle["cases"] if c["id"] == "av_pair")
        g = CONTRACT_PROBE["av_pair"]
        assert av["width"] == g["width"]
        assert av["height"] == g["height"]
        assert av["sample_rate"] == g["sample_rate"]
        aud = next(c for c in bundle["cases"] if c["id"] == "aud_mix")
        assert aud["sample_rate"] == CONTRACT_PROBE["aud_mix"]["sample_rate"]

    def test_frame_hash_count(self, bundle: dict) -> None:
        """Video cases expose one filtered-frame digest."""
        for case_id in ("av_pair", "vid_scale"):
            row = next(c for c in bundle["cases"] if c["id"] == case_id)
            g = CONTRACT_PROBE[case_id]
            assert len(row["frame_hashes"]) == len(g["frame_hashes"])
            assert row["frame_hashes"][0] == g["frame_hashes"][0]

    def test_synth_manifest_still_valid(self) -> None:
        """Prior synth manifest remains on-contract."""
        synth = json.loads(SYNTH.read_text())
        assert synth["schema_tag"] == SCHEMA

    def test_case_fixtures_lack_probe_contract_rows(self) -> None:
        """Bundled case fixtures do not ship probe golden rows for copy shortcuts."""
        for fixture_path in (MANIFEST, REGRESSION_CI):
            doc = json.loads(fixture_path.read_text())
            for row in doc["cases"]:
                assert "probe_row" not in row
