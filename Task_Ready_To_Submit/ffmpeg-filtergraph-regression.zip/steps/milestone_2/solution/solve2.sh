#!/bin/bash
set -euo pipefail
cd /app

cat > lane/op_b.cpp <<'LANE_EOF'
#include "lane/op_b.h"

#include <array>
#include <cstdio>
#include <filesystem>
#include <memory>
#include <sstream>
#include <vector>

#include "bridge/json_util.h"

namespace lane {
namespace {

std::string run_capture(const std::string& cmd) {
  std::array<char, 4096> buf{};
  std::string out;
  std::unique_ptr<FILE, decltype(&pclose)> pipe(popen(cmd.c_str(), "r"), pclose);
  if (!pipe) {
    return out;
  }
  while (fgets(buf.data(), static_cast<int>(buf.size()), pipe.get()) != nullptr) {
    out += buf.data();
  }
  while (!out.empty() && (out.back() == '\n' || out.back() == '\r' || out.back() == ' ')) {
    out.pop_back();
  }
  return out;
}

std::vector<std::string> frame_digests_pipe(const bridge::CaseRow& row,
                                            const std::string& synth_root,
                                            int out_w, int out_h) {
  std::vector<std::string> hashes;
  if (!row.has_video || row.video.frames <= 0 || out_w <= 0 || out_h <= 0) {
    return hashes;
  }
  const auto base = std::filesystem::path(synth_root) / row.id;
  std::ostringstream cmd;
  cmd << "ffmpeg -hide_banner -loglevel error ";
  if (row.has_video) {
    cmd << "-f rawvideo -pix_fmt yuv420p -s " << row.video.width << "x"
        << row.video.height << " -r " << row.video.fps << " -i "
        << (base / "video.raw").string() << " ";
  }
  if (row.has_audio) {
    cmd << "-f s16le -ar " << row.audio.rate << " -ac " << row.audio.channels
        << " -i " << (base / "audio.raw").string() << " ";
  }
  (void)cmd;
  for (int i = 0; i < row.video.frames; ++i) {
    std::ostringstream one;
    one << "ffmpeg -hide_banner -loglevel error ";
    if (row.has_video) {
      one << "-f rawvideo -pix_fmt yuv420p -s " << row.video.width << "x"
          << row.video.height << " -r " << row.video.fps << " -i "
          << (base / "video.raw").string() << " ";
    }
    if (row.has_audio) {
      one << "-f s16le -ar " << row.audio.rate << " -ac " << row.audio.channels
          << " -i " << (base / "audio.raw").string() << " ";
    }
    one << "-vf \"" << row.filter << ",select='eq(n\\," << i
        << ")'\" -vsync 0 -frames:v 1 -f rawvideo -pix_fmt rgb24 - 2>/dev/null | "
           "sha256sum | awk '{print $1}'";
    hashes.push_back(run_capture(one.str()));
  }
  return hashes;
}

bridge::ProbeCaseRow probe_case(const bridge::CaseRow& row,
                                const std::string& synth_root) {
  const auto base = std::filesystem::path(synth_root) / row.id;
  std::ostringstream graph;
  graph << "ffmpeg -hide_banner -loglevel error -y ";
  if (row.has_video) {
    graph << "-f rawvideo -pix_fmt yuv420p -s " << row.video.width << "x"
          << row.video.height << " -r " << row.video.fps << " -i "
          << (base / "video.raw").string() << " ";
  }
  if (row.has_audio) {
    graph << "-f s16le -ar " << row.audio.rate << " -ac " << row.audio.channels
          << " -i " << (base / "audio.raw").string() << " ";
  }
  const auto out_path = (base / "out.mkv").string();
  if (row.has_video && row.has_audio) {
    graph << "-vf \"" << row.filter << "\" -af \"aresample=44100\" -frames:v "
          << row.video.frames;
  } else if (row.has_video) {
    graph << "-vf \"" << row.filter << "\" -frames:v " << row.video.frames;
  } else if (row.has_audio) {
    graph << "-af \"" << row.filter << "\"";
    graph << " -t " << (static_cast<double>(row.audio.samples) / row.audio.rate);
  }
  graph << " " << out_path;
  run_capture(graph.str());

  bridge::ProbeCaseRow out;
  out.id = row.id;
  const int out_w = row.video.width;
  const int out_h = row.video.height;

  const std::string vcount = run_capture(
      "ffprobe -v error -select_streams v -show_entries stream=index -of "
      "csv=p=0 " +
      out_path + " 2>/dev/null | wc -l");
  const std::string acount = run_capture(
      "ffprobe -v error -select_streams a -show_entries stream=index -of "
      "csv=p=0 " +
      out_path + " 2>/dev/null | wc -l");
  try {
    out.video_streams = vcount.empty() ? 0 : std::stoi(vcount);
    out.audio_streams = acount.empty() ? 0 : std::stoi(acount);
  } catch (...) {
    out.video_streams = 0;
    out.audio_streams = 0;
  }

  if (out.video_streams > 0) {
    out.codec_video = run_capture(
        "ffprobe -v error -select_streams v:0 -show_entries stream=codec_name "
        "-of default=nw=1:nk=1 " +
        out_path);
    try {
      out.width = std::stoi(run_capture(
          "ffprobe -v error -select_streams v:0 -show_entries stream=width -of "
          "default=nw=1:nk=1 " +
          out_path));
      out.height = std::stoi(run_capture(
          "ffprobe -v error -select_streams v:0 -show_entries stream=height -of "
          "default=nw=1:nk=1 " +
          out_path));
    } catch (...) {
      out.width = 0;
      out.height = 0;
    }
    const std::string dur = run_capture(
        "ffprobe -v error -select_streams v:0 -show_entries stream=duration -of "
        "default=nw=1:nk=1 " +
        out_path);
    if (!dur.empty()) {
      try {
        out.duration_sec = std::stod(dur);
      } catch (...) {
        out.duration_sec = 0.0;
      }
    }
  }
  if (out.audio_streams > 0) {
    out.codec_audio = run_capture(
        "ffprobe -v error -select_streams a:0 -show_entries stream=codec_name "
        "-of default=nw=1:nk=1 " +
        out_path);
    const std::string rate = run_capture(
        "ffprobe -v error -select_streams a:0 -show_entries stream=sample_rate "
        "-of default=nw=1:nk=1 " +
        out_path);
    if (!rate.empty()) {
      try {
        out.sample_rate = std::stoi(rate);
      } catch (...) {
        out.sample_rate = 0;
      }
    }
    if (out.video_streams == 0) {
      std::string dur = run_capture(
          "ffprobe -v error -select_streams a:0 -show_entries stream=duration "
          "-of default=nw=1:nk=1 " +
          out_path);
      if (dur.empty() || dur == "N/A") {
        dur = run_capture(
            "ffprobe -v error -show_entries format=duration -of default=nw=1:nk=1 " +
            out_path);
      }
      if (!dur.empty() && dur != "N/A") {
        try {
          out.duration_sec = std::stod(dur);
        } catch (...) {
          out.duration_sec = 0.0;
        }
      }
    }
  }
  out.frame_hashes = frame_digests_pipe(row, synth_root, out_w, out_h);
  return out;
}

}  // namespace

bridge::ProbeBundle op_b(const std::string& manifest_path,
                         const std::string& synth_root) {
  const bridge::ManifestDoc doc = bridge::load_manifest(manifest_path);
  bridge::ProbeBundle bundle;
  bundle.schema_tag = doc.schema_tag;
  for (const auto& row : doc.cases) {
    bundle.cases.push_back(probe_case(row, synth_root));
  }
  bridge::write_probe_bundle("/app/output/probe_bundle.json", bundle);
  return bundle;
}

}  // namespace lane
LANE_EOF

make -C /app fglab
/app/bin/fglab probe
