With synth payloads present, run the probe pass to build `/app/output/probe_bundle.json` from the bundled filtergraphs.

**The current probe binary does not yet meet the Probe bundle contract** — do not assume it is correct. Today's broken capture path:
- Sets both `video_streams` and `audio_streams` to the container format stream total instead of separate video-only and audio-only counts.
- Stores durations as ffprobe seconds × 1000 instead of seconds.
- When both video and audio exist, still derives timing from the video stream path rather than the audio timing path used for audio-only or A/V cases.
- Builds filtered-frame digests with a `select` filter on frame **n+1** instead of frame **n**.

Repair probe capture in source so each case row matches the Probe bundle section of `/app/docs/regression_contract.md` (schema_tag, video_streams, audio_streams, duration_sec, frame_hashes). Rebuild with `make -C /app fglab`, run the probe pass, and signal completion.
