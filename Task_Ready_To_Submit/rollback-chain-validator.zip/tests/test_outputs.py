"""Verifier for mesh unwind audit emission."""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

APP = Path("/app")
REPORT = APP / "output" / "revert_audit.json"


def _stem_tag(stem: str) -> str:
    bundle = json.loads((APP / "cases" / f"{stem}.json").read_text(encoding="utf-8"))
    return str(bundle["scenario_label"])


def _drive(stem: str) -> dict:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    if REPORT.exists():
        REPORT.unlink()
    subprocess.run(
        ["/app/bin/meshrelay"],
        cwd=str(APP),
        env={**os.environ, "tb_mesh": stem},
        check=True,
    )
    payload = json.loads(REPORT.read_text(encoding="utf-8"))
    assert "scenario_runs" in payload and len(payload["scenario_runs"]) == 1
    row = payload["scenario_runs"][0]
    assert row.get("scenario_tag") == _stem_tag(stem)
    return row


def _assert_row(
    row: dict,
    *,
    steps_ordered: int,
    pins_locked: int,
    skew_rows: int,
    gap_units: int,
    clash_pairs: int,
) -> None:
    assert row["steps_ordered"] == steps_ordered
    assert row["pins_locked"] == pins_locked
    assert row["skew_rows"] == skew_rows
    assert row["gap_units"] == gap_units
    assert row["clash_pairs"] == clash_pairs


def test_mesh_alpha() -> None:
    """Baseline aligned mesh pack."""
    row = _drive("mesh_alpha")
    _assert_row(row, steps_ordered=3, pins_locked=0, skew_rows=0, gap_units=0, clash_pairs=0)


def test_mesh_beta() -> None:
    """Pack with a locked schema pin and revision drift on all units."""
    row = _drive("mesh_beta")
    _assert_row(row, steps_ordered=2, pins_locked=1, skew_rows=0, gap_units=3, clash_pairs=0)


def test_mesh_gamma() -> None:
    """Two-unit chain with one active async inbox."""
    row = _drive("mesh_gamma")
    _assert_row(row, steps_ordered=2, pins_locked=0, skew_rows=1, gap_units=0, clash_pairs=0)


def test_mesh_delta() -> None:
    """Mixed lane pack with live and target revision mismatch."""
    row = _drive("mesh_delta")
    _assert_row(row, steps_ordered=3, pins_locked=0, skew_rows=0, gap_units=2, clash_pairs=0)


def test_mesh_eps() -> None:
    """Pairwise revision matrix with one violating floor."""
    row = _drive("mesh_eps")
    _assert_row(row, steps_ordered=2, pins_locked=0, skew_rows=0, gap_units=1, clash_pairs=1)


def test_mesh_zeta() -> None:
    """Combined pin, inbox, and drift signals in one pack."""
    row = _drive("mesh_zeta")
    _assert_row(row, steps_ordered=2, pins_locked=1, skew_rows=1, gap_units=3, clash_pairs=0)


def test_mesh_theta() -> None:
    """Drift and matrix floor tension on linked units."""
    row = _drive("mesh_theta")
    _assert_row(row, steps_ordered=3, pins_locked=0, skew_rows=0, gap_units=2, clash_pairs=1)


def test_mesh_iota() -> None:
    """Multiple locked schema pins on a three-unit chain."""
    row = _drive("mesh_iota")
    _assert_row(row, steps_ordered=1, pins_locked=2, skew_rows=0, gap_units=0, clash_pairs=0)


def test_mesh_kappa() -> None:
    """Three-unit mesh with two lagging active inboxes."""
    row = _drive("mesh_kappa")
    _assert_row(row, steps_ordered=3, pins_locked=0, skew_rows=2, gap_units=0, clash_pairs=0)


def test_mesh_peak() -> None:
    """Stress pack exercising every audit counter."""
    row = _drive("mesh_peak")
    _assert_row(row, steps_ordered=3, pins_locked=1, skew_rows=1, gap_units=3, clash_pairs=1)
