package gate_r2

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libgate_r2.a -ldl -lm
#include "queue.h"
#include <stdlib.h>
*/
import "C"

import (
	"axrevert/store_io"
	"unsafe"
)

// FoldSkew counts active queue rows with unsafe offset drift via Rust fold.
func FoldSkew(rows []store_io.QueueRow) int {
	if len(rows) == 0 {
		return 0
	}
	wire := make([]C.WireCell, len(rows))
	for i, row := range rows {
		copyWire(&wire[i], row)
	}
	res := C.rt_fold_q((*C.WireCell)(unsafe.Pointer(&wire[0])), C.int(len(wire)))
	return int(res.row_n)
}

func copyWire(dst *C.WireCell, row store_io.QueueRow) {
	id := []byte(row.UnitID)
	for i := 0; i < len(id) && i < 63; i++ {
		dst.unit_id[i] = C.char(id[i])
	}
	dst.committed = C.int32_t(row.Committed)
	dst.head = C.int32_t(row.Head)
	if row.Active {
		dst.active = 1
	}
}
