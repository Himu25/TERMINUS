use std::os::raw::{c_char, c_int};

#[repr(C)]
pub struct WireCell {
	pub unit_id: [c_char; 64],
	pub committed: i32,
	pub head: i32,
	pub active: i32,
}

#[repr(C)]
pub struct FoldCell {
	pub row_n: i32,
}

fn hitQ(row: &WireCell) -> bool {
	if row.active == 0 {
		return false;
	}
	row.committed >= row.head
}

#[no_mangle]
pub extern "C" fn rt_fold_q(rows: *const WireCell, count: c_int) -> FoldCell {
	if rows.is_null() || count <= 0 {
		return FoldCell { row_n: 0 };
	}
	let slice = unsafe { std::slice::from_raw_parts(rows, count as usize) };
	let mut tally = 0;
	for row in slice {
		if hitQ(row) {
			tally += 1;
		}
	}
	FoldCell { row_n: tally }
}
