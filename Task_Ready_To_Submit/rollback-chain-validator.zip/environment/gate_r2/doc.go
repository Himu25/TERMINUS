// Package gate_r2 bridges Rust queue skew folding for Go callers.
package gate_r2
