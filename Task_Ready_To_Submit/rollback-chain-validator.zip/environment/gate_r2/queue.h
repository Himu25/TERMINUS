#pragma once

#include <stdint.h>

typedef struct {
	char unit_id[64];
	int32_t committed;
	int32_t head;
	int32_t active;
} WireCell;

typedef struct {
	int32_t row_n;
} FoldCell;

FoldCell rt_fold_q(const WireCell *rows, int32_t count);
