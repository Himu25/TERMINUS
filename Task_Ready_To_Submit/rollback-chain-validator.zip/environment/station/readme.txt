station relay notes
