hull notes
