// Package store_io defines replay bundle shapes for mesh unwind audits.
package store_io
