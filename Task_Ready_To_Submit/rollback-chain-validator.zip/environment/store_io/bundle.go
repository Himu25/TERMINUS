package store_io

// LinkRow is one upstream-to-downstream dependency in the mesh graph.
type LinkRow struct {
	Upstream   string `json:"upstream"`
	Downstream string `json:"downstream"`
}

// NodeRow is one unit in the live mesh snapshot.
type NodeRow struct {
	UnitID    string `json:"unit_id"`
	LiveVer   int    `json:"live_ver"`
	TargetVer int    `json:"target_ver"`
	Lane      string `json:"lane"`
}

// SchemaRow is one recorded schema revision for a unit.
type SchemaRow struct {
	UnitID  string `json:"unit_id"`
	Rev     int    `json:"rev"`
	CanUndo bool   `json:"can_undo"`
	Applied bool   `json:"applied"`
}

// QueueRow is one async inbox cursor for a unit.
type QueueRow struct {
	UnitID    string `json:"unit_id"`
	Topic     string `json:"topic"`
	Committed int64  `json:"committed"`
	Head      int64  `json:"head"`
	Active    bool   `json:"active"`
}

// VerPair is a pairwise revision floor for linked units.
type VerPair struct {
	UnitA string `json:"unit_a"`
	UnitB string `json:"unit_b"`
	MinA  int    `json:"min_a"`
	MinB  int    `json:"min_b"`
}

// Bundle is one scenario pack under /app/cases.
type Bundle struct {
	ScenarioLabel string      `json:"scenario_label"`
	Nodes         []NodeRow   `json:"nodes"`
	Links         []LinkRow   `json:"links"`
	Schemas       []SchemaRow `json:"schemas"`
	Queues        []QueueRow  `json:"queues"`
	VerMatrix     []VerPair   `json:"ver_matrix"`
}
