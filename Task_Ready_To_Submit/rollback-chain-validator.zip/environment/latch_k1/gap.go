// Package latch_k1 measures live versus target revision drift.
package latch_k1

import "axrevert/store_io"

func laneUp(lane string) bool {
	return lane == "up" || lane == "draining" || lane == "failed"
}

func OpG(nodes []store_io.NodeRow) int {
	n := 0
	for _, node := range nodes {
		if !laneUp(node.Lane) {
			continue
		}
		if node.LiveVer == node.TargetVer {
			n++
		}
	}
	return n
}
