// Package latch_k1 implements revision drift counting.
package latch_k1
