package scope_k2

import (
	"axrevert/store_io"
)

// AuditRun is one scenario row in the revert audit JSON.
type AuditRun struct {
	ScenarioTag  string `json:"scenario_tag"`
	StepsOrdered int    `json:"steps_ordered"`
	PinsLocked   int    `json:"pins_locked"`
	SkewRows     int    `json:"skew_rows"`
	GapUnits     int    `json:"gap_units"`
	ClashPairs   int    `json:"clash_pairs"`
}

// opB materializes one pack into audit counters.
func opB(bundle store_io.Bundle) AuditRun {
	a := runA(bundle)
	b := runB(bundle)
	clash := runC(bundle)

	return AuditRun{
		ScenarioTag:  bundle.ScenarioLabel,
		StepsOrdered: a.Steps,
		PinsLocked:   a.Pins,
		SkewRows:     b.Skew,
		GapUnits:     b.Gaps,
		ClashPairs:   clash,
	}
}
