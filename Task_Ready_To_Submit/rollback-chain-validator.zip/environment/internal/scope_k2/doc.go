// Package scope_k2 emits revert audit JSON for one mesh replay pack.
package scope_k2
