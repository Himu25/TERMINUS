package scope_k2

import (
	"axrevert/chain_m3"
	"axrevert/depot_q7"
	"axrevert/store_io"
)

type tallyA struct {
	Steps int
	Pins  int
}

func runA(bundle store_io.Bundle) tallyA {
	return tallyA{
		Steps: depot_q7.OpU(bundle.Nodes, bundle.Links, bundle.Schemas),
		Pins:  chain_m3.OpP(bundle.Schemas),
	}
}
