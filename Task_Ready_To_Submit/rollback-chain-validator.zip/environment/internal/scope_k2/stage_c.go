package scope_k2

import (
	"axrevert/mesh_p5"
	"axrevert/store_io"
)

func runC(bundle store_io.Bundle) int {
	return mesh_p5.OpV(bundle.Nodes, bundle.VerMatrix)
}
