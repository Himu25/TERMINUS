package scope_k2

import (
	"axrevert/gate_r2"
	"axrevert/latch_k1"
	"axrevert/store_io"
)

type tallyB struct {
	Skew int
	Gaps int
}

func runB(bundle store_io.Bundle) tallyB {
	return tallyB{
		Skew: gate_r2.FoldSkew(bundle.Queues),
		Gaps: latch_k1.OpG(bundle.Nodes),
	}
}
