#!/bin/bash
set -euo pipefail
test -f /app/go.mod
