// Package mesh_p5 checks revision floors across linked unit pairs.
package mesh_p5

import "axrevert/store_io"

func idxN(nodes []store_io.NodeRow) map[string]store_io.NodeRow {
	out := make(map[string]store_io.NodeRow, len(nodes))
	for _, row := range nodes {
		out[row.UnitID] = row
	}
	return out
}

func lexAB(a, b string) (string, string) {
	if a < b {
		return a, b
	}
	return b, a
}

func OpV(nodes []store_io.NodeRow, pairs []store_io.VerPair) int {
	byID := idxN(nodes)
	seen := make(map[string]bool)
	n := 0
	for _, pair := range pairs {
		a, okA := byID[pair.UnitA]
		b, okB := byID[pair.UnitB]
		if !okA || !okB {
			continue
		}
		k1, k2 := lexAB(pair.UnitA, pair.UnitB)
		token := k1 + "|" + k2 + "|" + pair.UnitA
		if seen[token] {
			continue
		}
		seen[token] = true
		if a.TargetVer < pair.MinA || b.TargetVer < pair.MinB {
			n++
		}
	}
	return n
}
