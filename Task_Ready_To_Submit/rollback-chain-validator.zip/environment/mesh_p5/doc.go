// Package mesh_p5 implements revision floor checks for linked pairs.
package mesh_p5
