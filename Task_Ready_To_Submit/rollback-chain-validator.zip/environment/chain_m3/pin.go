// Package chain_m3 tallies locked schema pins in a bundle.
package chain_m3

import (
	"sort"

	"axrevert/store_io"
)

type revKey struct {
	unit string
	rev  int
}

func grpTape(schemas []store_io.SchemaRow) map[string][]store_io.SchemaRow {
	out := make(map[string][]store_io.SchemaRow)
	for _, row := range schemas {
		out[row.UnitID] = append(out[row.UnitID], row)
	}
	for unit := range out {
		sort.Slice(out[unit], func(i, j int) bool {
			return out[unit][i].Rev < out[unit][j].Rev
		})
	}
	return out
}

func OpP(schemas []store_io.SchemaRow) int {
	byUnit := grpTape(schemas)
	seen := make(map[revKey]bool)
	n := 0
	for unit, rows := range byUnit {
		for _, row := range rows {
			key := revKey{unit: unit, rev: row.Rev}
			if seen[key] {
				continue
			}
			seen[key] = true
			if row.Applied && row.CanUndo {
				n++
			}
		}
	}
	return n
}
