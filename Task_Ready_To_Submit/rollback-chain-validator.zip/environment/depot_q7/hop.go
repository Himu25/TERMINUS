// Package depot_q7 counts units eligible for unwind sequencing.
package depot_q7

import "axrevert/store_io"

func idxU(nodes []store_io.NodeRow) map[string]store_io.NodeRow {
	out := make(map[string]store_io.NodeRow, len(nodes))
	for _, row := range nodes {
		out[row.UnitID] = row
	}
	return out
}

func hopBoth(links []store_io.LinkRow) (map[string][]string, map[string][]string) {
	fwd := make(map[string][]string)
	rev := make(map[string][]string)
	for _, row := range links {
		fwd[row.Upstream] = append(fwd[row.Upstream], row.Downstream)
		rev[row.Downstream] = append(rev[row.Downstream], row.Upstream)
	}
	return fwd, rev
}
