// Package depot_q7 counts units eligible for unwind sequencing.
package depot_q7

import (
	"sort"

	"axrevert/store_io"
)

func seqQ(nodes []store_io.NodeRow, links []store_io.LinkRow) []string {
	seen := make(map[string]bool)
	for _, row := range links {
		seen[row.Upstream] = true
	}
	out := make([]string, 0, len(seen))
	for id := range seen {
		out = append(out, id)
	}
	sort.Strings(out)
	return out
}
