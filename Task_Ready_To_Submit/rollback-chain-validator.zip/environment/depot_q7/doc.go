// Package depot_q7 implements unwind eligibility counting.
package depot_q7
