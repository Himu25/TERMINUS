// Package depot_q7 counts units eligible for unwind sequencing.
package depot_q7

import "axrevert/store_io"

func maskQ(schemas []store_io.SchemaRow) map[string]bool {
	out := make(map[string]bool)
	for _, row := range schemas {
		if row.Applied && row.CanUndo {
			out[row.UnitID] = true
		}
	}
	return out
}
