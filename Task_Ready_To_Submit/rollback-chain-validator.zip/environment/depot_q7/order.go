// Package depot_q7 counts units eligible for unwind sequencing.
package depot_q7

import "axrevert/store_io"

func OpU(nodes []store_io.NodeRow, links []store_io.LinkRow, schemas []store_io.SchemaRow) int {
	blocked := maskQ(schemas)
	seq := seqQ(nodes, links)
	n := 0
	for _, id := range seq {
		if !blocked[id] {
			n++
		}
	}
	return n
}
