package main

import (
	"os"

	"axrevert/internal/scope_k2"
)

// meshrelay replays one scenario bundle named by tb_mesh.
func main() {
	os.Exit(scope_k2.MainExit())
}
