#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1

mkdir -p /app/bin
cd /app/gate_r2
cargo build --release --locked
cd /app
GOFLAGS=-mod=mod go build -o /app/bin/meshrelay ./cmd/meshrelay
