Go cmd/meshrelay drives scope_k2 audit emission. Rust gate_r2 folds queue skew. Bash build script links both.
