Replay emits one scenario row per tb_mesh pack with steps_ordered, pins_locked, skew_rows, gap_units, and clash_pairs counters.
