#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TASK_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

if [ -f "/app/go.mod" ] && [ -d "/app/gate_r2" ]; then
  env_dir="/app"
elif [ -d "$TASK_DIR/environment" ]; then
  env_dir="$TASK_DIR/environment"
elif [ -d "/environment" ] && [ -f "/environment/go.mod" ]; then
  env_dir="/environment"
else
  echo "Could not locate task environment layout." >&2
  exit 1
fi

cd "$SCRIPT_DIR"
if ! patch -p1 --forward -d "$env_dir" <fixes.patch; then
  echo "Failed to apply oracle fixes.patch under $env_dir" >&2
  exit 1
fi

bash "$env_dir/scripts/build.sh"

if [ ! -x "$env_dir/bin/meshrelay" ]; then
  echo "meshrelay binary missing after rebuild" >&2
  exit 1
fi

for probe in \
  mesh_alpha mesh_beta mesh_gamma mesh_delta mesh_eps \
  mesh_zeta mesh_theta mesh_iota mesh_kappa mesh_peak
do
  rm -f "$env_dir/output/revert_audit.json"
  (
    cd "$env_dir"
    export tb_mesh="$probe"
    ./bin/meshrelay >/dev/null
  )
  python3 - "$env_dir" "$probe" <<'PY'
import json
import sys

env_dir, probe = sys.argv[1], sys.argv[2]
with open(f"{env_dir}/output/revert_audit.json", encoding="utf-8") as fh:
    audit = json.load(fh)
runs = audit.get("scenario_runs")
assert isinstance(runs, list) and len(runs) == 1, f"{probe}: scenario_runs must be a single-entry array"
row = runs[0]
with open(f"{env_dir}/cases/{probe}.json", encoding="utf-8") as fh:
    bundle = json.load(fh)
assert row.get("scenario_tag") == bundle["scenario_label"], f"{probe}: scenario_tag mismatch"
for key in ("steps_ordered", "pins_locked", "skew_rows", "gap_units", "clash_pairs"):
    value = row.get(key)
    assert isinstance(value, int) and value >= 0, f"{probe}: {key} must be a non-negative integer"
PY
done

echo "Oracle rebuilt meshrelay and validated all ten scenario bundles."
