package vault

import (
	"mtisol.lab/embed"
	"mtisol.lab/index"
	"mtisol.lab/pkg/types"
)

func I2Build(docs []types.CorpusDoc, dim, numParts int) types.Bank {
	bank := types.Bank{Rows: make([]types.BankRow, 0, len(docs))}
	for _, doc := range docs {
		vec := embed.VecFromText(doc.Text, dim)
		bank.Rows = append(bank.Rows, types.BankRow{
			ID:     doc.ID,
			Vec:    vec,
			PartID: index.P1PartID(doc, numParts),
			Tenant: doc.Tenant,
		})
	}
	return bank
}
