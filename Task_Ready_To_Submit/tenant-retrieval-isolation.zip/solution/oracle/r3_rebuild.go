package index

import "mtisol.lab/pkg/types"

func R3Apply(bank *types.Bank, incoming []types.BankRow, partID int) {
	kept := make([]types.BankRow, 0, len(bank.Rows))
	for _, row := range bank.Rows {
		if row.PartID != partID {
			kept = append(kept, row)
		}
	}
	bank.Rows = append(kept, incoming...)
}
