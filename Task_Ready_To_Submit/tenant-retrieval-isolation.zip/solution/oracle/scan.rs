use serde::{Deserialize, Serialize};
use std::cmp::Ordering;
use std::collections::HashSet;
use std::io::{self, Read, Write};

#[derive(Debug, Clone, Serialize, Deserialize)]
struct Row {
    id: String,
    vec: Vec<f64>,
    part_id: i32,
    tenant: String,
}

#[derive(Debug, Deserialize)]
struct ScanInput {
    query: Vec<f64>,
    rows: Vec<Row>,
    top_k: usize,
    allowed_parts: Vec<i32>,
    tenant_hint: String,
}

#[derive(Debug, Serialize)]
struct ScanOutput {
    indices: Vec<usize>,
    scan_units: i64,
    leak_pre: i32,
}

fn scan(input: &ScanInput) -> ScanOutput {
    let allow: HashSet<i32> = input.allowed_parts.iter().copied().collect();
    let mut scored: Vec<(usize, f64)> = Vec::new();
    for (i, row) in input.rows.iter().enumerate() {
        if !input.tenant_hint.is_empty() && row.tenant != input.tenant_hint {
            continue;
        }
        if !allow.is_empty() && !allow.contains(&row.part_id) {
            continue;
        }
        let mut dot = 0.0f64;
        let n = input.query.len().min(row.vec.len());
        for j in 0..n {
            dot += input.query[j] * row.vec[j];
        }
        scored.push((i, dot));
    }
    scored.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(Ordering::Equal));
    let top_k = if input.top_k == 0 || input.top_k > scored.len() {
        scored.len()
    } else {
        input.top_k
    };
    let visited = scored.len();
    let indices: Vec<usize> = scored.into_iter().take(top_k).map(|(i, _)| i).collect();
    let mut leak_pre = 0i32;
    if !input.tenant_hint.is_empty() {
        for &ix in &indices {
            if ix < input.rows.len() && input.rows[ix].tenant != input.tenant_hint {
                leak_pre += 1;
            }
        }
    }
    let scan_units = (visited as i64).max(1) * (input.query.len() as i64);
    ScanOutput {
        indices,
        scan_units,
        leak_pre,
    }
}

fn main() {
    let mut raw = String::new();
    io::stdin().read_to_string(&mut raw).expect("read stdin");
    let input: ScanInput = serde_json::from_str(&raw).expect("parse scan input");
    let out = scan(&input);
    let encoded = serde_json::to_string(&out).expect("encode scan output");
    io::stdout().write_all(encoded.as_bytes()).expect("write stdout");
}
