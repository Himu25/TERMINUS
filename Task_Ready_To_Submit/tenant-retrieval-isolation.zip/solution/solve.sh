#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight: tenant retrieval isolation workspace"
require_file /app/go.mod
require_file /app/config/isolation.toml
require_file /app/data/corpus_default.json
require_file /app/scan/Cargo.toml
mkdir -p /app/bin /app/output

log "survey: guardrails and subsystem layout"
grep -nE 'leak|partition|stale|tenant|isolation' \
  /app/config/isolation.toml /app/metrics/guardrails.txt /app/policies/retention.txt 2>/dev/null | head -n 20 || true
wc -l /app/k2/k2_store.go /app/index/p1_route.go /app/g4/g4_scope.go /app/scan/src/main.rs /app/embed/e1_vec.go /app/bench/b5_drive.go

log "restore tenant-scoped k2 store keys"
cp "${ROOT_DIR}/oracle/k2_store.go" /app/k2/k2_store.go

log "restore tenant-aware partition routing"
cp "${ROOT_DIR}/oracle/p1_route.go" /app/index/p1_route.go

log "restore scoped partial index rebuild merges"
cp "${ROOT_DIR}/oracle/r3_rebuild.go" /app/index/r3_rebuild.go

log "restore tenant metadata scope filter"
cp "${ROOT_DIR}/oracle/g4_scope.go" /app/g4/g4_scope.go

log "restore partition ids on vault load"
cp "${ROOT_DIR}/oracle/i2_load.go" /app/vault/i2_load.go

log "restore k2 layer tenant checks"
cp "${ROOT_DIR}/oracle/i5_layer.go" /app/vault/i5_layer.go

log "restore query shaping before embedding"
sed -i 's/return strings.TrimSpace(query)/return strings.Join(strings.Fields(query), " ")/' /app/embed/e1_vec.go

log "align hot-path cache keys with stopword-prepared queries"
sed -i 's/vault.I5CacheGet(store, qc.Query, hint)/vault.I5CacheGet(store, prep, hint)/' /app/bench/b5_drive.go
sed -i 's/vault.I5CachePut(store, qc.Query, hint, annIDs)/vault.I5CachePut(store, prep, hint, annIDs)/' /app/bench/b5_drive.go

log "install partition-scoped Rust scan"
cp "${ROOT_DIR}/oracle/scan.rs" /app/scan/src/main.rs

log "rebuild Go and Rust retrieval binaries"
bash /app/tools/build_all

log "regenerate query gold ids with repaired isolation path"
/app/bin/labeld /app/data/corpus_default.json /app/data/query_specs.jsonl /app/data/queries_default.jsonl

log "run default tenant isolation bench report"
chmod +x /app/tools/run_bench
/app/tools/run_bench /app/data/queries_default.jsonl /app/output/tenant_bench.json

log "post-run validation against isolation.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg_path = Path("/app/config/isolation.toml")
cfg = {}
for line in cfg_path.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = line.split("=", 1)
    k, v = k.strip(), v.strip()
    if k.endswith("_floor") or k.startswith("min_") or k.startswith("max_"):
        cfg[k] = float(v)
    elif k == "billing_pack_min_gold_hits":
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/tenant_bench.json").read_text())
assert report["status"] == "ok", report
assert report["mean_ann_recall_at_10"] >= cfg["ann_recall_floor"]
assert report["mean_isolation_purity"] >= cfg["min_isolation_purity"]
assert report["leak_rate"] <= cfg["max_leak_rate"]
assert report["partition_integrity"] >= cfg["min_partition_integrity"]
assert report["cache_stale_rate"] <= cfg["max_cache_stale_rate"]
bill = next(q for q in report["queries"] if q["query_id"] == "q_billing_refund")
assert bill["gold_hits"] >= cfg["billing_pack_min_gold_hits"]
print("ok", report["leak_rate"], report["partition_integrity"])
PY

log "oracle complete"
