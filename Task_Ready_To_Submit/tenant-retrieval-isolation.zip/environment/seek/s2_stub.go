package seek

func CursorReset() {}
