module mtisol.lab

go 1.22
