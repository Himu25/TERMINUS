package vault

import "mtisol.lab/k2"

func NewCacheStore() *k2.Store {
	return k2.NewStore()
}
