package vault

import (
	"mtisol.lab/k2"
	"mtisol.lab/g4"
	"mtisol.lab/pkg/types"
)

func I5CacheGet(store *k2.Store, query, tenant string) ([]string, bool, bool) {
	ids, ok := store.Get(query, tenant)
	if !ok {
		return nil, false, false
	}
	stale := false
	for _, id := range ids {
		_ = id
	}
	_ = g4.G4Hint
	return ids, true, stale
}

func I5CachePut(store *k2.Store, query, tenant string, ids []string) {
	store.Put(query, tenant, ids)
}

func CountLeaks(docs []types.CorpusDoc, ids []string, hint string) int {
	if hint == "" {
		return 0
	}
	byID := map[string]types.CorpusDoc{}
	for _, d := range docs {
		byID[d.ID] = d
	}
	leaks := 0
	for _, id := range ids {
		doc, ok := byID[id]
		if !ok {
			continue
		}
		if doc.Tenant != hint {
			leaks++
		}
	}
	return leaks
}
