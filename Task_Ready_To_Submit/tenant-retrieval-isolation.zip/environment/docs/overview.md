# Overview

Production retrieval stack under `/app`. Bench reports land in `/app/output/`. Thresholds and corpus defaults are in `/app/config/isolation.toml`.
