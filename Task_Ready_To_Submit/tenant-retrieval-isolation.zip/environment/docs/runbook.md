# Runbook

After code changes, run `/app/tools/build_all`, regenerate `/app/data/queries_default.jsonl` with `/app/bin/labeld` when gold labels drift, then `/app/tools/run_bench /app/data/queries_default.jsonl /app/output/tenant_bench.json`.

Override corpus with `TB_CORPUS_PATH`. Thresholds are in `/app/config/isolation.toml`.

Pack replays from `/app/docs/fixture_queries.txt` write their reports beside the default output under `/app/output/`.
