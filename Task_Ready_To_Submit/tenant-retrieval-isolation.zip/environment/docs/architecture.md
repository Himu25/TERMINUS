# Architecture notes

The stack under `/app` ingests corpus JSON, builds a searchable vector bank, runs ANN retrieval, applies metadata filtering and reranking, and aggregates bench metrics into `/app/output/tenant_bench.json`.

Corpus records carry tenant tags. Queries may include tenant hints that downstream stages must honor. The bench driver compares rolled-up metrics against `/app/config/isolation.toml`.

Pack replays listed in `/app/docs/fixture_queries.txt` exercise alternate corpora via TB_CORPUS_PATH.
