package net

const DefaultPort = 9472
