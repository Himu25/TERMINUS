package index

import "mtisol.lab/pkg/types"

func R3Apply(bank *types.Bank, incoming []types.BankRow, partID int) {
	_ = partID
	for i := range incoming {
		incoming[i].PartID = 0
	}
	bank.Rows = append(bank.Rows, incoming...)
}
