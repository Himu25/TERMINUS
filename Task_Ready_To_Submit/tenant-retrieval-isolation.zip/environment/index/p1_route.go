package index

import (
	"hash/fnv"

	"mtisol.lab/pkg/types"
)

func P1PartID(doc types.CorpusDoc, numParts int) int {
	if numParts <= 0 {
		numParts = 8
	}
	h := fnv.New32a()
	_, _ = h.Write([]byte(doc.ID))
	return int(h.Sum32() % uint32(numParts))
}

func P1PartsForTenant(tenant string, numParts int) []int {
	if numParts <= 0 {
		numParts = 8
	}
	h := fnv.New32a()
	_, _ = h.Write([]byte(tenant))
	base := int(h.Sum32() % uint32(numParts))
	return []int{base, (base + 1) % numParts}
}
