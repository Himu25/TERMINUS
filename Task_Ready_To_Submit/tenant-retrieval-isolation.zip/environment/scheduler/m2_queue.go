package scheduler

type Queue struct {
	depth int
}

func NewQueue(d int) *Queue {
	return &Queue{depth: d}
}
