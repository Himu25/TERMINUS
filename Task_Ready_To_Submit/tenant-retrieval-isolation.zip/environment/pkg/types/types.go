package types

type CorpusDoc struct {
	ID     string `json:"id"`
	Label  string `json:"label"`
	Text   string `json:"text"`
	Tenant string `json:"tenant"`
}

type BankRow struct {
	ID     string
	Vec    []float64
	PartID int
	Tenant string
}

type Bank struct {
	Rows []BankRow
}

type QueryCase struct {
	QueryID string   `json:"query_id"`
	Query   string   `json:"query"`
	GoldIDs []string `json:"gold_ids"`
}

type QueryRow struct {
	QueryID          string  `json:"query_id"`
	AnnRecallAt10    float64 `json:"ann_recall_at_10"`
	IsolationPurity  float64 `json:"isolation_purity"`
	NdcgAt10         float64 `json:"ndcg_at_10"`
	GoldHits         int     `json:"gold_hits"`
	FilterKept       int     `json:"filter_kept"`
	LeakCount        int     `json:"leak_count"`
	CacheStale       int     `json:"cache_stale"`
}

type TenantReport struct {
	Status               string     `json:"status"`
	CorpusVectors        int        `json:"corpus_vectors"`
	VectorDim            int        `json:"vector_dim"`
	QueriesTotal         int        `json:"queries_total"`
	MeanAnnRecallAt10    float64    `json:"mean_ann_recall_at_10"`
	MeanIsolationPurity  float64    `json:"mean_isolation_purity"`
	MeanNdcgAt10         float64    `json:"mean_ndcg_at_10"`
	LeakRate             float64    `json:"leak_rate"`
	PartitionIntegrity   float64    `json:"partition_integrity"`
	CacheStaleRate       float64    `json:"cache_stale_rate"`
	FilterSurvivalRate   float64    `json:"filter_survival_rate"`
	MeanScanUnits        float64    `json:"mean_scan_units"`
	ReportDigest         string     `json:"report_digest"`
	Queries              []QueryRow `json:"queries"`
}

type IsolationCfg struct {
	VectorDim              int
	TopK                   int
	SearchEF               int
	NumPartitions          int
	AnnRecallFloor         float64
	NdcgFloor              float64
	MinIsolationPurity     float64
	MaxLeakRate            float64
	MinPartitionIntegrity  float64
	MaxCacheStaleRate      float64
	MinFilterSurvival      float64
	CorpusPath             string
	TightSecurityRecall    float64
	BillingPackRecall      float64
	BillingPackMinGold     int
}

type PartialHit struct {
	DocID string
	Score float64
}
