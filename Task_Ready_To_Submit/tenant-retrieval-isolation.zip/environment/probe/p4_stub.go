package probe

// Go fallback scan is unused when scan binary is present.
