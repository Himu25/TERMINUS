bench fixtures and registry manifests live under data/ and registry/
