package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"strings"

	"mtisol.lab/bench"
	"mtisol.lab/corpus"
	"mtisol.lab/embed"
	"mtisol.lab/g4"
	"mtisol.lab/index"
	"mtisol.lab/vault"
	"mtisol.lab/pkg/types"
)

func main() {
	if len(os.Args) < 4 {
		fmt.Fprintln(os.Stderr, "usage: labeld <corpus.json> <specs.jsonl> <out.jsonl>")
		os.Exit(2)
	}
	cfg, err := bench.LoadCfg("/app/config/isolation.toml")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	docs, err := corpus.Load(os.Args[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	specs, err := loadSpecs(os.Args[2])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	bank := vault.I2Build(docs, cfg.VectorDim, cfg.NumPartitions)
	out, err := os.Create(os.Args[3])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer out.Close()
	w := bufio.NewWriter(out)
	for _, spec := range specs {
		prep := embed.StopPrep(spec.Query)
		qv := embed.VecFromText(embed.QxPrep(prep), cfg.VectorDim)
		hint := g4.G4Hint(spec.Query)
		allowed := index.P1PartsForTenant(hint, cfg.NumPartitions)
		idxs, _, _ := bench.RustScan(qv, bank, cfg.TopK, allowed, hint)
		annIDs := make([]string, 0, len(idxs))
		for _, ix := range idxs {
			if ix >= 0 && ix < len(bank.Rows) {
				annIDs = append(annIDs, bank.Rows[ix].ID)
			}
		}
		filtered := g4.G4Filter(docs, annIDs, hint)
		gold := filtered
		if len(gold) > cfg.TopK {
			gold = gold[:cfg.TopK]
		}
		row := types.QueryCase{QueryID: spec.QueryID, Query: spec.Query, GoldIDs: gold}
		raw, _ := json.Marshal(row)
		if _, err := w.Write(append(raw, '\n')); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	}
	if err := w.Flush(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func loadSpecs(path string) ([]types.QueryCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.QueryCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var qc types.QueryCase
		if err := json.Unmarshal([]byte(line), &qc); err != nil {
			return nil, err
		}
		out = append(out, qc)
	}
	return out, sc.Err()
}
