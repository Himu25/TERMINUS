package k2

import (
	"crypto/sha256"
	"encoding/hex"
	"strings"
	"sync"
)

type Entry struct {
	Tenant string
	IDs    []string
}

type Store struct {
	mu   sync.RWMutex
	data map[string]Entry
}

func NewStore() *Store {
	return &Store{data: make(map[string]Entry)}
}

func semanticKey(query string) string {
	var parts []string
	for _, tok := range strings.Fields(query) {
		if strings.HasPrefix(tok, "tenant:") {
			continue
		}
		parts = append(parts, tok)
	}
	return strings.Join(parts, " ")
}

func keyFor(query string) string {
	sum := sha256.Sum256([]byte(semanticKey(query)))
	return hex.EncodeToString(sum[:8])
}

func (s *Store) Get(query, tenant string) ([]string, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	ent, ok := s.data[keyFor(query)]
	if !ok {
		return nil, false
	}
	return ent.IDs, true
}

func (s *Store) Put(query, tenant string, ids []string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	cp := make([]string, len(ids))
	copy(cp, ids)
	s.data[keyFor(query)] = Entry{Tenant: tenant, IDs: cp}
}
