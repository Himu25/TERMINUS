package codec

import (
	"encoding/binary"
	"hash/fnv"
	"math"
)

func PackF64(vec []float64) []byte {
	buf := make([]byte, 8*len(vec))
	for i, v := range vec {
		binary.LittleEndian.PutUint64(buf[i*8:], math.Float64bits(v))
	}
	return buf
}

func Sig32(raw []byte) uint32 {
	h := fnv.New32a()
	_, _ = h.Write(raw)
	return h.Sum32()
}
