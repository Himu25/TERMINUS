package g4

import (
	"strings"

	"mtisol.lab/pkg/types"
)

func G4Hint(query string) string {
	for _, tok := range strings.Fields(query) {
		if strings.HasPrefix(tok, "tenant:") {
			return strings.TrimPrefix(tok, "tenant:")
		}
	}
	return ""
}

func labelSlot(doc types.CorpusDoc) string {
	parts := strings.Split(doc.Label, "-")
	if len(parts) < 2 {
		return ""
	}
	return parts[0]
}

func G4Keep(doc types.CorpusDoc, hint string) bool {
	if hint == "" {
		return true
	}
	return labelSlot(doc) == hint
}

func G4Filter(docs []types.CorpusDoc, ids []string, hint string) []string {
	if hint == "" {
		return ids
	}
	byID := make(map[string]types.CorpusDoc, len(docs))
	for _, d := range docs {
		byID[d.ID] = d
	}
	out := make([]string, 0, len(ids))
	for _, id := range ids {
		doc, ok := byID[id]
		if !ok {
			continue
		}
		if G4Keep(doc, hint) {
			out = append(out, id)
		}
	}
	return out
}
