package embed

import (
	"hash/fnv"
	"math"
	"strings"
)

func ActiveDim(dim int) int {
	return dim
}

func VecFromText(text string, dim int) []float64 {
	if dim <= 0 {
		dim = 32
	}
	out := make([]float64, dim)
	h := fnv.New64a()
	h.Write([]byte(text))
	seed := h.Sum64()
	for i := 0; i < dim; i++ {
		seed = seed*6364136223846793005 + 1442695040888963407
		out[i] = (float64(int64(seed>>33)%1000) / 500.0) - 1.0
	}
	norm := 0.0
	for _, v := range out {
		norm += v * v
	}
	norm = math.Sqrt(norm)
	if norm > 0 {
		for i := range out {
			out[i] /= norm
		}
	}
	return out
}

func Dot(a, b []float64) float64 {
	n := len(a)
	if len(b) < n {
		n = len(b)
	}
	s := 0.0
	for i := 0; i < n; i++ {
		s += a[i] * b[i]
	}
	return s
}

func QxPrep(query string) string {
	return strings.TrimSpace(query)
}
