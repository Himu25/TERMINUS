package embed

import (
	"os"
	"strings"
)

func StopPrep(text string) string {
	raw, err := os.ReadFile("/app/config/stopwords.txt")
	if err != nil {
		return text
	}
	stop := map[string]struct{}{}
	for _, line := range strings.Split(string(raw), "\n") {
		w := strings.TrimSpace(line)
		if w != "" {
			stop[w] = struct{}{}
		}
	}
	var out []string
	for _, tok := range strings.Fields(text) {
		if strings.HasPrefix(tok, "tenant:") {
			out = append(out, tok)
			continue
		}
		if _, skip := stop[tok]; skip {
			continue
		}
		out = append(out, tok)
	}
	return strings.Join(out, " ")
}
