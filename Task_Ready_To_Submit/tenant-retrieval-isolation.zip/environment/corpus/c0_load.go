package corpus

import (
	"encoding/json"
	"os"

	"mtisol.lab/pkg/types"
)

const DefaultCorpusPath = "/app/data/corpus_default.json"

func Load(path string) ([]types.CorpusDoc, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var payload struct {
		Vectors []types.CorpusDoc `json:"vectors"`
	}
	if err := json.Unmarshal(raw, &payload); err != nil {
		return nil, err
	}
	return payload.Vectors, nil
}
