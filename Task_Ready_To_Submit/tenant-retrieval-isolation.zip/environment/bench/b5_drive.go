package bench

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"strings"

	"mtisol.lab/corpus"
	"mtisol.lab/embed"
	"mtisol.lab/g4"
	"mtisol.lab/index"
	"mtisol.lab/vault"
	"mtisol.lab/pkg/types"
)

func LoadCfg(path string) (types.IsolationCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.IsolationCfg{}, err
	}
	cfg := types.IsolationCfg{CorpusPath: corpus.DefaultCorpusPath}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "vector_dim":
			fmt.Sscanf(val, "%d", &cfg.VectorDim)
		case "top_k":
			fmt.Sscanf(val, "%d", &cfg.TopK)
		case "search_ef":
			fmt.Sscanf(val, "%d", &cfg.SearchEF)
		case "num_partitions":
			fmt.Sscanf(val, "%d", &cfg.NumPartitions)
		case "ann_recall_floor":
			fmt.Sscanf(val, "%f", &cfg.AnnRecallFloor)
		case "ndcg_floor":
			fmt.Sscanf(val, "%f", &cfg.NdcgFloor)
		case "min_isolation_purity":
			fmt.Sscanf(val, "%f", &cfg.MinIsolationPurity)
		case "max_leak_rate":
			fmt.Sscanf(val, "%f", &cfg.MaxLeakRate)
		case "min_partition_integrity":
			fmt.Sscanf(val, "%f", &cfg.MinPartitionIntegrity)
		case "max_cache_stale_rate":
			fmt.Sscanf(val, "%f", &cfg.MaxCacheStaleRate)
		case "min_filter_survival":
			fmt.Sscanf(val, "%f", &cfg.MinFilterSurvival)
		case "corpus_path":
			cfg.CorpusPath = val
		case "tight_security_recall_floor":
			fmt.Sscanf(val, "%f", &cfg.TightSecurityRecall)
		case "billing_pack_recall_floor":
			fmt.Sscanf(val, "%f", &cfg.BillingPackRecall)
		case "billing_pack_min_gold_hits":
			fmt.Sscanf(val, "%d", &cfg.BillingPackMinGold)
		}
	}
	return cfg, nil
}

func LoadQueries(path string) ([]types.QueryCase, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.QueryCase, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var qc types.QueryCase
		if err := json.Unmarshal([]byte(line), &qc); err != nil {
			return nil, err
		}
		out = append(out, qc)
	}
	return out, sc.Err()
}

func Run(cfg types.IsolationCfg, cases []types.QueryCase) (types.TenantReport, error) {
	if override := os.Getenv("TB_CORPUS_PATH"); override != "" {
		cfg.CorpusPath = override
	}
	docs, err := corpus.Load(cfg.CorpusPath)
	if err != nil {
		return types.TenantReport{}, err
	}
	bank := vault.I2Build(docs, cfg.VectorDim, cfg.NumPartitions)
	partRows := make([]types.BankRow, 0)
	for _, doc := range docs[:len(docs)/3] {
		partRows = append(partRows, types.BankRow{
			ID: doc.ID + "-rebuild",
			Vec: embed.VecFromText(doc.Text+" rebuild", cfg.VectorDim),
			PartID: index.P1PartID(doc, cfg.NumPartitions),
			Tenant: doc.Tenant,
		})
	}
	index.R3Apply(&bank, partRows, 0)
	store := vault.NewCacheStore()
	report := types.TenantReport{
		Status:        "ok",
		CorpusVectors: len(docs),
		VectorDim:     cfg.VectorDim,
		QueriesTotal:  len(cases),
	}
	report.Queries = make([]types.QueryRow, 0, len(cases))
	var sumAnn, sumNdcg, sumIso, sumFilter, sumLeak, sumStale, sumScan float64
	for _, qc := range cases {
		prep := embed.StopPrep(qc.Query)
		qv := embed.VecFromText(embed.QxPrep(prep), cfg.VectorDim)
		hint := g4.G4Hint(qc.Query)
		allowed := index.P1PartsForTenant(hint, cfg.NumPartitions)
		var annIDs []string
		var scanUnits int64
		var leakPre int
		var cacheStale int
		if cached, hit, stale := vault.I5CacheGet(store, qc.Query, hint); hit {
			annIDs = cached
			cacheStale = 0
			if stale {
				cacheStale = 1
			}
			leakPre = vault.CountLeaks(docs, annIDs, hint)
			if leakPre > 0 {
				cacheStale = 1
			}
		} else {
			idxs, units, leak := RustScan(qv, bank, cfg.TopK, allowed, hint)
			scanUnits = units
			leakPre = leak
			annIDs = make([]string, 0, len(idxs))
			for _, ix := range idxs {
				if ix >= 0 && ix < len(bank.Rows) {
					annIDs = append(annIDs, bank.Rows[ix].ID)
				}
			}
			vault.I5CachePut(store, qc.Query, hint, annIDs)
		}
		filtered := g4.G4Filter(docs, annIDs, hint)
		reranked := rerankIDs(qv, bank, filtered, cfg.TopK)
		annRec := recallAtK(annIDs, qc.GoldIDs, cfg.TopK)
		nd := ndcgAtK(reranked, qc.GoldIDs, cfg.TopK)
		hits := goldHits(reranked, qc.GoldIDs)
		kept := len(filtered)
		leakPost := vault.CountLeaks(docs, reranked, hint)
		iso := isolationPurity(cfg.TopK, leakPost)
		if len(annIDs) > 0 {
			sumFilter += float64(kept) / float64(len(annIDs))
		}
		report.Queries = append(report.Queries, types.QueryRow{
			QueryID:         qc.QueryID,
			AnnRecallAt10:   round4(annRec),
			IsolationPurity: round4(iso),
			NdcgAt10:        round4(nd),
			GoldHits:        hits,
			FilterKept:      kept,
			LeakCount:       leakPost,
			CacheStale:      cacheStale,
		})
		sumAnn += annRec
		sumNdcg += nd
		sumIso += iso
		if cfg.TopK > 0 {
			sumLeak += float64(leakPre) / float64(cfg.TopK)
		}
		sumStale += float64(cacheStale)
		sumScan += float64(scanUnits)
	}
	n := float64(len(cases))
	if n > 0 {
		report.MeanAnnRecallAt10 = round4(sumAnn / n)
		report.MeanNdcgAt10 = round4(sumNdcg / n)
		report.MeanIsolationPurity = round4(sumIso / n)
		report.LeakRate = round4(sumLeak / n)
		report.FilterSurvivalRate = round4(sumFilter / n)
		report.CacheStaleRate = round4(sumStale / n)
		report.MeanScanUnits = round4(sumScan / n)
	}
	report.PartitionIntegrity = round4(partitionIntegrity(bank, docs, cfg.NumPartitions))
	if report.MeanAnnRecallAt10 < cfg.AnnRecallFloor ||
		report.MeanNdcgAt10 < cfg.NdcgFloor ||
		report.MeanIsolationPurity < cfg.MinIsolationPurity ||
		report.LeakRate > cfg.MaxLeakRate ||
		report.PartitionIntegrity < cfg.MinPartitionIntegrity ||
		report.CacheStaleRate > cfg.MaxCacheStaleRate ||
		report.FilterSurvivalRate < cfg.MinFilterSurvival {
		report.Status = "fail"
	}
	digest, err := digestBody(report)
	if err != nil {
		return types.TenantReport{}, err
	}
	report.ReportDigest = digest
	return report, nil
}

func WriteReport(path string, report types.TenantReport) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, append(raw, '\n'), 0o644)
}

func partitionIntegrity(bank types.Bank, docs []types.CorpusDoc, numParts int) float64 {
	if len(bank.Rows) == 0 {
		return 0
	}
	byID := map[string]types.CorpusDoc{}
	for _, d := range docs {
		byID[d.ID] = d
		if strings.HasSuffix(d.ID, "-rebuild") {
			base := strings.TrimSuffix(d.ID, "-rebuild")
			byID[base+"-rebuild"] = d
		}
	}
	ok := 0
	for _, row := range bank.Rows {
		doc, found := byID[row.ID]
		if !found {
			doc, found = byID[strings.TrimSuffix(row.ID, "-rebuild")]
		}
		if !found {
			continue
		}
		want := index.P1PartID(doc, numParts)
		if row.PartID == want {
			ok++
		}
	}
	return float64(ok) / float64(len(bank.Rows))
}

func isolationPurity(topK, leaks int) float64 {
	if topK <= 0 {
		return 1
	}
	return math.Max(0, 1.0-float64(leaks)/float64(topK))
}

func rerankIDs(qv []float64, bank types.Bank, ids []string, topK int) []string {
	type scored struct {
		id    string
		score float64
	}
	byID := map[string]types.BankRow{}
	for _, row := range bank.Rows {
		byID[row.ID] = row
	}
	pairs := make([]scored, 0, len(ids))
	for _, id := range ids {
		row, ok := byID[id]
		if !ok {
			continue
		}
		pairs = append(pairs, scored{id: id, score: embed.Dot(qv, row.Vec)})
	}
	for i := 0; i < len(pairs); i++ {
		for j := i + 1; j < len(pairs); j++ {
			if pairs[j].score > pairs[i].score {
				pairs[i], pairs[j] = pairs[j], pairs[i]
			}
		}
	}
	if topK <= 0 || topK > len(pairs) {
		topK = len(pairs)
	}
	out := make([]string, 0, topK)
	for i := 0; i < topK; i++ {
		out = append(out, pairs[i].id)
	}
	return out
}

func recallAtK(ranked, gold []string, k int) float64 {
	if len(gold) == 0 {
		return 0
	}
	gset := map[string]struct{}{}
	for _, g := range gold {
		gset[g] = struct{}{}
	}
	if k <= 0 || k > len(ranked) {
		k = len(ranked)
	}
	hits := 0
	for i := 0; i < k; i++ {
		if _, ok := gset[ranked[i]]; ok {
			hits++
		}
	}
	return float64(hits) / float64(len(gset))
}

func ndcgAtK(ranked, gold []string, k int) float64 {
	if len(gold) == 0 {
		return 0
	}
	gset := map[string]struct{}{}
	for _, g := range gold {
		gset[g] = struct{}{}
	}
	if k <= 0 || k > len(ranked) {
		k = len(ranked)
	}
	dcg := 0.0
	for i := 0; i < k; i++ {
		if _, ok := gset[ranked[i]]; ok {
			dcg += 1.0 / math.Log2(float64(i+2))
		}
	}
	idcg := 0.0
	for i := 0; i < len(gold) && i < k; i++ {
		idcg += 1.0 / math.Log2(float64(i+2))
	}
	if idcg == 0 {
		return 0
	}
	return dcg / idcg
}

func goldHits(ranked, gold []string) int {
	gset := map[string]struct{}{}
	for _, g := range gold {
		gset[g] = struct{}{}
	}
	hits := 0
	for _, id := range ranked {
		if _, ok := gset[id]; ok {
			hits++
		}
	}
	return hits
}

func round4(v float64) float64 {
	return math.Round(v*10000) / 10000
}

func digestBody(report types.TenantReport) (string, error) {
	clone := report
	clone.ReportDigest = ""
	raw, err := json.Marshal(clone)
	if err != nil {
		return "", err
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:]), nil
}
