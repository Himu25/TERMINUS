package bench

import (
	"bytes"
	"encoding/json"
	"os/exec"

	"mtisol.lab/pkg/types"
)

type rustRow struct {
	ID     string    `json:"id"`
	Vec    []float64 `json:"vec"`
	PartID int       `json:"part_id"`
	Tenant string    `json:"tenant"`
}

type rustScanIn struct {
	Query         []float64 `json:"query"`
	Rows          []rustRow `json:"rows"`
	TopK          int       `json:"top_k"`
	AllowedParts  []int     `json:"allowed_parts"`
	TenantHint    string    `json:"tenant_hint"`
}

type rustScanOut struct {
	Indices   []int `json:"indices"`
	ScanUnits int64 `json:"scan_units"`
	LeakPre   int   `json:"leak_pre"`
}

func RustScan(query []float64, bank types.Bank, topK int, allowed []int, hint string) ([]int, int64, int) {
	rows := make([]rustRow, 0, len(bank.Rows))
	for _, row := range bank.Rows {
		rows = append(rows, rustRow{
			ID: row.ID, Vec: row.Vec, PartID: row.PartID, Tenant: row.Tenant,
		})
	}
	payload := rustScanIn{
		Query: query, Rows: rows, TopK: topK,
		AllowedParts: allowed, TenantHint: hint,
	}
	raw, err := json.Marshal(payload)
	if err != nil {
		return nil, 0, 0
	}
	cmd := exec.Command("/app/bin/scan")
	cmd.Stdin = bytes.NewReader(raw)
	var stdout bytes.Buffer
	cmd.Stdout = &stdout
	if err := cmd.Run(); err != nil {
		return nil, 0, 0
	}
	var out rustScanOut
	if err := json.Unmarshal(stdout.Bytes(), &out); err != nil {
		return nil, 0, 0
	}
	return out.Indices, out.ScanUnits, out.LeakPre
}
