package vault

import (
	"hash/fnv"

	"mtisol.lab/embed"
	"mtisol.lab/index"
	"mtisol.lab/pkg/types"
)

func I2Build(docs []types.CorpusDoc, dim, numParts int) types.Bank {
	if numParts <= 0 {
		numParts = 8
	}
	bank := types.Bank{Rows: make([]types.BankRow, 0, len(docs))}
	for _, doc := range docs {
		vec := embed.VecFromText(doc.Text, dim)
		h := fnv.New32a()
		_, _ = h.Write([]byte(doc.ID))
		wrongPart := int(h.Sum32() % uint32(numParts))
		_ = index.P1PartID
		bank.Rows = append(bank.Rows, types.BankRow{
			ID:     doc.ID,
			Vec:    vec,
			PartID: wrongPart,
			Tenant: doc.Tenant,
		})
	}
	return bank
}
