"""Validate /app/output/tenant_bench.json against isolation.toml guardrails."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from contextlib import contextmanager
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "tenant_bench.json"
CFG = APP / "config" / "isolation.toml"
RUNNER = APP / "tools" / "run_bench"
FIXTURES = Path(__file__).resolve().parent / "fixtures"
DEFAULT_QUERIES = APP / "data" / "queries_default.jsonl"
QUERY_SPECS = APP / "data" / "query_specs.jsonl"

REPORT_KEYS = frozenset(
    {
        "status",
        "corpus_vectors",
        "vector_dim",
        "queries_total",
        "mean_ann_recall_at_10",
        "mean_isolation_purity",
        "mean_ndcg_at_10",
        "leak_rate",
        "partition_integrity",
        "cache_stale_rate",
        "filter_survival_rate",
        "mean_scan_units",
        "report_digest",
        "queries",
    }
)
QUERY_KEYS = frozenset(
    {
        "query_id",
        "ann_recall_at_10",
        "isolation_purity",
        "ndcg_at_10",
        "gold_hits",
        "filter_kept",
        "leak_count",
        "cache_stale",
    }
)


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "vector_dim": 32,
        "top_k": 10,
        "ann_recall_floor": 0.72,
        "ndcg_floor": 0.72,
        "min_isolation_purity": 0.95,
        "max_leak_rate": 0.05,
        "min_partition_integrity": 0.95,
        "max_cache_stale_rate": 0.0,
        "min_filter_survival": 0.40,
        "tight_security_recall_floor": 0.5,
        "billing_pack_recall_floor": 0.6667,
        "billing_pack_min_gold_hits": 2,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in (
            "ann_recall_floor",
            "ndcg_floor",
            "min_isolation_purity",
            "max_leak_rate",
            "min_partition_integrity",
            "max_cache_stale_rate",
            "min_filter_survival",
            "tight_security_recall_floor",
            "billing_pack_recall_floor",
        ):
            cfg[key] = float(val)
        elif key == "billing_pack_min_gold_hits":
            cfg[key] = int(float(val))
        elif key in ("vector_dim", "top_k"):
            cfg[key] = int(float(val))
    return cfg


def _load_jsonl(path: Path) -> list[dict]:
    rows: list[dict] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            rows.append(json.loads(line))
    return rows


def _query_ids(path: Path) -> list[str]:
    return [str(row["query_id"]) for row in _load_jsonl(path)]


def _tenant_tagged_ids() -> list[str]:
    return [
        str(row["query_id"])
        for row in _load_jsonl(DEFAULT_QUERIES)
        if "tenant:" in str(row.get("query", ""))
    ]


def _billing_default_id() -> str:
    for row in _load_jsonl(QUERY_SPECS):
        query = str(row.get("query", ""))
        if "tenant:billing" in query:
            return str(row["query_id"])
    raise AssertionError("missing billing query in query_specs")


def _pack_dir(tag: str) -> Path:
    matches = sorted(p for p in FIXTURES.iterdir() if p.is_dir() and tag in p.name)
    assert len(matches) == 1, f"expected one pack dir for {tag!r}, found {matches}"
    return matches[0]


def _regress_fixture(stem: str) -> Path:
    matches = sorted(FIXTURES.glob(f"regress_{stem}.*"))
    assert len(matches) == 1, f"expected one regress fixture for {stem!r}, found {matches}"
    return matches[0]


def _scratch_report(label: str) -> Path:
    slug = re.sub(r"[^a-z0-9]+", "_", label.lower()).strip("_")
    return APP / "output" / f"bench_{slug}.json"


def _digest_payload(report: dict) -> dict:
    clone = dict(report)
    clone["report_digest"] = ""
    return clone


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _assert_query_row(row: dict) -> None:
    assert set(row) == QUERY_KEYS
    assert isinstance(row["query_id"], str) and row["query_id"]
    for key in ("ann_recall_at_10", "isolation_purity", "ndcg_at_10"):
        assert isinstance(row[key], (int, float))
        assert 0.0 <= float(row[key]) <= 1.0
    assert isinstance(row["gold_hits"], int) and row["gold_hits"] >= 0
    assert isinstance(row["filter_kept"], int) and row["filter_kept"] >= 0
    assert isinstance(row["leak_count"], int) and row["leak_count"] >= 0
    assert isinstance(row["cache_stale"], int) and row["cache_stale"] in {0, 1}


def _assert_report_schema(data: dict) -> None:
    assert set(data) == REPORT_KEYS
    assert data["status"] in {"ok", "fail"}
    for key in ("corpus_vectors", "vector_dim", "queries_total"):
        assert isinstance(data[key], int) and data[key] >= 0
    for key in (
        "mean_ann_recall_at_10",
        "mean_isolation_purity",
        "mean_ndcg_at_10",
        "leak_rate",
        "partition_integrity",
        "cache_stale_rate",
        "filter_survival_rate",
        "mean_scan_units",
    ):
        assert isinstance(data[key], (int, float))
        assert float(data[key]) >= 0.0
    digest = data["report_digest"]
    assert isinstance(digest, str) and len(digest) == 64
    assert re.fullmatch(r"[0-9a-f]{64}", digest)
    assert isinstance(data["queries"], list)
    for row in data["queries"]:
        _assert_query_row(row)


def _load_report(path: Path = OUT) -> dict:
    assert path.is_file(), f"missing report at {path}"
    data = json.loads(path.read_text(encoding="utf-8"))
    _assert_report_schema(data)
    return data


def _rebuild() -> None:
    subprocess.run(
        ["bash", "/app/tools/build_all"],
        cwd=APP,
        check=True,
        capture_output=True,
        text=True,
    )


def _run_bench(query_path: Path, out_path: Path, corpus_path: Path | None = None) -> None:
    env = os.environ.copy()
    if corpus_path is not None:
        env["TB_CORPUS_PATH"] = str(corpus_path)
    subprocess.run(
        [RUNNER.as_posix(), query_path.as_posix(), out_path.as_posix()],
        cwd=APP,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )


def _row(report: dict, query_id: str) -> dict:
    for row in report["queries"]:
        if row["query_id"] == query_id:
            return row
    raise AssertionError(f"query_id {query_id} not in report")


@pytest.fixture(scope="session")
def cfg() -> dict[str, float | int]:
    return _parse_cfg()


def test_default_report_schema_and_digest(cfg: dict[str, float | int]) -> None:
    """Default tenant_bench.json matches the documented schema and digest rules."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)
    assert report["queries_total"] == len(report["queries"])
    lines = [ln for ln in DEFAULT_QUERIES.read_text(encoding="utf-8").splitlines() if ln.strip()]
    assert report["queries_total"] == len(lines)


def test_default_quality_floors(cfg: dict[str, float | int]) -> None:
    """Default bundle meets isolation.toml mean floors and ceilings."""
    report = _load_report()
    assert report["status"] == "ok"
    assert report["mean_ann_recall_at_10"] >= cfg["ann_recall_floor"]
    assert report["mean_ndcg_at_10"] >= cfg["ndcg_floor"]
    assert report["mean_isolation_purity"] >= cfg["min_isolation_purity"]
    assert report["leak_rate"] <= cfg["max_leak_rate"]
    assert report["partition_integrity"] >= cfg["min_partition_integrity"]
    assert report["cache_stale_rate"] <= cfg["max_cache_stale_rate"]
    assert report["filter_survival_rate"] >= cfg["min_filter_survival"]


def test_tenant_tagged_filter_survival(cfg: dict[str, float | int]) -> None:
    """Tenant-tagged default queries retain candidates through metadata filtering."""
    report = _load_report()
    tagged = [_row(report, qid) for qid in _tenant_tagged_ids()]
    assert tagged, "expected tenant-tagged default queries"
    assert all(row["filter_kept"] > 0 for row in tagged)


def test_billing_default_gold_hits(cfg: dict[str, float | int]) -> None:
    """Default billing query recovers enough gold neighbors."""
    report = _load_report()
    bill = _row(report, _billing_default_id())
    assert bill["gold_hits"] >= cfg["billing_pack_min_gold_hits"]


def test_determinism_byte_identical(cfg: dict[str, float | int]) -> None:
    """Identical inputs produce byte-identical tenant_bench.json."""
    tmp = _scratch_report("repeat")
    _run_bench(DEFAULT_QUERIES, tmp)
    assert OUT.read_bytes() == tmp.read_bytes()


def test_fixture_tight_pack(cfg: dict[str, float | int]) -> None:
    """Tight security fixture pack benches clean with valid digest."""
    pack = _pack_dir("tight")
    out = _scratch_report("pack_tight")
    queries = pack / "queries.jsonl"
    _run_bench(queries, out, pack / "corpus.json")
    report = _load_report(out)
    assert report["report_digest"] == _expected_digest(report)
    tight_id = _query_ids(queries)[0]
    tight = _row(report, tight_id)
    assert tight["ann_recall_at_10"] >= cfg["tight_security_recall_floor"]
    assert report["leak_rate"] <= cfg["max_leak_rate"]


def test_fixture_billing_pack(cfg: dict[str, float | int]) -> None:
    """Billing fixture pack meets recall and gold-hit floors."""
    pack = _pack_dir("billing")
    out = _scratch_report("pack_billing")
    queries = pack / "queries.jsonl"
    _run_bench(queries, out, pack / "corpus.json")
    report = _load_report(out)
    assert report["report_digest"] == _expected_digest(report)
    row = _row(report, _query_ids(queries)[0])
    assert row["ann_recall_at_10"] >= cfg["billing_pack_recall_floor"]
    assert row["gold_hits"] >= cfg["billing_pack_min_gold_hits"]
    assert report["leak_rate"] <= cfg["max_leak_rate"]


@contextmanager
def _ablation(fixture: Path, *dest_parts: str):
    dest_path = APP.joinpath(*dest_parts)
    backup = dest_path.read_text(encoding="utf-8")
    try:
        shutil.copy(fixture, dest_path)
        _rebuild()
        yield
    finally:
        dest_path.write_text(backup, encoding="utf-8")
        _rebuild()


def test_ablation_broken_cache_fails(cfg: dict[str, float | int]) -> None:
    """Reverting cache tenant scoping must produce stale cross-tenant cache hits."""
    pack = _pack_dir("cache")
    out = _scratch_report("ablation_cache")
    queries = pack / "queries.jsonl"
    with _ablation(_regress_fixture("k2_store"), "k2", "k2_store.go"):
        _run_bench(queries, out, pack / "corpus.json")
        report = _load_report(out)
        assert report["cache_stale_rate"] > cfg["max_cache_stale_rate"]


def test_ablation_broken_gate_fails(cfg: dict[str, float | int]) -> None:
    """Reverting metadata gate must drop filter survival."""
    out = _scratch_report("ablation_gate")
    with _ablation(_regress_fixture("g4_scope"), "g4", "g4_scope.go"):
        _run_bench(DEFAULT_QUERIES, out)
        report = _load_report(out)
        assert report["status"] == "fail" or report["filter_survival_rate"] < cfg["min_filter_survival"]


def test_ablation_broken_scan_fails(cfg: dict[str, float | int]) -> None:
    """Reverting partition-scoped Rust scan must raise leak_rate."""
    out = _scratch_report("ablation_scan")
    with _ablation(_regress_fixture("scan"), "scan", "src", "main.rs"):
        _run_bench(DEFAULT_QUERIES, out)
        report = _load_report(out)
        assert report["status"] == "fail" or report["leak_rate"] > cfg["max_leak_rate"]


def test_ablation_broken_route_fails(cfg: dict[str, float | int]) -> None:
    """Reverting tenant-aware partition routing must hurt partition_integrity."""
    out = _scratch_report("ablation_route")
    with _ablation(_regress_fixture("p1_route"), "index", "p1_route.go"):
        _run_bench(DEFAULT_QUERIES, out)
        report = _load_report(out)
        assert report["status"] == "fail" or report["partition_integrity"] < cfg["min_partition_integrity"]


def test_ablation_broken_rebuild_fails(cfg: dict[str, float | int]) -> None:
    """Reverting scoped partial rebuild must break partition_integrity."""
    out = _scratch_report("rebuild")
    with _ablation(_regress_fixture("r3_rebuild"), "index", "r3_rebuild.go"):
        _run_bench(DEFAULT_QUERIES, out)
        report = _load_report(out)
        assert report["status"] == "fail" or report["partition_integrity"] < cfg["min_partition_integrity"]


def test_ablation_broken_bank_fails(cfg: dict[str, float | int]) -> None:
    """Reverting partition ids on vault load must break partition_integrity."""
    out = _scratch_report("ablation_vault")
    with _ablation(_regress_fixture("i2_load"), "vault", "i2_load.go"):
        _run_bench(DEFAULT_QUERIES, out)
        report = _load_report(out)
        assert report["status"] == "fail" or report["partition_integrity"] < cfg["min_partition_integrity"]
