package main

import (
	"log"
	"os"

	"lab.local/scope_federation_rate_audit/internal/driver"
)

func main() {
	if os.Getenv("TB_FEDERATE_FIXTURE") != "1" {
		log.Fatal("TB_FEDERATE_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/federation_audit_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
