module lab.local/scope_federation_rate_audit

go 1.22
