# Scope federation rate audit

Mixed Rust token-bucket refill and Go policy broker for edge cluster admission replay.

Run `/app/bin/federate_audit_run` with `TB_FEDERATE_FIXTURE=1` after building via `/app/scripts/build.sh`.
