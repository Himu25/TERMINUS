# Federation rate audit replay layout

Each pack under `/app/data` carries:

- `cluster_plan.json` — run id, partition epoch cutoff, scope rows, and opening token balances.
- `traffic_tape.jsonl` — ordered admission probes with tick, scope, client, and units.
- `sync_journal.jsonl` — optional federation sync rows with epoch, scope, remote token balance, and sequence.

Replay applies the sync journal against the partition epoch, merges duplicate scopes by sequence, refills token buckets through the Rust bridge using each scope rate and refill binding, clamps to capacity, then walks the traffic tape for admission decisions. The Go broker emits allowed and denied totals plus sync bookkeeping.

The audit report lives at `/app/output/federation_audit_report.json`.
