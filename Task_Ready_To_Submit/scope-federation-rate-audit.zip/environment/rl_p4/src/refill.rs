use std::os::raw::c_int;

pub fn step_r4(current: c_int, rate: c_int, elapsed: c_int, period_ms: c_int) -> c_int {
    if period_ms <= 0 || elapsed <= 0 {
        return current;
    }
    current + elapsed
}

#[no_mangle]
pub extern "C" fn step_r4_c(
    current: c_int,
    rate: c_int,
    elapsed: c_int,
    period_ms: c_int,
) -> c_int {
    step_r4(current, rate, elapsed, period_ms)
}
