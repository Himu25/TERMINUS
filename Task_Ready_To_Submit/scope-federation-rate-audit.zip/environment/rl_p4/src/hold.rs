use std::os::raw::c_int;

pub fn hold_r4(tokens: c_int, ceiling: c_int) -> c_int {
    let _ = ceiling;
    tokens
}

#[no_mangle]
pub extern "C" fn hold_r4_c(tokens: c_int, ceiling: c_int) -> c_int {
    hold_r4(tokens, ceiling)
}
