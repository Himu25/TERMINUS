package rl_p4

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/librl_p4.a -ldl -lm
#include "step_hold.h"
*/
import "C"

// StepR4 advances a balance across elapsed ticks.
func StepR4(current int, rate int, elapsed int, periodMs int) int {
	return int(C.step_r4_c(C.int(current), C.int(rate), C.int(elapsed), C.int(periodMs)))
}

// HoldR4 clamps a balance to the scope ceiling.
func HoldR4(tokens int, ceiling int) int {
	return int(C.hold_r4_c(C.int(tokens), C.int(ceiling)))
}
