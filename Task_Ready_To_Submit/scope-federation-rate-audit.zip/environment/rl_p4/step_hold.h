#ifndef RL_P4_STEP_HOLD_H
#define RL_P4_STEP_HOLD_H

#include <stdint.h>

int32_t step_r4_c(int32_t current, int32_t rate, int32_t elapsed, int32_t period_ms);
int32_t hold_r4_c(int32_t tokens, int32_t ceiling);

#endif
