Edge cluster scope federation rate audit — Rust refill bridge plus Go policy broker.

Build with `/app/scripts/build.sh`, run `/app/bin/federate_audit_run` with `TB_FEDERATE_FIXTURE=1`.
