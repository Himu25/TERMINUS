package main

import (
	"fmt"
	"os"

	"lab.local/scope_federation_rate_audit/pkg/digest"
)

func main() {
	if len(os.Args) != 7 {
		fmt.Fprintln(os.Stderr, "usage: digest_cli run_id allowed denied refill_ms sync_rows partition_ticks")
		os.Exit(2)
	}
	fmt.Println(digest.Hex(os.Args[1], atoi(os.Args[2]), atoi(os.Args[3]), atoi(os.Args[4]), atoi(os.Args[5]), atoi(os.Args[6])))
}

func atoi(s string) int {
	n := 0
	for _, ch := range s {
		if ch < '0' || ch > '9' {
			continue
		}
		n = n*10 + int(ch-'0')
	}
	return n
}
