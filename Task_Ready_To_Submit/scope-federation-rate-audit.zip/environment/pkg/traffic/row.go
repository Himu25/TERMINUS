package traffic

// Row is one deterministic traffic tape event.
type Row struct {
	Tick   int    `json:"tick"`
	Scope  string `json:"scope"`
	Client string `json:"client"`
	Units  int    `json:"units"`
}
