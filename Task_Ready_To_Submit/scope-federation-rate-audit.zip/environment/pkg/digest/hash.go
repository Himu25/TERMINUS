package digest

import (
	"crypto/sha256"
	"fmt"
	"strings"
)

// Hex seals the scalar counters for replay verification.
func Hex(runID string, allowed int, denied int, refillMs int, syncRows int, partTicks int) string {
	payload := strings.Join([]string{
		runID,
		fmt.Sprintf("%d", allowed),
		fmt.Sprintf("%d", denied),
		fmt.Sprintf("%d", refillMs),
		fmt.Sprintf("%d", syncRows),
		fmt.Sprintf("%d", partTicks),
	}, "|")
	sum := sha256.Sum256([]byte(payload))
	return fmt.Sprintf("%x", sum)
}
