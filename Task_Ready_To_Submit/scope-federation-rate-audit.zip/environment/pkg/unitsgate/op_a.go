package unitsgate

// OpA decides admission when pending units are compared to available tokens.
func OpA(units int, available int) bool {
	return available < units
}
