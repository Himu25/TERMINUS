package unitsgate

// OpB normalizes request weight before downstream accounting.
func OpB(units int, weight int) int {
	if weight <= 0 {
		return units
	}
	return units * weight
}
