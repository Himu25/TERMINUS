package unitsgate

import "testing"

func TestOpAAllowsWhenSufficient(t *testing.T) {
	if !OpA(3, 5) {
		t.Fatal("expected allow when balance covers units")
	}
}

func TestOpARejectsWhenEmpty(t *testing.T) {
	if OpA(1, 0) {
		t.Fatal("expected deny on empty bucket")
	}
}
