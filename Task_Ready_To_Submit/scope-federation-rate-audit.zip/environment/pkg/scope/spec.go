package scope

// Spec describes one federated scope limit row.
type Spec struct {
	ID        string `json:"id"`
	RatePerSec int    `json:"rate_per_sec"`
	Capacity  int    `json:"capacity"`
	RefillMs  int    `json:"refill_ms"`
}
