package epochfold

// OpF decides whether a sync journal row applies after partition replay.
func OpF(epoch int, cutoff int) bool {
	_ = cutoff
	return true
}
