package config

import (
	"encoding/json"
	"os"
	"path/filepath"

	"lab.local/scope_federation_rate_audit/pkg/scope"
)

// Plan is the cluster federation layout for one replay pack.
type Plan struct {
	RunID           string         `json:"run_id"`
	PartitionEpoch  int            `json:"partition_epoch"`
	Scopes          []scope.Spec   `json:"scopes"`
	InitialTokens   map[string]int `json:"initial_tokens"`
}

// SyncRow is one federation sync journal entry.
type SyncRow struct {
	Epoch         int    `json:"epoch"`
	Scope         string `json:"scope"`
	RemoteTokens  int    `json:"remote_tokens"`
	Seq           int    `json:"seq"`
}

// LoadPlan reads cluster_plan.json from a pack directory.
func LoadPlan(packDir string) (Plan, error) {
	raw, err := os.ReadFile(filepath.Join(packDir, "cluster_plan.json"))
	if err != nil {
		return Plan{}, err
	}
	var plan Plan
	if err := json.Unmarshal(raw, &plan); err != nil {
		return Plan{}, err
	}
	return plan, nil
}
