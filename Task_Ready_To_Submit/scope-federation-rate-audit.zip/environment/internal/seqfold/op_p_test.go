package seqfold

import "testing"

func TestOpPPrefersHigherSeq(t *testing.T) {
	if !OpP(5, 2) {
		t.Fatal("expected higher sequence to win")
	}
	if OpP(2, 5) {
		t.Fatal("expected lower sequence to lose")
	}
}
