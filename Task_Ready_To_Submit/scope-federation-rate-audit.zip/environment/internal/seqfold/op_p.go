package seqfold

// OpP picks the winning sync row when two rows target the same scope.
func OpP(candidateSeq int, incumbentSeq int) bool {
	return candidateSeq < incumbentSeq
}
