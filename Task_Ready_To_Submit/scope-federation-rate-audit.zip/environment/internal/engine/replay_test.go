package engine

import (
	"testing"

	"lab.local/scope_federation_rate_audit/internal/config"
	"lab.local/scope_federation_rate_audit/pkg/scope"
	"lab.local/scope_federation_rate_audit/pkg/traffic"
)

func TestReplayEmptyTape(t *testing.T) {
	plan := config.Plan{
		RunID: "t-empty",
		Scopes: []scope.Spec{
			{ID: "s1", RatePerSec: 1, Capacity: 5, RefillMs: 10},
		},
		InitialTokens: map[string]int{"s1": 2},
	}
	out := Replay(plan, nil, nil)
	if out.AllowedCount != 0 || out.DeniedCount != 0 {
		t.Fatalf("unexpected counters: %+v", out)
	}
}

func TestReplaySingleAllow(t *testing.T) {
	plan := config.Plan{
		RunID: "t-one",
		Scopes: []scope.Spec{
			{ID: "s1", RatePerSec: 1, Capacity: 5, RefillMs: 10},
		},
		InitialTokens: map[string]int{"s1": 3},
	}
	events := []traffic.Row{{Tick: 1, Scope: "s1", Client: "c", Units: 1}}
	out := Replay(plan, events, nil)
	if out.AllowedCount+out.DeniedCount != 1 {
		t.Fatalf("expected one decision, got %+v", out)
	}
}
