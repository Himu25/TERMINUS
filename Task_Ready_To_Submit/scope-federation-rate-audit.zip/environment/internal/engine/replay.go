package engine

import (
	"lab.local/scope_federation_rate_audit/internal/config"
	"lab.local/scope_federation_rate_audit/internal/syncfold"
	"lab.local/scope_federation_rate_audit/pkg/unitsgate"
	"lab.local/scope_federation_rate_audit/pkg/scope"
	"lab.local/scope_federation_rate_audit/pkg/traffic"
	"lab.local/scope_federation_rate_audit/rl_p4"
)

// Outcome is the folded counters for one pack replay.
type Outcome struct {
	AllowedCount    int
	DeniedCount     int
	RefillBindingMs int
	SyncRowsApplied int
	PartitionTicks  int
}

// Replay executes one traffic pack through the federation audit pipeline.
func Replay(plan config.Plan, events []traffic.Row, sync []config.SyncRow) Outcome {
	specByID := map[string]scope.Spec{}
	for _, row := range plan.Scopes {
		specByID[row.ID] = row
	}
	tokens := map[string]int{}
	for scope, bal := range plan.InitialTokens {
		tokens[scope] = bal
	}
	syncOut := syncfold.Apply(sync, plan.PartitionEpoch, tokens)

	refillMs := 0
	if len(plan.Scopes) > 0 {
		refillMs = plan.Scopes[0].RefillMs
	}

	lastTick := map[string]int{}
	allowed := 0
	denied := 0
	for _, evt := range events {
		spec, ok := specByID[evt.Scope]
		if !ok {
			denied++
			continue
		}
		prev := lastTick[evt.Scope]
		elapsed := evt.Tick - prev
		if prev == 0 {
			elapsed = evt.Tick
		}
		cur := tokens[evt.Scope]
		cur = rl_p4.StepR4(cur, spec.RatePerSec, elapsed, spec.RefillMs)
		cur = rl_p4.HoldR4(cur, spec.Capacity)
		if unitsgate.OpA(evt.Units, cur) {
			cur -= evt.Units
			allowed++
		} else {
			denied++
		}
		tokens[evt.Scope] = cur
		lastTick[evt.Scope] = evt.Tick
	}

	return Outcome{
		AllowedCount:    allowed,
		DeniedCount:     denied,
		RefillBindingMs: refillMs,
		SyncRowsApplied: syncOut.Applied,
		PartitionTicks:  syncOut.PartitionTick,
	}
}
