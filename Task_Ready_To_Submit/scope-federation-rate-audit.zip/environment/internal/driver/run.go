package driver

import (
	"bufio"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"

	"lab.local/scope_federation_rate_audit/internal/config"
	"lab.local/scope_federation_rate_audit/internal/engine"
	"lab.local/scope_federation_rate_audit/pkg/digest"
	"lab.local/scope_federation_rate_audit/pkg/traffic"
)

type report struct {
	SchemaVersion   string `json:"schema_version"`
	RunID           string `json:"run_id"`
	AllowedCount    int    `json:"allowed_count"`
	DeniedCount     int    `json:"denied_count"`
	RefillBindingMs int    `json:"refill_binding_ms"`
	SyncRowsApplied int    `json:"sync_rows_applied"`
	PartitionTicks  int    `json:"partition_ticks"`
	DigestHex       string `json:"digest_hex"`
}

// RunActive replays the pack linked from /app/data/active.
func RunActive(appRoot string) (report, error) {
	return RunPack(filepath.Join(appRoot, "data", "active"))
}

// RunPack replays one fixture directory.
func RunPack(packDir string) (report, error) {
	plan, err := config.LoadPlan(packDir)
	if err != nil {
		return report{}, err
	}
	events, err := loadTraffic(filepath.Join(packDir, "traffic_tape.jsonl"))
	if err != nil {
		return report{}, err
	}
	sync, err := loadSync(filepath.Join(packDir, "sync_journal.jsonl"))
	if err != nil {
		return report{}, err
	}
	out := engine.Replay(plan, events, sync)
	rep := report{
		SchemaVersion:   "1",
		RunID:           plan.RunID,
		AllowedCount:    out.AllowedCount,
		DeniedCount:     out.DeniedCount,
		RefillBindingMs: out.RefillBindingMs,
		SyncRowsApplied: out.SyncRowsApplied,
		PartitionTicks:  out.PartitionTicks,
		DigestHex: digest.Hex(
			plan.RunID,
			out.AllowedCount,
			out.DeniedCount,
			out.RefillBindingMs,
			out.SyncRowsApplied,
			out.PartitionTicks,
		),
	}
	return rep, nil
}

// EmitReport writes the JSON artifact.
func EmitReport(path string, rep report) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}

func loadTraffic(path string) ([]traffic.Row, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := []traffic.Row{}
	scan := bufio.NewScanner(f)
	for scan.Scan() {
		line := strings.TrimSpace(scan.Text())
		if line == "" {
			continue
		}
		var row traffic.Row
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return nil, err
		}
		out = append(out, row)
	}
	return out, scan.Err()
}

func loadSync(path string) ([]config.SyncRow, error) {
	f, err := os.Open(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	defer f.Close()
	out := []config.SyncRow{}
	scan := bufio.NewScanner(f)
	for scan.Scan() {
		line := strings.TrimSpace(scan.Text())
		if line == "" {
			continue
		}
		var row config.SyncRow
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return nil, err
		}
		out = append(out, row)
	}
	return out, scan.Err()
}
