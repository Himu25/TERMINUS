package syncfold

import (
	"lab.local/scope_federation_rate_audit/internal/config"
	"lab.local/scope_federation_rate_audit/internal/epochfold"
	"lab.local/scope_federation_rate_audit/internal/seqfold"
)

// Result holds counters from applying the sync journal.
type Result struct {
	Applied       int
	PartitionTick int
}

// Apply merges federation sync rows into working token balances.
func Apply(rows []config.SyncRow, cutoff int, tokens map[string]int) Result {
	winners := map[string]config.SyncRow{}
	for _, row := range rows {
		if !epochfold.OpF(row.Epoch, cutoff) {
			continue
		}
		if prev, ok := winners[row.Scope]; ok {
			if seqfold.OpP(row.Seq, prev.Seq) {
				winners[row.Scope] = row
			}
		} else {
			winners[row.Scope] = row
		}
	}
	out := Result{}
	for scope, row := range winners {
		tokens[scope] = row.RemoteTokens
		out.Applied++
		if row.Epoch > out.PartitionTick {
			out.PartitionTick = row.Epoch
		}
	}
	return out
}
