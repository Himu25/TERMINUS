#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

write_go_gate() {
  cat > /app/pkg/unitsgate/op_a.go <<'EOF'
package unitsgate

// OpA decides admission when pending units are compared to available tokens.
func OpA(units int, available int) bool {
	if units <= 0 {
		return true
	}
	if available < 0 {
		return false
	}
	return available >= units
}
EOF
}

write_go_epoch() {
  cat > /app/internal/epochfold/op_f.go <<'EOF'
package epochfold

// OpF decides whether a sync journal row applies after partition replay.
func OpF(epoch int, cutoff int) bool {
	if cutoff <= 0 {
		return epoch >= 0
	}
	return epoch >= cutoff
}
EOF
}

write_go_seq() {
  cat > /app/internal/seqfold/op_p.go <<'EOF'
package seqfold

// OpP picks the winning sync row when two rows target the same scope.
func OpP(candidateSeq int, incumbentSeq int) bool {
	if candidateSeq == incumbentSeq {
		return false
	}
	return candidateSeq > incumbentSeq
}
EOF
}

write_rust_refill() {
  cat > /app/rl_p4/src/refill.rs <<'EOF'
use std::os::raw::c_int;

pub fn step_r4(current: c_int, rate: c_int, elapsed: c_int, period_ms: c_int) -> c_int {
    if period_ms <= 0 || elapsed <= 0 {
        return current;
    }
    if rate <= 0 {
        return current;
    }
    current + (elapsed * rate) / period_ms
}

#[no_mangle]
pub extern "C" fn step_r4_c(
    current: c_int,
    rate: c_int,
    elapsed: c_int,
    period_ms: c_int,
) -> c_int {
    step_r4(current, rate, elapsed, period_ms)
}
EOF
}

write_rust_hold() {
  cat > /app/rl_p4/src/hold.rs <<'EOF'
use std::os::raw::c_int;

pub fn hold_r4(tokens: c_int, ceiling: c_int) -> c_int {
    if ceiling <= 0 {
        return tokens;
    }
    if tokens > ceiling {
        return ceiling;
    }
    tokens
}

#[no_mangle]
pub extern "C" fn hold_r4_c(tokens: c_int, ceiling: c_int) -> c_int {
    hold_r4(tokens, ceiling)
}
EOF
}

write_go_gate
write_go_epoch
write_go_seq
write_rust_refill
write_rust_hold

bash /app/scripts/build.sh

rm -f /app/output/federation_audit_report.json
mkdir -p /app/output
TB_FEDERATE_FIXTURE=1 /app/bin/federate_audit_run
test -s /app/output/federation_audit_report.json

GOFLAGS=-mod=mod go test ./...

python3 <<'PY'
import json
from pathlib import Path

rep = json.loads(Path("/app/output/federation_audit_report.json").read_text())
for key in (
    "schema_version",
    "run_id",
    "allowed_count",
    "denied_count",
    "refill_binding_ms",
    "sync_rows_applied",
    "partition_ticks",
    "digest_hex",
):
    if key not in rep:
        raise SystemExit(f"missing {key}")
PY
