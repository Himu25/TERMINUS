"""Verifier for scope federation rate audit report."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = APP / "data" / "replay"
OUT = APP / "output" / "federation_audit_report.json"
SCHEMA = APP / "schemas" / "federation_audit_report.schema.json"
GO_BIN = "/usr/local/go/bin/go"
VERIFY_BIN = "/app/bin/federate_audit_run"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:/usr/local/go/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _digest_hex(
    run_id: str,
    allowed: int,
    denied: int,
    refill_ms: int,
    sync_rows: int,
    part_ticks: int,
) -> str:
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            run_id,
            str(allowed),
            str(denied),
            str(refill_ms),
            str(sync_rows),
            str(part_ticks),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _op_a(units: int, available: int) -> bool:
    return available >= units


def _op_f(epoch: int, cutoff: int) -> bool:
    return epoch >= cutoff


def _op_p(candidate: int, incumbent: int) -> bool:
    return candidate > incumbent


def _refill(current: int, rate: int, elapsed: int, period_ms: int) -> int:
    if period_ms <= 0 or elapsed <= 0:
        return current
    return current + (elapsed * rate) // period_ms


def _cap_hold(tokens: int, ceiling: int) -> int:
    if ceiling <= 0:
        return tokens
    return min(tokens, ceiling)


def _load_pack(pack_dir: Path) -> tuple[dict, list[dict], list[dict]]:
    plan = json.loads((pack_dir / "cluster_plan.json").read_text())
    events: list[dict] = []
    for line in (pack_dir / "traffic_tape.jsonl").read_text().splitlines():
        if line.strip():
            events.append(json.loads(line))
    sync: list[dict] = []
    sync_path = pack_dir / "sync_journal.jsonl"
    if sync_path.exists():
        for line in sync_path.read_text().splitlines():
            if line.strip():
                sync.append(json.loads(line))
    return plan, events, sync


def _apply_sync(rows: list[dict], cutoff: int, tokens: dict[str, int]) -> tuple[int, int]:
    winners: dict[str, dict] = {}
    for row in rows:
        if not _op_f(row["epoch"], cutoff):
            continue
        scope = row["scope"]
        if scope in winners:
            prev = winners[scope]
            if _op_p(row["seq"], prev["seq"]):
                winners[scope] = row
        else:
            winners[scope] = row
    applied = 0
    part_tick = 0
    for scope, row in winners.items():
        tokens[scope] = row["remote_tokens"]
        applied += 1
        if row["epoch"] > part_tick:
            part_tick = row["epoch"]
    return applied, part_tick


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = FIXTURES / pack_name
    plan, events, sync = _load_pack(pack_dir)
    spec_by_id = {row["id"]: row for row in plan["scopes"]}
    tokens = dict(plan["initial_tokens"])
    sync_applied, part_ticks = _apply_sync(sync, plan["partition_epoch"], tokens)
    refill_ms = plan["scopes"][0]["refill_ms"] if plan["scopes"] else 0

    last_tick: dict[str, int] = {}
    allowed = 0
    denied = 0
    for evt in events:
        spec = spec_by_id.get(evt["scope"])
        if spec is None:
            denied += 1
            continue
        prev = last_tick.get(evt["scope"], 0)
        elapsed = evt["tick"] - prev if prev else evt["tick"]
        cur = tokens.get(evt["scope"], 0)
        cur = _refill(cur, spec["rate_per_sec"], elapsed, spec["refill_ms"])
        cur = _cap_hold(cur, spec["capacity"])
        if _op_a(evt["units"], cur):
            cur -= evt["units"]
            allowed += 1
        else:
            denied += 1
        tokens[evt["scope"]] = cur
        last_tick[evt["scope"]] = evt["tick"]

    digest = _digest_hex(
        plan["run_id"],
        allowed,
        denied,
        refill_ms,
        sync_applied,
        part_ticks,
    )
    return {
        "schema_version": "1",
        "run_id": plan["run_id"],
        "allowed_count": allowed,
        "denied_count": denied,
        "refill_binding_ms": refill_ms,
        "sync_rows_applied": sync_applied,
        "partition_ticks": part_ticks,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {
        **os.environ,
        "TB_FEDERATE_FIXTURE": "1",
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
    }
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def _validate_report_schema(report: dict, schema: dict) -> None:
    for key in schema["required"]:
        assert key in report
    assert isinstance(report["schema_version"], str)
    assert isinstance(report["run_id"], str)
    for int_key in (
        "allowed_count",
        "denied_count",
        "refill_binding_ms",
        "sync_rows_applied",
        "partition_ticks",
    ):
        assert isinstance(report[int_key], int)
    assert isinstance(report["digest_hex"], str)


def test_report_satisfies_schema() -> None:
    """Emitted report must validate against the federation audit JSON schema."""
    schema = json.loads(SCHEMA.read_text())
    _swap("traffic_alpha")
    got = _run_tool()
    _validate_report_schema(got, schema)


def test_alpha_report_matches_replay() -> None:
    """Alpha pack should replay with full admission totals and digest."""
    _swap("traffic_alpha")
    exp = _expected_from_fixture("traffic_alpha")
    got = _run_tool()
    assert got == exp


def test_alpha_admission_totals() -> None:
    """Alpha should admit every probe when buckets carry enough tokens."""
    _swap("traffic_alpha")
    exp = _expected_from_fixture("traffic_alpha")
    got = _run_tool()
    assert got["allowed_count"] == exp["allowed_count"]
    assert got["denied_count"] == exp["denied_count"]


def test_beta_stale_sync_row_dropped() -> None:
    """Beta must ignore the pre-cutoff sync row and keep the opening balance."""
    _swap("traffic_beta")
    exp = _expected_from_fixture("traffic_beta")
    got = _run_tool()
    assert got["sync_rows_applied"] == exp["sync_rows_applied"]
    assert got["allowed_count"] == exp["allowed_count"]
    assert got["denied_count"] == exp["denied_count"]


def test_gamma_sync_merge_winner() -> None:
    """Gamma should merge the higher sequence sync row before admission."""
    _swap("traffic_gamma")
    exp = _expected_from_fixture("traffic_gamma")
    got = _run_tool()
    assert got["partition_ticks"] == exp["partition_ticks"]
    assert got["allowed_count"] == exp["allowed_count"]


def test_delta_refill_binding() -> None:
    """Delta should refill from the long idle gap using the scope rate binding."""
    _swap("traffic_delta")
    exp = _expected_from_fixture("traffic_delta")
    got = _run_tool()
    assert got["refill_binding_ms"] == exp["refill_binding_ms"]
    assert got["denied_count"] == exp["denied_count"]


def test_epsilon_capacity_clamp() -> None:
    """Epsilon should clamp merged remote tokens to scope capacity before admission."""
    _swap("traffic_epsilon")
    exp = _expected_from_fixture("traffic_epsilon")
    got = _run_tool()
    assert got["denied_count"] == exp["denied_count"]
    assert got["allowed_count"] == exp["allowed_count"]


def test_go_subsystem_tests_pass() -> None:
    """Go tests under /app must pass after the repair."""
    subprocess.run(
        [GO_BIN, "test", "./..."],
        cwd="/app",
        env={
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:/usr/local/go/bin:" + os.environ.get("PATH", ""),
        },
        check=True,
    )
