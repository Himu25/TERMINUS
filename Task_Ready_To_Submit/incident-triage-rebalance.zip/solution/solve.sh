#!/usr/bin/env bash
set -euo pipefail

# Terminal-Bench Canary: incident-triage-rebalance (solve.sh)

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/pkg/collapsgate/op_p.go <<'EOF'
package collapsgate

func gateMet(count int, need int) bool {
	if need <= 0 {
		return false
	}
	if count < 0 {
		return false
	}
	return count >= need
}

// GateP decides whether a cascade group has enough correlated alerts to collapse.
func GateP(correlatedCount int, need int) bool {
	return gateMet(correlatedCount, need)
}
EOF

cat > /app/pkg/labelnorm/op_v.go <<'EOF'
package labelnorm

func normalizeSeverity(severity int, confidence int, cutoff int) int {
	if confidence >= cutoff {
		return severity
	}
	if severity <= 1 {
		return 1
	}
	return severity - 1
}

// OpV returns the effective severity after label confidence is applied.
func OpV(severity int, confidence int, cutoff int) int {
	return normalizeSeverity(severity, confidence, cutoff)
}
EOF

cat > /app/internal/resfilter/op_r.go <<'EOF'
package resfilter

// OpR decides whether a historical resolution may influence queue scoring.
func OpR(code string, trusted bool) bool {
	_ = code
	return trusted
}
EOF

cat > /app/pkg/recallfloor/op_m.go <<'EOF'
package recallfloor

// OpM checks whether enough critical alerts remain in the queue head.
func OpM(inHead int, need int) bool {
	return inHead >= need
}
EOF

cat > /app/rankgate/src/lib.rs <<'EOF'
use std::os::raw::c_longlong;

/// SgBlendRank applies cascade decay to a parent rank score.
#[no_mangle]
pub extern "C" fn sg_blend_rank(base: c_longlong, decay: c_longlong) -> c_longlong {
    base - decay
}
EOF

bash /app/scripts/build.sh

rm -f /app/output/triage_report.json
mkdir -p /app/output
TB_TRIAGE_FIXTURE=1 /app/bin/triage_run
test -s /app/output/triage_report.json

GOFLAGS=-mod=mod go test ./...
