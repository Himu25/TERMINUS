"""Verifier for incident triage rebalance report."""

import json
import os
import shutil
import subprocess

import pytest
from pathlib import Path

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = APP / "data" / "replay"
OUT = APP / "output" / "triage_report.json"
GO_BIN = "/usr/local/go/bin/go"
VERIFY_BIN = "/tmp/triage_run_verify_bin"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)
    subprocess.run(["cp", "/app/bin/triage_run", VERIFY_BIN], check=True)


def _digest_hex(
    run_id: str,
    queue_depth: int,
    critical_recall_pct: int,
    noise_suppressed: int,
    cascade_groups: int,
    label_repair_count: int,
    recall_floor_hits: int,
    fatigue_band: str,
) -> str:
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            run_id,
            str(queue_depth),
            str(critical_recall_pct),
            str(noise_suppressed),
            str(cascade_groups),
            str(label_repair_count),
            str(recall_floor_hits),
            fatigue_band,
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _op_v(severity: int, confidence: int, cutoff: int) -> int:
    if confidence >= cutoff:
        return severity
    return max(1, severity - 1)


def _op_r(_code: str, trusted: bool) -> bool:
    return trusted


def _gate_p(count: int, need: int) -> bool:
    return count >= need if need > 0 else False


def _blend_rank(base: int, decay: int) -> int:
    return base - decay


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = FIXTURES / pack_name
    bundle = json.loads((pack_dir / "alert_bundle.json").read_text())
    rows = []
    for line in (pack_dir / "alerts.jsonl").read_text().splitlines():
        if line.strip():
            rows.append(json.loads(line))
    hist = {}
    hist_path = pack_dir / "history.jsonl"
    if hist_path.exists():
        for line in hist_path.read_text().splitlines():
            if line.strip():
                item = json.loads(line)
                hist[item["alert_id"]] = item
    rows.sort(key=lambda r: r["ts_ms"])

    items = []
    noise = 0
    repairs = 0
    for row in rows:
        raw = row["severity"]
        eff = _op_v(row["severity"], row["label_confidence"], bundle["label_cutoff"])
        if eff < raw:
            noise += 1
        tier = eff
        if row["alert_id"] in hist:
            res = hist[row["alert_id"]]
            if _op_r(res["code"], res["trusted"]):
                if eff > 1:
                    eff -= 1
                    repairs += 1
        rank = eff * 1000 + (999999 - row["ts_ms"] % 1000000)
        items.append({"row": row, "rank": rank, "tier": tier})

    groups = []
    if items:
        cur = [0]
        root = items[0]["row"]["cascade_root"]
        last_ts = items[0]["row"]["ts_ms"]
        for i in range(1, len(items)):
            row = items[i]["row"]
            if row["cascade_root"] == root and row["ts_ms"] - last_ts <= bundle["correlation_ms"]:
                cur.append(i)
                last_ts = row["ts_ms"]
            else:
                groups.append(cur)
                cur = [i]
                root = row["cascade_root"]
                last_ts = row["ts_ms"]
        groups.append(cur)

    cascade_groups = 0
    queue = []
    used = [False] * len(items)
    for g in groups:
        if _gate_p(len(g), bundle["q_size"]):
            cascade_groups += 1
            parent = items[g[0]]
            queue.append({"id": parent["row"]["alert_id"], "rank": parent["rank"], "tier": parent["tier"]})
            for i, idx in enumerate(g):
                used[idx] = True
                if i == 0:
                    continue
                child = items[idx]
                blended = _blend_rank(parent["rank"], i * 15)
                queue.append({"id": child["row"]["alert_id"], "rank": blended, "tier": child["tier"]})
            continue
        for idx in g:
            if used[idx]:
                continue
            it = items[idx]
            queue.append({"id": it["row"]["alert_id"], "rank": it["rank"], "tier": it["tier"]})
            used[idx] = True
    for i, it in enumerate(items):
        if not used[i]:
            queue.append({"id": it["row"]["alert_id"], "rank": it["rank"], "tier": it["tier"]})

    queue.sort(key=lambda s: s["rank"], reverse=True)
    head = min(bundle["recall_head"], len(queue))
    critical_total = sum(1 for s in queue if s["tier"] >= 4)
    critical_head = sum(1 for s in queue[:head] if s["tier"] >= 4)
    recall_pct = (critical_head * 100) // critical_total if critical_total else 0
    floor_hits = critical_head if critical_head >= bundle["recall_min"] else 0
    band = "noisy" if rows and (noise * 100) // len(rows) >= bundle["fatigue_pct"] else "clean"
    digest = _digest_hex(
        bundle["run_id"],
        len(queue),
        recall_pct,
        noise,
        cascade_groups,
        repairs,
        floor_hits,
        band,
    )
    return {
        "schema_version": "1",
        "run_id": bundle["run_id"],
        "queue_depth": len(queue),
        "critical_recall_pct": recall_pct,
        "noise_suppressed": noise,
        "cascade_groups": cascade_groups,
        "label_repair_count": repairs,
        "recall_floor_hits": floor_hits,
        "fatigue_band": band,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_TRIAGE_FIXTURE": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_alpha_report_matches_replay() -> None:
    """Alpha pack should replay with full critical recall in the head window."""
    _swap("triage_alpha")
    exp = _expected_from_fixture("triage_alpha")
    got = _run_tool()
    assert got == exp


def test_beta_report_matches_replay() -> None:
    """Beta pack should demote doubtful severity labels below the cutoff."""
    _swap("triage_beta")
    exp = _expected_from_fixture("triage_beta")
    got = _run_tool()
    assert got["noise_suppressed"] == exp["noise_suppressed"]
    assert got["critical_recall_pct"] == exp["critical_recall_pct"]


def test_gamma_report_matches_replay() -> None:
    """Gamma should collapse only the three-alert shard cascade under q_size three."""
    _swap("triage_gamma")
    exp = _expected_from_fixture("triage_gamma")
    got = _run_tool()
    assert got["cascade_groups"] == exp["cascade_groups"]
    assert got["queue_depth"] == exp["queue_depth"]


def test_delta_report_matches_replay() -> None:
    """Delta must ignore untrusted historical closures when scoring live rows."""
    _swap("triage_delta")
    exp = _expected_from_fixture("triage_delta")
    got = _run_tool()
    assert got["label_repair_count"] == exp["label_repair_count"]
    assert got["critical_recall_pct"] == exp["critical_recall_pct"]


def test_epsilon_report_matches_replay() -> None:
    """Epsilon should record recall floor hits when head criticals meet recall_min."""
    _swap("triage_epsilon")
    exp = _expected_from_fixture("triage_epsilon")
    got = _run_tool()
    assert got["recall_floor_hits"] == exp["recall_floor_hits"]
    assert got["label_repair_count"] == exp["label_repair_count"]


def test_zeta_report_matches_replay() -> None:
    """Alpha noise ratio should land in the noisy fatigue band."""
    _swap("triage_alpha")
    exp = _expected_from_fixture("triage_alpha")
    got = _run_tool()
    assert got["fatigue_band"] == exp["fatigue_band"]


def test_go_subsystem_tests_pass() -> None:
    """Go tests under /app must pass after the repair."""
    subprocess.run(
        [GO_BIN, "test", "./..."],
        cwd="/app",
        env={
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        },
        check=True,
    )
