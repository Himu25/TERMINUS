# Cascade correlation notes

Rows sharing the same `cascade_root` within `correlation_ms` milliseconds form one candidate group. Collapse requires enough correlated siblings; singleton roots stay independent unless the collapse gate misfires.

Child rows inherit a decayed rank from the parent slot through the Rust rank gate bridge.
