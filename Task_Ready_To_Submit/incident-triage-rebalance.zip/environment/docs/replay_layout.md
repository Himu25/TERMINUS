# Triage replay layout

Active pack lives under `/app/data/active/` with `alert_bundle.json`, `alerts.jsonl`, and optional `history.jsonl`. Indexed replay packs for regression sit under `/app/data/replay/<pack_id>/` with the same shape.

The triage driver reads bundle knobs, sorts alerts by `ts_ms`, folds correlated cascade groups, applies historical resolution rows, and writes `/app/output/triage_report.json`.

Field semantics for alert rows and report counters are documented in the comment block above `main` in `/app/cmd/triage_run/main.go`.
