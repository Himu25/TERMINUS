# Resolution ledger

Historical closures live in `history.jsonl` beside the alert stream. Each row carries `alert_id`, `code`, and `trusted`. Only trusted closures may demote live queue scoring; misleading auto closures must be ignored.

Low `label_confidence` values imply doubtful severity labels and should reduce effective severity before ranking.
