Build the triage driver with `/app/scripts/build.sh` (Go plus Rust staticlib via `/usr/local/go/bin/go` and cargo). Verifier helpers include `/tmp/triage_run_verify_bin` and `/app/tools/digest_cli` for digest recomputation.

Indexed replay packs are listed in `/app/docs/replay_index.txt`.
