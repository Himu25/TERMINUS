// Report JSON for /app/output/triage_report.json:
//
// schema_version — string, must be "1"
// run_id — string, echoes active pack name
// queue_depth — count of ranked alert slots after cascade folding
// critical_recall_pct — integer 0-100 share of tier-four alerts landing in recall head
// noise_suppressed — count of alerts whose effective severity dropped from label doubt
// cascade_groups — count of correlated groups collapsed under q_size
// label_repair_count — trusted resolution demotions applied
// recall_floor_hits — critical alerts protected when head meets recall_min
// fatigue_band — string, "clean" or "noisy"
// digest_hex — lowercase hex SHA-256 of run_id|queue_depth|critical_recall_pct|noise_suppressed|cascade_groups|label_repair_count|recall_floor_hits|fatigue_band
//
// Root object contains only these keys.
//
// Replay sorts alerts by ts_ms, groups rows sharing cascade_root within correlation_ms,
// and collapses a group only when at least q_size correlated alerts agree. Effective
// severity drops when label_confidence sits below label_cutoff. Historical rows in
// history.jsonl demote only when the closure row is marked trusted. Cascade children
// inherit a decayed rank from the parent slot. After ranking, recall head is the first
// recall_head slots; critical_recall_pct is the percentage of tier-four-or-higher
// alerts found there. recall_floor_hits counts head criticals when recall_min is met.
// fatigue_band is noisy when noise_suppressed as a percentage of input rows meets or
// exceeds fatigue_pct.
package main

import (
	"log"
	"os"

	"lab.local/incident_triage_rebalance/internal/driver"
)

func main() {
	if os.Getenv("TB_TRIAGE_FIXTURE") != "1" {
		log.Fatal("TB_TRIAGE_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/triage_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
