package rankgate

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/librankgate.a -ldl -lm
#include "rank_blend.h"
*/
import "C"

// BlendRank folds cascade decay into a parent rank score.
func BlendRank(base int64, decay int64) int64 {
	return int64(C.sg_blend_rank(C.longlong(base), C.longlong(decay)))
}
