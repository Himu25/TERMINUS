use std::os::raw::c_longlong;

/// SgBlendRank applies cascade decay to a parent rank score.
#[no_mangle]
pub extern "C" fn sg_blend_rank(base: c_longlong, decay: c_longlong) -> c_longlong {
    base + decay
}
