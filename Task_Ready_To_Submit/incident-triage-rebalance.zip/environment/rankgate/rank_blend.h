#pragma once

long long sg_blend_rank(long long base, long long decay);
