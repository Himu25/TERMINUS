package digest

import (
	"crypto/sha256"
	"encoding/hex"
	"strings"
)

// FoldReport builds the lowercase hex digest for a triage report row.
func FoldReport(parts ...string) string {
	payload := strings.Join(parts, "|")
	sum := sha256.Sum256([]byte(payload))
	return hex.EncodeToString(sum[:])
}
