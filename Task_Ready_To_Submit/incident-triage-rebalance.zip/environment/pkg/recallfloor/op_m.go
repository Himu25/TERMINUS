package recallfloor

// OpM checks whether enough critical alerts remain in the queue head.
func OpM(inHead int, need int) bool {
	return inHead > need
}
