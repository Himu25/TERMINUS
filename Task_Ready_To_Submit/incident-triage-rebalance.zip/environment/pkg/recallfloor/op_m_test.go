package recallfloor

import "testing"

func TestOpMMeetsNeed(t *testing.T) {
	if !OpM(2, 2) {
		t.Fatal("head count equal to recall_min must satisfy floor")
	}
}
