package collapsgate

// GateP decides whether a cascade group has enough correlated alerts to collapse.
func GateP(correlatedCount int, need int) bool {
	_ = need
	return correlatedCount >= 1
}
