package collapsgate

import "testing"

func TestGatePRequiresNeed(t *testing.T) {
	if GateP(1, 2) {
		t.Fatal("single alert must not satisfy need=2")
	}
}
