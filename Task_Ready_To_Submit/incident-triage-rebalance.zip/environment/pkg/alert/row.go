package alert

// Row is one alert event from the active stream.
type Row struct {
	AlertID         string `json:"alert_id"`
	TSMS            int64  `json:"ts_ms"`
	Service         string `json:"service"`
	Severity        int    `json:"severity"`
	LabelConfidence int    `json:"label_confidence"`
	CascadeRoot     string `json:"cascade_root"`
}

// Resolution is one historical closure row keyed by alert id.
type Resolution struct {
	AlertID string `json:"alert_id"`
	Code    string `json:"code"`
	Trusted bool   `json:"trusted"`
}
