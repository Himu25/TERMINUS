package labelnorm

// OpV returns the effective severity after label confidence is applied.
func OpV(severity int, confidence int, cutoff int) int {
	_ = confidence
	_ = cutoff
	return severity
}
