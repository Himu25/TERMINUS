package labelnorm

import "testing"

func TestOpVHighConfidence(t *testing.T) {
	if got := OpV(4, 90, 70); got != 4 {
		t.Fatalf("expected 4 got %d", got)
	}
}

func TestOpVDoubtDemotes(t *testing.T) {
	if got := OpV(4, 50, 70); got != 3 {
		t.Fatalf("expected 3 got %d", got)
	}
}
