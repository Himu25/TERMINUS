Verifier helpers include /tmp/triage_run_verify_bin and /app/tools/digest_cli for digest recomputation.
