package driver

import (
	"encoding/json"
	"os"

	"lab.local/incident_triage_rebalance/internal/config"
	"lab.local/incident_triage_rebalance/internal/engine"
	"lab.local/incident_triage_rebalance/pkg/digest"
)

// Report is the JSON shape written to /app/output/triage_report.json.
type Report struct {
	SchemaVersion     string `json:"schema_version"`
	RunID             string `json:"run_id"`
	QueueDepth        int    `json:"queue_depth"`
	CriticalRecallPct int    `json:"critical_recall_pct"`
	NoiseSuppressed   int    `json:"noise_suppressed"`
	CascadeGroups     int    `json:"cascade_groups"`
	LabelRepairCount  int    `json:"label_repair_count"`
	RecallFloorHits   int    `json:"recall_floor_hits"`
	FatigueBand       string `json:"fatigue_band"`
	DigestHex         string `json:"digest_hex"`
}

// RunActive loads the active pack and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	bundle, rows, hist, err := config.LoadBundle(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(bundle, rows, hist)
	digestHex := digest.FoldReport(
		bundle.RunID,
		itoa(out.QueueDepth),
		itoa(out.CriticalRecallPct),
		itoa(out.NoiseSuppressed),
		itoa(out.CascadeGroups),
		itoa(out.LabelRepairCount),
		itoa(out.RecallFloorHits),
		out.FatigueBand,
	)
	return Report{
		SchemaVersion:     "1",
		RunID:             bundle.RunID,
		QueueDepth:        out.QueueDepth,
		CriticalRecallPct: out.CriticalRecallPct,
		NoiseSuppressed:   out.NoiseSuppressed,
		CascadeGroups:     out.CascadeGroups,
		LabelRepairCount:  out.LabelRepairCount,
		RecallFloorHits:   out.RecallFloorHits,
		FatigueBand:       out.FatigueBand,
		DigestHex:         digestHex,
	}, nil
}

// EmitReport writes rep to path as compact JSON.
func EmitReport(path string, rep Report) error {
	if err := os.MkdirAll("/app/output", 0o755); err != nil {
		return err
	}
	raw, err := json.Marshal(rep)
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func itoa(v int) string {
	if v == 0 {
		return "0"
	}
	var buf [16]byte
	i := len(buf)
	n := v
	neg := false
	if n < 0 {
		neg = true
		n = -n
	}
	for n > 0 {
		i--
		buf[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		buf[i] = '-'
	}
	return string(buf[i:])
}
