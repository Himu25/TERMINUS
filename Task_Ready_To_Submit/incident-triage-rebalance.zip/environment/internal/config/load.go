package config

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"lab.local/incident_triage_rebalance/pkg/alert"
)

// Bundle holds replay knobs for one alert pack.
type Bundle struct {
	RunID          string `json:"run_id"`
	CorrelationMS  int64  `json:"correlation_ms"`
	QSize          int    `json:"q_size"`
	RecallHead     int    `json:"recall_head"`
	RecallMin      int    `json:"recall_min"`
	LabelCutoff    int    `json:"label_cutoff"`
	FatiguePct     int    `json:"fatigue_pct"`
}

// ActivePaths resolves the active pack directory under appRoot.
func ActivePaths(appRoot string) (string, error) {
	dir := filepath.Join(appRoot, "data", "active")
	st, err := os.Stat(dir)
	if err != nil {
		return "", err
	}
	if !st.IsDir() {
		return "", fmt.Errorf("active path is not a directory")
	}
	return dir, nil
}

// LoadBundle reads bundle config, alerts, and history from dir.
func LoadBundle(dir string) (Bundle, []alert.Row, map[string]alert.Resolution, error) {
	raw, err := os.ReadFile(filepath.Join(dir, "alert_bundle.json"))
	if err != nil {
		return Bundle{}, nil, nil, err
	}
	var bundle Bundle
	if err := json.Unmarshal(raw, &bundle); err != nil {
		return Bundle{}, nil, nil, err
	}
	rows, err := loadAlerts(filepath.Join(dir, "alerts.jsonl"))
	if err != nil {
		return Bundle{}, nil, nil, err
	}
	hist, err := loadHistory(filepath.Join(dir, "history.jsonl"))
	if err != nil {
		return Bundle{}, nil, nil, err
	}
	return bundle, rows, hist, nil
}

func loadAlerts(path string) ([]alert.Row, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var out []alert.Row
	for _, line := range splitLines(string(raw)) {
		if line == "" {
			continue
		}
		var row alert.Row
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return nil, err
		}
		out = append(out, row)
	}
	return out, nil
}

func loadHistory(path string) (map[string]alert.Resolution, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return map[string]alert.Resolution{}, nil
	}
	out := map[string]alert.Resolution{}
	for _, line := range splitLines(string(raw)) {
		if line == "" {
			continue
		}
		var row alert.Resolution
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return nil, err
		}
		out[row.AlertID] = row
	}
	return out, nil
}

func splitLines(s string) []string {
	var lines []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			lines = append(lines, s[start:i])
			start = i + 1
		}
	}
	if start < len(s) {
		lines = append(lines, s[start:])
	}
	return lines
}
