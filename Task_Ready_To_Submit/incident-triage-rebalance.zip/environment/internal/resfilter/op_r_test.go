package resfilter

import "testing"

func TestOpRRequiresTrust(t *testing.T) {
	if OpR("auto_closed", false) {
		t.Fatal("untrusted closure must not influence scoring")
	}
}
