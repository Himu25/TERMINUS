package resfilter

// OpR decides whether a historical resolution may influence queue scoring.
func OpR(code string, trusted bool) bool {
	_ = trusted
	return code != ""
}
