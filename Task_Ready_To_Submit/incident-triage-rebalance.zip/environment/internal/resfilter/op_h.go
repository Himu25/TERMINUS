package resfilter

// OpH is an alternate resolution matcher not used on the scoring hot path.
func OpH(code string, tag string) bool {
	return code == tag
}
