package engine

import (
	"lab.local/incident_triage_rebalance/internal/config"
	"lab.local/incident_triage_rebalance/internal/resfilter"
	"lab.local/incident_triage_rebalance/pkg/alert"
	"lab.local/incident_triage_rebalance/pkg/collapsgate"
	"lab.local/incident_triage_rebalance/pkg/labelnorm"
	"lab.local/incident_triage_rebalance/pkg/recallfloor"
	"lab.local/incident_triage_rebalance/rankgate"
)

type item struct {
	row  alert.Row
	rank int64
	tier int
}

type scored struct {
	id   string
	rank int64
	tier int
}

// Outcome is the folded counters for one pack replay.
type Outcome struct {
	QueueDepth        int
	CriticalRecallPct int
	NoiseSuppressed   int
	CascadeGroups     int
	LabelRepairCount  int
	RecallFloorHits   int
	FatigueBand       string
}

// Replay executes one alert bundle through triage scoring.
func Replay(bundle config.Bundle, rows []alert.Row, hist map[string]alert.Resolution) Outcome {
	items := make([]item, 0, len(rows))
	noise := 0
	repairs := 0
	for _, row := range rows {
		raw := row.Severity
		eff := labelnorm.OpV(row.Severity, row.LabelConfidence, bundle.LabelCutoff)
		if eff < raw {
			noise++
		}
		tier := eff
		if res, ok := hist[row.AlertID]; ok {
			if resfilter.OpR(res.Code, res.Trusted) {
				if eff > 1 {
					eff--
					repairs++
				}
			}
		}
		rank := int64(eff)*1000 + int64(999999-row.TSMS%1000000)
		items = append(items, item{row: row, rank: rank, tier: tier})
	}
	sortItems(items)

	groups := collapseGroups(items, bundle)
	cascadeGroups := 0
	queue := make([]scored, 0, len(items))
	used := make([]bool, len(items))
	for _, g := range groups {
		if len(g) == 0 {
			continue
		}
		if collapsgate.GateP(len(g), bundle.QSize) {
			cascadeGroups++
			parent := items[g[0]]
			queue = append(queue, scored{id: parent.row.AlertID, rank: parent.rank, tier: parent.tier})
			for i, idx := range g {
				used[idx] = true
				if i == 0 {
					continue
				}
				child := items[idx]
				decay := int64(i * 15)
				blended := rankgate.BlendRank(parent.rank, decay)
				queue = append(queue, scored{id: child.row.AlertID, rank: blended, tier: child.tier})
			}
			continue
		}
		for _, idx := range g {
			if used[idx] {
				continue
			}
			it := items[idx]
			queue = append(queue, scored{id: it.row.AlertID, rank: it.rank, tier: it.tier})
			used[idx] = true
		}
	}
	for i, it := range items {
		if used[i] {
			continue
		}
		queue = append(queue, scored{id: it.row.AlertID, rank: it.rank, tier: it.tier})
	}
	sortScored(queue)

	criticalTotal := 0
	criticalHead := 0
	head := bundle.RecallHead
	if head > len(queue) {
		head = len(queue)
	}
	for i, s := range queue {
		if s.tier >= 4 {
			criticalTotal++
			if i < head {
				criticalHead++
			}
		}
	}
	recallPct := 0
	if criticalTotal > 0 {
		recallPct = (criticalHead * 100) / criticalTotal
	}
	floorHits := 0
	if recallfloor.OpM(criticalHead, bundle.RecallMin) {
		floorHits = criticalHead
	}
	band := "clean"
	if len(rows) > 0 && (noise*100)/len(rows) >= bundle.FatiguePct {
		band = "noisy"
	}
	return Outcome{
		QueueDepth:        len(queue),
		CriticalRecallPct: recallPct,
		NoiseSuppressed:   noise,
		CascadeGroups:     cascadeGroups,
		LabelRepairCount:  repairs,
		RecallFloorHits:   floorHits,
		FatigueBand:       band,
	}
}

func sortItems(items []item) {
	for i := 0; i < len(items); i++ {
		for j := i + 1; j < len(items); j++ {
			if items[j].row.TSMS < items[i].row.TSMS {
				items[i], items[j] = items[j], items[i]
			}
		}
	}
}

func collapseGroups(items []item, bundle config.Bundle) [][]int {
	if len(items) == 0 {
		return nil
	}
	var groups [][]int
	cur := []int{0}
	root := items[0].row.CascadeRoot
	lastTS := items[0].row.TSMS
	for i := 1; i < len(items); i++ {
		row := items[i].row
		if row.CascadeRoot == root && row.TSMS-lastTS <= bundle.CorrelationMS {
			cur = append(cur, i)
			lastTS = row.TSMS
			continue
		}
		groups = append(groups, cur)
		cur = []int{i}
		root = row.CascadeRoot
		lastTS = row.TSMS
	}
	groups = append(groups, cur)
	return groups
}

func sortScored(queue []scored) {
	for i := 0; i < len(queue); i++ {
		for j := i + 1; j < len(queue); j++ {
			if queue[j].rank > queue[i].rank {
				queue[i], queue[j] = queue[j], queue[i]
			}
		}
	}
}
