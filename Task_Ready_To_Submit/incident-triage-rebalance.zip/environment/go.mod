module lab.local/incident_triage_rebalance

go 1.22
