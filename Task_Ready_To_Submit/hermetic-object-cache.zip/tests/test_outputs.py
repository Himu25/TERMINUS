"""Verifier for /app/output/build_matrix.json."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
REPORT = APP / "output" / "build_matrix.json"
SCENARIOS = APP.joinpath("fixtures", "scenarios")
SYS_HDR = APP / "tree" / "include" / "sys" / "limit.h"
SYS_HDR_BACKUP = APP / "tree" / "include" / "sys" / "limit.h.orig"

# Expected counter tuples — embedded in the verifier, not in the task environment.
EXPECTED = {
    "steady_incremental": {
        "units_built": 1,
        "remote_hits": 1,
        "remote_misses": 1,
        "local_fallbacks": 1,
        "key_rotations": 1,
    },
    "macro_flag_split": {
        "units_built": 2,
        "remote_hits": 0,
        "remote_misses": 2,
        "local_fallbacks": 2,
        "key_rotations": 2,
    },
    "sys_header_bump": {
        "units_built": 1,
        "remote_hits": 0,
        "remote_misses": 1,
        "local_fallbacks": 1,
        "key_rotations": 1,
    },
    "remote_evict": {
        "units_built": 2,
        "remote_hits": 0,
        "remote_misses": 2,
        "local_fallbacks": 2,
        "key_rotations": 1,
    },
}


def _env() -> dict[str, str]:
    return os.environ.copy()


def rebuild_binaries() -> None:
    subprocess.run(
        ["go", "build", "-o", "/app/bin/buildctl", "./cmd/buildctl"],
        cwd=str(APP),
        check=True,
        env=_env(),
    )
    subprocess.run(
        ["cargo", "build", "--release", "--bin", "kvctl"],
        cwd=str(APP / "crates" / "kvpart"),
        check=True,
        env=_env(),
    )
    shutil.copy2(
        APP / "output" / "cargo-target" / "release" / "kvctl",
        APP / "bin" / "kvctl",
    )


def reset_tree_header() -> None:
    if SYS_HDR_BACKUP.exists():
        shutil.copy2(SYS_HDR_BACKUP, SYS_HDR)


def snapshot_header() -> None:
    if not SYS_HDR_BACKUP.exists():
        shutil.copy2(SYS_HDR, SYS_HDR_BACKUP)


def run_matrix(extra: dict[str, str] | None = None) -> None:
    env = _env()
    if extra:
        env.update(extra)
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    for d in ("offbox-vault", "spill-vault"):
        p = APP / "var" / d
        if p.exists():
            shutil.rmtree(p)
        p.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ["/app/bin/buildctl", "-scenarios", str(SCENARIOS), "-out", str(REPORT)],
        cwd=str(APP),
        check=True,
        env=env,
    )


def _scenario(report: dict, name: str) -> dict:
    for row in report["scenarios"]:
        if row["name"] == name:
            return row
    raise AssertionError(f"missing scenario {name!r}")


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    snapshot_header()
    rebuild_binaries()


@pytest.fixture()
def report() -> dict:
    reset_tree_header()
    run_matrix({"TB_MATRIX_FIXTURE": "1"})
    return json.loads(REPORT.read_text())


def test_report_schema(report: dict) -> None:
    """build_matrix.json matches the published contract."""
    assert isinstance(report, dict)
    rows = report["scenarios"]
    assert isinstance(rows, list) and len(rows) == 4
    names = sorted(r["name"] for r in rows)
    assert names == [
        "macro_flag_split",
        "remote_evict",
        "steady_incremental",
        "sys_header_bump",
    ]
    for row in rows:
        assert set(row.keys()) >= {
            "name",
            "finish_reason",
            "units_built",
            "remote_hits",
            "remote_misses",
            "local_fallbacks",
            "key_rotations",
            "matrix_digest_hex",
        }


def test_all_scenarios_complete(report: dict) -> None:
    """Every bundled scenario reaches a completed matrix replay."""
    for name in EXPECTED:
        assert _scenario(report, name)["finish_reason"] == "complete"


def test_steady_incremental_hits(report: dict) -> None:
    """Steady incremental records a remote hit on the second pass."""
    row = _scenario(report, "steady_incremental")
    exp = EXPECTED["steady_incremental"]
    assert row["remote_hits"] == exp["remote_hits"]
    assert row["remote_misses"] == exp["remote_misses"]
    assert row["local_fallbacks"] == exp["local_fallbacks"]
    assert row["units_built"] == exp["units_built"]


def test_steady_incremental_digest(report: dict) -> None:
    """Steady incremental matrix digest is stable and non-empty."""
    row = _scenario(report, "steady_incremental")
    assert len(row["matrix_digest_hex"]) == 64
    assert row["key_rotations"] == EXPECTED["steady_incremental"]["key_rotations"]


def test_matrix_digest_hex_shape(report: dict) -> None:
    """Every scenario exposes a 64-character lowercase matrix digest."""
    for name in EXPECTED:
        digest = _scenario(report, name)["matrix_digest_hex"]
        assert len(digest) == 64
        assert digest == digest.lower()
        int(digest, 16)


def test_macro_flag_split_rotations(report: dict) -> None:
    """Argv-only drift rotates keys even when preprocess bytes match."""
    row = _scenario(report, "macro_flag_split")
    exp = EXPECTED["macro_flag_split"]
    assert row["key_rotations"] == exp["key_rotations"]
    assert row["remote_hits"] == exp["remote_hits"]
    assert row["remote_misses"] == exp["remote_misses"]


def test_macro_flag_split_no_false_hit(report: dict) -> None:
    """Macro flag split never reuses a remote object across argv variants."""
    row = _scenario(report, "macro_flag_split")
    exp = EXPECTED["macro_flag_split"]
    assert row["units_built"] == exp["units_built"]
    assert row["local_fallbacks"] == exp["local_fallbacks"]


def test_sys_header_bump_miss(report: dict) -> None:
    """System include content bump forces a remote miss."""
    row = _scenario(report, "sys_header_bump")
    exp = EXPECTED["sys_header_bump"]
    assert row["remote_misses"] == exp["remote_misses"]
    assert row["key_rotations"] == exp["key_rotations"]
    assert SYS_HDR.read_text() != SYS_HDR_BACKUP.read_text()


def test_sys_header_bump_builds_locally(report: dict) -> None:
    """System include drift compiles locally once."""
    row = _scenario(report, "sys_header_bump")
    exp = EXPECTED["sys_header_bump"]
    assert row["units_built"] == exp["units_built"]
    assert row["local_fallbacks"] == exp["local_fallbacks"]


def test_remote_evict_fallback(report: dict) -> None:
    """Purged remote shard still compiles via local fallback."""
    row = _scenario(report, "remote_evict")
    exp = EXPECTED["remote_evict"]
    assert row["local_fallbacks"] == exp["local_fallbacks"]
    assert row["units_built"] == exp["units_built"]
    assert row["remote_misses"] == exp["remote_misses"]


def test_remote_evict_no_remote_hit_after_purge(report: dict) -> None:
    """Remote purge prevents hits on the second pass."""
    row = _scenario(report, "remote_evict")
    assert _scenario(report, "remote_evict")["remote_hits"] == EXPECTED["remote_evict"]["remote_hits"]


def test_counter_alignment(report: dict) -> None:
    """Replay counters match the verifier reference tuples."""
    for name, exp in EXPECTED.items():
        row = _scenario(report, name)
        for key, value in exp.items():
            assert row[key] == value


def test_rebuild_from_source(report: dict) -> None:
    """Fresh go and rust rebuilds reproduce the same build matrix."""
    reset_tree_header()
    rebuild_binaries()
    run_matrix({"TB_MATRIX_FIXTURE": "1"})
    again = json.loads(REPORT.read_text())
    assert again["scenarios"] == report["scenarios"]
