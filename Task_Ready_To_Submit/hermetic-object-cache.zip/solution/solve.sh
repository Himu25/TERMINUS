#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
cd /app
chmod +x /app/internal/preprocess/run.sh /app/internal/compile/run.sh

cat > crates/kvpart/src/key/argv.rs <<'EOF'
use sha2::{Digest, Sha256};

pub fn pack_d(argv: &[String]) -> String {
    let mut hasher = Sha256::new();
    for arg in argv {
        hasher.update(arg.as_bytes());
        hasher.update(b"\0");
    }
    hex::encode(hasher.finalize())
}
EOF

cat > crates/kvpart/src/key/toolchain.rs <<'EOF'
pub fn mix_t(compiler: &str) -> String {
    compiler.to_string()
}
EOF

cat > crates/kvpart/src/key/sys.rs <<'EOF'
use std::path::Path;

pub fn pack_s(paths: &[String]) -> String {
    let mut parts = Vec::new();
    for p in paths {
        let digest = content_mix(Path::new(p));
        parts.push(format!("{}:{}", p, digest));
    }
    parts.sort();
    parts.join("|")
}

fn content_mix(path: &Path) -> String {
    use sha2::{Digest, Sha256};
    let data = std::fs::read(path).unwrap_or_default();
    let mut hasher = Sha256::new();
    hasher.update(&data);
    hex::encode(hasher.finalize())
}
EOF

cat > internal/spine/tally.go <<'EOF'
package spine

func bumpRotations(ctr *counters) {
	ctr.KeyRotations++
}
EOF

cat > internal/spine/seam.go <<'EOF'
package spine

import "fmt"

func seamZ(
	id string,
	ctr *counters,
	digestLines *[]string,
	keyHex string,
	abs string,
	argv []string,
) error {
	obj, err := compileUnit(abs, argv)
	if err != nil {
		return err
	}
	ctr.UnitsBuilt++
	ctr.LocalFallbacks++
	if err := keystorePut(keyHex, obj); err != nil {
		return err
	}
	*digestLines = append(*digestLines, fmt.Sprintf("%s:%s:0", id, keyHex))
	return nil
}
EOF

sed -i 's/return seamZ(id, ctr, digestLines, resp.KeyHex)/return seamZ(id, ctr, digestLines, resp.KeyHex, abs, argv)/' \
  internal/spine/unit.go

bash /app/ci/run_build_matrix.sh
