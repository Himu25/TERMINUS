# Compile matrix layout

Go buildctl under `/app/cmd/buildctl` replays JSON scenarios from `/app/fixtures/scenarios`, calls the Rust sidecar for off-box lookup and object materialization, and drives preprocess and compile wrappers under `/app/internal/preprocess` and `/app/internal/compile` on sources in `/app/tree`.

The agent-visible report is `/app/output/build_matrix.json`. It contains a `scenarios` array; each element carries `name`, `finish_reason`, `units_built`, `remote_hits`, `remote_misses`, `local_fallbacks`, `key_rotations`, and `matrix_digest_hex`. Bundled fixtures should finish with `finish_reason` set to `complete`. The digest is a 64-character lowercase SHA-256 hex string over sorted lines of the form `unit_id:key_hex:hit`, where `hit` is `1` when the unit was served from the remote shard and `0` otherwise.

Off-box object files live under `/app/var/offbox-vault`. Local spill objects live under `/app/var/spill-vault`. Rust rebuild output uses `/app/output/cargo-target`; Go build cache uses `/app/output/go-build`. System include baselines for replay hygiene may sit beside live headers (for example `/app/tree/include/sys/limit.h.orig` next to `/app/tree/include/sys/limit.h`).
