package api

type UnitSpec struct {
	ID     string   `json:"id"`
	Source string   `json:"source"`
	Argv   []string `json:"argv"`
	Passes int      `json:"passes"`
}

type ScenarioFile struct {
	Name                  string    `json:"name"`
	Units                 []UnitSpec `json:"units"`
	MutateSysHeader       bool      `json:"mutate_sys_header,omitempty"`
	PurgeRemoteBeforeSecond bool    `json:"purge_remote_before_second,omitempty"`
	SecondPass            *UnitSpec `json:"second_pass,omitempty"`
}

type ScenarioRow struct {
	Name             string `json:"name"`
	FinishReason     string `json:"finish_reason"`
	UnitsBuilt       int    `json:"units_built"`
	RemoteHits       int    `json:"remote_hits"`
	RemoteMisses     int    `json:"remote_misses"`
	LocalFallbacks   int    `json:"local_fallbacks"`
	KeyRotations     int    `json:"key_rotations"`
	MatrixDigestHex  string `json:"matrix_digest_hex"`
}

type MatrixReport struct {
	Scenarios []ScenarioRow `json:"scenarios"`
}
