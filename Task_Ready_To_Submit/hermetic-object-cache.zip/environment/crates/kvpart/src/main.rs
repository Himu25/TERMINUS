use kvpart::{handle_lookup, store_object, LookupRequest};
use std::io::{self, Read};

fn main() {
    let mut buf = String::new();
    io::stdin().read_to_string(&mut buf).expect("stdin");
    let v: serde_json::Value = serde_json::from_str(&buf).expect("json");
    if v.get("op").and_then(|x| x.as_str()) == Some("put") {
        let key = v["key_hex"].as_str().expect("key");
        let obj = v["object_hex"].as_str().expect("obj");
        let bytes = hex::decode(obj).expect("hex");
        store_object(key, &bytes);
        println!("{{\"ok\":true}}");
        return;
    }
    let req: LookupRequest = serde_json::from_value(v).expect("lookup json");
    let prev = req
        .unit_id
        .split('|')
        .nth(1)
        .map(|s| s.to_string());
    let unit = req.unit_id.split('|').next().unwrap_or("").to_string();
    let mut clean = req.clone();
    clean.unit_id = unit;
    let resp = handle_lookup(&clean, prev.as_deref());
    println!("{}", serde_json::to_string(&resp).unwrap());
}
