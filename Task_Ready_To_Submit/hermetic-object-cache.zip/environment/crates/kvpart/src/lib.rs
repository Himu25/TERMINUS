pub mod key;
pub mod store;

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LookupRequest {
    pub unit_id: String,
    pub source_path: String,
    pub preprocess_digest_hex: String,
    pub argv: Vec<String>,
    pub compiler_stamp: String,
    pub sys_include_paths: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LookupResponse {
    pub key_hex: String,
    pub remote_hit: bool,
    pub compiled_locally: bool,
    pub key_rotated: bool,
}

pub fn handle_lookup(req: &LookupRequest, prev_key: Option<&str>) -> LookupResponse {
    let key_hex = key::material::blend_a(req);
    let rotated = prev_key.map(|p| p != key_hex).unwrap_or(true);
    match store::remote::lane_r(&key_hex) {
        Ok(obj) => {
            store::local::vault_s(&key_hex, &obj);
            LookupResponse {
                key_hex,
                remote_hit: true,
                compiled_locally: false,
                key_rotated: rotated,
            }
        }
        Err(_) => LookupResponse {
            key_hex,
            remote_hit: false,
            compiled_locally: false,
            key_rotated: rotated,
        },
    }
}

pub fn store_object(key_hex: &str, object_bytes: &[u8]) {
    store::remote::put_lane(key_hex, object_bytes);
    store::local::vault_s(key_hex, object_bytes);
}
