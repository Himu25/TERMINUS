use sha2::{Digest, Sha256};

pub fn pack_d(argv: &[String]) -> String {
    let mut hasher = Sha256::new();
    for arg in argv {
        if arg.starts_with("-D") {
            continue;
        }
        hasher.update(arg.as_bytes());
        hasher.update(b"\0");
    }
    hex::encode(hasher.finalize())
}
