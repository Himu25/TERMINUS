pub fn pack_s(paths: &[String]) -> String {
    let mut parts = Vec::new();
    for p in paths {
        parts.push(p.clone());
    }
    parts.sort();
    parts.join("|")
}
