use super::{argv, sys};
use crate::LookupRequest;
use sha2::{Digest, Sha256};

pub fn blend_a(req: &LookupRequest) -> String {
    let mut hasher = Sha256::new();
    hasher.update(req.source_path.as_bytes());
    hasher.update(req.preprocess_digest_hex.as_bytes());
    hasher.update(super::toolchain::mix_t(&req.compiler_stamp).as_bytes());
    hasher.update(argv::pack_d(&req.argv).as_bytes());
    hasher.update(sys::pack_s(&req.sys_include_paths).as_bytes());
    hex::encode(hasher.finalize())
}
