use std::fs;
use std::path::PathBuf;

fn root() -> PathBuf {
    PathBuf::from("/app/var/offbox-vault")
}

pub fn lane_r(key_hex: &str) -> Result<Vec<u8>, ()> {
    let path = root().join(key_hex);
    if path.exists() {
        fs::read(path).map_err(|_| ())
    } else {
        Err(())
    }
}

pub fn put_lane(key_hex: &str, bytes: &[u8]) {
    let path = root().join(key_hex);
    if let Some(parent) = path.parent() {
        let _ = fs::create_dir_all(parent);
    }
    let _ = fs::write(path, bytes);
}

pub fn purge_all() {
    let _ = fs::remove_dir_all(root());
    let _ = fs::create_dir_all(root());
}
