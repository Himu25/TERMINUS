use std::fs;
use std::path::PathBuf;

fn root() -> PathBuf {
    PathBuf::from("/app/var/spill-vault")
}

pub fn vault_s(key_hex: &str, bytes: &[u8]) {
    let path = root().join(key_hex);
    if let Some(parent) = path.parent() {
        let _ = fs::create_dir_all(parent);
    }
    let _ = fs::write(path, bytes);
}

pub fn lane_local(key_hex: &str) -> Option<Vec<u8>> {
    let path = root().join(key_hex);
    fs::read(path).ok()
}
