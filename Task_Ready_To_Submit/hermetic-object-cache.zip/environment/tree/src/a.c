#include <project/config.h>
#include <sys/limit.h>
#ifdef NDEBUG
#define TB_WRAP(x) (x)
#else
#define TB_WRAP(x) (x)
#endif
int tb_a(void) { return TB_WRAP(TB_SYS_LIMIT) + TB_FEATURE; }
