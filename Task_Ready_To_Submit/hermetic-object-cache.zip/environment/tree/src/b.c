#include <project/config.h>
#ifndef TB_ALT
int tb_b(void) { return TB_FEATURE; }
#else
int tb_b(void) { return TB_FEATURE + 1; }
#endif
