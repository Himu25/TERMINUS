#!/usr/bin/env bash
set -euo pipefail
test -x /app/internal/preprocess/run.sh
test -x /app/internal/compile/run.sh
command -v gcc >/dev/null
