package main

import (
	"flag"
	"fmt"
	"os"

	"hermetic/internal/spine"
)

func main() {
	scDir := flag.String("scenarios", "/app/fixtures/scenarios", "scenario directory")
	out := flag.String("out", "/app/output/build_matrix.json", "report path")
	flag.Parse()
	if err := os.MkdirAll("/app/output", 0o777); err != nil {
		fmt.Fprintf(os.Stderr, "mkdir output: %v\n", err)
		os.Exit(1)
	}
	if err := spine.RunAll(*scDir, *out); err != nil {
		fmt.Fprintf(os.Stderr, "matrix: %v\n", err)
		os.Exit(1)
	}
}
