#!/usr/bin/env bash
set -euo pipefail
SRC="$1"
shift
OUT="$1"
shift
gcc -E -P "$@" "$SRC" | tr -d '\r' >"$OUT"
