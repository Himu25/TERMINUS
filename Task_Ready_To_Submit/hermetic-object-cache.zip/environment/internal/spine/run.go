package spine

import (
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"

	"hermetic/pkg/api"
)

func ReplayScenario(sc *api.ScenarioFile) (api.ScenarioRow, error) {
	ctr := &counters{}
	var digestLines []string
	var prevKey string

	if sc.MutateSysHeader {
		path := "/app/tree/include/sys/limit.h"
		data, err := os.ReadFile(path)
		if err != nil {
			return api.ScenarioRow{}, err
		}
		updated := strings.Replace(string(data), "1024", "2048", 1)
		if err := os.WriteFile(path, []byte(updated), 0o644); err != nil {
			return api.ScenarioRow{}, err
		}
	}

	units := sc.Units
	if sc.SecondPass != nil {
		units = append(units, *sc.SecondPass)
	}

	for idx, unit := range units {
		if sc.PurgeRemoteBeforeSecond && idx == 1 {
			_ = exec.Command("rm", "-rf", "/app/var/offbox-vault").Run()
			_ = os.MkdirAll("/app/var/offbox-vault", 0o777)
		}
		for pass := 0; pass < unit.Passes; pass++ {
			if err := RunUnit(unit.ID, unit.Source, unit.Argv, ctr, &prevKey, &digestLines); err != nil {
				return api.ScenarioRow{
					Name:         sc.Name,
					FinishReason: "error",
				}, err
			}
		}
	}

	digest, err := matrixDigest(digestLines)
	if err != nil {
		return api.ScenarioRow{}, err
	}
	return api.ScenarioRow{
		Name:            sc.Name,
		FinishReason:    "complete",
		UnitsBuilt:      ctr.UnitsBuilt,
		RemoteHits:      ctr.RemoteHits,
		RemoteMisses:    ctr.RemoteMisses,
		LocalFallbacks:  ctr.LocalFallbacks,
		KeyRotations:    ctr.KeyRotations,
		MatrixDigestHex: digest,
	}, nil
}

func matrixDigest(lines []string) (string, error) {
	sort.Strings(lines)
	body := strings.Join(lines, "\n") + "\n"
	cmd := exec.Command("openssl", "dgst", "-sha256", "-hex")
	cmd.Stdin = bytes.NewReader([]byte(body))
	out, err := cmd.Output()
	if err != nil {
		return "", err
	}
	fields := strings.Fields(string(out))
	return strings.ToLower(fields[len(fields)-1]), nil
}

func LoadScenarios(dir string) ([]api.ScenarioFile, error) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}
	var out []api.ScenarioFile
	for _, ent := range entries {
		if ent.IsDir() || !strings.HasSuffix(ent.Name(), ".json") {
			continue
		}
		raw, err := os.ReadFile(filepath.Join(dir, ent.Name()))
		if err != nil {
			return nil, err
		}
		var sc api.ScenarioFile
		if err := json.Unmarshal(raw, &sc); err != nil {
			return nil, err
		}
		out = append(out, sc)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Name < out[j].Name })
	return out, nil
}

func WriteReport(path string, rows []api.ScenarioRow) error {
	report := api.MatrixReport{Scenarios: rows}
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o644)
}

func RunAll(scenarioDir, outPath string) error {
	scenarios, err := LoadScenarios(scenarioDir)
	if err != nil {
		return err
	}
	var rows []api.ScenarioRow
	for _, sc := range scenarios {
		row, err := ReplayScenario(&sc)
		if err != nil {
			return fmt.Errorf("%s: %w", sc.Name, err)
		}
		rows = append(rows, row)
	}
	return WriteReport(outPath, rows)
}
