package spine

func bumpRotations(ctr *counters) {
	ctr.KeyRotations = 0
}
