package spine

import (
	"bytes"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

type lookupReq struct {
	UnitID              string   `json:"unit_id"`
	SourcePath          string   `json:"source_path"`
	PreprocessDigestHex string   `json:"preprocess_digest_hex"`
	Argv                []string `json:"argv"`
	CompilerStamp       string   `json:"compiler_stamp"`
	SysIncludePaths     []string `json:"sys_include_paths"`
}

type lookupResp struct {
	KeyHex           string `json:"key_hex"`
	RemoteHit        bool   `json:"remote_hit"`
	CompiledLocally  bool   `json:"compiled_locally"`
	KeyRotated       bool   `json:"key_rotated"`
}

type counters struct {
	UnitsBuilt     int
	RemoteHits     int
	RemoteMisses   int
	LocalFallbacks int
	KeyRotations   int
}

func compilerStamp() string {
	out, err := exec.Command("gcc", "-dumpversion").Output()
	if err != nil {
		return "gcc-unknown"
	}
	return "gcc-" + strings.TrimSpace(string(out))
}

func preprocessDigest(src string, argv []string) (string, error) {
	tmp, err := os.CreateTemp("", "pp-*.txt")
	if err != nil {
		return "", err
	}
	defer os.Remove(tmp.Name())
	args := append([]string{"/app/internal/preprocess/run.sh", src, tmp.Name()}, argv...)
	if err := exec.Command(args[0], args[1:]...).Run(); err != nil {
		return "", err
	}
	data, err := os.ReadFile(tmp.Name())
	if err != nil {
		return "", err
	}
	cmd := exec.Command("openssl", "dgst", "-sha256", "-hex")
	cmd.Stdin = bytes.NewReader(data)
	out, err := cmd.Output()
	if err != nil {
		return "", err
	}
	fields := strings.Fields(string(out))
	return strings.ToLower(fields[len(fields)-1]), nil
}

func keystoreLookup(req lookupReq, prevKey string) (lookupResp, error) {
	if prevKey != "" {
		req.UnitID = req.UnitID + "|" + prevKey
	}
	payload, _ := json.Marshal(req)
	cmd := exec.Command("/app/bin/kvctl")
	cmd.Stdin = bytes.NewReader(payload)
	out, err := cmd.Output()
	if err != nil {
		return lookupResp{}, err
	}
	var resp lookupResp
	if err := json.Unmarshal(out, &resp); err != nil {
		return lookupResp{}, err
	}
	return resp, nil
}

func keystorePut(keyHex string, obj []byte) error {
	payload, _ := json.Marshal(map[string]string{
		"op":         "put",
		"key_hex":    keyHex,
		"object_hex": hex.EncodeToString(obj),
	})
	cmd := exec.Command("/app/bin/kvctl")
	cmd.Stdin = bytes.NewReader(payload)
	_, err := cmd.Output()
	return err
}

func compileUnit(src string, argv []string) ([]byte, error) {
	objPath, err := os.CreateTemp("", "unit-*.o")
	if err != nil {
		return nil, err
	}
	defer os.Remove(objPath.Name())
	args := append([]string{"/app/internal/compile/run.sh", src, objPath.Name()}, argv...)
	if err := exec.Command(args[0], args[1:]...).Run(); err != nil {
		return nil, err
	}
	return os.ReadFile(objPath.Name())
}

func RunUnit(id, src string, argv []string, ctr *counters, prevKey *string, digestLines *[]string) error {
	abs := filepath.Join("/app", src)
	pp, err := preprocessDigest(abs, argv)
	if err != nil {
		return err
	}
	req := lookupReq{
		UnitID:              id,
		SourcePath:          abs,
		PreprocessDigestHex: pp,
		Argv:                argv,
		CompilerStamp:       compilerStamp(),
		SysIncludePaths:     []string{"/app/tree/include/sys/limit.h"},
	}
	resp, err := keystoreLookup(req, *prevKey)
	if err != nil {
		return err
	}
	if resp.KeyRotated {
		bumpRotations(ctr)
	}
	*prevKey = resp.KeyHex
	if resp.RemoteHit {
		ctr.RemoteHits++
		*digestLines = append(*digestLines, fmt.Sprintf("%s:%s:1", id, resp.KeyHex))
		return nil
	}
	ctr.RemoteMisses++
	return seamZ(id, ctr, digestLines, resp.KeyHex, abs, argv)
}
