package spine

import "fmt"

func seamZ(
	id string,
	ctr *counters,
	digestLines *[]string,
	keyHex string,
	abs string,
	argv []string,
) error {
	_ = abs
	_ = argv
	return fmt.Errorf("off-box miss for %s", id)
}
