#!/usr/bin/env bash
set -euo pipefail
SRC="$1"
OBJ="$2"
shift 2
gcc -c -o "$OBJ" "$@" "$SRC"
