#!/usr/bin/env bash
set -euo pipefail
export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
cd /app
mkdir -p /app/output /app/var/offbox-vault /app/var/spill-vault
go build -o /app/bin/buildctl ./cmd/buildctl
cd /app/crates/kvpart
cargo build --release --locked --bin kvctl 2>/dev/null || cargo build --release --bin kvctl
install -m 0755 /app/crates/kvpart/target/release/kvctl /app/bin/kvctl
cd /app
/app/bin/buildctl \
  -scenarios /app/fixtures/scenarios \
  -out /app/output/build_matrix.json
