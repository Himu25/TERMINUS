module hermetic

go 1.22
