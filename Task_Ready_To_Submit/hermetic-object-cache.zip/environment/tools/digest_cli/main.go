package main

import (
	"bufio"
	"fmt"
	"os"
	"os/exec"
	"sort"
	"strings"
)

func main() {
	var lines []string
	sc := bufio.NewScanner(os.Stdin)
	for sc.Scan() {
		lines = append(lines, sc.Text())
	}
	sort.Strings(lines)
	body := strings.Join(lines, "\n") + "\n"
	cmd := exec.Command("openssl", "dgst", "-sha256", "-hex")
	cmd.Stdin = strings.NewReader(body)
	out, err := cmd.Output()
	if err != nil {
		os.Exit(1)
	}
	fields := strings.Fields(string(out))
	fmt.Println(strings.ToLower(fields[len(fields)-1]))
}
