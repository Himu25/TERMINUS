#!/usr/bin/env bash
set -euo pipefail
cd /app && bash /app/scripts/build.sh
