package main

import (
	"os"

	"bindlab/internal/driver"
)

func main() {
	manifest := "/app/data/active/manifest.json"
	if v := os.Getenv("TB_BIND_MANIFEST"); v != "" {
		manifest = v
	}
	out := "/app/output/bind_report.json"
	if err := driver.Run(manifest, out); err != nil {
		os.Stderr.WriteString(err.Error() + "\n")
		os.Exit(1)
	}
}
