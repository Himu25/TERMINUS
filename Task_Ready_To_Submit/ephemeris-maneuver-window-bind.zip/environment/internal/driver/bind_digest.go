package driver

import "bindlab/internal/q9"

func sealHex(names []string, ranges []float64, _ int, _ int, _ float64, _ int, _ int) string {
	return q9.OpD(names, ranges)
}
