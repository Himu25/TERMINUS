package driver

import "bindlab/internal/q9"

func bumpPassed(total int, row WindowRow, overlap bool) int {
	if row.Passed != 1 {
		return total
	}
	return q9.OpB(total, overlap)
}
