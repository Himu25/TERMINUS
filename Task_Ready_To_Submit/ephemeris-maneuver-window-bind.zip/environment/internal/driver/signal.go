package driver

import "math"

func GenSecondary(baseT0 float64, offset float64) [3]float64 {
	return [3]float64{
		7000.0 + offset,
		math.Sin(baseT0 * 1e-4) * 100.0,
		math.Cos(baseT0 * 1e-4) * 50.0,
	}
}
