package driver

import (
	"encoding/json"
	"os"
)

type replayProfile struct {
	Steps int `json:"steps"`
}

func profileSteps(path string) uint32 {
	raw, err := os.ReadFile(path)
	if err != nil {
		return 32
	}
	var prof replayProfile
	if err := json.Unmarshal(raw, &prof); err != nil || prof.Steps <= 0 {
		return 32
	}
	return uint32(prof.Steps)
}
