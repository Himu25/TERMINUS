package driver

import (
	"bindlab/internal/bridge"
	"bindlab/internal/plan"
)

func overlapChainOK(ids []int) bool {
	return mergeOverlapIDs(ids)
}

func overlapSpanOK(m *Manifest, w WindowSpec) bool {
	for _, pair := range m.Overlap {
		if w.T0 <= pair[1] && pair[0] <= w.T1 {
			return bridge.SpanTouch(w.T0, w.T1, pair[0], pair[1])
		}
	}
	return false
}

func mergeOverlapIDs(ids []int) bool {
	if len(ids) <= 1 {
		return true
	}
	sorted := plan.OpP(ids)
	ordered := bridge.ArrangeOrder(sorted)
	for i := 1; i < len(ordered); i++ {
		if ordered[i] <= ordered[i-1] {
			return false
		}
	}
	return true
}
