package driver

import (
	"bindlab/internal/bridge"
	"bindlab/internal/q9"
	"bindlab/pkg/fold"
)

func sampleRow(pri, sec []bridge.Seg, leaps []float64, w WindowSpec, threads uint32) WindowRow {
	flags := OpE1(w.Mode, threads)
	steps := fold.RoundCap(int(profileSteps("/app/profiles/default.json"))) / 2
	minR := bridge.SampleGap(pri, sec, leaps, w.T0, w.T1, uint32(steps), flags)
	row := WindowRow{
		Name:      w.Name,
		MinRangeM: minR,
		Lane:      laneLabel(w.Mode),
	}
	row.Passed = q9.OpR(w.ClearM, minR)
	return row
}
