package driver

import (
	"encoding/json"
	"os"
	"path/filepath"

	"bindlab/internal/bridge"
)

type WindowSpec struct {
	Name   string  `json:"name"`
	T0     float64 `json:"t0"`
	T1     float64 `json:"t1"`
	ClearM float64 `json:"clear_m"`
	Mode   string  `json:"mode"`
}

type Segment struct {
	T0         float64 `json:"t0"`
	T1         float64 `json:"t1"`
	X          float64 `json:"x"`
	Y          float64 `json:"y"`
	Z          float64 `json:"z"`
	VX         float64 `json:"vx"`
	VY         float64 `json:"vy"`
	VZ         float64 `json:"vz"`
}

type Manifest struct {
	PackID    string       `json:"pack_id"`
	Threads   uint32       `json:"threads"`
	Leaps     []float64    `json:"leap_tape"`
	Primary   []Segment    `json:"primary_segments"`
	Secondary []Segment    `json:"secondary_segments"`
	Overlap   [][2]float64 `json:"overlap_tape"`
	Windows   []WindowSpec `json:"windows"`
}

type WindowRow struct {
	Name      string  `json:"name"`
	MinRangeM float64 `json:"min_range_m"`
	Passed    int     `json:"passed"`
	Lane      string  `json:"lane"`
}

type Report struct {
	SchemaVersion  int         `json:"schema_version"`
	PackID         string      `json:"pack_id"`
	WindowsTotal   int         `json:"windows_total"`
	WindowsPassed  int         `json:"windows_passed"`
	MinRangeWorstM float64     `json:"min_range_worst_m"`
	LeapOK         int         `json:"leap_ok"`
	OverlapOK      int         `json:"overlap_ok"`
	DigestHex      string      `json:"digest_hex"`
	Windows        []WindowRow `json:"windows"`
}

func LoadManifest(path string) (*Manifest, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var m Manifest
	if err := json.Unmarshal(raw, &m); err != nil {
		return nil, err
	}
	return &m, nil
}

func toBridgeSegs(segs []Segment) []bridge.Seg {
	out := make([]bridge.Seg, len(segs))
	for i, s := range segs {
		out[i] = bridge.Seg{
			T0: s.T0, T1: s.T1,
			X: s.X, Y: s.Y, Z: s.Z,
			VX: s.VX, VY: s.VY, VZ: s.VZ,
		}
	}
	return out
}

func tapePair(m *Manifest, w WindowSpec) bool {
	for _, pair := range m.Overlap {
		if w.T0 <= pair[1] && pair[0] <= w.T1 {
			return true
		}
	}
	return false
}

func tapePairStrict(m *Manifest, w WindowSpec) bool {
	return overlapSpanOK(m, w)
}

func laneLabel(mode string) string {
	switch mode {
	case "parallel":
		return "stripe"
	case "leap":
		return "tape"
	case "overlap":
		return "pair"
	default:
		return "nominal"
	}
}

func buildReport(m *Manifest) Report {
	pri := toBridgeSegs(m.Primary)
	sec := toBridgeSegs(m.Secondary)
	report := Report{
		SchemaVersion: 2,
		PackID:        m.PackID,
		WindowsTotal:  len(m.Windows),
		LeapOK:        1,
		OverlapOK:     1,
	}
	var worst float64
	var names []string
	var ranges []float64
	overlapIDs := make([]int, 0)
	for i, w := range m.Windows {
		row := sampleRow(pri, sec, m.Leaps, w, m.Threads)
		report.WindowsPassed = bumpPassed(report.WindowsPassed, row, tapePair(m, w))
		if row.MinRangeM > worst {
			worst = row.MinRangeM
		}
		if w.Mode == "leap" && row.Passed == 0 {
			report.LeapOK = 0
		}
		if w.Mode == "overlap" && row.Passed == 0 {
			report.OverlapOK = 0
		}
		if w.Mode == "overlap" && !tapePairStrict(m, w) {
			report.OverlapOK = 0
		}
		if w.Mode == "parallel" {
			delta := bridge.PathDelta(pri, sec, m.Leaps, w.T0, w.T1, m.Threads)
			if delta > 1e-4 {
				report.LeapOK = 0
			}
		}
		if tapePair(m, w) {
			overlapIDs = append(overlapIDs, i)
		}
		names = append(names, w.Name)
		ranges = append(ranges, row.MinRangeM)
		report.Windows = append(report.Windows, row)
	}
	if len(overlapIDs) > 0 && !overlapChainOK(overlapIDs) {
		report.OverlapOK = 0
	}
	report.MinRangeWorstM = worst
	report.DigestHex = sealHex(names, ranges, report.WindowsTotal, report.WindowsPassed, worst, report.LeapOK, report.OverlapOK)
	return report
}

func Run(manifestPath, outPath string) error {
	m, err := LoadManifest(manifestPath)
	if err != nil {
		return err
	}
	report := buildReport(m)
	if err := os.MkdirAll(filepath.Dir(outPath), 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(outPath, raw, 0o644)
}
