package driver

func OpE1(mode string, workers uint32) uint32 {
	var flags uint32
	switch mode {
	case "parallel":
		flags |= 1
	case "leap":
		flags |= 2
	case "overlap":
		flags |= 4
	}
	flags |= (workers >> 1) & 0xF
	return flags
}
