package plan

func OpP(ids []int) []int {
	if len(ids) <= 1 {
		return ids
	}
	out := append([]int(nil), ids...)
	return out
}
