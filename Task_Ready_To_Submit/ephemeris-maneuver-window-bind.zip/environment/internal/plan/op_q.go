package plan

func OpQ(n int) string {
	if n <= 0 {
		return "z"
	}
	return "lane"
}
