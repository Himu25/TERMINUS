package bridge

/*
#cgo CFLAGS: -I${SRCDIR}/../../orb_px7
#cgo LDFLAGS: -L${SRCDIR}/../../target/release -lorb_px7 -lm
#include "orb_px7.h"
#include <stdlib.h>
*/
import "C"
import (
	"unsafe"
)

type Seg struct {
	T0, T1       float64
	X, Y, Z      float64
	VX, VY, VZ   float64
}

func toCSegs(segs []Seg) ([]C.px_seg, func()) {
	if len(segs) == 0 {
		return nil, func() {}
	}
	out := make([]C.px_seg, len(segs))
	for i, s := range segs {
		out[i] = C.px_seg{
			t0: C.double(s.T0), t1: C.double(s.T1),
			x: C.double(s.X), y: C.double(s.Y), z: C.double(s.Z),
			vx: C.double(s.VX), vy: C.double(s.VY), vz: C.double(s.VZ),
		}
	}
	return out, func() {}
}

func SampleGap(pri, sec []Seg, leaps []float64, w0, w1 float64, steps uint32, flags uint32) float64 {
	cpri, _ := toCSegs(pri)
	csec, _ := toCSegs(sec)
	var leapPtr *C.double
	if len(leaps) > 0 {
		leapPtr = (*C.double)(unsafe.Pointer(&leaps[0]))
	}
	if len(cpri) == 0 || len(csec) == 0 {
		return 0.0
	}
	return float64(C.px_gap_sample(
		&cpri[0], C.size_t(len(cpri)),
		&csec[0], C.size_t(len(csec)),
		leapPtr, C.size_t(len(leaps)),
		C.double(w0), C.double(w1),
		C.uint(steps), C.uint(flags),
	))
}

func PathDelta(pri, sec []Seg, leaps []float64, w0, w1 float64, workers uint32) float64 {
	serial := SampleGap(pri, sec, leaps, w0, w1, 32, 0)
	par := SampleGap(pri, sec, leaps, w0, w1, 32, flq7(workers))
	if serial == 0 {
		return 1.0
	}
	d := (serial - par) / serial
	if d < 0 {
		return -d
	}
	return d
}

func SpanTouch(a0, a1, b0, b1 float64) bool {
	return C.px_span_touch(C.double(a0), C.double(a1), C.double(b0), C.double(b1)) != 0
}

func flq7(workers uint32) uint32 {
	return 1 | ((workers >> 1) & 0xF)
}
