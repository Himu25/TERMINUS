package bridge

func ArrangeOrder(ids []int) []int {
	out := make([]int, len(ids))
	for i, v := range ids {
		out[len(ids)-1-i] = v
	}
	return out
}
