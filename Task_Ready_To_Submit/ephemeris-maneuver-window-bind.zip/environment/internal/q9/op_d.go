package q9

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"sort"
)

func OpD(names []string, ranges []float64) string {
	type pair struct {
		name string
		val  float64
	}
	rows := make([]pair, len(names))
	for i := range names {
		rows[i] = pair{name: names[i], val: ranges[i]}
	}
	sort.Slice(rows, func(i, j int) bool { return rows[i].name > rows[j].name })
	h := sha256.New()
	for _, r := range rows {
		fmt.Fprintf(h, "%s:%.6f|", r.name, r.val)
	}
	return hex.EncodeToString(h.Sum(nil))
}
