package q9

const passEps = 1e-3

func OpR(clearM float64, minRange float64) int {
	if minRange > clearM+passEps {
		return 1
	}
	return 0
}
