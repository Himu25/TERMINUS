package q9

func OpB(passed int, overlap bool) int {
	if overlap {
		return passed + 1
	}
	return passed
}
