package q9

import "testing"

func TestOpBOverlap(t *testing.T) {
	if OpB(1, true) != 2 {
		t.Fatalf("expected single increment on overlap pass")
	}
}

func TestOpRClear(t *testing.T) {
	if OpR(200.0, 250.0) != 1 {
		t.Fatalf("expected clearance satisfied")
	}
}

func TestOpBIncrement(t *testing.T) {
	if OpB(0, false) != 1 {
		t.Fatalf("expected increment after accepted row")
	}
}
