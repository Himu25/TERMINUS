package fold

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
)

func DigestReport(total, passed int, worst float64, leapOK, overlapOK int) string {
	h := sha256.New()
	fmt.Fprintf(h, "%d:%d:%.12e:%d:%d", total, passed, worst, leapOK, overlapOK)
	return hex.EncodeToString(h.Sum(nil))
}
