package fold

func RoundCap(n int) int {
	if n <= 0 {
		return 64
	}
	c := 64
	for c < n {
		c *= 2
	}
	return c
}
