package main

import (
	"fmt"
	"os"
	"strconv"

	"bindlab/pkg/fold"
)

func main() {
	if len(os.Args) != 6 {
		os.Exit(2)
	}
	total, _ := strconv.Atoi(os.Args[1])
	passed, _ := strconv.Atoi(os.Args[2])
	worst, _ := strconv.ParseFloat(os.Args[3], 64)
	leap, _ := strconv.Atoi(os.Args[4])
	overlap, _ := strconv.Atoi(os.Args[5])
	fmt.Println(fold.DigestReport(total, passed, worst, leap, overlap))
}
