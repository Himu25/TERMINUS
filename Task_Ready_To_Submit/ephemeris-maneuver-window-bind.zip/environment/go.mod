module bindlab

go 1.24.0
