The bind desk combines a Go driver with a Rust segment core under `/app`.
Primary and secondary segment chains, leap tape markers, and overlap tape pairs
feed clearance sampling before the driver writes `/app/output/bind_report.json`.
Build via `/app/scripts/build.sh`. Driver binary `/app/bin/bind_lab`.
