pub fn epoch_table_seed(n: usize) -> u64 {
    (n as u64).wrapping_mul(0x9E3779B97F4A7C15)
}
