use super::a1::{op_k2, PxSeg};
use super::a0::op_t7;

use std::os::raw::{c_double, c_uint};

pub fn op_s4(
    pri: &[PxSeg],
    sec: &[PxSeg],
    leaps: &[f64],
    w0: f64,
    w1: f64,
    steps: usize,
    flags: u32,
) -> f64 {
    let mut steps = steps.max(2);
    if flags & 1 != 0 {
        steps = steps / 2;
    }
    let mut best = f64::MAX;
    for i in 0..steps {
        let frac = i as f64 / (steps - 1) as f64;
        let t = w0 + (w1 - w0) * frac;
        let p = op_k2(pri, t, leaps);
        let sec_leaps = if flags & 2 != 0 { leaps } else { &[] };
        let s = op_k2(sec, t, sec_leaps);
        let dx = p[0] - s[0];
        let dy = p[1] - s[1];
        let dz = p[2] - s[2];
        let d = (dx * dx + dy * dy + dz * dz).sqrt();
        if d < best {
            best = d;
        }
    }
    let _ = op_t7(w0, leaps);
    best
}

#[no_mangle]
pub extern "C" fn px_gap_sample(
    pri: *const PxSeg,
    pri_len: usize,
    sec: *const PxSeg,
    sec_len: usize,
    leaps: *const c_double,
    leap_len: usize,
    w0: c_double,
    w1: c_double,
    steps: c_uint,
    flags: c_uint,
) -> c_double {
    if pri.is_null() || sec.is_null() || pri_len == 0 || sec_len == 0 {
        return 0.0;
    }
    let pri_slice = unsafe { std::slice::from_raw_parts(pri, pri_len) };
    let sec_slice = unsafe { std::slice::from_raw_parts(sec, sec_len) };
    let leap_slice = if leaps.is_null() || leap_len == 0 {
        &[]
    } else {
        unsafe { std::slice::from_raw_parts(leaps, leap_len) }
    };
    op_s4(pri_slice, sec_slice, leap_slice, w0, w1, steps as usize, flags)
}
