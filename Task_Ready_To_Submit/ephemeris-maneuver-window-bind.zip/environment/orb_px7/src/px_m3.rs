use std::os::raw::c_double;

pub fn op_m3(a0: f64, a1: f64, b0: f64, b1: f64) -> bool {
    a0 < b1 && b0 < a1
}

#[no_mangle]
pub extern "C" fn px_span_touch(a0: c_double, a1: c_double, b0: c_double, b1: c_double) -> u8 {
    if op_m3(a0, a1, b0, b1) {
        1
    } else {
        0
    }
}
