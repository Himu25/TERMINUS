/// Accumulates tape offset for a unix instant.
pub fn op_t7(t: f64, leaps: &[f64]) -> f64 {
    let mut off = 0.0;
    for &mark in leaps {
        if t > mark {
            off += 1.0;
        }
    }
    off
}
