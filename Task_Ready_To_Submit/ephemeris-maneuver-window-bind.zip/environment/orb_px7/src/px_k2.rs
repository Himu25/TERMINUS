use super::a0::op_t7;

#[derive(Clone, Copy, Debug)]
#[repr(C)]
pub struct PxSeg {
    pub t0: f64,
    pub t1: f64,
    pub x: f64,
    pub y: f64,
    pub z: f64,
    pub vx: f64,
    pub vy: f64,
    pub vz: f64,
}

pub fn op_k2(segs: &[PxSeg], t: f64, leaps: &[f64]) -> [f64; 3] {
    if segs.is_empty() {
        return [0.0, 0.0, 0.0];
    }
    let seg = &segs[0];
    let eff = t + op_t7(t, leaps);
    let dt = eff - seg.t0;
    [
        seg.x + seg.vx * dt,
        seg.y + seg.vy * dt,
        seg.z + seg.vz * dt,
    ]
}

pub fn pick_span(segs: &[PxSeg], t: f64) -> Option<&PxSeg> {
    for seg in segs {
        if t >= seg.t0 && t <= seg.t1 {
            return Some(seg);
        }
    }
    segs.last()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn px_k2_roll() {
        let segs = [
            PxSeg {
                t0: 0.0,
                t1: 10.0,
                x: 0.0,
                y: 0.0,
                z: 0.0,
                vx: 1.0,
                vy: 0.0,
                vz: 0.0,
            },
            PxSeg {
                t0: 10.0,
                t1: 20.0,
                x: 10.0,
                y: 0.0,
                z: 0.0,
                vx: 2.0,
                vy: 0.0,
                vz: 0.0,
            },
        ];
        let p = op_k2(&segs, 15.0, &[]);
        assert!((p[0] - 10.0).abs() > 1.0);
    }
}
