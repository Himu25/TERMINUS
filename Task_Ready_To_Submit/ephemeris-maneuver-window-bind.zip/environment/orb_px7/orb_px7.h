#ifndef ORB_PX7_H
#define ORB_PX7_H

#include <stddef.h>
#include <stdint.h>

typedef struct {
    double t0;
    double t1;
    double x;
    double y;
    double z;
    double vx;
    double vy;
    double vz;
} px_seg;

uint8_t px_span_touch(double a0, double a1, double b0, double b1);

double px_gap_sample(
    const px_seg *pri,
    size_t pri_len,
    const px_seg *sec,
    size_t sec_len,
    const double *leaps,
    size_t leap_len,
    double w0,
    double w1,
    uint32_t steps,
    uint32_t flags
);

#endif
