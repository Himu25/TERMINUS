#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
cd /app

mkdir -p /app/bin /app/output /app/target/release

export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/app/target}"
export RUSTFLAGS="-C target-cpu=generic"

cargo build --release --locked -p orb_px7

export CGO_ENABLED=1
export CGO_CFLAGS="-I/app/orb_px7"
export CGO_LDFLAGS="-L/app/target/release -lorb_px7 -lm"
export GOFLAGS="-mod=mod"
export GOCACHE="${GOCACHE:-/app/output/go-build}"
export GOTMPDIR="${GOTMPDIR:-/tmp}"

install -d -m 0777 /app/output/go-build

go build -trimpath -ldflags="-s -w" -o /app/bin/bind_lab ./cmd/bind_lab
go build -trimpath -ldflags="-s -w" -o /app/bin/digest_cli ./tools/digest_cli

go test -c -o /dev/null ./internal/q9/...
cargo test --release --locked -p orb_px7 px_k2_roll --no-run
