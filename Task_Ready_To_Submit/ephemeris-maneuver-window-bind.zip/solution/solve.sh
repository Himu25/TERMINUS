#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

sed -i 's/if t > mark/if t >= mark/' /app/orb_px7/src/px_t7.rs

sed -i 's/let seg = \&segs\[0\];/let seg = pick_span(segs, t).unwrap_or(\&segs[0]);/' /app/orb_px7/src/px_k2.rs
sed -i 's/(p\[0\] - 10.0).abs() > 1.0/(p[0] - 20.0).abs() < 1e-6/' /app/orb_px7/src/px_k2.rs

sed -i 's/a0 < b1 && b0 < a1/a0 <= b1 \&\& b0 <= a1/' /app/orb_px7/src/px_m3.rs

perl -0pi -e 's/let mut steps = steps.max\(2\);\n    if flags & 1 != 0 \{\n        steps = steps \/ 2;\n    \}/let steps = steps.max(2);/s' /app/orb_px7/src/px_s4.rs
perl -0pi -e 's/let sec_leaps = if flags & 2 != 0 \{ leaps \} else \{ \&\[\] \};\n        let s = op_k2\(sec, t, sec_leaps\);/let s = op_k2(sec, t, leaps);/s' /app/orb_px7/src/px_s4.rs

cat > /app/internal/q9/op_b.go <<'EOF'
package q9

func OpB(passed int, overlap bool) int {
	_ = overlap
	return passed + 1
}
EOF

sed -i 's/minRange > clearM+passEps/minRange+passEps >= clearM/' /app/internal/q9/op_r.go

perl -0pi -e 's/sort\.Slice\(rows, func\(i, j int\) bool \{ return rows\[i\]\.name > rows\[j\]\.name \}\)/sort.Slice(rows, func(i, j int) bool { return rows[i].name < rows[j].name })/s' /app/internal/q9/op_d.go

perl -0pi -e 's/case "parallel":\n\t\tflags \|= 1/case "parallel":\n\t\tflags |= 1\n\t\tflags |= 2/s' /app/internal/driver/encode.go
sed -i 's/((workers >> 1) \& 0xF)/((workers \& 0xF))/' /app/internal/driver/encode.go

sed -i 's/return 1 | ((workers >> 1) \& 0xF)/return 1 | 2 | (workers \& 0xF)/' /app/internal/bridge/bridge.go

sed -i 's|fold.RoundCap(int(profileSteps("/app/profiles/default.json"))) / 2|fold.RoundCap(int(profileSteps("/app/profiles/default.json")))|' /app/internal/driver/sample.go

cat > /app/internal/bridge/canon.go <<'EOF'
package bridge

func ArrangeOrder(ids []int) []int {
	out := make([]int, len(ids))
	copy(out, ids)
	return out
}
EOF

cat > /app/internal/plan/op_p.go <<'EOF'
package plan

func OpP(ids []int) []int {
	out := append([]int(nil), ids...)
	for i := 0; i < len(out); i++ {
		for j := i + 1; j < len(out); j++ {
			if out[j] < out[i] {
				out[i], out[j] = out[j], out[i]
			}
		}
	}
	return out
}
EOF

cat > /app/internal/driver/bind_digest.go <<'EOF'
package driver

import "bindlab/pkg/fold"

func sealHex(_ []string, _ []float64, total, passed int, worst float64, leapOK, overlapOK int) string {
	return fold.DigestReport(total, passed, worst, leapOK, overlapOK)
}
EOF

bash /app/scripts/build.sh

rm -f /app/output/bind_report.json
mkdir -p /app/output
TB_BIND_FIXTURE=1 /app/bin/bind_lab
test -s /app/output/bind_report.json

env CGO_ENABLED=1 CGO_CFLAGS="-I/app/orb_px7" CGO_LDFLAGS="-L/app/target/release -lorb_px7 -lm" GOFLAGS=-mod=mod \
  go test ./internal/q9/...

cargo test --release -p orb_px7 px_k2_roll
