"""Verifier for the mission bind desk."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "bind_report.json"
BIN = "/app/bin/bind_lab"
ACTIVE_MANIFEST = APP / "data/active/manifest.json"
REPORT_EXAMPLE = APP / "schemas/bind_report.example.json"
FIXTURE_INDEX = APP / "docs/fixture_index.txt"
REG_LEAP = APP / "data/regression/pack_leap/manifest.json"
REG_OVERLAP = APP / "data/regression/pack_overlap/manifest.json"
REG_BREAK = APP / "data/regression/pack_break/manifest.json"

SCHEMA_VERSION = 2
RANGE_TOL = 1e-3
PARALLEL_RANGE_M = 450.0


def _run_bind(manifest: Path | None = None) -> dict:
    env = {**os.environ, "TB_BIND_FIXTURE": "1"}
    if manifest is not None:
        env["TB_BIND_MANIFEST"] = str(manifest)
    subprocess.run([BIN], cwd="/app", env=env, check=True)
    return json.loads(OUT.read_text())


@pytest.fixture(scope="session")
def active_report() -> dict:
    """Single active-manifest replay shared across behavioral tests."""
    return _run_bind()


def _window_row(report: dict, name: str) -> dict:
    for row in report["windows"]:
        if row["name"] == name:
            return row
    raise KeyError(name)


def _fixture_pack_names() -> list[str]:
    entries = [
        line.strip()
        for line in FIXTURE_INDEX.read_text().splitlines()
        if line.strip() and not line.startswith("#")
    ]
    names: list[str] = []
    for entry in entries:
        if entry.startswith("/app/data/regression/"):
            names.append(Path(entry).parent.name)
        elif " -> " in entry:
            names.append(entry.split(" -> ", 1)[0].strip())
        else:
            names.append(entry)
    return names


def test_b01_report_shape(active_report: dict) -> None:
    """Report carries the bind schema version and active pack id."""
    manifest = json.loads(ACTIVE_MANIFEST.read_text())
    example = json.loads(REPORT_EXAMPLE.read_text())
    assert active_report["schema_version"] == SCHEMA_VERSION
    assert active_report["pack_id"] == manifest["pack_id"]
    assert active_report["windows_total"] == len(manifest["windows"])
    for key in example:
        if key != "windows":
            assert key in active_report


def test_b02_pack_clean(active_report: dict) -> None:
    """Every active window completes with clearance satisfied."""
    assert active_report["windows_passed"] == active_report["windows_total"]
    assert active_report["min_range_worst_m"] > 0.0
    for row in active_report["windows"]:
        assert row["passed"]
        assert row["min_range_m"] > 0.0


def test_b03_leap_clearance(active_report: dict) -> None:
    """Leap-bound window row stays accepted on the active pack."""
    row = _window_row(active_report, "win_leap")
    assert row["passed"]
    assert row["lane"] == "tape"
    assert row["min_range_m"] > 250.0


def test_b04_overlap_clearance(active_report: dict) -> None:
    """Overlap tape windows both stay accepted on the active pack."""
    row_a = _window_row(active_report, "win_overlap_a")
    row_b = _window_row(active_report, "win_overlap_b")
    assert row_a["passed"] and row_b["passed"]
    assert row_a["lane"] == "pair" and row_b["lane"] == "pair"
    assert row_b["min_range_m"] >= row_a["min_range_m"]


def test_b05_leap_gate(active_report: dict) -> None:
    """Leap tape gate and parallel lane stay reconciled."""
    assert active_report["leap_ok"]
    row = _window_row(active_report, "win_parallel")
    assert row["passed"]
    assert row["lane"] == "stripe"
    assert abs(row["min_range_m"] - PARALLEL_RANGE_M) <= RANGE_TOL


def test_b06_overlap_gate(active_report: dict) -> None:
    """Overlap tape gate stays set when paired windows pass."""
    assert active_report["overlap_ok"]


def test_b07_digest_bind(active_report: dict) -> None:
    """Report digest matches digest_cli over counters."""
    proc = subprocess.run(
        [
            "/app/bin/digest_cli",
            str(active_report["windows_total"]),
            str(active_report["windows_passed"]),
            f"{active_report['min_range_worst_m']:.12e}",
            str(active_report["leap_ok"]),
            str(active_report["overlap_ok"]),
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    assert proc.stdout.strip() == active_report["digest_hex"]


def test_b08_go_units() -> None:
    """Go ledger package unit tests pass."""
    env = {
        **os.environ,
        "CGO_ENABLED": "1",
        "CGO_CFLAGS": "-I/app/orb_px7",
        "CGO_LDFLAGS": "-L/app/target/release -lorb_px7 -lm",
        "GOFLAGS": "-mod=mod",
    }
    subprocess.run(
        ["go", "test", "./internal/q9/..."],
        cwd="/app",
        env=env,
        check=True,
    )


def test_b09_rust_units() -> None:
    """Rust segment handoff smoke test passes."""
    env = {**os.environ, "CARGO_TARGET_DIR": "/app/target"}
    subprocess.run(
        ["cargo", "test", "--release", "--locked", "-p", "orb_px7", "px_k2_roll"],
        cwd="/app",
        env=env,
        check=True,
    )


def test_b10_regression_leap() -> None:
    """Leap regression pack keeps win_leap accepted."""
    report = _run_bind(manifest=REG_LEAP)
    row = _window_row(report, "win_leap")
    assert row["passed"]
    assert row["lane"] == "tape"


def test_b11_regression_overlap() -> None:
    """Overlap regression pack keeps both overlap windows accepted."""
    report = _run_bind(manifest=REG_OVERLAP)
    assert _window_row(report, "win_overlap_a")["passed"]
    assert _window_row(report, "win_overlap_b")["passed"]


def test_b12_fixture_index() -> None:
    """Fixture index lists regression pack paths that exist on disk."""
    names = _fixture_pack_names()
    assert "pack_leap" in names
    assert "pack_overlap" in names
    assert "pack_break" in names
    assert str(REG_LEAP) in FIXTURE_INDEX.read_text()
    assert str(REG_OVERLAP) in FIXTURE_INDEX.read_text()
    assert str(REG_BREAK) in FIXTURE_INDEX.read_text()
    for name in names:
        assert (APP / "data/regression" / name / "manifest.json").is_file()


def test_b13_regression_break() -> None:
    """Segment-break regression pack keeps win_handoff accepted."""
    report = _run_bind(manifest=REG_BREAK)
    row = _window_row(report, "win_handoff")
    assert row["passed"]
    assert row["min_range_m"] > 150.0


def test_b14_active_break(active_report: dict) -> None:
    """Active pack segment-break row stays accepted."""
    row = _window_row(active_report, "win_handoff")
    assert row["passed"]
    assert row["min_range_m"] > 150.0
