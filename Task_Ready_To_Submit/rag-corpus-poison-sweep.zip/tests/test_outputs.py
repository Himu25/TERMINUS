"""Verifier for RAG corpus poison sweep reports."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

APP = Path("/app")
REPORT = APP / "output" / "corpus_sweep.json"
CORPUSSWEEP = APP / "bin" / "corpussweep"
_RUN_TIMEOUT = 60


def _stem_tag(stem: str) -> str:
    bundle = json.loads((APP / "batches" / f"{stem}.json").read_text(encoding="utf-8"))
    return str(bundle["scenario_label"])


def _drive(stem: str) -> dict:
    if not CORPUSSWEEP.is_file():
        raise FileNotFoundError(
            f"missing sweep binary at {CORPUSSWEEP}; rebuild with /app/scripts/build.sh"
        )
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    if REPORT.exists():
        REPORT.unlink()
    proc = subprocess.run(
        [str(CORPUSSWEEP)],
        cwd=str(APP),
        env={**os.environ, "tb_batch": stem},
        check=False,
        capture_output=True,
        timeout=_RUN_TIMEOUT,
        start_new_session=True,
    )
    if proc.returncode != 0:
        err = proc.stderr.decode(errors="replace").strip()
        raise RuntimeError(f"corpussweep exited {proc.returncode}: {err or 'no stderr'}")
    payload = json.loads(REPORT.read_text(encoding="utf-8"))
    assert "sweep_runs" in payload and len(payload["sweep_runs"]) == 1
    row = payload["sweep_runs"][0]
    assert row.get("scenario_tag") == _stem_tag(stem)
    return row


def _assert_row(
    row: dict,
    *,
    samples_kept: int,
    samples_quarantined: int,
    weight_delta: int,
    trust_repairs: int,
    partial_blocks: int,
    rare_hits: int,
    sources_blocked: int,
    spread_epochs: int,
) -> None:
    assert row["samples_kept"] == samples_kept
    assert row["samples_quarantined"] == samples_quarantined
    assert row["weight_delta"] == weight_delta
    assert row["trust_repairs"] == trust_repairs
    assert row["partial_blocks"] == partial_blocks
    assert row["rare_hits"] == rare_hits
    assert row["sources_blocked"] == sources_blocked
    assert row["spread_epochs"] == spread_epochs


# Per-batch replay bands: tight enough that unfixed bench output fails, wide
# enough that a mostly-correct rebuild can land within ~1-3/10 agent trials.
def _assert_row_banded(
    row: dict,
    *,
    samples_kept: int | None = None,
    samples_kept_min: int | None = None,
    samples_kept_max: int | None = None,
    samples_quarantined: int | None = None,
    samples_quarantined_min: int | None = None,
    samples_quarantined_max: int | None = None,
    weight_delta: int | None = None,
    weight_delta_min: int | None = None,
    weight_delta_max: int | None = None,
    trust_repairs: int | None = None,
    trust_repairs_min: int | None = None,
    trust_repairs_max: int | None = None,
    partial_blocks: int | None = None,
    partial_blocks_max: int | None = None,
    rare_hits: int = 0,
    sources_blocked: int | None = None,
    spread_epochs: int | None = None,
    spread_epochs_min: int | None = None,
    spread_epochs_max: int | None = None,
) -> None:
    if samples_kept is not None:
        assert row["samples_kept"] == samples_kept
    else:
        lo = 0 if samples_kept_min is None else samples_kept_min
        hi = row["samples_kept"] if samples_kept_max is None else samples_kept_max
        assert lo <= row["samples_kept"] <= hi

    if samples_quarantined is not None:
        assert row["samples_quarantined"] == samples_quarantined
    else:
        lo = 0 if samples_quarantined_min is None else samples_quarantined_min
        hi = row["samples_quarantined"] if samples_quarantined_max is None else samples_quarantined_max
        assert lo <= row["samples_quarantined"] <= hi

    if weight_delta is not None:
        assert row["weight_delta"] == weight_delta
    else:
        lo = row["weight_delta"] if weight_delta_min is None else weight_delta_min
        hi = row["weight_delta"] if weight_delta_max is None else weight_delta_max
        assert lo <= row["weight_delta"] <= hi

    if trust_repairs is not None:
        assert row["trust_repairs"] == trust_repairs
    else:
        lo = 0 if trust_repairs_min is None else trust_repairs_min
        hi = row["trust_repairs"] if trust_repairs_max is None else trust_repairs_max
        assert lo <= row["trust_repairs"] <= hi

    if partial_blocks is not None:
        assert row["partial_blocks"] == partial_blocks
    elif partial_blocks_max is not None:
        assert row["partial_blocks"] <= partial_blocks_max

    assert row["rare_hits"] == rare_hits

    if sources_blocked is not None:
        assert row["sources_blocked"] == sources_blocked

    if spread_epochs is not None:
        assert row["spread_epochs"] == spread_epochs
    else:
        lo = 0 if spread_epochs_min is None else spread_epochs_min
        hi = row["spread_epochs"] if spread_epochs_max is None else spread_epochs_max
        assert lo <= row["spread_epochs"] <= hi


def test_batch_alpha_cross_source_doc_collision() -> None:
    """Shared doc_ink across retrieval sources must not collapse distinct training rows."""
    row = _drive("batch_alpha")
    _assert_row(
        row,
        samples_kept=161,
        samples_quarantined=161,
        weight_delta=0,
        trust_repairs=1,
        partial_blocks=0,
        rare_hits=0,
        sources_blocked=0,
        spread_epochs=0,
    )


def test_batch_beta_halt_scope_per_source() -> None:
    """A halt_flag on one source must not freeze QUAR rows on unrelated sources."""
    row = _drive("batch_beta")
    _assert_row_banded(
        row,
        samples_kept_min=65,
        samples_quarantined_min=65,
        weight_delta_min=-35,
        weight_delta_max=5,
        sources_blocked=1,
        spread_epochs_max=1,
    )


def test_batch_gamma_shadow_tier_excluded() -> None:
    """Training totals must ignore SHADOW-tier TRAIN rows outside the live tier contract."""
    row = _drive("batch_gamma")
    _assert_row(
        row,
        samples_kept=10,
        samples_quarantined=10,
        weight_delta=0,
        trust_repairs=0,
        partial_blocks=0,
        rare_hits=0,
        sources_blocked=0,
        spread_epochs=0,
    )


def test_batch_delta_replay_and_halt() -> None:
    """Per-source halt must not freeze rows on a different source still feeding."""
    row = _drive("batch_delta")
    _assert_row_banded(
        row,
        samples_kept_min=40,
        samples_quarantined_min=35,
        weight_delta_min=-20,
        weight_delta_max=15,
        partial_blocks_max=1,
        sources_blocked=1,
        spread_epochs_max=1,
    )


def test_batch_peak_composite() -> None:
    """Halt on one source must leave TRAIN and QUAR booking on another source intact."""
    row = _drive("batch_peak")
    _assert_row_banded(
        row,
        samples_kept_min=18,
        samples_quarantined_min=20,
        weight_delta_min=-10,
        weight_delta_max=5,
        sources_blocked=1,
        spread_epochs_max=1,
    )


def test_batch_ozone_trust_anchor_overrides_quarantine_sum() -> None:
    """Trust anchor hints interact with live-tier TRAIN weight sums."""
    row = _drive("batch_ozone")
    _assert_row(
        row,
        samples_kept=100,
        samples_quarantined=90,
        weight_delta=10,
        trust_repairs=0,
        partial_blocks=0,
        rare_hits=0,
        sources_blocked=0,
        spread_epochs=0,
    )


def test_batch_canyon_cross_source_doc_collision() -> None:
    """Shared doc_ink on distinct sources must survive narrowing with trailing replays."""
    row = _drive("batch_canyon")
    _assert_row(
        row,
        samples_kept=100,
        samples_quarantined=75,
        weight_delta=25,
        trust_repairs=2,
        partial_blocks=0,
        rare_hits=0,
        sources_blocked=0,
        spread_epochs=0,
    )


def test_batch_echo_halt_orphan_train() -> None:
    """Per-source halt drops late QUAR mirrors while live-tier TRAIN rows stay booked."""
    row = _drive("batch_echo")
    _assert_row_banded(
        row,
        samples_kept_min=50,
        samples_quarantined_min=25,
        weight_delta_min=-5,
        weight_delta_max=30,
        partial_blocks_max=2,
        sources_blocked=1,
        spread_epochs_max=1,
    )


def test_batch_frost_negative_anchor_clamp() -> None:
    """SHADOW-tier bulk and a negative trust anchor must not inflate live-tier kept totals."""
    row = _drive("batch_frost")
    _assert_row(
        row,
        samples_kept=35,
        samples_quarantined=0,
        weight_delta=35,
        trust_repairs=0,
        partial_blocks=0,
        rare_hits=1,
        sources_blocked=0,
        spread_epochs=0,
    )


def test_batch_haze_dual_halt_late_quar() -> None:
    """Independent halt_flag rows on two sources must not freeze a third source still pairing."""
    row = _drive("batch_haze")
    _assert_row_banded(
        row,
        samples_kept_min=100,
        samples_quarantined_min=100,
        weight_delta_min=-25,
        weight_delta_max=5,
        sources_blocked=2,
        spread_epochs_max=2,
    )


def test_batch_iron_replay_halt_shadow() -> None:
    """Replay collapse, per-source halt, tier exclusion, and quarantine sum interact."""
    row = _drive("batch_iron")
    _assert_row_banded(
        row,
        samples_kept_min=20,
        samples_kept_max=80,
        samples_quarantined_min=20,
        weight_delta_min=-10,
        weight_delta_max=60,
        trust_repairs=1,
        partial_blocks_max=1,
        sources_blocked=1,
        spread_epochs_max=1,
    )


def test_batch_jade_triple_replay_same_source() -> None:
    """Three identical ingests on one source must count as two trust_repairs events."""
    row = _drive("batch_jade")
    _assert_row(
        row,
        samples_kept=7,
        samples_quarantined=7,
        weight_delta=0,
        trust_repairs=2,
        partial_blocks=0,
        rare_hits=0,
        sources_blocked=0,
        spread_epochs=0,
    )


def test_batch_kite_halt_unrelated_source_quar() -> None:
    """Halting one source must not block QUAR or TRAIN lines on a different source."""
    row = _drive("batch_kite")
    _assert_row_banded(
        row,
        samples_kept_min=120,
        samples_quarantined_min=120,
        weight_delta_min=-65,
        weight_delta_max=5,
        sources_blocked=1,
        spread_epochs_max=1,
    )


def test_batch_loom_interleaved_dup_halt() -> None:
    """Interleaved sources with shared doc_ink must keep one TRAIN row per source after narrowing."""
    row = _drive("batch_loom")
    _assert_row(
        row,
        samples_kept=18,
        samples_quarantined=18,
        weight_delta=0,
        trust_repairs=1,
        partial_blocks=0,
        rare_hits=0,
        sources_blocked=1,
        spread_epochs=0,
    )


def test_batch_mist_anchor_shadow_replay() -> None:
    """Trust anchor override, SHADOW TRAIN, and duplicate replay must not double-count kept weight."""
    row = _drive("batch_mist")
    _assert_row(
        row,
        samples_kept=100,
        samples_quarantined=75,
        weight_delta=25,
        trust_repairs=1,
        partial_blocks=0,
        rare_hits=0,
        sources_blocked=0,
        spread_epochs=0,
    )


def test_batch_nova_full_stack_stress() -> None:
    """HELD-tier TRAIN weight must stay off kept totals while QUAR sums stay booked."""
    row = _drive("batch_nova")
    _assert_row(
        row,
        samples_kept=24,
        samples_quarantined=48,
        weight_delta=-24,
        trust_repairs=0,
        partial_blocks=0,
        rare_hits=0,
        sources_blocked=0,
        spread_epochs=0,
    )


def test_batch_veil_partial_aux_poison() -> None:
    """common_sig triggers present only on aux_surface must increment partial_blocks."""
    row = _drive("batch_veil")
    _assert_row(
        row,
        samples_kept=65,
        samples_quarantined=25,
        weight_delta=40,
        trust_repairs=0,
        partial_blocks=1,
        rare_hits=0,
        sources_blocked=0,
        spread_epochs=0,
    )


def test_batch_ripple_delayed_spread_window() -> None:
    """spread_lag must quarantine only QUAR rows within the contamination window after halt."""
    row = _drive("batch_ripple")
    _assert_row_banded(
        row,
        samples_kept_min=35,
        samples_quarantined_max=10,
        weight_delta_min=30,
        partial_blocks_max=1,
        sources_blocked=1,
        spread_epochs_min=1,
        spread_epochs_max=2,
    )
