package ridge_d7

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libridge_fold.a -ldl -lm
#include "ridge_fold.h"
#include <stdlib.h>
*/
import "C"

import (
	"unsafe"

	"corpusweep/feedwire"
)

// SweepView is one sweep row for JSON emission.
type SweepView struct {
	SamplesKept        int
	SamplesQuarantined int
	WeightDelta        int
	PartialBlocks      int
}

// FoldSpan folds training and quarantine views after carry.
func FoldSpan(rows []feedwire.Row, posted string, anchor *int) SweepView {
	if len(rows) == 0 {
		return viewFrom(C.vf_meter_span(nil, 0, cStr(posted), cAnchor(anchor)))
	}
	cRows := make([]C.vf_row, len(rows))
	keepers := make([]*C.char, 0, len(rows)*4+1)
	defer freeAll(keepers)

	for idx := range rows {
		r := rows[idx]
		w := C.CString(r.Source)
		i := C.CString(r.Doc)
		f := C.CString(r.Role)
		b := C.CString(r.Tier)
		keepers = append(keepers, w, i, f, b)
		cRows[idx] = C.vf_row{
			wire:     w,
			ink:      i,
			grain:    C.int(r.Weight),
			face:     f,
			band:     b,
			sentinel: C.bool(r.HaltFlag),
		}
	}
	p := cStr(posted)
	keepers = append(keepers, p)
	ct := C.vf_meter_span(
		(*C.vf_row)(unsafe.Pointer(&cRows[0])),
		C.size_t(len(cRows)),
		p,
		cAnchor(anchor),
	)
	return viewFrom(ct)
}

func cStr(s string) *C.char {
	return C.CString(s)
}

func cAnchor(anchor *int) *C.int {
	if anchor == nil {
		return nil
	}
	v := C.int(*anchor)
	return &v
}

func freeAll(ptrs []*C.char) {
	for _, p := range ptrs {
		C.free(unsafe.Pointer(p))
	}
}

func viewFrom(ct C.vf_tally) SweepView {
	return SweepView{
		SamplesKept:        int(ct.primary_score),
		SamplesQuarantined: int(ct.diversity_score),
		WeightDelta:        int(ct.score_delta),
		PartialBlocks:      int(ct.stale_skips),
	}
}
