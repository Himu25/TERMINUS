#ifndef RIDGE_FOLD_H
#define RIDGE_FOLD_H

#include <stdbool.h>
#include <stddef.h>

typedef struct {
    const char *wire;
    const char *ink;
    int grain;
    const char *face;
    const char *band;
    bool sentinel;
} vf_row;

typedef struct {
    int primary_score;
    int diversity_score;
    int score_delta;
    int stale_skips;
} vf_tally;

vf_tally vf_meter_span(
    const vf_row *rows,
    size_t count,
    const char *posted,
    const int *anchor
);

#endif
