// Package ridge_d7 binds numeric views through a Rust fold library.
package ridge_d7
