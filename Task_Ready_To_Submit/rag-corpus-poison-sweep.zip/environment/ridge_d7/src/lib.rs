use std::ffi::CStr;
use std::os::raw::{c_char, c_int};

#[repr(C)]
pub struct VfRow {
    pub wire: *const c_char,
    pub ink: *const c_char,
    pub grain: c_int,
    pub face: *const c_char,
    pub band: *const c_char,
    pub sentinel: bool,
}

#[repr(C)]
pub struct VfRoll {
    pub primary_score: c_int,
    pub diversity_score: c_int,
    pub score_delta: c_int,
    pub stale_skips: c_int,
}

struct RowView<'a> {
    wire: &'a str,
    face: &'a str,
    band: &'a str,
    grain: i32,
    sentinel: bool,
}

fn row_at(raw: &VfRow) -> Option<RowView<'_>> {
    unsafe {
        Some(RowView {
            wire: CStr::from_ptr(raw.wire).to_str().ok()?,
            face: CStr::from_ptr(raw.face).to_str().ok()?,
            band: CStr::from_ptr(raw.band).to_str().ok()?,
            grain: raw.grain,
            sentinel: raw.sentinel,
        })
    }
}

fn accrete_p(rows: &[RowView]) -> i32 {
    rows.iter()
        .filter(|r| r.face == "TRAIN" && !r.sentinel)
        .map(|r| r.grain)
        .sum()
}

fn side_q(rows: &[RowView], anchor: Option<i32>) -> i32 {
    let mut mirror = rows
        .iter()
        .filter(|r| r.face == "QUAR")
        .map(|r| r.grain)
        .sum::<i32>();
    if let Some(hint) = anchor {
        mirror = hint;
    }
    mirror
}

fn lone_r(rows: &[RowView], posted: &str) -> i32 {
    let mut orphan = 0;
    for r in rows {
        if r.face != "TRAIN" || r.sentinel || r.band != posted {
            continue
        }
        let paired = rows.iter().any(|m| m.face == "QUAR" && m.wire == r.wire);
        if !paired {
            orphan += 1;
        }
    }
    orphan
}

#[no_mangle]
pub extern "C" fn vf_meter_span(
    rows: *const VfRow,
    count: usize,
    posted: *const c_char,
    anchor: *const c_int,
) -> VfRoll {
    let posted = unsafe {
        CStr::from_ptr(posted)
            .to_str()
            .unwrap_or("")
            .to_string()
    };
    let anchor_val = if anchor.is_null() {
        None
    } else {
        Some(unsafe { *anchor })
    };

    let mut parsed = Vec::with_capacity(count);
    if !rows.is_null() {
        let slice = unsafe { std::slice::from_raw_parts(rows, count) };
        for raw in slice {
            if let Some(v) = row_at(raw) {
                parsed.push(v);
            }
        }
    }

    let booked = accrete_p(&parsed);
    let mirror = side_q(&parsed, anchor_val);
    let orphan = lone_r(&parsed, &posted);
    VfRoll {
        primary_score: booked,
        diversity_score: mirror,
        score_delta: booked - mirror,
        stale_skips: orphan,
    }
}
