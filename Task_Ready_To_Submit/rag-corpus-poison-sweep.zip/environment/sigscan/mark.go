package sigscan

import (
	"strings"

	"corpusweep/feedwire"
)

func fold(s string) string {
	return strings.ToLower(s)
}

func hasAny(text string, sigs []string) bool {
	low := fold(text)
	for _, sig := range sigs {
		if sig == "" {
			continue
		}
		if strings.Contains(low, fold(sig)) {
			return true
		}
	}
	return false
}

// RareTally counts ingest rows whose body or aux matches rare_sig markers.
func RareTally(rows []feedwire.Row, rare []string) int {
	if len(rare) == 0 {
		return 0
	}
	n := 0
	for _, r := range rows {
		if hasAny(r.Doc, rare) || hasAny(r.AuxSurface, rare) {
			n++
		}
	}
	return n
}

// PartialTally counts rows with triggers only on aux_surface, not on doc_ink.
func PartialTally(rows []feedwire.Row, common []string) int {
	if len(common) == 0 {
		return 0
	}
	n := 0
	for _, r := range rows {
		if hasAny(r.Doc, common) {
			continue
		}
		if hasAny(r.AuxSurface, common) {
			n++
		}
	}
	return n
}

// BlockedSources counts distinct source_tag values that raised halt_flag.
func BlockedSources(rows []feedwire.Row) int {
	seen := map[string]bool{}
	for _, r := range rows {
		if r.HaltFlag {
			seen[r.Source] = true
		}
	}
	return len(seen)
}
