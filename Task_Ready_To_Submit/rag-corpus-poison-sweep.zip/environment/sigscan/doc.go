// Package sigscan tallies marker hits on ingest surfaces.
package sigscan
