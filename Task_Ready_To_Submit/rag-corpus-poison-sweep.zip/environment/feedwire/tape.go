package feedwire

// Row is one ingest line from a retrieval source into the training corpus builder.
type Row struct {
	Source     string `json:"source_tag"`
	Doc        string `json:"doc_ink"`
	Weight     int    `json:"weight"`
	Role       string `json:"role"`
	Tier       string `json:"tier"`
	HaltFlag   bool   `json:"halt_flag"`
	Epoch      int    `json:"epoch"`
	AuxSurface string `json:"aux_surface"`
}

// Batch is one deterministic replay under /app/batches.
type Batch struct {
	ScenarioLabel  string   `json:"scenario_label"`
	LiveTierToken  string   `json:"live_tier_token"`
	TrustAnchor    *int     `json:"trust_anchor"`
	HaltPairSource string   `json:"halt_pair_source"`
	SpreadLag      int      `json:"spread_lag"`
	CommonSig      []string `json:"common_sig"`
	RareSig        []string `json:"rare_sig"`
	Ingest         []Row    `json:"ingest"`
}
