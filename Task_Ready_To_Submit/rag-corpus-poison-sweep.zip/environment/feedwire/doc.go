// Package feedwire defines batch ingest tapes for corpus sweeps.
package feedwire
