package runner

import (
	"corpusweep/feedwire"
	"corpusweep/keel_m8"
)

func runShift(rows []feedwire.Row, pair string, lag int) ([]feedwire.Row, int) {
	return keel_m8.ShiftSpan(rows, pair, lag)
}
