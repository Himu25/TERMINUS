package runner

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"

	"corpusweep/feedwire"
	"corpusweep/sigscan"
)

// SweepRun is the JSON shape for one scenario emission.
type SweepRun struct {
	ScenarioTag        string `json:"scenario_tag"`
	SamplesKept        int    `json:"samples_kept"`
	SamplesQuarantined int    `json:"samples_quarantined"`
	WeightDelta        int    `json:"weight_delta"`
	TrustRepairs       int    `json:"trust_repairs"`
	PartialBlocks      int    `json:"partial_blocks"`
	RareHits           int    `json:"rare_hits"`
	SourcesBlocked     int    `json:"sources_blocked"`
	SpreadEpochs       int    `json:"spread_epochs"`
}

type sweepPayload struct {
	SweepRuns []SweepRun `json:"sweep_runs"`
}

// Run loads one batch using tb_batch, writes /app/output/corpus_sweep.json.
func Run() error {
	stem := os.Getenv("tb_batch")
	if stem == "" {
		return errors.New("tb_batch must name a stem under /app/batches")
	}
	emit := "/app/output/corpus_sweep.json"
	raw, err := os.ReadFile(filepath.Join("/app", "batches", stem+".json"))
	if err != nil {
		return err
	}
	var batch feedwire.Batch
	if err := json.Unmarshal(raw, &batch); err != nil {
		return err
	}
	trimmed, noise := runClip(batch.Ingest)
	carried, spreadCuts := runShift(trimmed, batch.HaltPairSource, batch.SpreadLag)
	view := runSeal(carried, batch.LiveTierToken, batch.TrustAnchor)
	rare := sigscan.RareTally(batch.Ingest, batch.CommonSig)
	partial := sigscan.PartialTally(batch.Ingest, batch.CommonSig)
	blocked := sigscan.BlockedSources(batch.Ingest)
	run := SweepRun{
		ScenarioTag:        batch.ScenarioLabel,
		SamplesKept:        view.SamplesKept,
		SamplesQuarantined: view.SamplesQuarantined,
		WeightDelta:        view.WeightDelta,
		TrustRepairs:       noise,
		PartialBlocks:      view.PartialBlocks,
		RareHits:           rare,
		SourcesBlocked:     blocked,
		SpreadEpochs:       spreadCuts,
	}
	_ = partial
	out := sweepPayload{SweepRuns: []SweepRun{run}}
	if err := os.MkdirAll(filepath.Dir(emit), 0o755); err != nil {
		return err
	}
	buf, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		return err
	}
	tmp := emit + ".tmp"
	if err := os.WriteFile(tmp, buf, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, emit)
}

// MainExit is a thin wrapper for cmd.
func MainExit() int {
	if err := Run(); err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		return 1
	}
	return 0
}
