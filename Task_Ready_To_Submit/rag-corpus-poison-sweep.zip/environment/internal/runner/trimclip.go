package runner

import (
	"corpusweep/feedwire"
	"corpusweep/flux_p2"
)

func runClip(rows []feedwire.Row) ([]feedwire.Row, int) {
	return flux_p2.ClipSpan(rows)
}
