package runner

import (
	"corpusweep/feedwire"
	"corpusweep/ridge_d7"
)

func runSeal(rows []feedwire.Row, posted string, anchor *int) ridge_d7.SweepView {
	return ridge_d7.FoldSpan(rows, posted, anchor)
}
