module corpusweep

go 1.22
