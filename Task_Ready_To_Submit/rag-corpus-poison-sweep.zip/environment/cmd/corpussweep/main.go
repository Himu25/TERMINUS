// corpussweep replays one batch from /app/batches when tb_batch is set.
//
// Output /app/output/corpus_sweep.json carries sweep_runs[0] with:
// scenario_tag,
// samples_kept (TRAIN weight on tier matching live_tier_token; held/shadow off totals),
// samples_quarantined (QUAR sum or trust_anchor override, floored at zero),
// weight_delta (kept minus quarantined),
// trust_repairs (duplicate ingest rows removed during narrowing),
// partial_blocks (common_sig only on aux_surface, after narrowing and shift),
// rare_hits (rare_sig on doc_ink or aux_surface, after narrowing and shift),
// sources_blocked (distinct halt_flag sources),
// spread_epochs (QUAR rows cut inside spread_lag after halt).
// Negative trust_anchor counts as zero for samples_quarantined.
package main

import (
	"os"

	"corpusweep/internal/runner"
)

func main() {
	os.Exit(runner.MainExit())
}
