# Corpus sweep ingest

Mixed Go/Rust pipeline that replays retrieval-sourced training batches, narrows duplicates, applies per-source halt and spread windows, and emits trust metrics under `/app/output`.

Build: `/app/scripts/build.sh`  
Run: `tb_batch=<stem> /app/bin/corpussweep`
