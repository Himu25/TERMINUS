package keel_m8

import "corpusweep/feedwire"

// ShiftSpan applies halt and delayed-spread ordering after narrowing.
func ShiftSpan(rows []feedwire.Row, _ string, spreadLag int) ([]feedwire.Row, int) {
	out := make([]feedwire.Row, 0, len(rows))
	stopped := false
	spreadCuts := 0
	for idx := range rows {
		r := rows[idx]
		if r.HaltFlag {
			stopped = true
			out = append(out, r)
			continue
		}
		if stopped {
			if r.Role == "QUAR" {
				spreadCuts++
			}
			continue
		}
		out = append(out, r)
	}
	return out, spreadCuts
}
