// Package keel_m8 walks narrowed rows with sentinel awareness.
package keel_m8
