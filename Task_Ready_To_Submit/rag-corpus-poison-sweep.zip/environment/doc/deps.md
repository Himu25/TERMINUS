Vendor `face` values are TRAIN or QUAR.
