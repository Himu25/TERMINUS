# Architecture sketch

- `cmd/corpussweep` CLI entry (reads `tb_batch` for the batches stem)
- `flux_p2` replay collapse
- `keel_m8` lock-row walk
- `ridge_d7` certified/provisional fold via cgo
- `internal/runner` wires stages without centralizing every fix symbol
