Local smoke: `go build -o /tmp/corpussweep ./cmd/corpussweep && tb_batch=batch_alpha /tmp/corpussweep`
