package flux_p2

import (
	"strings"

	"corpusweep/feedwire"
)

func tagFrom(r feedwire.Row) string {
	return r.Doc
}

// ClipSpan removes replayed duplicates while preserving first-seen order.
func ClipSpan(rows []feedwire.Row) ([]feedwire.Row, int) {
	seen := map[string]bool{}
	out := make([]feedwire.Row, 0, len(rows))
	noise := 0
	for idx := range rows {
		r := rows[idx]
		key := tagFrom(r)
		if seen[key] {
			noise++
			continue
		}
		seen[key] = true
		out = append(out, r)
	}
	return out, noise
}

// TagKey is the composite dedupe key used after repair.
func TagKey(r feedwire.Row) string {
	var b strings.Builder
	src := strings.TrimSpace(r.Source)
	if src == "" {
		src = r.Doc
	}
	b.WriteString(src)
	b.WriteByte('|')
	b.WriteString(strings.TrimSpace(r.Doc))
	return b.String()
}
