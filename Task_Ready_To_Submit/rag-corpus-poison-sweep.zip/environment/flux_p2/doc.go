// Package flux_p2 narrows replayed ingest rows.
package flux_p2
