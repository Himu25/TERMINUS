#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/flux_p2/prune.go <<'EOF'
package flux_p2

import (
	"strings"

	"corpusweep/feedwire"
)

func tagFrom(r feedwire.Row) string {
	var b strings.Builder
	src := strings.TrimSpace(r.Source)
	if src == "" {
		src = r.Doc
	}
	b.Grow(len(src) + 1 + len(r.Doc))
	b.WriteString(src)
	b.WriteByte('|')
	b.WriteString(strings.TrimSpace(r.Doc))
	return b.String()
}

// ClipSpan removes replayed duplicates while preserving first-seen order.
func ClipSpan(rows []feedwire.Row) ([]feedwire.Row, int) {
	seen := map[string]bool{}
	out := make([]feedwire.Row, 0, len(rows))
	noise := 0
	for idx := range rows {
		r := rows[idx]
		key := tagFrom(r)
		if seen[key] {
			noise++
			continue
		}
		seen[key] = true
		out = append(out, r)
	}
	return out, noise
}

// TagKey is the composite dedupe key used after repair.
func TagKey(r feedwire.Row) string {
	return tagFrom(r)
}
EOF

cat > /app/keel_m8/k2_span.go <<'EOF'
package keel_m8

import "corpusweep/feedwire"

// ShiftSpan applies halt and delayed-spread ordering after narrowing.
func ShiftSpan(rows []feedwire.Row, _ string, spreadLag int) ([]feedwire.Row, int) {
	out := make([]feedwire.Row, 0, len(rows))
	haltEpoch := map[string]int{}
	spreadCuts := 0
	for idx := range rows {
		r := rows[idx]
		if r.HaltFlag {
			if _, seen := haltEpoch[r.Source]; !seen {
				haltEpoch[r.Source] = r.Epoch
			}
			out = append(out, r)
			continue
		}
		ep, halted := haltEpoch[r.Source]
		if halted && r.Role == "QUAR" && r.Epoch > ep {
			if spreadLag > 0 {
				if r.Epoch <= ep+spreadLag {
					spreadCuts++
					continue
				}
			} else {
				continue
			}
		}
		out = append(out, r)
	}
	return out, spreadCuts
}
EOF

cat > /app/internal/runner/drive.go <<'EOF'
package runner

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"

	"corpusweep/feedwire"
	"corpusweep/sigscan"
)

// SweepRun is the JSON shape for one scenario emission.
type SweepRun struct {
	ScenarioTag        string `json:"scenario_tag"`
	SamplesKept        int    `json:"samples_kept"`
	SamplesQuarantined int    `json:"samples_quarantined"`
	WeightDelta        int    `json:"weight_delta"`
	TrustRepairs       int    `json:"trust_repairs"`
	PartialBlocks      int    `json:"partial_blocks"`
	RareHits           int    `json:"rare_hits"`
	SourcesBlocked     int    `json:"sources_blocked"`
	SpreadEpochs       int    `json:"spread_epochs"`
}

type sweepPayload struct {
	SweepRuns []SweepRun `json:"sweep_runs"`
}

// Run loads one batch using tb_batch, writes /app/output/corpus_sweep.json.
func Run() error {
	stem := os.Getenv("tb_batch")
	if stem == "" {
		return errors.New("tb_batch must name a stem under /app/batches")
	}
	emit := "/app/output/corpus_sweep.json"
	raw, err := os.ReadFile(filepath.Join("/app", "batches", stem+".json"))
	if err != nil {
		return err
	}
	var batch feedwire.Batch
	if err := json.Unmarshal(raw, &batch); err != nil {
		return err
	}
	trimmed, noise := runClip(batch.Ingest)
	carried, spreadCuts := runShift(trimmed, batch.HaltPairSource, batch.SpreadLag)
	view := runSeal(carried, batch.LiveTierToken, batch.TrustAnchor)
	rare := sigscan.RareTally(carried, batch.RareSig)
	partial := sigscan.PartialTally(carried, batch.CommonSig)
	blocked := sigscan.BlockedSources(batch.Ingest)
	run := SweepRun{
		ScenarioTag:        batch.ScenarioLabel,
		SamplesKept:        view.SamplesKept,
		SamplesQuarantined: view.SamplesQuarantined,
		WeightDelta:        view.WeightDelta,
		TrustRepairs:       noise,
		PartialBlocks:      partial,
		RareHits:           rare,
		SourcesBlocked:     blocked,
		SpreadEpochs:       spreadCuts,
	}
	out := sweepPayload{SweepRuns: []SweepRun{run}}
	if err := os.MkdirAll(filepath.Dir(emit), 0o755); err != nil {
		return err
	}
	buf, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		return err
	}
	tmp := emit + ".tmp"
	if err := os.WriteFile(tmp, buf, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, emit)
}

// MainExit is a thin wrapper for cmd.
func MainExit() int {
	if err := Run(); err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		return 1
	}
	return 0
}
EOF

cat > /app/ridge_d7/src/lib.rs <<'EOF'
use std::ffi::CStr;
use std::os::raw::{c_char, c_int};

#[repr(C)]
pub struct VfRow {
    pub wire: *const c_char,
    pub ink: *const c_char,
    pub grain: c_int,
    pub face: *const c_char,
    pub band: *const c_char,
    pub sentinel: bool,
}

#[repr(C)]
pub struct VfRoll {
    pub primary_score: c_int,
    pub diversity_score: c_int,
    pub score_delta: c_int,
    pub stale_skips: c_int,
}

struct RowView<'a> {
    wire: &'a str,
    face: &'a str,
    band: &'a str,
    grain: i32,
    sentinel: bool,
}

fn row_at(raw: &VfRow) -> Option<RowView<'_>> {
    unsafe {
        Some(RowView {
            wire: CStr::from_ptr(raw.wire).to_str().ok()?,
            face: CStr::from_ptr(raw.face).to_str().ok()?,
            band: CStr::from_ptr(raw.band).to_str().ok()?,
            grain: raw.grain,
            sentinel: raw.sentinel,
        })
    }
}

fn accrete_q(rows: &[RowView], mark: &str) -> i32 {
    rows.iter()
        .filter(|r| r.face == "TRAIN" && !r.sentinel && r.band == mark)
        .map(|r| r.grain)
        .sum()
}

fn side_q(rows: &[RowView], anchor: Option<i32>) -> i32 {
    let mut mirror = rows
        .iter()
        .filter(|r| r.face == "QUAR")
        .map(|r| r.grain)
        .sum::<i32>();
    if let Some(hint) = anchor {
        mirror = if hint < 0 { 0 } else { hint };
    }
    if mirror < 0 {
        mirror = 0;
    }
    mirror
}

fn lone_r(rows: &[RowView], posted: &str) -> i32 {
    let mut orphan = 0;
    for r in rows {
        if r.face != "TRAIN" || r.sentinel || r.band != posted {
            continue
        }
        let paired = rows.iter().any(|m| m.face == "QUAR" && m.wire == r.wire);
        if !paired {
            orphan += 1;
        }
    }
    orphan
}

#[no_mangle]
pub extern "C" fn vf_meter_span(
    rows: *const VfRow,
    count: usize,
    posted: *const c_char,
    anchor: *const c_int,
) -> VfRoll {
    let posted = unsafe {
        CStr::from_ptr(posted)
            .to_str()
            .unwrap_or("")
            .to_string()
    };
    let anchor_val = if anchor.is_null() {
        None
    } else {
        Some(unsafe { *anchor })
    };

    let mut parsed = Vec::with_capacity(count);
    if !rows.is_null() {
        let slice = unsafe { std::slice::from_raw_parts(rows, count) };
        for raw in slice {
            if let Some(v) = row_at(raw) {
                parsed.push(v);
            }
        }
    }

    let booked = accrete_q(&parsed, &posted);
    let mirror = side_q(&parsed, anchor_val);
    let orphan = lone_r(&parsed, &posted);
    VfRoll {
        primary_score: booked,
        diversity_score: mirror,
        score_delta: booked - mirror,
        stale_skips: orphan,
    }
}
EOF

bash /app/scripts/build.sh
