Retrieval feeds under `/app` are marking corpora clean, but poisoned training rows show up in replay output. Rebuild the sweep binary, replay bundled batches, and repair the pipeline until `/app/output/corpus_sweep.json` reports honest counters.

Replay collapse conflates unrelated retrieval sources when narrowing keys on document text alone. Shared doc_ink values from different source_tag lines survive as separate rows; replay duplicates on the same source increment the repair counter once per dropped line in first-seen order.

Halt handling stays scoped to the source that raised halt_flag. Rows from other sources continue to pair and book normally mid-batch. The spread counter records QUAR lines trimmed from a halted source inside the batch lag window, and the blocked-source count reflects distinct halt_flag sources on the ingest tape.

The kept total includes live-tier TRAIN weight only; held and shadow tiers do not add to it. Quarantine normally sums QUAR weight unless a trust_anchor hint overrides it—negative anchors clamp to zero so quarantine stays non-negative. Weight delta is kept minus quarantine.

Partial and rare poison tallies belong on the narrowed-and-shifted feed, not the raw ingest tape. Partial hits require common signature markers on auxiliary surfaces only; rare hits match rare signature tokens on document or auxiliary text on that same feed.

Run `/app/scripts/build.sh` to rebuild `/app/bin/corpussweep`, set `tb_batch` to the batch stem, and write `/app/output/corpus_sweep.json` with `sweep_runs` length 1 and `scenario_tag` from the batch. JSON field definitions are in `/app/cmd/corpussweep/main.go`. Signal completion for correct bundled batch replays.