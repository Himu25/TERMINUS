#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1

cd /app/shieldgate
cargo build --release --locked

cd /app
go build -trimpath -buildvcs=false -o /app/bin/corpus_scan ./cmd/corpus_scan
