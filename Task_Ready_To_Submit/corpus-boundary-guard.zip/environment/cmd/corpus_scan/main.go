// Report JSON for /app/output/boundary_report.json:
//
// schema_version — string, must be "1"
// pack_id — string, echoes active pack name
// lanes_scanned — count of chunk records replayed
// blocks_applied — surfaces blocked after scoring
// keep_intact — keeper surfaces preserved despite scoring
// peel_repairs — successful peel steps across all surfaces (peel runs before script fold)
// locale_mix — string, "mono" or "mixed"
// bundle_clean — boolean (not 0/1 strings)
// digest_hex — lowercase hex SHA-256 of pack_id|lanes_scanned|blocks_applied|keep_intact|peel_repairs|locale_mix|bundle_clean
//
// Replay walks each chunk in the active pack. Scan surfaces include body text and every aux map value.
// Each surface peels layered encodings for the chunk depth before script folding. Surfaces block when
// signature score meets gate_need and keeper folding rejects them. Keeper folding accepts surfaces whose
// folded text includes a keeper marker and the template prefix. locale_mix is mixed when any chunk locale
// differs from the pack mono locale. bundle_clean is true only when every scored threat surface was blocked or kept.
//
// Root object contains only these keys.
package main

import (
	"log"
	"os"

	"lab.local/corpus_boundary_guard/internal/driver"
)

func main() {
	if os.Getenv("TB_CORPUS_FIXTURE") != "1" {
		log.Fatal("TB_CORPUS_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/boundary_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
