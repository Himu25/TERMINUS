module lab.local/corpus_boundary_guard

go 1.22
