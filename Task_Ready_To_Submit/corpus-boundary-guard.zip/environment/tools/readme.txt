Digest helper for boundary report checksums. peel_ref provides one transport unwrap step for replay checks.
