package main

import (
	"fmt"
	"os"

	"lab.local/corpus_boundary_guard/pkg/digest"
)

func main() {
	if len(os.Args) != 8 {
		fmt.Fprintln(os.Stderr, "usage: gen_digest pack lanes blocks keep peel mix clean")
		os.Exit(2)
	}
	fmt.Println(digest.Hex(os.Args[1], os.Args[2], os.Args[3], os.Args[4], os.Args[5], os.Args[6], os.Args[7]))
}
