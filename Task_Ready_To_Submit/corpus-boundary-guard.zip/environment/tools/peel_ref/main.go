package main

import (
	"encoding/base64"
	"fmt"
	"os"
)

func main() {
	if len(os.Args) != 2 {
		fmt.Fprintln(os.Stderr, "usage: peel_ref <text>")
		os.Exit(2)
	}
	raw := os.Args[1]
	out, err := base64.StdEncoding.DecodeString(raw)
	if err != nil {
		fmt.Print(raw)
		return
	}
	fmt.Print(string(out))
}
