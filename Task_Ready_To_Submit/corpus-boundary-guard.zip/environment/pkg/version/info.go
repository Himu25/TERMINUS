package version

const ToolVersion = "0.4.2"
