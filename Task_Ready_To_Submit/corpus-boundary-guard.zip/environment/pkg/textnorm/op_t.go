package textnorm

import "strings"

var homoMap = map[rune]rune{
	'\u0430': 'a',
	'\u0435': 'e',
	'\u043e': 'o',
	'\u0440': 'p',
	'\u0441': 'c',
	'\u0443': 'y',
	'\u0445': 'x',
	'\u0456': 'i',
}

func foldRunes(s string) string {
	var b strings.Builder
	b.Grow(len(s))
	for _, r := range s {
		if mapped, ok := homoMap[r]; ok {
			b.WriteRune(mapped)
			continue
		}
		b.WriteRune(r)
	}
	return b.String()
}

func OpT(s string) string {
	return strings.ToLower(s)
}
