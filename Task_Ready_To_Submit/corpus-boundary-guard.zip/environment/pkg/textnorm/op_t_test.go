package textnorm

import "testing"

func TestOpTLower(t *testing.T) {
	if OpT("AbC") != "abc" {
		t.Fatalf("expected lowercase fold")
	}
}
