package peel

/*
#cgo LDFLAGS: -L${SRCDIR}/../../shieldgate/target/release -lshieldgate
#include "../../shieldgate/shield_fold.h"
#include <stdlib.h>
*/
import "C"
import (
	"unsafe"
)

func Run(text string, layers int) (string, int) {
	if layers <= 0 {
		return text, 0
	}
	cur := text
	repairs := 0
	for i := 0; i < layers; i++ {
		cstr := C.CString(cur)
		out := C.sg_shift(cstr)
		C.free(unsafe.Pointer(cstr))
		if out == nil {
			break
		}
		next := C.GoString(out)
		C.free(unsafe.Pointer(out))
		if next == cur {
			break
		}
		cur = next
		repairs++
	}
	return cur, repairs
}
