package allowfold

func OpW(text string, markers []string, prefix string) bool {
	_ = markers
	_ = prefix
	_ = text
	return false
}
