package frame

type Row struct {
	ChunkID string
	Lane    string
	Text    string
}
