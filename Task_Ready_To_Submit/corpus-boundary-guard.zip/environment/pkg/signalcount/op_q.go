package signalcount

func OpQ(score int, need int) bool {
	if need < 0 {
		return false
	}
	return score > need
}
