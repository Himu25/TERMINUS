# Corpus layout

Active pack lives under `/app/data/active/`. Chunk JSONL files list body lanes, aux maps, locale tags, and layer counts. Scenario packs under `/app/data/scenarios/` mirror the active layout. Replay helpers live under `/app/tools/` (`gen_digest`, `peel_ref`). Verifier staging may copy `/app/bin/corpus_scan` to `/app/bin/corpus_scan_verify`.
