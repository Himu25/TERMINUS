Upgrade fragment: mono locale baseline is `en` unless pack overrides.
