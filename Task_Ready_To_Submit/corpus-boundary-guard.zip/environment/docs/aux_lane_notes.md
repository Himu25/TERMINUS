Sidecar aux fields carry citation footers and editor notes alongside the body lane.
