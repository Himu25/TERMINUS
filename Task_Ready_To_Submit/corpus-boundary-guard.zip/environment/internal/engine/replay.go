package engine

import (
	"os/exec"
	"strconv"

	"lab.local/corpus_boundary_guard/internal/chunk"
	"lab.local/corpus_boundary_guard/internal/config"
)

type Outcome struct {
	LanesScanned  uint32
	BlocksApplied uint32
	KeepIntact    uint32
	PeelRepairs   uint32
	LocaleMix     string
	BundleClean   bool
}

func Replay(pack config.Pack, chunks []config.Chunk) Outcome {
	var blocks, keep, peel uint32
	mixed := false
	threatSeen := false
	allHandled := true

	for _, c := range chunks {
		if c.Locale != "" && c.Locale != pack.LocaleMono {
			mixed = true
		}
		res := chunk.Process(c, pack)
		blocks += res.Blocks
		keep += res.Keep
		peel += res.Peel
		if res.ThreatSeen && !res.Handled {
			allHandled = false
		}
		if res.ThreatSeen {
			threatSeen = true
		}
	}

	mix := "mono"
	if mixed {
		mix = "mixed"
	}
	clean := true
	if threatSeen {
		clean = allHandled && (blocks+keep) > 0
	}

	return Outcome{
		LanesScanned:  uint32(len(chunks)),
		BlocksApplied: blocks,
		KeepIntact:    keep,
		PeelRepairs:   peel,
		LocaleMix:     mix,
		BundleClean:   clean,
	}
}

func DigestFor(
	packID string,
	lanes uint32,
	blocks uint32,
	keep uint32,
	peel uint32,
	mix string,
	clean bool,
) (string, error) {
	ck := "false"
	if clean {
		ck = "true"
	}
	cmd := exec.Command(
		"go", "run", "-mod=mod", "/app/tools/gen_digest",
		packID,
		strconv.FormatUint(uint64(lanes), 10),
		strconv.FormatUint(uint64(blocks), 10),
		strconv.FormatUint(uint64(keep), 10),
		strconv.FormatUint(uint64(peel), 10),
		mix,
		ck,
	)
	out, err := cmd.Output()
	if err != nil {
		return "", err
	}
	if len(out) > 0 && out[len(out)-1] == '\n' {
		out = out[:len(out)-1]
	}
	return string(out), nil
}
