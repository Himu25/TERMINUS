package driver

import (
	"encoding/json"
	"os"
	"path/filepath"

	"lab.local/corpus_boundary_guard/internal/config"
	"lab.local/corpus_boundary_guard/internal/engine"
)

type Report struct {
	SchemaVersion string `json:"schema_version"`
	PackID        string `json:"pack_id"`
	LanesScanned  uint32 `json:"lanes_scanned"`
	BlocksApplied uint32 `json:"blocks_applied"`
	KeepIntact    uint32 `json:"keep_intact"`
	PeelRepairs   uint32 `json:"peel_repairs"`
	LocaleMix     string `json:"locale_mix"`
	BundleClean   bool   `json:"bundle_clean"`
	DigestHex     string `json:"digest_hex"`
}

func RunActive(root string) (Report, error) {
	pack, chunks, err := config.LoadActive(root)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(pack, chunks)
	digest, err := engine.DigestFor(
		pack.PackID,
		out.LanesScanned,
		out.BlocksApplied,
		out.KeepIntact,
		out.PeelRepairs,
		out.LocaleMix,
		out.BundleClean,
	)
	if err != nil {
		return Report{}, err
	}
	return Report{
		SchemaVersion: "1",
		PackID:        pack.PackID,
		LanesScanned:  out.LanesScanned,
		BlocksApplied: out.BlocksApplied,
		KeepIntact:    out.KeepIntact,
		PeelRepairs:   out.PeelRepairs,
		LocaleMix:     out.LocaleMix,
		BundleClean:   out.BundleClean,
		DigestHex:     digest,
	}, nil
}

func EmitReport(path string, rep Report) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}
