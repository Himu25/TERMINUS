package config

import (
	"bufio"
	"encoding/json"
	"os"
	"path/filepath"
)

type Pack struct {
	PackID         string   `json:"pack_id"`
	GateNeed       int      `json:"gate_need"`
	SigTable       []string `json:"sig_table"`
	KeepMarkers    []string `json:"keep_markers"`
	TemplatePrefix string   `json:"template_prefix"`
	LocaleMono     string   `json:"locale_mono"`
	Chunks         []string `json:"chunks"`
}

type Chunk struct {
	ChunkID string            `json:"chunk_id"`
	Body    string            `json:"body"`
	Aux     map[string]string `json:"aux"`
	Locale  string            `json:"locale"`
	Layers  int               `json:"layers"`
}

func LoadActive(root string) (Pack, []Chunk, error) {
	raw, err := os.ReadFile(filepath.Join(root, "data", "active", "corpus_pack.json"))
	if err != nil {
		return Pack{}, nil, err
	}
	var pack Pack
	if err := json.Unmarshal(raw, &pack); err != nil {
		return Pack{}, nil, err
	}
	var chunks []Chunk
	for _, rel := range pack.Chunks {
		path := filepath.Join(root, "data", "active", rel)
		file, err := os.Open(path)
		if err != nil {
			return Pack{}, nil, err
		}
		sc := bufio.NewScanner(file)
		for sc.Scan() {
			line := sc.Text()
			if line == "" {
				continue
			}
			var c Chunk
			if err := json.Unmarshal([]byte(line), &c); err != nil {
				file.Close()
				return Pack{}, nil, err
			}
			chunks = append(chunks, c)
		}
		file.Close()
		if err := sc.Err(); err != nil {
			return Pack{}, nil, err
		}
	}
	return pack, chunks, nil
}
