package chunk

import (
	"lab.local/corpus_boundary_guard/internal/config"
	"lab.local/corpus_boundary_guard/internal/scan"
	"lab.local/corpus_boundary_guard/pkg/signalcount"
)

type gateOutcome struct {
	threat bool
	block  bool
	keep   bool
	ok     bool
}

func gateStage(folded string, pack config.Pack) gateOutcome {
	score := scan.OpS(folded, pack.SigTable)
	if score <= 0 {
		return gateOutcome{ok: true}
	}
	if !signalcount.OpQ(score, pack.GateNeed) {
		return gateOutcome{threat: true, ok: false}
	}
	if keeperStage(folded, pack) {
		return gateOutcome{threat: true, keep: true, ok: true}
	}
	return gateOutcome{threat: true, block: true, ok: true}
}
