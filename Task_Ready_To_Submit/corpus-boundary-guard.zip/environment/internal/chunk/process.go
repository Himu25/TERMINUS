package chunk

import (
	"lab.local/corpus_boundary_guard/internal/config"
	"lab.local/corpus_boundary_guard/internal/scan"
)

type Result struct {
	Blocks     uint32
	Keep       uint32
	Peel       uint32
	ThreatSeen bool
	Handled    bool
}

func Process(c config.Chunk, pack config.Pack) Result {
	surfaces := scan.OpH(c)
	var blocks, keep, peelTotal uint32
	threatSeen := false
	handled := true

	for _, surf := range surfaces {
		folded, repairs := OpP(surf, c.Layers)
		peelTotal += repairs
		out := gateStage(folded, pack)
		if out.threat && !out.ok {
			handled = false
		}
		if out.threat {
			threatSeen = true
		}
		if out.keep {
			keep++
		}
		if out.block {
			blocks++
		}
	}

	return Result{
		Blocks:     blocks,
		Keep:       keep,
		Peel:       peelTotal,
		ThreatSeen: threatSeen,
		Handled:    handled,
	}
}
