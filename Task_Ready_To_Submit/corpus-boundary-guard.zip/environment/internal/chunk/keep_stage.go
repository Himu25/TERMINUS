package chunk

import (
	"lab.local/corpus_boundary_guard/internal/config"
	"lab.local/corpus_boundary_guard/pkg/allowfold"
)

func keeperStage(folded string, pack config.Pack) bool {
	return allowfold.OpW(folded, pack.KeepMarkers, pack.TemplatePrefix)
}
