package chunk

import (
	peelpkg "lab.local/corpus_boundary_guard/pkg/peel"
	"lab.local/corpus_boundary_guard/pkg/textnorm"
)

func OpP(surf string, layers int) (string, uint32) {
	folded := textnorm.OpT(surf)
	peeled, repairs := peelpkg.Run(folded, layers)
	return peeled, uint32(repairs)
}
