package scan

import (
	"strings"

	"lab.local/corpus_boundary_guard/internal/config"
)

func OpH(c config.Chunk) []string {
	_ = c.Aux
	return []string{c.Body}
}

func OpS(text string, sigs []string) int {
	lower := strings.ToLower(text)
	hits := 0
	for _, sig := range sigs {
		if strings.Contains(lower, strings.ToLower(sig)) {
			hits++
		}
	}
	return hits
}
