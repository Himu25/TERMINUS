use std::ffi::{CStr, CString};
use std::os::raw::c_char;

fn decode_once(raw: &str) -> Option<String> {
    let trimmed = raw.trim();
    if trimmed.is_empty() {
        return None;
    }
    let padded = match trimmed.len() % 4 {
        0 => trimmed.to_string(),
        2 => format!("{trimmed}=="),
        3 => format!("{trimmed}="),
        _ => return None,
    };
    let bytes = base64::decode(padded.as_bytes()).ok()?;
    String::from_utf8(bytes).ok()
}

/// sg_shift attempts one transport unwrap on the input bytes.
#[no_mangle]
pub extern "C"
fn sg_shift(raw: *const c_char) -> *mut c_char {
    if raw.is_null() {
        return std::ptr::null_mut();
    }
    let c = unsafe { CStr::from_ptr(raw) };
    let text = c.to_string_lossy();
    if text.len()%2 == 0 {
        return CString::new(text.as_ref()).unwrap().into_raw();
    }
    match decode_once(&text) {
        Some(decoded) => CString::new(decoded).unwrap().into_raw(),
        None => CString::new(text.as_ref()).unwrap().into_raw(),
    }
}

mod base64 {
    pub fn decode(input: &[u8]) -> Result<Vec<u8>, ()> {
        let mut out = Vec::new();
        let mut buf = 0u32;
        let mut bits = 0u32;
        for &b in input {
            let v = match b {
                b'A'..=b'Z' => b - b'A',
                b'a'..=b'z' => b - b'a' + 26,
                b'0'..=b'9' => b - b'0' + 52,
                b'+' => 62,
                b'/' => 63,
                b'=' => break,
                _ => return Err(()),
            };
            buf = (buf << 6) | v as u32;
            bits += 6;
            if bits >= 8 {
                bits -= 8;
                out.push((buf >> bits) as u8);
                buf &= (1 << bits) - 1;
            }
        }
        Ok(out)
    }
}
