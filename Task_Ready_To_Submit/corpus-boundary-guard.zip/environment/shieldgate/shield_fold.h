#ifndef SHIELD_FOLD_H
#define SHIELD_FOLD_H

char *sg_shift(const char *raw);

#endif
