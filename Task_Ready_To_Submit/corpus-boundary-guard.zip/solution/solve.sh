#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/internal/scan/op_h.go <<'EOF'
package scan

import (
	"strings"

	"lab.local/corpus_boundary_guard/internal/config"
)

func OpH(c config.Chunk) []string {
	out := []string{c.Body}
	for _, v := range c.Aux {
	 out = append(out, v)
	}
	return out
}

func OpS(text string, sigs []string) int {
	lower := strings.ToLower(text)
	hits := 0
	for _, sig := range sigs {
		if strings.Contains(lower, strings.ToLower(sig)) {
			hits++
		}
	}
	return hits
}
EOF

cat > /app/pkg/allowfold/op_w.go <<'EOF'
package allowfold

import "strings"

func OpW(text string, markers []string, prefix string) bool {
	low := strings.ToLower(text)
	hasMarker := false
	for _, m := range markers {
		if strings.Contains(low, strings.ToLower(m)) {
			hasMarker = true
			break
		}
	}
	if !hasMarker {
		return false
	}
	return strings.Contains(low, strings.ToLower(prefix))
}
EOF

cat > /app/internal/chunk/op_p.go <<'EOF'
package chunk

import (
	peelpkg "lab.local/corpus_boundary_guard/pkg/peel"
	"lab.local/corpus_boundary_guard/pkg/textnorm"
)

func OpP(surf string, layers int) (string, uint32) {
	peeled, repairs := peelpkg.Run(surf, layers)
	return textnorm.OpT(peeled), uint32(repairs)
}
EOF

cat > /app/pkg/signalcount/op_q.go <<'EOF'
package signalcount

func OpQ(score int, need int) bool {
	if need < 0 {
		return false
	}
	return score >= need
}
EOF

python3 <<'PY'
import shutil
from pathlib import Path


def patch(path: str, old: str, new: str) -> None:
    target = Path(path)
    work = Path("/tmp") / f"{target.name}.work"
    shutil.copy2(target, work)
    copied = work.read_text()
    if old not in copied:
        raise SystemExit(f"missing patch anchor in {path}")
    work.write_text(copied.replace(old, new, 1))
    target.write_text(work.read_text())


patch(
    "/app/pkg/textnorm/op_t.go",
    "return strings.ToLower(s)",
    "return strings.ToLower(foldRunes(s))",
)
patch(
    "/app/pkg/textnorm/op_t.go",
    "'\\u0456': 'i',\n}",
    "'\\u0456': 'i',\n\t'\\uff49': 'i',\n}",
)
patch(
    "/app/shieldgate/src/lib.rs",
    "    if text.len()%2 == 0 {\n"
    "        return CString::new(text.as_ref()).unwrap().into_raw();\n"
    "    }\n",
    "",
)
PY

bash /app/scripts/build.sh

rm -f /app/output/boundary_report.json
mkdir -p /app/output
TB_CORPUS_FIXTURE=1 /app/bin/corpus_scan
test -s /app/output/boundary_report.json

GOFLAGS=-mod=mod go test ./...
