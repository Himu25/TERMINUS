"""Verifier for corpus boundary guard report."""

import json
import os
import shutil
import subprocess

import pytest
from pathlib import Path

APP = Path("/app")
ACTIVE = APP / "data" / "active"
SCENARIOS = APP / "data" / "scenarios"
OUT = APP / "output" / "boundary_report.json"
GO_BIN = "go"
VERIFY_BIN = str(APP / "bin" / "corpus_scan_verify")

HOMO = str.maketrans(
    {
        "\u0430": "a",
        "\u0435": "e",
        "\u043e": "o",
        "\u0440": "p",
        "\u0441": "c",
        "\u0443": "y",
        "\u0445": "x",
        "\u0456": "i",
        "\uff49": "i",
    }
)


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)
    subprocess.run(["cp", "/app/bin/corpus_scan", VERIFY_BIN], check=True)


def _digest_hex(
    pack_id: str,
    lanes: int,
    blocks: int,
    keep: int,
    peel: int,
    mix: str,
    clean: bool,
) -> str:
    ck = "true" if clean else "false"
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/gen_digest",
            pack_id,
            str(lanes),
            str(blocks),
            str(keep),
            str(peel),
            mix,
            ck,
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _fold(text: str) -> str:
    return text.translate(HOMO).lower()


def _alphabet() -> str:
    upper = "".join(chr(i) for i in range(65, 91))
    lower = "".join(chr(i) for i in range(97, 123))
    digits = "".join(chr(i) for i in range(48, 58))
    return upper + lower + digits + "+/"


def _b64decode(raw: str) -> str:
    alphabet = _alphabet()
    out = bytearray()
    buf = 0
    bits = 0
    for ch in raw.strip():
        if ch == "=":
            break
        val = alphabet.find(ch)
        if val < 0:
            continue
        buf = (buf << 6) | val
        bits += 6
        if bits >= 8:
            bits -= 8
            out.append((buf >> bits) & 0xFF)
            buf &= (1 << bits) - 1
    return out.decode("utf-8", errors="replace")


def _peel_once(text: str) -> str:
    try:
        return _b64decode(text)
    except (ValueError, UnicodeDecodeError):
        return text


def _peel_run(text: str, layers: int) -> tuple[str, int]:
    cur = text
    repairs = 0
    for _ in range(layers):
        nxt = _peel_once(cur)
        if nxt == cur:
            break
        cur = nxt
        repairs += 1
    return cur, repairs


def _collect_surfaces(chunk: dict) -> list[str]:
    out = [chunk["body"]]
    for val in chunk.get("aux", {}).values():
        out.append(val)
    return out


def _score(text: str, sigs: list[str]) -> int:
    low = text.lower()
    return sum(1 for sig in sigs if sig.lower() in low)


def _keeper(text: str, markers: list[str], prefix: str) -> bool:
    low = text.lower()
    if not any(m.lower() in low for m in markers):
        return False
    return prefix.lower() in low


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = SCENARIOS / pack_name
    pack = json.loads((pack_dir / "corpus_pack.json").read_text())
    chunks: list[dict] = []
    for rel in pack["chunks"]:
        path = pack_dir / rel
        for line in path.read_text().splitlines():
            if line.strip():
                chunks.append(json.loads(line))

    blocks = 0
    keep = 0
    peel_total = 0
    mixed = False
    all_handled = True
    threat_seen = False

    for chunk in chunks:
        if chunk.get("locale", "en") != pack["locale_mono"]:
            mixed = True
        for surf in _collect_surfaces(chunk):
            peeled, repairs = _peel_run(surf, int(chunk.get("layers", 0)))
            peel_total += repairs
            folded = _fold(peeled)
            score = _score(folded, pack["sig_table"])
            if score <= 0:
                continue
            threat_seen = True
            if score < pack["gate_need"]:
                all_handled = False
                continue
            if _keeper(folded, pack["keep_markers"], pack["template_prefix"]):
                keep += 1
                continue
            blocks += 1

    mix = "mixed" if mixed else "mono"
    clean = threat_seen and all_handled and (blocks + keep) > 0
    if not threat_seen:
        clean = True

    digest = _digest_hex(
        pack["pack_id"],
        len(chunks),
        blocks,
        keep,
        peel_total,
        mix,
        clean,
    )
    return {
        "schema_version": "1",
        "pack_id": pack["pack_id"],
        "lanes_scanned": len(chunks),
        "blocks_applied": blocks,
        "keep_intact": keep,
        "peel_repairs": peel_total,
        "locale_mix": mix,
        "bundle_clean": clean,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = SCENARIOS / pack_name
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    env = {**os.environ, "TB_CORPUS_FIXTURE": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    return json.loads(OUT.read_text())


def test_alpha_report_matches_replay() -> None:
    """Active-style pack blocks direct hostile body text."""
    _swap("pack_alpha")
    expected = _expected_from_fixture("pack_alpha")
    got = _run_tool()
    assert got == expected


def test_beta_homoglyph_and_locale_mix() -> None:
    """Script-mixed wording and non-mono locale are reflected in the report."""
    _swap("pack_beta")
    expected = _expected_from_fixture("pack_beta")
    got = _run_tool()
    assert got["locale_mix"] == "mixed"
    assert got["blocks_applied"] == expected["blocks_applied"]
    assert got["digest_hex"] == expected["digest_hex"]


def test_gamma_aux_surface_blocked() -> None:
    """Sidecar aux lane threats increment blocks_applied."""
    _swap("pack_gamma")
    expected = _expected_from_fixture("pack_gamma")
    got = _run_tool()
    assert got["blocks_applied"] == expected["blocks_applied"]
    assert got["blocks_applied"] >= 1


def test_delta_peel_repairs_on_encoded_body() -> None:
    """Layered encoding contributes peel_repairs and blocking."""
    _swap("pack_delta")
    expected = _expected_from_fixture("pack_delta")
    got = _run_tool()
    assert got["peel_repairs"] == expected["peel_repairs"]
    assert got["blocks_applied"] == expected["blocks_applied"]


def test_epsilon_keeper_preserved() -> None:
    """Policy keeper templates stay intact instead of blocking."""
    _swap("pack_epsilon")
    expected = _expected_from_fixture("pack_epsilon")
    got = _run_tool()
    assert got["keep_intact"] == expected["keep_intact"]
    assert got["keep_intact"] >= 1
    assert got["blocks_applied"] == expected["blocks_applied"]


def test_zeta_bundle_clean_on_alpha() -> None:
    """Fully handled threat surfaces mark bundle_clean true on alpha."""
    _swap("pack_alpha")
    expected = _expected_from_fixture("pack_alpha")
    got = _run_tool()
    assert got["bundle_clean"] == expected["bundle_clean"]


def test_go_subsystem_tests_pass() -> None:
    """Go unit tests under /app pass."""
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run([GO_BIN, "test", "./..."], cwd="/app", env=env, check=True)
