`/app/output/incident_attribution.json` schema:

- primary_cause — code from /app/docs/cause_taxonomy.txt
- symptom_onset_utc — RFC3339 UTC timestamp of the symptom_trigger row
- evidence_chain — ordered objects with seq, ts, service, event_id, role
- remediation_steps — ordered codes from /app/docs/remediation_catalog.txt
- ruled_out — decoy cause codes rejected after log review
- symptom_windows — latency_p95_start, latency_p95_peak, quality_drop_start, cost_spike_start (derive spike boundaries from `/app/archive/metrics/` using `/app/config/metric_thresholds.toml`)
- config_snapshot_ref — basename of the config snapshot whose reload_ts matches the in-window cfg_shard_prefix row tied to the regression
- evidence_epoch_span — seconds between earliest and latest evidence_chain timestamps after epoch normalization
- latency_overlay_total — summed latency_p95 samples between latency_p95_start and latency_p95_peak via the metric overlay path
- attribution_digest — eight lowercase hex characters

Evidence roles: config_change, symptom_trigger, propagation, amplification, cost_symptom.
When multiple in-window log rows share an event_id, evidence_chain retains the earliest timestamp; later duplicate shard copies are excluded.
Chain event ids and roles: /app/docs/chain_roles.txt.
Decoy markers: /app/docs/decoy_markers.txt.
Digest recipe: /app/docs/digest_recipe.txt.
Metric thresholds: /app/config/metric_thresholds.toml.
Incident review window: /app/config/incident_window.toml.
