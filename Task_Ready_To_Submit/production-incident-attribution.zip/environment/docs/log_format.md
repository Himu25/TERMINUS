# log format

Each JSONL row carries ts, service, event_id, trace_id, severity, msg, and fields object.
Timestamps are RFC3339 UTC with Z suffix.
