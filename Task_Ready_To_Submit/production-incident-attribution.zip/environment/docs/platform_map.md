# platform map

Services write JSONL shards under /app/archive/logs/<service>/.
Metric rollups live in /app/archive/metrics/ (latency_p95.csv, quality_score.csv, gpu_spend.csv).
Config snapshots for embedder reloads are under /app/archive/config_snapshots/.

Router handles retrieval orchestration.
Embedder owns embedding cache keys keyed by shard prefix length.
Gateway applies retry policy on upstream timeouts.
Billing records gpu tick spend.

On-call attribution output belongs at /app/output/incident_attribution.json.
Attribution export driver: /app/bin/r7d. Metric overlay helper: /app/bin/q9m.
