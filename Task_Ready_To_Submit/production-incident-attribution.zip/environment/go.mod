module prodincident

go 1.22
