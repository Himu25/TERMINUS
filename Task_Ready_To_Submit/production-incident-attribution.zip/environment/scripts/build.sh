#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

export CGO_ENABLED=1
export GOCACHE=/app/output/go-build

mkdir -p /app/output /app/bin /app/output/go-build

cd "$ROOT/q9m"
cargo build --release --locked 2>/dev/null || cargo build --release
cd "$ROOT"

go mod tidy
go build -o /app/bin/logscan ./cmd/logscan
go build -o /app/bin/q9m ./cmd/q9m
go build -o /app/bin/r7d ./cmd/r7d

chmod 0755 /app/bin/logscan /app/bin/q9m /app/bin/r7d
