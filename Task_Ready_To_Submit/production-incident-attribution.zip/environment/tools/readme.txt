Offline helpers under /app/bin/.
Metric overlay helper (q9m): q9m <csv-path> <start> <end> — sums metric samples inside the UTC span; start and end are RFC3339 UTC timestamps.
Attribution driver (r7d): emits the on-call bundle when sources are consistent.
