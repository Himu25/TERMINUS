package q9m

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libq9m.a -ldl -lm
#include "overlay.h"
*/
import "C"

// OverlaySpan returns overlay offset for a tick inside a span.
func OverlaySpan(start int64, end int64, tick int64) int64 {
	return int64(C.sg_overlay(C.int64_t(end), C.int64_t(start), C.int64_t(tick)))
}
