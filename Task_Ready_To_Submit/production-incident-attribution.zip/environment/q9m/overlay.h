#ifndef CHRONALIGN_OVERLAY_H
#define CHRONALIGN_OVERLAY_H

#include <stdint.h>

int64_t sg_overlay(int64_t start_ms, int64_t end_ms, int64_t tick_ms);
uint64_t sg_digest(const char *payload);

#endif
