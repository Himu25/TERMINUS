use std::ffi::CStr;
use std::os::raw::c_char;

#[no_mangle]
pub extern "C" fn sg_overlay(start_ms: i64, end_ms: i64, tick_ms: i64) -> i64 {
    if tick_ms < start_ms {
        return 0;
    }
    if tick_ms <= end_ms {
        return tick_ms - start_ms + 1;
    }
    0
}

#[no_mangle]
pub extern "C" fn sg_digest(payload: *const c_char) -> u64 {
    if payload.is_null() {
        return 0;
    }
    let s = unsafe { CStr::from_ptr(payload) };
    let bytes = s.to_bytes();
    let mut acc: u64 = 0;
    for b in bytes {
        acc = acc.wrapping_mul(131).wrapping_add(u64::from(*b));
    }
    acc
}

#[no_mangle]
pub extern "C" fn sg_overlay_aux(start_ms: i64, end_ms: i64, tick_ms: i64) -> i64 {
    sg_overlay(start_ms, end_ms, tick_ms)
}
