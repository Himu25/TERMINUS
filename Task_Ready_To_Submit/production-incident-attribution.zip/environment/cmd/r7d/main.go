package main

import (
	"bufio"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"

	"prodincident/q9m"
	"prodincident/pkg/clipx"
	"prodincident/pkg/index"
	"prodincident/pkg/seqy"
)

type Evidence struct {
	Seq     int    `json:"seq"`
	TS      string `json:"ts"`
	Service string `json:"service"`
	EventID string `json:"event_id"`
	Role    string `json:"role"`
}

type Report struct {
	PrimaryCause         string            `json:"primary_cause"`
	SymptomOnsetUTC      string            `json:"symptom_onset_utc"`
	EvidenceChain        []Evidence        `json:"evidence_chain"`
	RemediationSteps     []string          `json:"remediation_steps"`
	RuledOut             []string          `json:"ruled_out"`
	SymptomWindows       map[string]string `json:"symptom_windows"`
	ConfigSnapshotRef    string            `json:"config_snapshot_ref"`
	EvidenceEpochSpan    int64             `json:"evidence_epoch_span"`
	LatencyOverlayTotal  int64             `json:"latency_overlay_total"`
	AttributionDigest    string            `json:"attribution_digest"`
}

type logRow struct {
	TS      string
	Service string
	EventID string
	Fields  map[string]any
}

func main() {
	chainOrder, roleMap, err := loadChainRoles("/app/docs/chain_roles.txt")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	bounds, err := seqy.ReadBand("/app/config/incident_window.toml")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	entries, err := index.ScanDir("/app/archive/logs")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	rows := make([]seqy.Row, 0, len(entries))
	for _, e := range entries {
		if !seqy.BandOk(e.TS, bounds.Start, bounds.End) {
			continue
		}
		rows = append(rows, seqy.Row{TS: e.TS, Service: e.Service, EventID: e.EventID})
	}
	picked := seqy.OpQ(rows, chainOrder)
	for i := range picked {
		picked[i].Role = roleMap[picked[i].EventID]
		if _, err := clipx.ClipSpan(picked[i].TS); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	}
	sort.Slice(picked, func(i, j int) bool { return picked[i].TS < picked[j].TS })
	evidence := make([]Evidence, 0, len(picked))
	for i, row := range picked {
		evidence = append(evidence, Evidence{
			Seq:     i + 1,
			TS:      row.TS,
			Service: row.Service,
			EventID: row.EventID,
			Role:    row.Role,
		})
	}
	fullLogs, err := loadLogRows("/app/archive/logs", bounds)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	onset := symptomOnset(evidence)
	cause, reloadTS, err := derivePrimaryCause(fullLogs)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	snapshotRef, err := snapRef(reloadTS)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	remediation, err := loadRemediationCodes("/app/docs/remediation_catalog.txt")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	decoyCodes, err := loadDecoyCodes("/app/docs/decoy_markers.txt")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	ruled := deriveRuledOut(fullLogs, decoyCodes, onset)
	windows, err := deriveSymptomWindows()
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	epochSpan, err := chainSec(evidence)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	overlayTotal, err := bandSum(windows["latency_p95_start"], windows["latency_p95_peak"])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	digest := digestFor(cause, onset, remediation)
	report := Report{
		PrimaryCause:        cause,
		SymptomOnsetUTC:     onset,
		EvidenceChain:       evidence,
		RemediationSteps:    remediation,
		RuledOut:            ruled,
		SymptomWindows:      windows,
		ConfigSnapshotRef:   snapshotRef,
		EvidenceEpochSpan:   epochSpan,
		LatencyOverlayTotal: overlayTotal,
		AttributionDigest:   digest,
	}
	outPath := filepath.Join("/app/output", "incident_attribution.json")
	if err := os.MkdirAll(filepath.Dir(outPath), 0o777); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	f, err := os.Create(outPath)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer f.Close()
	enc := json.NewEncoder(f)
	enc.SetIndent("", "  ")
	if err := enc.Encode(report); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func loadChainRoles(path string) ([]string, map[string]string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, nil, err
	}
	order := make([]string, 0)
	roles := make(map[string]string)
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		parts := strings.Fields(line)
		if len(parts) != 2 {
			continue
		}
		order = append(order, parts[0])
		roles[parts[0]] = parts[1]
	}
	if len(order) == 0 {
		return nil, nil, fmt.Errorf("no chain roles in %s", path)
	}
	return order, roles, nil
}

func loadLogRows(root string, bounds seqy.Band) ([]logRow, error) {
	var out []logRow
	err := filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if info.IsDir() || !strings.HasSuffix(path, ".jsonl") {
			return nil
		}
		f, err := os.Open(path)
		if err != nil {
			return err
		}
		defer f.Close()
		sc := bufio.NewScanner(f)
		for sc.Scan() {
			var raw map[string]any
			if json.Unmarshal(sc.Bytes(), &raw) != nil {
				continue
			}
			ts := stringVal(raw["ts"])
			if !seqy.BandOk(ts, bounds.Start, bounds.End) {
				continue
			}
			fields, _ := raw["fields"].(map[string]any)
			out = append(out, logRow{
				TS:      ts,
				Service: stringVal(raw["service"]),
				EventID: stringVal(raw["event_id"]),
				Fields:  fields,
			})
		}
		return sc.Err()
	})
	sort.Slice(out, func(i, j int) bool { return out[i].TS < out[j].TS })
	return out, err
}

func stringVal(v any) string {
	s, _ := v.(string)
	return s
}

func symptomOnset(chain []Evidence) string {
	for _, row := range chain {
		if row.Role == "symptom_trigger" {
			return row.TS
		}
	}
	return ""
}

func derivePrimaryCause(rows []logRow) (string, string, error) {
	for _, row := range rows {
		if row.EventID != "cfg_shard_prefix" {
			continue
		}
		prior, okPrior := numField(row.Fields, "prior_shard_prefix_len")
		current, okCurrent := numField(row.Fields, "shard_prefix_len")
		if okPrior && okCurrent && current < prior {
			code, err := matchTaxonomy("/app/docs/cause_taxonomy.txt", "prefix length change")
			if err != nil {
				return "", "", err
			}
			return code, row.TS, nil
		}
	}
	return "", "", fmt.Errorf("could not derive primary cause from logs")
}

func matchTaxonomy(path, needle string) (string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		parts := strings.SplitN(line, " — ", 2)
		if len(parts) != 2 {
			continue
		}
		if strings.Contains(strings.ToLower(parts[1]), strings.ToLower(needle)) {
			return strings.TrimSpace(parts[0]), nil
		}
	}
	return "", fmt.Errorf("no taxonomy match for %q", needle)
}

func numField(fields map[string]any, key string) (float64, bool) {
	if fields == nil {
		return 0, false
	}
	v, ok := fields[key]
	if !ok {
		return 0, false
	}
	switch n := v.(type) {
	case float64:
		return n, true
	case int:
		return float64(n), true
	default:
		return 0, false
	}
}

func snapRef(reloadTS string) (string, error) {
	_ = reloadTS
	entries, err := os.ReadDir("/app/archive/config_snapshots")
	if err != nil {
		return "", err
	}
	sort.Slice(entries, func(i, j int) bool { return entries[i].Name() < entries[j].Name() })
	for _, entry := range entries {
		if entry.IsDir() || !strings.HasSuffix(entry.Name(), ".toml") {
			continue
		}
		return strings.TrimSuffix(entry.Name(), ".toml"), nil
	}
	return "", fmt.Errorf("no config snapshots found")
}

func loadRemediationCodes(path string) ([]string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	codes := make([]string, 0)
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		code := strings.TrimSpace(strings.SplitN(line, " — ", 2)[0])
		if code != "" {
			codes = append(codes, code)
		}
	}
	if len(codes) == 0 {
		return nil, fmt.Errorf("no remediation codes in %s", path)
	}
	return codes, nil
}

func loadDecoyCodes(path string) ([]string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	codes := make([]string, 0)
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		code := strings.TrimSpace(strings.SplitN(line, " — ", 2)[0])
		if code != "" {
			codes = append(codes, code)
		}
	}
	return codes, nil
}

var decoyEventMap = map[string]string{
	"model_rollout":        "MODEL_ROLLOUT",
	"autoscale_scale_out":  "AUTOSCALE_SCALE_OUT",
	"redis_flush_announce": "REDIS_FLUSH_EXEC",
}

func deriveRuledOut(rows []logRow, decoyCodes []string, onset string) []string {
	allowed := make(map[string]struct{}, len(decoyCodes))
	for _, code := range decoyCodes {
		allowed[code] = struct{}{}
	}
	seen := make(map[string]struct{})
	for _, row := range rows {
		mapped, ok := decoyEventMap[row.EventID]
		if !ok {
			continue
		}
		if _, ok := allowed[mapped]; !ok {
			continue
		}
		if mapped == "REDIS_FLUSH_EXEC" {
			if executed, ok := row.Fields["executed"].(bool); ok && executed {
				continue
			}
		}
		if mapped == "AUTOSCALE_SCALE_OUT" {
			if onset != "" && row.TS < onset {
				continue
			}
		}
		seen[mapped] = struct{}{}
	}
	out := make([]string, 0, len(seen))
	for code := range seen {
		out = append(out, code)
	}
	sort.Strings(out)
	return out
}

func loadThresholds(path string) (map[string]float64, error) {
	vals := map[string]float64{
		"latency_p95_alert": 300.0,
		"quality_floor":     0.80,
		"cost_spike_usd":    55.0,
	}
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return vals, nil
		}
		return nil, err
	}
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") || !strings.Contains(line, "=") {
			continue
		}
		key, raw, _ := strings.Cut(line, "=")
		v, err := strconv.ParseFloat(strings.TrimSpace(raw), 64)
		if err != nil {
			return nil, err
		}
		vals[strings.TrimSpace(key)] = v
	}
	return vals, nil
}

func readMetricSeries(path string) ([][2]string, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	r := csv.NewReader(f)
	records, err := r.ReadAll()
	if err != nil {
		return nil, err
	}
	out := make([][2]string, 0, len(records)-1)
	for _, row := range records[1:] {
		if len(row) < 2 {
			continue
		}
		out = append(out, [2]string{row[0], row[1]})
	}
	return out, nil
}

func deriveSymptomWindows() (map[string]string, error) {
	thresholds, err := loadThresholds("/app/config/metric_thresholds.toml")
	if err != nil {
		return nil, err
	}
	lat, err := readMetricSeries("/app/archive/metrics/latency_p95.csv")
	if err != nil {
		return nil, err
	}
	qual, err := readMetricSeries("/app/archive/metrics/quality_score.csv")
	if err != nil {
		return nil, err
	}
	cost, err := readMetricSeries("/app/archive/metrics/gpu_spend.csv")
	if err != nil {
		return nil, err
	}
	latStart, err := firstAtOrAbove(lat, thresholds["latency_p95_alert"])
	if err != nil {
		return nil, err
	}
	latPeak, err := peakTimestamp(lat)
	if err != nil {
		return nil, err
	}
	qualStart, err := firstAtOrBelow(qual, thresholds["quality_floor"])
	if err != nil {
		return nil, err
	}
	costStart, err := firstAtOrAbove(cost, thresholds["cost_spike_usd"])
	if err != nil {
		return nil, err
	}
	return map[string]string{
		"latency_p95_start":  latStart,
		"latency_p95_peak":   latPeak,
		"quality_drop_start": qualStart,
		"cost_spike_start":   costStart,
	}, nil
}

func firstAtOrAbove(series [][2]string, threshold float64) (string, error) {
	for _, row := range series {
		val, err := strconv.ParseFloat(row[1], 64)
		if err != nil {
			return "", err
		}
		if val >= threshold {
			return row[0], nil
		}
	}
	return "", fmt.Errorf("no series point at or above %v", threshold)
}

func firstAtOrBelow(series [][2]string, threshold float64) (string, error) {
	for _, row := range series {
		val, err := strconv.ParseFloat(row[1], 64)
		if err != nil {
			return "", err
		}
		if val <= threshold {
			return row[0], nil
		}
	}
	return "", fmt.Errorf("no series point at or below %v", threshold)
}

func peakTimestamp(series [][2]string) (string, error) {
	if len(series) == 0 {
		return "", fmt.Errorf("empty metric series")
	}
	bestTS := series[0][0]
	bestVal := -1.0
	for _, row := range series {
		val, err := strconv.ParseFloat(row[1], 64)
		if err != nil {
			return "", err
		}
		if val > bestVal {
			bestVal = val
			bestTS = row[0]
		}
	}
	return bestTS, nil
}

func chainSec(chain []Evidence) (int64, error) {
	if len(chain) == 0 {
		return 0, fmt.Errorf("empty evidence chain")
	}
	minSec, err := clipx.ClipSpan(chain[0].TS)
	if err != nil {
		return 0, err
	}
	maxSec := minSec
	for _, row := range chain[1:] {
		sec, err := clipx.ClipSpan(row.TS)
		if err != nil {
			return 0, err
		}
		if sec < minSec {
			minSec = sec
		}
		if sec > maxSec {
			maxSec = sec
		}
	}
	return maxSec - minSec, nil
}

func parseClockTS(ts string) int64 {
	ts = strings.TrimSuffix(ts, "Z")
	parts := strings.Split(ts, "T")
	if len(parts) != 2 {
		return 0
	}
	seg := strings.Split(parts[1], ":")
	if len(seg) != 3 {
		return 0
	}
	m, _ := strconv.Atoi(seg[1])
	s, _ := strconv.Atoi(seg[2])
	return int64(m*60 + s)
}

func bandSum(startTS, endTS string) (int64, error) {
	start := parseClockTS(startTS)
	end := parseClockTS(endTS)
	data, err := os.ReadFile("/app/archive/metrics/latency_p95.csv")
	if err != nil {
		return 0, err
	}
	total := int64(0)
	for _, line := range strings.Split(string(data), "\n")[1:] {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		parts := strings.Split(line, ",")
		if len(parts) < 2 {
			continue
		}
		tick := parseClockTS(parts[0])
		val, _ := strconv.ParseFloat(parts[1], 64)
		offset := q9m.OverlaySpan(start, end, tick)
		if offset > 0 {
			total += int64(val)
		}
	}
	return total, nil
}

func digestFor(cause, onset string, steps []string) string {
	parts := append([]string{cause, onset}, steps...)
	payload := strings.Join(parts, "|")
	sum := sha256.Sum256([]byte(payload))
	return hex.EncodeToString(sum[:])[:8]
}
