package main

import (
	"fmt"
	"os"
	"strconv"
	"strings"

	"prodincident/q9m"
)

func main() {
	if len(os.Args) < 4 {
		fmt.Fprintln(os.Stderr, "usage: q9m <csv-path> <start> <end>")
		os.Exit(2)
	}
	data, err := os.ReadFile(os.Args[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	start := parseTs(os.Args[2])
	end := parseTs(os.Args[3])
	lines := strings.Split(string(data), "\n")
	total := int64(0)
	for _, line := range lines[1:] {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		parts := strings.Split(line, ",")
		if len(parts) < 2 {
			continue
		}
		ts := parseTs(parts[0])
		val, _ := strconv.ParseFloat(parts[1], 64)
		offset := q9m.OverlaySpan(start, end, ts)
		if offset > 0 {
			total += int64(val)
		}
	}
	fmt.Println(total)
}

func parseTs(ts string) int64 {
	ts = strings.TrimSuffix(ts, "Z")
	parts := strings.Split(ts, "T")
	if len(parts) != 2 {
		return 0
	}
	clock := parts[1]
	seg := strings.Split(clock, ":")
	if len(seg) != 3 {
		return 0
	}
	m, _ := strconv.Atoi(seg[1])
	s, _ := strconv.Atoi(seg[2])
	return int64(m*60 + s)
}
