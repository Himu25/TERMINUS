package main

import (
	"encoding/json"
	"fmt"
	"os"

	"prodincident/pkg/index"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Fprintln(os.Stderr, "usage: logscan <log-root>")
		os.Exit(2)
	}
	rows, err := index.ScanDir(os.Args[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	enc := json.NewEncoder(os.Stdout)
	for _, row := range rows {
		_ = enc.Encode(row)
	}
}
