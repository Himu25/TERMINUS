package index

import (
	"bufio"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
)

type Entry struct {
	TS      string `json:"ts"`
	Service string `json:"service"`
	EventID string `json:"event_id"`
	Role    string `json:"-"`
}

func ScanDir(root string) ([]Entry, error) {
	var out []Entry
	err := filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if info.IsDir() || !strings.HasSuffix(path, ".jsonl") {
			return nil
		}
		f, err := os.Open(path)
		if err != nil {
			return err
		}
		defer f.Close()
		sc := bufio.NewScanner(f)
		for sc.Scan() {
			var row map[string]any
			if json.Unmarshal(sc.Bytes(), &row) != nil {
				continue
			}
			e := Entry{
				TS:      stringVal(row["ts"]),
				Service: stringVal(row["service"]),
				EventID: stringVal(row["event_id"]),
			}
			out = append(out, e)
		}
		return sc.Err()
	})
	return out, err
}

func stringVal(v any) string {
	s, _ := v.(string)
	return s
}
