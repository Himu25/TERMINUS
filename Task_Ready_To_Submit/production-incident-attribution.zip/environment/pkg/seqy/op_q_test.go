package seqy

import "testing"

func TestOpQFilters(t *testing.T) {
	rows := []Row{
		{TS: "2026-05-28T14:18:04Z", EventID: "cfg_shard_prefix"},
		{TS: "2026-05-28T14:22:11Z", EventID: "miss_ratio_breach"},
	}
	got := OpQ(rows, []string{"cfg_shard_prefix", "miss_ratio_breach"})
	if len(got) == 0 {
		t.Fatal("expected matches")
	}
}
