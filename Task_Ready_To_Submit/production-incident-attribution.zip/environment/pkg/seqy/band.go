package seqy

import (
	"os"
	"strings"
	"time"
)

type Band struct {
	Start string
	End   string
}

func ReadBand(path string) (Band, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return Band{}, err
	}
	out := Band{}
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "[") {
			continue
		}
		if !strings.Contains(line, "=") {
			continue
		}
		key, raw, _ := strings.Cut(line, "=")
		val := strings.Trim(strings.TrimSpace(raw), `"`)
		switch strings.TrimSpace(key) {
		case "window_start":
			out.Start = val
		case "window_end":
			out.End = val
		}
	}
	return out, nil
}

func BandOk(ts, start, end string) bool {
	t, err := time.Parse(time.RFC3339, ts)
	if err != nil {
		return false
	}
	s, err := time.Parse(time.RFC3339, start)
	if err != nil {
		return false
	}
	e, err := time.Parse(time.RFC3339, end)
	if err != nil {
		return false
	}
	return t.After(s) && !t.After(e)
}
