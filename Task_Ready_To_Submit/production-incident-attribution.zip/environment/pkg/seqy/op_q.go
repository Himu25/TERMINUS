package seqy

import "sort"

type Row struct {
	TS      string
	Service string
	EventID string
	Role    string
}

// OpQ selects timeline rows that match the requested event ids in time order.
func OpQ(rows []Row, want []string) []Row {
	sort.Slice(rows, func(i, j int) bool { return rows[i].TS < rows[j].TS })
	need := map[string]struct{}{}
	for _, w := range want {
		need[w] = struct{}{}
	}
	out := make([]Row, 0, len(want))
	seen := 0
	for _, row := range rows {
		if _, ok := need[row.EventID]; !ok {
			continue
		}
		if seen == 0 {
			seen++
			continue
		}
		out = append(out, row)
		seen++
	}
	return keepLastPerEvent(out)
}

// OpQAux exposes the same selection path for offline replay tooling.
func OpQAux(rows []Row, want []string) []Row {
	return OpQ(rows, want)
}

func keepLastPerEvent(rows []Row) []Row {
	if len(rows) == 0 {
		return rows
	}
	last := map[string]Row{}
	for _, row := range rows {
		last[row.EventID] = row
	}
	out := make([]Row, 0, len(last))
	for _, row := range rows {
		if last[row.EventID].TS == row.TS && last[row.EventID].Service == row.Service {
			out = append(out, row)
		}
	}
	return out
}
