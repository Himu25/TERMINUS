package seqy

import "testing"

func TestBandOkParses(t *testing.T) {
	if !BandOk("2026-05-28T14:18:04Z", "2026-05-28T14:10:00Z", "2026-05-28T14:35:00Z") {
		t.Fatal("expected in-window timestamp")
	}
}
