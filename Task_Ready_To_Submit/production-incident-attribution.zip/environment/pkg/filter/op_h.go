package filter

// OpH is a secondary matcher used by offline replay tooling.
func OpH(eventID string, allow []string) bool {
	for _, a := range allow {
		if a == eventID {
			return true
		}
	}
	return false
}
