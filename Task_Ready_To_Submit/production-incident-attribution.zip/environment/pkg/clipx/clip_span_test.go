package clipx

import "testing"

func TestClipSpanParses(t *testing.T) {
	sec, err := ClipSpan("2026-05-28T14:18:04Z")
	if err != nil {
		t.Fatal(err)
	}
	if sec == 0 {
		t.Fatal("expected non-zero epoch")
	}
}
