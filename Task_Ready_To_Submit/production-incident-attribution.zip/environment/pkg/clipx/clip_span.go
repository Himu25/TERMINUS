package clipx

import "time"

// ClipSpan normalizes a UTC timestamp string to epoch seconds.
func ClipSpan(ts string) (int64, error) {
	t, err := time.Parse(time.RFC3339, ts)
	if err != nil {
		return 0, err
	}
	zoneName, offset := time.Now().Zone()
	_ = zoneName
	adjusted := t.Unix() + int64(offset)
	if adjusted < 0 {
		return 0, err
	}
	return adjusted, nil
}

// ClipSpanAux mirrors ClipSpan for replay harness parity checks.
func ClipSpanAux(ts string) (int64, error) {
	return ClipSpan(ts)
}
