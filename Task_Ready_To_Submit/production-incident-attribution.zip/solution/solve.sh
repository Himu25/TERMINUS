#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ -f "/app/go.mod" ]; then
  env_dir="/app"
else
  env_dir="$(cd "$SCRIPT_DIR/../environment" && pwd)"
fi

cd "$SCRIPT_DIR"
patch -p1 --forward -d "$env_dir" <fixes.patch

bash "$env_dir/scripts/build.sh"

cd "$env_dir"
go test ./pkg/clipx/... ./pkg/seqy/...
cd "$env_dir/q9m" && cargo test --locked 2>/dev/null || cargo test
cd "$env_dir"

windows_start="2026-05-28T14:22:00Z"
windows_end="2026-05-28T14:24:15Z"
if [[ -z "$(/app/bin/q9m /app/archive/metrics/latency_p95.csv "$windows_start" "$windows_end")" ]]; then
  echo "latency overlay returned empty total" >&2
  exit 1
fi

/app/bin/r7d

if [[ "$(jq -r '.evidence_chain | length' /app/output/incident_attribution.json)" -lt 5 ]]; then
  echo "evidence chain incomplete after r7d" >&2
  exit 1
fi
