"""Verify production incident attribution report against archived evidence."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

APP = Path("/app")
OUT = APP / "output" / "incident_attribution.json"
LOG_ROOT = APP / "archive" / "logs"
CHAIN_ROLES = APP / "docs" / "chain_roles.txt"
WINDOW_CFG = APP / "config" / "incident_window.toml"
SNAP_DIR = APP / "archive" / "config_snapshots"
METRICS = {
    "latency": APP / "archive" / "metrics" / "latency_p95.csv",
    "quality": APP / "archive" / "metrics" / "quality_score.csv",
    "gpu_spend": APP / "archive" / "metrics" / "gpu_spend.csv",
}
THRESHOLDS = APP / "config" / "metric_thresholds.toml"
ROLE_SET = {
    "config_change",
    "symptom_trigger",
    "propagation",
    "amplification",
    "cost_symptom",
}


def _load_window() -> tuple[str, str]:
    start = end = ""
    for line in WINDOW_CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line.startswith("window_start"):
            start = line.split("=", 1)[1].strip().strip('"')
        elif line.startswith("window_end"):
            end = line.split("=", 1)[1].strip().strip('"')
    assert start and end, "incident window bounds missing"
    return start, end


def _in_window(ts: str, start: str, end: str) -> bool:
    fmt = "%Y-%m-%dT%H:%M:%SZ"
    t = datetime.strptime(ts, fmt).replace(tzinfo=timezone.utc)
    s = datetime.strptime(start, fmt).replace(tzinfo=timezone.utc)
    e = datetime.strptime(end, fmt).replace(tzinfo=timezone.utc)
    return s <= t <= e


def _load_chain_roles() -> tuple[list[str], dict[str, str]]:
    order: list[str] = []
    roles: dict[str, str] = {}
    for line in CHAIN_ROLES.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        event_id, role = line.split()
        order.append(event_id)
        roles[event_id] = role
    return order, roles


def _iter_log_rows() -> list[dict]:
    rows: list[dict] = []
    for path in sorted(LOG_ROOT.rglob("*.jsonl")):
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    rows.sort(key=lambda r: r["ts"])
    return rows


def _expected_chain() -> list[dict]:
    start, end = _load_window()
    order, roles = _load_chain_roles()
    by_id: dict[str, dict] = {}
    for row in _iter_log_rows():
        event_id = row.get("event_id")
        if event_id not in order:
            continue
        if not _in_window(row["ts"], start, end):
            continue
        if event_id not in by_id:
            by_id[event_id] = row
    chain = []
    for seq, event_id in enumerate(order, start=1):
        row = by_id[event_id]
        chain.append(
            {
                "seq": seq,
                "ts": row["ts"],
                "service": row["service"],
                "event_id": event_id,
                "role": roles[event_id],
            }
        )
    return chain


def _expected_primary_cause() -> str:
    start, end = _load_window()
    for row in _iter_log_rows():
        if row.get("event_id") != "cfg_shard_prefix":
            continue
        if not _in_window(row["ts"], start, end):
            continue
        fields = row.get("fields") or {}
        prior = fields.get("prior_shard_prefix_len")
        current = fields.get("shard_prefix_len")
        if prior is not None and current is not None and current < prior:
            return "CACHE_KEY_TRUNCATION"
    raise AssertionError("could not derive primary cause from logs")


def _expected_ruled_out() -> list[str]:
    start, end = _load_window()
    codes = ["MODEL_ROLLOUT", "AUTOSCALE_SCALE_OUT", "REDIS_FLUSH_EXEC"]
    onset = _symptom_onset_from_chain(_expected_chain())
    present: list[str] = []
    for row in _iter_log_rows():
        if not _in_window(row["ts"], start, end):
            continue
        event_id = row.get("event_id", "")
        mapped = {
            "model_rollout": "MODEL_ROLLOUT",
            "autoscale_scale_out": "AUTOSCALE_SCALE_OUT",
            "redis_flush_announce": "REDIS_FLUSH_EXEC",
        }.get(event_id)
        if not mapped or mapped not in codes:
            continue
        if mapped == "REDIS_FLUSH_EXEC":
            fields = row.get("fields") or {}
            if fields.get("executed") is True:
                continue
        if mapped == "AUTOSCALE_SCALE_OUT" and row["ts"] < onset:
            continue
        present.append(mapped)
    return sorted(set(present))


def _symptom_onset_from_chain(chain: list[dict]) -> str:
    for row in chain:
        if row["role"] == "symptom_trigger":
            return row["ts"]
    raise AssertionError("missing symptom trigger")


def _expected_remediation() -> list[str]:
    return [
        "RESTORE_SHARD_PREFIX",
        "PURGE_EMBED_CACHE",
        "ENABLE_RETRY_CAP",
    ]


def _load_thresholds() -> dict[str, float]:
    vals: dict[str, float] = {
        "latency_p95_alert": 300.0,
        "quality_floor": 0.80,
        "cost_spike_usd": 55.0,
    }
    if not THRESHOLDS.is_file():
        return vals
    for line in THRESHOLDS.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, raw = line.split("=", 1)
        vals[key.strip()] = float(raw.strip())
    return vals


def _metric_windows() -> dict[str, str]:
    thresholds = _load_thresholds()
    latency_rows = METRICS["latency"].read_text(encoding="utf-8").splitlines()[1:]
    quality_rows = METRICS["quality"].read_text(encoding="utf-8").splitlines()[1:]
    cost_rows = METRICS["gpu_spend"].read_text(encoding="utf-8").splitlines()[1:]

    def parse(rows: list[str]) -> list[tuple[str, float]]:
        out = []
        for row in rows:
            ts, val = row.split(",")
            out.append((ts, float(val)))
        return out

    lat = parse(latency_rows)
    qual = parse(quality_rows)
    cost = parse(cost_rows)

    lat_start = next(ts for ts, val in lat if val >= thresholds["latency_p95_alert"])
    lat_peak = max(lat, key=lambda item: item[1])[0]
    qual_start = next(ts for ts, val in qual if val <= thresholds["quality_floor"])
    cost_start = next(ts for ts, val in cost if val >= thresholds["cost_spike_usd"])

    return {
        "latency_p95_start": lat_start,
        "latency_p95_peak": lat_peak,
        "quality_drop_start": qual_start,
        "cost_spike_start": cost_start,
    }


def _clip_span(ts: str) -> int:
    dt = datetime.strptime(ts, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    return int(dt.timestamp())


def _expected_epoch_span(chain: list[dict]) -> int:
    epochs = [_clip_span(row["ts"]) for row in chain]
    return max(epochs) - min(epochs)


def _parse_clock(ts: str) -> int:
    clock = ts.split("T", 1)[1].rstrip("Z")
    minute, second = clock.split(":")[1:3]
    return int(minute) * 60 + int(second)


def _overlay_span(start_ms: int, end_ms: int, tick_ms: int) -> int:
    if tick_ms < start_ms:
        return 0
    if tick_ms < end_ms:
        return tick_ms - start_ms + 1
    if tick_ms == end_ms:
        return tick_ms - start_ms + 1
    return 0


def _expected_overlay_total(windows: dict[str, str]) -> int:
    start = _parse_clock(windows["latency_p95_start"])
    end = _parse_clock(windows["latency_p95_peak"])
    total = 0
    for row in METRICS["latency"].read_text(encoding="utf-8").splitlines()[1:]:
        ts, val = row.split(",")
        if _overlay_span(start, end, _parse_clock(ts)) > 0:
            total += int(float(val))
    return total


def _expected_snapshot_ref(chain: list[dict]) -> str:
    reload_ts = next(row["ts"] for row in chain if row["event_id"] == "cfg_shard_prefix")
    for path in sorted(SNAP_DIR.glob("*.toml")):
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line.startswith("reload_ts"):
                continue
            val = line.split("=", 1)[1].strip().strip('"')
            if val == reload_ts:
                return path.stem
    raise AssertionError("no config snapshot matched reload_ts")


def _digest(cause: str, onset: str, steps: list[str]) -> str:
    payload = "|".join([cause, onset, *steps])
    proc = subprocess.run(
        ["sha256sum"],
        input=payload.encode(),
        capture_output=True,
        check=True,
        text=False,
    )
    return proc.stdout.decode().split()[0][:8]


def _reference_report() -> dict:
    chain = _expected_chain()
    cause = _expected_primary_cause()
    onset = _symptom_onset_from_chain(chain)
    remediation = _expected_remediation()
    windows = _metric_windows()
    return {
        "primary_cause": cause,
        "symptom_onset_utc": onset,
        "evidence_chain": chain,
        "remediation_steps": remediation,
        "ruled_out": _expected_ruled_out(),
        "symptom_windows": windows,
        "config_snapshot_ref": _expected_snapshot_ref(chain),
        "evidence_epoch_span": _expected_epoch_span(chain),
        "latency_overlay_total": _expected_overlay_total(windows),
        "attribution_digest": _digest(cause, onset, remediation),
    }


def _load_report() -> dict:
    assert OUT.is_file(), "incident_attribution.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


def test_report_schema_complete() -> None:
    """Report exposes every contract field with structured evidence rows."""
    report = _load_report()
    for key in _reference_report():
        assert key in report, f"missing {key}"
    row = report["evidence_chain"][0]
    for field in ("seq", "ts", "service", "event_id", "role"):
        assert field in row, f"evidence row missing {field}"


def test_primary_cause_code() -> None:
    """Dominant cause matches log-derived taxonomy selection."""
    report = _load_report()
    assert report["primary_cause"] == _reference_report()["primary_cause"]


def test_symptom_onset_utc() -> None:
    """Onset aligns with the symptom_trigger row in the chain."""
    report = _load_report()
    assert report["symptom_onset_utc"] == _reference_report()["symptom_onset_utc"]


def test_evidence_chain_order_and_ids() -> None:
    """Evidence chain lists causal events in chronological order."""
    report = _load_report()
    want = _reference_report()["evidence_chain"]
    assert len(report["evidence_chain"]) == len(want)
    for got, ref in zip(report["evidence_chain"], want, strict=True):
        assert got["seq"] == ref["seq"]
        assert got["ts"] == ref["ts"]
        assert got["service"] == ref["service"]
        assert got["event_id"] == ref["event_id"]


def test_evidence_roles_valid() -> None:
    """Each evidence row carries a documented causal role token."""
    report = _load_report()
    for got, ref in zip(
        report["evidence_chain"], _reference_report()["evidence_chain"], strict=True
    ):
        assert got["role"] == ref["role"]
        assert got["role"] in ROLE_SET


def test_remediation_steps_order() -> None:
    """Remediation catalog codes appear in the required execution order."""
    report = _load_report()
    assert report["remediation_steps"] == _reference_report()["remediation_steps"]


def test_ruled_out_decoys() -> None:
    """Decoy causes are explicitly rejected."""
    report = _load_report()
    assert sorted(report["ruled_out"]) == sorted(_reference_report()["ruled_out"])


def test_symptom_windows_present() -> None:
    """Symptom windows anchor latency, quality, and cost spikes."""
    report = _load_report()
    assert report["symptom_windows"] == _reference_report()["symptom_windows"]


def test_config_snapshot_ref() -> None:
    """Config snapshot basename matches the in-window reload timestamp."""
    report = _load_report()
    assert report["config_snapshot_ref"] == _reference_report()["config_snapshot_ref"]


def test_evidence_epoch_span() -> None:
    """Epoch span covers the full evidence chain duration."""
    report = _load_report()
    assert report["evidence_epoch_span"] == _reference_report()["evidence_epoch_span"]


def test_latency_overlay_total() -> None:
    """Latency overlay total matches the metric overlay span over the symptom band."""
    report = _load_report()
    assert report["latency_overlay_total"] == _reference_report()["latency_overlay_total"]


def test_attribution_digest_contract() -> None:
    """Digest is eight lowercase hex chars tied to cause, onset, and remediation."""
    report = _load_report()
    digest = report["attribution_digest"]
    assert re.fullmatch(r"[0-9a-f]{8}", digest)
    ref = _reference_report()
    assert digest == _digest(
        ref["primary_cause"], ref["symptom_onset_utc"], ref["remediation_steps"]
    )


def test_evidence_timestamps_monotonic() -> None:
    """Evidence timestamps never move backward."""
    report = _load_report()
    stamps = [row["ts"] for row in report["evidence_chain"]]
    assert stamps == sorted(stamps)


def test_config_change_precedes_symptom() -> None:
    """Config change event must precede the symptom trigger in the chain."""
    report = _load_report()
    roles = [row["role"] for row in report["evidence_chain"]]
    assert roles.index("config_change") < roles.index("symptom_trigger")


def test_latency_band_sum() -> None:
    """Metric overlay helper sums latency samples inside the documented review span."""
    windows = _reference_report()["symptom_windows"]
    proc = subprocess.run(
        [
            "/app/bin/q9m",
            str(METRICS["latency"]),
            windows["latency_p95_start"],
            windows["latency_p95_peak"],
        ],
        capture_output=True,
        text=True,
        check=True,
    )
    assert int(proc.stdout.strip()) == _reference_report()["latency_overlay_total"]


def test_r7d_replay_matches_report() -> None:
    """Running the attribution driver reproduces the submitted report."""
    ref = _load_report()
    backup = OUT.with_suffix(".json.bak")
    shutil.copy2(OUT, backup)
    try:
        OUT.unlink()
        subprocess.run(["/app/bin/r7d"], check=True)
        replay = json.loads(OUT.read_text(encoding="utf-8"))
        assert replay == ref
    finally:
        if backup.is_file():
            shutil.move(str(backup), str(OUT))


def test_truncated_report_rejected() -> None:
    """Submitted evidence chain must cover every role in chain_roles.txt."""
    report = _load_report()
    event_order, role_by_event = _load_chain_roles()
    required_roles = set(role_by_event.values())
    got_roles = {row["role"] for row in report["evidence_chain"]}
    assert required_roles <= got_roles, (
        f"missing causal roles: {sorted(required_roles - got_roles)}"
    )
    required_events = set(event_order)
    got_events = {row["event_id"] for row in report["evidence_chain"]}
    assert required_events <= got_events, (
        f"missing chain event_ids: {sorted(required_events - got_events)}"
    )
