#!/usr/bin/env bash
set -euo pipefail

cd /app

python3 - <<'PY'
from pathlib import Path

bolt = Path("/app/svc/internal/store/bolt.go")
text = bolt.read_text()
text = text.replace('Requires   []string          `json:"require"`', 'Requires   []string          `json:"requires"`')
text = text.replace('PickupRoom string `json:"pickup"`', 'PickupRoom string `json:"pickup_room"`')
old = """\t\tif out.MaxTurns > 0 {
\t\t\tout.MaxTurns--
\t\t}
\t\treturn nil"""
new = "\t\treturn nil"
if old not in text:
    raise SystemExit("MaxTurns decrement block not found")
bolt.write_text(text.replace(old, new, 1))
PY

python3 - <<'PY'
from pathlib import Path

seed = Path("/app/svc/cmd/seed/main.go")
text = seed.read_text()
text = text.replace('Requires: []string{"key"}', 'Requires: []string{"key_inv"}', 1)
seed.write_text(text)
PY

sed -i 's|api_prefix = "/api/v1"|api_prefix = "/v1"|' /app/config/rules_client.toml

cat > /app/ref/lib/format/detect.rb <<'EOF'
# frozen_string_literal: true

module Format
  module Detect
    module_function

    EXTENSION_FORMAT = {
      '.jsonl' => 'jsonl',
      '.tsv' => 'tsv',
      '.compact' => 'compact'
    }.freeze

    def from_path(path)
      ext = File.extname(path)
      EXTENSION_FORMAT.fetch(ext) { raise "unknown replay format for #{path}" }
    end
  end
end
EOF

cat > /app/ref/lib/parser/jsonl.rb <<'EOF'
# frozen_string_literal: true

require 'json'

module Parser
  module Jsonl
    module_function

    def parse(path)
      File.readlines(path, chomp: true).filter_map do |line|
        next if line.strip.empty?

        row = JSON.parse(line)
        kind = row['kind']
        turn = row['turn'].to_i
        target = row['to'] || row['item'] || row['target']
        { turn: turn, kind: normalize_kind(kind), target: target }
      end
    end

    def normalize_kind(raw)
      case raw
      when 'move', 'M' then 'move'
      when 'use', 'U' then 'use'
      else raw
      end
    end
  end
end
EOF

cat > /app/ref/lib/parser/tsv.rb <<'EOF'
# frozen_string_literal: true

module Parser
  module Tsv
    module_function

    def parse(path)
      lines = File.readlines(path, chomp: true)
      data = lines.drop(1)
      data.filter_map do |line|
        turn_s, action, target = line.split("\t")
        next if [turn_s, action, target].any?(&:nil?)

        turn = turn_s.to_i
        { turn: turn, kind: normalize_kind(action), target: target }
      end
    end

    def normalize_kind(raw)
      case raw
      when 'move' then 'move'
      when 'use' then 'use'
      else raw
      end
    end
  end
end
EOF

cat > /app/ref/lib/parser/compact.rb <<'EOF'
# frozen_string_literal: true

module Parser
  module Compact
    module_function

    def parse(path)
      File.readlines(path, chomp: true).filter_map do |line|
        line = line.strip
        next if line.empty?

        if line =~ /\At(\d+):([MU])\s+(\S+)\z/
          turn = Regexp.last_match(1).to_i
          kind = Regexp.last_match(2) == 'M' ? 'move' : 'use'
          target = Regexp.last_match(3)
          { turn: turn, kind: kind, target: target }
        end
      end
    end
  end
end
EOF

python3 - <<'PY'
from pathlib import Path

move = Path("/app/ref/lib/validate/move.rb")
text = move.read_text()
old = """    def adjacent?(room, target)
      exits = room['exits'] || {}
      forward = exits.value?(target)
      reverse = reverse_lookup?(room, target)
      forward || reverse
    end

    def reverse_lookup?(room, target)
      exits = room['exits'] || {}
      exits.key?(target)
    end"""
new = """    def adjacent?(room, target)
      exits = room['exits'] || {}
      exits.value?(target)
    end"""
if old not in text:
    raise SystemExit("move adjacent block not found")
move.write_text(text.replace(old, new, 1))
PY

cat > /app/ref/lib/validate/item.rb <<'EOF'
# frozen_string_literal: true

module Validate
  module Item
    module_function

    def apply(api, state, item_id)
      meta = api.item(item_id)
      room = api.room(state[:room])
      items_here = room['items'] || []
      unless items_here.include?(item_id)
        state[:last_reason] = 'item_not_available'
        return false
      end
      pickup = meta['pickup_room']
      if pickup && pickup != state[:room]
        state[:last_reason] = 'item_not_available'
        return false
      end
      effect = meta['effect']
      state[:flags][effect] = true
      state[:inventory] << item_id unless meta['consumes']
      true
    end
  end
end
EOF

cat > /app/ref/lib/reconcile/status.rb <<'EOF'
# frozen_string_literal: true

require 'digest'

module Reconcile
  module Status
    module_function

    def archive_ok_for_turn?(archive, turn_no)
      flags = archive.fetch('turn_flags')
      flags[turn_no - 1]
    end

    def derive(state, constraints, first_illegal, archive_mismatch, _archive, _turns_played)
      return 'desynced' if archive_mismatch
      return 'forfeited' if first_illegal
      return 'forfeited' unless state[:finished]
      return 'forfeited' if state[:room] != constraints['finish_room']
      'valid'
    end

    def classify_mismatch(archive_ok, rules_ok, turn_no)
      return nil if archive_ok == rules_ok

      {
        'turn' => turn_no,
        'reason' => 'archive_rules_mismatch',
        'archive_ok' => archive_ok,
        'rules_ok' => rules_ok
      }
    end

    def illegal_from_state(state, turn_no)
      return nil if state[:last_reason].nil?

      {
        'turn' => turn_no,
        'reason' => state[:last_reason]
      }
    end
  end
end
EOF

cat > /app/ref/lib/labyrinth_referee.rb <<'EOF'
# frozen_string_literal: true

require 'json'
require 'digest'
require 'fileutils'

require_relative 'format/detect'
require_relative 'parser/jsonl'
require_relative 'parser/tsv'
require_relative 'parser/compact'
require_relative 'client/rules_api'
require_relative 'validate/move'
require_relative 'validate/item'
require_relative 'reconcile/report'
require_relative 'reconcile/status'

module LabyrinthReferee
  SCHEMA_VERSION = 'labyrinth-ref-v1'

  module_function

  def run(batch_path)
    batch = JSON.parse(File.read(batch_path))
    api = Client::RulesAPI.new
    rows = batch.fetch('matches').map do |entry|
      reconcile_one(api, entry)
    end
    report = Reconcile::Report.build(batch['batch_id'], rows)
    FileUtils.mkdir_p('/app/output')
    File.write('/app/output/referee_report.json', JSON.pretty_generate(report))
  end

  def reconcile_one(api, entry)
    match_id = entry['match_id']
    replay_path = entry['replay_path']
    format = Format::Detect.from_path(replay_path)
    turns = parse_replay(replay_path, format)
    archive = load_archive(match_id)
    constraints = api.constraints(match_id)
    state = initial_state
    first_illegal = nil
    archive_mismatch = nil
    played = 0

    turns.each do |turn|
      played += 1
      if turn[:turn] > constraints['max_turns']
        state[:last_reason] = 'turn_cap_exceeded'
        first_illegal ||= { 'turn' => turn[:turn], 'reason' => 'turn_cap_exceeded' }
        break
      end
      rules_ok = apply_turn(api, state, turn)
      archive_ok = Reconcile::Status.archive_ok_for_turn?(archive, turn[:turn])
      if !rules_ok && first_illegal.nil?
        first_illegal = Reconcile::Status.illegal_from_state(state, turn[:turn])
        mismatch = Reconcile::Status.classify_mismatch(archive_ok, rules_ok, turn[:turn])
        archive_mismatch ||= mismatch
        break
      end
      mismatch = Reconcile::Status.classify_mismatch(archive_ok, rules_ok, turn[:turn])
      archive_mismatch ||= mismatch
    end

    status = Reconcile::Status.derive(state, constraints, first_illegal, archive_mismatch, archive, played)
    fi = archive_mismatch || first_illegal
    {
      'match_id' => match_id,
      'format' => format,
      'status' => status,
      'turns_played' => played,
      'first_illegal' => fi
    }
  end

  def parse_replay(path, format)
    case format
    when 'jsonl' then Parser::Jsonl.parse(path)
    when 'tsv' then Parser::Tsv.parse(path)
    when 'compact' then Parser::Compact.parse(path)
    end
  end

  def load_archive(match_id)
    path = "/app/archive/#{match_id}.archive.json"
    JSON.parse(File.read(path))
  end

  def initial_state
    {
      room: 'r_start',
      flags: {},
      inventory: [],
      last_reason: nil,
      finished: false
    }
  end

  def apply_turn(api, state, turn)
    case turn[:kind]
    when 'move'
      Validate::Move.apply(api, state, turn[:target])
    when 'use'
      Validate::Item.apply(api, state, turn[:target])
    else
      state[:last_reason] = 'unknown_kind'
      false
    end
  end
end
EOF

bash /app/scripts/build.sh
bash /app/scripts/start_api.sh

rm -f /app/output/referee_report.json
mkdir -p /app/output
TB_LABYRINTH_FIXTURE=1 /app/bin/referee_run
test -s /app/output/referee_report.json

curl -sf "http://127.0.0.1:8741/v1/rooms/r_gallery" | python3 -c "import json,sys; g=json.load(sys.stdin); assert 'lit' in g.get('requires', [])"
curl -sf "http://127.0.0.1:8741/v1/items/key" | python3 -c "import json,sys; k=json.load(sys.stdin); assert k.get('pickup_room')=='r_gallery'"
