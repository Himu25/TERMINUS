"""Verifier for Ruby referee reconciled against Gin bbolt rules API."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "referee_report.json"
SCHEMA = APP / "schemas" / "referee_report.schema.json"
CONFIG = APP / "config" / "referee.toml"
VERIFY_BIN = Path("/tmp/referee_run_verify_bin")

ACTIVE_BATCH = APP / "data" / "active" / "matches.json"
REPLAY_INDEX = APP / "docs" / "replay_index.txt"

MATCH_ALPHA = "match_alpha"
MATCH_BETA = "match_beta"
MATCH_GAMMA = "match_gamma"
MATCH_DELTA = "match_delta"
MATCH_EPSILON = "match_epsilon"
MATCH_ZETA = "match_zeta"


def _config_tokens() -> dict[str, str]:
    tokens: dict[str, str] = {}
    for line in CONFIG.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("["):
            continue
        if "=" in line:
            key, value = line.split("=", 1)
            tokens[key.strip()] = value.strip().strip('"')
    return tokens


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {**os.environ, "GOCACHE": "/tmp/go-build"}
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)
    subprocess.run(["cp", "/app/bin/referee_run", str(VERIFY_BIN)], check=True)
    subprocess.run(["bash", "/app/scripts/start_api.sh"], check=True)


def _digest_hex(rows: list[dict]) -> str:
    payload = "\n".join(
        f"{row['match_id']}:{row['status']}:{row['turns_played']}"
        for row in sorted(rows, key=lambda r: r["match_id"])
    )
    proc = subprocess.run(
        ["ruby", "-e", "require 'digest'; puts Digest::SHA256.hexdigest(STDIN.read)"],
        input=payload,
        capture_output=True,
        text=True,
        check=True,
    )
    return proc.stdout.strip()


def _api_get(path: str) -> dict:
    proc = subprocess.run(
        ["curl", "-sf", f"http://127.0.0.1:8741/v1{path}"],
        capture_output=True,
        text=True,
        check=True,
    )
    return json.loads(proc.stdout)


def _run_batch(batch_path: Path) -> dict:
    subprocess.run([str(VERIFY_BIN), str(batch_path)], cwd="/app", check=True)
    return json.loads(OUT.read_text())


def _run_fixture_env() -> dict:
    env = {**os.environ, "TB_LABYRINTH_FIXTURE": "1"}
    subprocess.run([str(VERIFY_BIN)], cwd="/app", env=env, check=True)
    return json.loads(OUT.read_text())


def _by_id(report: dict) -> dict[str, dict]:
    return {row["match_id"]: row for row in report["matches"]}


def _schema_required_keys() -> set[str]:
    schema = json.loads(SCHEMA.read_text())
    top = set(schema["required"])
    row = set(schema["properties"]["matches"]["items"]["required"])
    return top | row


def test_active_report_schema() -> None:
    """Active batch report exposes every schema-required field."""
    report = _run_batch(ACTIVE_BATCH)
    required = _schema_required_keys()
    assert required.issubset(set(report) | {k for row in report["matches"] for k in row})


def test_active_report_shape() -> None:
    """Active batch exposes documented top-level counters."""
    tokens = _config_tokens()
    batch = json.loads(ACTIVE_BATCH.read_text())
    report = _run_batch(ACTIVE_BATCH)
    for key in (
        "schema_version",
        "batch_id",
        "matches_total",
        "valid_count",
        "forfeited_count",
        "desynced_count",
        "digest_hex",
        "matches",
    ):
        assert key in report
    assert report["batch_id"] == batch["batch_id"]
    assert report["schema_version"] == tokens["schema_version"]


def test_active_status_totals() -> None:
    """Status counters sum to the batch size with mixed outcomes."""
    report = _run_batch(ACTIVE_BATCH)
    assert report["matches_total"] == len(report["matches"])
    total = (
        report["valid_count"] + report["forfeited_count"] + report["desynced_count"]
    )
    assert total == report["matches_total"]
    statuses = {row["status"] for row in report["matches"]}
    assert len(statuses) >= 2


def test_active_digest_hex() -> None:
    """Report digest matches the documented row fold."""
    report = _run_batch(ACTIVE_BATCH)
    expected = _digest_hex(report["matches"])
    assert report["digest_hex"] == expected


def test_match_alpha_valid_jsonl() -> None:
    """Alpha jsonl replay completes without an illegal turn."""
    tokens = _config_tokens()
    report = _run_batch(ACTIVE_BATCH)
    row = _by_id(report)[MATCH_ALPHA]
    assert row["format"] == tokens["jsonl"]
    assert row["status"] == "valid"
    assert row["first_illegal"] is None


def test_match_beta_valid_tsv() -> None:
    """Beta tsv replay finishes cleanly after the armory detour."""
    tokens = _config_tokens()
    report = _run_batch(ACTIVE_BATCH)
    row = _by_id(report)[MATCH_BETA]
    assert row["format"] == tokens["tsv"]
    assert row["status"] == "valid"
    assert row["first_illegal"] is None


def test_match_gamma_valid_compact() -> None:
    """Gamma compact replay follows the short gallery route."""
    tokens = _config_tokens()
    report = _run_batch(ACTIVE_BATCH)
    row = _by_id(report)[MATCH_GAMMA]
    assert row["format"] == tokens["compact"]
    assert row["status"] == "valid"
    assert row["first_illegal"] is None


def test_match_delta_forfeited() -> None:
    """Delta replay forfeits on a non-adjacent finish jump."""
    tokens = _config_tokens()
    report = _run_batch(ACTIVE_BATCH)
    row = _by_id(report)[MATCH_DELTA]
    assert row["status"] == "forfeited"
    fi = row["first_illegal"]
    assert fi is not None
    assert fi["reason"] == tokens["forfeit"]


def test_match_epsilon_desynced() -> None:
    """Epsilon archive disagrees with rules on vault entry without key."""
    tokens = _config_tokens()
    report = _run_batch(ACTIVE_BATCH)
    row = _by_id(report)[MATCH_EPSILON]
    assert row["status"] == "desynced"
    fi = row["first_illegal"]
    assert fi is not None
    assert fi["reason"] == tokens["desync"]
    assert fi["archive_ok"] is True
    assert fi["rules_ok"] is False


def test_match_zeta_valid_long_route() -> None:
    """Zeta compact replay clears the longer armory gallery chain within cap."""
    report = _run_batch(ACTIVE_BATCH)
    row = _by_id(report)[MATCH_ZETA]
    assert row["status"] == "valid"
    cons = _api_get(f"/matches/{MATCH_ZETA}/constraints")
    assert row["turns_played"] <= cons["max_turns"]


def test_replay_index_lists_active_batch() -> None:
    """Indexed batch path replays the same tallies as the active fixture."""
    paths = [Path(line.strip()) for line in REPLAY_INDEX.read_text().splitlines() if line.strip()]
    assert paths == [ACTIVE_BATCH]
    indexed = _run_batch(paths[0])
    active = _run_batch(ACTIVE_BATCH)
    assert indexed["valid_count"] == active["valid_count"]
    assert indexed["forfeited_count"] == active["forfeited_count"]
    assert indexed["desynced_count"] == active["desynced_count"]


def test_fixture_env_replays_active_batch() -> None:
    """TB_LABYRINTH_FIXTURE=1 drives the active batch manifest."""
    fixture = _run_fixture_env()
    active = _run_batch(ACTIVE_BATCH)
    assert fixture["batch_id"] == active["batch_id"]
    assert fixture["valid_count"] == active["valid_count"]
    assert fixture["forfeited_count"] == active["forfeited_count"]
    assert fixture["desynced_count"] == active["desynced_count"]


def test_rules_api_room_topology() -> None:
    """Rules service exposes the gallery vault one-way edge."""
    gallery = _api_get("/rooms/r_gallery")
    vault = _api_get("/rooms/r_vault")
    assert gallery["exits"]["E"] == "r_vault"
    assert vault["exits"]["W"] == "r_gallery"
    assert "E" not in vault["exits"]


def test_rules_api_gallery_entry_requires_lit() -> None:
    """Gallery entry requires the lit flag from torch use in the hall."""
    gallery = _api_get("/rooms/r_gallery")
    assert "lit" in gallery["requires"]


def test_rules_api_vault_requires_key_effect() -> None:
    """Vault entry binds to the key item inventory effect."""
    tokens = _config_tokens()
    vault = _api_get("/rooms/r_vault")
    assert tokens["vault_require_effect"] in vault["requires"]


def test_rules_api_key_pickup_room() -> None:
    """Consumable key pickup is scoped to the gallery room."""
    tokens = _config_tokens()
    key = _api_get("/items/key")
    assert key["pickup_room"] == tokens["key_pickup_room"]
    assert key["effect"] == tokens["vault_require_effect"]


def test_item_torch_sets_lit_requirement() -> None:
    """Torch use in the hall sets the lit requirement flag."""
    torch = _api_get("/items/torch")
    assert torch["effect"] == "lit"
    assert torch["pickup_room"] == "r_hall"


def test_zeta_constraints_turn_cap() -> None:
    """Long compact route match exposes the extended turn cap."""
    tokens = _config_tokens()
    cons = _api_get(f"/matches/{MATCH_ZETA}/constraints")
    assert cons["max_turns"] == int(tokens["extended_max_turns"])
    assert cons["finish_room"] == tokens["finish_room"]
