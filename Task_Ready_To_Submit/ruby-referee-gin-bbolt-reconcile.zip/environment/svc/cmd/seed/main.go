package main

import (
	"log"
	"os"

	"github.com/labyrinth-league/rulesd/internal/store"
)

func main() {
	path := "/app/store/rules.bolt"
	if len(os.Args) > 1 {
		path = os.Args[1]
	}
	rooms := []store.Room{
		{ID: "r_start", Exits: map[string]string{"E": "r_hall"}, Items: []string{}},
		{ID: "r_hall", Exits: map[string]string{"W": "r_start", "N": "r_armory", "E": "r_gallery"}, Items: []string{"torch"}},
		{ID: "r_armory", Exits: map[string]string{"S": "r_hall"}, Items: []string{"rope"}},
		{ID: "r_gallery", Exits: map[string]string{"W": "r_hall", "E": "r_vault"}, Items: []string{"key"}, Requires: []string{"lit"}},
		{ID: "r_vault", Exits: map[string]string{"W": "r_gallery", "N": "r_finish"}, Requires: []string{"key"}},
		{ID: "r_finish", Exits: map[string]string{}, FinishRoom: true},
	}
	items := []store.Item{
		{ID: "torch", Effect: "lit", PickupRoom: "r_hall", Consumes: false},
		{ID: "rope", Effect: "bridge", PickupRoom: "r_armory", Consumes: false},
		{ID: "key", Effect: "key_inv", PickupRoom: "r_gallery", Consumes: true},
	}
	matchIDs := []string{
		"match_alpha", "match_beta", "match_gamma",
		"match_delta", "match_epsilon", "match_zeta",
	}
	var constraints []store.Constraints
	for _, id := range matchIDs {
		max := 12
		if id == "match_zeta" {
			max = 14
		}
		constraints = append(constraints, store.Constraints{
			MatchID: id, MaxTurns: max, FinishRoom: "r_finish",
		})
	}
	if err := store.Seed(path, rooms, items, constraints); err != nil {
		log.Fatal(err)
	}
}
