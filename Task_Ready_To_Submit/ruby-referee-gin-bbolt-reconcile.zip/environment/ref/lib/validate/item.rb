# frozen_string_literal: true

module Validate
  module Item
    module_function

    def apply(api, state, item_id)
      meta = api.item(item_id)
      room = api.room(state[:room])
      items_here = room['items'] || []
      pickup_room = meta['pickup_room']
      unless items_here.include?(item_id)
        state[:last_reason] = 'item_not_available'
        return false
      end
      effect = meta['effect']
      state[:flags][effect] = true
      state[:inventory] << item_id
      true
    end

    def phantom_room?(state, item_id)
      state[:inventory].include?(item_id)
    end
  end
end
