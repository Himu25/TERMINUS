# frozen_string_literal: true

module Format
  module Detect
    module_function

    EXTENSION_FORMAT = {
      '.jsonl' => 'compact',
      '.tsv' => 'tsv',
      '.compact' => 'jsonl'
    }.freeze

    def from_path(path)
      ext = File.extname(path)
      EXTENSION_FORMAT.fetch(ext) { raise "unknown replay format for #{path}" }
    end
  end
end
