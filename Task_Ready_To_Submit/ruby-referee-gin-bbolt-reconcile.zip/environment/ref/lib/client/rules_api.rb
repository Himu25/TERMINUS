# frozen_string_literal: true

require 'net/http'
require 'json'
require 'uri'

module Client
  class RulesAPI
    def initialize(config_path = '/app/config/rules_client.toml')
      @base = load_base(config_path)
    end

    def room(id)
      get("/rooms/#{id}")
    end

    def item(id)
      get("/items/#{id}")
    end

    def constraints(match_id)
      get("/matches/#{match_id}/constraints")
    end

    private

    def load_base(path)
      host = '127.0.0.1'
      port = 8741
      prefix = '/v1'
      File.readlines(path, chomp: true).each do |line|
        line = line.strip
        next if line.empty? || line.start_with?('#')

        key, value = line.split('=', 2).map(&:strip)
        value = value.delete('"')
        case key
        when 'api_host' then host = value
        when 'api_port' then port = value.to_i
        when 'api_prefix' then prefix = value
        end
      end
      "http://#{host}:#{port}#{prefix}"
    end

    def get(path)
      uri = URI("#{@base}#{path}")
      res = Net::HTTP.get_response(uri)
      raise "rules api error #{res.code} for #{path}" unless res.is_a?(Net::HTTPSuccess)

      JSON.parse(res.body)
    end
  end
end
