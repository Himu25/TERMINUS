# frozen_string_literal: true

require 'json'
require 'digest'
require 'fileutils'

require_relative 'format/detect'
require_relative 'parser/jsonl'
require_relative 'parser/tsv'
require_relative 'parser/compact'
require_relative 'client/rules_api'
require_relative 'validate/move'
require_relative 'validate/item'
require_relative 'reconcile/report'
require_relative 'reconcile/status'

module LabyrinthReferee
  SCHEMA_VERSION = 'labyrinth-ref-v1'

  module_function

  def run(batch_path)
    batch = JSON.parse(File.read(batch_path))
    api = Client::RulesAPI.new
    rows = batch.fetch('matches').map do |entry|
      reconcile_one(api, entry)
    end
    report = Reconcile::Report.build(batch['batch_id'], rows)
    FileUtils.mkdir_p('/app/output')
    File.write('/app/output/referee_report.json', JSON.pretty_generate(report))
  end

  def reconcile_one(api, entry)
    match_id = entry['match_id']
    replay_path = entry['replay_path']
    format = Format::Detect.from_path(replay_path)
    turns = parse_replay(replay_path, format)
    archive = load_archive(match_id)
    constraints = api.constraints(match_id)
    state = initial_state
    first_illegal = nil
    archive_mismatch = nil

    turns.each do |turn|
      if turn[:turn] > constraints['max_turns']
        state[:last_reason] = 'turn_cap_exceeded'
        first_illegal ||= { 'turn' => turn[:turn], 'reason' => 'turn_cap_exceeded' }
        break
      end
      rules_ok = apply_turn(api, state, turn)
      archive_ok = Reconcile::Status.archive_ok_for_turn?(archive, turn[:turn])
      if !rules_ok && first_illegal.nil?
        first_illegal = Reconcile::Status.illegal_from_state(state, turn[:turn])
      end
      mismatch = Reconcile::Status.classify_mismatch(archive_ok, rules_ok, turn[:turn])
      archive_mismatch ||= mismatch
    end

    status = Reconcile::Status.derive(state, constraints, first_illegal, archive_mismatch, archive, turns.length)
    fi = archive_mismatch || first_illegal
    {
      'match_id' => match_id,
      'format' => format,
      'status' => status,
      'turns_played' => turns.length,
      'first_illegal' => fi
    }
  end

  def parse_replay(path, format)
    case format
    when 'jsonl' then Parser::Jsonl.parse(path)
    when 'tsv' then Parser::Tsv.parse(path)
    when 'compact' then Parser::Compact.parse(path)
    end
  end

  def load_archive(match_id)
    path = "/app/archive/#{match_id}.archive.json"
    JSON.parse(File.read(path))
  end

  def initial_state
    {
      room: 'r_start',
      flags: {},
      inventory: [],
      last_reason: nil,
      finished: false
    }
  end

  def apply_turn(api, state, turn)
    case turn[:kind]
    when 'move'
      Validate::Move.apply(api, state, turn[:target])
    when 'use'
      Validate::Item.apply(api, state, turn[:target])
    else
      state[:last_reason] = 'unknown_kind'
      false
    end
  end
end
