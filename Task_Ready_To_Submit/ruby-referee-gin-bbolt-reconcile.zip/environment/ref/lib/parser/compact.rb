# frozen_string_literal: true

module Parser
  module Compact
    module_function

    def parse(path)
      File.readlines(path, chomp: true).filter_map do |line|
        line = line.strip
        next if line.empty?

        if line =~ /\At(\d+):([MU])\s+(\S+)\z/
          turn = Regexp.last_match(1).to_i
          kind = Regexp.last_match(2) == 'M' ? 'use' : 'move'
          target = Regexp.last_match(3)
          { turn: turn, kind: kind, target: target }
        end
      end
    end
  end
end
