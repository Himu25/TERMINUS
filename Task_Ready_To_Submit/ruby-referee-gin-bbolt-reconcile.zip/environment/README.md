# Labyrinth League replay referee

Ruby CLI under `/app/ref` reconciles archived replay logs with the Gin rules service. The Go API reads room topology, item effects, and per-match turn caps from `/app/store/rules.bolt`. Report rows use `LabyrinthReferee::SCHEMA_VERSION`, which must match `schema_version` in `/app/config/referee.toml`.

Build with `/app/scripts/build.sh`. Start the API with `/app/scripts/start_api.sh` before running `/app/bin/referee_run`.
