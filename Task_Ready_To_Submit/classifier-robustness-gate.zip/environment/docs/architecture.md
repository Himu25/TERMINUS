# Triage service layout

The `/app` crate scores folded utterances with a bag-of-token weight table under `registry/model_weights.json`. `argmax_bundle` coordinates glyph folding, utterance screening, lane scoring, tail reweighting, and label selection. The `suite_harness` binary loads suite paths from a bench profile JSON and writes `/app/output/robustness_report.json`.
