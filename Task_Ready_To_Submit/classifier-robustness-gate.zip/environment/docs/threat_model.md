# Threat model notes

Adversarial suites cover homoglyph spam, instruction override strings, shifted promotional phrasing, and combined multi-vector rows in `combined_suite.tsv`. Stress ordering lives in `stress_profiles.json`. Production traffic still uses `clean_eval.tsv` for regression.
