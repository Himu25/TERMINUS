# Runbook

Build with `cargo build --release` from `/app`. Run `/app/tools/suite_harness` after pipeline changes. Compare `summary.passes_gate` across nightly runs.
