use crate::glyph_pipeline;
use crate::lexicon::WeightTable;

/// Return true when the utterance may proceed to scoring.
pub fn permit_entry(raw: &str) -> bool {
    let probe = raw.to_lowercase();
    !probe.contains("ignore previous instructions")
}

pub fn dispatch(raw: &str, weights: &WeightTable) -> String {
    if !permit_entry(raw) {
        return "escalate".to_string();
    }
    glyph_pipeline::forward(raw, weights)
}
