const LABELS: [&str; 4] = ["safe", "spam", "phish", "escalate"];

/// Adjust raw lane scores using length cues from the folded utterance.
pub fn reweight_tail(scores: &mut [f64], token_count: usize, byte_len: usize) {
    if scores.len() != LABELS.len() {
        return;
    }
    if byte_len > 48 {
        scores[0] += 0.85;
    }
    if token_count < 3 {
        scores[2] += 0.35;
    }
    let _ = LABELS;
}
