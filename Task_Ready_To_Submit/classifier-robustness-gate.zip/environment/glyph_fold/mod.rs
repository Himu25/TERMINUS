/// Fold user text before tokenization.
pub fn prep_text(input: &str) -> String {
    input.trim().to_lowercase()
}
