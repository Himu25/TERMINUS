use crate::tail_adjust::reweight_tail;
use crate::lexicon::WeightTable;

const LANES: [&str; 4] = ["safe", "spam", "phish", "escalate"];

pub fn pick_lane(folded: &str, weights: &WeightTable) -> String {
    let tokens: Vec<String> = folded
        .split_whitespace()
        .filter(|t| !t.is_empty())
        .map(|t| t.to_string())
        .collect();
    let mut scores = vec![0.0; LANES.len()];
    for (idx, lane) in LANES.iter().enumerate() {
        scores[idx] = weights.score_lane(lane, &tokens);
    }
    reweight_tail(&mut scores, tokens.len(), folded.len());
    let mut best_idx = 0usize;
    for (idx, val) in scores.iter().enumerate().skip(1) {
        if *val > scores[best_idx] {
            best_idx = idx;
        }
    }
    LANES[best_idx].to_string()
}
