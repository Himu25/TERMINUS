/// Split on whitespace for offline metrics tooling.
pub fn split_ws(body: &str) -> Vec<String> {
    body.split_whitespace().map(|t| t.to_string()).collect()
}
