use serde::Deserialize;
use std::fs;
use std::path::Path;

#[derive(Debug, Clone, Deserialize)]
pub struct SuiteRef {
    pub name: String,
    pub path: String,
}

#[derive(Debug, Clone, Deserialize)]
pub struct BenchProfile {
    pub suites: Vec<SuiteRef>,
}

impl BenchProfile {
    pub fn load(path: &Path) -> Result<Self, String> {
        let body = fs::read_to_string(path).map_err(|e| e.to_string())?;
        serde_json::from_str(&body).map_err(|e| e.to_string())
    }
}

pub fn read_suite(path: &Path) -> Result<Vec<(String, String)>, String> {
    let body = fs::read_to_string(path).map_err(|e| e.to_string())?;
    let mut rows = Vec::new();
    for line in body.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.splitn(2, '\t').collect();
        if parts.len() != 2 {
            return Err(format!("bad row: {line}"));
        }
        rows.push((parts[0].to_string(), parts[1].to_string()));
    }
    Ok(rows)
}
