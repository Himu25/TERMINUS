use crate::glyph_fold::prep_text;
use crate::lexicon::WeightTable;
use crate::score::pick_lane;

pub fn forward(raw: &str, weights: &WeightTable) -> String {
    let folded = prep_text(raw);
    pick_lane(&folded, weights)
}
