use std::fs;
use std::path::PathBuf;

use triage_svc::dispatch;
use triage_svc::manifest::{read_suite, BenchProfile};
use triage_svc::WeightTable;

#[derive(serde::Serialize)]
struct SuiteStat {
    name: String,
    total: u32,
    correct: u32,
    accuracy: f64,
}

#[derive(serde::Serialize)]
struct Summary {
    clean_accuracy: f64,
    robustness_score: f64,
    passes_gate: bool,
}

#[derive(serde::Serialize)]
struct Report {
    suites: Vec<SuiteStat>,
    summary: Summary,
}

struct GateFloors {
    clean_floor: f64,
    unicode_floor: f64,
    injection_floor: f64,
    shift_floor: f64,
    combined_floor: f64,
    composite_floor: f64,
}

impl GateFloors {
    fn load() -> Result<Self, String> {
        let body =
            fs::read_to_string("/app/config/thresholds.toml").map_err(|e| e.to_string())?;
        let mut floors = GateFloors {
            clean_floor: 0.0,
            unicode_floor: 0.0,
            injection_floor: 0.0,
            shift_floor: 0.0,
            combined_floor: 0.0,
            composite_floor: 0.0,
        };
        for line in body.lines() {
            let line = line.split('#').next().unwrap_or("").trim();
            if line.is_empty() {
                continue;
            }
            let Some((key, raw)) = line.split_once('=') else {
                continue;
            };
            let value: f64 = raw
                .trim()
                .parse::<f64>()
                .map_err(|e: std::num::ParseFloatError| e.to_string())?;
            match key.trim() {
                "clean_floor" => floors.clean_floor = value,
                "unicode_floor" => floors.unicode_floor = value,
                "injection_floor" => floors.injection_floor = value,
                "shift_floor" => floors.shift_floor = value,
                "combined_floor" => floors.combined_floor = value,
                "composite_floor" => floors.composite_floor = value,
                _ => {}
            }
        }
        Ok(floors)
    }

    fn suite_floor(&self, name: &str) -> Option<f64> {
        match name {
            "clean" => Some(self.clean_floor),
            "unicode_suite" => Some(self.unicode_floor),
            "injection_suite" => Some(self.injection_floor),
            "shift_suite" => Some(self.shift_floor),
            "combined_suite" => Some(self.combined_floor),
            _ => None,
        }
    }
}

fn round4(v: f64) -> f64 {
    (v * 10000.0).round() / 10000.0
}

fn eval_suite(
    name: &str,
    path: &PathBuf,
    weights: &WeightTable,
) -> Result<SuiteStat, String> {
    let rows = read_suite(path)?;
    let mut correct = 0u32;
    for (text, want) in &rows {
        let got = dispatch(text, weights);
        if got == *want {
            correct += 1;
        }
    }
    let total = rows.len() as u32;
    let accuracy = if total == 0 {
        0.0
    } else {
        round4(correct as f64 / total as f64)
    };
    Ok(SuiteStat {
        name: name.to_string(),
        total,
        correct,
        accuracy,
    })
}

fn write_report(profile_path: &PathBuf, weights: &WeightTable) -> Result<(), String> {
    let floors = GateFloors::load()?;
    let profile = BenchProfile::load(profile_path)?;
    let mut suites = Vec::new();
    for suite in &profile.suites {
        suites.push(eval_suite(&suite.name, &PathBuf::from(&suite.path), weights)?);
    }
    let clean_acc = suites
        .iter()
        .find(|s| s.name == "clean")
        .map(|s| s.accuracy)
        .unwrap_or(0.0);
    let adv: Vec<f64> = suites
        .iter()
        .filter(|s| s.name != "clean")
        .map(|s| s.accuracy)
        .collect();
    let robustness_score = if adv.is_empty() {
        0.0
    } else {
        round4(adv.iter().sum::<f64>() / adv.len() as f64)
    };
    let passes_gate = suites.iter().all(|suite| {
        floors
            .suite_floor(&suite.name)
            .is_some_and(|floor| suite.accuracy >= floor)
    }) && robustness_score >= floors.composite_floor;
    let report = Report {
        suites,
        summary: Summary {
            clean_accuracy: clean_acc,
            robustness_score,
            passes_gate,
        },
    };
    fs::create_dir_all("/app/output").map_err(|e| e.to_string())?;
    let body = serde_json::to_string_pretty(&report).map_err(|e| e.to_string())?;
    fs::write("/app/output/robustness_report.json", format!("{body}\n")).map_err(|e| e.to_string())?;
    Ok(())
}

fn main() -> Result<(), String> {
    let weights = WeightTable::load(&PathBuf::from("/app/registry/model_weights.json"))?;
    let mut args: Vec<String> = std::env::args().skip(1).collect();
    if args.first().map(|s| s.as_str()) == Some("--probe") {
        let text = args
            .get(1)
            .ok_or_else(|| "usage: suite_harness --probe <utterance>".to_string())?;
        print!("{}", dispatch(text, &weights));
        return Ok(());
    }
    let profile_path = if args.is_empty() {
        PathBuf::from("/app/config/bench_profiles.json")
    } else {
        PathBuf::from(args.remove(0))
    };
    write_report(&profile_path, &weights)
}
