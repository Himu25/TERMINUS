use serde::Deserialize;
use std::collections::HashMap;
use std::fs;
use std::path::Path;

#[derive(Debug, Clone, Deserialize)]
pub struct LaneWeights {
    pub bias: f64,
    pub tokens: HashMap<String, f64>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct WeightTable {
    pub safe: LaneWeights,
    pub spam: LaneWeights,
    pub phish: LaneWeights,
    pub escalate: LaneWeights,
}

impl WeightTable {
    pub fn load(path: &Path) -> Result<Self, String> {
        let body = fs::read_to_string(path).map_err(|e| e.to_string())?;
        serde_json::from_str(&body).map_err(|e| e.to_string())
    }

    pub fn score_lane(&self, lane: &str, tokens: &[String]) -> f64 {
        let lane_w = match lane {
            "safe" => &self.safe,
            "spam" => &self.spam,
            "phish" => &self.phish,
            "escalate" => &self.escalate,
            _ => return f64::NEG_INFINITY,
        };
        let mut total = lane_w.bias;
        for tok in tokens {
            if let Some(w) = lane_w.tokens.get(tok) {
                total += w;
            }
        }
        total
    }
}
