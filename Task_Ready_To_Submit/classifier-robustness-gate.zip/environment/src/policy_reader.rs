use std::fs;
use std::path::Path;

/// Load moderation policy prose for deploy logs.
pub fn load_policy(path: &Path) -> std::io::Result<String> {
    fs::read_to_string(path)
}
