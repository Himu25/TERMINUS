Helper scripts for offline corpus audits live outside this image.
