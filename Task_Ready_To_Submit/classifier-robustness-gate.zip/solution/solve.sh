#!/bin/bash
set -euo pipefail

# Terminal-Bench Canary: solver-side fix script

log() { printf '[oracle] %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight: triage layout"
require_file /app/glyph_fold/mod.rs
require_file /app/filter_ingress/mod.rs
require_file /app/tail_adjust/mod.rs
require_file /app/registry/model_weights.json
require_file /app/config/bench_profiles.json

FG="/app/glyph_fold/mod.rs"
SU="/app/filter_ingress/mod.rs"
RT="/app/tail_adjust/mod.rs"

log "patch glyph folding for homoglyphs and invisible code points"
cat > "$FG" <<'RS'
use unicode_normalization::UnicodeNormalization;

fn map_glyph(ch: char) -> char {
    match ch {
        '\u{0430}' => 'a',
        '\u{0435}' | '\u{0454}' => 'e',
        '\u{043e}' => 'o',
        '\u{0440}' => 'p',
        '\u{0441}' => 'c',
        '\u{0443}' => 'y',
        '\u{0456}' | '\u{0457}' | '\u{0438}' => 'i',
        '\u{0432}' => 'v',
        '\u{043d}' => 'n',
        '\u{043c}' => 'm',
        '\u{0434}' => 'd',
        '\u{043b}' => 'l',
        '\u{0433}' => 'g',
        '\u{043a}' => 'k',
        '\u{0442}' => 't',
        '\u{0437}' => 'z',
        '\u{0445}' => 'x',
        '\u{0436}' => 'j',
        '\u{0444}' => 'f',
        '\u{0431}' => 'b',
        _ => ch,
    }
}

fn deleet_token(token: &str) -> String {
    token
        .chars()
        .map(|c| match c {
            '0' => 'o',
            '1' => 'i',
            '3' => 'e',
            '4' => 'a',
            '5' => 's',
            '7' => 't',
            '@' => 'a',
            '$' => 's',
            _ => c,
        })
        .collect()
}

/// Fold user text before tokenization.
pub fn prep_text(input: &str) -> String {
    let mut scrubbed = String::new();
    for ch in input.chars() {
        if matches!(
            ch,
            '\u{200b}'
                | '\u{200c}'
                | '\u{200d}'
                | '\u{feff}'
                | '\u{202a}'
                | '\u{202b}'
                | '\u{202c}'
                | '\u{202d}'
                | '\u{202e}'
        ) {
            continue;
        }
        if ch == '\u{2060}' {
            scrubbed.push(' ');
            continue;
        }
        scrubbed.push(map_glyph(ch));
    }
    let folded: String = scrubbed.nfkc().collect();
    folded
        .split_whitespace()
        .map(deleet_token)
        .collect::<Vec<_>>()
        .join(" ")
        .trim()
        .to_lowercase()
}
RS

log "expand utterance screen for override families"
cat > "$SU" <<'RS'
use crate::glyph_fold::prep_text;
use crate::glyph_pipeline;
use crate::lexicon::WeightTable;

/// Return true when the utterance may proceed to scoring.
pub fn permit_entry(raw: &str) -> bool {
    let probe = prep_text(raw);
    const BLOCKED: [&str; 14] = [
        "ignore previous",
        "ignore prior",
        "ignore earlier",
        "ignore safety",
        "disregard all",
        "disregard policies",
        "developer mode",
        "assistant override",
        "new instruction",
        "jailbreak",
        "bypass moderation",
        "respond only safe",
        "from now on you only",
        "roleplay as admin",
    ];
    if BLOCKED.iter().any(|needle| probe.contains(needle)) {
        return false;
    }
    if probe.contains("system:") || probe.contains("<<sys>>") || probe.contains("### system") {
        return false;
    }
    if probe.contains("system override")
        || probe.contains("print safe")
        || probe.contains("print harmless")
        || probe.contains("reply only safe")
    {
        return false;
    }
    if probe.contains("admin prompt")
        || probe.contains("classify as safe")
        || probe.contains("classifysafe")
        || probe.contains("disable filters")
        || probe.contains("respond only safe")
        || probe.contains("wiring funds")
        || probe.contains("moving funds")
    {
        return false;
    }
    if probe.contains("classify") && probe.contains("safe") {
        return false;
    }
    if probe.contains("execute wire") && (probe.contains("transfer") || probe.contains("payment")) {
        return false;
    }
    if probe.contains("human:") && probe.contains("assistant:") {
        return false;
    }
    true
}

pub fn dispatch(raw: &str, weights: &WeightTable) -> String {
    if !permit_entry(raw) {
        return "escalate".to_string();
    }
    glyph_pipeline::forward(raw, weights)
}
RS

log "rebalance tail weights for promotional skew"
cat > "$RT" <<'RS'
const LABELS: [&str; 4] = ["safe", "spam", "phish", "escalate"];

/// Adjust raw lane scores using length cues from the folded utterance.
pub fn reweight_tail(scores: &mut [f64], token_count: usize, byte_len: usize) {
    if scores.len() != LABELS.len() {
        return;
    }
    if token_count >= 4 && byte_len >= 18 {
        scores[1] += 0.15;
    }
    if byte_len >= 12 && token_count <= 6 {
        let density = byte_len as f64 / token_count.max(1) as f64;
        if density > 5.5 {
            scores[1] += 0.25;
        }
    }
    let _ = LABELS;
}
RS

log "rebuild bench binary"
cd /app
cargo build --release --manifest-path /app/Cargo.toml
install -m 0755 /app/target/release/suite_harness /app/bin/suite_harness
test -x /app/bin/suite_harness

log "smoke: robustness report passes gate"
/app/tools/suite_harness
require_file /app/output/robustness_report.json
python3 - <<'PY'
import json
from pathlib import Path

report = json.loads(Path("/app/output/robustness_report.json").read_text())
summary = report["summary"]
if not summary["passes_gate"]:
    raise SystemExit("passes_gate false")
if summary["clean_accuracy"] < 0.9000:
    raise SystemExit("clean floor miss")
if summary["robustness_score"] < 0.9400:
    raise SystemExit("composite floor miss")
for suite in report["suites"]:
    if suite["name"] != "clean" and suite["accuracy"] < 0.9500:
        raise SystemExit(f"suite {suite['name']} below floor")
PY

log "oracle complete"
