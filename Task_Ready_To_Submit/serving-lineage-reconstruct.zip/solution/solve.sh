#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/internal/weave_n3/resolve.go <<'EOF'
package weave_n3

import (
	"bufio"
	"encoding/json"
	"os"
	"path/filepath"

	"lineagereplay/artifactwire"
	"lineagereplay/datasets"
	"lineagereplay/flux_p2"
)

type ResolveResult struct {
	DatasetIDs     []string
	CollisionFixes int
	CorpusPrunes   int
}

func loadRows(root, subdir string) ([]artifactwire.TrackerRow, error) {
	path := filepath.Join(root, subdir, "runs.jsonl")
	f, err := os.Open(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	defer f.Close()
	var rows []artifactwire.TrackerRow
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		var row artifactwire.TrackerRow
		if err := json.Unmarshal(sc.Bytes(), &row); err != nil {
			continue
		}
		rows = append(rows, row)
	}
	return rows, sc.Err()
}

func allRows(root string) ([]artifactwire.TrackerRow, error) {
	ml, err := loadRows(root, "mlflow")
	if err != nil {
		return nil, err
	}
	wb, err := loadRows(root, "wandb")
	if err != nil {
		return nil, err
	}
	return append(ml, wb...), nil
}

func runNameDupes(rows []artifactwire.TrackerRow, name string) int {
	n := 0
	for _, row := range rows {
		if row.RunName == name {
			n++
		}
	}
	return n
}

func ResolveRun(root string, _ string, seedDigest string) (ResolveResult, error) {
	rows, err := allRows(root)
	if err != nil {
		return ResolveResult{}, err
	}
	for _, row := range rows {
		if row.SeedDigest != seedDigest {
			continue
		}
		fixes := 0
		if runNameDupes(rows, row.RunName) > 1 {
			fixes = 1
		}
		pinned, err := datasets.PinTokens(root, row.DatasetIDs)
		if err != nil {
			return ResolveResult{}, err
		}
		ids, prunes := flux_p2.ClipSpan(pinned)
		return ResolveResult{
			DatasetIDs:     ids,
			CollisionFixes: fixes,
			CorpusPrunes:   prunes,
		}, nil
	}
	return ResolveResult{}, nil
}
EOF

cat > /app/internal/latch_m2/op_k.go <<'EOF'
package latch_m2

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"

	"lineagereplay/artifactwire"
)

type LatchRow struct {
	ModelID string
	Step    int
	Repairs int
}

func scanDir(dir string, want string) (*artifactwire.Sidecar, string, error) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, "", nil
		}
		return nil, "", err
	}
	for _, ent := range entries {
		if ent.IsDir() || filepath.Ext(ent.Name()) != ".json" {
			continue
		}
		raw, err := os.ReadFile(filepath.Join(dir, ent.Name()))
		if err != nil {
			return nil, "", err
		}
		var sc artifactwire.Sidecar
		if err := json.Unmarshal(raw, &sc); err != nil {
			continue
		}
		if strings.EqualFold(sc.SHA256, want) {
			copy := sc
			stem := strings.TrimSuffix(ent.Name(), ".sidecar.json")
			return &copy, stem, nil
		}
	}
	return nil, "", nil
}

func OpK(root string, row artifactwire.DeployRow) (LatchRow, error) {
	dirs := []string{
		filepath.Join(root, "checkpoints"),
		filepath.Join(root, "s3_snapshots"),
	}
	var matched *artifactwire.Sidecar
	var matchedName string
	for _, dir := range dirs {
		sc, stem, err := scanDir(dir, row.ExpectedSHA)
		if err != nil {
			return LatchRow{}, err
		}
		if sc != nil {
			matched = sc
			matchedName = stem
			break
		}
	}
	if matched == nil {
		pattern := filepath.Join(root, "checkpoints", row.ModelID+".sidecar.json")
		raw, err := os.ReadFile(pattern)
		if err != nil {
			return LatchRow{}, err
		}
		var sc artifactwire.Sidecar
		if err := json.Unmarshal(raw, &sc); err != nil {
			return LatchRow{}, err
		}
		matched = &sc
		matchedName = row.ModelID
	}
	repairs := 0
	if matchedName != row.ModelID {
		repairs = 1
	}
	if !strings.EqualFold(matched.SHA256, row.ExpectedSHA) {
		repairs = 0
	}
	return LatchRow{
		ModelID: row.ModelID,
		Step:    matched.Step,
		Repairs: repairs,
	}, nil
}

func LoadDeploy(root string) (artifactwire.DeployManifest, error) {
	raw, err := os.ReadFile(filepath.Join(root, "serving.json"))
	if err != nil {
		return artifactwire.DeployManifest{}, err
	}
	var man artifactwire.DeployManifest
	if err := json.Unmarshal(raw, &man); err != nil {
		return artifactwire.DeployManifest{}, err
	}
	return man, nil
}
EOF

cat > /app/internal/rank_p1/pick.go <<'EOF'
package rank_p1

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sort"

	"lineagereplay/artifactwire"
)

type PickResult struct {
	Protocol string
	Scores   map[string]float64
}

func PickMarked(root, modelID string) (PickResult, error) {
	dir := filepath.Join(root, "eval", modelID)
	entries, err := os.ReadDir(dir)
	if err != nil {
		return PickResult{}, err
	}
	var shards []artifactwire.EvalShard
	var names []string
	for _, ent := range entries {
		if ent.IsDir() || filepath.Ext(ent.Name()) != ".json" {
			continue
		}
		raw, err := os.ReadFile(filepath.Join(dir, ent.Name()))
		if err != nil {
			return PickResult{}, err
		}
		var shard artifactwire.EvalShard
		if err := json.Unmarshal(raw, &shard); err != nil {
			continue
		}
		shards = append(shards, shard)
		names = append(names, ent.Name())
	}
	if len(shards) == 0 {
		return PickResult{}, nil
	}
	for idx := range shards {
		if shards[idx].Primary {
			return PickResult{
				Protocol: shards[idx].Protocol,
				Scores:   shards[idx].Scores,
			}, nil
		}
	}
	sort.Strings(names)
	for _, ent := range entries {
		if ent.Name() != names[0] {
			continue
		}
		raw, _ := os.ReadFile(filepath.Join(dir, ent.Name()))
		var shard artifactwire.EvalShard
		_ = json.Unmarshal(raw, &shard)
		return PickResult{Protocol: shard.Protocol, Scores: shard.Scores}, nil
	}
	return PickResult{}, nil
}
EOF

cat > /app/logscan/backfill.go <<'EOF'
package logscan

import (
	"lineagereplay/artifactwire"
	"lineagereplay/span_g1"
)

// BackfillZeros merges family defaults into hyperparameter slots left unset after folding.
func BackfillZeros(hp *span_g1.HparamBlock, def artifactwire.FamilyDefaults, parts []Part) {
	gap := HasGap(parts)
	fill := func(slot *float64, val float64) {
		if (gap || *slot == 0) && *slot == 0 {
			*slot = val
			hp.GapsFilled++
		}
	}
	fill(&hp.LR, def.LR)
	fill(&hp.BatchSize, def.BatchSize)
	fill(&hp.Epochs, def.Epochs)
	fill(&hp.WeightDecay, def.WeightDecay)
}
EOF

bash /app/scripts/build.sh

tb_scene=scene_alpha /app/bin/lineagereplay
test -s /app/output/deployment_report.json
