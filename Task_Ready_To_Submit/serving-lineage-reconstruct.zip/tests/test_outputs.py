"""Verifier for serving lineage reconstruction reports."""

from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

APP = Path("/app")
REPORT = APP / "output" / "deployment_report.json"
FIXTURES = Path(__file__).resolve().parent / "fixtures"

_PACK_DIRS = {
    "scene_alpha": "alpha",
    "scene_beta": "beta",
    "scene_gamma": "gamma",
    "scene_delta": "delta",
    "scene_eps": "eps",
    "scene_peak": "peak",
}


def _fixture_root(stem: str) -> Path:
    return FIXTURES / _PACK_DIRS[stem]


def _scene_tag(stem: str) -> str:
    spec = json.loads((FIXTURES / "scenes" / f"{stem}.json").read_text(encoding="utf-8"))
    return str(spec["scene_tag"])


def _drive(stem: str) -> dict:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    if REPORT.exists():
        REPORT.unlink()
    subprocess.run(
        ["/app/bin/lineagereplay"],
        cwd=str(APP),
        env={**os.environ, "tb_scene": stem},
        check=True,
    )
    payload = json.loads(REPORT.read_text(encoding="utf-8"))
    assert payload["scene_tag"] == _scene_tag(stem)
    assert isinstance(payload["deployments"], list) and payload["deployments"]
    digest = payload["report_digest"]
    assert isinstance(digest, str) and re.fullmatch(r"[0-9a-f]{64}", digest)
    return payload


def _deployment(payload: dict, model_id: str) -> dict:
    for row in payload["deployments"]:
        if row["model_id"] == model_id:
            return row
    raise AssertionError(f"missing deployment {model_id}")


def _deploy_row(root: Path, model_id: str) -> dict:
    man = json.loads((root / "serving.json").read_text(encoding="utf-8"))
    for row in man["models"]:
        if row["model_id"] == model_id:
            return row
    raise AssertionError(model_id)


def _lineage_rows(root: Path) -> list[dict]:
    rows: list[dict] = []
    for sub in ("mlflow", "wandb"):
        path = root / sub / "runs.jsonl"
        if not path.exists():
            continue
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                rows.append(json.loads(line))
    return rows


def _pin_catalog(root: Path, ids: list[str]) -> list[str]:
    path = root / "datasets" / "catalog.json"
    if not path.exists():
        return [token.strip() for token in ids if token.strip()]
    catalog = json.loads(path.read_text(encoding="utf-8"))
    out: list[str] = []
    for token in ids:
        token = token.strip()
        if not token:
            continue
        version = catalog.get(token)
        if version:
            out.append(f"{token}@{version}")
        else:
            out.append(token)
    return out


def _canonical_corpus(ids: list[str]) -> tuple[list[str], int]:
    seen: set[str] = set()
    out: list[str] = []
    prunes = 0
    for token in ids:
        token = token.strip()
        if not token:
            continue
        if token in seen:
            prunes += 1
            continue
        seen.add(token)
        out.append(token)
    return out, prunes


def _expected_datasets(root: Path, seed_digest: str) -> tuple[list[str], int, int]:
    rows = _lineage_rows(root)
    counts: dict[str, int] = {}
    for row in rows:
        counts[row["run_name"]] = counts.get(row["run_name"], 0) + 1
    for row in rows:
        if row["seed_digest"] == seed_digest:
            fixes = 1 if counts.get(row["run_name"], 0) > 1 else 0
            pinned = _pin_catalog(root, list(row["dataset_ids"]))
            datasets, prunes = _canonical_corpus(pinned)
            return datasets, fixes, prunes
    raise AssertionError(seed_digest)


def _expected_bind(root: Path, deploy: dict) -> tuple[int, int]:
    want = deploy["expected_sha256"].lower()
    repairs = 0
    step = 0
    matched_name = ""
    search_dirs = [root / "checkpoints", root / "s3_snapshots"]
    for directory in search_dirs:
        if not directory.exists():
            continue
        for path in sorted(directory.glob("*.json")):
            sc = json.loads(path.read_text(encoding="utf-8"))
            if sc["sha256"].lower() == want:
                step = int(sc["step"])
                matched_name = path.name.replace(".sidecar.json", "")
                break
        if matched_name:
            break
    if matched_name and matched_name != deploy["model_id"]:
        repairs = 1
    return step, repairs


def _expected_eval(root: Path, model_id: str) -> tuple[str, dict]:
    eval_dir = root / "eval" / model_id
    primary = None
    for path in sorted(eval_dir.glob("*.json")):
        shard = json.loads(path.read_text(encoding="utf-8"))
        if shard.get("primary"):
            primary = shard
            break
    if primary is None:
        raise AssertionError(model_id)
    return str(primary["protocol"]), dict(primary["scores"])


def _log_parts(root: Path, model_id: str) -> list[int]:
    log_dir = root / "logs" / model_id
    seqs = []
    for path in log_dir.glob("*.log"):
        seqs.append(int(path.stem))
    return sorted(seqs)


def _expected_hyperparams(root: Path, deploy: dict) -> tuple[dict[str, float], int]:
    family = deploy["family"]
    defaults = json.loads((root / "defaults" / f"{family}.json").read_text(encoding="utf-8"))
    hp = {k: 0.0 for k in ("lr", "batch_size", "epochs", "weight_decay")}
    log_dir = root / "logs" / deploy["model_id"]
    for path in sorted(log_dir.glob("*.log")):
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or "=" not in line:
                continue
            key, val = (part.strip() for part in line.split("=", 1))
            key = key.lower()
            if key in hp:
                hp[key] = float(val)
    seqs = _log_parts(root, deploy["model_id"])
    gap = any(b - a > 1 for a, b in zip(seqs, seqs[1:]))
    gaps = 0
    for key, default in (
        ("lr", defaults["lr"]),
        ("batch_size", defaults["batch_size"]),
        ("epochs", defaults["epochs"]),
        ("weight_decay", defaults["weight_decay"]),
    ):
        if (gap or hp[key] == 0.0) and hp[key] == 0.0:
            hp[key] = float(default)
            gaps += 1
    return hp, gaps


def _expected_confidence(collision: int, prunes: int, gaps: int, bind: int) -> float:
    base = 0.70 + 0.05 * collision + 0.05 * prunes + 0.05 * gaps + 0.05 * bind
    if base > 1.0:
        base = 1.0
    return round(base, 2)


def test_scene_alpha_deployment_lineage() -> None:
    """scene_alpha endpoints must resolve distinct corpora and collision counts."""
    root = _fixture_root("scene_alpha")
    payload = _drive("scene_alpha")
    for model_id in ("cls_a", "cls_b"):
        deploy = _deploy_row(root, model_id)
        datasets, fixes, prunes = _expected_datasets(root, deploy["seed_digest"])
        row = _deployment(payload, model_id)
        assert row["dataset_ids"] == datasets
        assert row["collision_fixes"] == fixes
        assert row["corpus_prunes"] == prunes
        assert row["lineage_confidence"] == _expected_confidence(fixes, prunes, 0, 0)


def test_scene_alpha_checkpoint_binding() -> None:
    """scene_alpha sidecars whose filenames match model ids report correct steps."""
    root = _fixture_root("scene_alpha")
    payload = _drive("scene_alpha")
    for model_id in ("cls_a", "cls_b"):
        deploy = _deploy_row(root, model_id)
        step, _ = _expected_bind(root, deploy)
        assert _deployment(payload, model_id)["checkpoint_step"] == step


def test_scene_beta_sidecar_rebind() -> None:
    """scene_beta must bind checkpoint metadata via digest when filenames disagree."""
    root = _fixture_root("scene_beta")
    payload = _drive("scene_beta")
    deploy = _deploy_row(root, "mdl_bind")
    step, repairs = _expected_bind(root, deploy)
    datasets, fixes, prunes = _expected_datasets(root, deploy["seed_digest"])
    row = _deployment(payload, "mdl_bind")
    assert row["checkpoint_step"] == step
    assert row["bind_repairs"] == repairs
    assert row["dataset_ids"] == datasets
    assert row["corpus_prunes"] == prunes
    assert row["lineage_confidence"] == _expected_confidence(fixes, prunes, 0, repairs)


def test_scene_gamma_hyperparam_gaps() -> None:
    """scene_gamma must count defaults merged into unset hyperparameter slots."""
    root = _fixture_root("scene_gamma")
    payload = _drive("scene_gamma")
    deploy = _deploy_row(root, "mdl_gap")
    hp, gaps = _expected_hyperparams(root, deploy)
    row = _deployment(payload, "mdl_gap")
    assert row["hyperparams"] == hp
    assert row["gaps_filled"] == gaps
    assert row["lineage_confidence"] == _expected_confidence(0, 0, gaps, 0)


def test_scene_eps_corpus_canonical() -> None:
    """scene_eps dataset_ids must pin catalog versions and deduplicate tokens."""
    root = _fixture_root("scene_eps")
    payload = _drive("scene_eps")
    deploy = _deploy_row(root, "mdl_eps")
    datasets, fixes, prunes = _expected_datasets(root, deploy["seed_digest"])
    row = _deployment(payload, "mdl_eps")
    assert row["dataset_ids"] == datasets
    assert row["corpus_prunes"] == prunes
    assert row["collision_fixes"] == fixes
    assert row["lineage_confidence"] == _expected_confidence(fixes, prunes, 0, 0)


def test_scene_delta_eval_selection() -> None:
    """scene_delta eval fields must follow the shard marked primary."""
    root = _fixture_root("scene_delta")
    payload = _drive("scene_delta")
    protocol, scores = _expected_eval(root, "mdl_eval")
    row = _deployment(payload, "mdl_eval")
    assert row["eval_protocol"] == protocol
    assert row["eval_scores"] == scores
    assert row["lineage_confidence"] == _expected_confidence(0, 0, 0, 0)


def test_scene_peak_corpus_binding() -> None:
    """scene_peak must resolve tracker, corpus, and checkpoint disagreements together."""
    root = _fixture_root("scene_peak")
    payload = _drive("scene_peak")
    deploy = _deploy_row(root, "mdl_peak")
    datasets, fixes, prunes = _expected_datasets(root, deploy["seed_digest"])
    step, repairs = _expected_bind(root, deploy)
    _, gaps = _expected_hyperparams(root, deploy)
    row = _deployment(payload, "mdl_peak")
    assert row["dataset_ids"] == datasets
    assert row["collision_fixes"] == fixes
    assert row["corpus_prunes"] == prunes
    assert row["bind_repairs"] == repairs
    assert row["checkpoint_step"] == step
    assert row["lineage_confidence"] == _expected_confidence(fixes, prunes, gaps, repairs)


def test_report_digest_seal() -> None:
    """report_digest must be sha256 of the payload with report_digest blanked."""
    payload = _drive("scene_alpha")
    clone = dict(payload)
    clone["report_digest"] = ""
    raw = json.dumps(clone, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    assert payload["report_digest"] == proc.stdout.split()[0]


def test_deployment_sort_order() -> None:
    """deployments array must be sorted ascending by model_id."""
    payload = _drive("scene_alpha")
    ids = [row["model_id"] for row in payload["deployments"]]
    assert ids == sorted(ids)


def test_replay_determinism() -> None:
    """Two consecutive replays must emit byte-identical report files."""
    _drive("scene_beta")
    first = REPORT.read_bytes()
    _drive("scene_beta")
    second = REPORT.read_bytes()
    assert first == second
