package datasets

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// PinTokens suffixes catalog keys with @version when datasets/catalog.json lists them.
func PinTokens(root string, ids []string) ([]string, error) {
	path := filepath.Join(root, "datasets", "catalog.json")
	raw, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return append([]string(nil), ids...), nil
		}
		return nil, err
	}
	var catalog map[string]string
	if err := json.Unmarshal(raw, &catalog); err != nil {
		return nil, err
	}
	out := make([]string, 0, len(ids))
	for _, id := range ids {
		token := strings.TrimSpace(id)
		if token == "" {
			continue
		}
		if ver, ok := catalog[token]; ok {
			out = append(out, fmt.Sprintf("%s@%s", token, ver))
			continue
		}
		out = append(out, token)
	}
	return out, nil
}
