Artifact trees live under `/app/data/fixtures`. Scene specs under `/app/scenes` name an `artifact_root` relative to `/app`.

Build `/app/bin/lineagereplay` with `/app/scripts/build.sh`. The driver reads `tb_scene`, loads serving manifests, tracker jsonl under mlflow/ and wandb/, checkpoint sidecars under checkpoints/ and s3_snapshots/, numbered log fragments, family defaults under defaults/, dataset catalogs under datasets/, and evaluation shards under eval/{model_id}/, then writes `/app/output/deployment_report.json`.

Go packages under `/app/internal` coordinate ingest readers. The Rust crate under `/app/span_g1` folds numbered log fragments. Supporting utilities live in flux_p2, logscan, datasets, keel_m8, and artifactwire. Regression scenes under `/app/docs/fixture_index.txt` include isolated slices plus scene_peak, which stacks tracker and checkpoint disagreements on one tree.
