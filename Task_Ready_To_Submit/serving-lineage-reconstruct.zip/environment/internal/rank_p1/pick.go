package rank_p1

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sort"

	"lineagereplay/artifactwire"
)

type PickResult struct {
	Protocol string
	Scores   map[string]float64
}

// PickMarked loads eval_protocol and eval_scores from eval/{model_id}/ shards.
func PickMarked(root, modelID string) (PickResult, error) {
	dir := filepath.Join(root, "eval", modelID)
	entries, err := os.ReadDir(dir)
	if err != nil {
		return PickResult{}, err
	}
	var names []string
	for _, ent := range entries {
		if ent.IsDir() {
			continue
		}
		if filepath.Ext(ent.Name()) == ".json" {
			names = append(names, ent.Name())
		}
	}
	sort.Strings(names)
	if len(names) == 0 {
		return PickResult{}, nil
	}
	raw, err := os.ReadFile(filepath.Join(dir, names[0]))
	if err != nil {
		return PickResult{}, err
	}
	var shard artifactwire.EvalShard
	if err := json.Unmarshal(raw, &shard); err != nil {
		return PickResult{}, err
	}
	return PickResult{
		Protocol: shard.Protocol,
		Scores:   shard.Scores,
	}, nil
}
