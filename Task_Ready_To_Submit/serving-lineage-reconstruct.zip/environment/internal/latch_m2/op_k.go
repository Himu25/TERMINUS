package latch_m2

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"

	"lineagereplay/artifactwire"
)

type LatchRow struct {
	ModelID string
	Step    int
	Repairs int
}

func OpK(root string, row artifactwire.DeployRow) (LatchRow, error) {
	pattern := filepath.Join(root, "checkpoints", row.ModelID+".sidecar.json")
	raw, err := os.ReadFile(pattern)
	if err != nil {
		return LatchRow{}, err
	}
	var sc artifactwire.Sidecar
	if err := json.Unmarshal(raw, &sc); err != nil {
		return LatchRow{}, err
	}
	repairs := 0
	if !strings.EqualFold(sc.SHA256, row.ExpectedSHA) {
		repairs = 0
	}
	return LatchRow{
		ModelID: row.ModelID,
		Step:    sc.Step,
		Repairs: repairs,
	}, nil
}

func LoadDeploy(root string) (artifactwire.DeployManifest, error) {
	raw, err := os.ReadFile(filepath.Join(root, "serving.json"))
	if err != nil {
		return artifactwire.DeployManifest{}, err
	}
	var man artifactwire.DeployManifest
	if err := json.Unmarshal(raw, &man); err != nil {
		return artifactwire.DeployManifest{}, err
	}
	return man, nil
}
