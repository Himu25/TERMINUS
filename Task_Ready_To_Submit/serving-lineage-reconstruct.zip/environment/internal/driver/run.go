package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"

	"lineagereplay/internal/latch_m2"
)

// Deployment is one reconstructed production endpoint row.
type Deployment struct {
	ModelID           string             `json:"model_id"`
	DatasetIDs        []string           `json:"dataset_ids"`
	Hyperparams       map[string]float64 `json:"hyperparams"`
	EvalProtocol      string             `json:"eval_protocol"`
	EvalScores        map[string]float64 `json:"eval_scores"`
	CheckpointStep    int                `json:"checkpoint_step"`
	CollisionFixes    int                `json:"collision_fixes"`
	CorpusPrunes      int                `json:"corpus_prunes"`
	GapsFilled        int                `json:"gaps_filled"`
	BindRepairs       int                `json:"bind_repairs"`
	LineageConfidence float64            `json:"lineage_confidence"`
}

// Payload is the top-level deployment report.
type Payload struct {
	SceneTag     string       `json:"scene_tag"`
	Deployments  []Deployment `json:"deployments"`
	ReportDigest string       `json:"report_digest"`
}

type sceneSpec struct {
	SceneTag     string `json:"scene_tag"`
	ArtifactRoot string `json:"artifact_root"`
}

// Run rebuilds deployments for tb_scene and writes /app/output/deployment_report.json.
func Run() error {
	stem := os.Getenv("tb_scene")
	if stem == "" {
		return errors.New("tb_scene must name a stem under /app/scenes")
	}
	raw, err := os.ReadFile(filepath.Join("/app/scenes", stem+".json"))
	if err != nil {
		return err
	}
	var spec sceneSpec
	if err := json.Unmarshal(raw, &spec); err != nil {
		return err
	}
	root := filepath.Join("/app", spec.ArtifactRoot)
	man, err := latch_m2.LoadDeploy(root)
	if err != nil {
		return err
	}
	defs, err := loadDefaults(root)
	if err != nil {
		return err
	}

	var deployments []Deployment
	for _, row := range man.Models {
		dep, err := BuildRow(root, row, defs)
		if err != nil {
			return err
		}
		deployments = append(deployments, dep)
	}
	sort.Slice(deployments, func(i, j int) bool { return deployments[i].ModelID < deployments[j].ModelID })

	out := Payload{SceneTag: spec.SceneTag, Deployments: deployments}
	out.ReportDigest = digestPayload(out)
	emit := "/app/output/deployment_report.json"
	if err := os.MkdirAll(filepath.Dir(emit), 0o755); err != nil {
		return err
	}
	buf, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		return err
	}
	tmp := emit + ".tmp"
	if err := os.WriteFile(tmp, buf, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, emit)
}

func digestPayload(p Payload) string {
	clone := p
	clone.ReportDigest = ""
	raw, _ := json.Marshal(clone)
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

// MainExit wraps Run for cmd.
func MainExit() int {
	if err := Run(); err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		return 1
	}
	return 0
}
