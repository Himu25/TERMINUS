package driver

import (
	"encoding/json"
	"os"
	"path/filepath"

	"lineagereplay/artifactwire"
	"lineagereplay/internal/latch_m2"
	"lineagereplay/internal/rank_p1"
	"lineagereplay/internal/weave_n3"
	"lineagereplay/logscan"
	"lineagereplay/span_g1"
)

// BuildRow stitches ingest stages into one deployment row.
func BuildRow(root string, row artifactwire.DeployRow, defs map[string]artifactwire.FamilyDefaults) (Deployment, error) {
	res, err := weave_n3.ResolveRun(root, row.CanonicalRun, row.SeedDigest)
	if err != nil {
		return Deployment{}, err
	}
	bind, err := latch_m2.OpK(root, row)
	if err != nil {
		return Deployment{}, err
	}
	parts, err := logscan.LoadParts(filepath.Join(root, "logs", row.ModelID))
	if err != nil {
		return Deployment{}, err
	}
	def := defs[row.Family]
	var logParts []span_g1.LogPart
	for _, p := range parts {
		logParts = append(logParts, span_g1.LogPart{Text: p.Text, SeqNo: p.Seq})
	}
	hp := span_g1.FoldHparams(logParts, def.LR, def.BatchSize, def.Epochs, def.WeightDecay)
	logscan.BackfillZeros(&hp, def, parts)
	ev, err := rank_p1.PickMarked(root, row.ModelID)
	if err != nil {
		return Deployment{}, err
	}
	conf := rowConfidence(res.CollisionFixes, res.CorpusPrunes, hp.GapsFilled, bind.Repairs)
	return Deployment{
		ModelID:    row.ModelID,
		DatasetIDs: res.DatasetIDs,
		Hyperparams: map[string]float64{
			"lr":           hp.LR,
			"batch_size":   hp.BatchSize,
			"epochs":       hp.Epochs,
			"weight_decay": hp.WeightDecay,
		},
		EvalProtocol:      ev.Protocol,
		EvalScores:        ev.Scores,
		CheckpointStep:    bind.Step,
		CollisionFixes:    res.CollisionFixes,
		CorpusPrunes:      res.CorpusPrunes,
		GapsFilled:        hp.GapsFilled,
		BindRepairs:       bind.Repairs,
		LineageConfidence: conf,
	}, nil
}

func loadDefaults(root string) (map[string]artifactwire.FamilyDefaults, error) {
	dir := filepath.Join(root, "defaults")
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}
	out := map[string]artifactwire.FamilyDefaults{}
	for _, ent := range entries {
		if ent.IsDir() || filepath.Ext(ent.Name()) != ".json" {
			continue
		}
		family := ent.Name()[:len(ent.Name())-5]
		raw, err := os.ReadFile(filepath.Join(dir, ent.Name()))
		if err != nil {
			return nil, err
		}
		var def artifactwire.FamilyDefaults
		if err := json.Unmarshal(raw, &def); err != nil {
			return nil, err
		}
		out[family] = def
	}
	return out, nil
}

func rowConfidence(collisions, prunes, gaps, binds int) float64 {
	base := 0.70
	base += float64(collisions) * 0.05
	base += float64(prunes) * 0.05
	base += float64(gaps) * 0.05
	base += float64(binds) * 0.05
	if base > 1.0 {
		return 1.0
	}
	return float64(int(base*100+0.5)) / 100.0
}
