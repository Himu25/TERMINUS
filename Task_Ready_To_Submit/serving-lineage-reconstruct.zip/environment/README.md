# serving-lineage-reconstruct

Reconstruct production deployment lineage from scattered MLOps artifacts (mlflow, wandb, checkpoints, s3_snapshots, logs).

Set `tb_scene` to a stem in `/app/scenes` before invoking `/app/bin/lineagereplay`.
