// lineagereplay reconstructs production deployment lineage from scattered MLOps artifacts.
//
// Invoke with tb_scene set to a stem under /app/scenes.
// Output /app/output/deployment_report.json carries:
//   scene_tag — label from the scene spec;
//   deployments — one object per live endpoint sorted by model_id;
//   report_digest — sha256 hex of the payload with report_digest blanked.
//
// Each deployment object includes:
//   model_id,
//   dataset_ids,
//   hyperparams (lr, batch_size, epochs, weight_decay),
//   eval_protocol,
//   eval_scores,
//   checkpoint_step,
//   collision_fixes,
//   corpus_prunes,
//   gaps_filled,
//   bind_repairs,
//   lineage_confidence.
//
// Identical tb_scene replays emit byte-identical reports.
package main

import (
	"os"

	"lineagereplay/internal/driver"
)

func main() {
	os.Exit(driver.MainExit())
}
