package logscan

import (
	"lineagereplay/artifactwire"
	"lineagereplay/span_g1"
)

// BackfillZeros merges family defaults into hyperparameter slots left unset after folding.
func BackfillZeros(hp *span_g1.HparamBlock, def artifactwire.FamilyDefaults, parts []Part) {
	gap := HasGap(parts)
	if (gap || hp.LR == 0) && hp.LR == 0 {
		hp.LR = def.LR
	}
	if (gap || hp.BatchSize == 0) && hp.BatchSize == 0 {
		hp.BatchSize = def.BatchSize
	}
	if (gap || hp.Epochs == 0) && hp.Epochs == 0 {
		hp.Epochs = def.Epochs
	}
	if (gap || hp.WeightDecay == 0) && hp.WeightDecay == 0 {
		hp.WeightDecay = def.WeightDecay
	}
}
