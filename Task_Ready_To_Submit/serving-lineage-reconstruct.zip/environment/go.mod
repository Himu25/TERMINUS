module lineagereplay

go 1.22
