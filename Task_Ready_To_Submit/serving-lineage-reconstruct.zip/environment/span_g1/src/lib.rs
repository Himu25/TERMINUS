use std::ffi::CStr;
use std::os::raw::{c_char, c_int};

#[repr(C)]
pub struct RkLogPart {
    pub text: *const c_char,
    pub seq_no: c_int,
}

#[repr(C)]
pub struct RkHparam {
    pub lr: f64,
    pub batch_size: f64,
    pub epochs: f64,
    pub weight_decay: f64,
    pub gaps_filled: c_int,
}

fn parse_pair(line: &str) -> Option<(String, f64)> {
    let line = line.trim();
    if line.is_empty() {
        return None;
    }
    let (k, v) = line.split_once('=')?;
    let key = k.trim().to_ascii_lowercase();
    let val: f64 = v.trim().parse().ok()?;
    Some((key, val))
}

fn scan_part(text: &str, out: &mut RkHparam) {
    for line in text.lines() {
        let Some((key, val)) = parse_pair(line) else {
            continue;
        };
        match key.as_str() {
            "lr" => out.lr = val,
            "batch_size" => out.batch_size = val,
            "epochs" => out.epochs = val,
            "weight_decay" => out.weight_decay = val,
            _ => {}
        }
    }
}

#[no_mangle]
pub extern "C" fn rk_fold_hparams(
    parts: *const RkLogPart,
    count: c_int,
    def_lr: f64,
    def_batch: f64,
    def_epochs: f64,
    def_wd: f64,
) -> RkHparam {
    let mut hp = RkHparam {
        lr: 0.0,
        batch_size: 0.0,
        epochs: 0.0,
        weight_decay: 0.0,
        gaps_filled: 0,
    };
    if parts.is_null() || count <= 0 {
        return hp;
    }
    let slice = unsafe { std::slice::from_raw_parts(parts, count as usize) };
    let mut ordered: Vec<&RkLogPart> = slice.iter().collect();
    ordered.sort_by_key(|p| p.seq_no);
    for raw in ordered {
        if raw.text.is_null() {
            continue;
        }
        let text = unsafe { CStr::from_ptr(raw.text).to_str().unwrap_or("") };
        scan_part(text, &mut hp);
    }
    hp
}
