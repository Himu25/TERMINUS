#!/bin/bash
# CI smoke: ensure lineagereplay binary exists after image build.
test -x /app/bin/lineagereplay
