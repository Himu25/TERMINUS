"""Verifier for cross-system-identity-weave."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "weave_report.json"
HARNESS = APP / "tools" / "id_weave"
PROFILE = APP / "config" / "bench_profiles.json"
THRESHOLDS = APP / "config" / "thresholds.toml"
REGISTRY_LABELS = APP / "registry" / "mapping_labels.json"
STAGING_LABELS = APP / "registry" / "staging_mapping_labels.json"
FIXTURES = Path("/tests/fixtures")

ADJUDICATION: dict[str, dict[str, list[list[str]]]] = {
    "clean_anchor": {
        "merge_pairs": [["crm-a1", "bill-a1"], ["crm-b1", "bill-b1"]],
        "deferred_pairs": [],
    },
    "email_fork": {
        "merge_pairs": [["crm-e1", "bill-e1"], ["crm-e1", "ana-e1"], ["crm-e2", "mkt-e2"]],
        "deferred_pairs": [],
    },
    "merge_chain": {
        "merge_pairs": [["crm-m1", "ana-m3"], ["crm-m1", "sup-m3"]],
        "deferred_pairs": [],
    },
    "name_history": {
        "merge_pairs": [["crm-n1", "bill-n1"]],
        "deferred_pairs": [],
    },
    "block_ext": {
        "merge_pairs": [["crm-bk3", "sup-bk3"]],
        "deferred_pairs": [],
    },
    "pending_hold": {
        "merge_pairs": [["crm-p1", "ana-p3"]],
        "deferred_pairs": [["crm-p1", "bill-p2"]],
    },
    "priority_split": {
        "merge_pairs": [["crm-pr1", "bill-pr1"], ["crm-pr1", "mkt-pr1"]],
        "deferred_pairs": [],
    },
    "five_source": {
        "merge_pairs": [["crm-f1", "mkt-f1"], ["crm-f1", "sup-f1"]],
        "deferred_pairs": [],
    },
    "corrupt_mix": {
        "merge_pairs": [["crm-r2", "bill-r2"]],
        "deferred_pairs": [],
    },
    "locale_mix": {
        "merge_pairs": [["crm-l1", "bill-l1"], ["crm-l1", "ana-l1"]],
        "deferred_pairs": [],
    },
}

EXPECTED_COMPONENTS: dict[str, list[list[str]]] = {
    "clean_anchor": [["ana-a1", "bill-a1", "crm-a1", "mkt-a1", "sup-a1"], ["bill-b1", "crm-b1"]],
    "email_fork": [["ana-e1", "bill-e1", "crm-e1"], ["crm-e2", "mkt-e2"]],
    "merge_chain": [["ana-m3", "bill-m2", "crm-m1", "sup-m3"], ["crm-x1"]],
    "name_history": [["ana-n1", "bill-n1", "crm-n1"], ["crm-n2"]],
    "block_ext": [["bill-bk2"], ["crm-bk1"], ["crm-bk3", "sup-bk3"]],
    "pending_hold": [["ana-p3", "crm-p1"], ["bill-p2"]],
    "priority_split": [["bill-pr1", "crm-pr1", "mkt-pr1"]],
    "five_source": [["ana-f1", "bill-f1", "crm-f1", "mkt-f1", "sup-f1"], ["crm-f2"]],
    "corrupt_mix": [["bill-r2", "crm-r2"]],
    "locale_mix": [["ana-l1", "bill-l1", "crm-l1"]],
}

EXPECTED_BLOCKS: dict[str, int] = {
    "block_ext": 1,
}

REPORT_KEYS = frozenset({"scenarios", "summary"})
SCENARIO_KEYS = frozenset(
    {
        "name",
        "records_in",
        "links_in",
        "identities",
        "pairs_expected",
        "pairs_found",
        "mapping_recall",
        "components",
        "deferred_pairs",
        "blocks_honored",
        "conflicts_fixed",
    }
)
SUMMARY_KEYS = frozenset({"composite_recall", "passes_gate"})


def _parse_thresholds(path: Path) -> dict[str, float]:
    floors: dict[str, float] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.split("#", 1)[0].strip()
        if not stripped or "=" not in stripped:
            continue
        key, raw = stripped.split("=", 1)
        floors[key.strip()] = float(raw.strip())
    return floors


_FLOOR_DATA = _parse_thresholds(THRESHOLDS)
COMPOSITE_FLOOR = _FLOOR_DATA["composite_recall"]


def _profile_scenario_paths(profile_path: Path) -> dict[str, dict[str, Path]]:
    profile = json.loads(profile_path.read_text(encoding="utf-8"))
    out: dict[str, dict[str, Path]] = {}
    for entry in profile["scenarios"]:
        out[entry["name"]] = {
            "records": APP / entry["records"],
            "links": APP / entry["links"],
        }
    return out


def _profile_scenario_order(profile_path: Path) -> list[str]:
    profile = json.loads(profile_path.read_text(encoding="utf-8"))
    return [entry["name"] for entry in profile["scenarios"]]


def _count_valid_records(records_path: Path) -> int:
    count = 0
    for line in records_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        try:
            row = json.loads(stripped)
        except json.JSONDecodeError:
            continue
        if not str(row.get("rid", "")).strip():
            continue
        if not str(row.get("source", "")).strip():
            continue
        if not str(row.get("email", "")).strip():
            continue
        count += 1
    return count


def _normalize_components(components: list[list[str]]) -> list[list[str]]:
    return sorted([sorted(group) for group in components])


def _ids_in_components(components: list[list[str]]) -> set[str]:
    seen: set[str] = set()
    for group in components:
        for rid in group:
            assert rid not in seen, f"duplicate rid {rid} in components"
            seen.add(rid)
    return seen


def _pairs_satisfied(components: list[list[str]], pairs: list[list[str]]) -> int:
    parent: dict[str, str] = {}

    def find(node: str) -> str:
        parent.setdefault(node, node)
        while parent[node] != node:
            parent[node] = parent[parent[node]]
            node = parent[node]
        return node

    def merge(left: str, right: str) -> None:
        root_left = find(left)
        root_right = find(right)
        if root_left != root_right:
            parent[root_right] = root_left

    for group in components:
        if not group:
            continue
        anchor = group[0]
        for member in group[1:]:
            merge(anchor, member)

    found = 0
    for left, right in pairs:
        if find(left) == find(right):
            found += 1
    return found


def _normalize_pairs(pairs: list[list[str]]) -> list[list[str]]:
    out: list[list[str]] = []
    for left, right in pairs:
        if left <= right:
            out.append([left, right])
        else:
            out.append([right, left])
    out.sort()
    return out


def _run_harness(profile: Path | None = None) -> None:
    _stage_adjudication_registry()
    cmd = [str(HARNESS)]
    if profile is not None:
        cmd.append(str(profile))
    env = os.environ.copy()
    env["WEAVE_LABELS_PATH"] = str(STAGING_LABELS)
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False, env=env)
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "weave_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


def _scenario_map(report: dict) -> dict[str, dict]:
    return {row["name"]: row for row in report["scenarios"]}


def _round4(value: float) -> float:
    return float(f"{value:.4f}")


_PROFILE_PATHS = _profile_scenario_paths(PROFILE)
_PROFILE_ORDER = _profile_scenario_order(PROFILE)


def _stage_adjudication_registry() -> None:
    payload = json.dumps(ADJUDICATION, indent=2) + "\n"
    STAGING_LABELS.write_text(payload, encoding="utf-8")
    try:
        REGISTRY_LABELS.parent.mkdir(parents=True, exist_ok=True)
        REGISTRY_LABELS.write_text(payload, encoding="utf-8")
    except OSError:
        pass


@pytest.fixture(scope="session", autouse=True)
def adjudication_registry() -> None:
    _stage_adjudication_registry()


@pytest.fixture(scope="module")
def default_report(adjudication_registry: None) -> dict:
    _run_harness(PROFILE)
    return _load_report()


def _assert_scenario_shape(report: dict, name: str) -> dict:
    row = _scenario_map(report)[name]
    assert SCENARIO_KEYS.issubset(row.keys())
    expected_records = _count_valid_records(_PROFILE_PATHS[name]["records"])
    merge_pairs = ADJUDICATION[name]["merge_pairs"]
    expected_pairs = len(merge_pairs)
    assert row["records_in"] == expected_records
    assert row["identities"] == len(EXPECTED_COMPONENTS[name])
    satisfied = _pairs_satisfied(row["components"], merge_pairs)
    assert satisfied == expected_pairs
    recall_from_components = (
        1.0 if expected_pairs == 0 else _round4(satisfied / expected_pairs)
    )
    floor = _FLOOR_DATA[name]
    assert recall_from_components >= floor
    assert row["mapping_recall"] == recall_from_components
    assert _normalize_components(row["components"]) == _normalize_components(
        EXPECTED_COMPONENTS[name]
    )
    expected_deferred = _normalize_pairs(ADJUDICATION[name]["deferred_pairs"])
    assert _normalize_pairs(row["deferred_pairs"]) == expected_deferred
    if name in EXPECTED_BLOCKS:
        assert row["blocks_honored"] == EXPECTED_BLOCKS[name]
    if name == "priority_split":
        assert row["conflicts_fixed"] >= 1
    admitted = _ids_in_components(row["components"])
    assert len(admitted) == row["records_in"]
    return row


def test_report_top_level_shape(default_report: dict) -> None:
    """Report exposes scenarios and summary blocks with required keys."""
    assert REPORT_KEYS.issubset(default_report.keys())
    assert SUMMARY_KEYS.issubset(default_report["summary"].keys())


def test_clean_anchor_mapping(default_report: dict) -> None:
    """Shared ext_key rows across five sources collapse into unified identities."""
    _assert_scenario_shape(default_report, "clean_anchor")


def test_email_fork_aliases(default_report: dict) -> None:
    """Plus-tag and dotted gmail locals merge into one identity."""
    _assert_scenario_shape(default_report, "email_fork")


def test_merge_chain_pointer(default_report: dict) -> None:
    """Chained merged_into pointers reach the surviving analytics account."""
    _assert_scenario_shape(default_report, "merge_chain")


def test_name_history_aliases(default_report: dict) -> None:
    """prior_names on CRM rows pull billing spellings into the same identity."""
    _assert_scenario_shape(default_report, "name_history")


def test_block_ext_honors_block_lane(default_report: dict) -> None:
    """Block-lane signal keeps conflicting ext_key endpoints apart."""
    _assert_scenario_shape(default_report, "block_ext")


def test_pending_hold_deferred_pairs(default_report: dict) -> None:
    """Pending-lane edges stay in deferred_pairs without merging."""
    _assert_scenario_shape(default_report, "pending_hold")


def test_priority_split_unifies(default_report: dict) -> None:
    """Same ext_key with divergent emails still lands in one identity."""
    _assert_scenario_shape(default_report, "priority_split")


def test_five_source_chain(default_report: dict) -> None:
    """Weak links chain records across all five business sources."""
    _assert_scenario_shape(default_report, "five_source")


def test_corrupt_mix_admission(default_report: dict) -> None:
    """Malformed rows are excluded from records_in totals."""
    _assert_scenario_shape(default_report, "corrupt_mix")


def test_locale_mix_spellings(default_report: dict) -> None:
    """Mixed-locale spellings collapse through name affinity."""
    _assert_scenario_shape(default_report, "locale_mix")


def test_profile_order_matches_config(default_report: dict) -> None:
    """Scenario rows appear in profile order."""
    names = [row["name"] for row in default_report["scenarios"]]
    assert names == _PROFILE_ORDER


def test_composite_recall_matches_mean(default_report: dict) -> None:
    """Summary composite recall equals the unweighted mean of scenario recalls."""
    recalls = [row["mapping_recall"] for row in default_report["scenarios"]]
    expected = _round4(sum(recalls) / len(recalls))
    assert default_report["summary"]["composite_recall"] == expected


def test_passes_gate_iff_all_floors_hold(default_report: dict) -> None:
    """passes_gate is true exactly when every scenario clears its floor."""
    summary = default_report["summary"]
    all_clear = all(
        row["mapping_recall"] >= _FLOOR_DATA[row["name"]]
        for row in default_report["scenarios"]
    )
    assert summary["passes_gate"] is all_clear
    assert summary["passes_gate"] is True
    assert summary["composite_recall"] >= COMPOSITE_FLOOR


def test_deterministic_report_bytes(default_report: dict) -> None:
    """Back-to-back default-profile runs are byte-identical."""
    first = OUT.read_bytes()
    _run_harness(PROFILE)
    second = OUT.read_bytes()
    assert first == second


def test_registry_tamper_resistance() -> None:
    """Harness scoring ignores registry tampering when staging labels differ."""
    _run_harness(PROFILE)
    baseline = _load_report()
    tampered = {"fake": {"merge_pairs": [["z99", "z98"]], "deferred_pairs": []}}
    REGISTRY_LABELS.write_text(json.dumps(tampered) + "\n", encoding="utf-8")
    _run_harness(PROFILE)
    after = _load_report()
    assert after == baseline


def test_alternate_profile_fixture() -> None:
    """Alternate bench profile from fixtures produces expected scenario subset."""
    alt = FIXTURES / "profile_pending_only.json"
    assert alt.is_file()
    _run_harness(alt)
    report = _load_report()
    names = [row["name"] for row in report["scenarios"]]
    assert names == ["pending_hold"]
    _assert_scenario_shape(report, "pending_hold")
