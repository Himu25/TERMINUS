package record

type Row struct {
	RID        string   `json:"rid"`
	Source     string   `json:"source"`
	Email      string   `json:"email"`
	Display    string   `json:"display"`
	ExtKey     string   `json:"ext_key"`
	MergedInto string   `json:"merged_into"`
	PriorNames []string `json:"prior_names"`
	Kind       string   `json:"kind"`
}

type Edge struct {
	Left  string `json:"left"`
	Right string `json:"right"`
	Lane  string `json:"lane"`
}
