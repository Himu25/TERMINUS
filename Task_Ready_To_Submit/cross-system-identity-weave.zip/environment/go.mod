module lab.local/cross_system_identity_weave

go 1.22
