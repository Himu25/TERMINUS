// Outward report written to /app/output/weave_report.json.
package main

import (
	"log"
	"os"

	"lab.local/cross_system_identity_weave/internal/meshdrive"
)

func main() {
	profile := "/app/config/bench_profiles.json"
	if len(os.Args) > 1 {
		profile = os.Args[1]
	}
	labelsPath := "/app/registry/mapping_labels.json"
	if v := os.Getenv("WEAVE_LABELS_PATH"); v != "" {
		labelsPath = v
	}
	labels, err := meshdrive.LoadLabels(labelsPath)
	if err != nil {
		log.Fatal(err)
	}
	rep, err := meshdrive.RunProfile("/app", profile, "/app/config/thresholds.toml", labels)
	if err != nil {
		log.Fatal(err)
	}
	if err := meshdrive.EmitReport("/app/output/weave_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
