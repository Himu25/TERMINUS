package lanepick

func SourceRank(source string) int {
	switch source {
	case "marketing":
		return 5
	case "support":
		return 4
	case "analytics":
		return 3
	case "billing":
		return 2
	case "crm":
		return 1
	default:
		return 0
	}
}

func SpA(tag string) bool {
	return tag == "strong"
}

func SpB(tag string) bool {
	return tag == "block"
}

func SpC(tag string) bool {
	return tag == "pending"
}
