package syncpack

import (
	"sort"
	"strings"

	"lab.local/cross_system_identity_weave/internal/feeder"
	"lab.local/cross_system_identity_weave/internal/lanepick"
	"lab.local/cross_system_identity_weave/meshcore"
	"lab.local/cross_system_identity_weave/pkg/record"
)

const nameCut = 0.85

type ScenarioResult struct {
	Name            string
	RecordsIn       int
	LinksIn         int
	Quarantined     int
	Identities      int
	PairsExpected   int
	PairsFound      int
	MappingRecall   float64
	Components      [][]string
	DeferredPairs   [][]string
	BlocksHonored   int
	ConflictsFixed  int
}

func RunScenario(name, recordsPath, linksPath string, expectedPairs [][]string, deferredPairs [][]string) (ScenarioResult, error) {
	rows, quarantined, err := feeder.LoadRecords(recordsPath)
	if err != nil {
		return ScenarioResult{}, err
	}
	edges, err := feeder.LoadEdges(linksPath)
	if err != nil {
		return ScenarioResult{}, err
	}

	ridToIdx := map[string]int{}
	foldedEmail := make([]string, len(rows))
	foldedNames := make([][]string, len(rows))
	extKeyOf := make([]string, len(rows))
	kindOf := make([]string, len(rows))
	for i, row := range rows {
		ridToIdx[row.RID] = i
		foldedEmail[i] = meshcore.FoldEmail(row.Email)
		foldedNames[i] = aliasFold(row)
		extKeyOf[i] = strings.TrimSpace(row.ExtKey)
		kindOf[i] = strings.TrimSpace(row.Kind)
	}

	var cgEdges []meshcore.Edge
	for _, edge := range edges {
		left, okL := ridToIdx[edge.Left]
		right, okR := ridToIdx[edge.Right]
		if !okL || !okR {
			continue
		}
		tag := laneCode(edge.Lane)
		if tag == 255 {
			continue
		}
		if lanepick.SpA(edge.Lane) || lanepick.SpB(edge.Lane) {
			cgEdges = append(cgEdges, meshcore.Edge{Left: uint32(left), Right: uint32(right), Tag: tag})
		}
	}

	for i := 0; i < len(rows); i++ {
		for j := i + 1; j < len(rows); j++ {
			if kindOf[i] != kindOf[j] {
				continue
			}
			if extKeyOf[i] != "" && extKeyOf[j] != "" && extKeyOf[i] == extKeyOf[j] {
				cgEdges = append(cgEdges, meshcore.Edge{Left: uint32(i), Right: uint32(j), Tag: meshcore.TagStrong})
			}
			if foldedEmail[i] != "" && foldedEmail[i] == foldedEmail[j] {
				cgEdges = append(cgEdges, meshcore.Edge{Left: uint32(i), Right: uint32(j), Tag: meshcore.TagWeak})
			}
			if nameAffinityPair(foldedNames[i], foldedNames[j]) >= nameCut {
				cgEdges = append(cgEdges, meshcore.Edge{Left: uint32(i), Right: uint32(j), Tag: meshcore.TagWeak})
			}
		}
	}

	parent := meshcore.KnitClusters(len(rows), cgEdges)

	rootToRIDs := map[uint32][]string{}
	for i, row := range rows {
		root := parent[i]
		rootToRIDs[root] = append(rootToRIDs[root], row.RID)
	}
	components := make([][]string, 0, len(rootToRIDs))
	for _, ids := range rootToRIDs {
		sort.Strings(ids)
		components = append(components, ids)
	}
	sort.Slice(components, func(i, j int) bool {
		if len(components[i]) == 0 || len(components[j]) == 0 {
			return len(components[i]) > 0
		}
		return components[i][0] < components[j][0]
	})

	deferred := collectDeferred(edges, ridToIdx, parent)
	blocksHonored := countBlocksHonored(edges, ridToIdx, parent)
	conflictsFixed := countConflictsFixed(rows, parent)

	pairsFound := countPairsFound(expectedPairs, ridToIdx, parent)
	pairsExpected := len(expectedPairs)
	recall := 1.0
	if pairsExpected > 0 {
		recall = round4(float64(pairsFound) / float64(pairsExpected))
	}

	return ScenarioResult{
		Name:           name,
		RecordsIn:      len(rows),
		LinksIn:        len(edges),
		Quarantined:    quarantined,
		Identities:     len(components),
		PairsExpected:  pairsExpected,
		PairsFound:     pairsFound,
		MappingRecall:  recall,
		Components:     components,
		DeferredPairs:  deferred,
		BlocksHonored:  blocksHonored,
		ConflictsFixed: conflictsFixed,
	}, nil
}

func aliasFold(row record.Row) []string {
	seen := map[string]struct{}{}
	var out []string
	add := func(s string) {
		s = strings.TrimSpace(s)
		if s == "" {
			return
		}
		f := strings.ToLower(s)
		if _, ok := seen[f]; ok {
			return
		}
		seen[f] = struct{}{}
		out = append(out, f)
	}
	add(row.Display)
	for _, n := range row.PriorNames {
		add(n)
	}
	return out
}

func nameAffinityPair(a, b []string) float64 {
	best := 0.0
	for _, left := range a {
		for _, right := range b {
			if v := meshcore.NameAffinity(left, right); v > best {
				best = v
			}
		}
	}
	return best
}

func laneCode(lane string) uint8 {
	switch lane {
	case "strong":
		return meshcore.TagStrong
	case "weak":
		return meshcore.TagWeak
	case "block":
		return meshcore.TagBlock
	case "pending":
		return meshcore.TagPending
	default:
		return 255
	}
}

func collectDeferred(edges []record.Edge, ridToIdx map[string]int, parent []uint32) [][]string {
	var out [][]string
	for _, edge := range edges {
		if !lanepick.SpC(edge.Lane) {
			continue
		}
		left, okL := ridToIdx[edge.Left]
		right, okR := ridToIdx[edge.Right]
		if !okL || !okR {
			continue
		}
		if parent[left] == parent[right] {
			continue
		}
		out = append(out, sortPair(edge.Left, edge.Right))
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i][0] != out[j][0] {
			return out[i][0] < out[j][0]
		}
		return out[i][1] < out[j][1]
	})
	return out
}

func countBlocksHonored(edges []record.Edge, ridToIdx map[string]int, parent []uint32) int {
	honored := 0
	for _, edge := range edges {
		if !lanepick.SpB(edge.Lane) {
			continue
		}
		left, okL := ridToIdx[edge.Left]
		right, okR := ridToIdx[edge.Right]
		if !okL || !okR {
			continue
		}
		if parent[left] != parent[right] {
			honored++
		}
	}
	return honored
}

func countConflictsFixed(rows []record.Row, parent []uint32) int {
	type group struct {
		rows []int
	}
	byRoot := map[uint32]*group{}
	for i := range rows {
		r := parent[i]
		if byRoot[r] == nil {
			byRoot[r] = &group{}
		}
		byRoot[r].rows = append(byRoot[r].rows, i)
	}
	fixed := 0
	for _, g := range byRoot {
		if len(g.rows) < 2 {
			continue
		}
		emails := map[string]struct{}{}
		for _, idx := range g.rows {
			e := meshcore.FoldEmail(rows[idx].Email)
			if e != "" {
				emails[e] = struct{}{}
			}
		}
		if len(emails) > 1 {
			fixed++
		}
	}
	return fixed
}

func countPairsFound(pairs [][]string, ridToIdx map[string]int, parent []uint32) int {
	found := 0
	for _, pair := range pairs {
		left, okL := ridToIdx[pair[0]]
		right, okR := ridToIdx[pair[1]]
		if !okL || !okR {
			continue
		}
		if parent[left] == parent[right] {
			found++
		}
	}
	return found
}

func sortPair(a, b string) []string {
	if a < b {
		return []string{a, b}
	}
	return []string{b, a}
}

func round4(v float64) float64 {
	return float64(int(v*10000+0.5)) / 10000
}
