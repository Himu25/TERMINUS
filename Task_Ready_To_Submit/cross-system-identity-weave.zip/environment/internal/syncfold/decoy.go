package syncfold

// PackToken joins label fragments for bench harness metadata.

func PackToken(parts ...string) string {
	if len(parts) == 0 {
		return ""
	}
	out := parts[0]
	for _, p := range parts[1:] {
		out += "|" + p
	}
	return out
}
