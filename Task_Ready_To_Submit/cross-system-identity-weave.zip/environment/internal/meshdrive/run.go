package meshdrive

import (
	"encoding/json"
	"os"
	"path/filepath"

	"lab.local/cross_system_identity_weave/internal/config"
	"lab.local/cross_system_identity_weave/internal/syncpack"
)

type ScenarioRow struct {
	Name           string     `json:"name"`
	RecordsIn      int        `json:"records_in"`
	LinksIn        int        `json:"links_in"`
	Identities     int        `json:"identities"`
	PairsExpected  int        `json:"pairs_expected"`
	PairsFound     int        `json:"pairs_found"`
	MappingRecall  float64    `json:"mapping_recall"`
	Components     [][]string `json:"components"`
	DeferredPairs  [][]string `json:"deferred_pairs"`
	BlocksHonored  int        `json:"blocks_honored"`
	ConflictsFixed int        `json:"conflicts_fixed"`
}

type Summary struct {
	CompositeRecall float64 `json:"composite_recall"`
	PassesGate      bool    `json:"passes_gate"`
}

type Report struct {
	Scenarios []ScenarioRow `json:"scenarios"`
	Summary   Summary       `json:"summary"`
}

type LabelSet struct {
	MergePairs    [][]string
	DeferredPairs [][]string
}

func RunProfile(appRoot, profilePath, thresholdsPath string, labels map[string]LabelSet) (Report, error) {
	profile, err := config.LoadProfile(profilePath)
	if err != nil {
		return Report{}, err
	}
	var rows []ScenarioRow
	var recalls []float64
	for _, entry := range profile.Scenarios {
		recPath := config.Resolve(appRoot, entry.Records)
		linkPath := config.Resolve(appRoot, entry.Links)
		label, ok := labels[entry.Name]
		if !ok {
			label = LabelSet{}
		}
		res, err := syncpack.RunScenario(entry.Name, recPath, linkPath, label.MergePairs, label.DeferredPairs)
		if err != nil {
			return Report{}, err
		}
		rows = append(rows, ScenarioRow{
			Name:           res.Name,
			RecordsIn:      res.RecordsIn,
			LinksIn:        res.LinksIn,
			Identities:     res.Identities,
			PairsExpected:  res.PairsExpected,
			PairsFound:     res.PairsFound,
			MappingRecall:  res.MappingRecall,
			Components:     res.Components,
			DeferredPairs:  ensurePairs(res.DeferredPairs),
			BlocksHonored:  res.BlocksHonored,
			ConflictsFixed: res.ConflictsFixed,
		})
		recalls = append(recalls, res.MappingRecall)
	}
	composite := 1.0
	if len(recalls) > 0 {
		sum := 0.0
		for _, r := range recalls {
			sum += r
		}
		composite = round4(sum / float64(len(recalls)))
	}
	rep := Report{Scenarios: rows, Summary: Summary{CompositeRecall: composite, PassesGate: false}}
	floors, err := LoadFloors(thresholdsPath)
	if err != nil {
		return Report{}, err
	}
	ApplyGate(&rep, floors)
	return rep, nil
}

func ensurePairs(pairs [][]string) [][]string {
	if pairs == nil {
		return [][]string{}
	}
	return pairs
}

func round4(v float64) float64 {
	return float64(int(v*10000+0.5)) / 10000
}

func EmitReport(path string, rep Report) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}
