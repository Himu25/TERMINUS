package meshdrive

import (
	"encoding/json"
	"os"
)

func LoadLabels(path string) (map[string]LabelSet, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var wire map[string]struct {
		MergePairs    [][]string `json:"merge_pairs"`
		DeferredPairs [][]string `json:"deferred_pairs"`
	}
	if err := json.Unmarshal(raw, &wire); err != nil {
		return nil, err
	}
	out := make(map[string]LabelSet, len(wire))
	for name, v := range wire {
		out[name] = LabelSet{MergePairs: v.MergePairs, DeferredPairs: v.DeferredPairs}
	}
	return out, nil
}
