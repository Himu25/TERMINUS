package meshdrive

import (
	"bufio"
	"os"
	"strconv"
	"strings"
)

type Floors struct {
	Scenario map[string]float64
	Composite float64
}

func LoadFloors(path string) (Floors, error) {
	f, err := os.Open(path)
	if err != nil {
		return Floors{}, err
	}
	defer f.Close()
	out := Floors{Scenario: map[string]float64{}}
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "[") {
			continue
		}
		parts := strings.SplitN(line, "=", 2)
		if len(parts) != 2 {
			continue
		}
		key := strings.TrimSpace(parts[0])
		val, err := strconv.ParseFloat(strings.TrimSpace(parts[1]), 64)
		if err != nil {
			continue
		}
		if key == "composite_recall" {
			out.Composite = val
		} else {
			out.Scenario[key] = val
		}
	}
	return out, sc.Err()
}

func ApplyGate(rep *Report, floors Floors) {
	ok := true
	if floors.Composite > 0 && rep.Summary.CompositeRecall < floors.Composite {
		ok = false
	}
	for i := range rep.Scenarios {
		row := &rep.Scenarios[i]
		if floor, exists := floors.Scenario[row.Name]; exists && row.MappingRecall < floor {
			ok = false
		}
	}
	rep.Summary.PassesGate = ok
}
