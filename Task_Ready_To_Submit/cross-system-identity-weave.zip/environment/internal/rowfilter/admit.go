package rowfilter

import "strings"

func Admit(rid, source, email string) bool {
	return strings.TrimSpace(rid) != "" || strings.TrimSpace(email) != ""
}
