package feeder

import "lab.local/cross_system_identity_weave/pkg/record"

func WalkTargets(rows []record.Row) []record.Row {
	out := make([]record.Row, len(rows))
	copy(out, rows)
	byRID := map[string]int{}
	for i, row := range out {
		byRID[row.RID] = i
	}
	for i := range out {
		target := out[i].MergedInto
		if target == "" {
			continue
		}
		if j, ok := byRID[target]; ok {
			out[i].Email = out[j].Email
			out[i].Display = out[j].Display
			out[i].ExtKey = out[j].ExtKey
		}
	}
	return out
}
