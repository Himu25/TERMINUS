package feeder

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"strings"

	"lab.local/cross_system_identity_weave/internal/rowfilter"
	"lab.local/cross_system_identity_weave/pkg/record"
)

func LoadRecords(path string) ([]record.Row, int, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, 0, err
	}
	defer f.Close()

	var rows []record.Row
	quarantined := 0
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		var row record.Row
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			quarantined++
			continue
		}
		if !rowfilter.Admit(row.RID, row.Source, row.Email) {
			quarantined++
			continue
		}
		rows = append(rows, row)
	}
	if err := sc.Err(); err != nil {
		return nil, 0, err
	}
	rows = WalkTargets(rows)
	return rows, quarantined, nil
}

func LoadEdges(path string) ([]record.Edge, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	var edges []record.Edge
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		var edge record.Edge
		if err := json.Unmarshal([]byte(line), &edge); err != nil {
			return nil, fmt.Errorf("edge parse: %w", err)
		}
		edges = append(edges, edge)
	}
	return edges, sc.Err()
}
