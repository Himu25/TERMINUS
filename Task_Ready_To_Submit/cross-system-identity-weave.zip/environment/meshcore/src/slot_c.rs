pub const LANE_STRONG: u8 = 0;
pub const LANE_WEAK: u8 = 1;
pub const LANE_BLOCK: u8 = 2;
pub const LANE_PENDING: u8 = 3;

#[derive(Clone, Copy)]
pub struct CgEdge {
    pub left: u32,
    pub right: u32,
    pub lane: u8,
}

pub fn phase_z(node_count: u32, edges: &[CgEdge]) -> Vec<u32> {
    let mut parent: Vec<u32> = (0..node_count).collect();
    for edge in edges {
        if edge.lane == LANE_BLOCK || edge.lane == LANE_PENDING {
            continue;
        }
        let a = edge.left as usize;
        let b = edge.right as usize;
        if a < parent.len() && b < parent.len() {
            parent[b] = parent[a];
        }
    }
    parent
}

#[no_mangle]
pub extern "C" fn cg_phase_z(
    node_count: u32,
    edges_ptr: *const CgEdge,
    edge_count: u32,
    out_parent: *mut u32,
) {
    if edges_ptr.is_null() || out_parent.is_null() || node_count == 0 {
        return;
    }
    let edges = unsafe { std::slice::from_raw_parts(edges_ptr, edge_count as usize) };
    let parent = phase_z(node_count, edges);
    unsafe {
        std::ptr::copy_nonoverlapping(parent.as_ptr(), out_parent, parent.len());
    }
}
