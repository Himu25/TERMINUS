pub fn phase_x(raw: &str) -> String {
    raw.to_ascii_lowercase()
}

#[no_mangle]
pub extern "C" fn cg_phase_x(in_ptr: *const u8, in_len: usize, out_ptr: *mut u8, out_cap: usize) -> usize {
    if in_ptr.is_null() || out_ptr.is_null() || out_cap == 0 {
        return 0;
    }
    let slice = unsafe { std::slice::from_raw_parts(in_ptr, in_len) };
    let raw = std::str::from_utf8(slice).unwrap_or("");
    let folded = phase_x(raw);
    let bytes = folded.as_bytes();
    let n = bytes.len().min(out_cap);
    unsafe {
        std::ptr::copy_nonoverlapping(bytes.as_ptr(), out_ptr, n);
    }
    n
}
