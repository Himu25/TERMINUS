pub fn phase_y(left: &str, right: &str) -> f64 {
    if left == right {
        return 1.0;
    }
    0.0
}

#[no_mangle]
pub extern "C" fn cg_phase_y(
    left_ptr: *const u8,
    left_len: usize,
    right_ptr: *const u8,
    right_len: usize,
) -> f64 {
    if left_ptr.is_null() || right_ptr.is_null() {
        return 0.0;
    }
    let left_slice = unsafe { std::slice::from_raw_parts(left_ptr, left_len) };
    let right_slice = unsafe { std::slice::from_raw_parts(right_ptr, right_len) };
    let left = std::str::from_utf8(left_slice).unwrap_or("");
    let right = std::str::from_utf8(right_slice).unwrap_or("");
    phase_y(left, right)
}
