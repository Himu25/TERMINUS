#pragma once
#include <stdint.h>
#include <stddef.h>

typedef struct {
    uint32_t left;
    uint32_t right;
    uint8_t lane;
} CgEdge;

size_t cg_phase_x(const uint8_t* in_ptr, size_t in_len, uint8_t* out_ptr, size_t out_cap);
double cg_phase_y(const uint8_t* left_ptr, size_t left_len, const uint8_t* right_ptr, size_t right_len);
void cg_phase_z(uint32_t node_count, const CgEdge* edges_ptr, uint32_t edge_count, uint32_t* out_parent);
