package meshcore

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libmeshcore.a -ldl -lm
#include "mesh_gate.h"
*/
import "C"
import "unsafe"

const (
	TagStrong  = 0
	TagWeak    = 1
	TagBlock   = 2
	TagPending = 3
)

type Edge struct {
	Left  uint32
	Right uint32
	Tag   uint8
}

func FoldEmail(raw string) string {
	if raw == "" {
		return ""
	}
	in := []byte(raw)
	out := make([]byte, len(in)*4+64)
	n := C.cg_phase_x(
		(*C.uint8_t)(unsafe.Pointer(&in[0])),
		C.size_t(len(in)),
		(*C.uint8_t)(unsafe.Pointer(&out[0])),
		C.size_t(len(out)),
	)
	return string(out[:int(n)])
}

func NameAffinity(left, right string) float64 {
	lb := []byte(left)
	rb := []byte(right)
	if len(lb) == 0 || len(rb) == 0 {
		return 0
	}
	return float64(C.cg_phase_y(
		(*C.uint8_t)(unsafe.Pointer(&lb[0])),
		C.size_t(len(lb)),
		(*C.uint8_t)(unsafe.Pointer(&rb[0])),
		C.size_t(len(rb)),
	))
}

func KnitClusters(nodeCount int, edges []Edge) []uint32 {
	if nodeCount <= 0 {
		return nil
	}
	cEdges := make([]C.CgEdge, len(edges))
	for i, e := range edges {
		cEdges[i] = C.CgEdge{
			left:  C.uint32_t(e.Left),
			right: C.uint32_t(e.Right),
			lane:  C.uint8_t(e.Tag),
		}
	}
	out := make([]uint32, nodeCount)
	var edgePtr *C.CgEdge
	if len(cEdges) > 0 {
		edgePtr = &cEdges[0]
	}
	C.cg_phase_z(
		C.uint32_t(nodeCount),
		edgePtr,
		C.uint32_t(len(cEdges)),
		(*C.uint32_t)(unsafe.Pointer(&out[0])),
	)
	return out
}
