# Data contract

## Input records

Each `records.jsonl` row carries `rid`, `source`, `email`, `display`, `ext_key`, `merged_into`,
`prior_names`, and `kind`. Optional `links.jsonl` rows name explicit `left`, `right`, and `lane`
values (`strong`, `weak`, `block`, `pending`).

## Weave report (`/app/output/weave_report.json`)

`scenarios` lists rows in bench-profile order. Each scenario row exposes:

- `name` — scenario stem from the active profile.
- `records_in` — admitted record rows for the scenario (blank `rid` or `source` rows must not count).
- `links_in` — explicit link rows consumed.
- `identities` — count of unified identity components after knitting.
- `pairs_expected` / `pairs_found` — mapping label pairs expected vs recovered.
- `mapping_recall` — pairs_found / pairs_expected when expected is positive.
- `components` — every unified identity as a sorted list of `rid` values.
- `deferred_pairs` — sorted `[left, right]` pairs for pending-lane links that must not share an identity.
- `blocks_honored` — block-lane links whose endpoints ended in different identities.
- `conflicts_fixed` — identities with more than one distinct folded email after knitting.

`summary` carries:

- `composite_recall` — unweighted mean of scenario `mapping_recall` values (four-decimal rounding).
- `passes_gate` — false unless every scenario recall and `composite_recall` meet floors in `/app/config/thresholds.toml`.

Label scoring may honor an overlay registry when the harness `WEAVE_LABELS_PATH` environment variable points at `/app/registry/staging_mapping_labels.json`.
