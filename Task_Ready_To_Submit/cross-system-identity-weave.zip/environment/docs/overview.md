# Cross-source weave service

Nightly exports from CRM, billing, analytics, support, and marketing land under `/app/data`.
The weave audit binary folds emails, walks account-merge pointers, and knits cross-system
components before writing `/app/output/weave_report.json`.
