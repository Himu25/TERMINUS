"""Verifier for fuzzy-entity-graph."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "graph_report.json"
HARNESS = APP / "tools" / "graph_harness"
PROFILE = APP / "config" / "bench_profiles.json"
THRESHOLDS = APP / "config" / "thresholds.toml"
REGISTRY_LABELS = APP / "registry" / "pair_labels.json"
STAGING_LABELS = APP / "registry" / "staging_pair_labels.json"
FIXTURES = Path("/tests/fixtures")

ADJUDICATION: dict[str, dict[str, list[list[str]]]] = {
    "clean_anchor": {
        "merge_pairs": [["c01", "c02"], ["c03", "c04"]],
        "uncertain_pairs": [],
    },
    "transitive_person": {
        "merge_pairs": [["t01", "t02"], ["t02", "t03"]],
        "uncertain_pairs": [],
    },
    "company_ocr": {
        "merge_pairs": [["o01", "o02"], ["o02", "o03"]],
        "uncertain_pairs": [],
    },
    "block_split": {
        "merge_pairs": [["b01", "b02"]],
        "uncertain_pairs": [],
    },
    "locale_mix": {
        "merge_pairs": [["m01", "m02"], ["m02", "m03"]],
        "uncertain_pairs": [],
    },
    "unicode_form": {
        "merge_pairs": [["n01", "n02"]],
        "uncertain_pairs": [],
    },
    "pending_hold": {
        "merge_pairs": [["p01", "p03"]],
        "uncertain_pairs": [["p01", "p02"]],
    },
    "conflict_tax": {
        "merge_pairs": [["x01", "x03"]],
        "uncertain_pairs": [],
    },
    "cross_kind": {
        "merge_pairs": [["k01", "k03"]],
        "uncertain_pairs": [],
    },
    "corrupt_mix": {
        "merge_pairs": [["r04", "r05"]],
        "uncertain_pairs": [],
    },
    "five_link": {
        "merge_pairs": [["f01", "f02"], ["f02", "f03"], ["f03", "f04"]],
        "uncertain_pairs": [],
    },
    "stress_bulk": {
        "merge_pairs": [
            ["s01a", "s01b"],
            ["s02a", "s02b"],
            ["s03a", "s03b"],
            ["s04a", "s04b"],
            ["s05a", "s05b"],
            ["s06a", "s06b"],
            ["s07a", "s07b"],
            ["s08a", "s08b"],
            ["s09a", "s09b"],
            ["s10a", "s10b"],
            ["s11a", "s11b"],
            ["s12a", "s12b"],
            ["s13a", "s13b"],
            ["s14a", "s14b"],
            ["s15a", "s15b"],
            ["s16a", "s16b"],
            ["s17a", "s17b"],
            ["s18a", "s18b"],
            ["s19a", "s19b"],
            ["s20a", "s20b"],
        ],
        "uncertain_pairs": [],
    },
}

EXPECTED_COMPONENTS: dict[str, list[list[str]]] = {
    "clean_anchor": [["c01", "c02"], ["c03", "c04"]],
    "transitive_person": [["t01", "t02", "t03"], ["t04"]],
    "company_ocr": [["o01", "o02", "o03"], ["o04"]],
    "block_split": [["b01", "b02"], ["b03"]],
    "locale_mix": [["m01", "m02", "m03"]],
    "unicode_form": [["n01", "n02"], ["n03"]],
    "pending_hold": [["p01", "p03"], ["p02"]],
    "conflict_tax": [["x01", "x03"], ["x02"]],
    "cross_kind": [["k01", "k03"], ["k02"]],
    "corrupt_mix": [["r01"], ["r04", "r05"]],
    "five_link": [["f01", "f02", "f03", "f04"], ["f05"]],
}

EXPECTED_BLOCKS: dict[str, int] = {
    "block_split": 1,
    "conflict_tax": 0,
}

REPORT_KEYS = frozenset({"scenarios", "summary"})
SCENARIO_KEYS = frozenset(
    {
        "name",
        "nodes_in",
        "edges_in",
        "clusters",
        "pairs_expected",
        "pairs_found",
        "pair_recall",
        "components",
        "uncertain_pairs",
        "blocks_honored",
    }
)
SUMMARY_KEYS = frozenset({"composite_recall", "passes_gate"})


def _parse_thresholds(path: Path) -> dict[str, float]:
    floors: dict[str, float] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.split("#", 1)[0].strip()
        if not stripped or "=" not in stripped:
            continue
        key, raw = stripped.split("=", 1)
        floors[key.strip()] = float(raw.strip())
    return floors


_FLOOR_DATA = _parse_thresholds(THRESHOLDS)
COMPOSITE_FLOOR = _FLOOR_DATA["composite_recall_min"]

SCENARIO_FLOOR_KEYS = {
    "clean_anchor": "clean_recall_min",
    "transitive_person": "transitive_recall_min",
    "company_ocr": "ocr_recall_min",
    "block_split": "block_recall_min",
    "locale_mix": "locale_recall_min",
    "unicode_form": "unicode_form_recall_min",
    "pending_hold": "pending_recall_min",
    "conflict_tax": "conflict_recall_min",
    "cross_kind": "cross_kind_recall_min",
    "corrupt_mix": "corrupt_recall_min",
    "five_link": "five_link_recall_min",
    "stress_bulk": "bulk_recall_min",
}


def _profile_scenario_paths(profile_path: Path) -> dict[str, dict[str, Path]]:
    profile = json.loads(profile_path.read_text(encoding="utf-8"))
    out: dict[str, dict[str, Path]] = {}
    for entry in profile["scenarios"]:
        out[entry["name"]] = {
            "nodes": APP / entry["nodes"],
            "edges": APP / entry["edges"],
        }
    return out


def _profile_scenario_order(profile_path: Path) -> list[str]:
    profile = json.loads(profile_path.read_text(encoding="utf-8"))
    return [entry["name"] for entry in profile["scenarios"]]


def _count_valid_nodes(nodes_path: Path) -> int:
    count = 0
    for line in nodes_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        try:
            row = json.loads(stripped)
        except json.JSONDecodeError:
            continue
        if not str(row.get("id", "")).strip():
            continue
        if not str(row.get("label", "")).strip():
            continue
        if not str(row.get("kind", "")).strip():
            continue
        count += 1
    return count


def _normalize_components(components: list[list[str]]) -> list[list[str]]:
    return sorted([sorted(group) for group in components])


def _ids_in_components(components: list[list[str]]) -> set[str]:
    seen: set[str] = set()
    for group in components:
        for node_id in group:
            assert node_id not in seen, f"duplicate id {node_id} in components"
            seen.add(node_id)
    return seen


def _pairs_satisfied(components: list[list[str]], pairs: list[list[str]]) -> int:
    parent: dict[str, str] = {}

    def find(node: str) -> str:
        parent.setdefault(node, node)
        while parent[node] != node:
            parent[node] = parent[parent[node]]
            node = parent[node]
        return node

    def merge(left: str, right: str) -> None:
        root_left = find(left)
        root_right = find(right)
        if root_left != root_right:
            parent[root_right] = root_left

    for group in components:
        if not group:
            continue
        anchor = group[0]
        for member in group[1:]:
            merge(anchor, member)

    found = 0
    for left, right in pairs:
        if find(left) == find(right):
            found += 1
    return found


def _normalize_pairs(pairs: list[list[str]]) -> list[list[str]]:
    out: list[list[str]] = []
    for left, right in pairs:
        if left <= right:
            out.append([left, right])
        else:
            out.append([right, left])
    out.sort()
    return out


def _run_harness(profile: Path | None = None) -> None:
    _stage_adjudication_registry()
    cmd = [str(HARNESS)]
    if profile is not None:
        cmd.append(str(profile))
    env = os.environ.copy()
    env["GRAPH_LABELS_PATH"] = str(STAGING_LABELS)
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False, env=env)
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "graph_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


def _scenario_map(report: dict) -> dict[str, dict]:
    return {row["name"]: row for row in report["scenarios"]}


def _round4(value: float) -> float:
    return float(f"{value:.4f}")


_PROFILE_PATHS = _profile_scenario_paths(PROFILE)
_PROFILE_ORDER = _profile_scenario_order(PROFILE)


def _stage_adjudication_registry() -> None:
    payload = json.dumps(ADJUDICATION, indent=2) + "\n"
    STAGING_LABELS.write_text(payload, encoding="utf-8")
    try:
        REGISTRY_LABELS.parent.mkdir(parents=True, exist_ok=True)
        REGISTRY_LABELS.write_text(payload, encoding="utf-8")
    except OSError:
        pass


@pytest.fixture(scope="session", autouse=True)
def adjudication_registry() -> None:
    _stage_adjudication_registry()


@pytest.fixture(scope="module")
def default_report(adjudication_registry: None) -> dict:
    _run_harness(PROFILE)
    return _load_report()


def _assert_scenario_shape(report: dict, name: str) -> dict:
    row = _scenario_map(report)[name]
    assert SCENARIO_KEYS.issubset(row.keys())
    expected_nodes = _count_valid_nodes(_PROFILE_PATHS[name]["nodes"])
    merge_pairs = ADJUDICATION[name]["merge_pairs"]
    expected_pairs = len(merge_pairs)
    if name in EXPECTED_COMPONENTS:
        expected_clusters = len(EXPECTED_COMPONENTS[name])
    else:
        expected_clusters = expected_nodes - expected_pairs
    assert row["nodes_in"] == expected_nodes
    assert row["clusters"] == expected_clusters
    satisfied = _pairs_satisfied(row["components"], merge_pairs)
    assert satisfied == expected_pairs
    recall_from_components = (
        1.0 if expected_pairs == 0 else _round4(satisfied / expected_pairs)
    )
    floor = _FLOOR_DATA[SCENARIO_FLOOR_KEYS[name]]
    assert recall_from_components >= floor
    assert row["pair_recall"] == recall_from_components
    if name in EXPECTED_COMPONENTS:
        assert _normalize_components(row["components"]) == _normalize_components(
            EXPECTED_COMPONENTS[name]
        )
    expected_uncertain = _normalize_pairs(ADJUDICATION[name]["uncertain_pairs"])
    assert _normalize_pairs(row["uncertain_pairs"]) == expected_uncertain
    if name in EXPECTED_BLOCKS:
        assert row["blocks_honored"] == EXPECTED_BLOCKS[name]
    admitted = _ids_in_components(row["components"])
    assert len(admitted) == row["nodes_in"]
    return row


def test_report_top_level_shape(default_report: dict) -> None:
    """Report exposes scenarios and summary blocks with required keys."""
    assert REPORT_KEYS.issubset(default_report.keys())
    assert SUMMARY_KEYS.issubset(default_report["summary"].keys())


def test_clean_anchor_recall(default_report: dict) -> None:
    """Clean anchor scenario merges every labeled pair."""
    _assert_scenario_shape(default_report, "clean_anchor")


def test_transitive_person_chain(default_report: dict) -> None:
    """Multi-hop alias chain collapses into one component."""
    _assert_scenario_shape(default_report, "transitive_person")


def test_company_ocr_fuzzy_org(default_report: dict) -> None:
    """OCR-skewed org labels merge under a shared anchor key."""
    _assert_scenario_shape(default_report, "company_ocr")


def test_block_split_honors_block_lane(default_report: dict) -> None:
    """Block-lane signal keeps conflicting endpoints in separate components."""
    _assert_scenario_shape(default_report, "block_split")


def test_locale_mix_multilingual(default_report: dict) -> None:
    """Mixed-locale spellings collapse when anchors align."""
    _assert_scenario_shape(default_report, "locale_mix")


def test_unicode_form_composed_decomposed(default_report: dict) -> None:
    """Composed and decomposed Unicode spellings merge under one anchor."""
    _assert_scenario_shape(default_report, "unicode_form")


def test_pending_hold_uncertain_pairs(default_report: dict) -> None:
    """Pending-lane edges stay in uncertain_pairs without merging."""
    _assert_scenario_shape(default_report, "pending_hold")


def test_conflict_tax_anchor_split(default_report: dict) -> None:
    """Same display label with diverging anchor keys stays split."""
    _assert_scenario_shape(default_report, "conflict_tax")


def test_cross_kind_no_fuzzy_across_kind(default_report: dict) -> None:
    """Org and person records with similar labels do not cross-merge."""
    _assert_scenario_shape(default_report, "cross_kind")


def test_corrupt_mix_admission(default_report: dict) -> None:
    """Malformed node rows are excluded from nodes_in totals."""
    _assert_scenario_shape(default_report, "corrupt_mix")


def test_five_link_transitive(default_report: dict) -> None:
    """Four-hop chain collapses to one component plus an isolated node."""
    _assert_scenario_shape(default_report, "five_link")


def test_stress_bulk_recall(default_report: dict) -> None:
    """Bulk scenario recovers every labeled pair."""
    _assert_scenario_shape(default_report, "stress_bulk")


def test_profile_order_matches_config(default_report: dict) -> None:
    """Scenario rows appear in profile order."""
    names = [row["name"] for row in default_report["scenarios"]]
    assert names == _PROFILE_ORDER


def test_composite_recall_matches_mean(default_report: dict) -> None:
    """Summary composite recall equals the unweighted mean of scenario recalls."""
    recalls = [row["pair_recall"] for row in default_report["scenarios"]]
    expected = _round4(sum(recalls) / len(recalls))
    assert default_report["summary"]["composite_recall"] == expected


def test_passes_gate_iff_all_floors_hold(default_report: dict) -> None:
    """passes_gate is true exactly when every scenario clears its floor."""
    summary = default_report["summary"]
    all_clear = all(
        row["pair_recall"] >= _FLOOR_DATA[SCENARIO_FLOOR_KEYS[row["name"]]]
        for row in default_report["scenarios"]
    )
    assert summary["passes_gate"] is all_clear
    assert summary["passes_gate"] is True
    assert summary["composite_recall"] >= COMPOSITE_FLOOR


def test_deterministic_report_bytes(default_report: dict) -> None:
    """Back-to-back default-profile runs are byte-identical."""
    first = OUT.read_bytes()
    _run_harness(PROFILE)
    second = OUT.read_bytes()
    assert first == second


def test_registry_tamper_resistance() -> None:
    """Harness scoring ignores registry tampering when staging labels differ."""
    _run_harness(PROFILE)
    baseline = _load_report()
    tampered = {"fake": {"merge_pairs": [["z99", "z98"]], "uncertain_pairs": []}}
    REGISTRY_LABELS.write_text(json.dumps(tampered) + "\n", encoding="utf-8")
    _run_harness(PROFILE)
    after = _load_report()
    assert after == baseline


def test_alternate_profile_fixture() -> None:
    """Alternate bench profile from fixtures produces expected scenario subset."""
    alt = FIXTURES / "profile_pending_only.json"
    assert alt.is_file()
    _run_harness(alt)
    report = _load_report()
    names = [row["name"] for row in report["scenarios"]]
    assert names == ["pending_hold"]
    _assert_scenario_shape(report, "pending_hold")
