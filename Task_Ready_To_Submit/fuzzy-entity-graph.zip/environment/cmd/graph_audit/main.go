// Outward report written to /app/output/graph_report.json.
//
// scenarios — array of per-scenario rows in profile order
// name — scenario identifier
// nodes_in — admitted node count
// edges_in — explicit edge count from edges file
// clusters — component count after knitting
// pairs_expected — labeled merge pairs for the scenario
// pairs_found — labeled pairs satisfied in components
// pair_recall — pairs_found / pairs_expected (1.0 when pairs_expected is zero)
// components — sorted merge groups as sorted node-id lists
// uncertain_pairs — pending-lane pairs that must not share a component
// blocks_honored — block-lane edges whose endpoints landed in different components
// summary.composite_recall — unweighted mean of pair_recall (four-decimal rounding)
// summary.passes_gate — false until harness applies threshold floors
package main

import (
	"log"
	"os"

	"lab.local/fuzzy_entity_graph/internal/driver"
)

func main() {
	profile := "/app/config/bench_profiles.json"
	if len(os.Args) > 1 {
		profile = os.Args[1]
	}
	labelsPath := "/app/registry/pair_labels.json"
	if v := os.Getenv("GRAPH_LABELS_PATH"); v != "" {
		labelsPath = v
	}
	labels, err := driver.LoadLabels(labelsPath)
	if err != nil {
		log.Fatal(err)
	}
	rep, err := driver.RunProfile("/app", profile, "/app/config/thresholds.toml", labels)
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/graph_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
