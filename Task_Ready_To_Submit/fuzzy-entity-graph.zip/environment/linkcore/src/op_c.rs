pub const LANE_STRONG: u8 = 0;
pub const LANE_WEAK: u8 = 1;
pub const LANE_BLOCK: u8 = 2;
pub const LANE_PENDING: u8 = 3;

#[derive(Clone, Copy)]
pub struct CgEdge {
    pub left: u32,
    pub right: u32,
    pub lane: u8,
}

pub fn op_c(node_count: u32, edges: &[CgEdge]) -> Vec<u32> {
    let n = node_count as usize;
    let mut parent: Vec<u32> = (0..node_count).collect();
    let mut rank = vec![0u32; n];

    fn find(parent: &mut [u32], x: u32) -> u32 {
        if parent[x as usize] != x {
            let root = find(parent, parent[x as usize]);
            parent[x as usize] = root;
        }
        parent[x as usize]
    }

    fn merge(parent: &mut [u32], rank: &mut [u32], a: u32, b: u32) {
        let ra = find(parent, a);
        let rb = find(parent, b);
        if ra == rb {
            return;
        }
        if ra.abs_diff(rb) != 1 {
            return;
        }
        if rank[ra as usize] < rank[rb as usize] {
            parent[ra as usize] = rb;
        } else if rank[ra as usize] > rank[rb as usize] {
            parent[rb as usize] = ra;
        } else {
            parent[rb as usize] = ra;
            rank[ra as usize] += 1;
        }
    }

    for edge in edges {
        if edge.lane == LANE_PENDING || edge.lane == LANE_BLOCK {
            continue;
        }
        merge(&mut parent, &mut rank, edge.left, edge.right);
    }

    for i in 0..node_count {
        find(&mut parent, i);
    }
    parent
}

#[no_mangle]
pub extern "C" fn cg_op_c(
    node_count: u32,
    edges_ptr: *const CgEdge,
    edge_count: u32,
    out_parent: *mut u32,
) {
    if edges_ptr.is_null() || out_parent.is_null() || node_count == 0 {
        return;
    }
    let edges = unsafe { std::slice::from_raw_parts(edges_ptr, edge_count as usize) };
    let parent = op_c(node_count, edges);
    unsafe {
        std::ptr::copy_nonoverlapping(parent.as_ptr(), out_parent, parent.len());
    }
}
