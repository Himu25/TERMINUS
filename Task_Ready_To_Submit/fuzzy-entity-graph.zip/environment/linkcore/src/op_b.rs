pub fn op_b(left: &str, right: &str) -> f64 {
    if left == right {
        1.0
    } else {
        0.0
    }
}

#[no_mangle]
pub extern "C" fn cg_op_b(
    left_ptr: *const u8,
    left_len: usize,
    right_ptr: *const u8,
    right_len: usize,
) -> f64 {
    if left_ptr.is_null() || right_ptr.is_null() {
        return 0.0;
    }
    let left_slice = unsafe { std::slice::from_raw_parts(left_ptr, left_len) };
    let right_slice = unsafe { std::slice::from_raw_parts(right_ptr, right_len) };
    let left = std::str::from_utf8(left_slice).unwrap_or("");
    let right = std::str::from_utf8(right_slice).unwrap_or("");
    op_b(left, right)
}
