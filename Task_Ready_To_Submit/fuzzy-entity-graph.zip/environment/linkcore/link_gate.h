#ifndef LINK_GATE_H
#define LINK_GATE_H

#include <stdint.h>

typedef struct {
    uint32_t left;
    uint32_t right;
    uint8_t lane;
} CgEdge;

size_t cg_op_a(const uint8_t *in_ptr, size_t in_len, uint8_t *out_ptr, size_t out_cap);
double cg_op_b(const uint8_t *left_ptr, size_t left_len, const uint8_t *right_ptr, size_t right_len);
void cg_op_c(uint32_t node_count, const CgEdge *edges, uint32_t edge_count, uint32_t *out_parent);

#endif
