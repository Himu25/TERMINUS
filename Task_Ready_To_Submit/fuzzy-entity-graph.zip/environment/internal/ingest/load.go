package ingest

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"strings"

	"lab.local/fuzzy_entity_graph/internal/rowgate"
	"lab.local/fuzzy_entity_graph/pkg/vertex"
)

func LoadNodes(path string) ([]vertex.Node, int, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, 0, err
	}
	defer f.Close()

	var nodes []vertex.Node
	quarantined := 0
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		var node vertex.Node
		if err := json.Unmarshal([]byte(line), &node); err != nil {
			quarantined++
			continue
		}
		if !rowgate.Admit(node.ID, node.Label, node.Kind) {
			quarantined++
			continue
		}
		nodes = append(nodes, node)
	}
	if err := sc.Err(); err != nil {
		return nil, 0, err
	}
	return nodes, quarantined, nil
}

func LoadEdges(path string) ([]vertex.Edge, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	var edges []vertex.Edge
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		var edge vertex.Edge
		if err := json.Unmarshal([]byte(line), &edge); err != nil {
			return nil, fmt.Errorf("edge parse: %w", err)
		}
		edges = append(edges, edge)
	}
	return edges, sc.Err()
}
