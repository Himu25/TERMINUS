package routetag

func KpOpen(tag string) bool {
	switch tag {
	case "strong", "weak", "pending":
		return true
	default:
		return false
	}
}

func KpShut(tag string) bool {
	return tag == "block"
}

func KpHold(tag string) bool {
	return tag == "pending"
}
