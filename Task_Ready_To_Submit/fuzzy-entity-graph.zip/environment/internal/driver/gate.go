package driver

import (
	"bufio"
	"os"
	"strconv"
	"strings"
)

var floorKeys = map[string]string{
	"clean_anchor":      "clean_recall_min",
	"transitive_person": "transitive_recall_min",
	"company_ocr":       "ocr_recall_min",
	"block_split":       "block_recall_min",
	"locale_mix":        "locale_recall_min",
	"pending_hold":      "pending_recall_min",
	"conflict_tax":      "conflict_recall_min",
	"cross_kind":        "cross_kind_recall_min",
	"corrupt_mix":       "corrupt_recall_min",
	"five_link":         "five_link_recall_min",
	"stress_bulk":       "bulk_recall_min",
}

func LoadFloors(path string) (map[string]float64, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	floors := map[string]float64{}
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line, _, _ := strings.Cut(sc.Text(), "#")
		line = strings.TrimSpace(line)
		if line == "" || !strings.Contains(line, "=") {
			continue
		}
		key, rawVal := strings.SplitN(line, "=", 2)[0], strings.SplitN(line, "=", 2)[1]
		key = strings.TrimSpace(key)
		rawVal = strings.TrimSpace(rawVal)
		val, err := strconv.ParseFloat(rawVal, 64)
		if err != nil {
			continue
		}
		floors[key] = val
	}
	return floors, sc.Err()
}

func ApplyGate(rep *Report, floors map[string]float64) {
	gate := true
	for i := range rep.Scenarios {
		row := &rep.Scenarios[i]
		key := floorKeys[row.Name]
		floor := 1.0
		if key != "" {
			if v, ok := floors[key]; ok {
				floor = v
			}
		}
		if row.PairRecall+1e-9 < floor {
			gate = false
		}
	}
	compositeFloor := floors["composite_recall_min"]
	if compositeFloor == 0 {
		compositeFloor = 1.0
	}
	if rep.Summary.CompositeRecall+1e-9 < compositeFloor {
		gate = false
	}
	rep.Summary.PassesGate = gate
}
