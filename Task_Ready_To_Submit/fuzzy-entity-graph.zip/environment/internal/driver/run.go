package driver

import (
	"encoding/json"
	"os"
	"path/filepath"

	"lab.local/fuzzy_entity_graph/internal/config"
	"lab.local/fuzzy_entity_graph/internal/syncfold"
)

type ScenarioRow struct {
	Name           string     `json:"name"`
	NodesIn        int        `json:"nodes_in"`
	EdgesIn        int        `json:"edges_in"`
	Clusters       int        `json:"clusters"`
	PairsExpected  int        `json:"pairs_expected"`
	PairsFound     int        `json:"pairs_found"`
	PairRecall     float64    `json:"pair_recall"`
	Components     [][]string `json:"components"`
	UncertainPairs [][]string `json:"uncertain_pairs"`
	BlocksHonored  int        `json:"blocks_honored"`
}

type Summary struct {
	CompositeRecall float64 `json:"composite_recall"`
	PassesGate      bool    `json:"passes_gate"`
}

type Report struct {
	Scenarios []ScenarioRow `json:"scenarios"`
	Summary   Summary       `json:"summary"`
}

func RunProfile(appRoot, profilePath, thresholdsPath string, labels map[string]LabelSet) (Report, error) {
	profile, err := config.LoadProfile(profilePath)
	if err != nil {
		return Report{}, err
	}
	var rows []ScenarioRow
	var recalls []float64
	for _, entry := range profile.Scenarios {
		nodesPath := config.Resolve(appRoot, entry.Nodes)
		edgesPath := config.Resolve(appRoot, entry.Edges)
		label, ok := labels[entry.Name]
		if !ok {
			label = LabelSet{}
		}
		res, err := syncfold.RunScenario(entry.Name, nodesPath, edgesPath, label.MergePairs, label.UncertainPairs)
		if err != nil {
			return Report{}, err
		}
		rows = append(rows, ScenarioRow{
			Name:           res.Name,
			NodesIn:        res.NodesIn,
			EdgesIn:        res.EdgesIn,
			Clusters:       res.Clusters,
			PairsExpected:  res.PairsExpected,
			PairsFound:     res.PairsFound,
			PairRecall:     res.PairRecall,
			Components:     res.Components,
			UncertainPairs: ensurePairs(res.UncertainPairs),
			BlocksHonored:  res.BlocksHonored,
		})
		recalls = append(recalls, res.PairRecall)
	}
	composite := 1.0
	if len(recalls) > 0 {
		sum := 0.0
		for _, r := range recalls {
			sum += r
		}
		composite = syncfoldRound(sum / float64(len(recalls)))
	}
	rep := Report{
		Scenarios: rows,
		Summary: Summary{
			CompositeRecall: composite,
			PassesGate:      false,
		},
	}
	floors, err := LoadFloors(thresholdsPath)
	if err != nil {
		return Report{}, err
	}
	ApplyGate(&rep, floors)
	return rep, nil
}

func syncfoldRound(v float64) float64 {
	return float64(int(v*10000+0.5)) / 10000
}

func ensurePairs(pairs [][]string) [][]string {
	if pairs == nil {
		return [][]string{}
	}
	return pairs
}

func EmitReport(path string, rep Report) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}

type LabelSet struct {
	MergePairs     [][]string
	UncertainPairs [][]string
}
