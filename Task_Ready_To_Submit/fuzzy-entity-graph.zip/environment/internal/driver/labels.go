package driver

import (
	"encoding/json"
	"os"
)

type rawLabelSet struct {
	MergePairs     [][]string `json:"merge_pairs"`
	UncertainPairs [][]string `json:"uncertain_pairs"`
}

func LoadLabels(path string) (map[string]LabelSet, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var parsed map[string]rawLabelSet
	if err := json.Unmarshal(raw, &parsed); err != nil {
		return nil, err
	}
	out := make(map[string]LabelSet, len(parsed))
	for name, entry := range parsed {
		out[name] = LabelSet{
			MergePairs:     entry.MergePairs,
			UncertainPairs: entry.UncertainPairs,
		}
	}
	return out, nil
}
