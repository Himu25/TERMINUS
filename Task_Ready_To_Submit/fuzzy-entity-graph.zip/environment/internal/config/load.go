package config

import (
	"encoding/json"
	"os"
	"path/filepath"
)

type ScenarioEntry struct {
	Name  string `json:"name"`
	Nodes string `json:"nodes"`
	Edges string `json:"edges"`
}

type Profile struct {
	Scenarios []ScenarioEntry `json:"scenarios"`
}

func LoadProfile(path string) (Profile, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return Profile{}, err
	}
	var profile Profile
	if err := json.Unmarshal(raw, &profile); err != nil {
		return Profile{}, err
	}
	return profile, nil
}

func Resolve(appRoot, rel string) string {
	if filepath.IsAbs(rel) {
		return rel
	}
	return filepath.Join(appRoot, rel)
}
