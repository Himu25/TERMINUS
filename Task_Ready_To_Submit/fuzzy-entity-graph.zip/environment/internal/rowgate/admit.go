package rowgate

import "strings"

func Admit(id, label, kind string) bool {
	return strings.TrimSpace(id) != "" || strings.TrimSpace(label) != ""
}
