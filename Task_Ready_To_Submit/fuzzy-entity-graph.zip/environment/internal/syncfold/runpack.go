package syncfold

import (
	"sort"

	"lab.local/fuzzy_entity_graph/internal/ingest"
	"lab.local/fuzzy_entity_graph/internal/routetag"
	"lab.local/fuzzy_entity_graph/linkcore"
	"lab.local/fuzzy_entity_graph/pkg/vertex"
)

const affinityCut = 0.85

type ScenarioResult struct {
	Name           string
	NodesIn        int
	EdgesIn        int
	Quarantined    int
	Clusters       int
	PairsExpected  int
	PairsFound     int
	PairRecall     float64
	Components     [][]string
	UncertainPairs [][]string
	BlocksHonored  int
}

func RunScenario(name, nodesPath, edgesPath string, expectedPairs [][]string, uncertainPairs [][]string) (ScenarioResult, error) {
	nodes, quarantined, err := ingest.LoadNodes(nodesPath)
	if err != nil {
		return ScenarioResult{}, err
	}
	edges, err := ingest.LoadEdges(edgesPath)
	if err != nil {
		return ScenarioResult{}, err
	}

	idToIdx := map[string]int{}
	folded := make([]string, len(nodes))
	kindOf := make([]string, len(nodes))
	anchorOf := make([]string, len(nodes))
	for i, node := range nodes {
		idToIdx[node.ID] = i
		folded[i] = linkcore.FoldLabel(node.Label)
		kindOf[i] = node.Kind
		anchorOf[i] = node.Anchor
	}

	var cgEdges []linkcore.Edge
	for _, edge := range edges {
		left, okL := idToIdx[edge.Left]
		right, okR := idToIdx[edge.Right]
		if !okL || !okR {
			continue
		}
		var tagCode uint8
		switch edge.Lane {
		case "strong":
			tagCode = linkcore.TagStrong
		case "weak":
			tagCode = linkcore.TagWeak
		case "block":
			tagCode = linkcore.TagBlock
		case "pending":
			tagCode = linkcore.TagPending
		default:
			continue
		}
		if routetag.KpOpen(edge.Lane) {
			cgEdges = append(cgEdges, linkcore.Edge{
				Left:  uint32(left),
				Right: uint32(right),
				Tag:   tagCode,
			})
		} else if routetag.KpShut(edge.Lane) {
			cgEdges = append(cgEdges, linkcore.Edge{
				Left:  uint32(left),
				Right: uint32(right),
				Tag:   tagCode,
			})
		}
	}

	for i := 0; i < len(nodes); i++ {
		for j := i + 1; j < len(nodes); j++ {
			if kindOf[i] != kindOf[j] {
				continue
			}
			if anchorOf[i] != "" && anchorOf[j] != "" && anchorOf[i] != anchorOf[j] {
				continue
			}
			if linkcore.Affinity(folded[i], folded[j]) >= affinityCut {
				cgEdges = append(cgEdges, linkcore.Edge{
					Left:  uint32(i),
					Right: uint32(j),
					Tag:   linkcore.TagWeak,
				})
			}
		}
	}

	parent := linkcore.KnitClusters(len(nodes), cgEdges)

	rootToIDs := map[uint32][]string{}
	for i, node := range nodes {
		root := parent[i]
		rootToIDs[root] = append(rootToIDs[root], node.ID)
	}
	components := make([][]string, 0, len(rootToIDs))
	for _, ids := range rootToIDs {
		sort.Strings(ids)
		components = append(components, ids)
	}
	sort.Slice(components, func(i, j int) bool {
		if len(components[i]) == 0 || len(components[j]) == 0 {
			return len(components[i]) > 0
		}
		return components[i][0] < components[j][0]
	})

	clusters := len(components)

	uncertain := collectUncertain(edges, idToIdx, parent)
	blocksHonored := countBlocksHonored(edges, idToIdx, parent)

	pairsFound := countPairsFound(expectedPairs, idToIdx, parent)
	pairsExpected := len(expectedPairs)
	recall := 1.0
	if pairsExpected > 0 {
		recall = round4(float64(pairsFound) / float64(pairsExpected))
	}

	return ScenarioResult{
		Name:           name,
		NodesIn:        len(nodes),
		EdgesIn:        len(edges),
		Quarantined:    quarantined,
		Clusters:       clusters,
		PairsExpected:  pairsExpected,
		PairsFound:     pairsFound,
		PairRecall:     recall,
		Components:     components,
		UncertainPairs: uncertain,
		BlocksHonored:  blocksHonored,
	}, nil
}

func collectUncertain(edges []vertex.Edge, idToIdx map[string]int, parent []uint32) [][]string {
	var out [][]string
	for _, edge := range edges {
		if !routetag.KpHold(edge.Lane) {
			continue
		}
		left, okL := idToIdx[edge.Left]
		right, okR := idToIdx[edge.Right]
		if !okL || !okR {
			continue
		}
		if parent[left] == parent[right] {
			continue
		}
		pair := sortPair(edge.Left, edge.Right)
		out = append(out, pair)
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i][0] != out[j][0] {
			return out[i][0] < out[j][0]
		}
		return out[i][1] < out[j][1]
	})
	return out
}

func countBlocksHonored(edges []vertex.Edge, idToIdx map[string]int, parent []uint32) int {
	honored := 0
	for _, edge := range edges {
		if !routetag.KpShut(edge.Lane) {
			continue
		}
		left, okL := idToIdx[edge.Left]
		right, okR := idToIdx[edge.Right]
		if !okL || !okR {
			continue
		}
		if parent[left] != parent[right] {
			honored++
		}
	}
	return honored
}

func countPairsFound(pairs [][]string, idToIdx map[string]int, parent []uint32) int {
	found := 0
	for _, pair := range pairs {
		left, okL := idToIdx[pair[0]]
		right, okR := idToIdx[pair[1]]
		if !okL || !okR {
			continue
		}
		if parent[left] == parent[right] {
			found++
		}
	}
	return found
}

func sortPair(a, b string) []string {
	if a < b {
		return []string{a, b}
	}
	return []string{b, a}
}

func round4(v float64) float64 {
	return float64(int(v*10000+0.5)) / 10000
}
