#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1

mkdir -p /app/bin
cd /app/linkcore
CARGO_TARGET_DIR=/app/linkcore/target cargo build --release --locked
cd /app
GOFLAGS=-mod=mod go build -trimpath -buildvcs=false -o /app/bin/graph_audit ./cmd/graph_audit
