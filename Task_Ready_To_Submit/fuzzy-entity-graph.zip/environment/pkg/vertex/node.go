package vertex

type Node struct {
	ID     string `json:"id"`
	Label  string `json:"label"`
	Kind   string `json:"kind"`
	Locale string `json:"locale"`
	Anchor string `json:"anchor"`
}

type Edge struct {
	Left  string `json:"left"`
	Right string `json:"right"`
	Lane  string `json:"lane"`
}
