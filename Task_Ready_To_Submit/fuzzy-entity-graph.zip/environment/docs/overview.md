# Graph consolidation pipeline

Offline benches read node and edge JSONL packs from `/app/data`, fold labels
through the Rust native helpers, knit components in Go syncfold, and emit
`/app/output/graph_report.json`.

Build with `/app/scripts/build.sh`. Default profile is
`/app/config/bench_profiles.json`.
