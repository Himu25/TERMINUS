Node rows are JSON objects with id, label, kind, locale, and anchor fields.
Edge rows carry left, right, and lane (strong, weak, block, pending).

Malformed rows must not affect nodes_in totals.

Pair-label registries default to `/app/registry/pair_labels.json`. Set
`GRAPH_LABELS_PATH` to override scoring labels; verification may stage an
overlay at `/app/registry/staging_pair_labels.json`.
