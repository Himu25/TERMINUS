module lab.local/fuzzy_entity_graph

go 1.22
