#!/bin/bash
set -euo pipefail

log_line() {
  printf '[oracle] %s\n' "$1"
}

require_file() {
  local p="$1"
  if [[ ! -f "$p" ]]; then
    log_line "missing expected file: $p"
    exit 1
  fi
}

rewrite_op_a() {
  log_line "rewriting op_a"
  require_file "/app/linkcore/src/op_a.rs"
  cat > /app/linkcore/src/op_a.rs <<'RUST'
pub fn op_a(raw: &str) -> String {
    use unicode_normalization::UnicodeNormalization;
    let nfc: String = raw.nfc().collect();
    let lower = nfc.to_lowercase();
    let mut out = String::with_capacity(lower.len());
    for ch in lower.chars() {
        out.push(map_glyph(ch));
    }
    strip_suffixes(&out)
}

fn strip_suffixes(raw: &str) -> String {
    let tokens: Vec<&str> = raw.split_whitespace().collect();
    let mut kept: Vec<&str> = Vec::new();
    for token in tokens {
        let core = token.trim_matches(|c: char| !c.is_alphanumeric());
        let lower = core.to_ascii_lowercase();
        if matches!(
            lower.as_str(),
            "inc" | "incorporated" | "corp" | "corporation" | "ltd" | "llc" | "co" | "gmbh"
        ) {
            continue;
        }
        kept.push(token);
    }
    if kept.is_empty() {
        raw.to_string()
    } else {
        kept.join(" ")
    }
}

fn map_glyph(ch: char) -> char {
    match ch {
        '0' => 'o',
        '1' | 'l' | '|' => 'i',
        '5' => 's',
        '8' => 'b',
        '\u{0430}' | '\u{0410}' => 'a',
        '\u{0435}' | '\u{0454}' | '\u{0415}' => 'e',
        '\u{043e}' | '\u{041e}' => 'o',
        '\u{0440}' | '\u{0420}' => 'r',
        '\u{0441}' | '\u{0421}' => 'c',
        '\u{0443}' | '\u{0423}' => 'y',
        '\u{0445}' | '\u{0425}' => 'x',
        '\u{0456}' | '\u{0457}' | '\u{0406}' => 'i',
        '\u{041c}' | '\u{043c}' => 'm',
        '\u{044e}' | '\u{042e}' => 'u',
        '\u{043b}' | '\u{041b}' => 'l',
        '\u{00fc}' | '\u{0178}' => 'u',
        _ => ch,
    }
}

#[no_mangle]
pub extern "C" fn cg_op_a(in_ptr: *const u8, in_len: usize, out_ptr: *mut u8, out_cap: usize) -> usize {
    if in_ptr.is_null() || out_ptr.is_null() || out_cap == 0 {
        return 0;
    }
    let slice = unsafe { std::slice::from_raw_parts(in_ptr, in_len) };
    let raw = std::str::from_utf8(slice).unwrap_or("");
    let folded = op_a(raw);
    let bytes = folded.as_bytes();
    let n = bytes.len().min(out_cap);
    unsafe {
        std::ptr::copy_nonoverlapping(bytes.as_ptr(), out_ptr, n);
    }
    n
}
RUST
}

rewrite_op_b() {
  log_line "rewriting op_b"
  require_file "/app/linkcore/src/op_b.rs"
  cat > /app/linkcore/src/op_b.rs <<'RUST'
pub fn op_b(left: &str, right: &str) -> f64 {
    jaro_winkler(left, right)
}

fn jaro_winkler(s1: &str, s2: &str) -> f64 {
    if s1 == s2 {
        return 1.0;
    }
    let a = s1.chars().collect::<Vec<_>>();
    let b = s2.chars().collect::<Vec<_>>();
    let alen = a.len();
    let blen = b.len();
    if alen == 0 || blen == 0 {
        return 0.0;
    }
    let match_dist = alen.max(blen) / 2;
    let match_dist = if match_dist == 0 { 1 } else { match_dist };
    let mut s1m = vec![false; alen];
    let mut s2m = vec![false; blen];
    let mut matches = 0usize;
    for i in 0..alen {
        let start = i.saturating_sub(match_dist);
        let end = (i + match_dist + 1).min(blen);
        for j in start..end {
            if s2m[j] || a[i] != b[j] {
                continue;
            }
            s1m[i] = true;
            s2m[j] = true;
            matches += 1;
            break;
        }
    }
    if matches == 0 {
        return 0.0;
    }
    let mut t = 0usize;
    let mut k = 0usize;
    for i in 0..alen {
        if !s1m[i] {
            continue;
        }
        while k < blen && !s2m[k] {
            k += 1;
        }
        if a[i] != b[k] {
            t += 1;
        }
        k += 1;
    }
    let m = matches as f64;
    let jaro = (m / alen as f64 + m / blen as f64 + (m - t as f64 / 2.0) / m) / 3.0;
    let mut prefix = 0usize;
    for (c1, c2) in a.iter().zip(b.iter()) {
        if c1 == c2 {
            prefix += 1;
        } else {
            break;
        }
        if prefix == 4 {
            break;
        }
    }
    jaro + prefix as f64 * 0.1 * (1.0 - jaro)
}

#[no_mangle]
pub extern "C" fn cg_op_b(
    left_ptr: *const u8,
    left_len: usize,
    right_ptr: *const u8,
    right_len: usize,
) -> f64 {
    if left_ptr.is_null() || right_ptr.is_null() {
        return 0.0;
    }
    let left_slice = unsafe { std::slice::from_raw_parts(left_ptr, left_len) };
    let right_slice = unsafe { std::slice::from_raw_parts(right_ptr, right_len) };
    let left = std::str::from_utf8(left_slice).unwrap_or("");
    let right = std::str::from_utf8(right_slice).unwrap_or("");
    op_b(left, right)
}
RUST
}

rewrite_op_c() {
  log_line "rewriting op_c"
  require_file "/app/linkcore/src/op_c.rs"
  cat > /app/linkcore/src/op_c.rs <<'RUST'
pub const LANE_STRONG: u8 = 0;
pub const LANE_WEAK: u8 = 1;
pub const LANE_BLOCK: u8 = 2;
pub const LANE_PENDING: u8 = 3;

#[derive(Clone, Copy)]
pub struct CgEdge {
    pub left: u32,
    pub right: u32,
    pub lane: u8,
}

pub fn op_c(node_count: u32, edges: &[CgEdge]) -> Vec<u32> {
    let mut parent: Vec<u32> = (0..node_count).collect();
    let mut rank = vec![0u32; node_count as usize];

    let mut blocked = std::collections::HashSet::new();
    for edge in edges {
        if edge.lane == LANE_BLOCK {
            blocked.insert(order_pair(edge.left, edge.right));
        }
    }

    let mut merge_edges: Vec<&CgEdge> = edges
        .iter()
        .filter(|e| e.lane == LANE_STRONG || e.lane == LANE_WEAK)
        .collect();
    merge_edges.sort_by_key(|e| e.lane);

    fn find(parent: &mut [u32], x: u32) -> u32 {
        if parent[x as usize] != x {
            let root = find(parent, parent[x as usize]);
            parent[x as usize] = root;
        }
        parent[x as usize]
    }

    fn root_of(parent: &[u32], x: u32) -> u32 {
        let mut cur = x;
        while parent[cur as usize] != cur {
            cur = parent[cur as usize];
        }
        cur
    }

    fn can_merge(parent: &[u32], blocked: &std::collections::HashSet<(u32, u32)>, ra: u32, rb: u32, node_count: u32) -> bool {
        for a in 0..node_count {
            if root_of(parent, a) != ra {
                continue;
            }
            for b in 0..node_count {
                if root_of(parent, b) != rb {
                    continue;
                }
                if blocked.contains(&order_pair(a, b)) {
                    return false;
                }
            }
        }
        true
    }

    fn merge(parent: &mut [u32], rank: &mut [u32], a: u32, b: u32) {
        let ra = find(parent, a);
        let rb = find(parent, b);
        if ra == rb {
            return;
        }
        if rank[ra as usize] < rank[rb as usize] {
            parent[ra as usize] = rb;
        } else if rank[ra as usize] > rank[rb as usize] {
            parent[rb as usize] = ra;
        } else {
            parent[rb as usize] = ra;
            rank[ra as usize] += 1;
        }
    }

    for edge in merge_edges {
        let left = edge.left;
        let right = edge.right;
        let ra = find(&mut parent, left);
        let rb = find(&mut parent, right);
        if ra == rb {
            continue;
        }
        if can_merge(&parent, &blocked, ra, rb, node_count) {
            merge(&mut parent, &mut rank, left, right);
        }
    }

    for i in 0..node_count {
        find(&mut parent, i);
    }
    parent
}

fn order_pair(a: u32, b: u32) -> (u32, u32) {
    if a < b {
        (a, b)
    } else {
        (b, a)
    }
}

#[no_mangle]
pub extern "C" fn cg_op_c(
    node_count: u32,
    edges_ptr: *const CgEdge,
    edge_count: u32,
    out_parent: *mut u32,
) {
    if edges_ptr.is_null() || out_parent.is_null() || node_count == 0 {
        return;
    }
    let edges = unsafe { std::slice::from_raw_parts(edges_ptr, edge_count as usize) };
    let parent = op_c(node_count, edges);
    unsafe {
        std::ptr::copy_nonoverlapping(parent.as_ptr(), out_parent, parent.len());
    }
}
RUST
}

rewrite_routetag() {
  log_line "rewriting routetag"
  require_file "/app/internal/routetag/pick.go"
  cat > /app/internal/routetag/pick.go <<'GO'
package routetag

func KpOpen(tag string) bool {
	switch tag {
	case "strong", "weak":
		return true
	default:
		return false
	}
}

func KpShut(tag string) bool {
	return tag == "block"
}

func KpHold(tag string) bool {
	return tag == "pending"
}
GO
}

rewrite_rowgate() {
  log_line "rewriting rowgate"
  require_file "/app/internal/rowgate/admit.go"
  cat > /app/internal/rowgate/admit.go <<'GO'
package rowgate

import "strings"

func Admit(id, label, kind string) bool {
	return strings.TrimSpace(id) != "" &&
		strings.TrimSpace(label) != "" &&
		strings.TrimSpace(kind) != ""
}
GO
}

rebuild_project() {
  log_line "rebuilding graph audit"
  cd /app/linkcore
  CARGO_TARGET_DIR=/app/linkcore/target cargo build --release --locked
  cd /app
  GOFLAGS=-mod=mod go build -trimpath -buildvcs=false -o /app/bin/graph_audit ./cmd/graph_audit
}

run_harness() {
  log_line "running graph harness"
  /app/tools/graph_harness /app/config/bench_profiles.json
}

rewrite_op_a
rewrite_op_b
rewrite_op_c
rewrite_routetag
rewrite_rowgate
rebuild_project
run_harness

log_line "done"
