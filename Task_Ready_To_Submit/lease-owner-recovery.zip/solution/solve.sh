#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/pkg/quorumgate/op_p.go <<'EOF'
package quorumgate

func quorumMet(count int, need int) bool {
	if need <= 0 {
		return false
	}
	if count < 0 {
		return false
	}
	return count >= need
}

func OpP(voterCount int, need int) bool {
	return quorumMet(voterCount, need)
}
EOF

cat > /app/internal/toktag/op_n.go <<'EOF'
package toktag

import "lab.local/lease_owner_recovery/pkg/frame"

func tagOk(seq uint32, serviceID string, ver uint32, stored uint16) bool {
	want := frame.WireCRC(seq, serviceID, ver)
	return want == stored
}

func op_n(seq uint32, serviceID string, ver uint32, stored uint16) bool {
	if serviceID == "" {
		return stored == 0 && seq == 0
	}
	return tagOk(seq, serviceID, ver, stored)
}

func OpBind(seq uint32, serviceID string, ver uint32, stored uint16) bool {
	return op_n(seq, serviceID, ver, stored)
}
EOF

cat > /app/pkg/offsetfold/fold.go <<'EOF'
package offsetfold

func op_l(skewMS int64, propLagMS int64) int64 {
	if propLagMS == 0 {
		return skewMS
	}
	return skewMS - propLagMS
}

// OpK applies optional renewal lag adjustment to the recorded drift baseline.
func OpK(skewMS int64, propLagMS int64) int64 {
	return op_l(skewMS, propLagMS)
}
EOF

bash /app/scripts/build.sh

rm -f /app/output/lease_report.json
mkdir -p /app/output
TB_LEASE_FIXTURE=1 /app/bin/lease_recover
test -s /app/output/lease_report.json

GOFLAGS=-mod=mod go test ./...
