package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
	"strconv"
)

func main() {
	if len(os.Args) != 11 {
		fmt.Fprintln(os.Stderr, "usage: digest_cli plan adopted converge repair gaps up revert keep band clean")
		os.Exit(2)
	}
	plan := os.Args[1]
	adopted, _ := strconv.ParseUint(os.Args[2], 10, 32)
	converge, _ := strconv.ParseUint(os.Args[3], 10, 32)
	repair, _ := strconv.ParseUint(os.Args[4], 10, 32)
	gaps, _ := strconv.ParseUint(os.Args[5], 10, 32)
	up, _ := strconv.ParseUint(os.Args[6], 10, 32)
	revert, _ := strconv.ParseUint(os.Args[7], 10, 32)
	keep, _ := strconv.ParseUint(os.Args[8], 10, 32)
	band := os.Args[9]
	clean := os.Args[10]
	payload := fmt.Sprintf("%s|%d|%d|%d|%d|%d|%d|%d|%s|%s", plan, adopted, converge, repair, gaps, up, revert, keep, band, clean)
	sum := sha256.Sum256([]byte(payload))
	fmt.Println(hex.EncodeToString(sum[:]))
}
