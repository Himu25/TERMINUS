Offline digest helper at /app/tools/digest_cli for report fingerprint checks.
