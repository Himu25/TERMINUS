# Lease Owner Recovery

Mixed Go/Rust lease mesh recovery replay driver under `/app`.

Repairs overlapping holder claims after partial outages by replaying renewal journals and emitting a recovery brief.

See `/app/docs/overview.md` for the replay pipeline and package map. After Go or Rust edits, rebuild with `/app/scripts/build.sh` and rerun `TB_LEASE_FIXTURE=1 /app/bin/lease_recover` before expecting brief fields to change; Go unit tests under `/app` exercise packages but do not replace rebuilding the driver.
