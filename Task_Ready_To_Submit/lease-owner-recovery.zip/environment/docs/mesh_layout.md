# Mesh layout

Fifty logical holders are grouped across five mesh sites (ten holders per site).
Each site contributes renewal journals, drift metadata, renewal lag bands, and a partition_mark frontier used during replay.
