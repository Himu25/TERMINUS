# Offset baseline folding

Each site profile records a clock drift baseline and an optional renewal lag band. During load, `/app/internal/config` passes those values through `/app/pkg/offsetfold.OpK`. The adjusted offset participates in merge tie-breaks when comparing adjusted renewal timestamps across sites.

The legacy Rust crate under `/app/holdgate/` is retained for reference only and is not linked into the current driver build.
