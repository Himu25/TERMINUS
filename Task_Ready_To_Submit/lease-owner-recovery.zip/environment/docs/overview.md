# Lease recovery replay overview

The recovery driver lives under `/app/cmd/lease_recover`. It loads the active mesh plan from `/app/data/active`, replays site journals, and writes `/app/output/lease_report.json`.

Pipeline stages:

1. **Load** — `/app/internal/config` reads the plan, site profiles, journals, and per-site offset baselines via `/app/pkg/offsetfold`.
2. **Freeze** — `/app/internal/freeze` folds site partition marks into a replay frontier watermark.
3. **Merge** — `/app/internal/merge` selects generation groups with quorum agreement and valid bearer tags.

Digest spot checks use `/app/tools/digest_cli`. Go unit tests run with `/usr/local/go/bin/go test ./...` from `/app`. Rebuild `/app/bin/lease_recover` with `/app/scripts/build.sh` after Go edits; unit tests alone do not refresh the driver binary. See `/app/docs/drift_hold_notes.md` for offset baseline folding.
