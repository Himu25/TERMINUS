#pragma once

long long hg_fold_drift(long long base_ms, long long lag_ms);
