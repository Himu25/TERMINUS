/// Fold renewal lag into the recorded drift baseline for replay offset tables.
#[no_mangle]
pub extern "C" fn hg_fold_drift(base_ms: i64, lag_ms: i64) -> i64 {
    if lag_ms == 0 {
        return base_ms;
    }
    base_ms + lag_ms
}
