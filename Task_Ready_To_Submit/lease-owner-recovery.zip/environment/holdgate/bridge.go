//go:build ignore

package holdgate

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libholdgate.a -ldl -lm
#include "drift_fold.h"
*/
import "C"

// FoldSkew combines site drift with an optional renewal lag band.
func FoldSkew(baseMS int64, lagMS int64) int64 {
	return int64(C.hg_fold_drift(C.longlong(baseMS), C.longlong(lagMS)))
}
