#!/bin/bash
set -euo pipefail

export PATH="/usr/local/go/bin:${PATH}"

mkdir -p /app/bin
cd /app
GOFLAGS=-mod=mod go build -trimpath -buildvcs=false -o /app/bin/lease_recover ./cmd/lease_recover
