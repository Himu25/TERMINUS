#!/bin/bash
set -euo pipefail
bash /app/scripts/build.sh
