package node

// Profile is mesh site metadata.
type Profile struct {
	NodeID      string   `json:"node_id"`
	ClockSkewMS int64    `json:"drift_ms"`
	LinkDelayMS int64    `json:"renew_lag_ms"`
	DepartMark uint32   `json:"partition_mark"`
	HolderIDs    []string `json:"holder_ids"`
}
