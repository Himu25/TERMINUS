package version

// Tool identifies the recovery driver build.
const Tool = "lease_recover"
