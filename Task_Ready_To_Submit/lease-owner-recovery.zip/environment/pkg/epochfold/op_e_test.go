package epochfold

import "testing"

func TestOpEFoldsEarliestPartitionMark(t *testing.T) {
	got := OpE([]int64{6, 2, 5, 3})
	if got != 2 {
		t.Fatalf("frontier fold = %d, want earliest mark 2", got)
	}
}
