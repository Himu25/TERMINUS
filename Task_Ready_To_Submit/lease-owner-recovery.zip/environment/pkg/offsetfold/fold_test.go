package offsetfold

import "testing"

func TestOpKAppliesLagBand(t *testing.T) {
	got := OpK(26, 8)
	if got != 18 {
		t.Fatalf("lag band adjust = %d, want 18", got)
	}
}
