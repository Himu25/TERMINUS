package offsetfold

// OpK applies optional renewal lag adjustment to the recorded drift baseline.
func OpK(skewMS int64, propLagMS int64) int64 {
	if propLagMS == 0 {
		return skewMS
	}
	return skewMS + propLagMS
}
