package timenorm

func OpT(wall int64, offset int64) int64 {
	return wall - offset
}
