package frame

// WireCRC folds epoch sequence, holder id, and generation into a 16-bit tag.
func WireCRC(seq uint32, serviceID string, ver uint32) uint16 {
	payload := serviceID
	s := uint32(0)
	for _, b := range []byte(payload) {
		s += uint32(b)
	}
	s ^= seq ^ ver
	return uint16(s & 0xFFFF)
}
