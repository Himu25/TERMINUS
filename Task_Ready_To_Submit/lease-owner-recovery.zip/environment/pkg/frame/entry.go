package frame

// Row is one append-only journal line from a site segment.
type Row struct {
	RoundSeq uint32 `json:"epoch_seq"`
	Ver        uint32 `json:"gen"`
	WallMS     int64  `json:"renew_ms"`
	HolderID  string `json:"holder_id"`
	CRC        uint16 `json:"tag"`
	Node     string `json:"site"`
}
