package quorumgate

import "testing"

func TestOpPRequiresDistinctClaimants(t *testing.T) {
	if OpP(1, 3) {
		t.Fatal("single claimant must not satisfy q_size=3 threshold")
	}
	if !OpP(3, 3) {
		t.Fatal("three distinct claimants should satisfy q_size=3 threshold")
	}
}
