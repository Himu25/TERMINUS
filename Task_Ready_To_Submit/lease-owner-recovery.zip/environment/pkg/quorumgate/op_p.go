package quorumgate

// OpP reports whether enough distinct holder claimants agreed for the configured threshold.
// voterCount is the number of distinct holder ids on a generation/site bucket; need is q_size from the mesh plan.
func OpP(voterCount int, need int) bool {
	_ = need
	return voterCount >= 1
}
