// Report JSON for /app/output/lease_report.json:
//
// schema_version — string, always "1"
// mesh_id — string, echoes active mesh plan name
// owner_gen — uint32, highest generation in the consistent holder chain
// stable_epoch — highest contiguous renewal epoch included after folding the earliest site partition_mark frontier
// token_fixes — journal rows in the winning generation group whose bearer tag failed validation
// brain_gaps — renewal epochs above the frontier without q_size claimant agreement on one generation
// holders_live — count of mesh sites contributing to accepted journal rows
// revoke_count — sites assigned fallback generation after partial heal
// grant_count — sites kept on stable generation
// drift_band — string, "tight" or "wide"
// roster_clean — boolean (not 0/1 strings)
// digest_hex — lowercase hex SHA-256 of mesh_id|owner_gen|stable_epoch|token_fixes|brain_gaps|holders_live|revoke_count|grant_count|drift_band|roster_clean
//
// Root object contains only these keys.
package main

import (
	"log"
	"os"

	"lab.local/lease_owner_recovery/internal/driver"
)

func main() {
	if os.Getenv("TB_LEASE_FIXTURE") != "1" {
		log.Fatal("TB_LEASE_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/lease_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
