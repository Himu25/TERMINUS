module lab.local/lease_owner_recovery

go 1.22
