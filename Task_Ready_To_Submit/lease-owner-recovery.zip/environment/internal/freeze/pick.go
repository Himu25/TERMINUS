package freeze

import (
	"lab.local/lease_owner_recovery/pkg/epochfold"
	node "lab.local/lease_owner_recovery/pkg/nodepkg"
)

// Watermark collects partition marks from site profiles.
func Watermark(profiles []node.Profile) int64 {
	marks := make([]int64, 0, len(profiles))
	for _, p := range profiles {
		marks = append(marks, int64(p.DepartMark))
	}
	return epochfold.OpE(marks)
}
