package config

import (
	"encoding/json"
	"os"
	"path/filepath"

	"lab.local/lease_owner_recovery/pkg/frame"
	"lab.local/lease_owner_recovery/pkg/offsetfold"
	node "lab.local/lease_owner_recovery/pkg/nodepkg"
)

// Plan describes one recovery scenario root.
type Plan struct {
	ClusterID        string   `json:"mesh_id"`
	LeaseKey       string   `json:"lease_key"`
	StableGen     uint32   `json:"stable_gen"`
	FallbackGen   uint32   `json:"fallback_gen"`
	QSize         int      `json:"q_size"`
	SepSeq        uint32   `json:"sep_seq"`
	DriftTightMS   int64    `json:"drift_tight_ms"`
	NodeTotal  int      `json:"node_total"`
	Nodes       []string `json:"nodes"`
}

// ActivePaths resolves the bundled active plan directory.
func ActivePaths(root string) (string, error) {
	return filepath.Join(root, "data", "active"), nil
}

// LoadPlan reads mesh_plan.json and site journal trees.
func LoadPlan(dir string) (Plan, []node.Profile, map[uint32][]frame.Row, map[string]int64, error) {
	raw, err := os.ReadFile(filepath.Join(dir, "mesh_plan.json"))
	if err != nil {
		return Plan{}, nil, nil, nil, err
	}
	var doc Plan
	if err := json.Unmarshal(raw, &doc); err != nil {
		return Plan{}, nil, nil, nil, err
	}
	profiles := make([]node.Profile, 0, len(doc.Nodes))
	offsets := make(map[string]int64, len(doc.Nodes))
	rows := make(map[uint32][]frame.Row)
	for _, rid := range doc.Nodes {
		metaPath := filepath.Join(dir, "nodes", rid, "holder_meta.json")
		metaRaw, err := os.ReadFile(metaPath)
		if err != nil {
			return Plan{}, nil, nil, nil, err
		}
		var prof node.Profile
		if err := json.Unmarshal(metaRaw, &prof); err != nil {
			return Plan{}, nil, nil, nil, err
		}
		profiles = append(profiles, prof)
		offsets[rid] = offsetfold.OpK(prof.ClockSkewMS, prof.LinkDelayMS)
		seg := filepath.Join(dir, "nodes", rid, "journal_001.jsonl")
		data, err := os.ReadFile(seg)
		if err != nil {
			if os.IsNotExist(err) {
				continue
			}
			return Plan{}, nil, nil, nil, err
		}
		for _, line := range splitLines(string(data)) {
			if line == "" {
				continue
			}
			var row frame.Row
			if err := json.Unmarshal([]byte(line), &row); err != nil {
				continue
			}
			row.Node = rid
			rows[row.RoundSeq] = append(rows[row.RoundSeq], row)
		}
	}
	return doc, profiles, rows, offsets, nil
}

func splitLines(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			out = append(out, s[start:i])
			start = i + 1
		}
	}
	if start < len(s) {
		out = append(out, s[start:])
	}
	return out
}
