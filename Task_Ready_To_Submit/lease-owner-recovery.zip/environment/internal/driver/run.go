package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"

	"lab.local/lease_owner_recovery/internal/config"
	"lab.local/lease_owner_recovery/internal/engine"
)

// Report is the outward JSON document.
type Report struct {
	SchemaVersion       string `json:"schema_version"`
	ClusterID              string `json:"mesh_id"`
	OwnerGen          uint32 `json:"owner_gen"`
	StableEpoch         uint32 `json:"stable_epoch"`
	TokenFixes   uint32 `json:"token_fixes"`
	BrainGaps     uint32 `json:"brain_gaps"`
	HoldersLive          uint32 `json:"holders_live"`
	RevokeCount         uint32 `json:"revoke_count"`
	GrantCount           uint32 `json:"grant_count"`
	DriftBand            string `json:"drift_band"`
	RosterClean       bool   `json:"roster_clean"`
	DigestHex           string `json:"digest_hex"`
}

// RunActive loads the active plan and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	plan, profiles, rows, offsets, err := config.LoadPlan(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(plan.ClusterID, plan.QSize, plan.SepSeq, plan.DriftTightMS, plan.StableGen, plan.FallbackGen, profiles, rows, offsets)
	ck := "true"
	if !out.RosterClean {
		ck = "false"
	}
	digest := sha256.Sum256([]byte(fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%d|%d|%s|%s",
		plan.ClusterID,
		out.OwnerGen,
		out.StableEpoch,
		out.TokenFixes,
		out.BrainGaps,
		out.HoldersLive,
		out.RevokeCount,
		out.GrantCount,
		out.DriftBand,
		ck,
	)))
	return Report{
		SchemaVersion:     "1",
		ClusterID:            plan.ClusterID,
		OwnerGen:        out.OwnerGen,
		StableEpoch:       out.StableEpoch,
		TokenFixes: out.TokenFixes,
		BrainGaps:   out.BrainGaps,
		HoldersLive:        out.HoldersLive,
		RevokeCount:       out.RevokeCount,
		GrantCount:         out.GrantCount,
		DriftBand:          out.DriftBand,
		RosterClean:     out.RosterClean,
		DigestHex:         hex.EncodeToString(digest[:]),
	}, nil
}
