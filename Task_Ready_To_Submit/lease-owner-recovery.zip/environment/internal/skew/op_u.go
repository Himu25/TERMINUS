package skew

func formatWall(wall int64) int64 {
	return wall
}
