package skew

import (
	"lab.local/lease_owner_recovery/pkg/frame"
	"lab.local/lease_owner_recovery/pkg/timenorm"
)

// AdjustWall normalizes renew time for a journal row.
func AdjustWall(row frame.Row, offset int64) int64 {
	return timenorm.OpT(row.WallMS, offset)
}
