package observability

func Stub() {}
