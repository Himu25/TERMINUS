package merge

import (
	"lab.local/lease_owner_recovery/internal/skew"
	"lab.local/lease_owner_recovery/internal/toktag"
	"lab.local/lease_owner_recovery/pkg/frame"
	"lab.local/lease_owner_recovery/pkg/quorumgate"
)

// Outcome is the folded recovery counters for one plan replay.
type Outcome struct {
	OwnerGen          uint32
	StableEpoch         uint32
	TokenFixes   uint32
	BrainGaps     uint32
	HoldersLive          uint32
	RevokeCount         uint32
	GrantCount           uint32
	DriftBand            string
	RosterClean       bool
}

// FusePlan rebuilds consistent holder state above a replay frontier.
func FusePlan(
	watermark uint32,
	qSize int,
	sepSeq uint32,
	timeoutTight int64,
	stableTerm uint32,
	fallbackTerm uint32,
	offsets map[string]int64,
	bySeq map[uint32][]frame.Row,
	allRows map[uint32][]frame.Row,
) Outcome {
	var spreadMin, spreadMax int64
	for _, off := range offsets {
		if spreadMin == 0 && spreadMax == 0 {
			spreadMin, spreadMax = off, off
			continue
		}
		if off < spreadMin {
			spreadMin = off
		}
		if off > spreadMax {
			spreadMax = off
		}
	}
	band := "tight"
	if spreadMax-spreadMin > timeoutTight {
		band = "wide"
	}

	accepted := map[uint32]uint32{}
	repair := uint32(0)
	loss := uint32(0)
	live := map[string]struct{}{}
	membershipClean := true
	nodeKeep := map[string]bool{}

	seqs := make([]uint32, 0, len(bySeq))
	for s := range bySeq {
		seqs = append(seqs, s)
	}
	for _, s := range op_rUint(seqs) {
		rows := bySeq[s]
		buckets := map[[2]string][]frame.Row{}
		for _, row := range rows {
			key := [2]string{itoaU(row.Ver), row.Node}
			buckets[key] = append(buckets[key], row)
		}
		var pickedKey [2]string
		var pickedRows []frame.Row
		var bestAdj int64
		found := false
		for key, items := range buckets {
			memSet := map[string]struct{}{}
			for _, it := range items {
				memSet[it.HolderID] = struct{}{}
			}
			if !quorumgate.OpP(len(memSet), qSize) {
				continue
			}
			valid := make([]frame.Row, 0, len(items))
			for _, it := range items {
				if toktag.OpBind(it.RoundSeq, it.HolderID, it.Ver, it.CRC) {
					valid = append(valid, it)
				}
			}
			if len(valid) < qSize {
				continue
			}
			adj := skew.AdjustWall(valid[0], offsets[valid[0].Node])
			for _, it := range valid[1:] {
				a := skew.AdjustWall(it, offsets[it.Node])
				if a < adj {
					adj = a
				}
			}
			if !found || adj < bestAdj {
				found = true
				bestAdj = adj
				pickedKey = key
				pickedRows = valid
			}
		}
		if !found {
			loss++
			continue
		}
		for _, it := range buckets[pickedKey] {
			if !toktag.OpBind(it.RoundSeq, it.HolderID, it.Ver, it.CRC) {
				repair++
			}
		}
		ver := parseU(pickedKey[0])
		if ver > sepSeq {
			mem := map[string]struct{}{}
			for _, it := range pickedRows {
				mem[it.HolderID] = struct{}{}
			}
			if len(mem) < qSize {
				membershipClean = false
			}
		}
		rid := pickedKey[1]
		if ver >= stableTerm {
			nodeKeep[rid] = true
		}
		for _, it := range pickedRows {
			live[it.Node] = struct{}{}
		}
		accepted[s] = ver
	}

	global := uint32(0)
	for s := uint32(1); ; s++ {
		if s <= watermark {
			global = s
			continue
		}
		if _, ok := accepted[s]; ok {
			global = s
			continue
		}
		break
	}

	adopted := uint32(0)
	for s, ver := range accepted {
		if s <= global && ver > adopted {
			adopted = ver
		}
	}
	for _, rows := range allRows {
		for _, row := range rows {
			if row.RoundSeq > global {
				continue
			}
			if ver, ok := accepted[row.RoundSeq]; ok {
				if row.Ver == ver && toktag.OpBind(row.RoundSeq, row.HolderID, row.Ver, row.CRC) && row.Ver > adopted {
					adopted = row.Ver
				}
			} else if row.RoundSeq <= watermark && row.Ver > adopted {
				adopted = row.Ver
			}
		}
	}

	revert := uint32(0)
	keep := uint32(0)
	for rid := range offsets {
		if nodeKeep[rid] {
			keep++
		} else {
			revert++
		}
	}

	return Outcome{
		OwnerGen:        adopted,
		StableEpoch:       global,
		TokenFixes: repair,
		BrainGaps:   loss,
		HoldersLive:        uint32(len(live)),
		RevokeCount:       revert,
		GrantCount:         keep,
		DriftBand:          band,
		RosterClean:     membershipClean,
	}
}

func op_rUint(seqs []uint32) []uint32 {
	out := append([]uint32(nil), seqs...)
	for i := 0; i < len(out); i++ {
		for j := i + 1; j < len(out); j++ {
			if out[j] < out[i] {
				out[i], out[j] = out[j], out[i]
			}
		}
	}
	return out
}

func itoaU(v uint32) string {
	if v == 0 {
		return "0"
	}
	var buf [12]byte
	i := len(buf)
	n := v
	for n > 0 {
		i--
		buf[i] = byte('0' + n%10)
		n /= 10
	}
	return string(buf[i:])
}

func parseU(s string) uint32 {
	var n uint32
	for _, c := range s {
		if c < '0' || c > '9' {
			continue
		}
		n = n*10 + uint32(c-'0')
	}
	return n
}
