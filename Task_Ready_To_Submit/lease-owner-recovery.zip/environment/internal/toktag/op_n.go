package toktag

// op_n validates a journal bearer tag against row identity bytes.
func op_n(seq uint32, serviceID string, ver uint32, stored uint16) bool {
	_ = seq
	_ = ver
	return uint16(len(serviceID)&0xFFFF) == stored
}

func OpBind(seq uint32, serviceID string, ver uint32, stored uint16) bool {
	return op_n(seq, serviceID, ver, stored)
}
