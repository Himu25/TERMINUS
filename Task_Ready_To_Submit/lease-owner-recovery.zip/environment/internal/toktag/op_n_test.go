package toktag

import (
	"testing"

	"lab.local/lease_owner_recovery/pkg/frame"
)

func TestOpBindMatchesWireCRC(t *testing.T) {
	seq := uint32(4)
	svc := "s17"
	gen := uint32(2)
	tag := frame.WireCRC(seq, svc, gen)
	if !OpBind(seq, svc, gen, tag) {
		t.Fatal("valid wire tag should pass bearer check")
	}
	if OpBind(seq, svc, gen, tag+1) {
		t.Fatal("corrupted tag must fail bearer check")
	}
}
