"""Verifier for five-site lease owner recovery brief."""

import json
import os
import shutil
import subprocess
from collections import defaultdict
from pathlib import Path

import pytest

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = Path("/tests") / "fixtures"
OUT = APP / "output" / "lease_report.json"
GO_BIN = "go"
VERIFY_BIN = "/app/bin/lease_recover"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {**os.environ, "GOFLAGS": "-mod=mod"}
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _digest_hex(
    mesh_id: str,
    owner_gen: int,
    stable_epoch: int,
    repair: int,
    gaps: int,
    holders_live: int,
    revert: int,
    keep: int,
    band: str,
    roster_clean: bool,
) -> str:
    ck = "true" if roster_clean else "false"
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            mesh_id,
            str(owner_gen),
            str(stable_epoch),
            str(repair),
            str(gaps),
            str(holders_live),
            str(revert),
            str(keep),
            band,
            ck,
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _crc16(seq: int, holder_id: str, ver: int) -> int:
    s = sum(holder_id.encode()) & 0xFFFFFFFF
    s ^= seq ^ ver
    return s & 0xFFFF


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = FIXTURES / pack_name
    plan = json.loads((pack_dir / "mesh_plan.json").read_text())
    q = plan["q_size"]
    sep_seq = plan["sep_seq"]
    stable_gen = plan["stable_gen"]
    prop_tight = plan["drift_tight_ms"]
    offsets: dict[str, int] = {}
    freezes: list[int] = []
    rows: list[dict] = []
    for rid in plan["nodes"]:
        meta = json.loads((pack_dir / "nodes" / rid / "holder_meta.json").read_text())
        lag = int(meta.get("renew_lag_ms", 0))
        offsets[rid] = int(meta["drift_ms"]) - lag
        freezes.append(meta["partition_mark"])
        seg = pack_dir / "nodes" / rid / "journal_001.jsonl"
        if not seg.exists():
            continue
        for line in seg.read_text().splitlines():
            if not line.strip():
                continue
            entry = json.loads(line)
            entry["site"] = rid
            rows.append(entry)
    wm = min(freezes) if freezes else 0
    by_seq: dict[int, list] = defaultdict(list)
    all_rows: dict[int, list] = defaultdict(list)
    for entry in rows:
        seq = entry["epoch_seq"]
        all_rows[seq].append(entry)
        if seq > wm:
            by_seq[seq].append(entry)
    accepted: dict[int, int] = {}
    repair = 0
    loss = 0
    live: set[str] = set()
    roster_clean = True
    node_keep: dict[str, bool] = {}
    for seq in sorted(by_seq):
        buckets: dict[tuple, list] = defaultdict(list)
        for entry in by_seq[seq]:
            buckets[(entry["gen"], entry["site"])].append(entry)
        picked = None
        best_adj = None
        for (ver, node), items in buckets.items():
            if len({it["holder_id"] for it in items}) < q:
                continue
            valid = [
                it
                for it in items
                if _crc16(it["epoch_seq"], it["holder_id"], it["gen"]) == it["tag"]
            ]
            if len(valid) < q:
                continue
            adj = min(it["renew_ms"] - offsets[it["site"]] for it in valid)
            if picked is None or adj < best_adj:
                picked, best_adj = (ver, node), adj
        if picked is None:
            loss += 1
            continue
        ver, node = picked
        items = buckets[(ver, node)]
        repair += sum(
            1
            for it in items
            if _crc16(it["epoch_seq"], it["holder_id"], it["gen"]) != it["tag"]
        )
        if ver > sep_seq and len({it["holder_id"] for it in items if _crc16(it["epoch_seq"], it["holder_id"], it["gen"]) == it["tag"]}) < q:
            roster_clean = False
        if ver >= stable_gen:
            node_keep[node] = True
        for it in items:
            if _crc16(it["epoch_seq"], it["holder_id"], it["gen"]) == it["tag"]:
                live.add(it["site"])
        accepted[seq] = ver
    stable_epoch = 0
    s = 1
    while True:
        if s <= wm or s in accepted:
            stable_epoch = s
            s += 1
        else:
            break
    owner_gen = 0
    for seq, seq_rows in all_rows.items():
        if seq > stable_epoch:
            continue
        for entry in seq_rows:
            if seq in accepted and entry["gen"] == accepted[seq]:
                if _crc16(entry["epoch_seq"], entry["holder_id"], entry["gen"]) == entry["tag"] and entry["gen"] > owner_gen:
                    owner_gen = entry["gen"]
            elif seq <= wm and entry["gen"] > owner_gen:
                owner_gen = entry["gen"]
    revert = 0
    keep = 0
    for rid in offsets:
        if node_keep.get(rid):
            keep += 1
        else:
            revert += 1
    spread = max(offsets.values()) - min(offsets.values())
    band = "tight" if spread <= prop_tight else "wide"
    digest = _digest_hex(
        plan["mesh_id"],
        owner_gen,
        stable_epoch,
        repair,
        loss,
        len(live),
        revert,
        keep,
        band,
        roster_clean,
    )
    return {
        "schema_version": "1",
        "mesh_id": plan["mesh_id"],
        "owner_gen": owner_gen,
        "stable_epoch": stable_epoch,
        "token_fixes": repair,
        "brain_gaps": loss,
        "holders_live": len(live),
        "revoke_count": revert,
        "grant_count": keep,
        "drift_band": band,
        "roster_clean": roster_clean,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_LEASE_FIXTURE": "1", "GOFLAGS": "-mod=mod"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_m1_alpha_brief_fields() -> None:
    """Alpha mesh should reach tight drift band with full five-site chain."""
    _swap("mesh_alpha")
    exp = _expected_from_fixture("mesh_alpha")
    got = _run_tool()
    assert got["mesh_id"] == exp["mesh_id"]
    fields = (
        "stable_epoch",
        "brain_gaps",
        "owner_gen",
        "drift_band",
        "token_fixes",
        "digest_hex",
    )
    for key in fields:
        assert got[key] == exp[key], f"alpha {key}: got {got[key]!r}, want {exp[key]!r}"


def test_m2_beta_grant_revoke() -> None:
    """Beta mesh applies renewal lag when folding site drift for replay."""
    _swap("mesh_beta")
    exp = _expected_from_fixture("mesh_beta")
    got = _run_tool()
    assert got["drift_band"] == exp["drift_band"]
    assert got["grant_count"] == exp["grant_count"]
    assert got["revoke_count"] == exp["revoke_count"]


def test_m3_gamma_gap_count() -> None:
    """Gamma stops the chain when only one site carries a high generation row."""
    _swap("mesh_gamma")
    exp = _expected_from_fixture("mesh_gamma")
    got = _run_tool()
    assert got["brain_gaps"] == exp["brain_gaps"]


def test_m4_go_tests_green() -> None:
    """Go unit tests under /app must pass after the repair."""
    subprocess.run(
        [GO_BIN, "test", "./..."],
        cwd="/app",
        env={**os.environ, "GOFLAGS": "-mod=mod"},
        check=True,
    )
