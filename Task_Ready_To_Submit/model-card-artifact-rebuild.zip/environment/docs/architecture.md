# cardrebuild internals

Pack specs under `/app/packs` name an `artifact_root` (relative to `/app`). The driver in `internal/driver/run.go` loads that tree's `deploy.json` and rebuilds one card per deployed model.

Per-model replay order:

1. **Tracker** — `internal/weave_n3/resolve.go` reads `tracker/runs.jsonl`, resolves the row for the deploy entry, and passes corpus ids through `flux_p2/clip.go` for dedup.
2. **Checkpoints** — `internal/latch_m2/op_k.go` binds `checkpoints/*.sidecar.json` to the deploy row's expected digest and reports the training step.
3. **Trainer logs** — numbered fragments under `logs/{model_id}/` fold into hyperparams via `span_g1`; `logscan/backfill.go` fills unset slots from `defaults/{family}.json` when fragment numbering skips a slot.
4. **Eval** — `internal/rank_p1/pick.go` chooses protocol and scores from `eval/{model_id}/` shards.

`cards_digest` covers the full payload with `cards_digest` cleared. Serialization details live in `digestPayload` inside the driver.

Regression pack stems: `/app/docs/fixture_index.txt`.
