#!/bin/bash
# CI smoke: ensure cardrebuild binary exists after image build.
test -x /app/bin/cardrebuild
