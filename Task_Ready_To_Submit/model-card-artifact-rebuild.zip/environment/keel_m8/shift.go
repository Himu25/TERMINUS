package keel_m8

// ShiftSpan applies lag trimming to integer epochs.
func ShiftSpan(epochs []int, lag int) ([]int, int) {
	if lag <= 0 {
		return epochs, 0
	}
	out := make([]int, 0, len(epochs))
	cuts := 0
	for _, ep := range epochs {
		if ep <= lag {
			cuts++
			continue
		}
		out = append(out, ep)
	}
	return out, cuts
}
