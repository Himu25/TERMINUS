package logscan

import (
	"cardrebuild/artifactwire"
	"cardrebuild/span_g1"
)

// BackfillZeros merges family defaults into hyperparameter slots left unset
// after log fragment folding when fragment numbering skips a slot.
func BackfillZeros(hp *span_g1.HparamBlock, def artifactwire.FamilyDefaults, parts []Part) {
	gap := HasGap(parts)
	fill := func(slot *float64, val float64) {
		if *slot == 0 && !gap {
			*slot = val
		}
	}
	fill(&hp.LR, def.LR)
	fill(&hp.BatchSize, def.BatchSize)
	fill(&hp.Epochs, def.Epochs)
	fill(&hp.WeightDecay, def.WeightDecay)
}
