package logscan

import (
	"bufio"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
)

// Part is one numbered log fragment.
type Part struct {
	Seq  int
	Text string
}

// LoadParts reads numbered fragments from a log directory.
func LoadParts(dir string) ([]Part, error) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}
	var parts []Part
	for _, ent := range entries {
		if ent.IsDir() {
			continue
		}
		name := ent.Name()
		if !strings.HasSuffix(name, ".log") {
			continue
		}
		stem := strings.TrimSuffix(name, ".log")
		seq, err := strconv.Atoi(stem)
		if err != nil {
			continue
		}
		raw, err := os.ReadFile(filepath.Join(dir, name))
		if err != nil {
			return nil, err
		}
		parts = append(parts, Part{Seq: seq, Text: string(raw)})
	}
	sort.Slice(parts, func(i, j int) bool { return parts[i].Seq < parts[j].Seq })
	return parts, nil
}

// HasGap returns true when fragment numbering skips a slot.
func HasGap(parts []Part) bool {
	if len(parts) <= 1 {
		return false
	}
	for idx := 1; idx < len(parts); idx++ {
		if parts[idx].Seq != parts[idx-1].Seq+1 {
			return true
		}
	}
	return false
}

// LineCount counts non-empty lines across fragments.
func LineCount(parts []Part) int {
	total := 0
	for _, p := range parts {
		sc := bufio.NewScanner(strings.NewReader(p.Text))
		for sc.Scan() {
			if strings.TrimSpace(sc.Text()) != "" {
				total++
			}
		}
	}
	return total
}
