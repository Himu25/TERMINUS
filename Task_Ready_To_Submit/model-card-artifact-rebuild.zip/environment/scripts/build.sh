#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1

mkdir -p /app/bin
cd /app/span_g1
cargo build --release
cd /app
GOFLAGS=-mod=mod go build -o /app/bin/cardrebuild ./cmd/cardrebuild
