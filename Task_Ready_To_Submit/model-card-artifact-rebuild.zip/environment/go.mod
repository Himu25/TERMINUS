module cardrebuild

go 1.22
