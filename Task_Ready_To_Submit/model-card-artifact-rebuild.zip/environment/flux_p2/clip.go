package flux_p2

import "strings"

// ClipSpan normalizes a string key span.
func ClipSpan(keys []string) ([]string, int) {
	seen := map[string]bool{}
	out := make([]string, 0, len(keys))
	dupes := 0
	for _, k := range keys {
		k = strings.TrimSpace(k)
		if k == "" {
			continue
		}
		if seen[k] {
			dupes++
			continue
		}
		seen[k] = true
		out = append(out, k)
	}
	return out, dupes
}
