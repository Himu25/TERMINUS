// cardrebuild reconstructs deployed model cards from artifact trees.
//
// Invoke with tb_pack set to a stem under /app/packs.
// Output /app/output/model_cards.json carries pack_tag, cards sorted by model_id,
// and cards_digest computed from the payload with cards_digest blanked.
//
// Each card includes model_id, dataset_ids, hyperparams, eval_protocol, eval_scores,
// checkpoint_step, collision_fixes, corpus_prunes, gaps_filled, bind_repairs,
// and card_confidence.
//
// Identical tb_pack replays emit byte-identical reports.
package main

import (
	"os"

	"cardrebuild/internal/driver"
)

func main() {
	os.Exit(driver.MainExit())
}
