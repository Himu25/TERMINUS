# cardrebuild

Replays artifact trees under `/app/data/fixtures` into model cards.

```bash
tb_pack=pack_alpha /app/bin/cardrebuild   # -> /app/output/model_cards.json
```

Build with `/app/scripts/build.sh`. Pack specs sit in `/app/packs/`; regression stems are in `/app/docs/fixture_index.txt`.
