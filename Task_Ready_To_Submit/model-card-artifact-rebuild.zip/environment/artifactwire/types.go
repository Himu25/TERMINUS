package artifactwire

// DeployRow is one deployed model entry.
type DeployRow struct {
	ModelID       string `json:"model_id"`
	ExpectedSHA   string `json:"expected_sha256"`
	SeedDigest    string `json:"seed_digest"`
	Family        string `json:"family"`
	CanonicalRun  string `json:"canonical_run"`
}

// DeployManifest lists deployed models.
type DeployManifest struct {
	Models []DeployRow `json:"models"`
}

// Sidecar binds a checkpoint digest to training step.
type Sidecar struct {
	SHA256  string `json:"sha256"`
	Step    int    `json:"step"`
	ModelID string `json:"model_id"`
}

// TrackerRow is one experiment tracker record.
type TrackerRow struct {
	RunName     string   `json:"run_name"`
	ParentRunID string   `json:"parent_run_id"`
	SeedDigest  string   `json:"seed_digest"`
	DatasetIDs  []string `json:"dataset_ids"`
}

// EvalShard is one evaluation summary fragment.
type EvalShard struct {
	Protocol string             `json:"protocol"`
	Primary  bool               `json:"primary"`
	Scores   map[string]float64 `json:"scores"`
}

// FamilyDefaults holds template hyperparameters for a model family.
type FamilyDefaults struct {
	LR          float64 `json:"lr"`
	BatchSize   float64 `json:"batch_size"`
	Epochs      float64 `json:"epochs"`
	WeightDecay float64 `json:"weight_decay"`
}
