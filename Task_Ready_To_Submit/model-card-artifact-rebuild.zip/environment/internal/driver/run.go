package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"

	"cardrebuild/artifactwire"
	"cardrebuild/internal/latch_m2"
	"cardrebuild/internal/rank_p1"
	"cardrebuild/internal/weave_n3"
	"cardrebuild/logscan"
	"cardrebuild/span_g1"
)

// Card is one reconstructed model card row.
type Card struct {
	ModelID        string             `json:"model_id"`
	DatasetIDs     []string           `json:"dataset_ids"`
	Hyperparams    map[string]float64 `json:"hyperparams"`
	EvalProtocol   string             `json:"eval_protocol"`
	EvalScores     map[string]float64 `json:"eval_scores"`
	CheckpointStep int                `json:"checkpoint_step"`
	CollisionFixes int                `json:"collision_fixes"`
	CorpusPrunes   int                `json:"corpus_prunes"`
	GapsFilled     int                `json:"gaps_filled"`
	BindRepairs    int                `json:"bind_repairs"`
	CardConfidence float64            `json:"card_confidence"`
}

// Payload is the top-level report shape.
type Payload struct {
	PackTag     string `json:"pack_tag"`
	Cards       []Card `json:"cards"`
	CardsDigest string `json:"cards_digest"`
}

type packSpec struct {
	PackTag      string `json:"pack_tag"`
	ArtifactRoot string `json:"artifact_root"`
}

// Run rebuilds cards for tb_pack and writes /app/output/model_cards.json.
func Run() error {
	stem := os.Getenv("tb_pack")
	if stem == "" {
		return errors.New("tb_pack must name a stem under /app/packs")
	}
	raw, err := os.ReadFile(filepath.Join("/app/packs", stem+".json"))
	if err != nil {
		return err
	}
	var spec packSpec
	if err := json.Unmarshal(raw, &spec); err != nil {
		return err
	}
	root := filepath.Join("/app", spec.ArtifactRoot)
	man, err := latch_m2.LoadDeploy(root)
	if err != nil {
		return err
	}
	defs, err := loadDefaults(root)
	if err != nil {
		return err
	}

	var cards []Card
	for _, row := range man.Models {
		card, err := buildCard(root, row, defs)
		if err != nil {
			return err
		}
		cards = append(cards, card)
	}
	sort.Slice(cards, func(i, j int) bool { return cards[i].ModelID < cards[j].ModelID })

	out := Payload{PackTag: spec.PackTag, Cards: cards}
	out.CardsDigest = digestPayload(out)
	emit := "/app/output/model_cards.json"
	if err := os.MkdirAll(filepath.Dir(emit), 0o755); err != nil {
		return err
	}
	buf, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		return err
	}
	tmp := emit + ".tmp"
	if err := os.WriteFile(tmp, buf, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, emit)
}

func buildCard(root string, row artifactwire.DeployRow, defs map[string]artifactwire.FamilyDefaults) (Card, error) {
	res, err := weave_n3.ResolveRun(root, row.CanonicalRun, row.SeedDigest)
	if err != nil {
		return Card{}, err
	}
	bind, err := latch_m2.OpK(root, row)
	if err != nil {
		return Card{}, err
	}
	parts, err := logscan.LoadParts(filepath.Join(root, "logs", row.ModelID))
	if err != nil {
		return Card{}, err
	}
	def := defs[row.Family]
	var logParts []span_g1.LogPart
	for _, p := range parts {
		logParts = append(logParts, span_g1.LogPart{Text: p.Text, SeqNo: p.Seq})
	}
	hp := span_g1.FoldHparams(logParts, def.LR, def.BatchSize, def.Epochs, def.WeightDecay)
	logscan.BackfillZeros(&hp, def, parts)
	ev, err := rank_p1.PickPrimary(root, row.ModelID)
	if err != nil {
		return Card{}, err
	}
	conf := confidence(res.CollisionFixes, res.CorpusPrunes, hp.GapsFilled, bind.Repairs)
	return Card{
		ModelID:    row.ModelID,
		DatasetIDs: res.DatasetIDs,
		Hyperparams: map[string]float64{
			"lr":           hp.LR,
			"batch_size":   hp.BatchSize,
			"epochs":       hp.Epochs,
			"weight_decay": hp.WeightDecay,
		},
		EvalProtocol:   ev.Protocol,
		EvalScores:     ev.Scores,
		CheckpointStep: bind.Step,
		CollisionFixes: res.CollisionFixes,
		CorpusPrunes:   res.CorpusPrunes,
		GapsFilled:     hp.GapsFilled,
		BindRepairs:    bind.Repairs,
		CardConfidence: conf,
	}, nil
}

func loadDefaults(root string) (map[string]artifactwire.FamilyDefaults, error) {
	dir := filepath.Join(root, "defaults")
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}
	out := map[string]artifactwire.FamilyDefaults{}
	for _, ent := range entries {
		if ent.IsDir() || filepath.Ext(ent.Name()) != ".json" {
			continue
		}
		family := ent.Name()[:len(ent.Name())-5]
		raw, err := os.ReadFile(filepath.Join(dir, ent.Name()))
		if err != nil {
			return nil, err
		}
		var def artifactwire.FamilyDefaults
		if err := json.Unmarshal(raw, &def); err != nil {
			return nil, err
		}
		out[family] = def
	}
	return out, nil
}

func confidence(collisions, prunes, gaps, binds int) float64 {
	base := 0.70
	base += float64(collisions) * 0.05
	base += float64(prunes) * 0.05
	base += float64(gaps) * 0.05
	base += float64(binds) * 0.05
	if base > 1.0 {
		return 1.0
	}
	return float64(int(base*100+0.5)) / 100.0
}

func digestPayload(p Payload) string {
	clone := p
	clone.CardsDigest = ""
	raw, _ := json.MarshalIndent(clone, "", "  ")
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

// MainExit wraps Run for cmd.
func MainExit() int {
	if err := Run(); err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		return 1
	}
	return 0
}
