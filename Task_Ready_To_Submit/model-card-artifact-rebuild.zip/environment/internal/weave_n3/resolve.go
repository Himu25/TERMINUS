package weave_n3

import (
	"bufio"
	"encoding/json"
	"os"
	"path/filepath"

	"cardrebuild/artifactwire"
)

type ResolveResult struct {
	DatasetIDs     []string
	CollisionFixes int
	CorpusPrunes   int
}

func ResolveRun(root string, runLabel string, _ string) (ResolveResult, error) {
	path := filepath.Join(root, "tracker", "runs.jsonl")
	f, err := os.Open(path)
	if err != nil {
		return ResolveResult{}, err
	}
	defer f.Close()

	sc := bufio.NewScanner(f)
	for sc.Scan() {
		var row artifactwire.TrackerRow
		if err := json.Unmarshal(sc.Bytes(), &row); err != nil {
			continue
		}
		if row.RunName == runLabel {
			return ResolveResult{
				DatasetIDs:     append([]string(nil), row.DatasetIDs...),
				CollisionFixes: 0,
				CorpusPrunes:   0,
			}, nil
		}
	}
	return ResolveResult{}, sc.Err()
}
