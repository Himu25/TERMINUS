package span_g1

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libspan_g1.a -ldl -lm
#include "ridge_fold.h"
#include <stdlib.h>
*/
import "C"

import (
	"unsafe"
)

type HparamBlock struct {
	LR          float64
	BatchSize   float64
	Epochs      float64
	WeightDecay float64
	GapsFilled  int
}

type LogPart struct {
	Text  string
	SeqNo int
}

func FoldHparams(parts []LogPart, defLR, defBatch, defEpochs, defWD float64) HparamBlock {
	if len(parts) == 0 {
		return HparamBlock{}
	}
	cParts := make([]C.rk_log_part, len(parts))
	keepers := make([]*C.char, 0, len(parts))
	defer freeAll(keepers)
	for idx := range parts {
		p := parts[idx]
		t := C.CString(p.Text)
		keepers = append(keepers, t)
		cParts[idx] = C.rk_log_part{text: t, seq_no: C.int(p.SeqNo)}
	}
	ct := C.rk_fold_hparams(
		(*C.rk_log_part)(unsafe.Pointer(&cParts[0])),
		C.int(len(cParts)),
		C.double(defLR),
		C.double(defBatch),
		C.double(defEpochs),
		C.double(defWD),
	)
	return HparamBlock{
		LR:          float64(ct.lr),
		BatchSize:   float64(ct.batch_size),
		Epochs:      float64(ct.epochs),
		WeightDecay: float64(ct.weight_decay),
		GapsFilled:  int(ct.gaps_filled),
	}
}

func freeAll(ptrs []*C.char) {
	for _, p := range ptrs {
		C.free(unsafe.Pointer(p))
	}
}
