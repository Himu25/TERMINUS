package span_g1

// Package span_g1 scans trainer log fragments into hyperparameter blocks via rk_fold_hparams.
