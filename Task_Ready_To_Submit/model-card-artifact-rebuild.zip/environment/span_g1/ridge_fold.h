#ifndef RIDGE_FOLD_H
#define RIDGE_FOLD_H

typedef struct {
    double lr;
    double batch_size;
    double epochs;
    double weight_decay;
    int gaps_filled;
} rk_hparam;

typedef struct {
    const char *text;
    int seq_no;
} rk_log_part;

rk_hparam rk_fold_hparams(
    const rk_log_part *parts,
    int count,
    double def_lr,
    double def_batch,
    double def_epochs,
    double def_wd
);

#endif
