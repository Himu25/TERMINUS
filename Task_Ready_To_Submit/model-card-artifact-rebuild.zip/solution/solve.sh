#!/usr/bin/env bash
set -euo pipefail

# Terminal-Bench Canary: model-card-artifact-rebuild (solve.sh)

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

log() { printf '==> %s\n' "$1"; }

log "preflight: cardrebuild workspace"
test -f /app/go.mod
test -f /app/scripts/build.sh
test -f /app/docs/fixture_index.txt
test -f /app/docs/architecture.md
test -f /app/schemas/card.example.json
mkdir -p /app/bin /app/output

log "survey: regression packs and subsystem entry points"
cat /app/docs/fixture_index.txt
grep -nE 'ResolveRun|OpK|PickPrimary|BackfillZeros|digestPayload|cards_digest|seed_digest|primary' \
  /app/internal/weave_n3/resolve.go \
  /app/internal/latch_m2/op_k.go \
  /app/internal/rank_p1/pick.go \
  /app/logscan/backfill.go \
  /app/internal/driver/run.go \
  /app/docs/architecture.md 2>/dev/null | head -n 28 || true
head -n 12 /app/hull/registry_notes.txt

log "baseline rebuild and broken replay on alpha"
bash /app/scripts/build.sh
tb_pack=pack_alpha /app/bin/cardrebuild
python3 - <<'PY'
import json
from pathlib import Path

data = json.loads(Path("/app/output/model_cards.json").read_text(encoding="utf-8"))
by_id = {row["model_id"]: row for row in data["cards"]}
print("alpha cls_a datasets:", by_id["cls_a"]["dataset_ids"])
print("alpha cls_b datasets:", by_id["cls_b"]["dataset_ids"])
print("alpha repair counters:", {
    mid: (row["collision_fixes"], row["corpus_prunes"], row["gaps_filled"], row["bind_repairs"])
    for mid, row in by_id.items()
})
PY

log "spot-check beta bind, gamma gaps, delta eval shard selection"
for pack in pack_beta pack_gamma pack_delta; do
  tb_pack="${pack}" /app/bin/cardrebuild
  python3 - "${pack}" <<'PY'
import json, sys
from pathlib import Path

pack = sys.argv[1]
data = json.loads(Path("/app/output/model_cards.json").read_text(encoding="utf-8"))
for row in data["cards"]:
    print(
        pack,
        row["model_id"],
        "bind_repairs=", row["bind_repairs"],
        "gaps_filled=", row["gaps_filled"],
        "eval_protocol=", row["eval_protocol"],
    )
PY
done

log "fix weave_n3: resolve tracker rows by seed_digest and clip corpora"
cat > /app/internal/weave_n3/resolve.go <<'EOF'
package weave_n3

import (
	"bufio"
	"encoding/json"
	"os"
	"path/filepath"

	"cardrebuild/artifactwire"
	"cardrebuild/flux_p2"
)

type ResolveResult struct {
	DatasetIDs     []string
	CollisionFixes int
	CorpusPrunes   int
}

func loadRows(root string) ([]artifactwire.TrackerRow, error) {
	path := filepath.Join(root, "tracker", "runs.jsonl")
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	var rows []artifactwire.TrackerRow
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		var row artifactwire.TrackerRow
		if err := json.Unmarshal(sc.Bytes(), &row); err != nil {
			continue
		}
		rows = append(rows, row)
	}
	return rows, sc.Err()
}

func runNameDupes(rows []artifactwire.TrackerRow, name string) int {
	n := 0
	for _, row := range rows {
		if row.RunName == name {
			n++
		}
	}
	return n
}

func ResolveRun(root string, _ string, seedDigest string) (ResolveResult, error) {
	rows, err := loadRows(root)
	if err != nil {
		return ResolveResult{}, err
	}
	for _, row := range rows {
		if row.SeedDigest != seedDigest {
			continue
		}
		fixes := 0
		if runNameDupes(rows, row.RunName) > 1 {
			fixes = 1
		}
		ids, prunes := flux_p2.ClipSpan(append([]string(nil), row.DatasetIDs...))
		return ResolveResult{
			DatasetIDs:     ids,
			CollisionFixes: fixes,
			CorpusPrunes:   prunes,
		}, nil
	}
	return ResolveResult{}, nil
}
EOF

log "fix latch_m2: bind sidecars by digest when filenames disagree with model id"
cat > /app/internal/latch_m2/op_k.go <<'EOF'
package latch_m2

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"

	"cardrebuild/artifactwire"
)

type LatchRow struct {
	ModelID string
	Step    int
	Repairs int
}

func OpK(root string, row artifactwire.DeployRow) (LatchRow, error) {
	dir := filepath.Join(root, "checkpoints")
	entries, err := os.ReadDir(dir)
	if err != nil {
		return LatchRow{}, err
	}
	var matched *artifactwire.Sidecar
	var matchedName string
	for _, ent := range entries {
		if ent.IsDir() || filepath.Ext(ent.Name()) != ".json" {
			continue
		}
		raw, err := os.ReadFile(filepath.Join(dir, ent.Name()))
		if err != nil {
			return LatchRow{}, err
		}
		var sc artifactwire.Sidecar
		if err := json.Unmarshal(raw, &sc); err != nil {
			continue
		}
		if strings.EqualFold(sc.SHA256, row.ExpectedSHA) {
			copy := sc
			matched = &copy
			matchedName = strings.TrimSuffix(ent.Name(), ".sidecar.json")
			break
		}
	}
	if matched == nil {
		pattern := filepath.Join(dir, row.ModelID+".sidecar.json")
		raw, err := os.ReadFile(pattern)
		if err != nil {
			return LatchRow{}, err
		}
		var sc artifactwire.Sidecar
		if err := json.Unmarshal(raw, &sc); err != nil {
			return LatchRow{}, err
		}
		matched = &sc
		matchedName = row.ModelID
	}
	repairs := 0
	if matchedName != row.ModelID {
		repairs = 1
	}
	if !strings.EqualFold(matched.SHA256, row.ExpectedSHA) {
		repairs = 0
	}
	return LatchRow{
		ModelID: row.ModelID,
		Step:    matched.Step,
		Repairs: repairs,
	}, nil
}

func LoadDeploy(root string) (artifactwire.DeployManifest, error) {
	raw, err := os.ReadFile(filepath.Join(root, "deploy.json"))
	if err != nil {
		return artifactwire.DeployManifest{}, err
	}
	var man artifactwire.DeployManifest
	if err := json.Unmarshal(raw, &man); err != nil {
		return artifactwire.DeployManifest{}, err
	}
	return man, nil
}
EOF

log "fix rank_p1: honor primary shard flag before alphabetical fallback"
cat > /app/internal/rank_p1/pick.go <<'EOF'
package rank_p1

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sort"

	"cardrebuild/artifactwire"
)

type PickResult struct {
	Protocol string
	Scores   map[string]float64
}

func PickPrimary(root, modelID string) (PickResult, error) {
	dir := filepath.Join(root, "eval", modelID)
	entries, err := os.ReadDir(dir)
	if err != nil {
		return PickResult{}, err
	}
	var shards []artifactwire.EvalShard
	var names []string
	for _, ent := range entries {
		if ent.IsDir() || filepath.Ext(ent.Name()) != ".json" {
			continue
		}
		raw, err := os.ReadFile(filepath.Join(dir, ent.Name()))
		if err != nil {
			return PickResult{}, err
		}
		var shard artifactwire.EvalShard
		if err := json.Unmarshal(raw, &shard); err != nil {
			continue
		}
		shards = append(shards, shard)
		names = append(names, ent.Name())
	}
	if len(shards) == 0 {
		return PickResult{}, nil
	}
	for idx := range shards {
		if shards[idx].Primary {
			return PickResult{
				Protocol: shards[idx].Protocol,
				Scores:   shards[idx].Scores,
			}, nil
		}
	}
	sort.Strings(names)
	for _, ent := range entries {
		if ent.Name() != names[0] {
			continue
		}
		raw, _ := os.ReadFile(filepath.Join(dir, ent.Name()))
		var shard artifactwire.EvalShard
		_ = json.Unmarshal(raw, &shard)
		return PickResult{Protocol: shard.Protocol, Scores: shard.Scores}, nil
	}
	return PickResult{}, nil
}
EOF

log "fix logscan backfill: merge family defaults when fragment numbering skips a slot"
cat > /app/logscan/backfill.go <<'EOF'
package logscan

import (
	"cardrebuild/artifactwire"
	"cardrebuild/span_g1"
)

// BackfillZeros merges family defaults into hyperparameter slots left unset
// after log fragment folding when fragment numbering skips a slot.
func BackfillZeros(hp *span_g1.HparamBlock, def artifactwire.FamilyDefaults, parts []Part) {
	gap := HasGap(parts)
	fill := func(slot *float64, val float64) {
		if (gap || *slot == 0) && *slot == 0 {
			*slot = val
			hp.GapsFilled++
		}
	}
	fill(&hp.LR, def.LR)
	fill(&hp.BatchSize, def.BatchSize)
	fill(&hp.Epochs, def.Epochs)
	fill(&hp.WeightDecay, def.WeightDecay)
}
EOF

log "fix driver digest: compact JSON for cards_digest"
python3 - <<'PY'
from pathlib import Path

path = Path("/app/internal/driver/run.go")
text = path.read_text(encoding="utf-8")

old_digest = "\traw, _ := json.MarshalIndent(clone, \"\", \"  \")"
new_digest = "\traw, _ := json.Marshal(clone)"
if old_digest not in text:
    raise SystemExit("driver digest anchor missing")
path.write_text(text.replace(old_digest, new_digest, 1), encoding="utf-8")
PY

log "rebuild and smoke alpha replay"
bash /app/scripts/build.sh
tb_pack=pack_alpha /app/bin/cardrebuild
test -s /app/output/model_cards.json

log "regression replay across fixture_index packs"
while IFS= read -r stem; do
  [[ -z "${stem}" || "${stem}" == \#* ]] && continue
  tb_pack="${stem}" /app/bin/cardrebuild
  test -s /app/output/model_cards.json
done < /app/docs/fixture_index.txt

log "done"
