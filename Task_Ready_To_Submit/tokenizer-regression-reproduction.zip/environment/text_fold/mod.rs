use unicode_normalization::UnicodeNormalization;

/// Pre-ingest text cleanup before token splitting.
pub fn normalize(raw: &str) -> String {
    let folded = raw.trim().to_ascii_lowercase();
    let nfkc: String = folded.nfkc().collect();
    nfkc.split_whitespace().collect::<Vec<_>>().join(" ")
}
