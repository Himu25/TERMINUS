Verifier-side helpers only.
