#[path = "../text_fold/mod.rs"]
pub mod text_fold;

#[path = "../text_lex/mod.rs"]
pub mod text_lex;

#[path = "../text_alias/mod.rs"]
pub mod text_alias;

#[path = "../text_pair/mod.rs"]
pub mod text_pair;

#[path = "../text_seal/mod.rs"]
pub mod text_seal;

pub mod bench_run;
pub mod corpus;
pub mod registry_paths;
pub mod scenario;
pub mod token_cfg;

pub use token_cfg::TokenCfg;
