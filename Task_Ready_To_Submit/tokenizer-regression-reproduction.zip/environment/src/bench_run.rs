use crate::text_fold;
use crate::text_lex;
use crate::text_alias;
use crate::text_pair;
use crate::text_seal;
use crate::scenario::ScenarioRow;
use crate::token_cfg::{self, TokenCfg};
use serde::Serialize;
use sha2::{Digest, Sha256};
use std::collections::HashMap;
use std::path::Path;

#[derive(Debug, Clone, Serialize)]
pub struct ScenarioStat {
    pub scenario_id: String,
    pub key_match: u32,
    pub embed_agreement: f64,
    pub legacy_preserved: u32,
    pub token_count: u32,
}

#[derive(Debug, Serialize)]
pub struct TokenReport {
    pub status: String,
    pub corpus_rows: usize,
    pub active_prep_profile: String,
    pub legacy_alias_rev: u32,
    pub scenarios_total: usize,
    pub unicode_parity_rate: f64,
    pub whitespace_parity_rate: f64,
    pub legacy_key_match_rate: f64,
    pub mean_embed_agreement: f64,
    pub collision_cases_resolved: u32,
    pub report_digest: String,
    pub scenarios: Vec<ScenarioStat>,
}

fn round4(v: f64) -> f64 {
    (v * 10000.0).round() / 10000.0
}

pub fn load_scenarios(path: &Path) -> Result<Vec<ScenarioRow>, String> {
    let raw = std::fs::read_to_string(path).map_err(|e| e.to_string())?;
    let mut out = Vec::new();
    for line in raw.lines() {
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        out.push(serde_json::from_str(line).map_err(|e| e.to_string())?);
    }
    Ok(out)
}

fn load_legacy_keys() -> HashMap<String, String> {
    let path = "/app/data/legacy_key_table.json";
    let Ok(raw) = std::fs::read_to_string(path) else {
        return HashMap::new();
    };
    let Ok(doc) = serde_json::from_str::<serde_json::Value>(&raw) else {
        return HashMap::new();
    };
    let mut out = HashMap::new();
    if let Some(obj) = doc.as_object() {
        for (k, v) in obj {
            if let Some(s) = v.as_str() {
                out.insert(k.clone(), s.to_string());
            }
        }
    }
    out
}

fn pipeline_tokens(raw: &str) -> Vec<String> {
    let prepped = text_fold::normalize(raw);
    let mut tokens = text_lex::tokens(&prepped);
    text_alias::apply(&mut tokens);
    tokens
}

fn embed_agreement(raw: &str) -> f64 {
    let tokens = pipeline_tokens(raw);
    let index = text_pair::vector_index(&tokens);
    let query = text_pair::vector_query(&tokens);
    if index.len() != query.len() || index.is_empty() {
        return 0.0;
    }
    let dot: f64 = index.iter().zip(query.iter()).map(|(a, b)| a * b).sum();
    let ni: f64 = index.iter().map(|x| x * x).sum::<f64>().sqrt();
    let nq: f64 = query.iter().map(|x| x * x).sum::<f64>().sqrt();
    if ni < 1e-9 || nq < 1e-9 {
        return 0.0;
    }
    round4((dot / (ni * nq)).max(0.0))
}

fn digest_payload(report: &TokenReport) -> String {
    let stub = TokenReport {
        status: report.status.clone(),
        corpus_rows: report.corpus_rows,
        active_prep_profile: report.active_prep_profile.clone(),
        legacy_alias_rev: report.legacy_alias_rev,
        scenarios_total: report.scenarios_total,
        unicode_parity_rate: report.unicode_parity_rate,
        whitespace_parity_rate: report.whitespace_parity_rate,
        legacy_key_match_rate: report.legacy_key_match_rate,
        mean_embed_agreement: report.mean_embed_agreement,
        collision_cases_resolved: report.collision_cases_resolved,
        report_digest: String::new(),
        scenarios: report.scenarios.clone(),
    };
    serde_json::to_string(&stub).unwrap_or_default()
}

pub fn run(cfg: &TokenCfg, cases: &[ScenarioRow]) -> Result<TokenReport, String> {
    let legacy = load_legacy_keys();
    let corpus = crate::corpus::load("/app/data/corpus_default.json")?;
    let mut stats = Vec::new();
    let mut unicode_ok = 0usize;
    let mut unicode_total = 0usize;
    let mut ws_ok = 0usize;
    let mut ws_total = 0usize;
    let mut legacy_ok = 0usize;
    let mut legacy_total = 0usize;
    let mut embed_sum = 0.0f64;
    let mut collision_resolved = 0u32;

    for case in cases {
        let tokens = pipeline_tokens(&case.raw_text);
        let live_key = text_seal::cache_key(&tokens);
        let expected = legacy.get(&case.scenario_id).cloned().unwrap_or_default();
        let key_match = if !expected.is_empty() && live_key == expected {
            1
        } else {
            0
        };
        let embed = embed_agreement(&case.raw_text);
        let legacy_preserved = if case.pack == "legacy" && key_match == 1 {
            1
        } else if case.pack == "legacy" {
            0
        } else {
            key_match
        };
        if case.pack == "unicode" {
            unicode_total += 1;
            if key_match == 1 {
                unicode_ok += 1;
            }
        }
        if case.pack == "whitespace" {
            ws_total += 1;
            if key_match == 1 {
                ws_ok += 1;
            }
        }
        if case.pack == "legacy" || case.pack == "collision" {
            legacy_total += 1;
            if key_match == 1 {
                legacy_ok += 1;
            }
        }
        if case.pack == "collision" && key_match == 1 && embed >= cfg.collision_embed_floor {
            collision_resolved += 1;
        }
        embed_sum += embed;
        stats.push(ScenarioStat {
            scenario_id: case.scenario_id.clone(),
            key_match,
            embed_agreement: embed,
            legacy_preserved,
            token_count: tokens.len() as u32,
        });
    }

    let unicode_rate = if unicode_total == 0 {
        0.0
    } else {
        round4(unicode_ok as f64 / unicode_total as f64)
    };
    let ws_rate = if ws_total == 0 {
        0.0
    } else {
        round4(ws_ok as f64 / ws_total as f64)
    };
    let legacy_rate = if legacy_total == 0 {
        0.0
    } else {
        round4(legacy_ok as f64 / legacy_total as f64)
    };
    let mean_embed = if cases.is_empty() {
        0.0
    } else {
        round4(embed_sum / cases.len() as f64)
    };

    let mut status = cfg.pass_status.clone();
    if unicode_rate < cfg.unicode_parity_floor
        || ws_rate < cfg.whitespace_parity_floor
        || legacy_rate < cfg.legacy_key_match_floor
        || mean_embed < cfg.mean_embed_agreement_floor
        || collision_resolved < cfg.min_collision_cases_resolved
    {
        status = "fail".to_string();
    }

    let mut report = TokenReport {
        status,
        corpus_rows: corpus.rows.len(),
        active_prep_profile: token_cfg::manifest_prep_profile(),
        legacy_alias_rev: token_cfg::manifest_alias_rev(),
        scenarios_total: cases.len(),
        unicode_parity_rate: unicode_rate,
        whitespace_parity_rate: ws_rate,
        legacy_key_match_rate: legacy_rate,
        mean_embed_agreement: mean_embed,
        collision_cases_resolved: collision_resolved,
        report_digest: String::new(),
        scenarios: stats,
    };
    let raw = digest_payload(&report);
    let mut hasher = Sha256::new();
    hasher.update(raw.as_bytes());
    report.report_digest = format!("{:x}", hasher.finalize());
    Ok(report)
}
