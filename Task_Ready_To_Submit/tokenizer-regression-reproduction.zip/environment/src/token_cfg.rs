use serde::Deserialize;
use std::fs;
use std::path::Path;

#[derive(Debug, Clone, Deserialize)]
pub struct TokenCfg {
    pub pass_status: String,
    pub unicode_parity_floor: f64,
    pub whitespace_parity_floor: f64,
    pub legacy_key_match_floor: f64,
    pub mean_embed_agreement_floor: f64,
    pub per_scenario_embed_floor: f64,
    pub collision_embed_floor: f64,
    pub min_collision_cases_resolved: u32,
    pub nfkc_cafe_embed_floor: f64,
    pub nbsp_invoice_key_match: u32,
    pub legacy_wifi_preserved: u32,
    pub tr_multiscript_embed_floor: f64,
}

impl TokenCfg {
    pub fn load(path: &str) -> Result<Self, String> {
        let raw = fs::read_to_string(path).map_err(|e| e.to_string())?;
        let mut cfg = TokenCfg {
            pass_status: "ok".to_string(),
            unicode_parity_floor: 0.95,
            whitespace_parity_floor: 0.95,
            legacy_key_match_floor: 0.95,
            mean_embed_agreement_floor: 0.95,
            per_scenario_embed_floor: 0.99,
            collision_embed_floor: 0.99,
            min_collision_cases_resolved: 3,
            nfkc_cafe_embed_floor: 0.99,
            nbsp_invoice_key_match: 1,
            legacy_wifi_preserved: 1,
            tr_multiscript_embed_floor: 0.99,
        };
        for line in raw.lines() {
            let line = line.trim();
            if line.is_empty() || line.starts_with('#') {
                continue;
            }
            let Some((key, val)) = line.split_once('=') else {
                continue;
            };
            let key = key.trim();
            let val = val.trim();
            match key {
                "pass_status" => cfg.pass_status = val.to_string(),
                "unicode_parity_floor" | "whitespace_parity_floor"
                | "legacy_key_match_floor" | "mean_embed_agreement_floor"
                | "per_scenario_embed_floor" | "collision_embed_floor"
                | "nfkc_cafe_embed_floor" | "tr_multiscript_embed_floor" => {
                    cfg_set_f64(&mut cfg, key, val);
                }
                "min_collision_cases_resolved" | "nbsp_invoice_key_match"
                | "legacy_wifi_preserved" => {
                    cfg_set_u32(&mut cfg, key, val);
                }
                _ => {}
            }
        }
        Ok(cfg)
    }
}

fn cfg_set_f64(cfg: &mut TokenCfg, key: &str, val: &str) {
    let Ok(v) = val.parse::<f64>() else {
        return;
    };
    match key {
        "unicode_parity_floor" => cfg.unicode_parity_floor = v,
        "whitespace_parity_floor" => cfg.whitespace_parity_floor = v,
        "legacy_key_match_floor" => cfg.legacy_key_match_floor = v,
        "mean_embed_agreement_floor" => cfg.mean_embed_agreement_floor = v,
        "per_scenario_embed_floor" => cfg.per_scenario_embed_floor = v,
        "collision_embed_floor" => cfg.collision_embed_floor = v,
        "nfkc_cafe_embed_floor" => cfg.nfkc_cafe_embed_floor = v,
        "tr_multiscript_embed_floor" => cfg.tr_multiscript_embed_floor = v,
        _ => {}
    }
}

fn cfg_set_u32(cfg: &mut TokenCfg, key: &str, val: &str) {
    let Ok(v) = val.parse::<u32>() else {
        return;
    };
    match key {
        "min_collision_cases_resolved" => cfg.min_collision_cases_resolved = v,
        "nbsp_invoice_key_match" => cfg.nbsp_invoice_key_match = v,
        "legacy_wifi_preserved" => cfg.legacy_wifi_preserved = v,
        _ => {}
    }
}

pub fn manifest_prep_profile() -> String {
    let path = Path::new("/app/registry/prep_manifest.json");
    let Ok(raw) = fs::read_to_string(path) else {
        return "unknown".to_string();
    };
    let Ok(doc) = serde_json::from_str::<serde_json::Value>(&raw) else {
        return "unknown".to_string();
    };
    doc.get("prep_profile")
        .and_then(|v| v.as_str())
        .unwrap_or("unknown")
        .to_string()
}

pub fn manifest_alias_rev() -> u32 {
    let path = Path::new("/app/registry/prep_manifest.json");
    let Ok(raw) = fs::read_to_string(path) else {
        return 0;
    };
    let Ok(doc) = serde_json::from_str::<serde_json::Value>(&raw) else {
        return 0;
    };
    doc.get("legacy_alias_rev")
        .and_then(|v| v.as_u64())
        .unwrap_or(0) as u32
}
