use serde::Deserialize;

#[derive(Debug, Clone, Deserialize)]
pub struct ScenarioRow {
    pub scenario_id: String,
    pub raw_text: String,
    pub pack: String,
}
