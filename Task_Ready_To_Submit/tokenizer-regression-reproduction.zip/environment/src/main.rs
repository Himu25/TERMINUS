use std::env;
use std::path::PathBuf;
use token_regression::bench_run;
use token_regression::token_cfg::TokenCfg;

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() != 3 {
        eprintln!("usage: ingest_report <scenario_specs.jsonl> <output.json>");
        std::process::exit(2);
    }
    let cfg = TokenCfg::load("/app/config/regression.toml").expect("load cfg");
    let cases = bench_run::load_scenarios(PathBuf::from(&args[1]).as_path())
        .expect("load scenarios");
    let report = bench_run::run(&cfg, &cases).expect("bench run");
    let out = serde_json::to_string_pretty(&report).expect("serialize");
    std::fs::write(&args[2], out).expect("write report");
}
