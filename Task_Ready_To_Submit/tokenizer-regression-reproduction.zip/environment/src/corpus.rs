use serde::Deserialize;

#[derive(Debug, Clone, Deserialize)]
pub struct CorpusDoc {
    pub doc_id: String,
    pub text: String,
}

#[derive(Debug, Clone, Deserialize)]
pub struct CorpusFile {
    pub rows: Vec<CorpusDoc>,
}

pub fn load(path: &str) -> Result<CorpusFile, String> {
    let raw = std::fs::read_to_string(path).map_err(|e| e.to_string())?;
    serde_json::from_str(&raw).map_err(|e| e.to_string())
}
