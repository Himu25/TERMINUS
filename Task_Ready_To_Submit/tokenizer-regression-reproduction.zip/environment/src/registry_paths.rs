use std::fs;
use std::path::Path;

fn manifest_doc() -> Option<serde_json::Value> {
    let raw = fs::read_to_string("/app/registry/prep_manifest.json").ok()?;
    serde_json::from_str(&raw).ok()
}

/// Active legacy alias table filename from the prep manifest.
pub fn active_legacy_alias_file() -> String {
    manifest_doc()
        .and_then(|doc| doc.get("legacy_alias_active").and_then(|v| v.as_str().map(str::to_string)))
        .unwrap_or_else(|| "legacy_aliases_r3.txt".to_string())
}

/// Active merge rule table filename from the prep manifest.
pub fn active_merge_rules_file() -> String {
    manifest_doc()
        .and_then(|doc| doc.get("merge_rules_active").and_then(|v| v.as_str().map(str::to_string)))
        .unwrap_or_else(|| "merge_rules_r3.txt".to_string())
}

/// Resolve a registry filename under `/app/registry`.
pub fn registry_path(name: &str) -> String {
    Path::new("/app/registry")
        .join(name)
        .to_string_lossy()
        .into_owned()
}
