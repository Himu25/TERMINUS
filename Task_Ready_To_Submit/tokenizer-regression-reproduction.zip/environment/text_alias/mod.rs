use std::collections::HashMap;
use std::fs;
use std::sync::OnceLock;

static ALIAS: OnceLock<HashMap<String, String>> = OnceLock::new();

fn alias_path() -> &'static str {
    "/app/registry/legacy_aliases_r3.txt"
}

fn load_aliases() -> HashMap<String, String> {
    let mut out = HashMap::new();
    let Ok(body) = fs::read_to_string(alias_path()) else {
        return out;
    };
    for line in body.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.split_whitespace().collect();
        if parts.len() >= 2 {
            let src = parts[..parts.len() - 1].join(" ");
            let dst = parts[parts.len() - 1].to_string();
            out.insert(src, dst);
        }
    }
    out
}

fn alias_map() -> &'static HashMap<String, String> {
    ALIAS.get_or_init(load_aliases)
}

fn apply_single(tokens: &mut [String], table: &HashMap<String, String>) {
    for tok in tokens.iter_mut() {
        if let Some(canonical) = table.get(tok.as_str()) {
            *tok = canonical.clone();
        }
    }
}

/// Rewrite token spans using the active span map.
pub fn apply(tokens: &mut Vec<String>) {
    let table = alias_map();
    apply_single(tokens, table);
}
