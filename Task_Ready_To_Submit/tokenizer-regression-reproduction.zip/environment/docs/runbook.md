Run `/app/tools/run_bench.sh` after rebuilding `/app/bin/ingest_report`. Floors in `/app/config/regression.toml`.
