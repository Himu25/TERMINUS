# Text ingest stack

Rust crate rooted at `/app`. Pipeline stages are sibling directories included via `#[path]` from `src/lib.rs` together with `registry_paths`.

## Bench driver

`/app/bin/ingest_report` reads a JSONL scenario pack and writes `/app/output/tokenizer_regression_bench.json`. `/app/tools/run_bench.sh` runs the default pack at `/app/data/scenario_specs.jsonl`.

Release builds use `CARGO_TARGET_DIR=/app/output/cargo-target`.

## Pipeline

The fold stage prepares raw text. The lex stage tokenizes with merge rules and stopword filtering. The alias stage rewrites multi-token spans using the legacy alias table. The seal stage fingerprints the final token stream. The pair stage builds separate index and query vectors over the same tokens.

Active merge and alias tables are named in `/app/registry/prep_manifest.json`. `registry_paths` resolves those filenames; ingest stages must load the active revision, not a stale default.

## Report schema

Top-level keys: status, corpus_rows, active_prep_profile, legacy_alias_rev, scenarios_total, unicode_parity_rate, whitespace_parity_rate, legacy_key_match_rate, mean_embed_agreement, collision_cases_resolved, report_digest, scenarios.

Each scenarios row: scenario_id, key_match, embed_agreement, legacy_preserved, token_count.

report_digest is 64 lowercase hex characters over compact JSON of every other field with report_digest cleared.

## Legacy cache key contract

V1 cache keys hash the final token stream joined with ASCII unit separator `0x1f` using SHA-256 lowercase hex. Expected keys for regression rows live in `/app/data/legacy_key_table.json`.

## Index-query vectors

Index and query vectors are built with the same slot layout; the query path must use the reference salt expected by the bench scorer. Collision pack rows count toward collision_cases_resolved only when both key_match and embed_agreement clear collision_embed_floor in regression.toml.

## Floors

Numeric guardrails are in `/app/config/regression.toml`, including mean_embed_agreement_floor, per_scenario_embed_floor, collision_embed_floor, and pack-specific scenario floors.
