#!/bin/bash
set -euo pipefail
mkdir -p /app/output
/app/bin/ingest_report \
  /app/data/scenario_specs.jsonl \
  /app/output/tokenizer_regression_bench.json
