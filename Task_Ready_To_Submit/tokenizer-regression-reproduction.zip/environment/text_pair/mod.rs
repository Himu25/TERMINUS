use sha2::{Digest, Sha256};

const DIM: usize = 32;

fn slot_hash(token: &str, salt: u8) -> u64 {
    let mut hasher = Sha256::new();
    hasher.update(token.as_bytes());
    hasher.update([salt]);
    let digest = hasher.finalize();
    u64::from_le_bytes(digest[..8].try_into().unwrap())
}

fn fill(tokens: &[String], salt: u8) -> Vec<f64> {
    let mut out = vec![0.0f64; DIM];
    for (idx, tok) in tokens.iter().enumerate() {
        let h = slot_hash(tok, salt);
        let slot = h as usize % DIM;
        let sign = if h & 1 == 0 { 1.0 } else { -1.0 };
        let weight = (h >> 8) as f64 / u64::MAX as f64;
        out[slot] += sign * weight;
        if idx % 2 == 1 {
            out[(slot + 1) % DIM] += weight * 0.25;
        }
    }
    let norm: f64 = out.iter().map(|x| x * x).sum::<f64>().sqrt();
    if norm > 1e-9 {
        for v in &mut out {
            *v /= norm;
        }
    }
    out
}

pub fn vector_index(tokens: &[String]) -> Vec<f64> {
    fill(tokens, 0)
}

pub fn vector_query(tokens: &[String]) -> Vec<f64> {
    fill(tokens, 2)
}
