"""Validate tokenizer_regression_bench.json after ingest pipeline repair."""

from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "tokenizer_regression_bench.json"
CFG = APP / "config" / "regression.toml"
SPECS = APP / "data" / "scenario_specs.jsonl"
CARGO_TARGET = APP / "output" / "cargo-target"

REPORT_KEYS = frozenset(
    {
        "status",
        "corpus_rows",
        "active_prep_profile",
        "legacy_alias_rev",
        "scenarios_total",
        "unicode_parity_rate",
        "whitespace_parity_rate",
        "legacy_key_match_rate",
        "mean_embed_agreement",
        "collision_cases_resolved",
        "report_digest",
        "scenarios",
    }
)
SCENARIO_KEYS = frozenset(
    {"scenario_id", "key_match", "embed_agreement", "legacy_preserved", "token_count"}
)


def _pass_status() -> str:
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line.startswith("pass_status"):
            return line.split("=", 1)[1].strip()
    return "ok"


def _parse_cfg() -> dict[str, float | int]:
    cfg: dict[str, float | int] = {
        "unicode_parity_floor": 0.95,
        "whitespace_parity_floor": 0.95,
        "legacy_key_match_floor": 0.95,
        "mean_embed_agreement_floor": 0.95,
        "per_scenario_embed_floor": 0.99,
        "collision_embed_floor": 0.99,
        "min_collision_cases_resolved": 3,
        "nfkc_cafe_embed_floor": 0.99,
        "nbsp_invoice_key_match": 1,
        "legacy_wifi_preserved": 1,
        "tr_multiscript_embed_floor": 0.99,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key.endswith("_floor"):
            cfg[key] = float(val)
        elif key.startswith("min_") or key.endswith("_match") or key.endswith("_preserved"):
            cfg[key] = int(float(val))
    return cfg


def _round4(value: float) -> float:
    return round(value * 10000 + 0.5) / 10000


def _digest_payload(report: dict) -> dict:
    return {
        "status": report["status"],
        "corpus_rows": report["corpus_rows"],
        "active_prep_profile": report["active_prep_profile"],
        "legacy_alias_rev": report["legacy_alias_rev"],
        "scenarios_total": report["scenarios_total"],
        "unicode_parity_rate": report["unicode_parity_rate"],
        "whitespace_parity_rate": report["whitespace_parity_rate"],
        "legacy_key_match_rate": report["legacy_key_match_rate"],
        "mean_embed_agreement": report["mean_embed_agreement"],
        "collision_cases_resolved": report["collision_cases_resolved"],
        "report_digest": "",
        "scenarios": report["scenarios"],
    }


def _expected_digest(report: dict) -> str:
    raw = json.dumps(_digest_payload(report), separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _rebuild_token_bench(env: dict[str, str] | None = None) -> None:
    build_env = dict(env or os.environ.copy())
    build_env["CARGO_TARGET_DIR"] = str(CARGO_TARGET)
    subprocess.run(
        ["cargo", "build", "--release", "--manifest-path", str(APP / "Cargo.toml")],
        cwd=APP,
        env=build_env,
        check=True,
        capture_output=True,
        text=True,
    )
    subprocess.run(
        [
            "install",
            "-m",
            "0755",
            str(CARGO_TARGET / "release" / "ingest_report"),
            "/app/bin/ingest_report",
        ],
        check=True,
        capture_output=True,
        text=True,
    )


def _run_bench(out_path: Path) -> None:
    subprocess.run(
        [
            "/app/bin/ingest_report",
            SPECS.as_posix(),
            out_path.as_posix(),
        ],
        check=True,
        capture_output=True,
        text=True,
    )


def _load_report() -> dict:
    return json.loads(OUT.read_text(encoding="utf-8"))


def _scenario(report: dict, scenario_id: str) -> dict:
    for row in report["scenarios"]:
        if row["scenario_id"] == scenario_id:
            return row
    raise KeyError(scenario_id)


@pytest.fixture(scope="session", autouse=True)
def _session_bench() -> None:
    _rebuild_token_bench()
    _run_bench(OUT)


def test_default_pass_status() -> None:
    """Default bench run reports the configured pass status."""
    assert (APP / "bin" / "ingest_report").is_file()
    assert os.access(APP / "bin" / "ingest_report", os.X_OK)
    report = _load_report()
    assert report["status"] == _pass_status()


def test_corpus_rows_populated() -> None:
    """Corpus row count reflects the default ingest corpus."""
    report = _load_report()
    assert report["corpus_rows"] >= 20


def test_report_schema_and_digest() -> None:
    """Report keys and digest match the architecture contract."""
    report = _load_report()
    assert set(report) == REPORT_KEYS
    assert re.fullmatch(r"[0-9a-f]{64}", report["report_digest"])
    assert report["report_digest"] == _expected_digest(report)


def test_manifest_profile_alignment() -> None:
    """Active prep profile and alias revision track prep_manifest.json."""
    manifest = json.loads((APP / "registry" / "prep_manifest.json").read_text())
    report = _load_report()
    assert report["active_prep_profile"] == manifest["prep_profile"]
    assert report["legacy_alias_rev"] == manifest["legacy_alias_rev"]


def test_unicode_parity_floor() -> None:
    """Unicode scenario pack meets the configured parity floor."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["unicode_parity_rate"] >= cfg["unicode_parity_floor"]


def test_whitespace_parity_floor() -> None:
    """Whitespace scenario pack meets the configured parity floor."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["whitespace_parity_rate"] >= cfg["whitespace_parity_floor"]


def test_legacy_key_match_floor() -> None:
    """Legacy cache keys match v1 expectations across regression rows."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["legacy_key_match_rate"] >= cfg["legacy_key_match_floor"]


def test_mean_embed_agreement_floor() -> None:
    """Index and query embedding lanes stay aligned on average."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["mean_embed_agreement"] >= cfg["mean_embed_agreement_floor"]


def test_collision_cases_resolved() -> None:
    """Multilingual collision scenarios recover expected keys."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["collision_cases_resolved"] >= cfg["min_collision_cases_resolved"]


def test_scenarios_total_matches_specs() -> None:
    """Scenario row count matches the default JSONL spec pack."""
    report = _load_report()
    spec_lines = [ln for ln in SPECS.read_text(encoding="utf-8").splitlines() if ln.strip()]
    assert report["scenarios_total"] == len(spec_lines)
    for row in report["scenarios"]:
        assert set(row) == SCENARIO_KEYS


def test_nfkc_cafe_scenario() -> None:
    """Named unicode row s_nfkc_cafe preserves keys and embed agreement."""
    cfg = _parse_cfg()
    report = _load_report()
    row = _scenario(report, "s_nfkc_cafe")
    assert row["key_match"] == 1
    assert row["embed_agreement"] >= cfg["nfkc_cafe_embed_floor"]


def test_nbsp_invoice_scenario() -> None:
    """Named whitespace row s_nbsp_invoice matches the legacy cache key."""
    cfg = _parse_cfg()
    report = _load_report()
    row = _scenario(report, "s_nbsp_invoice")
    assert row["key_match"] >= cfg["nbsp_invoice_key_match"]


def test_legacy_wifi_scenario() -> None:
    """Named legacy row s_legacy_wifi keeps backward-compatible aliases."""
    cfg = _parse_cfg()
    report = _load_report()
    row = _scenario(report, "s_legacy_wifi")
    assert row["legacy_preserved"] >= cfg["legacy_wifi_preserved"]


def test_tr_multiscript_scenario() -> None:
    """Named multilingual row s_tr_multiscript keeps embed agreement."""
    cfg = _parse_cfg()
    report = _load_report()
    row = _scenario(report, "s_tr_multiscript")
    assert row["embed_agreement"] >= cfg["tr_multiscript_embed_floor"]


def test_collision_rows_pair_key_and_embed() -> None:
    """Collision pack rows only count when keys match and embed lanes agree."""
    cfg = _parse_cfg()
    bar = cfg["collision_embed_floor"]
    report = _load_report()
    resolved = 0
    for row in report["scenarios"]:
        if not row["scenario_id"].startswith("s_collision_"):
            continue
        if row["key_match"] == 1 and row["embed_agreement"] >= bar:
            resolved += 1
        elif row["key_match"] == 1:
            assert row["embed_agreement"] < bar
    assert resolved == report["collision_cases_resolved"]


def test_mean_embed_not_saturated() -> None:
    """Index and query vectors align on the default pack without collapsing to zero."""
    cfg = _parse_cfg()
    report = _load_report()
    embeds = [row["embed_agreement"] for row in report["scenarios"]]
    assert max(embeds) <= 1.0
    assert min(embeds) >= cfg["per_scenario_embed_floor"]


def test_deterministic_default_run() -> None:
    """Repeated default bench runs produce byte-identical output."""
    tmp = APP / "output" / "tokenizer_regression_bench_rerun.json"
    _run_bench(tmp)
    assert OUT.read_bytes() == tmp.read_bytes()


def test_unicode_pack_fixture() -> None:
    """Verifier unicode fixture pack meets parity floors."""
    fixture = Path(__file__).resolve().parent / "fixtures" / "unicode_pack.jsonl"
    out = APP / "output" / "bench_unicode_pack.json"
    subprocess.run(
        ["/app/bin/ingest_report", fixture.as_posix(), out.as_posix()],
        check=True,
        capture_output=True,
        text=True,
    )
    report = json.loads(out.read_text(encoding="utf-8"))
    assert report["unicode_parity_rate"] >= _parse_cfg()["unicode_parity_floor"]


def test_whitespace_pack_fixture() -> None:
    """Verifier whitespace fixture pack meets parity floors."""
    fixture = Path(__file__).resolve().parent / "fixtures" / "whitespace_pack.jsonl"
    out = APP / "output" / "bench_whitespace_pack.json"
    subprocess.run(
        ["/app/bin/ingest_report", fixture.as_posix(), out.as_posix()],
        check=True,
        capture_output=True,
        text=True,
    )
    report = json.loads(out.read_text(encoding="utf-8"))
    assert report["whitespace_parity_rate"] >= _parse_cfg()["whitespace_parity_floor"]
