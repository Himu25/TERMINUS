"""Harness-owned v1 legacy cache-key contract (tests only)."""

from __future__ import annotations

import hashlib
import json
import math
import unicodedata
from pathlib import Path

_FIXTURES = Path(__file__).resolve().parent / "fixtures"
_REGISTRY = _FIXTURES / "registry"

_INVISIBLE = frozenset("\u200b\u200c\u200d\ufeff")


def _strip_invisibles(raw: str) -> str:
    return "".join(ch for ch in raw if ch not in _INVISIBLE)


def fold_text(raw: str) -> str:
    """NFKC fold with invisible stripping (oracle text_fold contract)."""
    nfkc = unicodedata.normalize("NFKC", raw)
    cleaned = _strip_invisibles(nfkc)
    return " ".join(cleaned.casefold().split())


def _load_alias_table(path: Path) -> dict[str, str]:
    table: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) >= 2:
            table[" ".join(parts[:-1])] = parts[-1]
    return table


def _load_merge_rules(path: Path) -> list[str]:
    rules: list[str] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            rules.append(line)
    return rules


def _stopwords() -> frozenset[str]:
    raw = (_REGISTRY / "stopwords.txt").read_text(encoding="utf-8")
    return frozenset(tok.strip().lower() for tok in raw.split() if tok.strip())


def _norm_spaces(raw: str) -> str:
    out: list[str] = []
    prev_space = False
    for ch in raw:
        if ch.isspace():
            if not prev_space:
                out.append(" ")
                prev_space = True
        else:
            out.append(ch)
            prev_space = False
    return "".join(out).strip()


def _split_basic(raw: str) -> list[str]:
    return [part for part in _norm_spaces(raw).split(" ") if part]


def _apply_merges(tokens: list[str], merges: list[str]) -> list[str]:
    for pair in merges:
        parts = pair.split()
        if len(parts) < 3:
            continue
        dst = parts[-1]
        out: list[str] = []
        idx = 0
        while idx < len(tokens):
            if (
                idx + 1 < len(tokens)
                and tokens[idx] == parts[0]
                and tokens[idx + 1] == parts[1]
            ):
                out.append(dst)
                idx += 2
            else:
                out.append(tokens[idx])
                idx += 1
        tokens = out
    return tokens


def _apply_alias(tokens: list[str], table: dict[str, str]) -> list[str]:
    idx = 0
    while idx < len(tokens):
        matched = False
        for src, dst in table.items():
            parts = src.split()
            if not parts or idx + len(parts) > len(tokens):
                continue
            if tokens[idx : idx + len(parts)] == parts:
                tokens[idx : idx + len(parts)] = [dst]
                matched = True
                break
        if matched:
            continue
        if tokens[idx] in table:
            tokens[idx] = table[tokens[idx]]
        idx += 1
    return tokens


def tokenize(
    raw_text: str,
    *,
    alias_file: str = "legacy_aliases_r6.txt",
    merge_file: str = "merge_rules_r6.txt",
) -> list[str]:
    """Token stream using harness-owned registry fixtures."""
    prepped = fold_text(raw_text)
    merges = _load_merge_rules(_REGISTRY / merge_file)
    aliases = _load_alias_table(_REGISTRY / alias_file)
    stops = _stopwords()
    tokens = _apply_merges(_split_basic(prepped), merges)
    tokens = [tok for tok in tokens if tok not in stops]
    return _apply_alias(tokens, aliases)


def legacy_cache_key(tokens: list[str]) -> str:
    """V1 cache key: SHA-256 lowercase hex over tokens joined with ASCII US (0x1f)."""
    joined = "\x1f".join(tokens)
    return hashlib.sha256(joined.encode("utf-8")).hexdigest()


def v1_cache_key(
    raw_text: str,
    *,
    alias_file: str = "legacy_aliases_r6.txt",
    merge_file: str = "merge_rules_r6.txt",
) -> str:
    return legacy_cache_key(tokenize(raw_text, alias_file=alias_file, merge_file=merge_file))


def _slot_hash(token: str, salt: int) -> int:
    digest = hashlib.sha256(token.encode("utf-8") + bytes([salt])).digest()
    return int.from_bytes(digest[:8], "little")


def _fill_vector(tokens: list[str], salt: int) -> list[float]:
    dim = 32
    out = [0.0] * dim
    for idx, tok in enumerate(tokens):
        h = _slot_hash(tok, salt)
        slot = (h + idx) % dim
        sign = 1.0 if h & 1 == 0 else -1.0
        weight = (h >> 8) / float(2**64 - 1)
        out[slot] += sign * weight
    norm = math.sqrt(sum(v * v for v in out))
    if norm > 1e-9:
        out = [v / norm for v in out]
    return out


def embed_agreement(tokens: list[str]) -> float:
    """Index/query vectors both use salt 0 (oracle text_pair contract)."""
    index = _fill_vector(tokens, 0)
    query = _fill_vector(tokens, 0)
    dot = sum(a * b for a, b in zip(index, query, strict=True))
    ni = math.sqrt(sum(v * v for v in index))
    nq = math.sqrt(sum(v * v for v in query))
    if ni < 1e-9 or nq < 1e-9:
        return 0.0
    return round(max(0.0, dot / (ni * nq)) * 10000 + 0.5) / 10000


def load_default_scenarios() -> list[dict[str, str]]:
    path = _FIXTURES / "default_scenario_specs.jsonl"
    rows: list[dict[str, str]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            rows.append(json.loads(line))
    return rows


def scenario_v1_keys() -> dict[str, str]:
    return {
        row["scenario_id"]: v1_cache_key(row["raw_text"])
        for row in load_default_scenarios()
    }
