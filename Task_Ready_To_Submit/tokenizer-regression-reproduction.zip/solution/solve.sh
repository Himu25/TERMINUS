#!/bin/bash
set -euo pipefail

log() { printf '[oracle] %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

log "preflight: tokenizer regression workspace"
require_file /app/Cargo.toml
require_file /app/config/regression.toml
require_file /app/registry/prep_manifest.json
require_file /app/data/scenario_specs.jsonl
require_file "${ROOT_DIR}/oracle/text_fold.rs"
require_file "${ROOT_DIR}/oracle/text_lex.rs"
require_file "${ROOT_DIR}/oracle/text_alias.rs"
require_file "${ROOT_DIR}/oracle/text_seal.rs"
require_file "${ROOT_DIR}/oracle/text_pair.rs"
mkdir -p /app/bin /app/output

log "survey: manifest registry layout"
python3 - <<'PY'
import json
from pathlib import Path
manifest = json.loads(Path("/app/registry/prep_manifest.json").read_text())
print("prep_profile", manifest.get("prep_profile"))
print("legacy_alias_rev", manifest.get("legacy_alias_rev"))
print("legacy_alias_active", manifest.get("legacy_alias_active"))
print("merge_rules_active", manifest.get("merge_rules_active"))
for line in Path("/app/config/regression.toml").read_text().splitlines():
    if "floor" in line or "collision" in line or "parity" in line:
        print(line.strip())
PY

log "restore text fold stage"
cp "${ROOT_DIR}/oracle/text_fold.rs" /app/text_fold/mod.rs

log "restore text lex stage with manifest merge rules"
cp "${ROOT_DIR}/oracle/text_lex.rs" /app/text_lex/mod.rs

log "restore text alias stage from manifest alias table"
cp "${ROOT_DIR}/oracle/text_alias.rs" /app/text_alias/mod.rs

log "restore stream seal separator contract"
cp "${ROOT_DIR}/oracle/text_seal.rs" /app/text_seal/mod.rs

log "restore index-query pair salts and slot layout"
cp "${ROOT_DIR}/oracle/text_pair.rs" /app/text_pair/mod.rs

log "rebuild ingest report binary"
export CARGO_TARGET_DIR=/app/output/cargo-target
cd /app
cargo build --release --manifest-path /app/Cargo.toml
install -m 0755 /app/output/cargo-target/release/ingest_report /app/bin/ingest_report

log "write regression bench report"
bash /app/tools/run_bench.sh

log "post-run validation against regression.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg = {}
for line in Path("/app/config/regression.toml").read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    key, val = line.split("=", 1)
    key, val = key.strip(), val.strip()
    if key.endswith("_floor"):
        cfg[key] = float(val)
    elif key.startswith("min_") or key.endswith("_match") or key.endswith("_preserved"):
        cfg[key] = int(float(val))

report = json.loads(Path("/app/output/tokenizer_regression_bench.json").read_text())
assert report["status"] == "ok", report
assert report["unicode_parity_rate"] >= cfg["unicode_parity_floor"], report
assert report["whitespace_parity_rate"] >= cfg["whitespace_parity_floor"], report
assert report["legacy_key_match_rate"] >= cfg["legacy_key_match_floor"], report
assert report["mean_embed_agreement"] >= cfg["mean_embed_agreement_floor"], report
assert report["collision_cases_resolved"] >= cfg["min_collision_cases_resolved"], report
nfkc = next(s for s in report["scenarios"] if s["scenario_id"] == "s_nfkc_cafe")
assert nfkc["embed_agreement"] >= cfg["nfkc_cafe_embed_floor"], nfkc
nbsp = next(s for s in report["scenarios"] if s["scenario_id"] == "s_nbsp_invoice")
assert nbsp["key_match"] >= cfg["nbsp_invoice_key_match"], nbsp
wifi = next(s for s in report["scenarios"] if s["scenario_id"] == "s_legacy_wifi")
assert wifi["legacy_preserved"] >= cfg["legacy_wifi_preserved"], wifi
tr = next(s for s in report["scenarios"] if s["scenario_id"] == "s_tr_multiscript")
assert tr["embed_agreement"] >= cfg["tr_multiscript_embed_floor"], tr
for row in report["scenarios"]:
    if row["scenario_id"].startswith("s_collision_"):
        if row["key_match"] == 1:
            assert row["embed_agreement"] >= cfg["collision_embed_floor"], row
print(
    "ok",
    report["unicode_parity_rate"],
    report["legacy_key_match_rate"],
    report["mean_embed_agreement"],
    report["collision_cases_resolved"],
)
PY

log "oracle complete"
