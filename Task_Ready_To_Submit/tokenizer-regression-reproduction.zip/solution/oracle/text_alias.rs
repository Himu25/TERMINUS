use std::collections::HashMap;
use std::fs;
use std::sync::OnceLock;

static ALIAS: OnceLock<HashMap<String, String>> = OnceLock::new();

fn alias_path() -> String {
    crate::registry_paths::registry_path(&crate::registry_paths::active_legacy_alias_file())
}

fn load_aliases() -> HashMap<String, String> {
    let mut out = HashMap::new();
    let Ok(body) = fs::read_to_string(alias_path()) else {
        return out;
    };
    for line in body.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let parts: Vec<&str> = line.split_whitespace().collect();
        if parts.len() >= 2 {
            let src = parts[..parts.len() - 1].join(" ");
            let dst = parts[parts.len() - 1].to_string();
            out.insert(src, dst);
        }
    }
    out
}

fn alias_map() -> &'static HashMap<String, String> {
    ALIAS.get_or_init(load_aliases)
}

fn apply_span(tokens: &mut Vec<String>, table: &HashMap<String, String>) {
    let mut idx = 0;
    while idx < tokens.len() {
        let mut matched = false;
        for (src, dst) in table.iter() {
            let parts: Vec<&str> = src.split_whitespace().collect();
            if parts.is_empty() || idx + parts.len() > tokens.len() {
                continue;
            }
            if tokens[idx..idx + parts.len()] == parts {
                tokens.splice(idx..idx + parts.len(), [dst.clone()]);
                matched = true;
                break;
            }
        }
        if matched {
            continue;
        }
        if let Some(canonical) = table.get(tokens[idx].as_str()) {
            tokens[idx] = canonical.clone();
        }
        idx += 1;
    }
}

/// Rewrite token spans using the active span map.
pub fn apply(tokens: &mut Vec<String>) {
    let table = alias_map();
    apply_span(tokens, table);
}
