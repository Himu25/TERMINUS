use std::collections::HashSet;
use std::fs;
use std::sync::OnceLock;

static STOPS: OnceLock<HashSet<String>> = OnceLock::new();

fn stop_set() -> &'static HashSet<String> {
    STOPS.get_or_init(|| {
        let mut out = HashSet::new();
        if let Ok(raw) = fs::read_to_string("/app/config/stopwords.txt") {
            for tok in raw.split_whitespace() {
                out.insert(tok.to_ascii_lowercase());
            }
        }
        out
    })
}

fn merge_path() -> String {
    crate::registry_paths::registry_path(&crate::registry_paths::active_merge_rules_file())
}

fn load_merges() -> Vec<String> {
    let Ok(body) = fs::read_to_string(merge_path()) else {
        return Vec::new();
    };
    body.lines()
        .map(str::trim)
        .filter(|line| !line.is_empty() && !line.starts_with('#'))
        .map(str::to_string)
        .collect()
}

fn norm_spaces(raw: &str) -> String {
    let mut out = String::new();
    let mut prev_space = false;
    for ch in raw.chars() {
        if ch.is_whitespace() {
            if !prev_space {
                out.push(' ');
                prev_space = true;
            }
        } else {
            out.push(ch);
            prev_space = false;
        }
    }
    out.trim().to_string()
}

fn split_basic(raw: &str) -> Vec<String> {
    norm_spaces(raw)
        .split(' ')
        .filter(|s| !s.is_empty())
        .map(str::to_string)
        .collect()
}

fn apply_merges(mut tokens: Vec<String>) -> Vec<String> {
    for pair in load_merges() {
        let parts: Vec<&str> = pair.split_whitespace().collect();
        if parts.len() >= 3 {
            let dst = parts[parts.len() - 1].to_string();
            let mut out = Vec::new();
            let mut idx = 0;
            while idx < tokens.len() {
                if idx + 1 < tokens.len()
                    && tokens[idx] == parts[0]
                    && tokens[idx + 1] == parts[1]
                {
                    out.push(dst.clone());
                    idx += 2;
                } else {
                    out.push(tokens[idx].clone());
                    idx += 1;
                }
            }
            tokens = out;
        }
    }
    tokens
}

/// Split normalized text into lexical tokens.
pub fn tokens(raw: &str) -> Vec<String> {
    let stops = stop_set();
    let merged = apply_merges(split_basic(raw));
    merged
        .into_iter()
        .filter(|t| !stops.contains(t))
        .collect()
}
