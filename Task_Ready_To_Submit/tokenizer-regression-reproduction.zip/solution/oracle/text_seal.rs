use sha2::{Digest, Sha256};

/// Derive a stable cache key from the final token stream.
pub fn cache_key(tokens: &[String]) -> String {
    let joined = tokens.join("\x1f");
    let mut hasher = Sha256::new();
    hasher.update(joined.as_bytes());
    format!("{:x}", hasher.finalize())
}
