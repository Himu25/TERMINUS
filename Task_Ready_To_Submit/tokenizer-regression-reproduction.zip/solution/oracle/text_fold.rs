use unicode_normalization::UnicodeNormalization;

fn strip_invisibles(raw: &str) -> String {
    raw.chars()
        .filter(|c| !matches!(*c, '\u{200b}' | '\u{200c}' | '\u{200d}' | '\u{feff}'))
        .collect()
}

/// Pre-ingest text cleanup before token splitting.
pub fn normalize(raw: &str) -> String {
    let nfkc: String = raw.nfkc().collect();
    let cleaned = strip_invisibles(&nfkc);
    let lowered = cleaned.to_lowercase();
    lowered.split_whitespace().collect::<Vec<_>>().join(" ")
}
