"""Verifier for latency pipeline bind report."""

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = APP / "data" / "replay"
OUT = APP / "output" / "bind_report.json"
GO_BIN = "/usr/local/go/bin/go"
VERIFY_BIN = "/tmp/metrics_ctl_verify_bin"


def _op_b(v: float, edges: list[float]) -> int:
    for i, edge in enumerate(edges):
        if v <= edge:
            return i
    return len(edges) - 1


def _op_r(tick_reset: bool, keep_window: bool) -> bool:
    if tick_reset:
        return not keep_window
    return False


def _op_p(n: int) -> int:
    return n


def _op_w(ts: int, lo: int, hi: int) -> bool:
    return ts >= lo and ts <= hi


def _value_in_bucket(v: float, bucket: int, edges: list[float]) -> bool:
    if bucket < 0 or bucket >= len(edges):
        return False
    upper = edges[bucket]
    if v > upper:
        return False
    if bucket == 0:
        return v >= 0
    return v > edges[bucket - 1]


def _event_ts_after_seq(events: list[dict], seq: int) -> int:
    for ev in events:
        if ev["seq"] > seq:
            return ev["ts_ns"]
    return 0


def _digest_hex(
    suite_id: str,
    total: int,
    bound: int,
    orphan: int,
    window: int,
    reset: int,
    delta: bool,
) -> str:
    dm = "true" if delta else "false"
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            suite_id,
            str(total),
            str(bound),
            str(orphan),
            str(window),
            str(reset),
            dm,
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _expected_from_fixture(name: str) -> dict:
    pack_dir = FIXTURES / name
    manifest = json.loads((pack_dir / "manifest.json").read_text())
    events = []
    for line in (pack_dir / "events" / "events_001.jsonl").read_text().splitlines():
        if line.strip():
            events.append(json.loads(line))

    edges = manifest["edges_ms"]
    lo, hi = manifest["window_ns"]
    delta = manifest["temporality"] == "delta"
    reset_set = set(manifest.get("resets") or [])
    pool: dict[int, dict] = {}
    last_reset_seq = -1

    for ev in events:
        if delta and ev["seq"] in reset_set:
            if _op_r(True, True):
                pool = {}
            last_reset_seq = ev["seq"]

        bucket = _op_b(ev["value_ms"], edges)
        pool[bucket] = {
            "value_ms": ev["value_ms"],
            "trace_id": ev["trace_id"],
            "span_id": ev["span_id"],
            "ts_ns": ev["ts_ns"],
            "bucket": bucket,
        }

    exemplars = []
    for ex in pool.values():
        export_ix = _op_p(ex["bucket"])
        exemplars.append({**ex, "export_ix": export_ix})

    bound_ok = 0
    orphan_count = 0
    window_violation = 0
    reset_survivor = 0
    post_reset_ts = _event_ts_after_seq(events, last_reset_seq) if last_reset_seq >= 0 else 0

    for ex in exemplars:
        if _value_in_bucket(ex["value_ms"], ex["export_ix"], edges):
            bound_ok += 1
        else:
            orphan_count += 1
        if not _op_w(ex["ts_ns"], lo, hi):
            window_violation += 1
        if delta and last_reset_seq >= 0 and ex["ts_ns"] >= post_reset_ts:
            if _value_in_bucket(ex["value_ms"], ex["export_ix"], edges):
                reset_survivor += 1

    total = len(exemplars)
    digest = _digest_hex(
        manifest["suite_id"],
        total,
        bound_ok,
        orphan_count,
        window_violation,
        reset_survivor,
        delta,
    )
    return {
        "schema_version": "1",
        "suite_id": manifest["suite_id"],
        "exemplar_total": total,
        "bound_ok": bound_ok,
        "orphan_count": orphan_count,
        "window_violation": window_violation,
        "reset_survivor": reset_survivor,
        "delta_mode": delta,
        "digest_hex": digest,
    }


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)
    subprocess.run(["cp", "/app/bin/metrics_ctl", VERIFY_BIN], check=True)


def _swap(name: str) -> None:
    src = FIXTURES / name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_METRICS_FIXTURE": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_r00_active_tape_replays() -> None:
    """Bundled /app/data/active tape must replay cleanly after the repair."""
    _swap("pack_alpha")
    exp = _expected_from_fixture("pack_alpha")
    got = _run_tool()
    assert got == exp


def test_r01_alpha_bound_ok() -> None:
    """Alpha tape keeps on-edge sample values inside their assigned slots."""
    _swap("pack_alpha")
    exp = _expected_from_fixture("pack_alpha")
    got = _run_tool()
    assert got["bound_ok"] == exp["bound_ok"]
    assert got["orphan_count"] == exp["orphan_count"]


def test_r02_beta_reset_survivor() -> None:
    """Beta delta reset should retain in-window pool entries when the window stays open."""
    _swap("pack_beta")
    exp = _expected_from_fixture("pack_beta")
    got = _run_tool()
    assert got["reset_survivor"] == exp["reset_survivor"]
    assert got["exemplar_total"] == exp["exemplar_total"]


def test_r03_gamma_window_violation() -> None:
    """Gamma exports should not keep samples whose timestamps sit outside the window."""
    _swap("pack_gamma")
    exp = _expected_from_fixture("pack_gamma")
    got = _run_tool()
    assert got["window_violation"] == exp["window_violation"]


def test_r04_delta_orphan_count() -> None:
    """Delta remap pack should not leave trace-linked samples in mismatched slots."""
    _swap("pack_delta")
    exp = _expected_from_fixture("pack_delta")
    got = _run_tool()
    assert got["orphan_count"] == exp["orphan_count"]


def test_r05_epsilon_full_report() -> None:
    """Epsilon blended tape should replay cleanly across all report counters."""
    _swap("pack_epsilon")
    exp = _expected_from_fixture("pack_epsilon")
    got = _run_tool()
    assert got == exp


def test_r06_digest_binding() -> None:
    """Report digest must bind counters and mode flags."""
    _swap("pack_alpha")
    exp = _expected_from_fixture("pack_alpha")
    got = _run_tool()
    assert got["digest_hex"] == exp["digest_hex"]


def test_r07_go_unit_tests_pass() -> None:
    """Go unit tests under /app must pass after the repair."""
    subprocess.run(
        [GO_BIN, "test", "./..."],
        cwd="/app",
        env={
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        },
        check=True,
    )
