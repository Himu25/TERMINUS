package hist

type Event struct {
	Seq     int     `json:"seq"`
	ValueMs float64 `json:"value_ms"`
	TraceID string  `json:"trace_id"`
	SpanID  string  `json:"span_id"`
	TsNs    int64   `json:"ts_ns"`
}

type Manifest struct {
	SuiteID     string    `json:"suite_id"`
	Temporality string    `json:"temporality"`
	WindowNs    [2]int64  `json:"window_ns"`
	EdgesMs     []float64 `json:"edges_ms"`
	Resets      []int     `json:"resets"`
}

type Exemplar struct {
	ValueMs  float64
	TraceID  string
	SpanID   string
	TsNs     int64
	Bucket   int
	ExportIx int
}

type Outcome struct {
	ExemplarTotal   int
	BoundOk         int
	OrphanCount     int
	WindowViolation int
	ResetSurvivor   int
	DeltaMode       bool
}
