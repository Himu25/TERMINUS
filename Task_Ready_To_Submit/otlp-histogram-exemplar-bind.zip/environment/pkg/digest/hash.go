package digest

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
)

func Bind(
	suiteID string,
	total int,
	bound int,
	orphan int,
	window int,
	reset int,
	delta bool,
) string {
	dm := "false"
	if delta {
		dm = "true"
	}
	raw := fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%s",
		suiteID, total, bound, orphan, window, reset, dm,
	)
	sum := sha256.Sum256([]byte(raw))
	return hex.EncodeToString(sum[:])
}
