package af_p7

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libaf_p7.a -ldl -lm
#include "af_p7.h"
*/
import "C"

func OpB(v float64, edges []float64) int {
	if len(edges) == 0 {
		return 0
	}
	return int(C.af_op_b(C.double(v), (*C.double)(&edges[0]), C.int(len(edges))))
}

func OpR(tickReset bool, keepWindow bool) bool {
	tr := 0
	if tickReset {
		tr = 1
	}
	kw := 0
	if keepWindow {
		kw = 1
	}
	return C.af_op_r(C.int(tr), C.int(kw)) != 0
}
