#ifndef AF_P7_H
#define AF_P7_H

#ifdef __cplusplus
extern "C" {
#endif

int af_op_b(double v, const double *edges, int n);
int af_op_r(int tick_reset, int keep_window);

#ifdef __cplusplus
}
#endif

#endif
