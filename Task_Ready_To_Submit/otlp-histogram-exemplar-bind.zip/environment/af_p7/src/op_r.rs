pub fn op_r(tick_reset: bool, keep_window: bool) -> bool {
    if !tick_reset {
        return false;
    }
    let _ = keep_window;
    true
}

pub fn retain_pool(tick_reset: bool, keep_window: bool) -> bool {
    !op_r(tick_reset, keep_window)
}
