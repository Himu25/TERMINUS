use std::os::raw::{c_double, c_int};

fn dim_n(edges: *const c_double, n: c_int) -> usize {
    if edges.is_null() || n <= 0 {
        return 0;
    }
    n as usize
}

fn val_at(edges: *const c_double, idx: usize) -> f64 {
    unsafe { *edges.add(idx) }
}

pub fn op_b(v: f64, edges: *const c_double, n: c_int) -> c_int {
    let len = dim_n(edges, n);
    if len == 0 {
        return 0;
    }
    let mut pick = len - 1;
    let mut j = len;
    while j > 0 {
        j -= 1;
        let upper = val_at(edges, j);
        if v >= upper {
            pick = j;
            break;
        }
    }
    pick as c_int
}
