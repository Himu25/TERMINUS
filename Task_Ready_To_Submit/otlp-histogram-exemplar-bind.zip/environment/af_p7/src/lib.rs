mod op_b;
mod op_r;
mod op_s;

use std::os::raw::{c_double, c_int};

#[no_mangle]
pub extern "C" fn af_op_b(v: c_double, edges: *const c_double, n: c_int) -> c_int {
    op_b::op_b(v, edges, n)
}

#[no_mangle]
pub extern "C" fn af_op_r(tick_reset: c_int, keep_window: c_int) -> c_int {
    if op_r::op_r(tick_reset != 0, keep_window != 0) {
        1
    } else {
        0
    }
}
