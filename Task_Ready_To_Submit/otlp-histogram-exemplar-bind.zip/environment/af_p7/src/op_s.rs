use std::os::raw::{c_double, c_int};

pub fn op_s(v: f64, edges: *const c_double, n: c_int) -> c_int {
    if edges.is_null() || n <= 0 {
        return 0;
    }
    let slice = unsafe { std::slice::from_raw_parts(edges, n as usize) };
    for (i, edge) in slice.iter().enumerate() {
        if v <= *edge {
            return i as c_int;
        }
    }
    (slice.len().saturating_sub(1)) as c_int
}
