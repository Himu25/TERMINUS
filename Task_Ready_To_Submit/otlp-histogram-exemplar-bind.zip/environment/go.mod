module lab.local/metrics_pipe

go 1.22
