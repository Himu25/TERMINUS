# Pipeline overview

Samples enter the Rust aggregation crate, then pass through the Go export driver.
The bind report summarizes how exported trace-linked samples align with slot indices.

See `/app/data/active/manifest.json` for temporality and window settings.
