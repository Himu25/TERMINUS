# Latency export lab

Mixed Rust aggregation and Go export pipeline for latency sample replay.

Build with `/app/scripts/build.sh`. Run the driver with `TB_METRICS_FIXTURE=1`.

Active inputs live under `/app/data/active/`. Regression packs are indexed in `/app/docs/scenario_index.txt`.
