// Report JSON for /app/output/bind_report.json:
//
// schema_version — string, must be "1"
// suite_id — string, echoes active manifest suite_id
// exemplar_total — count of trace-linked samples emitted in the bind pass
// bound_ok — samples whose value lies inside the assigned slot interval
// orphan_count — samples whose trace id is present but value sits outside the assigned slot
// window_violation — samples whose timestamp falls outside the configured aggregation interval
// reset_survivor — post-reset samples that still bind correctly when delta mode is active
// delta_mode — boolean, true when manifest temporality is delta
// digest_hex — lowercase hex SHA-256 of suite_id|exemplar_total|bound_ok|orphan_count|window_violation|reset_survivor|delta_mode
//
// Root object contains only these keys.
//
// Replay reads manifest.json and events/events_001.jsonl from the active data dir.
// Slot intervals follow explicit upper bounds in edges_ms: value maps to the smallest
// index i where value <= edges_ms[i]. Delta resets honor keep-window retention.
// Export validation remaps slot indices before checking value membership.
// Timestamp membership uses a closed interval on window_ns.
package main

import (
	"fmt"
	"os"

	"lab.local/metrics_pipe/internal/driver"
)

func main() {
	if os.Getenv("TB_METRICS_FIXTURE") != "1" {
		fmt.Fprintln(os.Stderr, "set TB_METRICS_FIXTURE=1 to run pipeline")
		os.Exit(2)
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if err := driver.EmitReport("/app", rep); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
