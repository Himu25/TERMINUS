package driver

import (
	"encoding/json"
	"os"
	"path/filepath"

	"lab.local/metrics_pipe/internal/config"
	"lab.local/metrics_pipe/internal/engine"
)

type Report struct {
	SchemaVersion   string `json:"schema_version"`
	SuiteID         string `json:"suite_id"`
	ExemplarTotal   int    `json:"exemplar_total"`
	BoundOk         int    `json:"bound_ok"`
	OrphanCount     int    `json:"orphan_count"`
	WindowViolation int    `json:"window_violation"`
	ResetSurvivor   int    `json:"reset_survivor"`
	DeltaMode       bool   `json:"delta_mode"`
	DigestHex       string `json:"digest_hex"`
}

func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActiveDir(appRoot)
	if err != nil {
		return Report{}, err
	}
	manifest, err := config.LoadManifest(dir)
	if err != nil {
		return Report{}, err
	}
	events, err := config.LoadEvents(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(manifest, events)
	digest := engine.DigestFor(manifest, out)
	return Report{
		SchemaVersion:   "1",
		SuiteID:         manifest.SuiteID,
		ExemplarTotal:   out.ExemplarTotal,
		BoundOk:         out.BoundOk,
		OrphanCount:     out.OrphanCount,
		WindowViolation: out.WindowViolation,
		ResetSurvivor:   out.ResetSurvivor,
		DeltaMode:       out.DeltaMode,
		DigestHex:       digest,
	}, nil
}

func EmitReport(appRoot string, rep Report) error {
	path := filepath.Join(appRoot, "output", "bind_report.json")
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(rep, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	return os.WriteFile(path, raw, 0o644)
}
