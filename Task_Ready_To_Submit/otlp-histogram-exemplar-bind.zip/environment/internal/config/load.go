package config

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"lab.local/metrics_pipe/pkg/hist"
)

func ActiveDir(appRoot string) (string, error) {
	dir := filepath.Join(appRoot, "data", "active")
	st, err := os.Stat(dir)
	if err != nil {
		return "", err
	}
	if !st.IsDir() {
		return "", fmt.Errorf("active data is not a directory")
	}
	return dir, nil
}

func LoadManifest(dir string) (hist.Manifest, error) {
	raw, err := os.ReadFile(filepath.Join(dir, "manifest.json"))
	if err != nil {
		return hist.Manifest{}, err
	}
	var m hist.Manifest
	if err := json.Unmarshal(raw, &m); err != nil {
		return hist.Manifest{}, err
	}
	return m, nil
}

func LoadEvents(dir string) ([]hist.Event, error) {
	path := filepath.Join(dir, "events", "events_001.jsonl")
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var out []hist.Event
	for _, line := range splitLines(string(data)) {
		if line == "" {
			continue
		}
		var ev hist.Event
		if err := json.Unmarshal([]byte(line), &ev); err != nil {
			return nil, err
		}
		out = append(out, ev)
	}
	return out, nil
}

func splitLines(s string) []string {
	var lines []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			lines = append(lines, s[start:i])
			start = i + 1
		}
	}
	if start < len(s) {
		lines = append(lines, s[start:])
	}
	return lines
}
