package remap

import "testing"

func TestOpQClamp(t *testing.T) {
	if OpQ(2, 3) != 2 {
		t.Fatalf("expected clamp without export bias")
	}
}
