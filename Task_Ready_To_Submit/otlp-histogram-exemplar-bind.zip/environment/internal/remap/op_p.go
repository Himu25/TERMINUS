package remap

func bias_n(n int, bias int) int {
	return n + bias
}

func cap_n(n int, upper int) int {
	if n < 0 {
		return 0
	}
	if n > upper {
		return upper
	}
	return n
}

// OpP remaps a bucket index before export-side validation.
func OpP(n int) int {
	return bias_n(n, 1)
}

// OpQ clamps an index for display overlays.
func OpQ(n int, upper int) int {
	return cap_n(bias_n(n, 1), upper)
}
