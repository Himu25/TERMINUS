package engine

import (
	"lab.local/metrics_pipe/af_p7"
	"lab.local/metrics_pipe/internal/frame"
	"lab.local/metrics_pipe/internal/remap"
	"lab.local/metrics_pipe/pkg/digest"
	"lab.local/metrics_pipe/pkg/hist"
)

func Replay(m hist.Manifest, events []hist.Event) hist.Outcome {
	delta := m.Temporality == "delta"
	lo, hi := m.WindowNs[0], m.WindowNs[1]
	resetSet := map[int]bool{}
	for _, r := range m.Resets {
		resetSet[r] = true
	}

	pool := make(map[int]hist.Exemplar)
	lastResetSeq := -1

	for _, ev := range events {
		if delta && resetSet[ev.Seq] {
			if af_p7.OpR(true, true) {
				pool = make(map[int]hist.Exemplar)
			}
			lastResetSeq = ev.Seq
		}

		bucket := af_p7.OpB(ev.ValueMs, m.EdgesMs)
		pool[bucket] = hist.Exemplar{
			ValueMs: ev.ValueMs,
			TraceID: ev.TraceID,
			SpanID:  ev.SpanID,
			TsNs:    ev.TsNs,
			Bucket:  bucket,
		}
	}

	exemplars := make([]hist.Exemplar, 0, len(pool))
	for _, ex := range pool {
		ex.ExportIx = remap.OpP(ex.Bucket)
		exemplars = append(exemplars, ex)
	}

	out := hist.Outcome{
		ExemplarTotal: len(exemplars),
		DeltaMode:     delta,
	}

	for _, ex := range exemplars {
		if valueInBucket(ex.ValueMs, ex.ExportIx, m.EdgesMs) {
			out.BoundOk++
		} else {
			out.OrphanCount++
		}
		if !frame.OpW(ex.TsNs, lo, hi) {
			out.WindowViolation++
		}
		if delta && lastResetSeq >= 0 && ex.TsNs >= eventTsAfterSeq(events, lastResetSeq) {
			if valueInBucket(ex.ValueMs, ex.ExportIx, m.EdgesMs) {
				out.ResetSurvivor++
			}
		}
	}

	_ = digest.Bind(m.SuiteID, out.ExemplarTotal, out.BoundOk, out.OrphanCount, out.WindowViolation, out.ResetSurvivor, delta)
	return out
}

func valueInBucket(v float64, bucket int, edges []float64) bool {
	if len(edges) == 0 {
		return false
	}
	if bucket < 0 || bucket >= len(edges) {
		return false
	}
	upper := edges[bucket]
	if v > upper {
		return false
	}
	if bucket == 0 {
		return v >= 0
	}
	lower := edges[bucket-1]
	return v > lower
}

func eventTsAfterSeq(events []hist.Event, seq int) int64 {
	for _, ev := range events {
		if ev.Seq > seq {
			return ev.TsNs
		}
	}
	return 0
}

func DigestFor(m hist.Manifest, out hist.Outcome) string {
	return digest.Bind(
		m.SuiteID,
		out.ExemplarTotal,
		out.BoundOk,
		out.OrphanCount,
		out.WindowViolation,
		out.ResetSurvivor,
		out.DeltaMode,
	)
}
