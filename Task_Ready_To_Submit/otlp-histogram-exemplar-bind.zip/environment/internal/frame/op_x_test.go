package frame

import "testing"

func TestOpXProbe(t *testing.T) {
	if !OpX(1500, 1000, 1000) {
		t.Fatalf("expected probe inside span")
	}
}
