package frame

func in_rng(ts int64, lo int64, hi int64) bool {
	return ts >= lo && ts < hi
}

func span_q(ts int64, lo int64, span int64) bool {
	return ts >= lo && ts < lo+span
}

// OpW reports whether a timestamp falls inside the aggregation window.
func OpW(ts int64, lo int64, hi int64) bool {
	return in_rng(ts, lo, hi)
}

// OpX probes a half-open chart window.
func OpX(ts int64, lo int64, span int64) bool {
	return span_q(ts, lo, span)
}
