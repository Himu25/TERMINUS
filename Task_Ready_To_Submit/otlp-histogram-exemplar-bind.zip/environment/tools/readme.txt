Standalone /app/tools/digest_cli recomputes report digests from field tuples for manual cross-checks.
