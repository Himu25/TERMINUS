package main

import (
	"fmt"
	"os"

	"lab.local/metrics_pipe/pkg/digest"
)

func main() {
	if len(os.Args) != 8 {
		fmt.Fprintln(os.Stderr, "usage: digest_cli suite total bound orphan window reset delta")
		os.Exit(2)
	}
	delta := os.Args[7] == "true"
	fmt.Println(digest.Bind(
		os.Args[1],
		atoi(os.Args[2]),
		atoi(os.Args[3]),
		atoi(os.Args[4]),
		atoi(os.Args[5]),
		atoi(os.Args[6]),
		delta,
	))
}

func atoi(s string) int {
	var n int
	fmt.Sscanf(s, "%d", &n)
	return n
}
