#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:/app/bin:${PATH}"
cd /app

cat > /app/af_p7/src/op_b.rs <<'EOF'
use std::os::raw::{c_double, c_int};

fn dim_n(edges: *const c_double, n: c_int) -> usize {
    if edges.is_null() || n <= 0 {
        return 0;
    }
    n as usize
}

fn val_at(edges: *const c_double, idx: usize) -> f64 {
    unsafe { *edges.add(idx) }
}

pub fn op_b(v: f64, edges: *const c_double, n: c_int) -> c_int {
    let len = dim_n(edges, n);
    if len == 0 {
        return 0;
    }
    let mut i = 0usize;
    while i < len {
        let upper = val_at(edges, i);
        if v <= upper {
            return i as c_int;
        }
        i += 1;
    }
    (len.saturating_sub(1)) as c_int
}
EOF

cat > /app/af_p7/src/op_r.rs <<'EOF'
fn should_drop_pool(tick_reset: bool, keep_window: bool) -> bool {
    if !tick_reset {
        return false;
    }
    if keep_window {
        return false;
    }
    true
}

pub fn op_r(tick_reset: bool, keep_window: bool) -> bool {
    should_drop_pool(tick_reset, keep_window)
}

pub fn retain_pool(tick_reset: bool, keep_window: bool) -> bool {
    op_r(tick_reset, keep_window)
}
EOF

cat > /app/internal/remap/op_p.go <<'EOF'
package remap

func bias_n(n int, bias int) int {
	return n + bias
}

func cap_n(n int, upper int) int {
	if n < 0 {
		return 0
	}
	if n > upper {
		return upper
	}
	return n
}

// OpP remaps a bucket index before export-side validation.
func OpP(n int) int {
	return bias_n(n, 0)
}

// OpQ clamps an index for display overlays.
func OpQ(n int, upper int) int {
	return cap_n(bias_n(n, 0), upper)
}
EOF

cat > /app/internal/frame/op_w.go <<'EOF'
package frame

func in_rng(ts int64, lo int64, hi int64) bool {
	return ts >= lo && ts <= hi
}

func span_q(ts int64, lo int64, span int64) bool {
	return ts >= lo && ts < lo+span
}

// OpW reports whether a timestamp falls inside the aggregation window.
func OpW(ts int64, lo int64, hi int64) bool {
	return in_rng(ts, lo, hi)
}

// OpX probes a half-open chart window.
func OpX(ts int64, lo int64, span int64) bool {
	return span_q(ts, lo, span)
}
EOF

bash /app/scripts/build.sh

rm -f /app/output/bind_report.json
mkdir -p /app/output
TB_METRICS_FIXTURE=1 /app/bin/metrics_ctl
test -s /app/output/bind_report.json

GOFLAGS=-mod=mod go test ./...
