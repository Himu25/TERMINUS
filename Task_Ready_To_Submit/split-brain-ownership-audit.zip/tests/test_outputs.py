"""Verifier for five-site split-brain ownership audit brief."""

import json
import os
import shutil
import subprocess
from collections import defaultdict
from pathlib import Path

import pytest

APP = Path("/app")
ACTIVE = APP / "data" / "active"
FIXTURES = Path("/tests") / "fixtures"
OUT = APP / "output" / "audit_report.json"
GO_BIN = "go"
VERIFY_BIN = "/app/bin/owner_audit"


@pytest.fixture(scope="session", autouse=True)
def _session_build() -> None:
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "CGO_ENABLED": "1",
        "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
    }
    subprocess.run(["bash", "/app/scripts/build.sh"], cwd="/app", env=env, check=True)


def _digest_hex(
    zone_id: str,
    primary_gen: int,
    fence_seq: int,
    repair: int,
    gaps: int,
    sites_active: int,
    revert: int,
    keep: int,
    band: str,
    title_clean: bool,
) -> str:
    ck = "true" if title_clean else "false"
    got = subprocess.run(
        [
            GO_BIN,
            "run",
            "-mod=mod",
            "/app/tools/digest_cli",
            zone_id,
            str(primary_gen),
            str(fence_seq),
            str(repair),
            str(gaps),
            str(sites_active),
            str(revert),
            str(keep),
            band,
            ck,
        ],
        cwd="/app",
        capture_output=True,
        text=True,
        check=True,
    )
    return got.stdout.strip()


def _crc16(seq: int, voter_id: str) -> int:
    s = sum(voter_id.encode()) & 0xFFFFFFFF
    s ^= seq
    return s & 0xFFFF


def _expected_from_fixture(pack_name: str) -> dict:
    pack_dir = FIXTURES / pack_name
    plan = json.loads((pack_dir / "zone_plan.json").read_text())
    q = plan["q_size"]
    sep_seq = plan["sep_seq"]
    stable_term = plan["stable_term"]
    prop_tight = plan["timeout_tight_ms"]
    offsets: dict[str, int] = {}
    freezes: list[int] = []
    rows: list[dict] = []
    for rid in plan["nodes"]:
        meta = json.loads((pack_dir / "nodes" / rid / "site_meta.json").read_text())
        lag = int(meta.get("link_delay_ms", 0))
        offsets[rid] = int(meta["clock_skew_ms"]) - lag
        freezes.append(meta["fence_mark"])
        seg = pack_dir / "nodes" / rid / "claim_001.jsonl"
        if not seg.exists():
            continue
        for line in seg.read_text().splitlines():
            if not line.strip():
                continue
            entry = json.loads(line)
            entry["node"] = rid
            rows.append(entry)
    wm = min(freezes) if freezes else 0
    by_seq: dict[int, list] = defaultdict(list)
    all_rows: dict[int, list] = defaultdict(list)
    for entry in rows:
        seq = entry["round_seq"]
        all_rows[seq].append(entry)
        if seq > wm:
            by_seq[seq].append(entry)
    accepted: dict[int, int] = {}
    repair = 0
    loss = 0
    live: set[str] = set()
    title_clean = True
    node_keep: dict[str, bool] = {}
    for seq in sorted(by_seq):
        buckets: dict[tuple, list] = defaultdict(list)
        for entry in by_seq[seq]:
            buckets[(entry["ver"], entry["node"])].append(entry)
        picked = None
        best_adj = None
        for (ver, node), items in buckets.items():
            if len({it["voter_id"] for it in items}) < q:
                continue
            valid = [
                it
                for it in items
                if _crc16(it["round_seq"], it["voter_id"]) == it["crc"]
            ]
            if len(valid) < q:
                continue
            adj = min(it["sent_ms"] - offsets[it["node"]] for it in valid)
            if picked is None or adj < best_adj:
                picked, best_adj = (ver, node), adj
        if picked is None:
            loss += 1
            continue
        ver, node = picked
        items = buckets[(ver, node)]
        repair += sum(
            1
            for it in items
            if _crc16(it["round_seq"], it["voter_id"]) != it["crc"]
        )
        if ver > sep_seq and len({it["voter_id"] for it in items if _crc16(it["round_seq"], it["voter_id"]) == it["crc"]}) < q:
            title_clean = False
        if ver >= stable_term:
            node_keep[node] = True
        for it in items:
            if _crc16(it["round_seq"], it["voter_id"]) == it["crc"]:
                live.add(it["node"])
        accepted[seq] = ver
    fence_seq = 0
    s = 1
    while True:
        if s <= wm or s in accepted:
            fence_seq = s
            s += 1
        else:
            break
    primary_gen = 0
    for seq, seq_rows in all_rows.items():
        if seq > fence_seq:
            continue
        for entry in seq_rows:
            if seq in accepted and entry["ver"] == accepted[seq]:
                if _crc16(entry["round_seq"], entry["voter_id"]) == entry["crc"] and entry["ver"] > primary_gen:
                    primary_gen = entry["ver"]
            elif seq <= wm and entry["ver"] > primary_gen:
                primary_gen = entry["ver"]
    revert = 0
    keep = 0
    for rid in offsets:
        if node_keep.get(rid):
            keep += 1
        else:
            revert += 1
    spread = max(offsets.values()) - min(offsets.values())
    band = "tight" if spread <= prop_tight else "wide"
    digest = _digest_hex(
        plan["zone_id"],
        primary_gen,
        fence_seq,
        repair,
        loss,
        len(live),
        revert,
        keep,
        band,
        title_clean,
    )
    return {
        "schema_version": "1",
        "zone_id": plan["zone_id"],
        "primary_gen": primary_gen,
        "fence_seq": fence_seq,
        "wire_fixes": repair,
        "dual_gaps": loss,
        "sites_active": len(live),
        "forfeit_count": revert,
        "assume_count": keep,
        "heartbeat_band": band,
        "title_clean": title_clean,
        "digest_hex": digest,
    }


def _swap(pack_name: str) -> None:
    src = FIXTURES / pack_name
    assert src.is_dir()
    if ACTIVE.exists():
        shutil.rmtree(ACTIVE)
    shutil.copytree(src, ACTIVE)


def _run_tool() -> dict:
    if OUT.exists():
        OUT.unlink()
    env = {**os.environ, "TB_OWNER_AUDIT_FIXTURE": "1", "GOFLAGS": "-mod=mod", "CGO_ENABLED": "1"}
    subprocess.run([VERIFY_BIN], cwd="/app", env=env, check=True)
    raw = json.loads(OUT.read_text())
    assert raw["schema_version"] == "1"
    return raw


def test_alpha_report_matches_ownership_replay() -> None:
    """Alpha zone should reach tight heartbeat band with full five-site chain."""
    _swap("zone_alpha")
    exp = _expected_from_fixture("zone_alpha")
    got = _run_tool()
    assert got["fence_seq"] == exp["fence_seq"]
    assert got["dual_gaps"] == exp["dual_gaps"]
    assert got["primary_gen"] == exp["primary_gen"]
    assert got["heartbeat_band"] == exp["heartbeat_band"]
    assert got["sites_active"] == exp["sites_active"]
    assert got["title_clean"] == exp["title_clean"]
    assert got["digest_hex"] == exp["digest_hex"]


def test_beta_report_matches_ownership_replay() -> None:
    """Beta zone applies pulse delay smear when folding site skew for replay."""
    _swap("zone_beta")
    exp = _expected_from_fixture("zone_beta")
    got = _run_tool()
    assert got["heartbeat_band"] == exp["heartbeat_band"]
    assert got["assume_count"] == exp["assume_count"]
    assert got["forfeit_count"] == exp["forfeit_count"]


def test_gamma_dual_gaps_after_lone_version() -> None:
    """Gamma stops the chain when only one site carries a high generation row."""
    _swap("zone_gamma")
    exp = _expected_from_fixture("zone_gamma")
    got = _run_tool()
    assert got["dual_gaps"] == exp["dual_gaps"]
    assert got["fence_seq"] == exp["fence_seq"]


def test_delta_high_dual_gaps() -> None:
    """Delta orphan high step should not extend the global chain."""
    _swap("zone_delta")
    exp = _expected_from_fixture("zone_delta")
    got = _run_tool()
    assert got["dual_gaps"] == exp["dual_gaps"]
    assert got["fence_seq"] == exp["fence_seq"]


def test_epsilon_wire_fixes_nonzero() -> None:
    """Epsilon should count one wire repair on the winning generation group."""
    _swap("zone_epsilon")
    exp = _expected_from_fixture("zone_epsilon")
    got = _run_tool()
    assert got["wire_fixes"] == exp["wire_fixes"]
    assert got["fence_seq"] == exp["fence_seq"]


def test_alpha_fence_seq_tracks_frontier_fold() -> None:
    """Alpha zone fence_seq tracks replay frontier fold."""
    _swap("zone_alpha")
    exp = _expected_from_fixture("zone_alpha")
    got = _run_tool()
    assert got["fence_seq"] == exp["fence_seq"]


def test_beta_assume_forfeit_split() -> None:
    """Beta partial heal should split assume and forfeit counts across sites."""
    _swap("zone_beta")
    exp = _expected_from_fixture("zone_beta")
    got = _run_tool()
    assert got["assume_count"] == exp["assume_count"]
    assert got["forfeit_count"] == exp["forfeit_count"]


def test_go_subsystem_tests_pass() -> None:
    """Go unit tests under /app must pass after the repair."""
    subprocess.run(
        [GO_BIN, "test", "./..."],
        cwd="/app",
        env={
            **os.environ,
            "GOFLAGS": "-mod=mod",
            "CGO_ENABLED": "1",
            "PATH": "/usr/local/cargo/bin:" + os.environ.get("PATH", ""),
        },
        check=True,
    )
