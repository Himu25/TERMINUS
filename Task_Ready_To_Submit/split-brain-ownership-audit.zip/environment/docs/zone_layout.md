# Zone layout

Fifty logical claimants are grouped across five zone sites (ten claimants per site).
Each site contributes claim tapes, clock skew metadata, pulse delay bands, and a fence_mark frontier used during replay.
