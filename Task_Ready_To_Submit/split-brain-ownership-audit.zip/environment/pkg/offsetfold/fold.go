package offsetfold

import "lab.local/split_brain_ownership_audit/ownsgate"

// FoldNodeSkew applies optional link delay smear to the recorded clock skew baseline.
func FoldNodeSkew(skewMS int64, propLagMS int64) int64 {
	return ownsgate.FoldSkew(skewMS, propLagMS)
}
