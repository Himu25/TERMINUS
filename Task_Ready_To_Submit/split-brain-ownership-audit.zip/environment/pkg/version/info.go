package version

// Tool identifies the recovery driver build.
const Tool = "owner_audit"
