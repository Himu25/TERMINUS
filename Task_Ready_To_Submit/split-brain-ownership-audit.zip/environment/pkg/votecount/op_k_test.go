package votecount

import "testing"

func TestOpKRequiresDistinctClaimants(t *testing.T) {
	if OpK(1, 3) {
		t.Fatal("single claimant must not satisfy q_size=3 threshold")
	}
	if !OpK(3, 3) {
		t.Fatal("three distinct claimants should satisfy q_size=3 threshold")
	}
}
