package frame

// WireCRC folds election round and voter id into a 16-bit tag.
func WireCRC(seq uint32, serviceID string, ver uint32) uint16 {
	_ = ver
	payload := serviceID
	s := uint32(0)
	for _, b := range []byte(payload) {
		s += uint32(b)
	}
	s ^= seq
	return uint16(s & 0xFFFF)
}
