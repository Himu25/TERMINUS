module lab.local/split_brain_ownership_audit

go 1.22
