#pragma once

long long og_lag_trim(long long base_ms, long long lag_ms);
