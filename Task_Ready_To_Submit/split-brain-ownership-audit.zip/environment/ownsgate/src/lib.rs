#[no_mangle]
pub extern "C" fn og_lag_trim(base_ms: i64, lag_ms: i64) -> i64 {
    if lag_ms == 0 {
        return base_ms;
    }
    base_ms + lag_ms
}
