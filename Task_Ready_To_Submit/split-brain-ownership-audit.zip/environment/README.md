# Split-brain ownership audit lab

Mixed-language ownership replay driver for a five-site zone after intermittent dual-title incidents during failover.
