// Report JSON for /app/output/audit_report.json.
//
// Replay (zone_plan.json supplies q_size, sep_seq, stable_term, timeout_tight_ms):
//   - Fold replay frontier to the minimum fence_mark across zone sites.
//   - Per-site offset is site_meta clock_skew_ms minus link_delay_ms.
//   - Row tag valid when crc equals low 16 bits of sum(voter_id bytes) xor round_seq.
//   - Above the frontier fold, bucket rows by (ver, node); accept one bucket per round when
//     it has at least q_size distinct voter_id claimants and at least q_size tag-valid rows
//     in that bucket; earliest sent_ms minus site offset wins ties.
//   - fence_seq: highest contiguous round from 1 while each round is at/below the fold or accepted.
//   - primary_gen: highest tag-valid ver on accepted rounds through fence_seq, plus stale high
//     ver rows still inside the fold.
//   - title_clean false if any accepted generation version above sep_seq had < q_size tag-valid claimants.
//   - heartbeat_band tight when max-min site offset spread <= timeout_tight_ms, else wide.
//
// Fields:
//   schema_version — string, always "1"
//   zone_id — string, echoes active zone plan name
//   primary_gen — uint32, highest generation in the consistent title chain
//   fence_seq — highest contiguous fence round included after folding the earliest site fence_mark frontier
//   wire_fixes — claim rows in the winning generation group whose wire tag failed validation
//   dual_gaps — fence rounds above the frontier without q_size claimant agreement on one generation
//   sites_active — distinct sites with tag-valid rows in quorum-accepted rounds above the replay frontier
//   forfeit_count — sites assigned fallback generation after partial heal
//   assume_count — sites kept on stable generation
//   heartbeat_band — string, "tight" or "wide"
//   title_clean — boolean (not 0/1 strings)
//   digest_hex — lowercase hex SHA-256 of zone_id|primary_gen|fence_seq|wire_fixes|dual_gaps|sites_active|forfeit_count|assume_count|heartbeat_band|title_clean
//
// Root object contains only these keys.
package main

import (
	"log"
	"os"

	"lab.local/split_brain_ownership_audit/internal/driver"
)

func main() {
	if os.Getenv("TB_OWNER_AUDIT_FIXTURE") != "1" {
		log.Fatal("TB_OWNER_AUDIT_FIXTURE unset or not 1")
	}
	rep, err := driver.RunActive("/app")
	if err != nil {
		log.Fatal(err)
	}
	if err := driver.EmitReport("/app/output/audit_report.json", rep); err != nil {
		log.Fatal(err)
	}
}
