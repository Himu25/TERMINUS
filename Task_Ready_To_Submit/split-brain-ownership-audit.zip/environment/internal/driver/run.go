package driver

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"

	"lab.local/split_brain_ownership_audit/internal/config"
	"lab.local/split_brain_ownership_audit/internal/engine"
)

// Report is the outward JSON document.
type Report struct {
	SchemaVersion       string `json:"schema_version"`
	ClusterID              string `json:"zone_id"`
	LeaderTerm          uint32 `json:"primary_gen"`
	StableSeq         uint32 `json:"fence_seq"`
	VoteRepairs   uint32 `json:"wire_fixes"`
	SplitGaps     uint32 `json:"dual_gaps"`
	NodesActive          uint32 `json:"sites_active"`
	DemoteCount         uint32 `json:"forfeit_count"`
	PromoteCount           uint32 `json:"assume_count"`
	TimeoutBand            string `json:"heartbeat_band"`
	MembershipClean       bool   `json:"title_clean"`
	DigestHex           string `json:"digest_hex"`
}

// RunActive loads the active plan and returns a filled report.
func RunActive(appRoot string) (Report, error) {
	dir, err := config.ActivePaths(appRoot)
	if err != nil {
		return Report{}, err
	}
	plan, profiles, rows, offsets, err := config.LoadPlan(dir)
	if err != nil {
		return Report{}, err
	}
	out := engine.Replay(plan.ClusterID, plan.QSize, plan.SepSeq, plan.TimeoutTightMS, plan.StableTerm, plan.FallbackTerm, profiles, rows, offsets)
	ck := "true"
	if !out.MembershipClean {
		ck = "false"
	}
	digest := sha256.Sum256([]byte(fmt.Sprintf(
		"%s|%d|%d|%d|%d|%d|%d|%d|%s|%s",
		plan.ClusterID,
		out.LeaderTerm,
		out.StableSeq,
		out.VoteRepairs,
		out.SplitGaps,
		out.NodesActive,
		out.DemoteCount,
		out.PromoteCount,
		out.TimeoutBand,
		ck,
	)))
	return Report{
		SchemaVersion:     "1",
		ClusterID:            plan.ClusterID,
		LeaderTerm:        out.LeaderTerm,
		StableSeq:       out.StableSeq,
		VoteRepairs: out.VoteRepairs,
		SplitGaps:   out.SplitGaps,
		NodesActive:        out.NodesActive,
		DemoteCount:       out.DemoteCount,
		PromoteCount:         out.PromoteCount,
		TimeoutBand:          out.TimeoutBand,
		MembershipClean:     out.MembershipClean,
		DigestHex:         hex.EncodeToString(digest[:]),
	}, nil
}
