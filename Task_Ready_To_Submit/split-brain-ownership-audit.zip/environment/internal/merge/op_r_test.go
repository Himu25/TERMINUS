package merge

import (
	"testing"

	"lab.local/split_brain_ownership_audit/pkg/frame"
)

func TestFusePlanEmpty(t *testing.T) {
	out := FusePlan(0, 3, 5, 25, 2, 1, map[string]int64{}, map[uint32][]frame.Row{}, map[uint32][]frame.Row{})
	if out.StableSeq != 0 {
		t.Fatalf("unexpected converge %d", out.StableSeq)
	}
}
