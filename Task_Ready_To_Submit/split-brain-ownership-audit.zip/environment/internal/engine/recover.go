package engine

import (
	"lab.local/split_brain_ownership_audit/internal/freeze"
	"lab.local/split_brain_ownership_audit/internal/merge"
	"lab.local/split_brain_ownership_audit/pkg/frame"
	node "lab.local/split_brain_ownership_audit/pkg/nodepkg"
)

// Replay executes one plan through freeze and merge stages.
func Replay(
	planID string,
	qSize int,
	sepSeq uint32,
	propTight int64,
	stableTerm uint32,
	fallbackTerm uint32,
	profiles []node.Profile,
	allRows map[uint32][]frame.Row,
	offsets map[string]int64,
) merge.Outcome {
	wm := freeze.Watermark(profiles)
	above := make(map[uint32][]frame.Row)
	for seq, rows := range allRows {
		if seq > uint32(wm) {
			above[seq] = rows
		}
	}
	out := merge.FusePlan(uint32(wm), qSize, sepSeq, propTight, stableTerm, fallbackTerm, offsets, above, allRows)
	_ = planID
	return out
}
