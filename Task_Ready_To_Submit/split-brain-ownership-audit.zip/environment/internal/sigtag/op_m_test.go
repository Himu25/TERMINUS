package sigtag

import (
	"testing"

	"lab.local/split_brain_ownership_audit/pkg/frame"
)

func TestOpSealMatchesWireCRC(t *testing.T) {
	seq := uint32(4)
	svc := "s17"
	ver := uint32(2)
	tag := frame.WireCRC(seq, svc, ver)
	if !OpSeal(seq, svc, ver, tag) {
		t.Fatal("valid wire tag should pass integrity check")
	}
	if OpSeal(seq, svc, ver, tag+1) {
		t.Fatal("corrupted tag must fail integrity check")
	}
}
