package freeze

import (
	"lab.local/split_brain_ownership_audit/pkg/rosterfold"
	node "lab.local/split_brain_ownership_audit/pkg/nodepkg"
)

// Watermark collects depart marks from node profiles.
func Watermark(profiles []node.Profile) int64 {
	marks := make([]int64, 0, len(profiles))
	for _, p := range profiles {
		marks = append(marks, int64(p.DepartMark))
	}
	return rosterfold.OpF(marks)
}
