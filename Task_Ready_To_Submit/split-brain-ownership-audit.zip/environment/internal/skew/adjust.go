package skew

import (
	"lab.local/split_brain_ownership_audit/pkg/frame"
	"lab.local/split_brain_ownership_audit/pkg/timenorm"
)

// AdjustWall normalizes sent time for a beat row.
func AdjustWall(row frame.Row, offset int64) int64 {
	return timenorm.OpT(row.WallMS, offset)
}
