"""Validate /app/output/stow_report.json against stow.toml guardrails."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "stow_report.json"
MOVES = APP / "data" / "moves_default.jsonl"
LAYOUT = APP / "data" / "bay_layout.json"
CFG = APP / "config" / "stow.toml"
CASES = Path(__file__).resolve().parent / "data"

_DEFAULT_MOVES_TEXT = MOVES.read_text(encoding="utf-8") if MOVES.is_file() else ""

REPORT_KEYS = frozenset(
    {
        "status",
        "moves_processed",
        "report_ok",
        "max_drift_units",
        "moment_total_centinm",
        "lashing_peak_n",
        "occupancy_total",
        "report_digest",
        "bays",
    }
)
BAY_KEYS = frozenset(
    {
        "bay_id",
        "moment_centinm",
        "lashing_peak_n",
        "occupancy",
        "drift_units",
    }
)


def _parse_cfg() -> dict[str, int]:
    cfg: dict[str, int] = {
        "max_drift_units": 0,
        "max_lashing_peak_n": 50000,
        "min_occupancy_total": 1,
    }
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key in cfg:
            cfg[key] = int(float(val))
    return cfg


def _load_layout() -> dict[str, dict[str, int]]:
    raw = json.loads(LAYOUT.read_text(encoding="utf-8"))
    tier_arm = {int(k): v for k, v in raw["tier_arm_dm"].items()}
    lash_scale = {1: 120, 2: 240, 3: 360}
    for line in CFG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, val = (part.strip() for part in line.split("=", 1))
        if key == "lash_scale_tier1":
            lash_scale[1] = int(float(val))
        elif key == "lash_scale_tier2":
            lash_scale[2] = int(float(val))
        elif key == "lash_scale_tier3":
            lash_scale[3] = int(float(val))
    return {"tier_arm": tier_arm, "lash_scale": lash_scale}


def _parse_moves(text: str) -> list[dict]:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if line:
            rows.append(json.loads(line))
    return rows


def _crane_rank(crane_id: str) -> int:
    if not crane_id:
        return 99
    last = crane_id[-1]
    if last.isdigit():
        return int(last)
    return 99


def _sort_moves(rows: list[dict]) -> list[dict]:
    return sorted(
        rows,
        key=lambda row: (row["seq"], _crane_rank(row["crane_id"]), row["crane_id"]),
    )


def _slot_key(bay: str, tier: int, row: int) -> str:
    return f"{bay}:{tier}:{row}"


def _expected_from_moves(moves_text: str) -> dict[str, dict]:
    layout = _load_layout()
    tier_arm = layout["tier_arm"]
    lash_scale = layout["lash_scale"]
    ordered = _sort_moves(_parse_moves(moves_text))
    slots: dict[str, dict] = {}
    bay_moment: dict[str, int] = {}
    bay_occ: dict[str, int] = {}

    for mv in ordered:
        bay = mv["bay_id"]
        key = _slot_key(bay, mv["tier"], mv["row"])
        arm = tier_arm[mv["tier"]]
        weight = mv["weight_kg"]
        delta = weight * arm // 100
        if mv["op"] == "clear":
            delta = -delta
        bay_moment[bay] = bay_moment.get(bay, 0) + delta
        if mv["op"] == "set":
            if key not in slots:
                bay_occ[bay] = bay_occ.get(bay, 0) + 1
            slots[key] = {"tier": mv["tier"], "weight": weight}
        elif mv["op"] == "clear" and key in slots:
            del slots[key]
            bay_occ[bay] = bay_occ.get(bay, 0) - 1

    bays: dict[str, dict] = {}
    for bay in sorted({mv["bay_id"] for mv in ordered}):
        prefix = f"{bay}:"
        slot_occ = sum(1 for k in slots if k.startswith(prefix))
        peak = 0
        for k, info in slots.items():
            if not k.startswith(prefix):
                continue
            lash = info["weight"] * lash_scale[info["tier"]] // 1000
            peak = max(peak, lash)
        bays[bay] = {
            "moment_centinm": bay_moment.get(bay, 0),
            "occupancy": bay_occ.get(bay, 0),
            "lashing_peak_n": peak,
            "drift_units": abs(bay_occ.get(bay, 0) - slot_occ),
        }

    total_moment = sum(v["moment_centinm"] for v in bays.values())
    total_occ = sum(v["occupancy"] for v in bays.values())
    global_lash = max((v["lashing_peak_n"] for v in bays.values()), default=0)
    max_drift = max((v["drift_units"] for v in bays.values()), default=0)
    return {
        "bays": bays,
        "moment_total_centinm": total_moment,
        "occupancy_total": total_occ,
        "lashing_peak_n": global_lash,
        "max_drift_units": max_drift,
        "moves_processed": len(ordered),
    }


def _atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def _swap_fixture(stem: str) -> str:
    src = CASES / f"{stem}.jsonl"
    text = src.read_text(encoding="utf-8")
    _atomic_write_text(MOVES, text)
    return text


def _expected_digest(report: dict) -> str:
    payload = dict(report)
    payload["report_digest"] = ""
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    proc = subprocess.run(
        ["sha256sum"],
        input=raw,
        text=True,
        capture_output=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _invoke_default() -> None:
    proc = subprocess.run(
        ["/app/tools/run_replay"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "stow_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


def _bay_map(report: dict) -> dict[str, dict]:
    return {row["bay_id"]: row for row in report["bays"]}


def _assert_global_lashing_invariants(report: dict, cfg: dict[str, int]) -> None:
    bay_peaks = [row["lashing_peak_n"] for row in report["bays"]]
    assert report["lashing_peak_n"] == max(bay_peaks, default=0)
    assert report["lashing_peak_n"] <= cfg["max_lashing_peak_n"]


@pytest.fixture(scope="module", autouse=True)
def _ensure_report() -> None:
    _invoke_default()


@pytest.fixture(autouse=True)
def restore_default_moves() -> None:
    yield
    if _DEFAULT_MOVES_TEXT:
        _atomic_write_text(MOVES, _DEFAULT_MOVES_TEXT)


def test_g1_schema() -> None:
    """Report must expose only the documented top-level keys."""
    report = _load_report()
    assert set(report.keys()) == REPORT_KEYS


def test_g8_row_shape() -> None:
    """Each bay row must match the documented per-bay schema."""
    report = _load_report()
    assert report["bays"]
    for row in report["bays"]:
        assert set(row.keys()) == BAY_KEYS
        assert isinstance(row["bay_id"], str) and row["bay_id"]
        assert isinstance(row["moment_centinm"], int)
        assert isinstance(row["lashing_peak_n"], int)
        assert isinstance(row["occupancy"], int)
        assert isinstance(row["drift_units"], int)


def test_g2_guardrails() -> None:
    """Default bundle must finish ok and meet stow.toml guardrails."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["status"] == "ok"
    assert report["report_ok"]
    assert report["max_drift_units"] <= cfg["max_drift_units"]
    assert report["occupancy_total"] >= cfg["min_occupancy_total"]


def test_g2a_global_lashing_peak_is_bay_max() -> None:
    """Top-level lashing_peak_n must equal the maximum per-bay lashing peak."""
    cfg = _parse_cfg()
    _assert_global_lashing_invariants(_load_report(), cfg)


def test_g2b_lashing_peak_within_config_cap() -> None:
    """Global lashing_peak_n must respect max_lashing_peak_n from stow.toml."""
    cfg = _parse_cfg()
    report = _load_report()
    assert report["lashing_peak_n"] <= cfg["max_lashing_peak_n"]


def test_g3_total_a() -> None:
    """Default replay moment_total_centinm must match layout-derived replay."""
    expected = _expected_from_moves(_DEFAULT_MOVES_TEXT)
    report = _load_report()
    assert report["moment_total_centinm"] == expected["moment_total_centinm"]


def test_g4_total_b() -> None:
    """Default replay occupancy_total must match slot-derived occupancy."""
    expected = _expected_from_moves(_DEFAULT_MOVES_TEXT)
    report = _load_report()
    assert report["occupancy_total"] == expected["occupancy_total"]


def test_g5_row_a() -> None:
    """B01 moment after tier-2 clear must match layout-derived replay."""
    expected = _expected_from_moves(_DEFAULT_MOVES_TEXT)
    report = _load_report()
    b01 = _bay_map(report)["B01"]
    assert b01["moment_centinm"] == expected["bays"]["B01"]["moment_centinm"]


def test_g6_row_b() -> None:
    """B01 occupancy after tier-2 clear must match slot ledger."""
    cfg = _parse_cfg()
    expected = _expected_from_moves(_DEFAULT_MOVES_TEXT)
    report = _load_report()
    b01 = _bay_map(report)["B01"]
    assert b01["occupancy"] == expected["bays"]["B01"]["occupancy"]
    assert b01["drift_units"] <= cfg["max_drift_units"]


def test_g7_row_c() -> None:
    """B04 slot clash must reflect C1-first tie resolution."""
    expected = _expected_from_moves(_DEFAULT_MOVES_TEXT)
    report = _load_report()
    b04 = _bay_map(report)["B04"]
    assert b04["moment_centinm"] == expected["bays"]["B04"]["moment_centinm"]
    assert b04["occupancy"] == expected["bays"]["B04"]["occupancy"]


def test_g9_count() -> None:
    """moves_processed must equal non-empty rows in the active bundle."""
    expected = _expected_from_moves(_DEFAULT_MOVES_TEXT)
    report = _load_report()
    assert report["moves_processed"] == expected["moves_processed"]


def test_g15_digest() -> None:
    """report_digest must hash the compact pre-digest JSON payload."""
    report = _load_report()
    assert report["report_digest"] == _expected_digest(report)


def test_g16_digest_format() -> None:
    """report_digest must be 64 lowercase hexadecimal characters."""
    digest = _load_report()["report_digest"]
    assert isinstance(digest, str)
    assert len(digest) == 64
    assert digest == digest.lower()
    int(digest, 16)


def test_g10_rerun() -> None:
    """Two back-to-back default runs must emit byte-identical reports."""
    first = OUT.read_bytes()
    _invoke_default()
    second = OUT.read_bytes()
    assert first == second


def test_g11_case_a() -> None:
    """Dual-crane open scenario must reconcile B01 moment and occupancy."""
    moves_text = _swap_fixture("dual_crane_open")
    _invoke_default()
    expected = _expected_from_moves(moves_text)
    report = _load_report()
    b01 = _bay_map(report)["B01"]
    cfg = _parse_cfg()
    assert b01["drift_units"] <= cfg["max_drift_units"]
    assert b01["moment_centinm"] == expected["bays"]["B01"]["moment_centinm"]
    assert b01["occupancy"] == expected["bays"]["B01"]["occupancy"]
    _assert_global_lashing_invariants(report, cfg)


def test_g12_case_b() -> None:
    """Stacked triple scenario must reconcile B02 moment and lash peak."""
    moves_text = _swap_fixture("stacked_triple")
    _invoke_default()
    expected = _expected_from_moves(moves_text)
    report = _load_report()
    b02 = _bay_map(report)["B02"]
    cfg = _parse_cfg()
    assert b02["drift_units"] <= cfg["max_drift_units"]
    assert b02["moment_centinm"] == expected["bays"]["B02"]["moment_centinm"]
    assert b02["occupancy"] == expected["bays"]["B02"]["occupancy"]
    assert b02["lashing_peak_n"] == expected["bays"]["B02"]["lashing_peak_n"]
    _assert_global_lashing_invariants(report, cfg)


def test_g13_case_c() -> None:
    """Slot clash scenario must keep C1-first weight on B04."""
    moves_text = _swap_fixture("slot_clash")
    _invoke_default()
    expected = _expected_from_moves(moves_text)
    report = _load_report()
    b04 = _bay_map(report)["B04"]
    cfg = _parse_cfg()
    assert b04["drift_units"] <= cfg["max_drift_units"]
    assert b04["moment_centinm"] == expected["bays"]["B04"]["moment_centinm"]
    assert b04["lashing_peak_n"] == expected["bays"]["B04"]["lashing_peak_n"]
    _assert_global_lashing_invariants(report, cfg)


def test_g14_case_d() -> None:
    """Clear-after-peer scenario must reconcile B01 ledger drift."""
    moves_text = _swap_fixture("clear_after_peer")
    _invoke_default()
    expected = _expected_from_moves(moves_text)
    cfg = _parse_cfg()
    report = _load_report()
    b01 = _bay_map(report)["B01"]
    assert report["max_drift_units"] <= cfg["max_drift_units"]
    assert b01["drift_units"] <= cfg["max_drift_units"]
    assert b01["occupancy"] == expected["bays"]["B01"]["occupancy"]
    _assert_global_lashing_invariants(report, cfg)
