Stow replay semantics

Vertical moment centinm delta per move multiplies weight_kg by the tier arm in decimeters from /app/data/bay_layout.json, divides by 100 with integer truncation toward zero (weight_kg * arm_dm // 100). Set moves add that delta; clear moves subtract the same magnitude applied at placement.

Lashing peak per bay is the maximum occupied-slot load: weight_kg times the tier lash scale from /app/config/stow.toml divided by 1000 with integer truncation toward zero (weight_kg * lash_scale // 1000).

Occupancy counts distinct occupied slots per bay after replay. Drift units compare ledger occupancy against slot-derived occupancy for each bay.

Crane tie-break: when seq values match, lower crane_id runs first when crane_priority_asc is true in /app/config/stow.toml.

Report JSON top-level fields: status, moves_processed, report_ok, max_drift_units, moment_total_centinm, lashing_peak_n, occupancy_total, report_digest, bays. Each bay row carries bay_id, moment_centinm, lashing_peak_n, occupancy, drift_units. Report digest is 64 lowercase hex from compact JSON with report_digest blanked.
