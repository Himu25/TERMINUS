movepack copies manifest JSONL to the active moves bundle.
baysim loads moves, sorts with tie policy, replays through the slot ledger and native arm integrator, and writes /app/output/stow_report.json.
