#!/bin/bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1

mkdir -p /app/bin
cd /app/r7
cargo build --release --locked
cd /app
GOFLAGS=-mod=mod go build -o /app/bin/baysim ./cmd/baysim
GOFLAGS=-mod=mod go build -o /app/bin/movepack ./cmd/movepack
