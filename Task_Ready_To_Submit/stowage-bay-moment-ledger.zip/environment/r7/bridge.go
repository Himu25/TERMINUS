package r7

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libr7_arm.a -ldl -lm
#include "fold_arm.h"
*/
import "C"

func Q0Span(op int, weightKg, tierDM int) int64 {
	raw := C.q0_span(C.int(op), C.int(weightKg), C.int(tierDM))
	return int64(raw)
}
