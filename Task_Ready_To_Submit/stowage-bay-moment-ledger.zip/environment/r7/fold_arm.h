#ifndef FOLD_ARM_H
#define FOLD_ARM_H

#include <stdint.h>

int32_t q0_span(int32_t op, int32_t weight_kg, int32_t tier_dm);

#endif
