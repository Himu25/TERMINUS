// Package r7 exposes the native arm integrator to Go callers.
package r7
