package summ

import "sbl.lab/pkg/types"

// S8Fold totals moment centinm across bay snapshots.
func S8Fold(bays []types.BaySnapshot) int64 {
	var sum int64
	for _, bay := range bays {
		sum += bay.MomentCentinm
	}
	return sum
}
