Stowage lab replay harness for multi-crane bay sequences.

Run /app/tools/run_replay after rebuilding with /app/scripts/build.sh.
