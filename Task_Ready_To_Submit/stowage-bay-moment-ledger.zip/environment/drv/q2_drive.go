package drv

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"sort"
	"strings"

	"sbl.lab/j2"
	"sbl.lab/m3"
	"sbl.lab/p5"
	"sbl.lab/pkg/types"
	"sbl.lab/r7"
)

func LoadCfg(path string) (types.StowCfg, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.StowCfg{}, err
	}
	cfg := types.StowCfg{
		MaxDriftUnits:     0,
		MaxLashingPeakN:   50000,
		MinOccupancyTotal: 1,
		CranePriorityAsc:  true,
		LashScaleMilli: map[int]int{
			1: 120,
			2: 240,
			3: 360,
		},
	}
	for _, line := range strings.Split(string(raw), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		switch key {
		case "max_drift_units":
			fmt.Sscanf(val, "%d", &cfg.MaxDriftUnits)
		case "max_lashing_peak_n":
			fmt.Sscanf(val, "%d", &cfg.MaxLashingPeakN)
		case "min_occupancy_total":
			fmt.Sscanf(val, "%d", &cfg.MinOccupancyTotal)
		case "crane_priority_asc":
			cfg.CranePriorityAsc = val == "true" || val == "1"
		case "lash_scale_tier1":
			var v int
			fmt.Sscanf(val, "%d", &v)
			cfg.LashScaleMilli[1] = v
		case "lash_scale_tier2":
			var v int
			fmt.Sscanf(val, "%d", &v)
			cfg.LashScaleMilli[2] = v
		case "lash_scale_tier3":
			var v int
			fmt.Sscanf(val, "%d", &v)
			cfg.LashScaleMilli[3] = v
		}
	}
	return cfg, nil
}

func LoadLayout(path string) (types.BayLayout, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return types.BayLayout{}, err
	}
	var layout struct {
		TierArmDM map[string]int `json:"tier_arm_dm"`
	}
	if err := json.Unmarshal(raw, &layout); err != nil {
		return types.BayLayout{}, err
	}
	out := types.BayLayout{TierArmDM: make(map[int]int)}
	for k, v := range layout.TierArmDM {
		var tier int
		fmt.Sscanf(k, "%d", &tier)
		out.TierArmDM[tier] = v
	}
	return out, nil
}

func LoadMoves(path string) ([]types.MoveRow, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := make([]types.MoveRow, 0)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var row types.MoveRow
		if err := json.Unmarshal([]byte(line), &row); err != nil {
			return nil, err
		}
		out = append(out, row)
	}
	return out, sc.Err()
}

func opCode(op string) int {
	if op == "clear" {
		return 1
	}
	return 0
}

func lashFor(weight, tier int, cfg types.StowCfg) int {
	scale, ok := cfg.LashScaleMilli[tier]
	if !ok {
		scale = 100
	}
	return weight * scale / 1000
}

func bayPeakLash(bay string, slots map[string]slotInfo, cfg types.StowCfg) int {
	peak := 0
	for key, info := range slots {
		if !strings.HasPrefix(key, bay+":") {
			continue
		}
		val := lashFor(info.weight, info.tier, cfg)
		if val > peak {
			peak = val
		}
	}
	return peak
}

type slotInfo struct {
	tier   int
	weight int
}

func replayBayState(slots map[string]slotInfo, bay string) (moment int64, peak int, occ int) {
	prefix := bay + ":"
	for key := range slots {
		if !strings.HasPrefix(key, prefix) {
			continue
		}
		occ++
	}
	return 0, 0, occ
}

func Run(cfg types.StowCfg, layout types.BayLayout, moves []types.MoveRow) (types.StowReport, error) {
	ordered := p5.UxPick(moves)
	state := m3.MkK1()
	bayMoment := make(map[string]int64)
	slotMeta := make(map[string]slotInfo)

	for _, mv := range ordered {
		arm := layout.TierArmDM[mv.Tier]
		delta := r7.Q0Span(opCode(mv.Op), mv.WeightKg, arm)
		bayMoment[mv.BayID] += delta
		m3.RxAccum(state, mv.BayID, mv.Tier, mv.Row, mv.Op, mv.WeightKg)
		key := fmt.Sprintf("%s:%d:%d", mv.BayID, mv.Tier, mv.Row)
		switch mv.Op {
		case "set":
			slotMeta[key] = slotInfo{tier: mv.Tier, weight: mv.WeightKg}
		case "clear":
			delete(slotMeta, key)
		}
	}

	bayIDs := make([]string, 0)
	seen := make(map[string]bool)
	for _, mv := range moves {
		if !seen[mv.BayID] {
			seen[mv.BayID] = true
			bayIDs = append(bayIDs, mv.BayID)
		}
	}
	sort.Strings(bayIDs)

	report := types.StowReport{
		Status:         "ok",
		MovesProcessed: len(ordered),
		Bays:           make([]types.BaySnapshot, 0, len(bayIDs)),
	}
	var totalMoment int64
	maxDrift := 0
	globalLashPeak := 0
	totalOcc := 0

	for _, bay := range bayIDs {
		occ := state.BayOcc[bay]
		moment := bayMoment[bay]
		peak := bayPeakLash(bay, slotMeta, cfg)
		_, _, occCheck := replayBayState(slotMeta, bay)
		drift := j2.S6Fold(int(moment), occ, occCheck)
		if drift < 0 {
			drift = -drift
		}
		if drift > maxDrift {
			maxDrift = drift
		}
		if peak > globalLashPeak {
			globalLashPeak = peak
		}
		totalMoment += moment
		totalOcc += occ
		report.Bays = append(report.Bays, types.BaySnapshot{
			BayID:         bay,
			MomentCentinm: moment,
			LashingPeakN:  peak,
			Occupancy:     occ,
			DriftUnits:    drift,
		})
	}

	report.MomentTotalCentinm = totalMoment
	report.LashingPeakN = globalLashPeak
	report.OccupancyTotal = totalOcc
	report.MaxDriftUnits = maxDrift
	report.ReportOK = maxDrift <= cfg.MaxDriftUnits &&
		globalLashPeak <= cfg.MaxLashingPeakN &&
		totalOcc >= cfg.MinOccupancyTotal
	if !report.ReportOK {
		report.Status = "drift"
	}

	digest, err := digestFor(report)
	if err != nil {
		return types.StowReport{}, err
	}
	report.ReportDigest = digest
	return report, nil
}

func digestFor(report types.StowReport) (string, error) {
	payload := report
	payload.ReportDigest = ""
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(payload); err != nil {
		return "", err
	}
	raw := bytes.TrimSpace(buf.Bytes())
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:]), nil
}

func WriteReport(path string, report types.StowReport) error {
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	enc.SetIndent("", "  ")
	if err := enc.Encode(report); err != nil {
		return err
	}
	return os.WriteFile(path, bytes.TrimSpace(buf.Bytes()), 0o644)
}
