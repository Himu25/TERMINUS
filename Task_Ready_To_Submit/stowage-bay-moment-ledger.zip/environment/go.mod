module sbl.lab

go 1.22
