package types

type StowCfg struct {
	MaxDriftUnits      int
	MaxLashingPeakN    int
	MinOccupancyTotal  int
	CranePriorityAsc   bool
	LashScaleMilli     map[int]int
}

type BayLayout struct {
	TierArmDM map[int]int `json:"tier_arm_dm"`
}

type MoveRow struct {
	MoveID   string `json:"move_id"`
	Seq      int    `json:"seq"`
	CraneID  string `json:"crane_id"`
	BayID    string `json:"bay_id"`
	Tier     int    `json:"tier"`
	Row      int    `json:"row"`
	Op       string `json:"op"`
	WeightKg int    `json:"weight_kg"`
}

type BaySnapshot struct {
	BayID          string `json:"bay_id"`
	MomentCentinm  int64  `json:"moment_centinm"`
	LashingPeakN   int    `json:"lashing_peak_n"`
	Occupancy      int    `json:"occupancy"`
	DriftUnits     int    `json:"drift_units"`
}

type StowReport struct {
	Status             string        `json:"status"`
	MovesProcessed     int           `json:"moves_processed"`
	ReportOK           bool          `json:"report_ok"`
	MaxDriftUnits      int           `json:"max_drift_units"`
	MomentTotalCentinm int64         `json:"moment_total_centinm"`
	LashingPeakN       int           `json:"lashing_peak_n"`
	OccupancyTotal     int           `json:"occupancy_total"`
	ReportDigest       string        `json:"report_digest"`
	Bays               []BaySnapshot `json:"bays"`
}
