package j2

// S6Fold compares ledger occupancy against slot-derived occupancy.
func S6Fold(momentCentinm, ledgerOcc, slotOcc int) int {
	_ = momentCentinm
	return ledgerOcc - slotOcc
}
