#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd /app

log() { printf '==> %s\n' "$1"; }

require_file() {
  if [[ ! -f "$1" ]]; then
    log "missing $1"
    exit 1
  fi
}

log "preflight workspace"
require_file /app/go.mod
require_file /app/config/stow.toml
require_file /app/data/move_manifest.jsonl
require_file /app/data/bay_layout.json
mkdir -p /app/bin /app/output

log "apply integrator patch"
patch -d /app -p0 --batch < "${ROOT_DIR}/patches/r7.patch"

log "apply ledger patch"
patch -d /app -p0 --batch < "${ROOT_DIR}/patches/m3.patch"

log "apply tie-policy patch"
patch -d /app -p0 --batch < "${ROOT_DIR}/patches/p5.patch"

log "rebuild replay harness"
bash /app/scripts/build.sh

log "refresh default move bundle"
/app/bin/movepack /app/data/move_manifest.jsonl /app/data/moves_default.jsonl

log "emit default stow report"
/app/tools/run_replay

log "post-run validation against stow.toml thresholds"
python3 - <<'PY'
import json
from pathlib import Path

cfg = {}
for line in Path("/app/config/stow.toml").read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k, v = (part.strip() for part in line.split("=", 1))
    if k in ("max_drift_units", "max_lashing_peak_n", "min_occupancy_total"):
        cfg[k] = int(float(v))

report = json.loads(Path("/app/output/stow_report.json").read_text())
assert report["status"] == "ok", report
assert report["report_ok"]
assert report["max_drift_units"] <= cfg["max_drift_units"]
assert report["occupancy_total"] >= cfg["min_occupancy_total"]
assert report["lashing_peak_n"] <= cfg["max_lashing_peak_n"]
print("ok", report["moment_total_centinm"], report["occupancy_total"])
PY

log "oracle complete"
