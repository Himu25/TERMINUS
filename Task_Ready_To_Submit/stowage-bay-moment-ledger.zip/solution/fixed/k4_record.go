package m3

import "fmt"

type K1State struct {
	Slots  map[string]int
	BayOcc map[string]int
}

func MkK1() *K1State {
	return &K1State{
		Slots:  make(map[string]int),
		BayOcc: make(map[string]int),
	}
}

func q1_key(a string, tier, row int) string {
	return fmt.Sprintf("%s:%d:%d", a, tier, row)
}

func q1_norm(a string) string {
	if a == "" {
		return "B00"
	}
	return a
}

func q1_put(state *K1State, key, a string, weight int) {
	state.Slots[key] = weight
	if state.BayOcc[a] == 0 {
		state.BayOcc[a] = 0
	}
}

func q1_drop(state *K1State, key, a string) {
	if _, ok := state.Slots[key]; ok {
		delete(state.Slots, key)
		state.BayOcc[a]--
		if state.BayOcc[a] < 0 {
			state.BayOcc[a] = 0
		}
	}
}

func RxAccum(state *K1State, a string, tier, row int, op string, weight int) {
	a = q1_norm(a)
	key := q1_key(a, tier, row)
	switch op {
	case "set":
		if _, occupied := state.Slots[key]; !occupied {
			state.BayOcc[a]++
		}
		q1_put(state, key, a, weight)
	case "clear":
		q1_drop(state, key, a)
	default:
		return
	}
}
