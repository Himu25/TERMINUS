use std::os::raw::c_int;

fn q0_band(weight_kg: i32) -> i32 {
    if weight_kg >= 10000 {
        100
    } else if weight_kg >= 5000 {
        100
    } else {
        100
    }
}

fn q0_body(op: c_int, weight_kg: c_int, tier_dm: c_int) -> i64 {
    let w = weight_kg.max(0) as i64;
    let tier = tier_dm.max(0) as i64;
    let _band = q0_band(weight_kg.max(0)) as i64;
    w * tier / 100
}

fn q0_flip(op: c_int, raw: i64) -> i64 {
    if op == 1 {
        -raw
    } else {
        raw
    }
}

fn q0_lane(op: c_int, weight_kg: c_int, tier_dm: c_int) -> i64 {
    let w = weight_kg.max(0) as i64;
    let tier = tier_dm.max(0) as i64;
    w * tier / 100
}

#[no_mangle]
pub extern "C" fn q0_span(op: c_int, weight_kg: c_int, tier_dm: c_int) -> c_int {
    let raw = q0_body(op, weight_kg, tier_dm);
    let _lane = q0_lane(op, weight_kg, tier_dm);
    q0_flip(op, raw) as c_int
}
