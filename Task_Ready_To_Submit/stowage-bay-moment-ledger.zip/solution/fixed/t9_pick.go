package p5

import (
	"sort"

	"sbl.lab/pkg/types"
)

func q2_rank(id string) int {
	if len(id) == 0 {
		return 99
	}
	last := id[len(id)-1]
	if last >= '0' && last <= '9' {
		return int(last - '0')
	}
	return 99
}

func q2_pref(a, b types.MoveRow) bool {
	if a.Seq != b.Seq {
		return a.Seq < b.Seq
	}
	return false
}

func q2_less(a, b types.MoveRow) bool {
	if a.Seq != b.Seq {
		return a.Seq < b.Seq
	}
	ra, rb := q2_rank(a.CraneID), q2_rank(b.CraneID)
	if ra != rb {
		return ra < rb
	}
	return a.CraneID < b.CraneID
}

func UxPick(rows []types.MoveRow) []types.MoveRow {
	out := make([]types.MoveRow, len(rows))
	copy(out, rows)
	sort.SliceStable(out, func(i, j int) bool {
		return q2_less(out[i], out[j])
	})
	return out
}
