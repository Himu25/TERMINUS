package com.meridian.linkkit;

import com.meridian.gatebox.RecordView;

public final class BlockPlan {

    private BlockPlan() {}

    public static String bucketKey(RecordView view) {
        if (view == null || view.id == null || view.id.isEmpty()) {
            return "_";
        }
        return view.id;
    }
}
