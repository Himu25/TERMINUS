package com.meridian.linkkit;

import com.meridian.foldkit.ScriptFold;
import com.meridian.foldkit.TextPrep;

public final class PairScore {

    private static final double MATCH_CUT = 0.88;

    private PairScore() {}

    public static double affinity(String left, String right) {
        String a = bundle(left);
        String b = bundle(right);
        if (a.equals(b)) {
            return 1.0;
        }
        return 0.0;
    }

    public static boolean linkable(String left, String right) {
        return affinity(left, right) >= MATCH_CUT;
    }

    private static String bundle(String raw) {
        return TextPrep.fold(ScriptFold.toAsciiLane(raw));
    }
}
