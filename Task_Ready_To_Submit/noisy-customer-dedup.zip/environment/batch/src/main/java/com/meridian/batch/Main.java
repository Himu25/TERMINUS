package com.meridian.batch;

import java.nio.file.Files;
import java.nio.file.Path;

public final class Main {

    private Main() {}

    public static void main(String[] args) throws Exception {
        Path profile =
                args.length > 0
                        ? Path.of(args[0])
                        : Path.of("/app/config/bench_profiles.json");
        String labelsOverride = System.getenv("MERIDIAN_LABELS_PATH");
        Path labels =
                labelsOverride == null || labelsOverride.isBlank()
                        ? Path.of("/app/registry/pair_labels.json")
                        : Path.of(labelsOverride);
        Path thresholds = Path.of("/app/config/thresholds.toml");
        Path output = Path.of("/app/output/dedup_report.json");
        Files.createDirectories(output.getParent());
        RunLedger ledger = new RunLedger(profile, labels, thresholds, output);
        ledger.execute();
    }
}
