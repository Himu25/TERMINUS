package com.meridian.batch;

import java.util.List;

// Bench row contract: rows_in rows_quarantined clusters pairs_expected pairs_found pair_recall components

public final class SuiteResult {
    public final String name;
    public final int rowsIn;
    public final int rowsQuarantined;
    public final int clusters;
    public final int pairsExpected;
    public final int pairsFound;
    public final double pairRecall;
    public final List<List<String>> components;

    public SuiteResult(
            String name,
            int rowsIn,
            int rowsQuarantined,
            int clusters,
            int pairsExpected,
            int pairsFound,
            double pairRecall,
            List<List<String>> components) {
        this.name = name;
        this.rowsIn = rowsIn;
        this.rowsQuarantined = rowsQuarantined;
        this.clusters = clusters;
        this.pairsExpected = pairsExpected;
        this.pairsFound = pairsFound;
        this.pairRecall = pairRecall;
        this.components = components;
    }
}
