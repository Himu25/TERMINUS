package com.meridian.batch;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public final class ThresholdCatalog {

    private ThresholdCatalog() {}

    public static Map<String, Double> load(Path path) throws IOException {
        Map<String, Double> floors = new HashMap<>();
        for (String line : Files.readAllLines(path, StandardCharsets.UTF_8)) {
            String stripped = line.split("#", 2)[0].trim();
            if (stripped.isEmpty() || !stripped.contains("=")) {
                continue;
            }
            String[] parts = stripped.split("=", 2);
            floors.put(parts[0].trim(), Double.parseDouble(parts[1].trim()));
        }
        return floors;
    }
}
