package com.meridian.batch;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.meridian.report.SummaryEmit;

public final class RunLedger {

    private final Path profilePath;
    private final Path labelsPath;
    private final Path thresholdsPath;
    private final Path outputPath;

    public RunLedger(Path profilePath, Path labelsPath, Path thresholdsPath, Path outputPath) {
        this.profilePath = profilePath;
        this.labelsPath = labelsPath;
        this.thresholdsPath = thresholdsPath;
        this.outputPath = outputPath;
    }

    public void execute() throws IOException {
        String profileJson = Files.readString(profilePath, StandardCharsets.UTF_8);
        Map<String, List<String[]>> labels;
        if (Files.exists(labelsPath)) {
            String labelsJson = Files.readString(labelsPath, StandardCharsets.UTF_8);
            labels = LabelCatalog.parse(labelsJson);
        } else {
            labels = Map.of();
        }
        List<ProfileEntry> entries = ProfileCatalog.parseSuites(profileJson);

        List<SuiteResult> results = new ArrayList<>();
        for (ProfileEntry entry : entries) {
            List<String[]> pairs = labels.getOrDefault(entry.name, List.of());
            results.add(DedupEngine.runSuite(entry.name, Path.of(entry.path), pairs));
        }

        Map<String, Double> floors = ThresholdCatalog.load(thresholdsPath);
        SummaryEmit.writeReport(outputPath, results, floors);
    }
}
