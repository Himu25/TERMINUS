package com.meridian.batch;

import com.meridian.bindkit.GroupMerge;
import com.meridian.gatebox.RecordView;
import com.meridian.gatebox.RowGate;
import com.meridian.linkkit.BlockPlan;
import com.meridian.linkkit.PairScore;
import com.meridian.foldkit.ScriptFold;
import com.meridian.foldkit.TextPrep;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class DedupEngine {

    private DedupEngine() {}

    public static SuiteResult runSuite(String suiteName, Path csvPath, List<String[]> expectedPairs)
            throws IOException {
        List<String> lines = Files.readAllLines(csvPath, StandardCharsets.UTF_8);
        List<RecordView> records = new ArrayList<>();
        int quarantined = 0;
        int rowIndex = 0;
        for (String line : lines) {
            String trimmed = line.trim();
            if (trimmed.isEmpty() || trimmed.startsWith("#")) {
                continue;
            }
            if (trimmed.equalsIgnoreCase("id,name,email,postal")) {
                continue;
            }
            String[] cols = trimmed.split(",", -1);
            if (!RowGate.admit(cols)) {
                quarantined++;
                continue;
            }
            records.add(
                    new RecordView(
                            cols[0].trim(),
                            cols[1].trim(),
                            cols[2].trim(),
                            cols[3].trim(),
                            rowIndex++));
        }

        Map<String, List<Integer>> blocks = new HashMap<>();
        for (int i = 0; i < records.size(); i++) {
            RecordView view = records.get(i);
            String key = BlockPlan.bucketKey(view);
            blocks.computeIfAbsent(key, k -> new ArrayList<>()).add(i);
        }

        GroupMerge merger = new GroupMerge(records.size());
        for (List<Integer> members : blocks.values()) {
            for (int i = 0; i < members.size(); i++) {
                for (int j = i + 1; j < members.size(); j++) {
                    int left = members.get(i);
                    int right = members.get(j);
                    RecordView a = records.get(left);
                    RecordView b = records.get(right);
                    String bundleLeft = fieldBundle(a);
                    String bundleRight = fieldBundle(b);
                    if (PairScore.linkable(bundleLeft, bundleRight)) {
                        merger.mergeGroups(left, right);
                    }
                }
            }
        }

        int clusters = merger.clusterCount();
        Map<String, Integer> idToIndex = new HashMap<>();
        for (int i = 0; i < records.size(); i++) {
            idToIndex.put(records.get(i).id, i);
        }

        Map<Integer, List<String>> rootToIds = new HashMap<>();
        for (RecordView record : records) {
            int root = merger.find(idToIndex.get(record.id));
            rootToIds.computeIfAbsent(root, ignored -> new ArrayList<>()).add(record.id);
        }
        List<List<String>> components = new ArrayList<>();
        for (List<String> ids : rootToIds.values()) {
            ids.sort(String::compareTo);
            components.add(ids);
        }
        components.sort(Comparator.comparing(group -> group.get(0)));

        int pairsExpected = expectedPairs.size();
        int pairsFound = 0;
        for (String[] pair : expectedPairs) {
            Integer left = idToIndex.get(pair[0]);
            Integer right = idToIndex.get(pair[1]);
            if (left == null || right == null) {
                continue;
            }
            if (merger.find(left) == merger.find(right)) {
                pairsFound++;
            }
        }

        double recall =
                pairsExpected == 0 ? 1.0 : round4((double) pairsFound / (double) pairsExpected);

        return new SuiteResult(
                suiteName,
                records.size(),
                quarantined,
                clusters,
                pairsExpected,
                pairsFound,
                recall,
                components);
    }

    private static String fieldBundle(RecordView view) {
        String name = TextPrep.fold(ScriptFold.toAsciiLane(view.name));
        String email = TextPrep.fold(ScriptFold.toAsciiLane(view.email));
        String postal = TextPrep.fold(ScriptFold.toAsciiLane(view.postal));
        return name + "|" + email + "|" + postal;
    }

    private static double round4(double value) {
        return Math.round(value * 10000.0) / 10000.0;
    }
}
