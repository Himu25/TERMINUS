package com.meridian.batch;

public final class ProfileEntry {
    public final String name;
    public final String path;

    public ProfileEntry(String name, String path) {
        this.name = name;
        this.path = path;
    }
}
