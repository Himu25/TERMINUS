package com.meridian.batch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class LabelCatalog {

    private static final Pattern SUITE_BLOCK =
            Pattern.compile("\"([a-z0-9_]+)\"\\s*:\\s*\\[((?:\\[\\s*\"[^\"]+\"\\s*,\\s*\"[^\"]+\"\\s*\\]\\s*,?\\s*)+)\\]");
    private static final Pattern PAIR = Pattern.compile("\\[\\s*\"([^\"]+)\"\\s*,\\s*\"([^\"]+)\"\\s*\\]");

    private LabelCatalog() {}

    public static Map<String, List<String[]>> parse(String json) {
        Map<String, List<String[]>> out = new HashMap<>();
        Matcher suiteMatcher = SUITE_BLOCK.matcher(json);
        while (suiteMatcher.find()) {
            String suite = suiteMatcher.group(1);
            String body = suiteMatcher.group(2);
            List<String[]> pairs = new ArrayList<>();
            Matcher pairMatcher = PAIR.matcher(body);
            while (pairMatcher.find()) {
                pairs.add(new String[] {pairMatcher.group(1), pairMatcher.group(2)});
            }
            out.put(suite, pairs);
        }
        return out;
    }
}
