package com.meridian.batch;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ProfileCatalog {

    private static final Pattern SUITE =
            Pattern.compile("\\{\\s*\"name\"\\s*:\\s*\"([^\"]+)\"\\s*,\\s*\"path\"\\s*:\\s*\"([^\"]+)\"\\s*\\}");

    private ProfileCatalog() {}

    public static List<ProfileEntry> parseSuites(String json) {
        List<ProfileEntry> entries = new ArrayList<>();
        Matcher matcher = SUITE.matcher(json);
        while (matcher.find()) {
            entries.add(new ProfileEntry(matcher.group(1), matcher.group(2)));
        }
        return entries;
    }
}
