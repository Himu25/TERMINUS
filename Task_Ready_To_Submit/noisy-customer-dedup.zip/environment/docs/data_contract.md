# Data contract

Each suite CSV uses header `id,name,email,postal`. IDs are opaque keys. Adjudicated duplicate pairs for scoring are injected at verification time only; the repair image does not ship that registry.

Physical line counts include every non-comment line after the header, including lines that should be quarantined.
