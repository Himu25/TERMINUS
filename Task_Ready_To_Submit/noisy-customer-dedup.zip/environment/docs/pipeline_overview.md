# Meridian consolidation batch

The batch ingests customer CSV feeds, quarantines malformed physical lines, normalizes fields for matching, blocks candidates, scores pairs, and merges groups. Nightly benches read suite corpora under `/app/data/` and write `/app/output/dedup_report.json`.

## Modules

- `com.meridian.gatebox` — row admission and record views
- `com.meridian.foldkit` — field folding before scoring
- `com.meridian.linkkit` — blocking keys and affinity
- `com.meridian.bindkit` — disjoint-set merges
- `com.meridian.batch` — suite orchestration
- `com.meridian.report` — JSON summary emission

## Operator entrypoints

Rebuild: `mvn -q -DskipTests package`

Run default bench: `/app/tools/dedup_harness`
