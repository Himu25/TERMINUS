Verifier invokes /app/tools/dedup_harness after agent edits. Logs land under /logs/verifier in Harbor runs.
