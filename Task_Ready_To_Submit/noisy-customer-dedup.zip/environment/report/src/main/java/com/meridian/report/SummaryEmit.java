package com.meridian.report;

import com.meridian.batch.SuiteResult;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Report JSON layout written to /app/output/dedup_report.json:
 * suites[].name, suites[].rows_in, suites[].rows_quarantined, suites[].clusters,
 * suites[].pairs_expected, suites[].pairs_found, suites[].pair_recall,
 * suites[].components,
 * summary.composite_recall, summary.total_quarantined, summary.passes_gate.
 */
public final class SummaryEmit {

    private static final Map<String, String> FLOOR_KEYS =
            Map.ofEntries(
                    Map.entry("clean_anchor", "clean_recall_min"),
                    Map.entry("ocr_noise_suite", "ocr_recall_min"),
                    Map.entry("script_mix_suite", "script_recall_min"),
                    Map.entry("corrupt_mix_suite", "corrupt_recall_min"),
                    Map.entry("cross_block", "cross_block_recall_min"),
                    Map.entry("transitive_chain", "transitive_recall_min"),
                    Map.entry("near_miss", "near_miss_recall_min"),
                    Map.entry("five_link_chain", "five_link_recall_min"),
                    Map.entry("email_local_trap", "email_local_recall_min"),
                    Map.entry("nfc_dup", "nfc_recall_min"),
                    Map.entry("stress_bulk", "bulk_recall_min"));

    private SummaryEmit() {}

    private static String componentJson(List<List<String>> components) {
        StringBuilder out = new StringBuilder();
        out.append("[");
        for (int i = 0; i < components.size(); i++) {
            List<String> group = components.get(i);
            out.append("[");
            for (int j = 0; j < group.size(); j++) {
                out.append("\"").append(escapeJson(group.get(j))).append("\"");
                if (j + 1 < group.size()) {
                    out.append(", ");
                }
            }
            out.append("]");
            if (i + 1 < components.size()) {
                out.append(", ");
            }
        }
        out.append("]");
        return out.toString();
    }

    private static String escapeJson(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    public static void writeReport(Path output, List<SuiteResult> suites, Map<String, Double> floors)
            throws IOException {
        StringBuilder json = new StringBuilder();
        json.append("{\n  \"suites\": [\n");
        double recallSum = 0.0;
        int quarantineTotal = 0;
        boolean gate = true;
        for (int i = 0; i < suites.size(); i++) {
            SuiteResult row = suites.get(i);
            recallSum += row.pairRecall;
            quarantineTotal += row.rowsQuarantined;
            String floorKey = FLOOR_KEYS.get(row.name);
            double floor = floorKey == null ? 1.0 : floors.getOrDefault(floorKey, 1.0);
            if (row.pairRecall + 1e-9 < floor) {
                gate = false;
            }
            json.append("    {\n");
            json.append("      \"name\": \"").append(row.name).append("\",\n");
            json.append("      \"rows_in\": ").append(row.rowsIn).append(",\n");
            json.append("      \"rows_quarantined\": ").append(row.rowsQuarantined).append(",\n");
            json.append("      \"clusters\": ").append(row.clusters).append(",\n");
            json.append("      \"pairs_expected\": ").append(row.pairsExpected).append(",\n");
            json.append("      \"pairs_found\": ").append(row.pairsFound).append(",\n");
            json.append(
                    String.format(
                            Locale.ROOT,
                            "      \"pair_recall\": %.4f,\n",
                            row.pairRecall));
            json.append("      \"components\": ");
            json.append(componentJson(row.components));
            json.append("\n    }");
            if (i + 1 < suites.size()) {
                json.append(",");
            }
            json.append("\n");
        }
        double composite = suites.isEmpty() ? 0.0 : recallSum / suites.size();
        composite = Math.round(composite * 10000.0) / 10000.0;
        double compositeFloor = floors.getOrDefault("composite_recall_min", 1.0);
        if (composite + 1e-9 < compositeFloor) {
            gate = false;
        }
        json.append("  ],\n  \"summary\": {\n");
        json.append(String.format(Locale.ROOT, "    \"composite_recall\": %.4f,\n", composite));
        json.append("    \"total_quarantined\": ").append(quarantineTotal).append(",\n");
        json.append("    \"passes_gate\": ").append(gate).append("\n");
        json.append("  }\n}\n");
        Files.writeString(output, json.toString(), StandardCharsets.UTF_8);
    }
}
