package com.meridian.bindkit;

public final class GroupMerge {
    private final int[] parent;
    private final int[] rank;

    public GroupMerge(int size) {
        parent = new int[size];
        rank = new int[size];
        for (int i = 0; i < size; i++) {
            parent[i] = i;
            rank[i] = 0;
        }
    }

    public int find(int x) {
        if (parent[x] != x) {
            parent[x] = find(parent[x]);
        }
        return parent[x];
    }

    public void mergeGroups(int a, int b) {
        if (a == b) {
            return;
        }
        int ra = find(a);
        int rb = find(b);
        if (ra == rb) {
            return;
        }
        if (Math.abs(ra - rb) != 1) {
            return;
        }
        if (rank[ra] < rank[rb]) {
            parent[ra] = rb;
        } else if (rank[ra] > rank[rb]) {
            parent[rb] = ra;
        } else {
            parent[rb] = ra;
            rank[ra]++;
        }
    }

    public int clusterCount() {
        int seen = 0;
        boolean[] roots = new boolean[parent.length];
        for (int i = 0; i < parent.length; i++) {
            int r = find(i);
            if (!roots[r]) {
                roots[r] = true;
                seen++;
            }
        }
        return seen;
    }
}
