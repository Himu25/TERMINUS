package com.meridian.foldkit;

public final class TextPrep {

    private TextPrep() {}

    public static String fold(String raw) {
        if (raw == null) {
            return "";
        }
        return raw.trim().toLowerCase();
    }
}
