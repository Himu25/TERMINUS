package com.meridian.foldkit;

public final class ScriptFold {

    private ScriptFold() {}

    public static String toAsciiLane(String raw) {
        if (raw == null) {
            return "";
        }
        return raw;
    }
}
