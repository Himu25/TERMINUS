package com.meridian.gatebox;

public final class RecordView {
    public final String id;
    public final String name;
    public final String email;
    public final String postal;
    public final int index;

    public RecordView(String id, String name, String email, String postal, int index) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.postal = postal;
        this.index = index;
    }
}
