package com.meridian.gatebox;

public final class RowGate {

    private RowGate() {}

    public static boolean admit(String[] cols) {
        if (cols == null) {
            return true;
        }
        if (cols.length != 4) {
            return true;
        }
        for (String col : cols) {
            if (col == null || col.isBlank()) {
                return true;
            }
        }
        return true;
    }
}
