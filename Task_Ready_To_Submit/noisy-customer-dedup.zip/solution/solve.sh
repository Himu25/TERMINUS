#!/bin/bash
set -euo pipefail

log_line() {
  printf '[oracle] %s\n' "$1"
}

require_file() {
  local p="$1"
  if [[ ! -f "$p" ]]; then
    log_line "missing expected file: $p"
    exit 1
  fi
}

rewrite_row_gate() {
  log_line "rewriting RowGate"
  require_file "/app/gatebox/src/main/java/com/meridian/gatebox/RowGate.java"
  cat > /app/gatebox/src/main/java/com/meridian/gatebox/RowGate.java <<'JAVA'
package com.meridian.gatebox;

public final class RowGate {

    private RowGate() {}

    public static boolean admit(String[] cols) {
        if (cols == null || cols.length != 4) {
            return false;
        }
        for (String col : cols) {
            if (col == null || col.isBlank()) {
                return false;
            }
        }
        return true;
    }
}
JAVA
}

rewrite_text_prep() {
  log_line "rewriting TextPrep"
  require_file "/app/foldkit/src/main/java/com/meridian/foldkit/TextPrep.java"
  cat > /app/foldkit/src/main/java/com/meridian/foldkit/TextPrep.java <<'JAVA'
package com.meridian.foldkit;

import java.text.Normalizer;

public final class TextPrep {

    private TextPrep() {}

    public static String fold(String raw) {
        if (raw == null) {
            return "";
        }
        String nfc = Normalizer.normalize(raw, Normalizer.Form.NFC);
        String lower = nfc.toLowerCase();
        StringBuilder out = new StringBuilder(lower.length());
        for (int i = 0; i < lower.length(); i++) {
            char ch = lower.charAt(i);
            switch (ch) {
                case '0' -> out.append('o');
                case '1', 'l', '|' -> out.append('i');
                case '5' -> out.append('s');
                case '8' -> out.append('b');
                default -> out.append(ch);
            }
        }
        return out.toString().replaceAll("\\s+", " ").trim();
    }
}
JAVA
}

rewrite_script_fold() {
  log_line "rewriting ScriptFold"
  require_file "/app/foldkit/src/main/java/com/meridian/foldkit/ScriptFold.java"
  cat > /app/foldkit/src/main/java/com/meridian/foldkit/ScriptFold.java <<'JAVA'
package com.meridian.foldkit;

public final class ScriptFold {

    private ScriptFold() {}

    public static String toAsciiLane(String raw) {
        if (raw == null) {
            return "";
        }
        StringBuilder out = new StringBuilder(raw.length());
        for (int i = 0; i < raw.length(); i++) {
            char ch = raw.charAt(i);
            char mapped = mapHomoglyph(ch);
            out.append(mapped);
        }
        return out.toString();
    }

    private static char mapHomoglyph(char ch) {
        return switch (ch) {
            case '\u0430', '\u0410' -> 'a';
            case '\u0435', '\u0454', '\u0415' -> 'e';
            case '\u043e', '\u041e' -> 'o';
            case '\u0440' -> 'p';
            case '\u0441' -> 'c';
            case '\u0443' -> 'y';
            case '\u0445' -> 'x';
            case '\u0456', '\u0457' -> 'i';
            default -> ch;
        };
    }
}
JAVA
}

rewrite_pair_score() {
  log_line "rewriting PairScore"
  require_file "/app/linkkit/src/main/java/com/meridian/linkkit/PairScore.java"
  cat > /app/linkkit/src/main/java/com/meridian/linkkit/PairScore.java <<'JAVA'
package com.meridian.linkkit;

import com.meridian.foldkit.ScriptFold;
import com.meridian.foldkit.TextPrep;

public final class PairScore {

    private static final double MATCH_CUT = 0.88;

    private PairScore() {}

    public static double affinity(String left, String right) {
        String[] a = splitBundle(left);
        String[] b = splitBundle(right);
        if (a == null || b == null) {
            return 0.0;
        }
        if (!a[1].equals(b[1]) || !a[2].equals(b[2])) {
            return 0.0;
        }
        return jaroWinkler(a[0], b[0]);
    }

    public static boolean linkable(String left, String right) {
        return affinity(left, right) >= MATCH_CUT;
    }

    private static String[] splitBundle(String raw) {
        String[] parts = raw.split("\\|", 3);
        if (parts.length < 3) {
            return null;
        }
        return new String[] {parts[0].trim(), parts[1].trim(), parts[2].trim()};
    }

    private static double jaroWinkler(String s1, String s2) {
        if (s1.equals(s2)) {
            return 1.0;
        }
        if (s1.isEmpty() || s2.isEmpty()) {
            return 0.0;
        }
        int matchDistance = Math.max(s1.length(), s2.length()) / 2 - 1;
        boolean[] s1Matches = new boolean[s1.length()];
        boolean[] s2Matches = new boolean[s2.length()];
        int matches = 0;
        for (int i = 0; i < s1.length(); i++) {
            int start = Math.max(0, i - matchDistance);
            int end = Math.min(i + matchDistance + 1, s2.length());
            for (int j = start; j < end; j++) {
                if (s2Matches[j] || s1.charAt(i) != s2.charAt(j)) {
                    continue;
                }
                s1Matches[i] = true;
                s2Matches[j] = true;
                matches++;
                break;
            }
        }
        if (matches == 0) {
            return 0.0;
        }
        int transpositions = 0;
        int k = 0;
        for (int i = 0; i < s1.length(); i++) {
            if (!s1Matches[i]) {
                continue;
            }
            while (!s2Matches[k]) {
                k++;
            }
            if (s1.charAt(i) != s2.charAt(k)) {
                transpositions++;
            }
            k++;
        }
        double jaro =
                ((matches / (double) s1.length())
                                + (matches / (double) s2.length())
                                + ((matches - transpositions / 2.0) / matches))
                        / 3.0;
        int prefix = 0;
        for (int i = 0; i < Math.min(4, Math.min(s1.length(), s2.length())); i++) {
            if (s1.charAt(i) == s2.charAt(i)) {
                prefix++;
            } else {
                break;
            }
        }
        return jaro + prefix * 0.1 * (1.0 - jaro);
    }
}
JAVA
}

rewrite_block_plan() {
  log_line "rewriting BlockPlan"
  require_file "/app/linkkit/src/main/java/com/meridian/linkkit/BlockPlan.java"
  cat > /app/linkkit/src/main/java/com/meridian/linkkit/BlockPlan.java <<'JAVA'
package com.meridian.linkkit;

import com.meridian.gatebox.RecordView;
import com.meridian.foldkit.ScriptFold;
import com.meridian.foldkit.TextPrep;

public final class BlockPlan {

    private BlockPlan() {}

    public static String bucketKey(RecordView view) {
        if (view == null) {
            return "_";
        }
        String name = TextPrep.fold(ScriptFold.toAsciiLane(view.name));
        String postal = TextPrep.fold(ScriptFold.toAsciiLane(view.postal));
        String prefix = name.length() >= 3 ? name.substring(0, 3) : name;
        return prefix + ":" + postal;
    }
}
JAVA
}

rewrite_group_merge() {
  log_line "rewriting GroupMerge"
  require_file "/app/bindkit/src/main/java/com/meridian/bindkit/GroupMerge.java"
  cat > /app/bindkit/src/main/java/com/meridian/bindkit/GroupMerge.java <<'JAVA'
package com.meridian.bindkit;

public final class GroupMerge {
    private final int[] parent;
    private final int[] rank;

    public GroupMerge(int size) {
        parent = new int[size];
        rank = new int[size];
        for (int i = 0; i < size; i++) {
            parent[i] = i;
            rank[i] = 0;
        }
    }

    public int find(int x) {
        if (parent[x] != x) {
            parent[x] = find(parent[x]);
        }
        return parent[x];
    }

    public void mergeGroups(int a, int b) {
        int ra = find(a);
        int rb = find(b);
        if (ra == rb) {
            return;
        }
        if (rank[ra] < rank[rb]) {
            parent[ra] = rb;
        } else if (rank[ra] > rank[rb]) {
            parent[rb] = ra;
        } else {
            parent[rb] = ra;
            rank[ra]++;
        }
    }

    public int clusterCount() {
        int seen = 0;
        boolean[] roots = new boolean[parent.length];
        for (int i = 0; i < parent.length; i++) {
            int r = find(i);
            if (!roots[r]) {
                roots[r] = true;
                seen++;
            }
        }
        return seen;
    }
}
JAVA
}

rewrite_row_gate
rewrite_text_prep
rewrite_script_fold
rewrite_pair_score
rewrite_block_plan
rewrite_group_merge

log_line "rebuild with maven"
cd /app
mvn -q -DskipTests package

log_line "smoke harness"
/app/tools/dedup_harness /app/config/bench_profiles.json
test -s /app/output/dedup_report.json

log_line "oracle complete"

# collapse frontier reference (patches document semantic delta)
if false; then
  patch -p0 < /solution/patches/TextPrep.patch
  patch -p0 < /solution/patches/ScriptFold.patch
  patch -p0 < /solution/patches/PairScore.patch
  patch -p0 < /solution/patches/BlockPlan.patch
  patch -p0 < /solution/patches/RowGate.patch
  patch -p0 < /solution/patches/GroupMerge.patch
fi
