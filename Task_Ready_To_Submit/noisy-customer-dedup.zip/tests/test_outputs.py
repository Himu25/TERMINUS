"""Verifier for noisy-customer-dedup."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUT = APP / "output" / "dedup_report.json"
HARNESS = APP / "tools" / "dedup_harness"
PROFILE = APP / "config" / "bench_profiles.json"
THRESHOLDS = APP / "config" / "thresholds.toml"
REGISTRY_LABELS = APP / "registry" / "pair_labels.json"
STAGING_LABELS = Path("/tmp/meridian_pair_labels.json")
FIXTURES = Path("/tests/fixtures")

ADJUDICATION_PAIRS: dict[str, list[list[str]]] = {
    "clean_anchor": [["c01", "c02"], ["c03", "c04"]],
    "ocr_noise_suite": [["o01", "o02"], ["o03", "o04"]],
    "script_mix_suite": [["s01", "s02"], ["s03", "s04"]],
    "corrupt_mix_suite": [["x01", "x02"]],
    "cross_block": [["k01", "k02"]],
    "transitive_chain": [["t01", "t02"], ["t02", "t03"]],
    "near_miss": [],
    "five_link_chain": [["f01", "f02"], ["f02", "f03"], ["f03", "f04"]],
    "email_local_trap": [],
    "nfc_dup": [["u01", "u02"]],
    "stress_bulk": [
        ["b01a", "b01b"],
        ["b02a", "b02b"],
        ["b03a", "b03b"],
        ["b04a", "b04b"],
        ["b05a", "b05b"],
        ["b06a", "b06b"],
        ["b07a", "b07b"],
        ["b08a", "b08b"],
        ["b09a", "b09b"],
        ["b10a", "b10b"],
        ["b11a", "b11b"],
        ["b12a", "b12b"],
        ["b13a", "b13b"],
        ["b14a", "b14b"],
        ["b15a", "b15b"],
        ["b16a", "b16b"],
        ["b17a", "b17b"],
        ["b18a", "b18b"],
        ["b19a", "b19b"],
        ["b20a", "b20b"],
    ],
}

REPORT_KEYS = frozenset({"suites", "summary"})
SUITE_KEYS = frozenset(
    {
        "name",
        "rows_in",
        "rows_quarantined",
        "clusters",
        "pairs_expected",
        "pairs_found",
        "pair_recall",
        "components",
    }
)
SUMMARY_KEYS = frozenset(
    {
        "composite_recall",
        "total_quarantined",
        "passes_gate",
    }
)


def _parse_thresholds(path: Path) -> dict[str, float]:
    floors: dict[str, float] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.split("#", 1)[0].strip()
        if not stripped or "=" not in stripped:
            continue
        key, raw = stripped.split("=", 1)
        floors[key.strip()] = float(raw.strip())
    return floors


_FLOOR_DATA = _parse_thresholds(THRESHOLDS)
COMPOSITE_FLOOR = _FLOOR_DATA["composite_recall_min"]

SUITE_FLOOR_KEYS = {
    "clean_anchor": "clean_recall_min",
    "ocr_noise_suite": "ocr_recall_min",
    "script_mix_suite": "script_recall_min",
    "corrupt_mix_suite": "corrupt_recall_min",
    "cross_block": "cross_block_recall_min",
    "transitive_chain": "transitive_recall_min",
    "near_miss": "near_miss_recall_min",
    "five_link_chain": "five_link_recall_min",
    "email_local_trap": "email_local_recall_min",
    "nfc_dup": "nfc_recall_min",
    "stress_bulk": "bulk_recall_min",
}


def _profile_suite_paths(profile_path: Path) -> dict[str, Path]:
    profile = json.loads(profile_path.read_text(encoding="utf-8"))
    return {entry["name"]: Path(entry["path"]) for entry in profile["suites"]}


def _profile_suite_order(profile_path: Path) -> list[str]:
    profile = json.loads(profile_path.read_text(encoding="utf-8"))
    return [entry["name"] for entry in profile["suites"]]


def _label_pairs(path: Path) -> dict[str, list[list[str]]]:
    return json.loads(path.read_text(encoding="utf-8"))


def _normalize_components(components: list[list[str]]) -> list[list[str]]:
    return sorted([sorted(group) for group in components])


def _ids_in_components(components: list[list[str]]) -> set[str]:
    seen: set[str] = set()
    for group in components:
        for record_id in group:
            assert record_id not in seen, f"duplicate id {record_id} in components"
            seen.add(record_id)
    return seen


def _pairs_satisfied(components: list[list[str]], pairs: list[list[str]]) -> int:
    parent: dict[str, str] = {}

    def find(node: str) -> str:
        parent.setdefault(node, node)
        while parent[node] != node:
            parent[node] = parent[parent[node]]
            node = parent[node]
        return node

    def merge(left: str, right: str) -> None:
        root_left = find(left)
        root_right = find(right)
        if root_left != root_right:
            parent[root_right] = root_left

    for group in components:
        if not group:
            continue
        anchor = group[0]
        for member in group[1:]:
            merge(anchor, member)

    found = 0
    for left, right in pairs:
        if find(left) == find(right):
            found += 1
    return found


EXPECTED_COMPONENTS: dict[str, list[list[str]]] = {
    "clean_anchor": [["c01", "c02"], ["c03", "c04"], ["c05"], ["c06"]],
    "ocr_noise_suite": [["o01", "o02"], ["o03", "o04"], ["o05"]],
    "script_mix_suite": [["s01", "s02"], ["s03", "s04"], ["s05"]],
    "corrupt_mix_suite": [["x01", "x02"], ["x03"], ["x04"], ["x05"]],
    "cross_block": [["k01", "k02"], ["k03"]],
    "transitive_chain": [["t01", "t02", "t03"], ["t04"]],
    "near_miss": [["n01"], ["n02"], ["n03"], ["n04"], ["n05"], ["n06"], ["n07"]],
    "five_link_chain": [["f01", "f02", "f03", "f04"], ["f05"]],
    "email_local_trap": [["e01"], ["e02"], ["e03"], ["e04"], ["e05"], ["e06"]],
    "nfc_dup": [["u01", "u02"], ["u03"]],
    "stress_bulk": [
        ["b01a", "b01b"],
        ["b02a", "b02b"],
        ["b03a", "b03b"],
        ["b04a", "b04b"],
        ["b05a", "b05b"],
        ["b06a", "b06b"],
        ["b07a", "b07b"],
        ["b08a", "b08b"],
        ["b09a", "b09b"],
        ["b10a", "b10b"],
        ["b11a", "b11b"],
        ["b12a", "b12b"],
        ["b13a", "b13b"],
        ["b14a", "b14b"],
        ["b15a", "b15b"],
        ["b16a", "b16b"],
        ["b17a", "b17b"],
        ["b18a", "b18b"],
        ["b19a", "b19b"],
        ["b20a", "b20b"],
        ["s01"],
        ["s02"],
        ["s03"],
        ["s04"],
        ["s05"],
        ["s06"],
        ["s07"],
        ["s08"],
        ["s09"],
        ["s10"],
    ],
}


def _count_valid_rows(csv_path: Path) -> int:
    rows = 0
    for line in csv_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.lower().startswith("id,name,email,postal"):
            continue
        cols = stripped.split(",", -1)
        if len(cols) != 4:
            continue
        if any(not col.strip() for col in cols):
            continue
        rows += 1
    return rows


def _count_physical_lines(csv_path: Path) -> int:
    count = 0
    for line in csv_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.lower().startswith("id,name,email,postal"):
            continue
        count += 1
    return count


def _expected_quarantine(csv_path: Path) -> int:
    return _count_physical_lines(csv_path) - _count_valid_rows(csv_path)


def _run_harness(profile: Path | None = None) -> None:
    _stage_adjudication_registry()
    cmd = [str(HARNESS)]
    if profile is not None:
        cmd.append(str(profile))
    env = os.environ.copy()
    env["MERIDIAN_LABELS_PATH"] = str(STAGING_LABELS)
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False, env=env)
    assert proc.returncode == 0, proc.stderr or proc.stdout


def _load_report() -> dict:
    assert OUT.is_file(), "dedup_report.json missing"
    return json.loads(OUT.read_text(encoding="utf-8"))


def _suite_map(report: dict) -> dict[str, dict]:
    return {row["name"]: row for row in report["suites"]}


def _round4(value: float) -> float:
    return float(f"{value:.4f}")


_PROFILE_PATHS = _profile_suite_paths(PROFILE)
_PROFILE_ORDER = _profile_suite_order(PROFILE)


def _labels() -> dict[str, list[list[str]]]:
    return ADJUDICATION_PAIRS


def _stage_adjudication_registry() -> None:
    payload = json.dumps(ADJUDICATION_PAIRS, indent=2) + "\n"
    STAGING_LABELS.write_text(payload, encoding="utf-8")
    if REGISTRY_LABELS.parent.exists() or REGISTRY_LABELS.parent == APP / "registry":
        try:
            REGISTRY_LABELS.parent.mkdir(parents=True, exist_ok=True)
            REGISTRY_LABELS.write_text(payload, encoding="utf-8")
        except OSError:
            pass


@pytest.fixture(scope="session", autouse=True)
def adjudication_registry() -> None:
    """Inject adjudication pairs for harness scoring; not present in the agent image."""
    _stage_adjudication_registry()


@pytest.fixture(scope="module")
def default_report(adjudication_registry: None) -> dict:
    """Full default bench profile run."""
    _run_harness(PROFILE)
    return _load_report()


def _assert_suite_shape(
    report: dict,
    name: str,
    *,
    min_quarantine: int = 0,
    exact_quarantine: int | None = None,
    require_zero_pairs: bool = False,
) -> dict:
    row = _suite_map(report)[name]
    expected_rows = _count_valid_rows(_PROFILE_PATHS[name])
    expected_pairs = len(_labels()[name])
    expected_clusters = expected_rows - expected_pairs
    assert row["rows_in"] == expected_rows
    if exact_quarantine is not None:
        assert row["rows_quarantined"] == exact_quarantine
    else:
        assert row["rows_quarantined"] >= min_quarantine
    assert row["clusters"] == expected_clusters
    label_pairs = _labels().get(name, [])
    satisfied = _pairs_satisfied(row["components"], label_pairs)
    assert satisfied == expected_pairs
    if require_zero_pairs:
        assert expected_pairs == 0
        assert satisfied == 0
    floor = _FLOOR_DATA[SUITE_FLOOR_KEYS[name]]
    recall_from_components = (
        1.0 if expected_pairs == 0 else _round4(satisfied / expected_pairs)
    )
    assert recall_from_components >= floor
    assert row["pair_recall"] == recall_from_components
    _assert_components(row, name)
    return row


def _assert_components(row: dict, name: str) -> None:
    components = row["components"]
    assert isinstance(components, list)
    assert len(components) == row["clusters"]
    admitted = _ids_in_components(components)
    assert len(admitted) == row["rows_in"]
    if name in EXPECTED_COMPONENTS:
        assert _normalize_components(components) == _normalize_components(
            EXPECTED_COMPONENTS[name]
        )
    label_pairs = _labels().get(name, [])
    assert _pairs_satisfied(components, label_pairs) == len(label_pairs)


def test_clean_anchor_recall(default_report: dict) -> None:
    """Clean anchor suite ingests every valid row and recovers labeled pairs."""
    _assert_suite_shape(default_report, "clean_anchor")


def test_ocr_noise_pair_recall(default_report: dict) -> None:
    """OCR-noise suite merges every registry-labeled pair."""
    _assert_suite_shape(default_report, "ocr_noise_suite")


def test_script_mix_pair_recall(default_report: dict) -> None:
    """Mixed-script suite recovers registry-labeled pairs."""
    _assert_suite_shape(default_report, "script_mix_suite")


def test_corrupt_rows_quarantined(default_report: dict) -> None:
    """Corrupt ingest lines are quarantined with exact counts from the feed."""
    csv_path = _PROFILE_PATHS["corrupt_mix_suite"]
    expected_q = _expected_quarantine(csv_path)
    assert expected_q >= 2
    _assert_suite_shape(
        default_report,
        "corrupt_mix_suite",
        exact_quarantine=expected_q,
    )


def test_cross_block_pair_across_postal(default_report: dict) -> None:
    """OCR twins in the same compare bucket merge when blocking uses field lanes not ids."""
    _assert_suite_shape(default_report, "cross_block")


def test_transitive_chain_single_component(default_report: dict) -> None:
    """Three-record chain collapses to one component via transitive consolidation."""
    _assert_suite_shape(default_report, "transitive_chain")


def test_near_miss_no_false_positive_merges(default_report: dict) -> None:
    """Lookalike names with distinct or shared email lanes stay in separate groups."""
    _assert_suite_shape(default_report, "near_miss", require_zero_pairs=True)
    row = _suite_map(default_report)["near_miss"]
    assert row["rows_in"] == row["clusters"]


def test_five_link_chain_transitive(default_report: dict) -> None:
    """Four-hop labeled chain collapses to one component plus an isolated row."""
    _assert_suite_shape(default_report, "five_link_chain")


def test_email_local_trap_no_false_merge(default_report: dict) -> None:
    """OCR-skewed names with distinct or shared email lanes never merge."""
    _assert_suite_shape(default_report, "email_local_trap", require_zero_pairs=True)


def test_nfc_dup_pair_recall(default_report: dict) -> None:
    """Composed and decomposed unicode spellings merge when the email lane matches."""
    _assert_suite_shape(default_report, "nfc_dup")


def test_stress_bulk_recall(default_report: dict) -> None:
    """Bulk suite recovers every registry pair without quarantines."""
    _assert_suite_shape(default_report, "stress_bulk")


def test_profile_order_matches_config(default_report: dict) -> None:
    """Suite rows appear in the same order as the active bench profile."""
    names = [row["name"] for row in default_report["suites"]]
    assert names == _PROFILE_ORDER


def test_composite_recall_matches_suite_mean(default_report: dict) -> None:
    """Summary composite recall equals the unweighted mean of suite recalls."""
    recalls = [row["pair_recall"] for row in default_report["suites"]]
    expected = _round4(sum(recalls) / len(recalls))
    assert default_report["summary"]["composite_recall"] == expected


def test_total_quarantined_sums_suites(default_report: dict) -> None:
    """Summary quarantine total matches the sum of per-suite quarantine counts."""
    total = sum(row["rows_quarantined"] for row in default_report["suites"])
    assert default_report["summary"]["total_quarantined"] == total


def test_passes_gate_iff_all_floors_hold(default_report: dict) -> None:
    """passes_gate is true exactly when every suite recall clears its floor."""
    summary = default_report["summary"]
    all_clear = all(
        row["pair_recall"] >= _FLOOR_DATA[SUITE_FLOOR_KEYS[row["name"]]]
        for row in default_report["suites"]
    )
    assert summary["passes_gate"] is all_clear
    assert summary["passes_gate"] is True
    assert summary["composite_recall"] >= COMPOSITE_FLOOR


def test_passes_gate_and_determinism(default_report: dict) -> None:
    """Back-to-back default-profile runs are byte-identical."""
    first = OUT.read_bytes()
    _run_harness(PROFILE)
    second = OUT.read_bytes()
    assert first == second


def test_default_harness_uses_bench_profile() -> None:
    """Harness with no profile argument reads the default bench profile."""
    _run_harness()
    report = _load_report()
    names = [row["name"] for row in report["suites"]]
    assert names == _PROFILE_ORDER


def test_rows_pairs_cluster_invariant(default_report: dict) -> None:
    """Every suite satisfies clusters = rows_in - adjudicated merges recovered."""
    for row in default_report["suites"]:
        label_pairs = _labels().get(row["name"], [])
        merges = _pairs_satisfied(row["components"], label_pairs)
        expected_clusters = row["rows_in"] - merges
        assert row["clusters"] == expected_clusters, row["name"]


def test_pairs_found_never_exceeds_expected(default_report: dict) -> None:
    """Recovered labeled pairs never outnumber registry expectations."""
    for row in default_report["suites"]:
        pairs = _labels().get(row["name"], [])
        assert _pairs_satisfied(row["components"], pairs) <= len(pairs)


def test_pairs_found_matches_component_membership(default_report: dict) -> None:
    """Adjudicated pairs satisfied in components match the verifier registry."""
    for row in default_report["suites"]:
        pairs = _labels().get(row["name"], [])
        assert _pairs_satisfied(row["components"], pairs) == len(pairs)


def test_components_partition_admitted_ids(default_report: dict) -> None:
    """Every admitted id appears in exactly one component list."""
    for row in default_report["suites"]:
        _assert_components(row, row["name"])


def test_transitive_chain_component_shape(default_report: dict) -> None:
    """Transitive chain collapses to one multi-id component plus an isolated row."""
    components = _suite_map(default_report)["transitive_chain"]["components"]
    assert _normalize_components(components) == [["t01", "t02", "t03"], ["t04"]]


def test_near_miss_singleton_components(default_report: dict) -> None:
    """Near-miss suite keeps every admitted id in its own component."""
    components = _suite_map(default_report)["near_miss"]["components"]
    assert _normalize_components(components) == EXPECTED_COMPONENTS["near_miss"]


def test_recall_rounded_four_decimals_all_suites(default_report: dict) -> None:
    """Every suite recall is a JSON number rendered to exactly four fractional digits."""
    for row in default_report["suites"]:
        assert row["pair_recall"] == _round4(float(row["pair_recall"]))


def test_isolated_ocr_profile_recall() -> None:
    """OCR-only profile still passes when the full matrix is not re-run."""
    profile = FIXTURES / "profile_ocr_only.json"
    _run_harness(profile)
    report = _load_report()
    row = _suite_map(report)["ocr_noise_suite"]
    assert _pairs_satisfied(row["components"], _labels()["ocr_noise_suite"]) == 2
    assert row["pair_recall"] == 1.0
    assert _normalize_components(row["components"]) == EXPECTED_COMPONENTS["ocr_noise_suite"]


def test_isolated_cross_block_profile() -> None:
    """Cross-block profile fails if blocking still keys compare buckets on record id alone."""
    profile = FIXTURES / "profile_cross_block.json"
    _run_harness(profile)
    report = _load_report()
    row = _suite_map(report)["cross_block"]
    assert _pairs_satisfied(row["components"], _labels()["cross_block"]) == 1
    assert _normalize_components(row["components"]) == EXPECTED_COMPONENTS["cross_block"]


def test_isolated_transitive_profile() -> None:
    """Transitive profile requires chained merges, not adjacent-only union."""
    profile = FIXTURES / "profile_transitive.json"
    _run_harness(profile)
    report = _load_report()
    row = _suite_map(report)["transitive_chain"]
    assert _pairs_satisfied(row["components"], _labels()["transitive_chain"]) == 2
    assert _normalize_components(row["components"]) == EXPECTED_COMPONENTS["transitive_chain"]


def test_isolated_near_miss_profile() -> None:
    """Near-miss profile keeps every row as its own cluster."""
    profile = FIXTURES / "profile_near_miss.json"
    _run_harness(profile)
    report = _load_report()
    row = _suite_map(report)["near_miss"]
    assert _pairs_satisfied(row["components"], _labels()["near_miss"]) == 0
    assert row["rows_in"] == row["clusters"] == 7
    assert _normalize_components(row["components"]) == EXPECTED_COMPONENTS["near_miss"]


def test_isolated_five_link_profile() -> None:
    """Five-link profile fails when transitive union only merges adjacent indices."""
    profile = FIXTURES / "profile_five_link.json"
    _run_harness(profile)
    report = _load_report()
    row = _suite_map(report)["five_link_chain"]
    assert _pairs_satisfied(row["components"], _labels()["five_link_chain"]) == 3
    assert _normalize_components(row["components"]) == EXPECTED_COMPONENTS["five_link_chain"]


def test_isolated_email_local_trap_profile() -> None:
    """Email-local trap profile fails if name similarity overrides email lanes."""
    profile = FIXTURES / "profile_email_local_trap.json"
    _run_harness(profile)
    report = _load_report()
    row = _suite_map(report)["email_local_trap"]
    assert _pairs_satisfied(row["components"], _labels()["email_local_trap"]) == 0
    assert row["rows_in"] == row["clusters"] == 6
    assert _normalize_components(row["components"]) == EXPECTED_COMPONENTS["email_local_trap"]


def test_isolated_nfc_dup_profile() -> None:
    """NFC profile fails when unicode normalization is skipped before scoring."""
    profile = FIXTURES / "profile_nfc_dup.json"
    _run_harness(profile)
    report = _load_report()
    row = _suite_map(report)["nfc_dup"]
    assert _pairs_satisfied(row["components"], _labels()["nfc_dup"]) == 1
    assert row["pair_recall"] == 1.0
    assert _normalize_components(row["components"]) == EXPECTED_COMPONENTS["nfc_dup"]


def test_isolated_script_mix_profile() -> None:
    """Script-mix profile fails when homoglyph folding is absent."""
    profile = FIXTURES / "profile_script_mix.json"
    _run_harness(profile)
    report = _load_report()
    row = _suite_map(report)["script_mix_suite"]
    assert _pairs_satisfied(row["components"], _labels()["script_mix_suite"]) == 2
    assert row["pair_recall"] == 1.0
    assert _normalize_components(row["components"]) == EXPECTED_COMPONENTS["script_mix_suite"]


def test_isolated_corrupt_mix_profile() -> None:
    """Corrupt profile quarantines every malformed physical line."""
    profile = FIXTURES / "profile_corrupt_mix.json"
    _run_harness(profile)
    report = _load_report()
    row = _suite_map(report)["corrupt_mix_suite"]
    csv_path = _PROFILE_PATHS["corrupt_mix_suite"]
    assert row["rows_quarantined"] == _expected_quarantine(csv_path)
    assert row["rows_in"] == _count_valid_rows(csv_path)


def test_report_schema(default_report: dict) -> None:
    """Report JSON exposes the documented suite and summary fields."""
    report = default_report
    assert set(report.keys()) == REPORT_KEYS
    summary = report["summary"]
    assert set(summary.keys()) == SUMMARY_KEYS
    assert isinstance(summary["composite_recall"], (int, float))
    assert isinstance(summary["total_quarantined"], int)
    assert isinstance(summary["passes_gate"], bool)
    for row in report["suites"]:
        assert set(row.keys()) == SUITE_KEYS
        assert isinstance(row["pair_recall"], (int, float))
        recall_text = f"{row['pair_recall']:.4f}"
        assert len(recall_text.split(".")[1]) == 4
        assert isinstance(row["components"], list)
        for group in row["components"]:
            assert isinstance(group, list)
            for record_id in group:
                assert isinstance(record_id, str)
        for key in ("rows_in", "rows_quarantined", "clusters", "pairs_expected", "pairs_found"):
            assert isinstance(row[key], int)
            assert row[key] >= 0
