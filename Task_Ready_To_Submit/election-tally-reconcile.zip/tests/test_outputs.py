"""Verifier for ballot report emission."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

APP = Path("/app")
REPORT = APP / "output" / "ballot_report.json"


def _stem_tag(stem: str) -> str:
    bundle = json.loads((APP / "cases" / f"{stem}.json").read_text(encoding="utf-8"))
    return str(bundle["scenario_label"])


def _drive(stem: str) -> dict:
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    if REPORT.exists():
        REPORT.unlink()
    subprocess.run(
        ["/app/bin/ecount"],
        cwd=str(APP),
        env={**os.environ, "tb_slice": stem},
        check=True,
    )
    payload = json.loads(REPORT.read_text(encoding="utf-8"))
    assert "precinct_runs" in payload and len(payload["precinct_runs"]) == 1
    row = payload["precinct_runs"][0]
    assert row.get("scenario_tag") == _stem_tag(stem)
    return row


def _assert_row(
    row: dict,
    *,
    booked_minor: int,
    mirror_minor: int,
    gap_minor: int,
    replay_noise: int,
    orphan_lines: int,
) -> None:
    assert row["booked_minor"] == booked_minor
    assert row["mirror_minor"] == mirror_minor
    assert row["gap_minor"] == gap_minor
    assert row["replay_noise"] == replay_noise
    assert row["orphan_lines"] == orphan_lines


def test_ward_alpha_dup_across_precincts() -> None:
    """Shared batch fingerprint across precincts must not collapse distinct certified lines."""
    row = _drive("ward_alpha")
    _assert_row(row, booked_minor=161, mirror_minor=161, gap_minor=0, replay_noise=1, orphan_lines=0)


def test_ward_beta_unrelated_precincts_after_lock() -> None:
    """A lock row for one precinct must not freeze unrelated precincts still expecting provisional lines."""
    row = _drive("ward_beta")
    _assert_row(row, booked_minor=70, mirror_minor=70, gap_minor=0, replay_noise=0, orphan_lines=0)


def test_ward_gamma_shadow_lane_excluded() -> None:
    """Certified totals must ignore held lane marks outside the certified contract."""
    row = _drive("ward_gamma")
    _assert_row(row, booked_minor=10, mirror_minor=10, gap_minor=0, replay_noise=0, orphan_lines=0)


def test_ward_delta_replay_and_halt() -> None:
    """Duplicate upload replay plus per-precinct provisional freeze after a lock row."""
    row = _drive("ward_delta")
    _assert_row(row, booked_minor=35, mirror_minor=35, gap_minor=0, replay_noise=1, orphan_lines=0)


def test_ward_peak_composite() -> None:
    """Composite ward mixes duplicate suppression, lock scope, and late provisional lines."""
    row = _drive("ward_peak")
    _assert_row(row, booked_minor=16, mirror_minor=16, gap_minor=0, replay_noise=1, orphan_lines=0)


def test_ward_ozone_anchor_overrides_mirror_sum() -> None:
    """Provisional anchor hints interact with certified-only booking sums."""
    row = _drive("ward_ozone")
    _assert_row(row, booked_minor=100, mirror_minor=90, gap_minor=10, replay_noise=0, orphan_lines=0)


def test_ward_canyon_cross_precinct_batch_collision() -> None:
    """Shared batch ink on distinct precincts must survive narrowing with trailing replays."""
    row = _drive("ward_canyon")
    _assert_row(row, booked_minor=100, mirror_minor=75, gap_minor=25, replay_noise=2, orphan_lines=0)


def test_ward_echo_lock_orphan_internals() -> None:
    """Per-precinct halt drops late provisional mirrors while posted-lane internals stay booked."""
    row = _drive("ward_echo")
    _assert_row(row, booked_minor=55, mirror_minor=30, gap_minor=25, replay_noise=0, orphan_lines=2)


def test_ward_frost_negative_anchor_clamp() -> None:
    """Held lane bulk and a negative provisional anchor must not inflate certified booked totals."""
    row = _drive("ward_frost")
    _assert_row(row, booked_minor=30, mirror_minor=0, gap_minor=30, replay_noise=0, orphan_lines=0)


def test_ward_haze_dual_lock_late_mirrors() -> None:
    """Independent lock rows on two precincts must not freeze a third precinct still pairing."""
    row = _drive("ward_haze")
    _assert_row(row, booked_minor=119, mirror_minor=119, gap_minor=0, replay_noise=0, orphan_lines=0)


def test_ward_iron_replay_lock_shadow_orphan() -> None:
    """Replay collapse, per-precinct halt, held lane exclusion, and orphan tally interact."""
    row = _drive("ward_iron")
    _assert_row(row, booked_minor=27, mirror_minor=20, gap_minor=7, replay_noise=1, orphan_lines=1)


def test_ward_jade_triple_replay_same_precinct() -> None:
    """Three identical uploads on one precinct must count as two replay_noise events."""
    row = _drive("ward_jade")
    _assert_row(row, booked_minor=7, mirror_minor=7, gap_minor=0, replay_noise=2, orphan_lines=0)


def test_ward_kite_lock_unrelated_precinct_mirror() -> None:
    """Halting one precinct must not block provisional or certified lines on a different precinct."""
    row = _drive("ward_kite")
    _assert_row(row, booked_minor=125, mirror_minor=125, gap_minor=0, replay_noise=0, orphan_lines=0)


def test_ward_loom_interleaved_dup_lock() -> None:
    """Interleaved precincts with shared batch ink and a mid-feed lock preserve unrelated pairing."""
    row = _drive("ward_loom")
    _assert_row(row, booked_minor=18, mirror_minor=18, gap_minor=0, replay_noise=1, orphan_lines=0)


def test_ward_mist_anchor_shadow_replay() -> None:
    """Anchor override, held internals, and duplicate replay must not double-count certified booked."""
    row = _drive("ward_mist")
    _assert_row(row, booked_minor=100, mirror_minor=75, gap_minor=25, replay_noise=1, orphan_lines=0)


def test_ward_nova_full_stack_stress() -> None:
    """Cross-precinct dedupe, lock scope, held-lane exclusion, and provisional sum divergence together."""
    row = _drive("ward_nova")
    _assert_row(row, booked_minor=48, mirror_minor=70, gap_minor=-22, replay_noise=1, orphan_lines=0)
