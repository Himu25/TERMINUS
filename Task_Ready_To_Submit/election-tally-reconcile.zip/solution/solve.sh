#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TASK_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

if [ -f "/app/go.mod" ] && [ -d "/app/dup_narrow" ]; then
  env_dir="/app"
elif [ -d "$TASK_DIR/environment" ]; then
  env_dir="$TASK_DIR/environment"
elif [ -d "/environment" ] && [ -f "/environment/go.mod" ]; then
  env_dir="/environment"
else
  echo "Could not locate task environment layout." >&2
  exit 1
fi

cd "$SCRIPT_DIR"
patch -p1 --forward -d "$env_dir" <fixes.patch

bash "$env_dir/scripts/build.sh"

echo "Oracle applied batch fingerprint, lock-row scope, and certified-lane booking fixes."
