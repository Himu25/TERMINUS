#!/bin/sh
set -u
bash /app/scripts/build.sh
cd /app && go test ./...
