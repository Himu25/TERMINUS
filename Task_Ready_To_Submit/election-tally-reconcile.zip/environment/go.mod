module tallybench

go 1.22
