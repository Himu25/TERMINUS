// Package dup_narrow narrows inbound tape rows before pairing.
package dup_narrow
