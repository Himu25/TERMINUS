package dup_narrow

import (
	"tallybench/ledgerwire"
)

func tagFrom(r ledgerwire.TapeRow) string {
	return r.Ink
}

// ClipSpan removes replayed duplicates while preserving first-seen order.
func ClipSpan(rows []ledgerwire.TapeRow) ([]ledgerwire.TapeRow, int) {
	seen := map[string]bool{}
	out := make([]ledgerwire.TapeRow, 0, len(rows))
	noise := 0
	for idx := range rows {
		r := rows[idx]
		key := tagFrom(r)
		if seen[key] {
			noise++
			continue
		}
		seen[key] = true
		out = append(out, r)
	}
	return out, noise
}
