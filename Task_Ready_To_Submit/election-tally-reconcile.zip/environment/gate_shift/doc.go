// Package gate_shift walks narrowed rows with sentinel awareness.
package gate_shift
