package gate_shift

import "tallybench/ledgerwire"

// ShiftSpan applies vendor ordering rules after narrowing.
func ShiftSpan(rows []ledgerwire.TapeRow, _ string) []ledgerwire.TapeRow {
	out := make([]ledgerwire.TapeRow, 0, len(rows))
	stopped := false
	for idx := range rows {
		r := rows[idx]
		if r.Sentinel {
			stopped = true
			out = append(out, r)
			continue
		}
		if stopped {
			continue
		}
		out = append(out, r)
	}
	return out
}
