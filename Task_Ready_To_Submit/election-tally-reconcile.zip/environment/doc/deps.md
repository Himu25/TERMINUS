Vendor `face` values are INTERNAL or MIRROR.
