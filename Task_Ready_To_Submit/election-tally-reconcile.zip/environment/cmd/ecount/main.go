package main

import (
	"os"

	"tallybench/internal/runner"
)

func main() {
	os.Exit(runner.MainExit())
}
