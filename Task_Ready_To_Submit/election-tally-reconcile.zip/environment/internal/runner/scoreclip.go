package runner

import (
	"tallybench/ledgerwire"
	"tallybench/sum_seal"
)

func runSeal(rows []ledgerwire.TapeRow, posted string, anchor *int) sum_seal.Tally {
	return sum_seal.MeterSpan(rows, posted, anchor)
}
