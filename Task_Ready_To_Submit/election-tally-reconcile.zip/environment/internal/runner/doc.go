// Package runner wires tape stages into the published report.
package runner
