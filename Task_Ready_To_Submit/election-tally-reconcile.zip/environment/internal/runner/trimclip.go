package runner

import (
	"tallybench/dup_narrow"
	"tallybench/ledgerwire"
)

func runClip(rows []ledgerwire.TapeRow) ([]ledgerwire.TapeRow, int) {
	return dup_narrow.ClipSpan(rows)
}
