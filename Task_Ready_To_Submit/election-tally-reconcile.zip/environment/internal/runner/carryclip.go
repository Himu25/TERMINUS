package runner

import (
	"tallybench/gate_shift"
	"tallybench/ledgerwire"
)

func runShift(rows []ledgerwire.TapeRow, pair string) []ledgerwire.TapeRow {
	return gate_shift.ShiftSpan(rows, pair)
}
