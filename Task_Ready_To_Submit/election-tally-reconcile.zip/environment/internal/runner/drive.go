package runner

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"

	"tallybench/ledgerwire"
)

// PrecinctRun is the JSON shape for one scenario emission.
type PrecinctRun struct {
	ScenarioTag string `json:"scenario_tag"`
	BookedMinor int    `json:"booked_minor"`
	MirrorMinor int    `json:"mirror_minor"`
	GapMinor    int    `json:"gap_minor"`
	ReplayNoise int    `json:"replay_noise"`
	OrphanLines int    `json:"orphan_lines"`
}

type precinctPayload struct {
	PrecinctRuns []PrecinctRun `json:"precinct_runs"`
}

// Run loads one bundle using tb_slice, writes /app/output/ballot_report.json.
func Run() error {
	stem := os.Getenv("tb_slice")
	if stem == "" {
		return errors.New("tb_slice must name a stem under /app/cases")
	}
	emit := "/app/output/ballot_report.json"
	raw, err := os.ReadFile(filepath.Join("/app", "cases", stem+".json"))
	if err != nil {
		return err
	}
	var bundle ledgerwire.Bundle
	if err := json.Unmarshal(raw, &bundle); err != nil {
		return err
	}
	trimmed, noise := runClip(bundle.Tape)
	carried := runShift(trimmed, bundle.PairSentinelWire)
	view := runSeal(carried, bundle.PostedLaneToken, bundle.MirrorAnchorHint)
	run := PrecinctRun{
		ScenarioTag: bundle.ScenarioLabel,
		BookedMinor: view.BookedMinor,
		MirrorMinor: view.MirrorMinor,
		GapMinor:    view.GapMinor,
		ReplayNoise: noise,
		OrphanLines: view.OrphanLines,
	}
	out := precinctPayload{PrecinctRuns: []PrecinctRun{run}}
	if err := os.MkdirAll(filepath.Dir(emit), 0o755); err != nil {
		return err
	}
	buf, err := json.MarshalIndent(out, "", "  ")
	if err != nil {
		return err
	}
	tmp := emit + ".tmp"
	if err := os.WriteFile(tmp, buf, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, emit)
}

// MainExit is a thin wrapper for cmd.
func MainExit() int {
	if err := Run(); err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		return 1
	}
	return 0
}
