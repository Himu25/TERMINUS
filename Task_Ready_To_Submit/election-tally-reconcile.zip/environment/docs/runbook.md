Local smoke: `go build -o /tmp/ecount ./cmd/ecount && tb_slice=ward_alpha /tmp/ecount`
