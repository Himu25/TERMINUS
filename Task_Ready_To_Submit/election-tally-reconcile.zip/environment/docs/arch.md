# Architecture sketch

- `cmd/ecount` CLI entry (reads `tb_slice` for the cases stem)
- `dup_narrow` replay collapse
- `gate_shift` lock-row walk
- `sum_seal` certified/provisional fold via cgo
- `internal/runner` wires stages without centralizing every fix symbol
