# tallybench

Mixed-language precinct feed reconciler used in integration drills. Go stages narrow duplicates and apply lock-row scope; Rust folds certified and provisional totals for the ballot report.
