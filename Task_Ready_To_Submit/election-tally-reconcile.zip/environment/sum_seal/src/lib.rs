use std::ffi::CStr;
use std::os::raw::{c_char, c_int};

#[repr(C)]
pub struct SfRow {
    pub wire: *const c_char,
    pub ink: *const c_char,
    pub grain: c_int,
    pub face: *const c_char,
    pub band: *const c_char,
    pub sentinel: bool,
}

#[repr(C)]
pub struct SfRoll {
    pub booked_minor: c_int,
    pub mirror_minor: c_int,
    pub gap_minor: c_int,
    pub orphan_lines: c_int,
}

struct RowView<'a> {
    wire: &'a str,
    face: &'a str,
    band: &'a str,
    grain: i32,
    sentinel: bool,
}

fn row_at(raw: &SfRow) -> Option<RowView<'_>> {
    unsafe {
        Some(RowView {
            wire: CStr::from_ptr(raw.wire).to_str().ok()?,
            face: CStr::from_ptr(raw.face).to_str().ok()?,
            band: CStr::from_ptr(raw.band).to_str().ok()?,
            grain: raw.grain,
            sentinel: raw.sentinel,
        })
    }
}

fn accrete_p(rows: &[RowView]) -> i32 {
    rows.iter()
        .filter(|r| r.face == "INTERNAL" && !r.sentinel)
        .map(|r| r.grain)
        .sum()
}

fn side_q(rows: &[RowView], anchor: Option<i32>) -> i32 {
    let mut mirror = rows
        .iter()
        .filter(|r| r.face == "MIRROR")
        .map(|r| r.grain)
        .sum::<i32>();
    if let Some(hint) = anchor {
        mirror = hint;
    }
    mirror
}

fn lone_r(rows: &[RowView], posted: &str) -> i32 {
    let mut orphan = 0;
    for r in rows {
        if r.face != "INTERNAL" || r.sentinel || r.band != posted {
            continue;
        }
        let paired = rows.iter().any(|m| m.face == "MIRROR" && m.wire == r.wire);
        if !paired {
            orphan += 1;
        }
    }
    orphan
}

#[no_mangle]
pub extern "C" fn sf_meter_span(
    rows: *const SfRow,
    count: usize,
    posted: *const c_char,
    anchor: *const c_int,
) -> SfRoll {
    let posted = unsafe {
        CStr::from_ptr(posted)
            .to_str()
            .unwrap_or("")
            .to_string()
    };
    let anchor_val = if anchor.is_null() {
        None
    } else {
        Some(unsafe { *anchor })
    };

    let mut parsed = Vec::with_capacity(count);
    if !rows.is_null() {
        let slice = unsafe { std::slice::from_raw_parts(rows, count) };
        for raw in slice {
            if let Some(v) = row_at(raw) {
                parsed.push(v);
            }
        }
    }

    let booked = accrete_p(&parsed);
    let mirror = side_q(&parsed, anchor_val);
    let orphan = lone_r(&parsed, &posted);
    SfRoll {
        booked_minor: booked,
        mirror_minor: mirror,
        gap_minor: booked - mirror,
        orphan_lines: orphan,
    }
}
