// Package sum_seal binds numeric views through a Rust fold library.
package sum_seal
