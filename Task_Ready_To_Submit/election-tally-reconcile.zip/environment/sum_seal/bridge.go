package sum_seal

/*
#cgo LDFLAGS: ${SRCDIR}/target/release/libseal_fold.a -ldl -lm
#include "seal_fold.h"
#include <stdlib.h>
*/
import "C"

import (
	"unsafe"

	"tallybench/ledgerwire"
)

// Tally is one ballot row for JSON emission.
type Tally struct {
	BookedMinor int
	MirrorMinor int
	GapMinor    int
	OrphanLines int
}

// MeterSpan folds mirror and posted booking views after carry.
func MeterSpan(rows []ledgerwire.TapeRow, posted string, anchor *int) Tally {
	if len(rows) == 0 {
		return tallyFrom(C.sf_meter_span(nil, 0, cStr(posted), cAnchor(anchor)))
	}
	cRows := make([]C.sf_row, len(rows))
	keepers := make([]*C.char, 0, len(rows)*4+1)
	defer freeAll(keepers)

	for idx := range rows {
		r := rows[idx]
		w := C.CString(r.Wire)
		i := C.CString(r.Ink)
		f := C.CString(r.Face)
		b := C.CString(r.Band)
		keepers = append(keepers, w, i, f, b)
		cRows[idx] = C.sf_row{
			wire:     w,
			ink:      i,
			grain:    C.int(r.Grain),
			face:     f,
			band:     b,
			sentinel: C.bool(r.Sentinel),
		}
	}
	p := cStr(posted)
	keepers = append(keepers, p)
	ct := C.sf_meter_span(
		(*C.sf_row)(unsafe.Pointer(&cRows[0])),
		C.size_t(len(cRows)),
		p,
		cAnchor(anchor),
	)
	return tallyFrom(ct)
}

func cStr(s string) *C.char {
	return C.CString(s)
}

func cAnchor(anchor *int) *C.int {
	if anchor == nil {
		return nil
	}
	v := C.int(*anchor)
	return &v
}

func freeAll(ptrs []*C.char) {
	for _, p := range ptrs {
		C.free(unsafe.Pointer(p))
	}
}

func tallyFrom(ct C.sf_tally) Tally {
	return Tally{
		BookedMinor: int(ct.booked_minor),
		MirrorMinor: int(ct.mirror_minor),
		GapMinor:    int(ct.gap_minor),
		OrphanLines: int(ct.orphan_lines),
	}
}
