#ifndef SEAL_FOLD_H
#define SEAL_FOLD_H

#include <stdbool.h>
#include <stddef.h>

typedef struct {
    const char *wire;
    const char *ink;
    int grain;
    const char *face;
    const char *band;
    bool sentinel;
} sf_row;

typedef struct {
    int booked_minor;
    int mirror_minor;
    int gap_minor;
    int orphan_lines;
} sf_tally;

sf_tally sf_meter_span(
    const sf_row *rows,
    size_t count,
    const char *posted,
    const int *anchor
);

#endif
