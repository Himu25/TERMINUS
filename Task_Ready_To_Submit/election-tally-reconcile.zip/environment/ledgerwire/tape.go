package ledgerwire

// TapeRow is one replayed line from the vendor or booking side.
type TapeRow struct {
	Wire     string `json:"wire_tag"`
	Ink      string `json:"ink"`
	Grain    int    `json:"grain"`
	Face     string `json:"face"`
	Band     string `json:"band"`
	Sentinel bool   `json:"sentinel"`
}

// Bundle is one deterministic scenario under /app/cases.
type Bundle struct {
	ScenarioLabel    string    `json:"scenario_label"`
	PostedLaneToken  string    `json:"posted_lane_token"`
	MirrorAnchorHint *int      `json:"mirror_anchor_hint"`
	PairSentinelWire string    `json:"pair_sentinel_wire"`
	Tape             []TapeRow `json:"tape"`
}
