// Package ledgerwire holds wire-tape shapes shared across packages.
package ledgerwire
