#!/bin/bash
set -euo pipefail

# Mixed Rust/Go link step: CGO_ENABLED=1 binds the Go binary to libseal_fold.a.
export PATH="/usr/local/cargo/bin:/usr/local/go/bin:${PATH}"
export CGO_ENABLED=1

mkdir -p /app/bin
cd /app/sum_seal
cargo build --release --locked
cd /app
GOFLAGS=-mod=mod go build -o /app/bin/ecount ./cmd/ecount
